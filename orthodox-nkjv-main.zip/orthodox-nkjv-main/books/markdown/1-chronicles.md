# 1-chronicles

## Chapter 1

1. Adam, Seth, Enosh,

2. Cainan, Mahalalel, Jared,

3. Enoch, Methuselah, Lamech,

4. Noah, Shem, Ham, and Japheth.

5. The sons of Japheth were Gomer, Magog, Madai, Javan, Tubal, Meshech, and Tiras.

6. The sons of Gomer were Ashkenaz, Diphath, and Togarmah.

7. The sons of Javan were Elishah, Tarshishah, Kittim, and Rodanim.

8. The sons of Ham were Cush, Mizraim, Put, and Canaan.

9. The sons of Cush were Seba, Havilah, Sabta, Raama, and Sabtecha. The sons of Raama were Sheba and Dedan.

10. Cush begot Nimrod; he began to be a mighty one on the earth.

11. Mizraim begot Ludim, Anamim, Lehabim, Naphtuhim,

12. Pathrusim, Casluhim (from whom came the Philistines and the Caphtorim).

13. Canaan begot Sidon, his firstborn, and Heth;

14. the Jebusite, the Amorite, and the Girgashite;

15. the Hivite, the Arkite, and the Sinite;

16. the Arvadite, the Zemarite, and the Hamathite.

17. The sons of Shem were Elam, Asshur, Arphaxad, Lud, Aram, Uz, Hul, Gether, and Meshech.

18. Arphaxad begot Shelah, and Shelah begot Eber.

19. To Eber were born two sons: the name of one was Peleg, for in his days the earth was divided; and his brother's name was Joktan.

20. Joktan begot Almodad, Sheleph, Hazarmaveth, Jerah,

21. Hadoram, Uzal, Diklah,

22. Ebal, Abimael, Sheba,

23. Ophir, Havilah, and Jobab. All these were the sons of Joktan.

24. Shem, Arphaxad, Shelah,

25. Eber, Peleg, Reu,

26. Serug, Nahor, Terah,

27. and Abram, who is Abraham.

28. The sons of Abraham were Isaac and Ishmael.

29. These are their genealogies: The firstborn of Ishmael was Nebajoth; then Kedar, Adbeel, Mibsam,

30. Mishma, Dumah, Massa, Hadad, Tema,

31. Jetur, Naphish, and Kedemah. These were the sons of Ishmael.

32. Now the sons born to Keturah, Abraham's concubine, were Zimran, Jokshan, Medan, Midian, Ishbak, and Shuah. The sons of Jokshan were Sheba and Dedan.

33. The sons of Midian were Ephah, Epher, Hanoch, Abida, and Eldaah. All these were the children of Keturah.

34. And Abraham begot Isaac. The sons of Isaac were Esau and Israel.

35. The sons of Esau were Eliphaz, Reuel, Jeush, Jaalam, and Korah.

36. And the sons of Eliphaz were Teman, Omar, Zephi, Gatam, and Kenaz; and by Timna, Amalek.

37. The sons of Reuel were Nahath, Zerah, Shammah, and Mizzah.

38. The sons of Seir were Lotan, Shobal, Zibeon, Anah, Dishon, Ezer, and Dishan.

39. And the sons of Lotan were Hori and Homam; Lotan's sister was Timna.

40. The sons of Shobal were Alian, Manahath, Ebal, Shephi, and Onam. The sons of Zibeon were Ajah and Anah.

41. The son of Anah was Dishon. The sons of Dishon were Hamran, Eshban, Ithran, and Cheran.

42. The sons of Ezer were Bilhan, Zaavan, and Jaakan. The sons of Dishan were Uz and Aran.

43. Now these were the kings who reigned in the land of Edom before a king reigned over the children of Israel: Bela the son of Beor, and the name of his city was Dinhabah.

44. And when Bela died, Jobab the son of Zerah of Bozrah reigned in his place.

45. When Jobab died, Husham of the land of the Temanites reigned in his place.

46. And when Husham died, Hadad the son of Bedad, who attacked Midian in the field of Moab, reigned in his place. The name of his city was Avith.

47. When Hadad died, Samlah of Masrekah reigned in his place.

48. And when Samlah died, Saul of Rehoboth-by-the-River reigned in his place.

49. When Saul died, Baal-Hanan the son of Achbor reigned in his place.

50. And when Baal-Hanan died, Hadad reigned in his place; and the name of his city was Pai. His wife's name was Mehetabel the daughter of Matred, the daughter of Mezahab.

51. Hadad died also. And the chiefs of Edom were Chief Timnah, Chief Aliah, Chief Jetheth,

52. Chief Aholibamah, Chief Elah, Chief Pinon,

53. Chief Kenaz, Chief Teman, Chief Mibzar,

54. Chief Magdiel, and Chief Iram. These were the chiefs of Edom.

## Chapter 2

1. These were the sons of Israel: Reuben, Simeon, Levi, Judah, Issachar, Zebulun,

2. Dan, Joseph, Benjamin, Naphtali, Gad, and Asher.

3. The sons of Judah were Er, Onan, and Shelah. These three were born to him by the daughter of Shua, the Canaanitess. Er, the firstborn of Judah, was wicked in the sight of the LORD; so He killed him.

4. And Tamar, his daughter-in-law, bore him Perez and Zerah. All the sons of Judah were five.

5. The sons of Perez were Hezron and Hamul.

6. The sons of Zerah were Zimri, Ethan, Heman, Calcol, and Dara--five of them in all.

7. The son of Carmi was Achar, the troubler of Israel, who transgressed in the accursed thing.

8. The son of Ethan was Azariah.

9. Also the sons of Hezron who were born to him were Jerahmeel, Ram, and Chelubai.

10. Ram begot Amminadab, and Amminadab begot Nahshon, leader of the children of Judah;

11. Nahshon begot Salma, and Salma begot Boaz;

12. Boaz begot Obed, and Obed begot Jesse;

13. Jesse begot Eliab his firstborn, Abinadab the second, Shimea the third,

14. Nethanel the fourth, Raddai the fifth,

15. Ozem the sixth, and David the seventh.

16. Now their sisters were Zeruiah and Abigail. And the sons of Zeruiah were Abishai, Joab, and Asahel--three.

17. Abigail bore Amasa; and the father of Amasa was Jether the Ishmaelite.

18. Caleb the son of Hezron had children by Azubah, his wife, and by Jerioth. Now these were her sons: Jesher, Shobab, and Ardon.

19. When Azubah died, Caleb took Ephrath as his wife, who bore him Hur.

20. And Hur begot Uri, and Uri begot Bezalel.

21. Now afterward Hezron went in to the daughter of Machir the father of Gilead, whom he married when he was sixty years old; and she bore him Segub.

22. Segub begot Jair, who had twenty-three cities in the land of Gilead.

23. (Geshur and Syria took from them the towns of Jair, with Kenath and its towns--sixty towns.) All these belonged to the sons of Machir the father of Gilead.

24. After Hezron died in Caleb Ephrathah, Hezron's wife Abijah bore him Ashhur the father of Tekoa.

25. The sons of Jerahmeel, the firstborn of Hezron, were Ram, the firstborn, and Bunah, Oren, Ozem, and Ahijah.

26. Jerahmeel had another wife, whose name was Atarah; she was the mother of Onam.

27. The sons of Ram, the firstborn of Jerahmeel, were Maaz, Jamin, and Eker.

28. The sons of Onam were Shammai and Jada. The sons of Shammai were Nadab and Abishur.

29. And the name of the wife of Abishur was Abihail, and she bore him Ahban and Molid.

30. The sons of Nadab were Seled and Appaim; Seled died without children.

31. The son of Appaim was Ishi, the son of Ishi was Sheshan, and Sheshan's son was Ahlai.

32. The sons of Jada, the brother of Shammai, were Jether and Jonathan; Jether died without children.

33. The sons of Jonathan were Peleth and Zaza. These were the sons of Jerahmeel.

34. Now Sheshan had no sons, only daughters. And Sheshan had an Egyptian servant whose name was Jarha.

35. Sheshan gave his daughter to Jarha his servant as wife, and she bore him Attai.

36. Attai begot Nathan, and Nathan begot Zabad;

37. Zabad begot Ephlal, and Ephlal begot Obed;

38. Obed begot Jehu, and Jehu begot Azariah;

39. Azariah begot Helez, and Helez begot Eleasah;

40. Eleasah begot Sismai, and Sismai begot Shallum;

41. Shallum begot Jekamiah, and Jekamiah begot Elishama.

42. The descendants of Caleb the brother of Jerahmeel were Mesha, his firstborn, who was the father of Ziph, and the sons of Mareshah the father of Hebron.

43. The sons of Hebron were Korah, Tappuah, Rekem, and Shema.

44. Shema begot Raham the father of Jorkoam, and Rekem begot Shammai.

45. And the son of Shammai was Maon, and Maon was the father of Beth Zur.

46. Ephah, Caleb's concubine, bore Haran, Moza, and Gazez; and Haran begot Gazez.

47. And the sons of Jahdai were Regem, Jotham, Geshan, Pelet, Ephah, and Shaaph.

48. Maachah, Caleb's concubine, bore Sheber and Tirhanah.

49. She also bore Shaaph the father of Madmannah, Sheva the father of Machbenah and the father of Gibea. And the daughter of Caleb was Achsah.

50. These were the descendants of Caleb: The sons of Hur, the firstborn of Ephrathah, were Shobal the father of Kirjath Jearim,

51. Salma the father of Bethlehem, and Hareph the father of Beth Gader.

52. And Shobal the father of Kirjath Jearim had descendants: Haroeh, and half of the families of Manuhoth.

53. The families of Kirjath Jearim were the Ithrites, the Puthites, the Shumathites, and the Mishraites. From these came the Zorathites and the Eshtaolites.

54. The sons of Salma were Bethlehem, the Netophathites, Atroth Beth Joab, half of the Manahethites, and the Zorites.

55. And the families of the scribes who dwelt at Jabez were the Tirathites, the Shimeathites, and the Suchathites. These were the Kenites who came from Hammath, the father of the house of Rechab.

## Chapter 3

1. The Family of David Now these were the sons of David who were born to him in Hebron: The firstborn was Amnon, by Ahinoam the Jezreelitess; the second, Daniel, by Abigail the Carmelitess;

2. the third, Absalom the son of Maacah, the daughter of Talmai, king of Geshur; the fourth, Adonijah the son of Haggith;

3. the fifth, Shephatiah, by Abital; the sixth, Ithream, by his wife Eglah.

4. These six were born to him in Hebron. There he reigned seven years and six months, and in Jerusalem he reigned thirty-three years.

5. And these were born to him in Jerusalem: Shimea, Shobab, Nathan, and Solomon--four by Bathshua the daughter of Ammiel.

6. Also there were Ibhar, Elishama, Eliphelet,

7. Nogah, Nepheg, Japhia,

8. Elishama, Eliada, and Eliphelet--nine in all.

9. These were all the sons of David, besides the sons of the concubines, and Tamar their sister.

10. Solomon's son was Rehoboam; Abijah was his son, Asa his son, Jehoshaphat his son,

11. Joram his son, Ahaziah his son, Joash his son,

12. Amaziah his son, Azariah his son, Jotham his son,

13. Ahaz his son, Hezekiah his son, Manasseh his son,

14. Amon his son, and Josiah his son.

15. The sons of Josiah were Johanan the firstborn, the second Jehoiakim, the third Zedekiah, and the fourth Shallum.

16. The sons of Jehoiakim were Jeconiah his son and Zedekiah his son.

17. And the sons of Jeconiah were Assir, Shealtiel his son,

18. and Malchiram, Pedaiah, Shenazzar, Jecamiah, Hoshama, and Nedabiah.

19. The sons of Pedaiah were Zerubbabel and Shimei. The sons of Zerubbabel were Meshullam, Hananiah, Shelomith their sister,

20. and Hashubah, Ohel, Berechiah, Hasadiah, and Jushab-Hesed--five in all.

21. The sons of Hananiah were Pelatiah and Jeshaiah, the sons of Rephaiah, the sons of Arnan, the sons of Obadiah, and the sons of Shechaniah.

22. The son of Shechaniah was Shemaiah. The sons of Shemaiah were Hattush, Igal, Bariah, Neariah, and Shaphat--six in all.

23. The sons of Neariah were Elioenai, Hezekiah, and Azrikam--three in all.

24. The sons of Elioenai were Hodaviah, Eliashib, Pelaiah, Akkub, Johanan, Delaiah, and Anani--seven in all.

## Chapter 4

1. The sons of Judah were Perez, Hezron, Carmi, Hur, and Shobal.

2. And Reaiah the son of Shobal begot Jahath, and Jahath begot Ahumai and Lahad. These were the families of the Zorathites.

3. These were the sons of the father of Etam: Jezreel, Ishma, and Idbash; and the name of their sister was Hazelelponi;

4. and Penuel was the father of Gedor, and Ezer was the father of Hushah. These were the sons of Hur, the firstborn of Ephrathah the father of Bethlehem.

5. And Ashhur the father of Tekoa had two wives, Helah and Naarah.

6. Naarah bore him Ahuzzam, Hepher, Temeni, and Haahashtari. These were the sons of Naarah.

7. The sons of Helah were Zereth, Zohar, and Ethnan;

8. and Koz begot Anub, Zobebah, and the families of Aharhel the son of Harum.

9. Now Jabez was more honorable than his brothers, and his mother called his name Jabez, saying, "Because I bore him in pain."

10. And Jabez called on the God of Israel saying, "Oh, that You would bless me indeed, and enlarge my territory, that Your hand would be with me, and that You would keep me from evil, that I may not cause pain!" So God granted him what he requested.

11. Chelub the brother of Shuhah begot Mehir, who was the father of Eshton.

12. And Eshton begot Beth-Rapha, Paseah, and Tehinnah the father of Ir-Nahash. These were the men of Rechah.

13. The sons of Kenaz were Othniel and Seraiah. The sons of Othniel were Hathath,

14. and Meonothai who begot Ophrah. Seraiah begot Joab the father of Ge Harashim, for they were craftsmen.

15. The sons of Caleb the son of Jephunneh were Iru, Elah, and Naam. The son of Elah was Kenaz.

16. The sons of Jehallelel were Ziph, Ziphah, Tiria, and Asarel.

17. The sons of Ezrah were Jether, Mered, Epher, and Jalon. And Mered's wife bore Miriam, Shammai, and Ishbah the father of Eshtemoa.

18. (His wife Jehudijah bore Jered the father of Gedor, Heber the father of Sochoh, and Jekuthiel the father of Zanoah.) And these were the sons of Bithiah the daughter of Pharaoh, whom Mered took.

19. The sons of Hodiah's wife, the sister of Naham, were the fathers of Keilah the Garmite and of Eshtemoa the Maachathite.

20. And the sons of Shimon were Amnon, Rinnah, Ben-Hanan, and Tilon. And the sons of Ishi were Zoheth and Ben-Zoheth.

21. The sons of Shelah the son of Judah were Er the father of Lecah, Laadah the father of Mareshah, and the families of the house of the linen workers of the house of Ashbea;

22. also Jokim, the men of Chozeba, and Joash; Saraph, who ruled in Moab, and Jashubi-Lehem. Now the records are ancient.

23. These were the potters and those who dwell at Netaim and Gederah; there they dwelt with the king for his work.

24. The sons of Simeon were Nemuel, Jamin, Jarib, Zerah, and Shaul,

25. Shallum his son, Mibsam his son, and Mishma his son.

26. And the sons of Mishma were Hamuel his son, Zacchur his son, and Shimei his son.

27. Shimei had sixteen sons and six daughters; but his brothers did not have many children, nor did any of their families multiply as much as the children of Judah.

28. They dwelt at Beersheba, Moladah, Hazar Shual,

29. Bilhah, Ezem, Tolad,

30. Bethuel, Hormah, Ziklag,

31. Beth Marcaboth, Hazar Susim, Beth Biri, and at Shaaraim. These were their cities until the reign of David.

32. And their villages were Etam, Ain, Rimmon, Tochen, and Ashan--five cities--

33. and all the villages that were around these cities as far as Baal. These were their dwelling places, and they maintained their genealogy:

34. Meshobab, Jamlech, and Joshah the son of Amaziah;

35. Joel, and Jehu the son of Joshibiah, the son of Seraiah, the son of Asiel;

36. Elioenai, Jaakobah, Jeshohaiah, Asaiah, Adiel, Jesimiel, and Benaiah;

37. Ziza the son of Shiphi, the son of Allon, the son of Jedaiah, the son of Shimri, the son of Shemaiah--

38. these mentioned by name were leaders in their families, and their father's house increased greatly.

39. So they went to the entrance of Gedor, as far as the east side of the valley, to seek pasture for their flocks.

40. And they found rich, good pasture, and the land was broad, quiet, and peaceful; for some Hamites formerly lived there.

41. These recorded by name came in the days of Hezekiah king of Judah; and they attacked their tents and the Meunites who were found there, and utterly destroyed them, as it is to this day. So they dwelt in their place, because there was pasture for their flocks there.

42. Now some of them, five hundred men of the sons of Simeon, went to Mount Seir, having as their captains Pelatiah, Neariah, Rephaiah, and Uzziel, the sons of Ishi.

43. And they defeated the rest of the Amalekites who had escaped. They have dwelt there to this day.

## Chapter 5

1. Now the sons of Reuben the firstborn of Israel--he was indeed the firstborn, but because he defiled his father's bed, his birthright was given to the sons of Joseph, the son of Israel, so that the genealogy is not listed according to the birthright;

2. yet Judah prevailed over his brothers, and from him came a ruler, although the birthright was Joseph's--

3. the sons of Reuben the firstborn of Israel were Hanoch, Pallu, Hezron, and Carmi.

4. The sons of Joel were Shemaiah his son, Gog his son, Shimei his son,

5. Micah his son, Reaiah his son, Baal his son,

6. and Beerah his son, whom Tiglath-Pileser king of Assyria carried into captivity. He was leader of the Reubenites.

7. And his brethren by their families, when the genealogy of their generations was registered: the chief, Jeiel, and Zechariah,

8. and Bela the son of Azaz, the son of Shema, the son of Joel, who dwelt in Aroer, as far as Nebo and Baal Meon.

9. Eastward they settled as far as the entrance of the wilderness this side of the River Euphrates, because their cattle had multiplied in the land of Gilead.

10. Now in the days of Saul they made war with the Hagrites, who fell by their hand; and they dwelt in their tents throughout the entire area east of Gilead.

11. And the children of Gad dwelt next to them in the land of Bashan as far as Salcah:

12. Joel was the chief, Shapham the next, then Jaanai and Shaphat in Bashan,

13. and their brethren of their father's house: Michael, Meshullam, Sheba, Jorai, Jachan, Zia, and Eber--seven in all.

14. These were the children of Abihail the son of Huri, the son of Jaroah, the son of Gilead, the son of Michael, the son of Jeshishai, the son of Jahdo, the son of Buz;

15. Ahi the son of Abdiel, the son of Guni, was chief of their father's house.

16. And the Gadites dwelt in Gilead, in Bashan and in its villages, and in all the common-lands of Sharon within their borders.

17. All these were registered by genealogies in the days of Jotham king of Judah, and in the days of Jeroboam king of Israel.

18. The sons of Reuben, the Gadites, and half the tribe of Manasseh had forty-four thousand seven hundred and sixty valiant men, men able to bear shield and sword, to shoot with the bow, and skillful in war, who went to war.

19. They made war with the Hagrites, Jetur, Naphish, and Nodab.

20. And they were helped against them, and the Hagrites were delivered into their hand, and all who were with them, for they cried out to God in the battle. He heeded their prayer, because they put their trust in Him.

21. Then they took away their livestock--fifty thousand of their camels, two hundred and fifty thousand of their sheep, and two thousand of their donkeys--also one hundred thousand of their men;

22. for many fell dead, because the war was God's. And they dwelt in their place until the captivity.

23. So the children of the half-tribe of Manasseh dwelt in the land. Their numbers increased from Bashan to Baal Hermon, that is, to Senir, or Mount Hermon.

24. These were the heads of their fathers' houses: Epher, Ishi, Eliel, Azriel, Jeremiah, Hodaviah, and Jahdiel. They were mighty men of valor, famous men, and heads of their fathers' houses.

25. And they were unfaithful to the God of their fathers, and played the harlot after the gods of the peoples of the land, whom God had destroyed before them.

26. So the God of Israel stirred up the spirit of Pul king of Assyria, that is, Tiglath-Pileser king of Assyria. He carried the Reubenites, the Gadites, and the half-tribe of Manasseh into captivity. He took them to Halah, Habor, Hara, and the river of Gozan to this day.

## Chapter 6

1. The sons of Levi were Gershon, Kohath, and Merari.

2. The sons of Kohath were Amram, Izhar, Hebron, and Uzziel.

3. The children of Amram were Aaron, Moses, and Miriam. And the sons of Aaron were Nadab, Abihu, Eleazar, and Ithamar.

4. Eleazar begot Phinehas, and Phinehas begot Abishua;

5. Abishua begot Bukki, and Bukki begot Uzzi;

6. Uzzi begot Zerahiah, and Zerahiah begot Meraioth;

7. Meraioth begot Amariah, and Amariah begot Ahitub;

8. Ahitub begot Zadok, and Zadok begot Ahimaaz;

9. Ahimaaz begot Azariah, and Azariah begot Johanan;

10. Johanan begot Azariah (it was he who ministered as priest in the temple that Solomon built in Jerusalem);

11. Azariah begot Amariah, and Amariah begot Ahitub;

12. Ahitub begot Zadok, and Zadok begot Shallum;

13. Shallum begot Hilkiah, and Hilkiah begot Azariah;

14. Azariah begot Seraiah, and Seraiah begot Jehozadak.

15. Jehozadak went into captivity when the LORD carried Judah and Jerusalem into captivity by the hand of Nebuchadnezzar.

16. The sons of Levi were Gershon, Kohath, and Merari.

17. These are the names of the sons of Gershon: Libni and Shimei.

18. The sons of Kohath were Amram, Izhar, Hebron, and Uzziel.

19. The sons of Merari were Mahli and Mushi. Now these are the families of the Levites according to their fathers:

20. Of Gershon were Libni his son, Jahath his son, Zimmah his son,

21. Joah his son, Iddo his son, Zerah his son, and Jeatherai his son.

22. The sons of Kohath were Amminadab his son, Korah his son, Assir his son,

23. Elkanah his son, Ebiasaph his son, Assir his son,

24. Tahath his son, Uriel his son, Uzziah his son, and Shaul his son.

25. The sons of Elkanah were Amasai and Ahimoth.

26. As for Elkanah, the sons of Elkanah were Zophai his son, Nahath his son,

27. Eliab his son, Jeroham his son, and Elkanah his son.

28. The sons of Samuel were Joel the firstborn, and Abijah the second.

29. The sons of Merari were Mahli, Libni his son, Shimei his son, Uzzah his son,

30. Shimea his son, Haggiah his son, and Asaiah his son.

31. Now these are the men whom David appointed over the service of song in the house of the LORD, after the ark came to rest.

32. They were ministering with music before the dwelling place of the tabernacle of meeting, until Solomon had built the house of the LORD in Jerusalem, and they served in their office according to their order.

33. And these are the ones who ministered with their sons: Of the sons of the Kohathites were Heman the singer, the son of Joel, the son of Samuel,

34. the son of Elkanah, the son of Jeroham, the son of Eliel, the son of Toah,

35. the son of Zuph, the son of Elkanah, the son of Mahath, the son of Amasai,

36. the son of Elkanah, the son of Joel, the son of Azariah, the son of Zephaniah,

37. the son of Tahath, the son of Assir, the son of Ebiasaph, the son of Korah,

38. the son of Izhar, the son of Kohath, the son of Levi, the son of Israel.

39. And his brother Asaph, who stood at his right hand, was Asaph the son of Berachiah, the son of Shimea,

40. the son of Michael, the son of Baaseiah, the son of Malchijah,

41. the son of Ethni, the son of Zerah, the son of Adaiah,

42. the son of Ethan, the son of Zimmah, the son of Shimei,

43. the son of Jahath, the son of Gershon, the son of Levi.

44. Their brethren, the sons of Merari, on the left hand, were Ethan the son of Kishi, the son of Abdi, the son of Malluch,

45. the son of Hashabiah, the son of Amaziah, the son of Hilkiah,

46. the son of Amzi, the son of Bani, the son of Shamer,

47. the son of Mahli, the son of Mushi, the son of Merari, the son of Levi.

48. And their brethren, the Levites, were appointed to every kind of service of the tabernacle of the house of God.

49. But Aaron and his sons offered sacrifices on the altar of burnt offering and on the altar of incense, for all the work of the Most Holy Place, and to make atonement for Israel, according to all that Moses the servant of God had commanded.

50. Now these are the sons of Aaron: Eleazar his son, Phinehas his son, Abishua his son,

51. Bukki his son, Uzzi his son, Zerahiah his son,

52. Meraioth his son, Amariah his son, Ahitub his son,

53. Zadok his son, and Ahimaaz his son.

54. Now these are their dwelling places throughout their settlements in their territory, for they were given by lot to the sons of Aaron, of the family of the Kohathites:

55. They gave them Hebron in the land of Judah, with its surrounding common-lands.

56. But the fields of the city and its villages they gave to Caleb the son of Jephunneh.

57. And to the sons of Aaron they gave one of the cities of refuge, Hebron; also Libnah with its common-lands, Jattir, Eshtemoa with its common-lands,

58. Hilen with its common-lands, Debir with its common-lands,

59. Ashan with its common-lands, and Beth Shemesh with its common-lands.

60. And from the tribe of Benjamin: Geba with its common-lands, Alemeth with its common-lands, and Anathoth with its common-lands. All their cities among their families were thirteen.

61. To the rest of the family of the tribe of the Kohathites they gave by lot ten cities from half the tribe of Manasseh.

62. And to the sons of Gershon, throughout their families, they gave thirteen cities from the tribe of Issachar, from the tribe of Asher, from the tribe of Naphtali, and from the tribe of Manasseh in Bashan.

63. To the sons of Merari, throughout their families, they gave twelve cities from the tribe of Reuben, from the tribe of Gad, and from the tribe of Zebulun.

64. So the children of Israel gave these cities with their common-lands to the Levites.

65. And they gave by lot from the tribe of the children of Judah, from the tribe of the children of Simeon, and from the tribe of the children of Benjamin these cities which are called by their names.

66. Now some of the families of the sons of Kohath were given cities as their territory from the tribe of Ephraim.

67. And they gave them one of the cities of refuge, Shechem with its common-lands, in the mountains of Ephraim, also Gezer with its common-lands,

68. Jokmeam with its common-lands, Beth Horon with its common-lands,

69. Aijalon with its common-lands, and Gath Rimmon with its common-lands.

70. And from the half-tribe of Manasseh: Aner with its common-lands and Bileam with its common-lands, for the rest of the family of the sons of Kohath.

71. From the family of the half-tribe of Manasseh the sons of Gershon were given Golan in Bashan with its common-lands and Ashtaroth with its common-lands.

72. And from the tribe of Issachar: Kedesh with its common-lands, Daberath with its common-lands,

73. Ramoth with its common-lands, and Anem with its common-lands.

74. And from the tribe of Asher: Mashal with its common-lands, Abdon with its common-lands,

75. Hukok with its common-lands, and Rehob with its common-lands.

76. And from the tribe of Naphtali: Kedesh in Galilee with its common-lands, Hammon with its common-lands, and Kirjathaim with its common-lands.

77. From the tribe of Zebulun the rest of the children of Merari were given Rimmon with its common-lands and Tabor with its common-lands.

78. And on the other side of the Jordan, across from Jericho, on the east side of the Jordan, they were given from the tribe of Reuben: Bezer in the wilderness with its common-lands, Jahzah with its common-lands,

79. Kedemoth with its common-lands, and Mephaath with its common-lands.

80. And from the tribe of Gad: Ramoth in Gilead with its common-lands, Mahanaim with its common-lands,

81. Heshbon with its common-lands, and Jazer with its common-lands.

## Chapter 7

1. The sons of Issachar were Tola, Puah, Jashub, and Shimron--four in all.

2. The sons of Tola were Uzzi, Rephaiah, Jeriel, Jahmai, Jibsam, and Shemuel, heads of their father's house. The sons of Tola were mighty men of valor in their generations; their number in the days of David was twenty-two thousand six hundred.

3. The son of Uzzi was Izrahiah, and the sons of Izrahiah were Michael, Obadiah, Joel, and Ishiah. All five of them were chief men.

4. And with them, by their generations, according to their fathers' houses, were thirty-six thousand troops ready for war; for they had many wives and sons.

5. Now their brethren among all the families of Issachar were mighty men of valor, listed by their genealogies, eighty-seven thousand in all.

6. The sons of Benjamin were Bela, Becher, and Jediael--three in all.

7. The sons of Bela were Ezbon, Uzzi, Uzziel, Jerimoth, and Iri--five in all. They were heads of their fathers' houses, and they were listed by their genealogies, twenty-two thousand and thirty-four mighty men of valor.

8. The sons of Becher were Zemirah, Joash, Eliezer, Elioenai, Omri, Jerimoth, Abijah, Anathoth, and Alemeth. All these are the sons of Becher.

9. And they were recorded by genealogy according to their generations, heads of their fathers' houses, twenty thousand two hundred mighty men of valor.

10. The son of Jediael was Bilhan, and the sons of Bilhan were Jeush, Benjamin, Ehud, Chenaanah, Zethan, Tharshish, and Ahishahar.

11. All these sons of Jediael were heads of their fathers' houses; there were seventeen thousand two hundred mighty men of valor fit to go out for war and battle.

12. Shuppim and Huppim were the sons of Ir, and Hushim was the son of Aher.

13. The sons of Naphtali were Jahziel, Guni, Jezer, and Shallum, the sons of Bilhah.

14. The descendants of Manasseh: his Syrian concubine bore him Machir the father of Gilead, the father of Asriel.

15. Machir took as his wife the sister of Huppim and Shuppim, whose name was Maachah. The name of Gilead's grandson was Zelophehad, but Zelophehad begot only daughters.

16. (Maachah the wife of Machir bore a son, and she called his name Peresh. The name of his brother was Sheresh, and his sons were Ulam and Rakem.

17. The son of Ulam was Bedan.) These were the descendants of Gilead the son of Machir, the son of Manasseh.

18. His sister Hammoleketh bore Ishhod, Abiezer, and Mahlah.

19. And the sons of Shemida were Ahian, Shechem, Likhi, and Aniam.

20. The sons of Ephraim were Shuthelah, Bered his son, Tahath his son, Eladah his son, Tahath his son,

21. Zabad his son, Shuthelah his son, and Ezer and Elead. The men of Gath who were born in that land killed them because they came down to take away their cattle.

22. Then Ephraim their father mourned many days, and his brethren came to comfort him.

23. And when he went in to his wife, she conceived and bore a son; and he called his name Beriah, because tragedy had come upon his house.

24. Now his daughter was Sheerah, who built Lower and Upper Beth Horon and Uzzen Sheerah;

25. and Rephah was his son, as well as Resheph, and Telah his son, Tahan his son,

26. Laadan his son, Ammihud his son, Elishama his son,

27. Nun his son, and Joshua his son.

28. Now their possessions and dwelling places were Bethel and its towns: to the east Naaran, to the west Gezer and its towns, and Shechem and its towns, as far as Ayyah and its towns;

29. and by the borders of the children of Manasseh were Beth Shean and its towns, Taanach and its towns, Megiddo and its towns, Dor and its towns. In these dwelt the children of Joseph, the son of Israel.

30. The sons of Asher were Imnah, Ishvah, Ishvi, Beriah, and their sister Serah.

31. The sons of Beriah were Heber and Malchiel, who was the father of Birzaith.

32. And Heber begot Japhlet, Shomer, Hotham, and their sister Shua.

33. The sons of Japhlet were Pasach, Bimhal, and Ashvath. These were the children of Japhlet.

34. The sons of Shemer were Ahi, Rohgah, Jehubbah, and Aram.

35. And the sons of his brother Helem were Zophah, Imna, Shelesh, and Amal.

36. The sons of Zophah were Suah, Harnepher, Shual, Beri, Imrah,

37. Bezer, Hod, Shamma, Shilshah, Jithran, and Beera.

38. The sons of Jether were Jephunneh, Pispah, and Ara.

39. The sons of Ulla were Arah, Haniel, and Rizia.

40. All these were the children of Asher, heads of their fathers' houses, choice men, mighty men of valor, chief leaders. And they were recorded by genealogies among the army fit for battle; their number was twenty-six thousand.

## Chapter 8

1. Now Benjamin begot Bela his firstborn, Ashbel the second, Aharah the third,

2. Nohah the fourth, and Rapha the fifth.

3. The sons of Bela were Addar, Gera, Abihud,

4. Abishua, Naaman, Ahoah,

5. Gera, Shephuphan, and Huram.

6. These are the sons of Ehud, who were the heads of the fathers' houses of the inhabitants of Geba, and who forced them to move to Manahath:

7. Naaman, Ahijah, and Gera who forced them to move. He begot Uzza and Ahihud.

8. Also Shaharaim had children in the country of Moab, after he had sent away Hushim and Baara his wives.

9. By Hodesh his wife he begot Jobab, Zibia, Mesha, Malcam,

10. Jeuz, Sachiah, and Mirmah. These were his sons, heads of their fathers' houses.

11. And by Hushim he begot Abitub and Elpaal.

12. The sons of Elpaal were Eber, Misham, and Shemed, who built Ono and Lod with its towns;

13. and Beriah and Shema, who were heads of their fathers' houses of the inhabitants of Aijalon, who drove out the inhabitants of Gath.

14. Ahio, Shashak, Jeremoth,

15. Zebadiah, Arad, Eder,

16. Michael, Ispah, and Joha were the sons of Beriah.

17. Zebadiah, Meshullam, Hizki, Heber,

18. Ishmerai, Jizliah, and Jobab were the sons of Elpaal.

19. Jakim, Zichri, Zabdi,

20. Elienai, Zillethai, Eliel,

21. Adaiah, Beraiah, and Shimrath were the sons of Shimei.

22. Ishpan, Eber, Eliel,

23. Abdon, Zichri, Hanan,

24. Hananiah, Elam, Antothijah,

25. Iphdeiah, and Penuel were the sons of Shashak.

26. Shamsherai, Shehariah, Athaliah,

27. Jaareshiah, Elijah, and Zichri were the sons of Jeroham.

28. These were heads of the fathers' houses by their generations, chief men. These dwelt in Jerusalem.

29. Now the father of Gibeon, whose wife's name was Maacah, dwelt at Gibeon.

30. And his firstborn son was Abdon, then Zur, Kish, Baal, Nadab,

31. Gedor, Ahio, Zecher,

32. and Mikloth, who begot Shimeah. They also dwelt alongside their relatives in Jerusalem, with their brethren.

33. Ner begot Kish, Kish begot Saul, and Saul begot Jonathan, Malchishua, Abinadab, and Esh-Baal.

34. The son of Jonathan was Merib-Baal, and Merib-Baal begot Micah.

35. The sons of Micah were Pithon, Melech, Tarea, and Ahaz.

36. And Ahaz begot Jehoaddah; Jehoaddah begot Alemeth, Azmaveth, and Zimri; and Zimri begot Moza.

37. Moza begot Binea, Raphah his son, Eleasah his son, and Azel his son.

38. Azel had six sons whose names were these: Azrikam, Bocheru, Ishmael, Sheariah, Obadiah, and Hanan. All these were the sons of Azel.

39. And the sons of Eshek his brother were Ulam his firstborn, Jeush the second, and Eliphelet the third.

40. The sons of Ulam were mighty men of valor--archers. They had many sons and grandsons, one hundred and fifty in all. These were all sons of Benjamin.

## Chapter 9

1. So all Israel was recorded by genealogies, and indeed, they were inscribed in the book of the kings of Israel. But Judah was carried away captive to Babylon because of their unfaithfulness.

2. And the first inhabitants who dwelt in their possessions in their cities were Israelites, priests, Levites, and the Nethinim.

3. Now in Jerusalem the children of Judah dwelt, and some of the children of Benjamin, and of the children of Ephraim and Manasseh:

4. Uthai the son of Ammihud, the son of Omri, the son of Imri, the son of Bani, of the descendants of Perez, the son of Judah.

5. Of the Shilonites: Asaiah the firstborn and his sons.

6. Of the sons of Zerah: Jeuel, and their brethren--six hundred and ninety.

7. Of the sons of Benjamin: Sallu the son of Meshullam, the son of Hodaviah, the son of Hassenuah;

8. Ibneiah the son of Jeroham; Elah the son of Uzzi, the son of Michri; Meshullam the son of Shephatiah, the son of Reuel, the son of Ibnijah;

9. and their brethren, according to their generations--nine hundred and fifty-six. All these men were heads of a father's house in their fathers' houses.

10. Of the priests: Jedaiah, Jehoiarib, and Jachin;

11. Azariah the son of Hilkiah, the son of Meshullam, the son of Zadok, the son of Meraioth, the son of Ahitub, the officer over the house of God;

12. Adaiah the son of Jeroham, the son of Pashur, the son of Malchijah; Maasai the son of Adiel, the son of Jahzerah, the son of Meshullam, the son of Meshillemith, the son of Immer;

13. and their brethren, heads of their fathers' houses--one thousand seven hundred and sixty. They were very able men for the work of the service of the house of God.

14. Of the Levites: Shemaiah the son of Hasshub, the son of Azrikam, the son of Hashabiah, of the sons of Merari;

15. Bakbakkar, Heresh, Galal, and Mattaniah the son of Micah, the son of Zichri, the son of Asaph;

16. Obadiah the son of Shemaiah, the son of Galal, the son of Jeduthun; and Berechiah the son of Asa, the son of Elkanah, who lived in the villages of the Netophathites.

17. And the gatekeepers were Shallum, Akkub, Talmon, Ahiman, and their brethren. Shallum was the chief.

18. Until then they had been gatekeepers for the camps of the children of Levi at the King's Gate on the east.

19. Shallum the son of Kore, the son of Ebiasaph, the son of Korah, and his brethren, from his father's house, the Korahites, were in charge of the work of the service, gatekeepers of the tabernacle. Their fathers had been keepers of the entrance to the camp of the LORD.

20. And Phinehas the son of Eleazar had been the officer over them in time past; the LORD was with him.

21. Zechariah the son of Meshelemiah was keeper of the door of the tabernacle of meeting.

22. All those chosen as gatekeepers were two hundred and twelve. They were recorded by their genealogy, in their villages. David and Samuel the seer had appointed them to their trusted office.

23. So they and their children were in charge of the gates of the house of the LORD, the house of the tabernacle, by assignment.

24. The gatekeepers were assigned to the four directions: the east, west, north, and south.

25. And their brethren in their villages had to come with them from time to time for seven days.

26. For in this trusted office were four chief gatekeepers; they were Levites. And they had charge over the chambers and treasuries of the house of God.

27. And they lodged all around the house of God because they had the responsibility, and they were in charge of opening it every morning.

28. Now some of them were in charge of the serving vessels, for they brought them in and took them out by count.

29. Some of them were appointed over the furnishings and over all the implements of the sanctuary, and over the fine flour and the wine and the oil and the incense and the spices.

30. And some of the sons of the priests made the ointment of the spices.

31. Mattithiah of the Levites, the firstborn of Shallum the Korahite, had the trusted office over the things that were baked in the pans.

32. And some of their brethren of the sons of the Kohathites were in charge of preparing the showbread for every Sabbath.

33. These are the singers, heads of the fathers' houses of the Levites, who lodged in the chambers, and were free from other duties; for they were employed in that work day and night.

34. These heads of the fathers' houses of the Levites were heads throughout their generations. They dwelt at Jerusalem.

35. Jeiel the father of Gibeon, whose wife's name was Maacah, dwelt at Gibeon.

36. His firstborn son was Abdon, then Zur, Kish, Baal, Ner, Nadab,

37. Gedor, Ahio, Zechariah, and Mikloth.

38. And Mikloth begot Shimeam. They also dwelt alongside their relatives in Jerusalem, with their brethren.

39. Ner begot Kish, Kish begot Saul, and Saul begot Jonathan, Malchishua, Abinadab, and Esh-Baal.

40. The son of Jonathan was Merib-Baal, and Merib-Baal begot Micah.

41. The sons of Micah were Pithon, Melech, Tahrea, and Ahaz.

42. And Ahaz begot Jarah; Jarah begot Alemeth, Azmaveth, and Zimri; and Zimri begot Moza;

43. Moza begot Binea, Rephaiah his son, Eleasah his son, and Azel his son.

44. And Azel had six sons whose names were these: Azrikam, Bocheru, Ishmael, Sheariah, Obadiah, and Hanan; these were the sons of Azel.

## Chapter 10

1. Now the Philistines fought against Israel; and the men of Israel fled from before the Philistines, and fell slain on Mount Gilboa.

2. Then the Philistines followed hard after Saul and his sons. And the Philistines killed Jonathan, Abinadab, and Malchishua, Saul's sons.

3. The battle became fierce against Saul. The archers hit him, and he was wounded by the archers.

4. Then Saul said to his armorbearer, "Draw your sword, and thrust me through with it, lest these uncircumcised men come and abuse me." But his armorbearer would not, for he was greatly afraid. Therefore Saul took a sword and fell on it.

5. And when his armorbearer saw that Saul was dead, he also fell on his sword and died.

6. So Saul and his three sons died, and all his house died together.

7. And when all the men of Israel who were in the valley saw that they had fled and that Saul and his sons were dead, they forsook their cities and fled; then the Philistines came and dwelt in them.

8. So it happened the next day, when the Philistines came to strip the slain, that they found Saul and his sons fallen on Mount Gilboa.

9. And they stripped him and took his head and his armor, and sent word throughout the land of the Philistines to proclaim the news in the temple of their idols and among the people.

10. Then they put his armor in the temple of their gods, and fastened his head in the temple of Dagon.

11. And when all Jabesh Gilead heard all that the Philistines had done to Saul,

12. all the valiant men arose and took the body of Saul and the bodies of his sons; and they brought them to Jabesh, and buried their bones under the tamarisk tree at Jabesh, and fasted seven days.

13. So Saul died for his unfaithfulness which he had committed against the LORD, because he did not keep the word of the LORD, and also because he consulted a medium for guidance.

14. But he did not inquire of the LORD; therefore He killed him, and turned the kingdom over to David the son of Jesse.

## Chapter 11

1. Then all Israel came together to David at Hebron, saying, "Indeed we are your bone and your flesh.

2. Also, in time past, even when Saul was king, you were the one who led Israel out and brought them in; and the LORD your God said to you, "You shall shepherd My people Israel, and be ruler over My people Israel."'

3. Therefore all the elders of Israel came to the king at Hebron, and David made a covenant with them at Hebron before the LORD. And they anointed David king over Israel, according to the word of the LORD by Samuel.

4. And David and all Israel went to Jerusalem, which is Jebus, where the Jebusites were, the inhabitants of the land.

5. But the inhabitants of Jebus said to David, "You shall not come in here!" Nevertheless David took the stronghold of Zion (that is, the City of David).

6. Now David said, "Whoever attacks the Jebusites first shall be chief and captain." And Joab the son of Zeruiah went up first, and became chief.

7. Then David dwelt in the stronghold; therefore they called it the City of David.

8. And he built the city around it, from the Millo to the surrounding area. Joab repaired the rest of the city.

9. So David went on and became great, and the LORD of hosts was with him.

10. Now these were the heads of the mighty men whom David had, who strengthened themselves with him in his kingdom, with all Israel, to make him king, according to the word of the LORD concerning Israel.

11. And this is the number of the mighty men whom David had: Jashobeam the son of a Hachmonite, chief of the captains; he had lifted up his spear against three hundred, killed by him at one time.

12. After him was Eleazar the son of Dodo, the Ahohite, who was one of the three mighty men.

13. He was with David at Pasdammim. Now there the Philistines were gathered for battle, and there was a piece of ground full of barley. So the people fled from the Philistines.

14. But they stationed themselves in the middle of that field, defended it, and killed the Philistines. So the LORD brought about a great victory.

15. Now three of the thirty chief men went down to the rock to David, into the cave of Adullam; and the army of the Philistines encamped in the Valley of Rephaim.

16. David was then in the stronghold, and the garrison of the Philistines was then in Bethlehem.

17. And David said with longing, "Oh, that someone would give me a drink of water from the well of Bethlehem, which is by the gate!"

18. So the three broke through the camp of the Philistines, drew water from the well of Bethlehem that was by the gate, and took it and brought it to David. Nevertheless David would not drink it, but poured it out to the LORD.

19. And he said, "Far be it from me, O my God, that I should do this! Shall I drink the blood of these men who have put their lives in jeopardy? For at the risk of their lives they brought it." Therefore he would not drink it. These things were done by the three mighty men.

20. Abishai the brother of Joab was chief of another three. He had lifted up his spear against three hundred men, killed them, and won a name among these three.

21. Of the three he was more honored than the other two men. Therefore he became their captain. However he did not attain to the first three.

22. Benaiah was the son of Jehoiada, the son of a valiant man from Kabzeel, who had done many deeds. He had killed two lion-like heroes of Moab. He also had gone down and killed a lion in the midst of a pit on a snowy day.

23. And he killed an Egyptian, a man of great height, five cubits tall. In the Egyptian's hand there was a spear like a weaver's beam; and he went down to him with a staff, wrested the spear out of the Egyptian's hand, and killed him with his own spear.

24. These things Benaiah the son of Jehoiada did, and won a name among three mighty men.

25. Indeed he was more honored than the thirty, but he did not attain to the first three. And David appointed him over his guard.

26. Also the mighty warriors were Asahel the brother of Joab, Elhanan the son of Dodo of Bethlehem,

27. Shammoth the Harorite, Helez the Pelonite,

28. Ira the son of Ikkesh the Tekoite, Abiezer the Anathothite,

29. Sibbechai the Hushathite, Ilai the Ahohite,

30. Maharai the Netophathite, Heled the son of Baanah the Netophathite,

31. Ithai the son of Ribai of Gibeah, of the sons of Benjamin, Benaiah the Pirathonite,

32. Hurai of the brooks of Gaash, Abiel the Arbathite,

33. Azmaveth the Baharumite, Eliahba the Shaalbonite,

34. the sons of Hashem the Gizonite, Jonathan the son of Shageh the Hararite,

35. Ahiam the son of Sacar the Hararite, Eliphal the son of Ur,

36. Hepher the Mecherathite, Ahijah the Pelonite,

37. Hezro the Carmelite, Naarai the son of Ezbai,

38. Joel the brother of Nathan, Mibhar the son of Hagri,

39. Zelek the Ammonite, Naharai the Berothite (the armorbearer of Joab the son of Zeruiah),

40. Ira the Ithrite, Gareb the Ithrite,

41. Uriah the Hittite, Zabad the son of Ahlai,

42. Adina the son of Shiza the Reubenite (a chief of the Reubenites) and thirty with him,

43. Hanan the son of Maachah, Joshaphat the Mithnite,

44. Uzzia the Ashterathite, Shama and Jeiel the sons of Hotham the Aroerite,

45. Jediael the son of Shimri, and Joha his brother, the Tizite,

46. Eliel the Mahavite, Jeribai and Joshaviah the sons of Elnaam, Ithmah the Moabite,

47. Eliel, Obed, and Jaasiel the Mezobaite.

## Chapter 12

1. Now these were the men who came to David at Ziklag while he was still a fugitive from Saul the son of Kish; and they were among the mighty men, helpers in the war,

2. armed with bows, using both the right hand and the left in hurling stones and shooting arrows with the bow. They were of Benjamin, Saul's brethren.

3. The chief was Ahiezer, then Joash, the sons of Shemaah the Gibeathite; Jeziel and Pelet the sons of Azmaveth; Berachah, and Jehu the Anathothite;

4. Ishmaiah the Gibeonite, a mighty man among the thirty, and over the thirty; Jeremiah, Jahaziel, Johanan, and Jozabad the Gederathite;

5. Eluzai, Jerimoth, Bealiah, Shemariah, and Shephatiah the Haruphite;

6. Elkanah, Jisshiah, Azarel, Joezer, and Jashobeam, the Korahites;

7. and Joelah and Zebadiah the sons of Jeroham of Gedor.

8. Some Gadites joined David at the stronghold in the wilderness, mighty men of valor, men trained for battle, who could handle shield and spear, whose faces were like the faces of lions, and were as swift as gazelles on the mountains:

9. Ezer the first, Obadiah the second, Eliab the third,

10. Mishmannah the fourth, Jeremiah the fifth,

11. Attai the sixth, Eliel the seventh,

12. Johanan the eighth, Elzabad the ninth,

13. Jeremiah the tenth, and Machbanai the eleventh.

14. These were from the sons of Gad, captains of the army; the least was over a hundred, and the greatest was over a thousand.

15. These are the ones who crossed the Jordan in the first month, when it had overflowed all its banks; and they put to flight all those in the valleys, to the east and to the west.

16. Then some of the sons of Benjamin and Judah came to David at the stronghold.

17. And David went out to meet them, and answered and said to them, "If you have come peaceably to me to help me, my heart will be united with you; but if to betray me to my enemies, since there is no wrong in my hands, may the God of our fathers look and bring judgment."

18. Then the Spirit came upon Amasai, chief of the captains, and he said: "We are yours, O David; We are on your side, O son of Jesse! Peace, peace to you, And peace to your helpers! For your God helps you." So David received them, and made them captains of the troop.

19. And some from Manasseh defected to David when he was going with the Philistines to battle against Saul; but they did not help them, for the lords of the Philistines sent him away by agreement, saying, "He may defect to his master Saul and endanger our heads."

20. When he went to Ziklag, those of Manasseh who defected to him were Adnah, Jozabad, Jediael, Michael, Jozabad, Elihu, and Zillethai, captains of the thousands who were from Manasseh.

21. And they helped David against the bands of raiders, for they were all mighty men of valor, and they were captains in the army.

22. For at that time they came to David day by day to help him, until it was a great army, like the army of God.

23. Now these were the numbers of the divisions that were equipped for war, and came to David at Hebron to turn over the kingdom of Saul to him, according to the word of the LORD:

24. of the sons of Judah bearing shield and spear, six thousand eight hundred armed for war;

25. of the sons of Simeon, mighty men of valor fit for war, seven thousand one hundred;

26. of the sons of Levi four thousand six hundred;

27. Jehoiada, the leader of the Aaronites, and with him three thousand seven hundred;

28. Zadok, a young man, a valiant warrior, and from his father's house twenty-two captains;

29. of the sons of Benjamin, relatives of Saul, three thousand (until then the greatest part of them had remained loyal to the house of Saul);

30. of the sons of Ephraim twenty thousand eight hundred, mighty men of valor, famous men throughout their father's house;

31. of the half-tribe of Manasseh eighteen thousand, who were designated by name to come and make David king;

32. of the sons of Issachar who had understanding of the times, to know what Israel ought to do, their chiefs were two hundred; and all their brethren were at their command;

33. of Zebulun there were fifty thousand who went out to battle, expert in war with all weapons of war, stouthearted men who could keep ranks;

34. of Naphtali one thousand captains, and with them thirty-seven thousand with shield and spear;

35. of the Danites who could keep battle formation, twenty-eight thousand six hundred;

36. of Asher, those who could go out to war, able to keep battle formation, forty thousand;

37. of the Reubenites and the Gadites and the half-tribe of Manasseh, from the other side of the Jordan, one hundred and twenty thousand armed for battle with every kind of weapon of war.

38. All these men of war, who could keep ranks, came to Hebron with a loyal heart, to make David king over all Israel; and all the rest of Israel were of one mind to make David king.

39. And they were there with David three days, eating and drinking, for their brethren had prepared for them.

40. Moreover those who were near to them, from as far away as Issachar and Zebulun and Naphtali, were bringing food on donkeys and camels, on mules and oxen--provisions of flour and cakes of figs and cakes of raisins, wine and oil and oxen and sheep abundantly, for there was joy in Israel.

## Chapter 13

1. Then David consulted with the captains of thousands and hundreds, and with every leader.

2. And David said to all the assembly of Israel, "If it seems good to you, and if it is of the LORD our God, let us send out to our brethren everywhere who are left in all the land of Israel, and with them to the priests and Levites who are in their cities and their common-lands, that they may gather together to us;

3. and let us bring the ark of our God back to us, for we have not inquired at it since the days of Saul."

4. Then all the assembly said that they would do so, for the thing was right in the eyes of all the people.

5. So David gathered all Israel together, from Shihor in Egypt to as far as the entrance of Hamath, to bring the ark of God from Kirjath Jearim.

6. And David and all Israel went up to Baalah, to Kirjath Jearim, which belonged to Judah, to bring up from there the ark of God the LORD, who dwells between the cherubim, where His name is proclaimed.

7. So they carried the ark of God on a new cart from the house of Abinadab, and Uzza and Ahio drove the cart.

8. Then David and all Israel played music before God with all their might, with singing, on harps, on stringed instruments, on tambourines, on cymbals, and with trumpets.

9. And when they came to Chidon's threshing floor, Uzza put out his hand to hold the ark, for the oxen stumbled.

10. Then the anger of the LORD was aroused against Uzza, and He struck him because he put his hand to the ark; and he died there before God.

11. And David became angry because of the LORD's outbreak against Uzza; therefore that place is called Perez Uzza to this day.

12. David was afraid of God that day, saying, "How can I bring the ark of God to me?"

13. So David would not move the ark with him into the City of David, but took it aside into the house of Obed-Edom the Gittite.

14. The ark of God remained with the family of Obed-Edom in his house three months. And the LORD blessed the house of Obed-Edom and all that he had.

## Chapter 14

1. Now Hiram king of Tyre sent messengers to David, and cedar trees, with masons and carpenters, to build him a house.

2. So David knew that the LORD had established him as king over Israel, for his kingdom was highly exalted for the sake of His people Israel.

3. Then David took more wives in Jerusalem, and David begot more sons and daughters.

4. And these are the names of his children whom he had in Jerusalem: Shammua, Shobab, Nathan, Solomon,

5. Ibhar, Elishua, Elpelet,

6. Nogah, Nepheg, Japhia,

7. Elishama, Beeliada, and Eliphelet.

8. Now when the Philistines heard that David had been anointed king over all Israel, all the Philistines went up to search for David. And David heard of it and went out against them.

9. Then the Philistines went and made a raid on the Valley of Rephaim.

10. And David inquired of God, saying, "Shall I go up against the Philistines? Will You deliver them into my hand?" The LORD said to him, "Go up, for I will deliver them into your hand."

11. So they went up to Baal Perazim, and David defeated them there. Then David said, "God has broken through my enemies by my hand like a breakthrough of water." Therefore they called the name of that place Baal Perazim.

12. And when they left their gods there, David gave a commandment, and they were burned with fire.

13. Then the Philistines once again made a raid on the valley.

14. Therefore David inquired again of God, and God said to him, "You shall not go up after them; circle around them, and come upon them in front of the mulberry trees.

15. And it shall be, when you hear a sound of marching in the tops of the mulberry trees, then you shall go out to battle, for God has gone out before you to strike the camp of the Philistines."

16. So David did as God commanded him, and they drove back the army of the Philistines from Gibeon as far as Gezer.

17. Then the fame of David went out into all lands, and the LORD brought the fear of him upon all nations.

## Chapter 15

1. David built houses for himself in the City of David; and he prepared a place for the ark of God, and pitched a tent for it.

2. Then David said, "No one may carry the ark of God but the Levites, for the LORD has chosen them to carry the ark of God and to minister before Him forever."

3. And David gathered all Israel together at Jerusalem, to bring up the ark of the LORD to its place, which he had prepared for it.

4. Then David assembled the children of Aaron and the Levites:

5. of the sons of Kohath, Uriel the chief, and one hundred and twenty of his brethren;

6. of the sons of Merari, Asaiah the chief, and two hundred and twenty of his brethren;

7. of the sons of Gershom, Joel the chief, and one hundred and thirty of his brethren;

8. of the sons of Elizaphan, Shemaiah the chief, and two hundred of his brethren;

9. of the sons of Hebron, Eliel the chief, and eighty of his brethren;

10. of the sons of Uzziel, Amminadab the chief, and one hundred and twelve of his brethren.

11. And David called for Zadok and Abiathar the priests, and for the Levites: for Uriel, Asaiah, Joel, Shemaiah, Eliel, and Amminadab.

12. He said to them, "You are the heads of the fathers' houses of the Levites; sanctify yourselves, you and your brethren, that you may bring up the ark of the LORD God of Israel to the place I have prepared for it.

13. For because you did not do it the first time, the LORD our God broke out against us, because we did not consult Him about the proper order."

14. So the priests and the Levites sanctified themselves to bring up the ark of the LORD God of Israel.

15. And the children of the Levites bore the ark of God on their shoulders, by its poles, as Moses had commanded according to the word of the LORD.

16. Then David spoke to the leaders of the Levites to appoint their brethren to be the singers accompanied by instruments of music, stringed instruments, harps, and cymbals, by raising the voice with resounding joy.

17. So the Levites appointed Heman the son of Joel; and of his brethren, Asaph the son of Berechiah; and of their brethren, the sons of Merari, Ethan the son of Kushaiah;

18. and with them their brethren of the second rank: Zechariah, Ben, Jaaziel, Shemiramoth, Jehiel, Unni, Eliab, Benaiah, Maaseiah, Mattithiah, Elipheleh, Mikneiah, Obed-Edom, and Jeiel, the gatekeepers;

19. the singers, Heman, Asaph, and Ethan, were to sound the cymbals of bronze;

20. Zechariah, Aziel, Shemiramoth, Jehiel, Unni, Eliab, Maaseiah, and Benaiah, with strings according to Alamoth;

21. Mattithiah, Elipheleh, Mikneiah, Obed-Edom, Jeiel, and Azaziah, to direct with harps on the Sheminith;

22. Chenaniah, leader of the Levites, was instructor in charge of the music, because he was skillful;

23. Berechiah and Elkanah were doorkeepers for the ark;

24. Shebaniah, Joshaphat, Nethanel, Amasai, Zechariah, Benaiah, and Eliezer, the priests, were to blow the trumpets before the ark of God; and Obed-Edom and Jehiah, doorkeepers for the ark.

25. So David, the elders of Israel, and the captains over thousands went to bring up the ark of the covenant of the LORD from the house of Obed-Edom with joy.

26. And so it was, when God helped the Levites who bore the ark of the covenant of the LORD, that they offered seven bulls and seven rams.

27. David was clothed with a robe of fine linen, as were all the Levites who bore the ark, the singers, and Chenaniah the music master with the singers. David also wore a linen ephod.

28. Thus all Israel brought up the ark of the covenant of the LORD with shouting and with the sound of the horn, with trumpets and with cymbals, making music with stringed instruments and harps.

29. And it happened, as the ark of the covenant of the LORD came to the City of David, that Michal, Saul's daughter, looked through a window and saw King David whirling and playing music; and she despised him in her heart.

## Chapter 16

1. So they brought the ark of God, and set it in the midst of the tabernacle that David had erected for it. Then they offered burnt offerings and peace offerings before God.

2. And when David had finished offering the burnt offerings and the peace offerings, he blessed the people in the name of the LORD.

3. Then he distributed to everyone of Israel, both man and woman, to everyone a loaf of bread, a piece of meat, and a cake of raisins.

4. And he appointed some of the Levites to minister before the ark of the LORD, to commemorate, to thank, and to praise the LORD God of Israel:

5. Asaph the chief, and next to him Zechariah, then Jeiel, Shemiramoth, Jehiel, Mattithiah, Eliab, Benaiah, and Obed-Edom: Jeiel with stringed instruments and harps, but Asaph made music with cymbals;

6. Benaiah and Jahaziel the priests regularly blew the trumpets before the ark of the covenant of God.

7. On that day David first delivered this psalm into the hand of Asaph and his brethren, to thank the LORD:

8. Oh, give thanks to the LORD! Call upon His name; Make known His deeds among the peoples!

9. Sing to Him, sing psalms to Him; Talk of all His wondrous works!

10. Glory in His holy name; Let the hearts of those rejoice who seek the LORD!

11. Seek the LORD and His strength; Seek His face evermore!

12. Remember His marvelous works which He has done, His wonders, and the judgments of His mouth,

13. O seed of Israel His servant, You children of Jacob, His chosen ones!

14. He is the LORD our God; His judgments are in all the earth.

15. Remember His covenant forever, The word which He commanded, for a thousand generations,

16. The covenant which He made with Abraham, And His oath to Isaac,

17. And confirmed it to Jacob for a statute, To Israel for an everlasting covenant,

18. Saying, "To you I will give the land of Canaan As the allotment of your inheritance,"

19. When you were few in number, Indeed very few, and strangers in it.

20. When they went from one nation to another, And from one kingdom to another people,

21. He permitted no man to do them wrong; Yes, He rebuked kings for their sakes,

22. Saying, "Do not touch My anointed ones, And do My prophets no harm."

23. Sing to the LORD, all the earth; Proclaim the good news of His salvation from day to day.

24. Declare His glory among the nations, His wonders among all peoples.

25. For the LORD is great and greatly to be praised; He is also to be feared above all gods.

26. For all the gods of the peoples are idols, But the LORD made the heavens.

27. Honor and majesty are before Him; Strength and gladness are in His place.

28. Give to the LORD, O families of the peoples, Give to the LORD glory and strength.

29. Give to the LORD the glory due His name; Bring an offering, and come before Him. Oh, worship the LORD in the beauty of holiness!

30. Tremble before Him, all the earth. The world also is firmly established, It shall not be moved.

31. Let the heavens rejoice, and let the earth be glad; And let them say among the nations, "The LORD reigns."

32. Let the sea roar, and all its fullness; Let the field rejoice, and all that is in it.

33. Then the trees of the woods shall rejoice before the LORD, For He is coming to judge the earth.

34. Oh, give thanks to the LORD, for He is good! For His mercy endures forever.

35. And say, "Save us, O God of our salvation; Gather us together, and deliver us from the Gentiles, To give thanks to Your holy name, To triumph in Your praise."

36. Blessed be the LORD God of Israel From everlasting to everlasting! And all the people said, "Amen!" and praised the LORD.

37. So he left Asaph and his brothers there before the ark of the covenant of the LORD to minister before the ark regularly, as every day's work required;

38. and Obed-Edom with his sixty-eight brethren, including Obed-Edom the son of Jeduthun, and Hosah, to be gatekeepers;

39. and Zadok the priest and his brethren the priests, before the tabernacle of the LORD at the high place that was at Gibeon,

40. to offer burnt offerings to the LORD on the altar of burnt offering regularly morning and evening, and to do according to all that is written in the Law of the LORD which He commanded Israel;

41. and with them Heman and Jeduthun and the rest who were chosen, who were designated by name, to give thanks to the LORD, because His mercy endures forever;

42. and with them Heman and Jeduthun, to sound aloud with trumpets and cymbals and the musical instruments of God. Now the sons of Jeduthun were gatekeepers.

43. Then all the people departed, every man to his house; and David returned to bless his house.

## Chapter 17

1. Now it came to pass, when David was dwelling in his house, that David said to Nathan the prophet, "See now, I dwell in a house of cedar, but the ark of the covenant of the LORD is under tent curtains."

2. Then Nathan said to David, "Do all that is in your heart, for God is with you."

3. But it happened that night that the word of God came to Nathan, saying,

4. "Go and tell My servant David, "Thus says the LORD: "You shall not build Me a house to dwell in.

5. For I have not dwelt in a house since the time that I brought up Israel, even to this day, but have gone from tent to tent, and from one tabernacle to another.

6. Wherever I have moved about with all Israel, have I ever spoken a word to any of the judges of Israel, whom I commanded to shepherd My people, saying, "Why have you not built Me a house of cedar?""

7. Now therefore, thus shall you say to My servant David, "Thus says the LORD of hosts: "I took you from the sheepfold, from following the sheep, to be ruler over My people Israel.

8. And I have been with you wherever you have gone, and have cut off all your enemies from before you, and have made you a name like the name of the great men who are on the earth.

9. Moreover I will appoint a place for My people Israel, and will plant them, that they may dwell in a place of their own and move no more; nor shall the sons of wickedness oppress them anymore, as previously,

10. since the time that I commanded judges to be over My people Israel. Also I will subdue all your enemies. Furthermore I tell you that the LORD will build you a house.

11. And it shall be, when your days are fulfilled, when you must go to be with your fathers, that I will set up your seed after you, who will be of your sons; and I will establish his kingdom.

12. He shall build Me a house, and I will establish his throne forever.

13. I will be his Father, and he shall be My son; and I will not take My mercy away from him, as I took it from him who was before you.

14. And I will establish him in My house and in My kingdom forever; and his throne shall be established forever.""'

15. According to all these words and according to all this vision, so Nathan spoke to David.

16. Then King David went in and sat before the LORD; and he said: "Who am I, O LORD God? And what is my house, that You have brought me this far?

17. And yet this was a small thing in Your sight, O God; and You have also spoken of Your servant's house for a great while to come, and have regarded me according to the rank of a man of high degree, O LORD God.

18. What more can David say to You for the honor of Your servant? For You know Your servant.

19. O LORD, for Your servant's sake, and according to Your own heart, You have done all this greatness, in making known all these great things.

20. O LORD, there is none like You, nor is there any God besides You, according to all that we have heard with our ears.

21. And who is like Your people Israel, the one nation on the earth whom God went to redeem for Himself as a people--to make for Yourself a name by great and awesome deeds, by driving out nations from before Your people whom You redeemed from Egypt?

22. For You have made Your people Israel Your very own people forever; and You, LORD, have become their God.

23. "And now, O LORD, the word which You have spoken concerning Your servant and concerning his house, let it be established forever, and do as You have said.

24. So let it be established, that Your name may be magnified forever, saying, "The LORD of hosts, the God of Israel, is Israel's God.' And let the house of Your servant David be established before You.

25. For You, O my God, have revealed to Your servant that You will build him a house. Therefore Your servant has found it in his heart to pray before You.

26. And now, LORD, You are God, and have promised this goodness to Your servant.

27. Now You have been pleased to bless the house of Your servant, that it may continue before You forever; for You have blessed it, O LORD, and it shall be blessed forever."

## Chapter 18

1. After this it came to pass that David attacked the Philistines, subdued them, and took Gath and its towns from the hand of the Philistines.

2. Then he defeated Moab, and the Moabites became David's servants, and brought tribute.

3. And David defeated Hadadezer king of Zobah as far as Hamath, as he went to establish his power by the River Euphrates.

4. David took from him one thousand chariots, seven thousand horsemen, and twenty thousand foot soldiers. Also David hamstrung all the chariot horses, except that he spared enough of them for one hundred chariots.

5. When the Syrians of Damascus came to help Hadadezer king of Zobah, David killed twenty-two thousand of the Syrians.

6. Then David put garrisons in Syria of Damascus; and the Syrians became David's servants, and brought tribute. So the LORD preserved David wherever he went.

7. And David took the shields of gold that were on the servants of Hadadezer, and brought them to Jerusalem.

8. Also from Tibhath and from Chun, cities of Hadadezer, David brought a large amount of bronze, with which Solomon made the bronze Sea, the pillars, and the articles of bronze.

9. Now when Tou king of Hamath heard that David had defeated all the army of Hadadezer king of Zobah,

10. he sent Hadoram his son to King David, to greet him and bless him, because he had fought against Hadadezer and defeated him (for Hadadezer had been at war with Tou); and Hadoram brought with him all kinds of articles of gold, silver, and bronze.

11. King David also dedicated these to the LORD, along with the silver and gold that he had brought from all these nations--from Edom, from Moab, from the people of Ammon, from the Philistines, and from Amalek.

12. Moreover Abishai the son of Zeruiah killed eighteen thousand Edomites in the Valley of Salt.

13. He also put garrisons in Edom, and all the Edomites became David's servants. And the LORD preserved David wherever he went.

14. So David reigned over all Israel, and administered judgment and justice to all his people.

15. Joab the son of Zeruiah was over the army; Jehoshaphat the son of Ahilud was recorder;

16. Zadok the son of Ahitub and Abimelech the son of Abiathar were the priests; Shavsha was the scribe;

17. Benaiah the son of Jehoiada was over the Cherethites and the Pelethites; and David's sons were chief ministers at the king's side.

## Chapter 19

1. It happened after this that Nahash the king of the people of Ammon died, and his son reigned in his place.

2. Then David said, "I will show kindness to Hanun the son of Nahash, because his father showed kindness to me." So David sent messengers to comfort him concerning his father. And David's servants came to Hanun in the land of the people of Ammon to comfort him.

3. And the princes of the people of Ammon said to Hanun, "Do you think that David really honors your father because he has sent comforters to you? Did his servants not come to you to search and to overthrow and to spy out the land?"

4. Therefore Hanun took David's servants, shaved them, and cut off their garments in the middle, at their buttocks, and sent them away.

5. Then some went and told David about the men; and he sent to meet them, because the men were greatly ashamed. And the king said, "Wait at Jericho until your beards have grown, and then return."

6. When the people of Ammon saw that they had made themselves repulsive to David, Hanun and the people of Ammon sent a thousand talents of silver to hire for themselves chariots and horsemen from Mesopotamia, from Syrian Maacah, and from Zobah.

7. So they hired for themselves thirty-two thousand chariots, with the king of Maacah and his people, who came and encamped before Medeba. Also the people of Ammon gathered together from their cities, and came to battle.

8. Now when David heard of it, he sent Joab and all the army of the mighty men.

9. Then the people of Ammon came out and put themselves in battle array before the gate of the city, and the kings who had come were by themselves in the field.

10. When Joab saw that the battle line was against him before and behind, he chose some of Israel's best, and put them in battle array against the Syrians.

11. And the rest of the people he put under the command of Abishai his brother, and they set themselves in battle array against the people of Ammon.

12. Then he said, "If the Syrians are too strong for me, then you shall help me; but if the people of Ammon are too strong for you, then I will help you.

13. Be of good courage, and let us be strong for our people and for the cities of our God. And may the LORD do what is good in His sight."

14. So Joab and the people who were with him drew near for the battle against the Syrians, and they fled before him.

15. When the people of Ammon saw that the Syrians were fleeing, they also fled before Abishai his brother, and entered the city. So Joab went to Jerusalem.

16. Now when the Syrians saw that they had been defeated by Israel, they sent messengers and brought the Syrians who were beyond the River, and Shophach the commander of Hadadezer's army went before them.

17. When it was told David, he gathered all Israel, crossed over the Jordan and came upon them, and set up in battle array against them. So when David had set up in battle array against the Syrians, they fought with him.

18. Then the Syrians fled before Israel; and David killed seven thousand charioteers and forty thousand foot soldiers of the Syrians, and killed Shophach the commander of the army.

19. And when the servants of Hadadezer saw that they were defeated by Israel, they made peace with David and became his servants. So the Syrians were not willing to help the people of Ammon anymore.

## Chapter 20

1. It happened in the spring of the year, at the time kings go out to battle, that Joab led out the armed forces and ravaged the country of the people of Ammon, and came and besieged Rabbah. But David stayed at Jerusalem. And Joab defeated Rabbah and overthrew it.

2. Then David took their king's crown from his head, and found it to weigh a talent of gold, and there were precious stones in it. And it was set on David's head. Also he brought out the spoil of the city in great abundance.

3. And he brought out the people who were in it, and put them to work with saws, with iron picks, and with axes. So David did to all the cities of the people of Ammon. Then David and all the people returned to Jerusalem.

4. Now it happened afterward that war broke out at Gezer with the Philistines, at which time Sibbechai the Hushathite killed Sippai, who was one of the sons of the giant. And they were subdued.

5. Again there was war with the Philistines, and Elhanan the son of Jair killed Lahmi the brother of Goliath the Gittite, the shaft of whose spear was like a weaver's beam.

6. Yet again there was war at Gath, where there was a man of great stature, with twenty-four fingers and toes, six on each hand and six on each foot; and he also was born to the giant.

7. So when he defied Israel, Jonathan the son of Shimea, David's brother, killed him.

8. These were born to the giant in Gath, and they fell by the hand of David and by the hand of his servants.

## Chapter 21

1. Now Satan stood up against Israel, and moved David to number Israel.

2. So David said to Joab and to the leaders of the people, "Go, number Israel from Beersheba to Dan, and bring the number of them to me that I may know it."

3. And Joab answered, "May the LORD make His people a hundred times more than they are. But, my lord the king, are they not all my lord's servants? Why then does my lord require this thing? Why should he be a cause of guilt in Israel?"

4. Nevertheless the king's word prevailed against Joab. Therefore Joab departed and went throughout all Israel and came to Jerusalem.

5. Then Joab gave the sum of the number of the people to David. All Israel had one million one hundred thousand men who drew the sword, and Judah had four hundred and seventy thousand men who drew the sword.

6. But he did not count Levi and Benjamin among them, for the king's word was abominable to Joab.

7. And God was displeased with this thing; therefore He struck Israel.

8. So David said to God, "I have sinned greatly, because I have done this thing; but now, I pray, take away the iniquity of Your servant, for I have done very foolishly."

9. Then the LORD spoke to Gad, David's seer, saying,

10. "Go and tell David, saying, "Thus says the LORD: "I offer you three things; choose one of them for yourself, that I may do it to you.""'

11. So Gad came to David and said to him, "Thus says the LORD: "Choose for yourself,

12. either three years of famine, or three months to be defeated by your foes with the sword of your enemies overtaking you, or else for three days the sword of the LORD--the plague in the land, with the angel of the LORD destroying throughout all the territory of Israel.' Now consider what answer I should take back to Him who sent me."

13. And David said to Gad, "I am in great distress. Please let me fall into the hand of the LORD, for His mercies are very great; but do not let me fall into the hand of man."

14. So the LORD sent a plague upon Israel, and seventy thousand men of Israel fell.

15. And God sent an angel to Jerusalem to destroy it. As he was destroying, the LORD looked and relented of the disaster, and said to the angel who was destroying, "It is enough; now restrain your hand." And the angel of the LORD stood by the threshing floor of Ornan the Jebusite.

16. Then David lifted his eyes and saw the angel of the LORD standing between earth and heaven, having in his hand a drawn sword stretched out over Jerusalem. So David and the elders, clothed in sackcloth, fell on their faces.

17. And David said to God, "Was it not I who commanded the people to be numbered? I am the one who has sinned and done evil indeed; but these sheep, what have they done? Let Your hand, I pray, O LORD my God, be against me and my father's house, but not against Your people that they should be plagued."

18. Therefore, the angel of the LORD commanded Gad to say to David that David should go and erect an altar to the LORD on the threshing floor of Ornan the Jebusite.

19. So David went up at the word of Gad, which he had spoken in the name of the LORD.

20. Now Ornan turned and saw the angel; and his four sons who were with him hid themselves, but Ornan continued threshing wheat.

21. So David came to Ornan, and Ornan looked and saw David. And he went out from the threshing floor, and bowed before David with his face to the ground.

22. Then David said to Ornan, "Grant me the place of this threshing floor, that I may build an altar on it to the LORD. You shall grant it to me at the full price, that the plague may be withdrawn from the people."

23. But Ornan said to David, "Take it to yourself, and let my lord the king do what is good in his eyes. Look, I also give you the oxen for burnt offerings, the threshing implements for wood, and the wheat for the grain offering; I give it all."

24. Then King David said to Ornan, "No, but I will surely buy it for the full price, for I will not take what is yours for the LORD, nor offer burnt offerings with that which costs me nothing."

25. So David gave Ornan six hundred shekels of gold by weight for the place.

26. And David built there an altar to the LORD, and offered burnt offerings and peace offerings, and called on the LORD; and He answered him from heaven by fire on the altar of burnt offering.

27. So the LORD commanded the angel, and he returned his sword to its sheath.

28. At that time, when David saw that the LORD had answered him on the threshing floor of Ornan the Jebusite, he sacrificed there.

29. For the tabernacle of the LORD and the altar of the burnt offering, which Moses had made in the wilderness, were at that time at the high place in Gibeon.

30. But David could not go before it to inquire of God, for he was afraid of the sword of the angel of the LORD.

## Chapter 22

1. Then David said, "This is the house of the LORD God, and this is the altar of burnt offering for Israel."

2. So David commanded to gather the aliens who were in the land of Israel; and he appointed masons to cut hewn stones to build the house of God.

3. And David prepared iron in abundance for the nails of the doors of the gates and for the joints, and bronze in abundance beyond measure,

4. and cedar trees in abundance; for the Sidonians and those from Tyre brought much cedar wood to David.

5. Now David said, "Solomon my son is young and inexperienced, and the house to be built for the LORD must be exceedingly magnificent, famous and glorious throughout all countries. I will now make preparation for it." So David made abundant preparations before his death.

6. Then he called for his son Solomon, and charged him to build a house for the LORD God of Israel.

7. And David said to Solomon: "My son, as for me, it was in my mind to build a house to the name of the LORD my God;

8. but the word of the LORD came to me, saying, "You have shed much blood and have made great wars; you shall not build a house for My name, because you have shed much blood on the earth in My sight.

9. Behold, a son shall be born to you, who shall be a man of rest; and I will give him rest from all his enemies all around. His name shall be Solomon, for I will give peace and quietness to Israel in his days.

10. He shall build a house for My name, and he shall be My son, and I will be his Father; and I will establish the throne of his kingdom over Israel forever.'

11. Now, my son, may the LORD be with you; and may you prosper, and build the house of the LORD your God, as He has said to you.

12. Only may the LORD give you wisdom and understanding, and give you charge concerning Israel, that you may keep the law of the LORD your God.

13. Then you will prosper, if you take care to fulfill the statutes and judgments with which the LORD charged Moses concerning Israel. Be strong and of good courage; do not fear nor be dismayed.

14. Indeed I have taken much trouble to prepare for the house of the LORD one hundred thousand talents of gold and one million talents of silver, and bronze and iron beyond measure, for it is so abundant. I have prepared timber and stone also, and you may add to them.

15. Moreover there are workmen with you in abundance: woodsmen and stonecutters, and all types of skillful men for every kind of work.

16. Of gold and silver and bronze and iron there is no limit. Arise and begin working, and the LORD be with you."

17. David also commanded all the leaders of Israel to help Solomon his son, saying,

18. "Is not the LORD your God with you? And has He not given you rest on every side? For He has given the inhabitants of the land into my hand, and the land is subdued before the LORD and before His people.

19. Now set your heart and your soul to seek the LORD your God. Therefore arise and build the sanctuary of the LORD God, to bring the ark of the covenant of the LORD and the holy articles of God into the house that is to be built for the name of the LORD."

## Chapter 23

1. So when David was old and full of days, he made his son Solomon king over Israel.

2. And he gathered together all the leaders of Israel, with the priests and the Levites.

3. Now the Levites were numbered from the age of thirty years and above; and the number of individual males was thirty-eight thousand.

4. Of these, twenty-four thousand were to look after the work of the house of the LORD, six thousand were officers and judges,

5. four thousand were gatekeepers, and four thousand praised the LORD with musical instruments, "which I made," said David, "for giving praise."

6. Also David separated them into divisions among the sons of Levi: Gershon, Kohath, and Merari.

7. Of the Gershonites: Laadan and Shimei.

8. The sons of Laadan: the first Jehiel, then Zetham and Joel--three in all.

9. The sons of Shimei: Shelomith, Haziel, and Haran--three in all. These were the heads of the fathers' houses of Laadan.

10. And the sons of Shimei: Jahath, Zina, Jeush, and Beriah. These were the four sons of Shimei.

11. Jahath was the first and Zizah the second. But Jeush and Beriah did not have many sons; therefore they were assigned as one father's house.

12. The sons of Kohath: Amram, Izhar, Hebron, and Uzziel--four in all.

13. The sons of Amram: Aaron and Moses; and Aaron was set apart, he and his sons forever, that he should sanctify the most holy things, to burn incense before the LORD, to minister to Him, and to give the blessing in His name forever.

14. Now the sons of Moses the man of God were reckoned to the tribe of Levi.

15. The sons of Moses were Gershon and Eliezer.

16. Of the sons of Gershon, Shebuel was the first.

17. Of the descendants of Eliezer, Rehabiah was the first. And Eliezer had no other sons, but the sons of Rehabiah were very many.

18. Of the sons of Izhar, Shelomith was the first.

19. Of the sons of Hebron, Jeriah was the first, Amariah the second, Jahaziel the third, and Jekameam the fourth.

20. Of the sons of Uzziel, Michah was the first and Jesshiah the second.

21. The sons of Merari were Mahli and Mushi. The sons of Mahli were Eleazar and Kish.

22. And Eleazar died, and had no sons, but only daughters; and their brethren, the sons of Kish, took them as wives.

23. The sons of Mushi were Mahli, Eder, and Jeremoth--three in all.

24. These were the sons of Levi by their fathers' houses--the heads of the fathers' houses as they were counted individually by the number of their names, who did the work for the service of the house of the LORD, from the age of twenty years and above.

25. For David said, "The LORD God of Israel has given rest to His people, that they may dwell in Jerusalem forever";

26. and also to the Levites, "They shall no longer carry the tabernacle, or any of the articles for its service."

27. For by the last words of David the Levites were numbered from twenty years old and above;

28. because their duty was to help the sons of Aaron in the service of the house of the LORD, in the courts and in the chambers, in the purifying of all holy things and the work of the service of the house of God,

29. both with the showbread and the fine flour for the grain offering, with the unleavened cakes and what is baked in the pan, with what is mixed and with all kinds of measures and sizes;

30. to stand every morning to thank and praise the LORD, and likewise at evening;

31. and at every presentation of a burnt offering to the LORD on the Sabbaths and on the New Moons and on the set feasts, by number according to the ordinance governing them, regularly before the LORD;

32. and that they should attend to the needs of the tabernacle of meeting, the needs of the holy place, and the needs of the sons of Aaron their brethren in the work of the house of the LORD.

## Chapter 24

1. Now these are the divisions of the sons of Aaron. The sons of Aaron were Nadab, Abihu, Eleazar, and Ithamar.

2. And Nadab and Abihu died before their father, and had no children; therefore Eleazar and Ithamar ministered as priests.

3. Then David with Zadok of the sons of Eleazar, and Ahimelech of the sons of Ithamar, divided them according to the schedule of their service.

4. There were more leaders found of the sons of Eleazar than of the sons of Ithamar, and thus they were divided. Among the sons of Eleazar were sixteen heads of their fathers' houses, and eight heads of their fathers' houses among the sons of Ithamar.

5. Thus they were divided by lot, one group as another, for there were officials of the sanctuary and officials of the house of God, from the sons of Eleazar and from the sons of Ithamar.

6. And the scribe, Shemaiah the son of Nethanel, one of the Levites, wrote them down before the king, the leaders, Zadok the priest, Ahimelech the son of Abiathar, and the heads of the fathers' houses of the priests and Levites, one father's house taken for Eleazar and one for Ithamar.

7. Now the first lot fell to Jehoiarib, the second to Jedaiah,

8. the third to Harim, the fourth to Seorim,

9. the fifth to Malchijah, the sixth to Mijamin,

10. the seventh to Hakkoz, the eighth to Abijah,

11. the ninth to Jeshua, the tenth to Shecaniah,

12. the eleventh to Eliashib, the twelfth to Jakim,

13. the thirteenth to Huppah, the fourteenth to Jeshebeab,

14. the fifteenth to Bilgah, the sixteenth to Immer,

15. the seventeenth to Hezir, the eighteenth to Happizzez,

16. the nineteenth to Pethahiah, the twentieth to Jehezekel,

17. the twenty-first to Jachin, the twenty-second to Gamul,

18. the twenty-third to Delaiah, the twenty-fourth to Maaziah.

19. This was the schedule of their service for coming into the house of the LORD according to their ordinance by the hand of Aaron their father, as the LORD God of Israel had commanded him.

20. And the rest of the sons of Levi: of the sons of Amram, Shubael; of the sons of Shubael, Jehdeiah.

21. Concerning Rehabiah, of the sons of Rehabiah, the first was Isshiah.

22. Of the Izharites, Shelomoth; of the sons of Shelomoth, Jahath.

23. Of the sons of Hebron, Jeriah was the first, Amariah the second, Jahaziel the third, and Jekameam the fourth.

24. Of the sons of Uzziel, Michah; of the sons of Michah, Shamir.

25. The brother of Michah, Isshiah; of the sons of Isshiah, Zechariah.

26. The sons of Merari were Mahli and Mushi; the son of Jaaziah, Beno.

27. The sons of Merari by Jaaziah were Beno, Shoham, Zaccur, and Ibri.

28. Of Mahli: Eleazar, who had no sons.

29. Of Kish: the son of Kish, Jerahmeel.

30. Also the sons of Mushi were Mahli, Eder, and Jerimoth. These were the sons of the Levites according to their fathers' houses.

31. These also cast lots just as their brothers the sons of Aaron did, in the presence of King David, Zadok, Ahimelech, and the heads of the fathers' houses of the priests and Levites. The chief fathers did just as their younger brethren.

## Chapter 25

1. Moreover David and the captains of the army separated for the service some of the sons of Asaph, of Heman, and of Jeduthun, who should prophesy with harps, stringed instruments, and cymbals. And the number of the skilled men performing their service was:

2. Of the sons of Asaph: Zaccur, Joseph, Nethaniah, and Asharelah; the sons of Asaph were under the direction of Asaph, who prophesied according to the order of the king.

3. Of Jeduthun, the sons of Jeduthun: Gedaliah, Zeri, Jeshaiah, Shimei, Hashabiah, and Mattithiah, six, under the direction of their father Jeduthun, who prophesied with a harp to give thanks and to praise the LORD.

4. Of Heman, the sons of Heman: Bukkiah, Mattaniah, Uzziel, Shebuel, Jerimoth, Hananiah, Hanani, Eliathah, Giddalti, Romamti-Ezer, Joshbekashah, Mallothi, Hothir, and Mahazioth.

5. All these were the sons of Heman the king's seer in the words of God, to exalt his horn. For God gave Heman fourteen sons and three daughters.

6. All these were under the direction of their father for the music in the house of the LORD, with cymbals, stringed instruments, and harps, for the service of the house of God. Asaph, Jeduthun, and Heman were under the authority of the king.

7. So the number of them, with their brethren who were instructed in the songs of the LORD, all who were skillful, was two hundred and eighty-eight.

8. And they cast lots for their duty, the small as well as the great, the teacher with the student.

9. Now the first lot for Asaph came out for Joseph; the second for Gedaliah, him with his brethren and sons, twelve;

10. the third for Zaccur, his sons and his brethren, twelve;

11. the fourth for Jizri, his sons and his brethren, twelve;

12. the fifth for Nethaniah, his sons and his brethren, twelve;

13. the sixth for Bukkiah, his sons and his brethren, twelve;

14. the seventh for Jesharelah, his sons and his brethren, twelve;

15. the eighth for Jeshaiah, his sons and his brethren, twelve;

16. the ninth for Mattaniah, his sons and his brethren, twelve;

17. the tenth for Shimei, his sons and his brethren, twelve;

18. the eleventh for Azarel, his sons and his brethren, twelve;

19. the twelfth for Hashabiah, his sons and his brethren, twelve;

20. the thirteenth for Shubael, his sons and his brethren, twelve;

21. the fourteenth for Mattithiah, his sons and his brethren, twelve;

22. the fifteenth for Jeremoth, his sons and his brethren, twelve;

23. the sixteenth for Hananiah, his sons and his brethren, twelve;

24. the seventeenth for Joshbekashah, his sons and his brethren, twelve;

25. the eighteenth for Hanani, his sons and his brethren, twelve;

26. the nineteenth for Mallothi, his sons and his brethren, twelve;

27. the twentieth for Eliathah, his sons and his brethren, twelve;

28. the twenty-first for Hothir, his sons and his brethren, twelve;

29. the twenty-second for Giddalti, his sons and his brethren, twelve;

30. the twenty-third for Mahazioth, his sons and his brethren, twelve;

31. the twenty-fourth for Romamti-Ezer, his sons and his brethren, twelve.

## Chapter 26

1. Concerning the divisions of the gatekeepers: of the Korahites, Meshelemiah the son of Kore, of the sons of Asaph.

2. And the sons of Meshelemiah were Zechariah the firstborn, Jediael the second, Zebadiah the third, Jathniel the fourth,

3. Elam the fifth, Jehohanan the sixth, Eliehoenai the seventh.

4. Moreover the sons of Obed-Edom were Shemaiah the firstborn, Jehozabad the second, Joah the third, Sacar the fourth, Nethanel the fifth,

5. Ammiel the sixth, Issachar the seventh, Peulthai the eighth; for God blessed him.

6. Also to Shemaiah his son were sons born who governed their fathers' houses, because they were men of great ability.

7. The sons of Shemaiah were Othni, Rephael, Obed, and Elzabad, whose brothers Elihu and Semachiah were able men.

8. All these were of the sons of Obed-Edom, they and their sons and their brethren, able men with strength for the work: sixty-two of Obed-Edom.

9. And Meshelemiah had sons and brethren, eighteen able men.

10. Also Hosah, of the children of Merari, had sons: Shimri the first (for though he was not the firstborn, his father made him the first),

11. Hilkiah the second, Tebaliah the third, Zechariah the fourth; all the sons and brethren of Hosah were thirteen.

12. Among these were the divisions of the gatekeepers, among the chief men, having duties just like their brethren, to serve in the house of the LORD.

13. And they cast lots for each gate, the small as well as the great, according to their father's house.

14. The lot for the East Gate fell to Shelemiah. Then they cast lots for his son Zechariah, a wise counselor, and his lot came out for the North Gate;

15. to Obed-Edom the South Gate, and to his sons the storehouse.

16. To Shuppim and Hosah the lot came out for the West Gate, with the Shallecheth Gate on the ascending highway--watchman opposite watchman.

17. On the east were six Levites, on the north four each day, on the south four each day, and for the storehouse two by two.

18. As for the Parbar on the west, there were four on the highway and two at the Parbar.

19. These were the divisions of the gatekeepers among the sons of Korah and among the sons of Merari.

20. Of the Levites, Ahijah was over the treasuries of the house of God and over the treasuries of the dedicated things.

21. The sons of Laadan, the descendants of the Gershonites of Laadan, heads of their fathers' houses, of Laadan the Gershonite: Jehieli.

22. The sons of Jehieli, Zetham and Joel his brother, were over the treasuries of the house of the LORD.

23. Of the Amramites, the Izharites, the Hebronites, and the Uzzielites:

24. Shebuel the son of Gershom, the son of Moses, was overseer of the treasuries.

25. And his brethren by Eliezer were Rehabiah his son, Jeshaiah his son, Joram his son, Zichri his son, and Shelomith his son.

26. This Shelomith and his brethren were over all the treasuries of the dedicated things which King David and the heads of fathers' houses, the captains over thousands and hundreds, and the captains of the army, had dedicated.

27. Some of the spoils won in battles they dedicated to maintain the house of the LORD.

28. And all that Samuel the seer, Saul the son of Kish, Abner the son of Ner, and Joab the son of Zeruiah had dedicated, every dedicated thing, was under the hand of Shelomith and his brethren.

29. Of the Izharites, Chenaniah and his sons performed duties as officials and judges over Israel outside Jerusalem.

30. Of the Hebronites, Hashabiah and his brethren, one thousand seven hundred able men, had the oversight of Israel on the west side of the Jordan for all the business of the LORD, and in the service of the king.

31. Among the Hebronites, Jerijah was head of the Hebronites according to his genealogy of the fathers. In the fortieth year of the reign of David they were sought, and there were found among them capable men at Jazer of Gilead.

32. And his brethren were two thousand seven hundred able men, heads of fathers' houses, whom King David made officials over the Reubenites, the Gadites, and the half-tribe of Manasseh, for every matter pertaining to God and the affairs of the king.

## Chapter 27

1. And the children of Israel, according to their number, the heads of fathers' houses, the captains of thousands and hundreds and their officers, served the king in every matter of the military divisions. These divisions came in and went out month by month throughout all the months of the year, each division having twenty-four thousand.

2. Over the first division for the first month was Jashobeam the son of Zabdiel, and in his division were twenty-four thousand;

3. he was of the children of Perez, and the chief of all the captains of the army for the first month.

4. Over the division of the second month was Dodai an Ahohite, and of his division Mikloth also was the leader; in his division were twenty-four thousand.

5. The third captain of the army for the third month was Benaiah, the son of Jehoiada the priest, who was chief; in his division were twenty-four thousand.

6. This was the Benaiah who was mighty among the thirty, and was over the thirty; in his division was Ammizabad his son.

7. The fourth captain for the fourth month was Asahel the brother of Joab, and Zebadiah his son after him; in his division were twenty-four thousand.

8. The fifth captain for the fifth month was Shamhuth the Izrahite; in his division were twenty-four thousand.

9. The sixth captain for the sixth month was Ira the son of Ikkesh the Tekoite; in his division were twenty-four thousand.

10. The seventh captain for the seventh month was Helez the Pelonite, of the children of Ephraim; in his division were twenty-four thousand.

11. The eighth captain for the eighth month was Sibbechai the Hushathite, of the Zarhites; in his division were twenty-four thousand.

12. The ninth captain for the ninth month was Abiezer the Anathothite, of the Benjamites; in his division were twenty-four thousand.

13. The tenth captain for the tenth month was Maharai the Netophathite, of the Zarhites; in his division were twenty-four thousand.

14. The eleventh captain for the eleventh month was Benaiah the Pirathonite, of the children of Ephraim; in his division were twenty-four thousand.

15. The twelfth captain for the twelfth month was Heldai the Netophathite, of Othniel; in his division were twenty-four thousand.

16. Furthermore, over the tribes of Israel: the officer over the Reubenites was Eliezer the son of Zichri; over the Simeonites, Shephatiah the son of Maachah;

17. over the Levites, Hashabiah the son of Kemuel; over the Aaronites, Zadok;

18. over Judah, Elihu, one of David's brothers; over Issachar, Omri the son of Michael;

19. over Zebulun, Ishmaiah the son of Obadiah; over Naphtali, Jerimoth the son of Azriel;

20. over the children of Ephraim, Hoshea the son of Azaziah; over the half-tribe of Manasseh, Joel the son of Pedaiah;

21. over the half-tribe of Manasseh in Gilead, Iddo the son of Zechariah; over Benjamin, Jaasiel the son of Abner;

22. over Dan, Azarel the son of Jeroham. These were the leaders of the tribes of Israel.

23. But David did not take the number of those twenty years old and under, because the LORD had said He would multiply Israel like the stars of the heavens.

24. Joab the son of Zeruiah began a census, but he did not finish, for wrath came upon Israel because of this census; nor was the number recorded in the account of the chronicles of King David.

25. And Azmaveth the son of Adiel was over the king's treasuries; and Jehonathan the son of Uzziah was over the storehouses in the field, in the cities, in the villages, and in the fortresses.

26. Ezri the son of Chelub was over those who did the work of the field for tilling the ground.

27. And Shimei the Ramathite was over the vineyards, and Zabdi the Shiphmite was over the produce of the vineyards for the supply of wine.

28. Baal-Hanan the Gederite was over the olive trees and the sycamore trees that were in the lowlands, and Joash was over the store of oil.

29. And Shitrai the Sharonite was over the herds that fed in Sharon, and Shaphat the son of Adlai was over the herds that were in the valleys.

30. Obil the Ishmaelite was over the camels, Jehdeiah the Meronothite was over the donkeys,

31. and Jaziz the Hagrite was over the flocks. All these were the officials over King David's property.

32. Also Jehonathan, David's uncle, was a counselor, a wise man, and a scribe; and Jehiel the son of Hachmoni was with the king's sons.

33. Ahithophel was the king's counselor, and Hushai the Archite was the king's companion.

34. After Ahithophel was Jehoiada the son of Benaiah, then Abiathar. And the general of the king's army was Joab.

## Chapter 28

1. Now David assembled at Jerusalem all the leaders of Israel: the officers of the tribes and the captains of the divisions who served the king, the captains over thousands and captains over hundreds, and the stewards over all the substance and possessions of the king and of his sons, with the officials, the valiant men, and all the mighty men of valor.

2. Then King David rose to his feet and said, "Hear me, my brethren and my people: I had it in my heart to build a house of rest for the ark of the covenant of the LORD, and for the footstool of our God, and had made preparations to build it.

3. But God said to me, "You shall not build a house for My name, because you have been a man of war and have shed blood.'

4. However the LORD God of Israel chose me above all the house of my father to be king over Israel forever, for He has chosen Judah to be the ruler. And of the house of Judah, the house of my father, and among the sons of my father, He was pleased with me to make me king over all Israel.

5. And of all my sons (for the LORD has given me many sons) He has chosen my son Solomon to sit on the throne of the kingdom of the LORD over Israel.

6. Now He said to me, "It is your son Solomon who shall build My house and My courts; for I have chosen him to be My son, and I will be his Father.

7. Moreover I will establish his kingdom forever, if he is steadfast to observe My commandments and My judgments, as it is this day.'

8. Now therefore, in the sight of all Israel, the assembly of the LORD, and in the hearing of our God, be careful to seek out all the commandments of the LORD your God, that you may possess this good land, and leave it as an inheritance for your children after you forever.

9. "As for you, my son Solomon, know the God of your father, and serve Him with a loyal heart and with a willing mind; for the LORD searches all hearts and understands all the intent of the thoughts. If you seek Him, He will be found by you; but if you forsake Him, He will cast you off forever.

10. Consider now, for the LORD has chosen you to build a house for the sanctuary; be strong, and do it."

11. Then David gave his son Solomon the plans for the vestibule, its houses, its treasuries, its upper chambers, its inner chambers, and the place of the mercy seat;

12. and the plans for all that he had by the Spirit, of the courts of the house of the LORD, of all the chambers all around, of the treasuries of the house of God, and of the treasuries for the dedicated things;

13. also for the division of the priests and the Levites, for all the work of the service of the house of the LORD, and for all the articles of service in the house of the LORD.

14. He gave gold by weight for things of gold, for all articles used in every kind of service; also silver for all articles of silver by weight, for all articles used in every kind of service;

15. the weight for the lampstands of gold, and their lamps of gold, by weight for each lampstand and its lamps; for the lampstands of silver by weight, for the lampstand and its lamps, according to the use of each lampstand.

16. And by weight he gave gold for the tables of the showbread, for each table, and silver for the tables of silver;

17. also pure gold for the forks, the basins, the pitchers of pure gold, and the golden bowls--he gave gold by weight for every bowl; and for the silver bowls, silver by weight for every bowl;

18. and refined gold by weight for the altar of incense, and for the construction of the chariot, that is, the gold cherubim that spread their wings and overshadowed the ark of the covenant of the LORD.

19. "All this," said David, "the LORD made me understand in writing, by His hand upon me, all the works of these plans."

20. And David said to his son Solomon, "Be strong and of good courage, and do it; do not fear nor be dismayed, for the LORD God--my God--will be with you. He will not leave you nor forsake you, until you have finished all the work for the service of the house of the LORD.

21. Here are the divisions of the priests and the Levites for all the service of the house of God; and every willing craftsman will be with you for all manner of workmanship, for every kind of service; also the leaders and all the people will be completely at your command."

## Chapter 29

1. Furthermore King David said to all the assembly: "My son Solomon, whom alone God has chosen, is young and inexperienced; and the work is great, because the temple is not for man but for the LORD God.

2. Now for the house of my God I have prepared with all my might: gold for things to be made of gold, silver for things of silver, bronze for things of bronze, iron for things of iron, wood for things of wood, onyx stones, stones to be set, glistening stones of various colors, all kinds of precious stones, and marble slabs in abundance.

3. Moreover, because I have set my affection on the house of my God, I have given to the house of my God, over and above all that I have prepared for the holy house, my own special treasure of gold and silver:

4. three thousand talents of gold, of the gold of Ophir, and seven thousand talents of refined silver, to overlay the walls of the houses;

5. the gold for things of gold and the silver for things of silver, and for all kinds of work to be done by the hands of craftsmen. Who then is willing to consecrate himself this day to the LORD?"

6. Then the leaders of the fathers' houses, leaders of the tribes of Israel, the captains of thousands and of hundreds, with the officers over the king's work, offered willingly.

7. They gave for the work of the house of God five thousand talents and ten thousand darics of gold, ten thousand talents of silver, eighteen thousand talents of bronze, and one hundred thousand talents of iron.

8. And whoever had precious stones gave them to the treasury of the house of the LORD, into the hand of Jehiel the Gershonite.

9. Then the people rejoiced, for they had offered willingly, because with a loyal heart they had offered willingly to the LORD; and King David also rejoiced greatly.

10. Therefore David blessed the LORD before all the assembly; and David said: "Blessed are You, LORD God of Israel, our Father, forever and ever.

11. Yours, O LORD, is the greatness, The power and the glory, The victory and the majesty; For all that is in heaven and in earth is Yours; Yours is the kingdom, O LORD, And You are exalted as head over all.

12. Both riches and honor come from You, And You reign over all. In Your hand is power and might; In Your hand it is to make great And to give strength to all.

13. "Now therefore, our God, We thank You And praise Your glorious name.

14. But who am I, and who are my people, That we should be able to offer so willingly as this? For all things come from You, And of Your own we have given You.

15. For we are aliens and pilgrims before You, As were all our fathers; Our days on earth are as a shadow, And without hope.

16. "O LORD our God, all this abundance that we have prepared to build You a house for Your holy name is from Your hand, and is all Your own.

17. I know also, my God, that You test the heart and have pleasure in uprightness. As for me, in the uprightness of my heart I have willingly offered all these things; and now with joy I have seen Your people, who are present here to offer willingly to You.

18. O LORD God of Abraham, Isaac, and Israel, our fathers, keep this forever in the intent of the thoughts of the heart of Your people, and fix their heart toward You.

19. And give my son Solomon a loyal heart to keep Your commandments and Your testimonies and Your statutes, to do all these things, and to build the temple for which I have made provision."

20. Then David said to all the assembly, "Now bless the LORD your God." So all the assembly blessed the LORD God of their fathers, and bowed their heads and prostrated themselves before the LORD and the king.

21. And they made sacrifices to the LORD and offered burnt offerings to the LORD on the next day: a thousand bulls, a thousand rams, a thousand lambs, with their drink offerings, and sacrifices in abundance for all Israel.

22. So they ate and drank before the LORD with great gladness on that day. And they made Solomon the son of David king the second time, and anointed him before the LORD to be the leader, and Zadok to be priest.

23. Then Solomon sat on the throne of the LORD as king instead of David his father, and prospered; and all Israel obeyed him.

24. All the leaders and the mighty men, and also all the sons of King David, submitted themselves to King Solomon.

25. So the LORD exalted Solomon exceedingly in the sight of all Israel, and bestowed on him such royal majesty as had not been on any king before him in Israel.

26. Thus David the son of Jesse reigned over all Israel.

27. And the period that he reigned over Israel was forty years; seven years he reigned in Hebron, and thirty-three years he reigned in Jerusalem.

28. So he died in a good old age, full of days and riches and honor; and Solomon his son reigned in his place.

29. Now the acts of King David, first and last, indeed they are written in the book of Samuel the seer, in the book of Nathan the prophet, and in the book of Gad the seer,

30. with all his reign and his might, and the events that happened to him, to Israel, and to all the kingdoms of the lands.


# 1-kings

## Chapter 1

1. Now King David was old, advanced in years; and they put covers on him, but he could not get warm.

2. Therefore his servants said to him, "Let a young woman, a virgin, be sought for our lord the king, and let her stand before the king, and let her care for him; and let her lie in your bosom, that our lord the king may be warm."

3. So they sought for a lovely young woman throughout all the territory of Israel, and found Abishag the Shunammite, and brought her to the king.

4. The young woman was very lovely; and she cared for the king, and served him; but the king did not know her.

5. Then Adonijah the son of Haggith exalted himself, saying, "I will be king"; and he prepared for himself chariots and horsemen, and fifty men to run before him.

6. (And his father had not rebuked him at any time by saying, "Why have you done so?" He was also very good-looking. His mother had borne him after Absalom.)

7. Then he conferred with Joab the son of Zeruiah and with Abiathar the priest, and they followed and helped Adonijah.

8. But Zadok the priest, Benaiah the son of Jehoiada, Nathan the prophet, Shimei, Rei, and the mighty men who belonged to David were not with Adonijah.

9. And Adonijah sacrificed sheep and oxen and fattened cattle by the stone of Zoheleth, which is by En Rogel; he also invited all his brothers, the king's sons, and all the men of Judah, the king's servants.

10. But he did not invite Nathan the prophet, Benaiah, the mighty men, or Solomon his brother.

11. So Nathan spoke to Bathsheba the mother of Solomon, saying, "Have you not heard that Adonijah the son of Haggith has become king, and David our lord does not know it?

12. Come, please, let me now give you advice, that you may save your own life and the life of your son Solomon.

13. Go immediately to King David and say to him, "Did you not, my lord, O king, swear to your maidservant, saying, "Assuredly your son Solomon shall reign after me, and he shall sit on my throne"? Why then has Adonijah become king?'

14. Then, while you are still talking there with the king, I also will come in after you and confirm your words."

15. So Bathsheba went into the chamber to the king. (Now the king was very old, and Abishag the Shunammite was serving the king.)

16. And Bathsheba bowed and did homage to the king. Then the king said, "What is your wish?"

17. Then she said to him, "My lord, you swore by the LORD your God to your maidservant, saying, "Assuredly Solomon your son shall reign after me, and he shall sit on my throne.'

18. So now, look! Adonijah has become king; and now, my lord the king, you do not know about it.

19. He has sacrificed oxen and fattened cattle and sheep in abundance, and has invited all the sons of the king, Abiathar the priest, and Joab the commander of the army; but Solomon your servant he has not invited.

20. And as for you, my lord, O king, the eyes of all Israel are on you, that you should tell them who will sit on the throne of my lord the king after him.

21. Otherwise it will happen, when my lord the king rests with his fathers, that I and my son Solomon will be counted as offenders."

22. And just then, while she was still talking with the king, Nathan the prophet also came in.

23. So they told the king, saying, "Here is Nathan the prophet." And when he came in before the king, he bowed down before the king with his face to the ground.

24. And Nathan said, "My lord, O king, have you said, "Adonijah shall reign after me, and he shall sit on my throne'?

25. For he has gone down today, and has sacrificed oxen and fattened cattle and sheep in abundance, and has invited all the king's sons, and the commanders of the army, and Abiathar the priest; and look! They are eating and drinking before him; and they say, "Long live King Adonijah!'

26. But he has not invited me--me your servant--nor Zadok the priest, nor Benaiah the son of Jehoiada, nor your servant Solomon.

27. Has this thing been done by my lord the king, and you have not told your servant who should sit on the throne of my lord the king after him?"

28. Then King David answered and said, "Call Bathsheba to me." So she came into the king's presence and stood before the king.

29. And the king took an oath and said, "As the LORD lives, who has redeemed my life from every distress,

30. just as I swore to you by the LORD God of Israel, saying, "Assuredly Solomon your son shall be king after me, and he shall sit on my throne in my place,' so I certainly will do this day."

31. Then Bathsheba bowed with her face to the earth, and paid homage to the king, and said, "Let my lord King David live forever!"

32. And King David said, "Call to me Zadok the priest, Nathan the prophet, and Benaiah the son of Jehoiada." So they came before the king.

33. The king also said to them, "Take with you the servants of your lord, and have Solomon my son ride on my own mule, and take him down to Gihon.

34. There let Zadok the priest and Nathan the prophet anoint him king over Israel; and blow the horn, and say, "Long live King Solomon!'

35. Then you shall come up after him, and he shall come and sit on my throne, and he shall be king in my place. For I have appointed him to be ruler over Israel and Judah."

36. Benaiah the son of Jehoiada answered the king and said, "Amen! May the LORD God of my lord the king say so too.

37. As the LORD has been with my lord the king, even so may He be with Solomon, and make his throne greater than the throne of my lord King David."

38. So Zadok the priest, Nathan the prophet, Benaiah the son of Jehoiada, the Cherethites, and the Pelethites went down and had Solomon ride on King David's mule, and took him to Gihon.

39. Then Zadok the priest took a horn of oil from the tabernacle and anointed Solomon. And they blew the horn, and all the people said, "Long live King Solomon!"

40. And all the people went up after him; and the people played the flutes and rejoiced with great joy, so that the earth seemed to split with their sound.

41. Now Adonijah and all the guests who were with him heard it as they finished eating. And when Joab heard the sound of the horn, he said, "Why is the city in such a noisy uproar?"

42. While he was still speaking, there came Jonathan, the son of Abiathar the priest. And Adonijah said to him, "Come in, for you are a prominent man, and bring good news."

43. Then Jonathan answered and said to Adonijah, "No! Our lord King David has made Solomon king.

44. The king has sent with him Zadok the priest, Nathan the prophet, Benaiah the son of Jehoiada, the Cherethites, and the Pelethites; and they have made him ride on the king's mule.

45. So Zadok the priest and Nathan the prophet have anointed him king at Gihon; and they have gone up from there rejoicing, so that the city is in an uproar. This is the noise that you have heard.

46. Also Solomon sits on the throne of the kingdom.

47. And moreover the king's servants have gone to bless our lord King David, saying, "May God make the name of Solomon better than your name, and may He make his throne greater than your throne.' Then the king bowed himself on the bed.

48. Also the king said thus, "Blessed be the LORD God of Israel, who has given one to sit on my throne this day, while my eyes see it!"'

49. So all the guests who were with Adonijah were afraid, and arose, and each one went his way.

50. Now Adonijah was afraid of Solomon; so he arose, and went and took hold of the horns of the altar.

51. And it was told Solomon, saying, "Indeed Adonijah is afraid of King Solomon; for look, he has taken hold of the horns of the altar, saying, "Let King Solomon swear to me today that he will not put his servant to death with the sword."'

52. Then Solomon said, "If he proves himself a worthy man, not one hair of him shall fall to the earth; but if wickedness is found in him, he shall die."

53. So King Solomon sent them to bring him down from the altar. And he came and fell down before King Solomon; and Solomon said to him, "Go to your house."

## Chapter 2

1. Now the days of David drew near that he should die, and he charged Solomon his son, saying:

2. "I go the way of all the earth; be strong, therefore, and prove yourself a man.

3. And keep the charge of the LORD your God: to walk in His ways, to keep His statutes, His commandments, His judgments, and His testimonies, as it is written in the Law of Moses, that you may prosper in all that you do and wherever you turn;

4. that the LORD may fulfill His word which He spoke concerning me, saying, "If your sons take heed to their way, to walk before Me in truth with all their heart and with all their soul,' He said, "you shall not lack a man on the throne of Israel.'

5. "Moreover you know also what Joab the son of Zeruiah did to me, and what he did to the two commanders of the armies of Israel, to Abner the son of Ner and Amasa the son of Jether, whom he killed. And he shed the blood of war in peacetime, and put the blood of war on his belt that was around his waist, and on his sandals that were on his feet.

6. Therefore do according to your wisdom, and do not let his gray hair go down to the grave in peace.

7. "But show kindness to the sons of Barzillai the Gileadite, and let them be among those who eat at your table, for so they came to me when I fled from Absalom your brother.

8. "And see, you have with you Shimei the son of Gera, a Benjamite from Bahurim, who cursed me with a malicious curse in the day when I went to Mahanaim. But he came down to meet me at the Jordan, and I swore to him by the LORD, saying, "I will not put you to death with the sword.'

9. Now therefore, do not hold him guiltless, for you are a wise man and know what you ought to do to him; but bring his gray hair down to the grave with blood."

10. So David rested with his fathers, and was buried in the City of David.

11. The period that David reigned over Israel was forty years; seven years he reigned in Hebron, and in Jerusalem he reigned thirty-three years.

12. Then Solomon sat on the throne of his father David; and his kingdom was firmly established.

13. Now Adonijah the son of Haggith came to Bathsheba the mother of Solomon. So she said, "Do you come peaceably?" And he said, "Peaceably."

14. Moreover he said, "I have something to say to you." And she said, "Say it."

15. Then he said, "You know that the kingdom was mine, and all Israel had set their expectations on me, that I should reign. However, the kingdom has been turned over, and has become my brother's; for it was his from the LORD.

16. Now I ask one petition of you; do not deny me." And she said to him, "Say it."

17. Then he said, "Please speak to King Solomon, for he will not refuse you, that he may give me Abishag the Shunammite as wife."

18. So Bathsheba said, "Very well, I will speak for you to the king."

19. Bathsheba therefore went to King Solomon, to speak to him for Adonijah. And the king rose up to meet her and bowed down to her, and sat down on his throne and had a throne set for the king's mother; so she sat at his right hand.

20. Then she said, "I desire one small petition of you; do not refuse me." And the king said to her, "Ask it, my mother, for I will not refuse you."

21. So she said, "Let Abishag the Shunammite be given to Adonijah your brother as wife."

22. And King Solomon answered and said to his mother, "Now why do you ask Abishag the Shunammite for Adonijah? Ask for him the kingdom also--for he is my older brother--for him, and for Abiathar the priest, and for Joab the son of Zeruiah."

23. Then King Solomon swore by the LORD, saying, "May God do so to me, and more also, if Adonijah has not spoken this word against his own life!

24. Now therefore, as the LORD lives, who has confirmed me and set me on the throne of David my father, and who has established a house for me, as He promised, Adonijah shall be put to death today!"

25. So King Solomon sent by the hand of Benaiah the son of Jehoiada; and he struck him down, and he died.

26. And to Abiathar the priest the king said, "Go to Anathoth, to your own fields, for you are deserving of death; but I will not put you to death at this time, because you carried the ark of the Lord GOD before my father David, and because you were afflicted every time my father was afflicted."

27. So Solomon removed Abiathar from being priest to the LORD, that he might fulfill the word of the LORD which He spoke concerning the house of Eli at Shiloh.

28. Then news came to Joab, for Joab had defected to Adonijah, though he had not defected to Absalom. So Joab fled to the tabernacle of the LORD, and took hold of the horns of the altar.

29. And King Solomon was told, "Joab has fled to the tabernacle of the LORD; there he is, by the altar." Then Solomon sent Benaiah the son of Jehoiada, saying, "Go, strike him down."

30. So Benaiah went to the tabernacle of the LORD, and said to him, "Thus says the king, "Come out!"' And he said, "No, but I will die here." And Benaiah brought back word to the king, saying, "Thus said Joab, and thus he answered me."

31. Then the king said to him, "Do as he has said, and strike him down and bury him, that you may take away from me and from the house of my father the innocent blood which Joab shed.

32. So the LORD will return his blood on his head, because he struck down two men more righteous and better than he, and killed them with the sword--Abner the son of Ner, the commander of the army of Israel, and Amasa the son of Jether, the commander of the army of Judah--though my father David did not know it.

33. Their blood shall therefore return upon the head of Joab and upon the head of his descendants forever. But upon David and his descendants, upon his house and his throne, there shall be peace forever from the LORD."

34. So Benaiah the son of Jehoiada went up and struck and killed him; and he was buried in his own house in the wilderness.

35. The king put Benaiah the son of Jehoiada in his place over the army, and the king put Zadok the priest in the place of Abiathar.

36. Then the king sent and called for Shimei, and said to him, "Build yourself a house in Jerusalem and dwell there, and do not go out from there anywhere.

37. For it shall be, on the day you go out and cross the Brook Kidron, know for certain you shall surely die; your blood shall be on your own head."

38. And Shimei said to the king, "The saying is good. As my lord the king has said, so your servant will do." So Shimei dwelt in Jerusalem many days.

39. Now it happened at the end of three years, that two slaves of Shimei ran away to Achish the son of Maachah, king of Gath. And they told Shimei, saying, "Look, your slaves are in Gath!"

40. So Shimei arose, saddled his donkey, and went to Achish at Gath to seek his slaves. And Shimei went and brought his slaves from Gath.

41. And Solomon was told that Shimei had gone from Jerusalem to Gath and had come back.

42. Then the king sent and called for Shimei, and said to him, "Did I not make you swear by the LORD, and warn you, saying, "Know for certain that on the day you go out and travel anywhere, you shall surely die'? And you said to me, "The word I have heard is good.'

43. Why then have you not kept the oath of the LORD and the commandment that I gave you?"

44. The king said moreover to Shimei, "You know, as your heart acknowledges, all the wickedness that you did to my father David; therefore the LORD will return your wickedness on your own head.

45. But King Solomon shall be blessed, and the throne of David shall be established before the LORD forever."

46. So the king commanded Benaiah the son of Jehoiada; and he went out and struck him down, and he died. Thus the kingdom was established in the hand of Solomon.

## Chapter 3

1. Now Solomon made a treaty with Pharaoh king of Egypt, and married Pharaoh's daughter; then he brought her to the City of David until he had finished building his own house, and the house of the LORD, and the wall all around Jerusalem.

2. Meanwhile the people sacrificed at the high places, because there was no house built for the name of the LORD until those days.

3. And Solomon loved the LORD, walking in the statutes of his father David, except that he sacrificed and burned incense at the high places.

4. Now the king went to Gibeon to sacrifice there, for that was the great high place: Solomon offered a thousand burnt offerings on that altar.

5. At Gibeon the LORD appeared to Solomon in a dream by night; and God said, "Ask! What shall I give you?"

6. And Solomon said: "You have shown great mercy to Your servant David my father, because he walked before You in truth, in righteousness, and in uprightness of heart with You; You have continued this great kindness for him, and You have given him a son to sit on his throne, as it is this day.

7. Now, O LORD my God, You have made Your servant king instead of my father David, but I am a little child; I do not know how to go out or come in.

8. And Your servant is in the midst of Your people whom You have chosen, a great people, too numerous to be numbered or counted.

9. Therefore give to Your servant an understanding heart to judge Your people, that I may discern between good and evil. For who is able to judge this great people of Yours?"

10. The speech pleased the LORD, that Solomon had asked this thing.

11. Then God said to him: "Because you have asked this thing, and have not asked long life for yourself, nor have asked riches for yourself, nor have asked the life of your enemies, but have asked for yourself understanding to discern justice,

12. behold, I have done according to your words; see, I have given you a wise and understanding heart, so that there has not been anyone like you before you, nor shall any like you arise after you.

13. And I have also given you what you have not asked: both riches and honor, so that there shall not be anyone like you among the kings all your days.

14. So if you walk in My ways, to keep My statutes and My commandments, as your father David walked, then I will lengthen your days."

15. Then Solomon awoke; and indeed it had been a dream. And he came to Jerusalem and stood before the ark of the covenant of the LORD, offered up burnt offerings, offered peace offerings, and made a feast for all his servants.

16. Now two women who were harlots came to the king, and stood before him.

17. And one woman said, "O my lord, this woman and I dwell in the same house; and I gave birth while she was in the house.

18. Then it happened, the third day after I had given birth, that this woman also gave birth. And we were together; no one was with us in the house, except the two of us in the house.

19. And this woman's son died in the night, because she lay on him.

20. So she arose in the middle of the night and took my son from my side, while your maidservant slept, and laid him in her bosom, and laid her dead child in my bosom.

21. And when I rose in the morning to nurse my son, there he was, dead. But when I had examined him in the morning, indeed, he was not my son whom I had borne."

22. Then the other woman said, "No! But the living one is my son, and the dead one is your son." And the first woman said, "No! But the dead one is your son, and the living one is my son." Thus they spoke before the king.

23. And the king said, "The one says, "This is my son, who lives, and your son is the dead one'; and the other says, "No! But your son is the dead one, and my son is the living one.'|"

24. Then the king said, "Bring me a sword." So they brought a sword before the king.

25. And the king said, "Divide the living child in two, and give half to one, and half to the other."

26. Then the woman whose son was living spoke to the king, for she yearned with compassion for her son; and she said, "O my lord, give her the living child, and by no means kill him!" But the other said, "Let him be neither mine nor yours, but divide him."

27. So the king answered and said, "Give the first woman the living child, and by no means kill him; she is his mother."

28. And all Israel heard of the judgment which the king had rendered; and they feared the king, for they saw that the wisdom of God was in him to administer justice.

## Chapter 4

1. So King Solomon was king over all Israel.

2. And these were his officials: Azariah the son of Zadok, the priest;

3. Elihoreph and Ahijah, the sons of Shisha, scribes; Jehoshaphat the son of Ahilud, the recorder;

4. Benaiah the son of Jehoiada, over the army; Zadok and Abiathar, the priests;

5. Azariah the son of Nathan, over the officers; Zabud the son of Nathan, a priest and the king's friend;

6. Ahishar, over the household; and Adoniram the son of Abda, over the labor force.

7. And Solomon had twelve governors over all Israel, who provided food for the king and his household; each one made provision for one month of the year.

8. These are their names: Ben-Hur, in the mountains of Ephraim;

9. Ben-Deker, in Makaz, Shaalbim, Beth Shemesh, and Elon Beth Hanan;

10. Ben-Hesed, in Arubboth; to him belonged Sochoh and all the land of Hepher;

11. Ben-Abinadab, in all the regions of Dor; he had Taphath the daughter of Solomon as wife;

12. Baana the son of Ahilud, in Taanach, Megiddo, and all Beth Shean, which is beside Zaretan below Jezreel, from Beth Shean to Abel Meholah, as far as the other side of Jokneam;

13. Ben-Geber, in Ramoth Gilead; to him belonged the towns of Jair the son of Manasseh, in Gilead; to him also belonged the region of Argob in Bashan--sixty large cities with walls and bronze gate-bars;

14. Ahinadab the son of Iddo, in Mahanaim;

15. Ahimaaz, in Naphtali; he also took Basemath the daughter of Solomon as wife;

16. Baanah the son of Hushai, in Asher and Aloth;

17. Jehoshaphat the son of Paruah, in Issachar;

18. Shimei the son of Elah, in Benjamin;

19. Geber the son of Uri, in the land of Gilead, in the country of Sihon king of the Amorites, and of Og king of Bashan. He was the only governor who was in the land.

20. Judah and Israel were as numerous as the sand by the sea in multitude, eating and drinking and rejoicing.

21. So Solomon reigned over all kingdoms from the River to the land of the Philistines, as far as the border of Egypt. They brought tribute and served Solomon all the days of his life.

22. Now Solomon's provision for one day was thirty kors of fine flour, sixty kors of meal,

23. ten fatted oxen, twenty oxen from the pastures, and one hundred sheep, besides deer, gazelles, roebucks, and fatted fowl.

24. For he had dominion over all the region on this side of the River from Tiphsah even to Gaza, namely over all the kings on this side of the River; and he had peace on every side all around him.

25. And Judah and Israel dwelt safely, each man under his vine and his fig tree, from Dan as far as Beersheba, all the days of Solomon.

26. Solomon had forty thousand stalls of horses for his chariots, and twelve thousand horsemen.

27. And these governors, each man in his month, provided food for King Solomon and for all who came to King Solomon's table. There was no lack in their supply.

28. They also brought barley and straw to the proper place, for the horses and steeds, each man according to his charge.

29. And God gave Solomon wisdom and exceedingly great understanding, and largeness of heart like the sand on the seashore.

30. Thus Solomon's wisdom excelled the wisdom of all the men of the East and all the wisdom of Egypt.

31. For he was wiser than all men--than Ethan the Ezrahite, and Heman, Chalcol, and Darda, the sons of Mahol; and his fame was in all the surrounding nations.

32. He spoke three thousand proverbs, and his songs were one thousand and five.

33. Also he spoke of trees, from the cedar tree of Lebanon even to the hyssop that springs out of the wall; he spoke also of animals, of birds, of creeping things, and of fish.

34. And men of all nations, from all the kings of the earth who had heard of his wisdom, came to hear the wisdom of Solomon.

## Chapter 5

1. Now Hiram king of Tyre sent his servants to Solomon, because he heard that they had anointed him king in place of his father, for Hiram had always loved David.

2. Then Solomon sent to Hiram, saying:

3. You know how my father David could not build a house for the name of the LORD his God because of the wars which were fought against him on every side, until the LORD put his foes under the soles of his feet.

4. But now the LORD my God has given me rest on every side; there is neither adversary nor evil occurrence.

5. And behold, I propose to build a house for the name of the LORD my God, as the LORD spoke to my father David, saying, "Your son, whom I will set on your throne in your place, he shall build the house for My name."

6. Now therefore, command that they cut down cedars for me from Lebanon; and my servants will be with your servants, and I will pay you wages for your servants according to whatever you say. For you know there is none among us who has skill to cut timber like the Sidonians.

7. So it was, when Hiram heard the words of Solomon, that he rejoiced greatly and said, 4 Blessed be the LORD this day, for He has given David a wise son over this great people!

8. Then Hiram sent to Solomon, saying: 4 I have considered the message which you sent me, and I will do all you desire concerning the cedar and cypress logs.

9. My servants shall bring them down from Lebanon to the sea; I will float them in rafts by sea to the place you indicate to me, and will have them broken apart there; then you can take them away. And you shall fulfill my desire by giving food for my household.

10. Then Hiram gave Solomon cedar and cypress logs according to all his desire.

11. And Solomon gave Hiram twenty thousand kors of wheat as food for his household, and twenty kors of pressed oil. Thus Solomon gave to Hiram year by year.

12. So the LORD gave Solomon wisdom, as He had promised him; and there was peace between Hiram and Solomon, and the two of them made a treaty together.

13. Then King Solomon raised up a labor force out of all Israel; and the labor force was thirty thousand men.

14. And he sent them to Lebanon, ten thousand a month in shifts: they were one month in Lebanon and two months at home; Adoniram was in charge of the labor force.

15. Solomon had seventy thousand who carried burdens, and eighty thousand who quarried stone in the mountains,

16. besides three thousand three hundred from the chiefs of Solomon's deputies, who supervised the people who labored in the work.

17. And the king commanded them to quarry large stones, costly stones, and hewn stones, to lay the foundation of the temple.

18. So Solomon's builders, Hiram's builders, and the Gebalites quarried them; and they prepared timber and stones to build the temple.

## Chapter 6

1. And it came to pass in the four hundred and eightieth year after the children of Israel had come out of the land of Egypt, in the fourth year of Solomon's reign over Israel, in the month of Ziv, which is the second month, that he began to build the house of the LORD.

2. Now the house which King Solomon built for the LORD, its length was sixty cubits, its width twenty, and its height thirty cubits.

3. The vestibule in front of the sanctuary of the house was twenty cubits long across the width of the house, and the width of the vestibule extended ten cubits from the front of the house.

4. And he made for the house windows with beveled frames.

5. Against the wall of the temple he built chambers all around, against the walls of the temple, all around the sanctuary and the inner sanctuary. Thus he made side chambers all around it.

6. The lowest chamber was five cubits wide, the middle was six cubits wide, and the third was seven cubits wide; for he made narrow ledges around the outside of the temple, so that the support beams would not be fastened into the walls of the temple.

7. And the temple, when it was being built, was built with stone finished at the quarry, so that no hammer or chisel or any iron tool was heard in the temple while it was being built.

8. The doorway for the middle story was on the right side of the temple. They went up by stairs to the middle story, and from the middle to the third.

9. So he built the temple and finished it, and he paneled the temple with beams and boards of cedar.

10. And he built side chambers against the entire temple, each five cubits high; they were attached to the temple with cedar beams.

11. Then the word of the LORD came to Solomon, saying:

12. "Concerning this temple which you are building, if you walk in My statutes, execute My judgments, keep all My commandments, and walk in them, then I will perform My word with you, which I spoke to your father David.

13. And I will dwell among the children of Israel, and will not forsake My people Israel."

14. So Solomon built the temple and finished it.

15. And he built the inside walls of the temple with cedar boards; from the floor of the temple to the ceiling he paneled the inside with wood; and he covered the floor of the temple with planks of cypress.

16. Then he built the twenty-cubit room at the rear of the temple, from floor to ceiling, with cedar boards; he built it inside as the inner sanctuary, as the Most Holy Place.

17. And in front of it the temple sanctuary was forty cubits long.

18. The inside of the temple was cedar, carved with ornamental buds and open flowers. All was cedar; there was no stone to be seen.

19. And he prepared the inner sanctuary inside the temple, to set the ark of the covenant of the LORD there.

20. The inner sanctuary was twenty cubits long, twenty cubits wide, and twenty cubits high. He overlaid it with pure gold, and overlaid the altar of cedar.

21. So Solomon overlaid the inside of the temple with pure gold. He stretched gold chains across the front of the inner sanctuary, and overlaid it with gold.

22. The whole temple he overlaid with gold, until he had finished all the temple; also he overlaid with gold the entire altar that was by the inner sanctuary.

23. Inside the inner sanctuary he made two cherubim of olive wood, each ten cubits high.

24. One wing of the cherub was five cubits, and the other wing of the cherub five cubits: ten cubits from the tip of one wing to the tip of the other.

25. And the other cherub was ten cubits; both cherubim were of the same size and shape.

26. The height of one cherub was ten cubits, and so was the other cherub.

27. Then he set the cherubim inside the inner room; and they stretched out the wings of the cherubim so that the wing of the one touched one wall, and the wing of the other cherub touched the other wall. And their wings touched each other in the middle of the room.

28. Also he overlaid the cherubim with gold.

29. Then he carved all the walls of the temple all around, both the inner and outer sanctuaries, with carved figures of cherubim, palm trees, and open flowers.

30. And the floor of the temple he overlaid with gold, both the inner and outer sanctuaries.

31. For the entrance of the inner sanctuary he made doors of olive wood; the lintel and doorposts were one-fifth of the wall.

32. The two doors were of olive wood; and he carved on them figures of cherubim, palm trees, and open flowers, and overlaid them with gold; and he spread gold on the cherubim and on the palm trees.

33. So for the door of the sanctuary he also made doorposts of olive wood, one-fourth of the wall.

34. And the two doors were of cypress wood; two panels comprised one folding door, and two panels comprised the other folding door.

35. Then he carved cherubim, palm trees, and open flowers on them, and overlaid them with gold applied evenly on the carved work.

36. And he built the inner court with three rows of hewn stone and a row of cedar beams.

37. In the fourth year the foundation of the house of the LORD was laid, in the month of Ziv.

38. And in the eleventh year, in the month of Bul, which is the eighth month, the house was finished in all its details and according to all its plans. So he was seven years in building it.

## Chapter 7

1. But Solomon took thirteen years to build his own house; so he finished all his house.

2. He also built the House of the Forest of Lebanon; its length was one hundred cubits, its width fifty cubits, and its height thirty cubits, with four rows of cedar pillars, and cedar beams on the pillars.

3. And it was paneled with cedar above the beams that were on forty-five pillars, fifteen to a row.

4. There were windows with beveled frames in three rows, and window was opposite window in three tiers.

5. And all the doorways and doorposts had rectangular frames; and window was opposite window in three tiers.

6. He also made the Hall of Pillars: its length was fifty cubits, and its width thirty cubits; and in front of them was a portico with pillars, and a canopy was in front of them.

7. Then he made a hall for the throne, the Hall of Judgment, where he might judge; and it was paneled with cedar from floor to ceiling.

8. And the house where he dwelt had another court inside the hall, of like workmanship. Solomon also made a house like this hall for Pharaoh's daughter, whom he had taken as wife.

9. All these were of costly stones cut to size, trimmed with saws, inside and out, from the foundation to the eaves, and also on the outside to the great court.

10. The foundation was of costly stones, large stones, some ten cubits and some eight cubits.

11. And above were costly stones, hewn to size, and cedar wood.

12. The great court was enclosed with three rows of hewn stones and a row of cedar beams. So were the inner court of the house of the LORD and the vestibule of the temple.

13. Now King Solomon sent and brought Huram from Tyre.

14. He was the son of a widow from the tribe of Naphtali, and his father was a man of Tyre, a bronze worker; he was filled with wisdom and understanding and skill in working with all kinds of bronze work. So he came to King Solomon and did all his work.

15. And he cast two pillars of bronze, each one eighteen cubits high, and a line of twelve cubits measured the circumference of each.

16. Then he made two capitals of cast bronze, to set on the tops of the pillars. The height of one capital was five cubits, and the height of the other capital was five cubits.

17. He made a lattice network, with wreaths of chainwork, for the capitals which were on top of the pillars: seven chains for one capital and seven for the other capital.

18. So he made the pillars, and two rows of pomegranates above the network all around to cover the capitals that were on top; and thus he did for the other capital.

19. The capitals which were on top of the pillars in the hall were in the shape of lilies, four cubits.

20. The capitals on the two pillars also had pomegranates above, by the convex surface which was next to the network; and there were two hundred such pomegranates in rows on each of the capitals all around.

21. Then he set up the pillars by the vestibule of the temple; he set up the pillar on the right and called its name Jachin, and he set up the pillar on the left and called its name Boaz.

22. The tops of the pillars were in the shape of lilies. So the work of the pillars was finished.

23. And he made the Sea of cast bronze, ten cubits from one brim to the other; it was completely round. Its height was five cubits, and a line of thirty cubits measured its circumference.

24. Below its brim were ornamental buds encircling it all around, ten to a cubit, all the way around the Sea. The ornamental buds were cast in two rows when it was cast.

25. It stood on twelve oxen: three looking toward the north, three looking toward the west, three looking toward the south, and three looking toward the east; the Sea was set upon them, and all their back parts pointed inward.

26. It was a handbreadth thick; and its brim was shaped like the brim of a cup, like a lily blossom. It contained two thousand baths.

27. He also made ten carts of bronze; four cubits was the length of each cart, four cubits its width, and three cubits its height.

28. And this was the design of the carts: They had panels, and the panels were between frames;

29. on the panels that were between the frames were lions, oxen, and cherubim. And on the frames was a pedestal on top. Below the lions and oxen were wreaths of plaited work.

30. Every cart had four bronze wheels and axles of bronze, and its four feet had supports. Under the laver were supports of cast bronze beside each wreath.

31. Its opening inside the crown at the top was one cubit in diameter; and the opening was round, shaped like a pedestal, one and a half cubits in outside diameter; and also on the opening were engravings, but the panels were square, not round.

32. Under the panels were the four wheels, and the axles of the wheels were joined to the cart. The height of a wheel was one and a half cubits.

33. The workmanship of the wheels was like the workmanship of a chariot wheel; their axle pins, their rims, their spokes, and their hubs were all of cast bronze.

34. And there were four supports at the four corners of each cart; its supports were part of the cart itself.

35. On the top of the cart, at the height of half a cubit, it was perfectly round. And on the top of the cart, its flanges and its panels were of the same casting.

36. On the plates of its flanges and on its panels he engraved cherubim, lions, and palm trees, wherever there was a clear space on each, with wreaths all around.

37. Thus he made the ten carts. All of them were of the same mold, one measure, and one shape.

38. Then he made ten lavers of bronze; each laver contained forty baths, and each laver was four cubits. On each of the ten carts was a laver.

39. And he put five carts on the right side of the house, and five on the left side of the house. He set the Sea on the right side of the house, toward the southeast.

40. Huram made the lavers and the shovels and the bowls. So Huram finished doing all the work that he was to do for King Solomon for the house of the LORD:

41. the two pillars, the two bowl-shaped capitals that were on top of the two pillars; the two networks covering the two bowl-shaped capitals which were on top of the pillars;

42. four hundred pomegranates for the two networks (two rows of pomegranates for each network, to cover the two bowl-shaped capitals that were on top of the pillars);

43. the ten carts, and ten lavers on the carts;

44. one Sea, and twelve oxen under the Sea;

45. the pots, the shovels, and the bowls. All these articles which Huram made for King Solomon for the house of the LORD were of burnished bronze.

46. In the plain of Jordan the king had them cast in clay molds, between Succoth and Zaretan.

47. And Solomon did not weigh all the articles, because there were so many; the weight of the bronze was not determined.

48. Thus Solomon had all the furnishings made for the house of the LORD: the altar of gold, and the table of gold on which was the showbread;

49. the lampstands of pure gold, five on the right side and five on the left in front of the inner sanctuary, with the flowers and the lamps and the wick-trimmers of gold;

50. the basins, the trimmers, the bowls, the ladles, and the censers of pure gold; and the hinges of gold, both for the doors of the inner room (the Most Holy Place) and for the doors of the main hall of the temple.

51. So all the work that King Solomon had done for the house of the LORD was finished; and Solomon brought in the things which his father David had dedicated: the silver and the gold and the furnishings. He put them in the treasuries of the house of the LORD.

## Chapter 8

1. Now Solomon assembled the elders of Israel and all the heads of the tribes, the chief fathers of the children of Israel, to King Solomon in Jerusalem, that they might bring up the ark of the covenant of the LORD from the City of David, which is Zion.

2. Therefore all the men of Israel assembled with King Solomon at the feast in the month of Ethanim, which is the seventh month.

3. So all the elders of Israel came, and the priests took up the ark.

4. Then they brought up the ark of the LORD, the tabernacle of meeting, and all the holy furnishings that were in the tabernacle. The priests and the Levites brought them up.

5. Also King Solomon, and all the congregation of Israel who were assembled with him, were with him before the ark, sacrificing sheep and oxen that could not be counted or numbered for multitude.

6. Then the priests brought in the ark of the covenant of the LORD to its place, into the inner sanctuary of the temple, to the Most Holy Place, under the wings of the cherubim.

7. For the cherubim spread their two wings over the place of the ark, and the cherubim overshadowed the ark and its poles.

8. The poles extended so that the ends of the poles could be seen from the holy place, in front of the inner sanctuary; but they could not be seen from outside. And they are there to this day.

9. Nothing was in the ark except the two tablets of stone which Moses put there at Horeb, when the LORD made a covenant with the children of Israel, when they came out of the land of Egypt.

10. And it came to pass, when the priests came out of the holy place, that the cloud filled the house of the LORD,

11. so that the priests could not continue ministering because of the cloud; for the glory of the LORD filled the house of the LORD.

12. Then Solomon spoke: "The LORD said He would dwell in the dark cloud.

13. I have surely built You an exalted house, And a place for You to dwell in forever."

14. Then the king turned around and blessed the whole assembly of Israel, while all the assembly of Israel was standing.

15. And he said: "Blessed be the LORD God of Israel, who spoke with His mouth to my father David, and with His hand has fulfilled it, saying,

16. "Since the day that I brought My people Israel out of Egypt, I have chosen no city from any tribe of Israel in which to build a house, that My name might be there; but I chose David to be over My people Israel.'

17. Now it was in the heart of my father David to build a temple for the name of the LORD God of Israel.

18. But the LORD said to my father David, "Whereas it was in your heart to build a temple for My name, you did well that it was in your heart.

19. Nevertheless you shall not build the temple, but your son who will come from your body, he shall build the temple for My name.'

20. So the LORD has fulfilled His word which He spoke; and I have filled the position of my father David, and sit on the throne of Israel, as the LORD promised; and I have built a temple for the name of the LORD God of Israel.

21. And there I have made a place for the ark, in which is the covenant of the LORD which He made with our fathers, when He brought them out of the land of Egypt."

22. Then Solomon stood before the altar of the LORD in the presence of all the assembly of Israel, and spread out his hands toward heaven;

23. and he said: "LORD God of Israel, there is no God in heaven above or on earth below like You, who keep Your covenant and mercy with Your servants who walk before You with all their hearts.

24. You have kept what You promised Your servant David my father; You have both spoken with Your mouth and fulfilled it with Your hand, as it is this day.

25. Therefore, LORD God of Israel, now keep what You promised Your servant David my father, saying, "You shall not fail to have a man sit before Me on the throne of Israel, only if your sons take heed to their way, that they walk before Me as you have walked before Me.'

26. And now I pray, O God of Israel, let Your word come true, which You have spoken to Your servant David my father.

27. "But will God indeed dwell on the earth? Behold, heaven and the heaven of heavens cannot contain You. How much less this temple which I have built!

28. Yet regard the prayer of Your servant and his supplication, O LORD my God, and listen to the cry and the prayer which Your servant is praying before You today:

29. that Your eyes may be open toward this temple night and day, toward the place of which You said, "My name shall be there,' that You may hear the prayer which Your servant makes toward this place.

30. And may You hear the supplication of Your servant and of Your people Israel, when they pray toward this place. Hear in heaven Your dwelling place; and when You hear, forgive.

31. "When anyone sins against his neighbor, and is forced to take an oath, and comes and takes an oath before Your altar in this temple,

32. then hear in heaven, and act, and judge Your servants, condemning the wicked, bringing his way on his head, and justifying the righteous by giving him according to his righteousness.

33. "When Your people Israel are defeated before an enemy because they have sinned against You, and when they turn back to You and confess Your name, and pray and make supplication to You in this temple,

34. then hear in heaven, and forgive the sin of Your people Israel, and bring them back to the land which You gave to their fathers.

35. "When the heavens are shut up and there is no rain because they have sinned against You, when they pray toward this place and confess Your name, and turn from their sin because You afflict them,

36. then hear in heaven, and forgive the sin of Your servants, Your people Israel, that You may teach them the good way in which they should walk; and send rain on Your land which You have given to Your people as an inheritance.

37. "When there is famine in the land, pestilence or blight or mildew, locusts or grasshoppers; when their enemy besieges them in the land of their cities; whatever plague or whatever sickness there is;

38. whatever prayer, whatever supplication is made by anyone, or by all Your people Israel, when each one knows the plague of his own heart, and spreads out his hands toward this temple:

39. then hear in heaven Your dwelling place, and forgive, and act, and give to everyone according to all his ways, whose heart You know (for You alone know the hearts of all the sons of men),

40. that they may fear You all the days that they live in the land which You gave to our fathers.

41. "Moreover, concerning a foreigner, who is not of Your people Israel, but has come from a far country for Your name's sake

42. (for they will hear of Your great name and Your strong hand and Your outstretched arm), when he comes and prays toward this temple,

43. hear in heaven Your dwelling place, and do according to all for which the foreigner calls to You, that all peoples of the earth may know Your name and fear You, as do Your people Israel, and that they may know that this temple which I have built is called by Your name.

44. "When Your people go out to battle against their enemy, wherever You send them, and when they pray to the LORD toward the city which You have chosen and the temple which I have built for Your name,

45. then hear in heaven their prayer and their supplication, and maintain their cause.

46. "When they sin against You (for there is no one who does not sin), and You become angry with them and deliver them to the enemy, and they take them captive to the land of the enemy, far or near;

47. yet when they come to themselves in the land where they were carried captive, and repent, and make supplication to You in the land of those who took them captive, saying, "We have sinned and done wrong, we have committed wickedness';

48. and when they return to You with all their heart and with all their soul in the land of their enemies who led them away captive, and pray to You toward their land which You gave to their fathers, the city which You have chosen and the temple which I have built for Your name:

49. then hear in heaven Your dwelling place their prayer and their supplication, and maintain their cause,

50. and forgive Your people who have sinned against You, and all their transgressions which they have transgressed against You; and grant them compassion before those who took them captive, that they may have compassion on them

51. (for they are Your people and Your inheritance, whom You brought out of Egypt, out of the iron furnace),

52. that Your eyes may be open to the supplication of Your servant and the supplication of Your people Israel, to listen to them whenever they call to You.

53. For You separated them from among all the peoples of the earth to be Your inheritance, as You spoke by Your servant Moses, when You brought our fathers out of Egypt, O Lord GOD."

54. And so it was, when Solomon had finished praying all this prayer and supplication to the LORD, that he arose from before the altar of the LORD, from kneeling on his knees with his hands spread up to heaven.

55. Then he stood and blessed all the assembly of Israel with a loud voice, saying:

56. "Blessed be the LORD, who has given rest to His people Israel, according to all that He promised. There has not failed one word of all His good promise, which He promised through His servant Moses.

57. May the LORD our God be with us, as He was with our fathers. May He not leave us nor forsake us,

58. that He may incline our hearts to Himself, to walk in all His ways, and to keep His commandments and His statutes and His judgments, which He commanded our fathers.

59. And may these words of mine, with which I have made supplication before the LORD, be near the LORD our God day and night, that He may maintain the cause of His servant and the cause of His people Israel, as each day may require,

60. that all the peoples of the earth may know that the LORD is God; there is no other.

61. Let your heart therefore be loyal to the LORD our God, to walk in His statutes and keep His commandments, as at this day."

62. Then the king and all Israel with him offered sacrifices before the LORD.

63. And Solomon offered a sacrifice of peace offerings, which he offered to the LORD, twenty-two thousand bulls and one hundred and twenty thousand sheep. So the king and all the children of Israel dedicated the house of the LORD.

64. On the same day the king consecrated the middle of the court that was in front of the house of the LORD; for there he offered burnt offerings, grain offerings, and the fat of the peace offerings, because the bronze altar that was before the LORD was too small to receive the burnt offerings, the grain offerings, and the fat of the peace offerings.

65. At that time Solomon held a feast, and all Israel with him, a great assembly from the entrance of Hamath to the Brook of Egypt, before the LORD our God, seven days and seven more days--fourteen days.

66. On the eighth day he sent the people away; and they blessed the king, and went to their tents joyful and glad of heart for all the good that the LORD had done for His servant David, and for Israel His people.

## Chapter 9

1. And it came to pass, when Solomon had finished building the house of the LORD and the king's house, and all Solomon's desire which he wanted to do,

2. that the LORD appeared to Solomon the second time, as He had appeared to him at Gibeon.

3. And the LORD said to him: "I have heard your prayer and your supplication that you have made before Me; I have consecrated this house which you have built to put My name there forever, and My eyes and My heart will be there perpetually.

4. Now if you walk before Me as your father David walked, in integrity of heart and in uprightness, to do according to all that I have commanded you, and if you keep My statutes and My judgments,

5. then I will establish the throne of your kingdom over Israel forever, as I promised David your father, saying, "You shall not fail to have a man on the throne of Israel.'

6. But if you or your sons at all turn from following Me, and do not keep My commandments and My statutes which I have set before you, but go and serve other gods and worship them,

7. then I will cut off Israel from the land which I have given them; and this house which I have consecrated for My name I will cast out of My sight. Israel will be a proverb and a byword among all peoples.

8. And as for this house, which is exalted, everyone who passes by it will be astonished and will hiss, and say, "Why has the LORD done thus to this land and to this house?'

9. Then they will answer, "Because they forsook the LORD their God, who brought their fathers out of the land of Egypt, and have embraced other gods, and worshiped them and served them; therefore the LORD has brought all this calamity on them."'

10. Now it happened at the end of twenty years, when Solomon had built the two houses, the house of the LORD and the king's house

11. (Hiram the king of Tyre had supplied Solomon with cedar and cypress and gold, as much as he desired), that King Solomon then gave Hiram twenty cities in the land of Galilee.

12. Then Hiram went from Tyre to see the cities which Solomon had given him, but they did not please him.

13. So he said, "What kind of cities are these which you have given me, my brother?" And he called them the land of Cabul, as they are to this day.

14. Then Hiram sent the king one hundred and twenty talents of gold.

15. And this is the reason for the labor force which King Solomon raised: to build the house of the LORD, his own house, the Millo, the wall of Jerusalem, Hazor, Megiddo, and Gezer.

16. (Pharaoh king of Egypt had gone up and taken Gezer and burned it with fire, had killed the Canaanites who dwelt in the city, and had given it as a dowry to his daughter, Solomon's wife.)

17. And Solomon built Gezer, Lower Beth Horon,

18. Baalath, and Tadmor in the wilderness, in the land of Judah,

19. all the storage cities that Solomon had, cities for his chariots and cities for his cavalry, and whatever Solomon desired to build in Jerusalem, in Lebanon, and in all the land of his dominion.

20. All the people who were left of the Amorites, Hittites, Perizzites, Hivites, and Jebusites, who were not of the children of Israel--

21. that is, their descendants who were left in the land after them, whom the children of Israel had not been able to destroy completely--from these Solomon raised forced labor, as it is to this day.

22. But of the children of Israel Solomon made no forced laborers, because they were men of war and his servants: his officers, his captains, commanders of his chariots, and his cavalry.

23. Others were chiefs of the officials who were over Solomon's work: five hundred and fifty, who ruled over the people who did the work.

24. But Pharaoh's daughter came up from the City of David to her house which Solomon had built for her. Then he built the Millo.

25. Now three times a year Solomon offered burnt offerings and peace offerings on the altar which he had built for the LORD, and he burned incense with them on the altar that was before the LORD. So he finished the temple.

26. King Solomon also built a fleet of ships at Ezion Geber, which is near Elath on the shore of the Red Sea, in the land of Edom.

27. Then Hiram sent his servants with the fleet, seamen who knew the sea, to work with the servants of Solomon.

28. And they went to Ophir, and acquired four hundred and twenty talents of gold from there, and brought it to King Solomon.

## Chapter 10

1. Now when the queen of Sheba heard of the fame of Solomon concerning the name of the LORD, she came to test him with hard questions.

2. She came to Jerusalem with a very great retinue, with camels that bore spices, very much gold, and precious stones; and when she came to Solomon, she spoke with him about all that was in her heart.

3. So Solomon answered all her questions; there was nothing so difficult for the king that he could not explain it to her.

4. And when the queen of Sheba had seen all the wisdom of Solomon, the house that he had built,

5. the food on his table, the seating of his servants, the service of his waiters and their apparel, his cupbearers, and his entryway by which he went up to the house of the LORD, there was no more spirit in her.

6. Then she said to the king: "It was a true report which I heard in my own land about your words and your wisdom.

7. However I did not believe the words until I came and saw with my own eyes; and indeed the half was not told me. Your wisdom and prosperity exceed the fame of which I heard.

8. Happy are your men and happy are these your servants, who stand continually before you and hear your wisdom!

9. Blessed be the LORD your God, who delighted in you, setting you on the throne of Israel! Because the LORD has loved Israel forever, therefore He made you king, to do justice and righteousness."

10. Then she gave the king one hundred and twenty talents of gold, spices in great quantity, and precious stones. There never again came such abundance of spices as the queen of Sheba gave to King Solomon.

11. Also, the ships of Hiram, which brought gold from Ophir, brought great quantities of almug wood and precious stones from Ophir.

12. And the king made steps of the almug wood for the house of the LORD and for the king's house, also harps and stringed instruments for singers. There never again came such almug wood, nor has the like been seen to this day.

13. Now King Solomon gave the queen of Sheba all she desired, whatever she asked, besides what Solomon had given her according to the royal generosity. So she turned and went to her own country, she and her servants.

14. The weight of gold that came to Solomon yearly was six hundred and sixty-six talents of gold,

15. besides that from the traveling merchants, from the income of traders, from all the kings of Arabia, and from the governors of the country.

16. And King Solomon made two hundred large shields of hammered gold; six hundred shekels of gold went into each shield.

17. He also made three hundred shields of hammered gold; three minas of gold went into each shield. The king put them in the House of the Forest of Lebanon.

18. Moreover the king made a great throne of ivory, and overlaid it with pure gold.

19. The throne had six steps, and the top of the throne was round at the back; there were armrests on either side of the place of the seat, and two lions stood beside the armrests.

20. Twelve lions stood there, one on each side of the six steps; nothing like this had been made for any other kingdom.

21. All King Solomon's drinking vessels were gold, and all the vessels of the House of the Forest of Lebanon were pure gold. Not one was silver, for this was accounted as nothing in the days of Solomon.

22. For the king had merchant ships at sea with the fleet of Hiram. Once every three years the merchant ships came bringing gold, silver, ivory, apes, and monkeys.

23. So King Solomon surpassed all the kings of the earth in riches and wisdom.

24. Now all the earth sought the presence of Solomon to hear his wisdom, which God had put in his heart.

25. Each man brought his present: articles of silver and gold, garments, armor, spices, horses, and mules, at a set rate year by year.

26. And Solomon gathered chariots and horsemen; he had one thousand four hundred chariots and twelve thousand horsemen, whom he stationed in the chariot cities and with the king at Jerusalem.

27. The king made silver as common in Jerusalem as stones, and he made cedar trees as abundant as the sycamores which are in the lowland.

28. Also Solomon had horses imported from Egypt and Keveh; the king's merchants bought them in Keveh at the current price.

29. Now a chariot that was imported from Egypt cost six hundred shekels of silver, and a horse one hundred and fifty; and thus, through their agents, they exported them to all the kings of the Hittites and the kings of Syria.

## Chapter 11

1. But King Solomon loved many foreign women, as well as the daughter of Pharaoh: women of the Moabites, Ammonites, Edomites, Sidonians, and Hittites--

2. from the nations of whom the LORD had said to the children of Israel, "You shall not intermarry with them, nor they with you. Surely they will turn away your hearts after their gods." Solomon clung to these in love.

3. And he had seven hundred wives, princesses, and three hundred concubines; and his wives turned away his heart.

4. For it was so, when Solomon was old, that his wives turned his heart after other gods; and his heart was not loyal to the LORD his God, as was the heart of his father David.

5. For Solomon went after Ashtoreth the goddess of the Sidonians, and after Milcom the abomination of the Ammonites.

6. Solomon did evil in the sight of the LORD, and did not fully follow the LORD, as did his father David.

7. Then Solomon built a high place for Chemosh the abomination of Moab, on the hill that is east of Jerusalem, and for Molech the abomination of the people of Ammon.

8. And he did likewise for all his foreign wives, who burned incense and sacrificed to their gods.

9. So the LORD became angry with Solomon, because his heart had turned from the LORD God of Israel, who had appeared to him twice,

10. and had commanded him concerning this thing, that he should not go after other gods; but he did not keep what the LORD had commanded.

11. Therefore the LORD said to Solomon, "Because you have done this, and have not kept My covenant and My statutes, which I have commanded you, I will surely tear the kingdom away from you and give it to your servant.

12. Nevertheless I will not do it in your days, for the sake of your father David; I will tear it out of the hand of your son.

13. However I will not tear away the whole kingdom; I will give one tribe to your son for the sake of My servant David, and for the sake of Jerusalem which I have chosen."

14. Now the LORD raised up an adversary against Solomon, Hadad the Edomite; he was a descendant of the king in Edom.

15. For it happened, when David was in Edom, and Joab the commander of the army had gone up to bury the slain, after he had killed every male in Edom

16. (because for six months Joab remained there with all Israel, until he had cut down every male in Edom),

17. that Hadad fled to go to Egypt, he and certain Edomites of his father's servants with him. Hadad was still a little child.

18. Then they arose from Midian and came to Paran; and they took men with them from Paran and came to Egypt, to Pharaoh king of Egypt, who gave him a house, apportioned food for him, and gave him land.

19. And Hadad found great favor in the sight of Pharaoh, so that he gave him as wife the sister of his own wife, that is, the sister of Queen Tahpenes.

20. Then the sister of Tahpenes bore him Genubath his son, whom Tahpenes weaned in Pharaoh's house. And Genubath was in Pharaoh's household among the sons of Pharaoh.

21. So when Hadad heard in Egypt that David rested with his fathers, and that Joab the commander of the army was dead, Hadad said to Pharaoh, "Let me depart, that I may go to my own country."

22. Then Pharaoh said to him, "But what have you lacked with me, that suddenly you seek to go to your own country?" So he answered, "Nothing, but do let me go anyway."

23. And God raised up another adversary against him, Rezon the son of Eliadah, who had fled from his lord, Hadadezer king of Zobah.

24. So he gathered men to him and became captain over a band of raiders, when David killed those of Zobah. And they went to Damascus and dwelt there, and reigned in Damascus.

25. He was an adversary of Israel all the days of Solomon (besides the trouble that Hadad caused); and he abhorred Israel, and reigned over Syria.

26. Then Solomon's servant, Jeroboam the son of Nebat, an Ephraimite from Zereda, whose mother's name was Zeruah, a widow, also rebelled against the king.

27. And this is what caused him to rebel against the king: Solomon had built the Millo and repaired the damages to the City of David his father.

28. The man Jeroboam was a mighty man of valor; and Solomon, seeing that the young man was industrious, made him the officer over all the labor force of the house of Joseph.

29. Now it happened at that time, when Jeroboam went out of Jerusalem, that the prophet Ahijah the Shilonite met him on the way; and he had clothed himself with a new garment, and the two were alone in the field.

30. Then Ahijah took hold of the new garment that was on him, and tore it into twelve pieces.

31. And he said to Jeroboam, "Take for yourself ten pieces, for thus says the LORD, the God of Israel: "Behold, I will tear the kingdom out of the hand of Solomon and will give ten tribes to you

32. (but he shall have one tribe for the sake of My servant David, and for the sake of Jerusalem, the city which I have chosen out of all the tribes of Israel),

33. because they have forsaken Me, and worshiped Ashtoreth the goddess of the Sidonians, Chemosh the god of the Moabites, and Milcom the god of the people of Ammon, and have not walked in My ways to do what is right in My eyes and keep My statutes and My judgments, as did his father David.

34. However I will not take the whole kingdom out of his hand, because I have made him ruler all the days of his life for the sake of My servant David, whom I chose because he kept My commandments and My statutes.

35. But I will take the kingdom out of his son's hand and give it to you--ten tribes.

36. And to his son I will give one tribe, that My servant David may always have a lamp before Me in Jerusalem, the city which I have chosen for Myself, to put My name there.

37. So I will take you, and you shall reign over all your heart desires, and you shall be king over Israel.

38. Then it shall be, if you heed all that I command you, walk in My ways, and do what is right in My sight, to keep My statutes and My commandments, as My servant David did, then I will be with you and build for you an enduring house, as I built for David, and will give Israel to you.

39. And I will afflict the descendants of David because of this, but not forever."'

40. Solomon therefore sought to kill Jeroboam. But Jeroboam arose and fled to Egypt, to Shishak king of Egypt, and was in Egypt until the death of Solomon.

41. Now the rest of the acts of Solomon, all that he did, and his wisdom, are they not written in the book of the acts of Solomon?

42. And the period that Solomon reigned in Jerusalem over all Israel was forty years.

43. Then Solomon rested with his fathers, and was buried in the City of David his father. And Rehoboam his son reigned in his place.

## Chapter 12

1. And Rehoboam went to Shechem, for all Israel had gone to Shechem to make him king.

2. So it happened, when Jeroboam the son of Nebat heard it (he was still in Egypt, for he had fled from the presence of King Solomon and had been dwelling in Egypt),

3. that they sent and called him. Then Jeroboam and the whole assembly of Israel came and spoke to Rehoboam, saying,

4. "Your father made our yoke heavy; now therefore, lighten the burdensome service of your father, and his heavy yoke which he put on us, and we will serve you."

5. So he said to them, "Depart for three days, then come back to me." And the people departed.

6. Then King Rehoboam consulted the elders who stood before his father Solomon while he still lived, and he said, "How do you advise me to answer these people?"

7. And they spoke to him, saying, "If you will be a servant to these people today, and serve them, and answer them, and speak good words to them, then they will be your servants forever."

8. But he rejected the advice which the elders had given him, and consulted the young men who had grown up with him, who stood before him.

9. And he said to them, "What advice do you give? How should we answer this people who have spoken to me, saying, "Lighten the yoke which your father put on us'?"

10. Then the young men who had grown up with him spoke to him, saying, "Thus you should speak to this people who have spoken to you, saying, "Your father made our yoke heavy, but you make it lighter on us'--thus you shall say to them: "My little finger shall be thicker than my father's waist!

11. And now, whereas my father put a heavy yoke on you, I will add to your yoke; my father chastised you with whips, but I will chastise you with scourges!"'

12. So Jeroboam and all the people came to Rehoboam the third day, as the king had directed, saying, "Come back to me the third day."

13. Then the king answered the people roughly, and rejected the advice which the elders had given him;

14. and he spoke to them according to the advice of the young men, saying, "My father made your yoke heavy, but I will add to your yoke; my father chastised you with whips, but I will chastise you with scourges!"

15. So the king did not listen to the people; for the turn of events was from the LORD, that He might fulfill His word, which the LORD had spoken by Ahijah the Shilonite to Jeroboam the son of Nebat.

16. Now when all Israel saw that the king did not listen to them, the people answered the king, saying: "What share have we in David? We have no inheritance in the son of Jesse. To your tents, O Israel! Now, see to your own house, O David!" So Israel departed to their tents.

17. But Rehoboam reigned over the children of Israel who dwelt in the cities of Judah.

18. Then King Rehoboam sent Adoram, who was in charge of the revenue; but all Israel stoned him with stones, and he died. Therefore King Rehoboam mounted his chariot in haste to flee to Jerusalem.

19. So Israel has been in rebellion against the house of David to this day.

20. Now it came to pass when all Israel heard that Jeroboam had come back, they sent for him and called him to the congregation, and made him king over all Israel. There was none who followed the house of David, but the tribe of Judah only.

21. And when Rehoboam came to Jerusalem, he assembled all the house of Judah with the tribe of Benjamin, one hundred and eighty thousand chosen men who were warriors, to fight against the house of Israel, that he might restore the kingdom to Rehoboam the son of Solomon.

22. But the word of God came to Shemaiah the man of God, saying,

23. "Speak to Rehoboam the son of Solomon, king of Judah, to all the house of Judah and Benjamin, and to the rest of the people, saying,

24. "Thus says the LORD: "You shall not go up nor fight against your brethren the children of Israel. Let every man return to his house, for this thing is from Me.""' Therefore they obeyed the word of the LORD, and turned back, according to the word of the LORD.

25. Then Jeroboam built Shechem in the mountains of Ephraim, and dwelt there. Also he went out from there and built Penuel.

26. And Jeroboam said in his heart, "Now the kingdom may return to the house of David:

27. If these people go up to offer sacrifices in the house of the LORD at Jerusalem, then the heart of this people will turn back to their lord, Rehoboam king of Judah, and they will kill me and go back to Rehoboam king of Judah."

28. Therefore the king asked advice, made two calves of gold, and said to the people, "It is too much for you to go up to Jerusalem. Here are your gods, O Israel, which brought you up from the land of Egypt!"

29. And he set up one in Bethel, and the other he put in Dan.

30. Now this thing became a sin, for the people went to worship before the one as far as Dan.

31. He made shrines on the high places, and made priests from every class of people, who were not of the sons of Levi.

32. Jeroboam ordained a feast on the fifteenth day of the eighth month, like the feast that was in Judah, and offered sacrifices on the altar. So he did at Bethel, sacrificing to the calves that he had made. And at Bethel he installed the priests of the high places which he had made.

33. So he made offerings on the altar which he had made at Bethel on the fifteenth day of the eighth month, in the month which he had devised in his own heart. And he ordained a feast for the children of Israel, and offered sacrifices on the altar and burned incense.

## Chapter 13

1. And behold, a man of God went from Judah to Bethel by the word of the LORD, and Jeroboam stood by the altar to burn incense.

2. Then he cried out against the altar by the word of the LORD, and said, "O altar, altar! Thus says the LORD: "Behold, a child, Josiah by name, shall be born to the house of David; and on you he shall sacrifice the priests of the high places who burn incense on you, and men's bones shall be burned on you."'

3. And he gave a sign the same day, saying, "This is the sign which the LORD has spoken: Surely the altar shall split apart, and the ashes on it shall be poured out."

4. So it came to pass when King Jeroboam heard the saying of the man of God, who cried out against the altar in Bethel, that he stretched out his hand from the altar, saying, "Arrest him!" Then his hand, which he stretched out toward him, withered, so that he could not pull it back to himself.

5. The altar also was split apart, and the ashes poured out from the altar, according to the sign which the man of God had given by the word of the LORD.

6. Then the king answered and said to the man of God, "Please entreat the favor of the LORD your God, and pray for me, that my hand may be restored to me." So the man of God entreated the LORD, and the king's hand was restored to him, and became as before.

7. Then the king said to the man of God, "Come home with me and refresh yourself, and I will give you a reward."

8. But the man of God said to the king, "If you were to give me half your house, I would not go in with you; nor would I eat bread nor drink water in this place.

9. For so it was commanded me by the word of the LORD, saying, "You shall not eat bread, nor drink water, nor return by the same way you came."'

10. So he went another way and did not return by the way he came to Bethel.

11. Now an old prophet dwelt in Bethel, and his sons came and told him all the works that the man of God had done that day in Bethel; they also told their father the words which he had spoken to the king.

12. And their father said to them, "Which way did he go?" For his sons had seen which way the man of God went who came from Judah.

13. Then he said to his sons, "Saddle the donkey for me." So they saddled the donkey for him; and he rode on it,

14. and went after the man of God, and found him sitting under an oak. Then he said to him, "Are you the man of God who came from Judah?" And he said, "I am."

15. Then he said to him, "Come home with me and eat bread."

16. And he said, "I cannot return with you nor go in with you; neither can I eat bread nor drink water with you in this place.

17. For I have been told by the word of the LORD, "You shall not eat bread nor drink water there, nor return by going the way you came."'

18. He said to him, "I too am a prophet as you are, and an angel spoke to me by the word of the LORD, saying, "Bring him back with you to your house, that he may eat bread and drink water."' (He was lying to him.)

19. So he went back with him, and ate bread in his house, and drank water.

20. Now it happened, as they sat at the table, that the word of the LORD came to the prophet who had brought him back;

21. and he cried out to the man of God who came from Judah, saying, "Thus says the LORD: "Because you have disobeyed the word of the LORD, and have not kept the commandment which the LORD your God commanded you,

22. but you came back, ate bread, and drank water in the place of which the LORD said to you, "Eat no bread and drink no water," your corpse shall not come to the tomb of your fathers."'

23. So it was, after he had eaten bread and after he had drunk, that he saddled the donkey for him, the prophet whom he had brought back.

24. When he was gone, a lion met him on the road and killed him. And his corpse was thrown on the road, and the donkey stood by it. The lion also stood by the corpse.

25. And there, men passed by and saw the corpse thrown on the road, and the lion standing by the corpse. Then they went and told it in the city where the old prophet dwelt.

26. Now when the prophet who had brought him back from the way heard it, he said, "It is the man of God who was disobedient to the word of the LORD. Therefore the LORD has delivered him to the lion, which has torn him and killed him, according to the word of the LORD which He spoke to him."

27. And he spoke to his sons, saying, "Saddle the donkey for me." So they saddled it.

28. Then he went and found his corpse thrown on the road, and the donkey and the lion standing by the corpse. The lion had not eaten the corpse nor torn the donkey.

29. And the prophet took up the corpse of the man of God, laid it on the donkey, and brought it back. So the old prophet came to the city to mourn, and to bury him.

30. Then he laid the corpse in his own tomb; and they mourned over him, saying, "Alas, my brother!"

31. So it was, after he had buried him, that he spoke to his sons, saying, "When I am dead, then bury me in the tomb where the man of God is buried; lay my bones beside his bones.

32. For the saying which he cried out by the word of the LORD against the altar in Bethel, and against all the shrines on the high places which are in the cities of Samaria, will surely come to pass."

33. After this event Jeroboam did not turn from his evil way, but again he made priests from every class of people for the high places; whoever wished, he consecrated him, and he became one of the priests of the high places.

34. And this thing was the sin of the house of Jeroboam, so as to exterminate and destroy it from the face of the earth.

## Chapter 14

1. At that time Abijah the son of Jeroboam became sick.

2. And Jeroboam said to his wife, "Please arise, and disguise yourself, that they may not recognize you as the wife of Jeroboam, and go to Shiloh. Indeed, Ahijah the prophet is there, who told me that I would be king over this people.

3. Also take with you ten loaves, some cakes, and a jar of honey, and go to him; he will tell you what will become of the child."

4. And Jeroboam's wife did so; she arose and went to Shiloh, and came to the house of Ahijah. But Ahijah could not see, for his eyes were glazed by reason of his age.

5. Now the LORD had said to Ahijah, "Here is the wife of Jeroboam, coming to ask you something about her son, for he is sick. Thus and thus you shall say to her; for it will be, when she comes in, that she will pretend to be another woman."

6. And so it was, when Ahijah heard the sound of her footsteps as she came through the door, he said, "Come in, wife of Jeroboam. Why do you pretend to be another person? For I have been sent to you with bad news.

7. Go, tell Jeroboam, "Thus says the LORD God of Israel: "Because I exalted you from among the people, and made you ruler over My people Israel,

8. and tore the kingdom away from the house of David, and gave it to you; and yet you have not been as My servant David, who kept My commandments and who followed Me with all his heart, to do only what was right in My eyes;

9. but you have done more evil than all who were before you, for you have gone and made for yourself other gods and molded images to provoke Me to anger, and have cast Me behind your back--

10. therefore behold! I will bring disaster on the house of Jeroboam, and will cut off from Jeroboam every male in Israel, bond and free; I will take away the remnant of the house of Jeroboam, as one takes away refuse until it is all gone.

11. The dogs shall eat whoever belongs to Jeroboam and dies in the city, and the birds of the air shall eat whoever dies in the field; for the LORD has spoken!"'

12. Arise therefore, go to your own house. When your feet enter the city, the child shall die.

13. And all Israel shall mourn for him and bury him, for he is the only one of Jeroboam who shall come to the grave, because in him there is found something good toward the LORD God of Israel in the house of Jeroboam.

14. "Moreover the LORD will raise up for Himself a king over Israel who shall cut off the house of Jeroboam; this is the day. What? Even now!

15. For the LORD will strike Israel, as a reed is shaken in the water. He will uproot Israel from this good land which He gave to their fathers, and will scatter them beyond the River, because they have made their wooden images, provoking the LORD to anger.

16. And He will give Israel up because of the sins of Jeroboam, who sinned and who made Israel sin."

17. Then Jeroboam's wife arose and departed, and came to Tirzah. When she came to the threshold of the house, the child died.

18. And they buried him; and all Israel mourned for him, according to the word of the LORD which He spoke through His servant Ahijah the prophet.

19. Now the rest of the acts of Jeroboam, how he made war and how he reigned, indeed they are written in the book of the chronicles of the kings of Israel.

20. The period that Jeroboam reigned was twenty-two years. So he rested with his fathers. Then Nadab his son reigned in his place.

21. And Rehoboam the son of Solomon reigned in Judah. Rehoboam was forty-one years old when he became king. He reigned seventeen years in Jerusalem, the city which the LORD had chosen out of all the tribes of Israel, to put His name there. His mother's name was Naamah, an Ammonitess.

22. Now Judah did evil in the sight of the LORD, and they provoked Him to jealousy with their sins which they committed, more than all that their fathers had done.

23. For they also built for themselves high places, sacred pillars, and wooden images on every high hill and under every green tree.

24. And there were also perverted persons in the land. They did according to all the abominations of the nations which the LORD had cast out before the children of Israel.

25. It happened in the fifth year of King Rehoboam that Shishak king of Egypt came up against Jerusalem.

26. And he took away the treasures of the house of the LORD and the treasures of the king's house; he took away everything. He also took away all the gold shields which Solomon had made.

27. Then King Rehoboam made bronze shields in their place, and committed them to the hands of the captains of the guard, who guarded the doorway of the king's house.

28. And whenever the king entered the house of the LORD, the guards carried them, then brought them back into the guardroom.

29. Now the rest of the acts of Rehoboam, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

30. And there was war between Rehoboam and Jeroboam all their days.

31. So Rehoboam rested with his fathers, and was buried with his fathers in the City of David. His mother's name was Naamah, an Ammonitess. Then Abijam his son reigned in his place.

## Chapter 15

1. In the eighteenth year of King Jeroboam the son of Nebat, Abijam became king over Judah.

2. He reigned three years in Jerusalem. His mother's name was Maachah the granddaughter of Abishalom.

3. And he walked in all the sins of his father, which he had done before him; his heart was not loyal to the LORD his God, as was the heart of his father David.

4. Nevertheless for David's sake the LORD his God gave him a lamp in Jerusalem, by setting up his son after him and by establishing Jerusalem;

5. because David did what was right in the eyes of the LORD, and had not turned aside from anything that He commanded him all the days of his life, except in the matter of Uriah the Hittite.

6. And there was war between Rehoboam and Jeroboam all the days of his life.

7. Now the rest of the acts of Abijam, and all that he did, are they not written in the book of the chronicles of the kings of Judah? And there was war between Abijam and Jeroboam.

8. So Abijam rested with his fathers, and they buried him in the City of David. Then Asa his son reigned in his place.

9. In the twentieth year of Jeroboam king of Israel, Asa became king over Judah.

10. And he reigned forty-one years in Jerusalem. His grandmother's name was Maachah the granddaughter of Abishalom.

11. Asa did what was right in the eyes of the LORD, as did his father David.

12. And he banished the perverted persons from the land, and removed all the idols that his fathers had made.

13. Also he removed Maachah his grandmother from being queen mother, because she had made an obscene image of Asherah. And Asa cut down her obscene image and burned it by the Brook Kidron.

14. But the high places were not removed. Nevertheless Asa's heart was loyal to the LORD all his days.

15. He also brought into the house of the LORD the things which his father had dedicated, and the things which he himself had dedicated: silver and gold and utensils.

16. Now there was war between Asa and Baasha king of Israel all their days.

17. And Baasha king of Israel came up against Judah, and built Ramah, that he might let none go out or come in to Asa king of Judah.

18. Then Asa took all the silver and gold that was left in the treasuries of the house of the LORD and the treasuries of the king's house, and delivered them into the hand of his servants. And King Asa sent them to Ben-Hadad the son of Tabrimmon, the son of Hezion, king of Syria, who dwelt in Damascus, saying,

19. "Let there be a treaty between you and me, as there was between my father and your father. See, I have sent you a present of silver and gold. Come and break your treaty with Baasha king of Israel, so that he will withdraw from me."

20. So Ben-Hadad heeded King Asa, and sent the captains of his armies against the cities of Israel. He attacked Ijon, Dan, Abel Beth Maachah, and all Chinneroth, with all the land of Naphtali.

21. Now it happened, when Baasha heard it, that he stopped building Ramah, and remained in Tirzah.

22. Then King Asa made a proclamation throughout all Judah; none was exempted. And they took away the stones and timber of Ramah, which Baasha had used for building; and with them King Asa built Geba of Benjamin, and Mizpah.

23. The rest of all the acts of Asa, all his might, all that he did, and the cities which he built, are they not written in the book of the chronicles of the kings of Judah? But in the time of his old age he was diseased in his feet.

24. So Asa rested with his fathers, and was buried with his fathers in the City of David his father. Then Jehoshaphat his son reigned in his place.

25. Now Nadab the son of Jeroboam became king over Israel in the second year of Asa king of Judah, and he reigned over Israel two years.

26. And he did evil in the sight of the LORD, and walked in the way of his father, and in his sin by which he had made Israel sin.

27. Then Baasha the son of Ahijah, of the house of Issachar, conspired against him. And Baasha killed him at Gibbethon, which belonged to the Philistines, while Nadab and all Israel laid siege to Gibbethon.

28. Baasha killed him in the third year of Asa king of Judah, and reigned in his place.

29. And it was so, when he became king, that he killed all the house of Jeroboam. He did not leave to Jeroboam anyone that breathed, until he had destroyed him, according to the word of the LORD which He had spoken by His servant Ahijah the Shilonite,

30. because of the sins of Jeroboam, which he had sinned and by which he had made Israel sin, because of his provocation with which he had provoked the LORD God of Israel to anger.

31. Now the rest of the acts of Nadab, and all that he did, are they not written in the book of the chronicles of the kings of Israel?

32. And there was war between Asa and Baasha king of Israel all their days.

33. In the third year of Asa king of Judah, Baasha the son of Ahijah became king over all Israel in Tirzah, and reigned twenty-four years.

34. He did evil in the sight of the LORD, and walked in the way of Jeroboam, and in his sin by which he had made Israel sin.

## Chapter 16

1. Then the word of the LORD came to Jehu the son of Hanani, against Baasha, saying:

2. "Inasmuch as I lifted you out of the dust and made you ruler over My people Israel, and you have walked in the way of Jeroboam, and have made My people Israel sin, to provoke Me to anger with their sins,

3. surely I will take away the posterity of Baasha and the posterity of his house, and I will make your house like the house of Jeroboam the son of Nebat.

4. The dogs shall eat whoever belongs to Baasha and dies in the city, and the birds of the air shall eat whoever dies in the fields."

5. Now the rest of the acts of Baasha, what he did, and his might, are they not written in the book of the chronicles of the kings of Israel?

6. So Baasha rested with his fathers and was buried in Tirzah. Then Elah his son reigned in his place.

7. And also the word of the LORD came by the prophet Jehu the son of Hanani against Baasha and his house, because of all the evil that he did in the sight of the LORD in provoking Him to anger with the work of his hands, in being like the house of Jeroboam, and because he killed them.

8. In the twenty-sixth year of Asa king of Judah, Elah the son of Baasha became king over Israel, and reigned two years in Tirzah.

9. Now his servant Zimri, commander of half his chariots, conspired against him as he was in Tirzah drinking himself drunk in the house of Arza, steward of his house in Tirzah.

10. And Zimri went in and struck him and killed him in the twenty-seventh year of Asa king of Judah, and reigned in his place.

11. Then it came to pass, when he began to reign, as soon as he was seated on his throne, that he killed all the household of Baasha; he did not leave him one male, neither of his relatives nor of his friends.

12. Thus Zimri destroyed all the household of Baasha, according to the word of the LORD, which He spoke against Baasha by Jehu the prophet,

13. for all the sins of Baasha and the sins of Elah his son, by which they had sinned and by which they had made Israel sin, in provoking the LORD God of Israel to anger with their idols.

14. Now the rest of the acts of Elah, and all that he did, are they not written in the book of the chronicles of the kings of Israel?

15. In the twenty-seventh year of Asa king of Judah, Zimri had reigned in Tirzah seven days. And the people were encamped against Gibbethon, which belonged to the Philistines.

16. Now the people who were encamped heard it said, "Zimri has conspired and also has killed the king." So all Israel made Omri, the commander of the army, king over Israel that day in the camp.

17. Then Omri and all Israel with him went up from Gibbethon, and they besieged Tirzah.

18. And it happened, when Zimri saw that the city was taken, that he went into the citadel of the king's house and burned the king's house down upon himself with fire, and died,

19. because of the sins which he had committed in doing evil in the sight of the LORD, in walking in the way of Jeroboam, and in his sin which he had committed to make Israel sin.

20. Now the rest of the acts of Zimri, and the treason he committed, are they not written in the book of the chronicles of the kings of Israel?

21. Then the people of Israel were divided into two parts: half of the people followed Tibni the son of Ginath, to make him king, and half followed Omri.

22. But the people who followed Omri prevailed over the people who followed Tibni the son of Ginath. So Tibni died and Omri reigned.

23. In the thirty-first year of Asa king of Judah, Omri became king over Israel, and reigned twelve years. Six years he reigned in Tirzah.

24. And he bought the hill of Samaria from Shemer for two talents of silver; then he built on the hill, and called the name of the city which he built, Samaria, after the name of Shemer, owner of the hill.

25. Omri did evil in the eyes of the LORD, and did worse than all who were before him.

26. For he walked in all the ways of Jeroboam the son of Nebat, and in his sin by which he had made Israel sin, provoking the LORD God of Israel to anger with their idols.

27. Now the rest of the acts of Omri which he did, and the might that he showed, are they not written in the book of the chronicles of the kings of Israel?

28. So Omri rested with his fathers and was buried in Samaria. Then Ahab his son reigned in his place.

29. In the thirty-eighth year of Asa king of Judah, Ahab the son of Omri became king over Israel; and Ahab the son of Omri reigned over Israel in Samaria twenty-two years.

30. Now Ahab the son of Omri did evil in the sight of the LORD, more than all who were before him.

31. And it came to pass, as though it had been a trivial thing for him to walk in the sins of Jeroboam the son of Nebat, that he took as wife Jezebel the daughter of Ethbaal, king of the Sidonians; and he went and served Baal and worshiped him.

32. Then he set up an altar for Baal in the temple of Baal, which he had built in Samaria.

33. And Ahab made a wooden image. Ahab did more to provoke the LORD God of Israel to anger than all the kings of Israel who were before him.

34. In his days Hiel of Bethel built Jericho. He laid its foundation with Abiram his firstborn, and with his youngest son Segub he set up its gates, according to the word of the LORD, which He had spoken through Joshua the son of Nun.

## Chapter 17

1. And Elijah the Tishbite, of the inhabitants of Gilead, said to Ahab, "As the LORD God of Israel lives, before whom I stand, there shall not be dew nor rain these years, except at my word."

2. Then the word of the LORD came to him, saying,

3. "Get away from here and turn eastward, and hide by the Brook Cherith, which flows into the Jordan.

4. And it will be that you shall drink from the brook, and I have commanded the ravens to feed you there."

5. So he went and did according to the word of the LORD, for he went and stayed by the Brook Cherith, which flows into the Jordan.

6. The ravens brought him bread and meat in the morning, and bread and meat in the evening; and he drank from the brook.

7. And it happened after a while that the brook dried up, because there had been no rain in the land.

8. Then the word of the LORD came to him, saying,

9. "Arise, go to Zarephath, which belongs to Sidon, and dwell there. See, I have commanded a widow there to provide for you."

10. So he arose and went to Zarephath. And when he came to the gate of the city, indeed a widow was there gathering sticks. And he called to her and said, "Please bring me a little water in a cup, that I may drink."

11. And as she was going to get it, he called to her and said, "Please bring me a morsel of bread in your hand."

12. So she said, "As the LORD your God lives, I do not have bread, only a handful of flour in a bin, and a little oil in a jar; and see, I am gathering a couple of sticks that I may go in and prepare it for myself and my son, that we may eat it, and die."

13. And Elijah said to her, "Do not fear; go and do as you have said, but make me a small cake from it first, and bring it to me; and afterward make some for yourself and your son.

14. For thus says the LORD God of Israel: "The bin of flour shall not be used up, nor shall the jar of oil run dry, until the day the LORD sends rain on the earth."'

15. So she went away and did according to the word of Elijah; and she and he and her household ate for many days.

16. The bin of flour was not used up, nor did the jar of oil run dry, according to the word of the LORD which He spoke by Elijah.

17. Now it happened after these things that the son of the woman who owned the house became sick. And his sickness was so serious that there was no breath left in him.

18. So she said to Elijah, "What have I to do with you, O man of God? Have you come to me to bring my sin to remembrance, and to kill my son?"

19. And he said to her, "Give me your son." So he took him out of her arms and carried him to the upper room where he was staying, and laid him on his own bed.

20. Then he cried out to the LORD and said, "O LORD my God, have You also brought tragedy on the widow with whom I lodge, by killing her son?"

21. And he stretched himself out on the child three times, and cried out to the LORD and said, "O LORD my God, I pray, let this child's soul come back to him."

22. Then the LORD heard the voice of Elijah; and the soul of the child came back to him, and he revived.

23. And Elijah took the child and brought him down from the upper room into the house, and gave him to his mother. And Elijah said, "See, your son lives!"

24. Then the woman said to Elijah, "Now by this I know that you are a man of God, and that the word of the LORD in your mouth is the truth."

## Chapter 18

1. And it came to pass after many days that the word of the LORD came to Elijah, in the third year, saying, "Go, present yourself to Ahab, and I will send rain on the earth."

2. So Elijah went to present himself to Ahab; and there was a severe famine in Samaria.

3. And Ahab had called Obadiah, who was in charge of his house. (Now Obadiah feared the LORD greatly.

4. For so it was, while Jezebel massacred the prophets of the LORD, that Obadiah had taken one hundred prophets and hidden them, fifty to a cave, and had fed them with bread and water.)

5. And Ahab had said to Obadiah, "Go into the land to all the springs of water and to all the brooks; perhaps we may find grass to keep the horses and mules alive, so that we will not have to kill any livestock."

6. So they divided the land between them to explore it; Ahab went one way by himself, and Obadiah went another way by himself.

7. Now as Obadiah was on his way, suddenly Elijah met him; and he recognized him, and fell on his face, and said, "Is that you, my lord Elijah?"

8. And he answered him, "It is I. Go, tell your master, "Elijah is here."'

9. So he said, "How have I sinned, that you are delivering your servant into the hand of Ahab, to kill me?

10. As the LORD your God lives, there is no nation or kingdom where my master has not sent someone to hunt for you; and when they said, "He is not here,' he took an oath from the kingdom or nation that they could not find you.

11. And now you say, "Go, tell your master, "Elijah is here"'!

12. And it shall come to pass, as soon as I am gone from you, that the Spirit of the LORD will carry you to a place I do not know; so when I go and tell Ahab, and he cannot find you, he will kill me. But I your servant have feared the LORD from my youth.

13. Was it not reported to my lord what I did when Jezebel killed the prophets of the LORD, how I hid one hundred men of the LORD's prophets, fifty to a cave, and fed them with bread and water?

14. And now you say, "Go, tell your master, "Elijah is here."' He will kill me!"

15. Then Elijah said, "As the LORD of hosts lives, before whom I stand, I will surely present myself to him today."

16. So Obadiah went to meet Ahab, and told him; and Ahab went to meet Elijah.

17. Then it happened, when Ahab saw Elijah, that Ahab said to him, "Is that you, O troubler of Israel?"

18. And he answered, "I have not troubled Israel, but you and your father's house have, in that you have forsaken the commandments of the LORD and have followed the Baals.

19. Now therefore, send and gather all Israel to me on Mount Carmel, the four hundred and fifty prophets of Baal, and the four hundred prophets of Asherah, who eat at Jezebel's table."

20. So Ahab sent for all the children of Israel, and gathered the prophets together on Mount Carmel.

21. And Elijah came to all the people, and said, "How long will you falter between two opinions? If the LORD is God, follow Him; but if Baal, follow him." But the people answered him not a word.

22. Then Elijah said to the people, "I alone am left a prophet of the LORD; but Baal's prophets are four hundred and fifty men.

23. Therefore let them give us two bulls; and let them choose one bull for themselves, cut it in pieces, and lay it on the wood, but put no fire under it; and I will prepare the other bull, and lay it on the wood, but put no fire under it.

24. Then you call on the name of your gods, and I will call on the name of the LORD; and the God who answers by fire, He is God." So all the people answered and said, "It is well spoken."

25. Now Elijah said to the prophets of Baal, "Choose one bull for yourselves and prepare it first, for you are many; and call on the name of your god, but put no fire under it."

26. So they took the bull which was given them, and they prepared it, and called on the name of Baal from morning even till noon, saying, "O Baal, hear us!" But there was no voice; no one answered. Then they leaped about the altar which they had made.

27. And so it was, at noon, that Elijah mocked them and said, "Cry aloud, for he is a god; either he is meditating, or he is busy, or he is on a journey, or perhaps he is sleeping and must be awakened."

28. So they cried aloud, and cut themselves, as was their custom, with knives and lances, until the blood gushed out on them.

29. And when midday was past, they prophesied until the time of the offering of the evening sacrifice. But there was no voice; no one answered, no one paid attention.

30. Then Elijah said to all the people, "Come near to me." So all the people came near to him. And he repaired the altar of the LORD that was broken down.

31. And Elijah took twelve stones, according to the number of the tribes of the sons of Jacob, to whom the word of the LORD had come, saying, "Israel shall be your name."

32. Then with the stones he built an altar in the name of the LORD; and he made a trench around the altar large enough to hold two seahs of seed.

33. And he put the wood in order, cut the bull in pieces, and laid it on the wood, and said, "Fill four waterpots with water, and pour it on the burnt sacrifice and on the wood."

34. Then he said, "Do it a second time," and they did it a second time; and he said, "Do it a third time," and they did it a third time.

35. So the water ran all around the altar; and he also filled the trench with water.

36. And it came to pass, at the time of the offering of the evening sacrifice, that Elijah the prophet came near and said, "LORD God of Abraham, Isaac, and Israel, let it be known this day that You are God in Israel and I am Your servant, and that I have done all these things at Your word.

37. Hear me, O LORD, hear me, that this people may know that You are the LORD God, and that You have turned their hearts back to You again."

38. Then the fire of the LORD fell and consumed the burnt sacrifice, and the wood and the stones and the dust, and it licked up the water that was in the trench.

39. Now when all the people saw it, they fell on their faces; and they said, "The LORD, He is God! The LORD, He is God!"

40. And Elijah said to them, "Seize the prophets of Baal! Do not let one of them escape!" So they seized them; and Elijah brought them down to the Brook Kishon and executed them there.

41. Then Elijah said to Ahab, "Go up, eat and drink; for there is the sound of abundance of rain."

42. So Ahab went up to eat and drink. And Elijah went up to the top of Carmel; then he bowed down on the ground, and put his face between his knees,

43. and said to his servant, "Go up now, look toward the sea." So he went up and looked, and said, "There is nothing." And seven times he said, "Go again."

44. Then it came to pass the seventh time, that he said, "There is a cloud, as small as a man's hand, rising out of the sea!" So he said, "Go up, say to Ahab, "Prepare your chariot, and go down before the rain stops you."'

45. Now it happened in the meantime that the sky became black with clouds and wind, and there was a heavy rain. So Ahab rode away and went to Jezreel.

46. Then the hand of the LORD came upon Elijah; and he girded up his loins and ran ahead of Ahab to the entrance of Jezreel.

## Chapter 19

1. And Ahab told Jezebel all that Elijah had done, also how he had executed all the prophets with the sword.

2. Then Jezebel sent a messenger to Elijah, saying, "So let the gods do to me, and more also, if I do not make your life as the life of one of them by tomorrow about this time."

3. And when he saw that, he arose and ran for his life, and went to Beersheba, which belongs to Judah, and left his servant there.

4. But he himself went a day's journey into the wilderness, and came and sat down under a broom tree. And he prayed that he might die, and said, "It is enough! Now, LORD, take my life, for I am no better than my fathers!"

5. Then as he lay and slept under a broom tree, suddenly an angel touched him, and said to him, "Arise and eat."

6. Then he looked, and there by his head was a cake baked on coals, and a jar of water. So he ate and drank, and lay down again.

7. And the angel of the LORD came back the second time, and touched him, and said, "Arise and eat, because the journey is too great for you."

8. So he arose, and ate and drank; and he went in the strength of that food forty days and forty nights as far as Horeb, the mountain of God.

9. And there he went into a cave, and spent the night in that place; and behold, the word of the LORD came to him, and He said to him, "What are you doing here, Elijah?"

10. So he said, "I have been very zealous for the LORD God of hosts; for the children of Israel have forsaken Your covenant, torn down Your altars, and killed Your prophets with the sword. I alone am left; and they seek to take my life."

11. Then He said, "Go out, and stand on the mountain before the LORD." And behold, the LORD passed by, and a great and strong wind tore into the mountains and broke the rocks in pieces before the LORD, but the LORD was not in the wind; and after the wind an earthquake, but the LORD was not in the earthquake;

12. and after the earthquake a fire, but the LORD was not in the fire; and after the fire a still small voice.

13. So it was, when Elijah heard it, that he wrapped his face in his mantle and went out and stood in the entrance of the cave. Suddenly a voice came to him, and said, "What are you doing here, Elijah?"

14. And he said, "I have been very zealous for the LORD God of hosts; because the children of Israel have forsaken Your covenant, torn down Your altars, and killed Your prophets with the sword. I alone am left; and they seek to take my life."

15. Then the LORD said to him: "Go, return on your way to the Wilderness of Damascus; and when you arrive, anoint Hazael as king over Syria.

16. Also you shall anoint Jehu the son of Nimshi as king over Israel. And Elisha the son of Shaphat of Abel Meholah you shall anoint as prophet in your place.

17. It shall be that whoever escapes the sword of Hazael, Jehu will kill; and whoever escapes the sword of Jehu, Elisha will kill.

18. Yet I have reserved seven thousand in Israel, all whose knees have not bowed to Baal, and every mouth that has not kissed him."

19. So he departed from there, and found Elisha the son of Shaphat, who was plowing with twelve yoke of oxen before him, and he was with the twelfth. Then Elijah passed by him and threw his mantle on him.

20. And he left the oxen and ran after Elijah, and said, "Please let me kiss my father and my mother, and then I will follow you." And he said to him, "Go back again, for what have I done to you?"

21. So Elisha turned back from him, and took a yoke of oxen and slaughtered them and boiled their flesh, using the oxen's equipment, and gave it to the people, and they ate. Then he arose and followed Elijah, and became his servant.

## Chapter 20

1. Now Ben-Hadad the king of Syria gathered all his forces together; thirty-two kings were with him, with horses and chariots. And he went up and besieged Samaria, and made war against it.

2. Then he sent messengers into the city to Ahab king of Israel, and said to him, "Thus says Ben-Hadad:

3. "Your silver and your gold are mine; your loveliest wives and children are mine."'

4. And the king of Israel answered and said, "My lord, O king, just as you say, I and all that I have are yours."

5. Then the messengers came back and said, "Thus speaks Ben-Hadad, saying, "Indeed I have sent to you, saying, "You shall deliver to me your silver and your gold, your wives and your children";

6. but I will send my servants to you tomorrow about this time, and they shall search your house and the houses of your servants. And it shall be, that whatever is pleasant in your eyes, they will put it in their hands and take it."'

7. So the king of Israel called all the elders of the land, and said, "Notice, please, and see how this man seeks trouble, for he sent to me for my wives, my children, my silver, and my gold; and I did not deny him."

8. And all the elders and all the people said to him, "Do not listen or consent."

9. Therefore he said to the messengers of Ben-Hadad, "Tell my lord the king, "All that you sent for to your servant the first time I will do, but this thing I cannot do."' And the messengers departed and brought back word to him.

10. Then Ben-Hadad sent to him and said, "The gods do so to me, and more also, if enough dust is left of Samaria for a handful for each of the people who follow me."

11. So the king of Israel answered and said, "Tell him, "Let not the one who puts on his armor boast like the one who takes it off."'

12. And it happened when Ben-Hadad heard this message, as he and the kings were drinking at the command post, that he said to his servants, "Get ready." And they got ready to attack the city.

13. Suddenly a prophet approached Ahab king of Israel, saying, "Thus says the LORD: "Have you seen all this great multitude? Behold, I will deliver it into your hand today, and you shall know that I am the LORD."'

14. So Ahab said, "By whom?" And he said, "Thus says the LORD: "By the young leaders of the provinces."' Then he said, "Who will set the battle in order?" And he answered, "You."

15. Then he mustered the young leaders of the provinces, and there were two hundred and thirty-two; and after them he mustered all the people, all the children of Israel--seven thousand.

16. So they went out at noon. Meanwhile Ben-Hadad and the thirty-two kings helping him were getting drunk at the command post.

17. The young leaders of the provinces went out first. And Ben-Hadad sent out a patrol, and they told him, saying, "Men are coming out of Samaria!"

18. So he said, "If they have come out for peace, take them alive; and if they have come out for war, take them alive."

19. Then these young leaders of the provinces went out of the city with the army which followed them.

20. And each one killed his man; so the Syrians fled, and Israel pursued them; and Ben-Hadad the king of Syria escaped on a horse with the cavalry.

21. Then the king of Israel went out and attacked the horses and chariots, and killed the Syrians with a great slaughter.

22. And the prophet came to the king of Israel and said to him, "Go, strengthen yourself; take note, and see what you should do, for in the spring of the year the king of Syria will come up against you."

23. Then the servants of the king of Syria said to him, "Their gods are gods of the hills. Therefore they were stronger than we; but if we fight against them in the plain, surely we will be stronger than they.

24. So do this thing: Dismiss the kings, each from his position, and put captains in their places;

25. and you shall muster an army like the army that you have lost, horse for horse and chariot for chariot. Then we will fight against them in the plain; surely we will be stronger than they." And he listened to their voice and did so.

26. So it was, in the spring of the year, that Ben-Hadad mustered the Syrians and went up to Aphek to fight against Israel.

27. And the children of Israel were mustered and given provisions, and they went against them. Now the children of Israel encamped before them like two little flocks of goats, while the Syrians filled the countryside.

28. Then a man of God came and spoke to the king of Israel, and said, "Thus says the LORD: "Because the Syrians have said, "The LORD is God of the hills, but He is not God of the valleys," therefore I will deliver all this great multitude into your hand, and you shall know that I am the LORD."'

29. And they encamped opposite each other for seven days. So it was that on the seventh day the battle was joined; and the children of Israel killed one hundred thousand foot soldiers of the Syrians in one day.

30. But the rest fled to Aphek, into the city; then a wall fell on twenty-seven thousand of the men who were left. And Ben-Hadad fled and went into the city, into an inner chamber.

31. Then his servants said to him, "Look now, we have heard that the kings of the house of Israel are merciful kings. Please, let us put sackcloth around our waists and ropes around our heads, and go out to the king of Israel; perhaps he will spare your life."

32. So they wore sackcloth around their waists and put ropes around their heads, and came to the king of Israel and said, "Your servant Ben-Hadad says, "Please let me live."' And he said, "Is he still alive? He is my brother."

33. Now the men were watching closely to see whether any sign of mercy would come from him; and they quickly grasped at this word and said, "Your brother Ben-Hadad." So he said, "Go, bring him." Then Ben-Hadad came out to him; and he had him come up into the chariot.

34. So Ben-Hadad said to him, "The cities which my father took from your father I will restore; and you may set up marketplaces for yourself in Damascus, as my father did in Samaria." Then Ahab said, "I will send you away with this treaty." So he made a treaty with him and sent him away.

35. Now a certain man of the sons of the prophets said to his neighbor by the word of the LORD, "Strike me, please." And the man refused to strike him.

36. Then he said to him, "Because you have not obeyed the voice of the LORD, surely, as soon as you depart from me, a lion shall kill you." And as soon as he left him, a lion found him and killed him.

37. And he found another man, and said, "Strike me, please." So the man struck him, inflicting a wound.

38. Then the prophet departed and waited for the king by the road, and disguised himself with a bandage over his eyes.

39. Now as the king passed by, he cried out to the king and said, "Your servant went out into the midst of the battle; and there, a man came over and brought a man to me, and said, "Guard this man; if by any means he is missing, your life shall be for his life, or else you shall pay a talent of silver.'

40. While your servant was busy here and there, he was gone." Then the king of Israel said to him, "So shall your judgment be; you yourself have decided it."

41. And he hastened to take the bandage away from his eyes; and the king of Israel recognized him as one of the prophets.

42. Then he said to him, "Thus says the LORD: "Because you have let slip out of your hand a man whom I appointed to utter destruction, therefore your life shall go for his life, and your people for his people."'

43. So the king of Israel went to his house sullen and displeased, and came to Samaria.

## Chapter 21

1. And it came to pass after these things that Naboth the Jezreelite had a vineyard which was in Jezreel, next to the palace of Ahab king of Samaria.

2. So Ahab spoke to Naboth, saying, "Give me your vineyard, that I may have it for a vegetable garden, because it is near, next to my house; and for it I will give you a vineyard better than it. Or, if it seems good to you, I will give you its worth in money."

3. But Naboth said to Ahab, "The LORD forbid that I should give the inheritance of my fathers to you!"

4. So Ahab went into his house sullen and displeased because of the word which Naboth the Jezreelite had spoken to him; for he had said, "I will not give you the inheritance of my fathers." And he lay down on his bed, and turned away his face, and would eat no food.

5. But Jezebel his wife came to him, and said to him, "Why is your spirit so sullen that you eat no food?"

6. He said to her, "Because I spoke to Naboth the Jezreelite, and said to him, "Give me your vineyard for money; or else, if it pleases you, I will give you another vineyard for it.' And he answered, "I will not give you my vineyard."'

7. Then Jezebel his wife said to him, "You now exercise authority over Israel! Arise, eat food, and let your heart be cheerful; I will give you the vineyard of Naboth the Jezreelite."

8. And she wrote letters in Ahab's name, sealed them with his seal, and sent the letters to the elders and the nobles who were dwelling in the city with Naboth.

9. She wrote in the letters, saying, 4 Proclaim a fast, and seat Naboth with high honor among the people;

10. and seat two men, scoundrels, before him to bear witness against him, saying, You have blasphemed God and the king. Then take him out, and stone him, that he may die.

11. So the men of his city, the elders and nobles who were inhabitants of his city, did as Jezebel had sent to them, as it was written in the letters which she had sent to them.

12. They proclaimed a fast, and seated Naboth with high honor among the people.

13. And two men, scoundrels, came in and sat before him; and the scoundrels witnessed against him, against Naboth, in the presence of the people, saying, "Naboth has blasphemed God and the king!" Then they took him outside the city and stoned him with stones, so that he died.

14. Then they sent to Jezebel, saying, "Naboth has been stoned and is dead."

15. And it came to pass, when Jezebel heard that Naboth had been stoned and was dead, that Jezebel said to Ahab, "Arise, take possession of the vineyard of Naboth the Jezreelite, which he refused to give you for money; for Naboth is not alive, but dead."

16. So it was, when Ahab heard that Naboth was dead, that Ahab got up and went down to take possession of the vineyard of Naboth the Jezreelite.

17. Then the word of the LORD came to Elijah the Tishbite, saying,

18. "Arise, go down to meet Ahab king of Israel, who lives in Samaria. There he is, in the vineyard of Naboth, where he has gone down to take possession of it.

19. You shall speak to him, saying, "Thus says the LORD: "Have you murdered and also taken possession?"' And you shall speak to him, saying, "Thus says the LORD: "In the place where dogs licked the blood of Naboth, dogs shall lick your blood, even yours.""'

20. So Ahab said to Elijah, "Have you found me, O my enemy?" And he answered, "I have found you, because you have sold yourself to do evil in the sight of the LORD:

21. "Behold, I will bring calamity on you. I will take away your posterity, and will cut off from Ahab every male in Israel, both bond and free.

22. I will make your house like the house of Jeroboam the son of Nebat, and like the house of Baasha the son of Ahijah, because of the provocation with which you have provoked Me to anger, and made Israel sin.'

23. And concerning Jezebel the LORD also spoke, saying, "The dogs shall eat Jezebel by the wall of Jezreel.'

24. The dogs shall eat whoever belongs to Ahab and dies in the city, and the birds of the air shall eat whoever dies in the field."

25. But there was no one like Ahab who sold himself to do wickedness in the sight of the LORD, because Jezebel his wife stirred him up.

26. And he behaved very abominably in following idols, according to all that the Amorites had done, whom the LORD had cast out before the children of Israel.

27. So it was, when Ahab heard those words, that he tore his clothes and put sackcloth on his body, and fasted and lay in sackcloth, and went about mourning.

28. And the word of the LORD came to Elijah the Tishbite, saying,

29. "See how Ahab has humbled himself before Me? Because he has humbled himself before Me, I will not bring the calamity in his days. In the days of his son I will bring the calamity on his house."

## Chapter 22

1. Now three years passed without war between Syria and Israel.

2. Then it came to pass, in the third year, that Jehoshaphat the king of Judah went down to visit the king of Israel.

3. And the king of Israel said to his servants, "Do you know that Ramoth in Gilead is ours, but we hesitate to take it out of the hand of the king of Syria?"

4. So he said to Jehoshaphat, "Will you go with me to fight at Ramoth Gilead?" Jehoshaphat said to the king of Israel, "I am as you are, my people as your people, my horses as your horses."

5. Also Jehoshaphat said to the king of Israel, "Please inquire for the word of the LORD today."

6. Then the king of Israel gathered the prophets together, about four hundred men, and said to them, "Shall I go against Ramoth Gilead to fight, or shall I refrain?" So they said, "Go up, for the Lord will deliver it into the hand of the king."

7. And Jehoshaphat said, "Is there not still a prophet of the LORD here, that we may inquire of Him?"

8. So the king of Israel said to Jehoshaphat, "There is still one man, Micaiah the son of Imlah, by whom we may inquire of the LORD; but I hate him, because he does not prophesy good concerning me, but evil." And Jehoshaphat said, "Let not the king say such things!"

9. Then the king of Israel called an officer and said, "Bring Micaiah the son of Imlah quickly!"

10. The king of Israel and Jehoshaphat the king of Judah, having put on their robes, sat each on his throne, at a threshing floor at the entrance of the gate of Samaria; and all the prophets prophesied before them.

11. Now Zedekiah the son of Chenaanah had made horns of iron for himself; and he said, "Thus says the LORD: "With these you shall gore the Syrians until they are destroyed."'

12. And all the prophets prophesied so, saying, "Go up to Ramoth Gilead and prosper, for the LORD will deliver it into the king's hand."

13. Then the messenger who had gone to call Micaiah spoke to him, saying, "Now listen, the words of the prophets with one accord encourage the king. Please, let your word be like the word of one of them, and speak encouragement."

14. And Micaiah said, "As the LORD lives, whatever the LORD says to me, that I will speak."

15. Then he came to the king; and the king said to him, "Micaiah, shall we go to war against Ramoth Gilead, or shall we refrain?" And he answered him, "Go and prosper, for the LORD will deliver it into the hand of the king!"

16. So the king said to him, "How many times shall I make you swear that you tell me nothing but the truth in the name of the LORD?"

17. Then he said, "I saw all Israel scattered on the mountains, as sheep that have no shepherd. And the LORD said, "These have no master. Let each return to his house in peace."'

18. And the king of Israel said to Jehoshaphat, "Did I not tell you he would not prophesy good concerning me, but evil?"

19. Then Micaiah said, "Therefore hear the word of the LORD: I saw the LORD sitting on His throne, and all the host of heaven standing by, on His right hand and on His left.

20. And the LORD said, "Who will persuade Ahab to go up, that he may fall at Ramoth Gilead?' So one spoke in this manner, and another spoke in that manner.

21. Then a spirit came forward and stood before the LORD, and said, "I will persuade him.'

22. The LORD said to him, "In what way?' So he said, "I will go out and be a lying spirit in the mouth of all his prophets.' And the LORD said, "You shall persuade him, and also prevail. Go out and do so.'

23. Therefore look! The LORD has put a lying spirit in the mouth of all these prophets of yours, and the LORD has declared disaster against you."

24. Now Zedekiah the son of Chenaanah went near and struck Micaiah on the cheek, and said, "Which way did the spirit from the LORD go from me to speak to you?"

25. And Micaiah said, "Indeed, you shall see on that day when you go into an inner chamber to hide!"

26. So the king of Israel said, "Take Micaiah, and return him to Amon the governor of the city and to Joash the king's son;

27. and say, "Thus says the king: "Put this fellow in prison, and feed him with bread of affliction and water of affliction, until I come in peace.""'

28. But Micaiah said, "If you ever return in peace, the LORD has not spoken by me." And he said, "Take heed, all you people!"

29. So the king of Israel and Jehoshaphat the king of Judah went up to Ramoth Gilead.

30. And the king of Israel said to Jehoshaphat, "I will disguise myself and go into battle; but you put on your robes." So the king of Israel disguised himself and went into battle.

31. Now the king of Syria had commanded the thirty-two captains of his chariots, saying, "Fight with no one small or great, but only with the king of Israel."

32. So it was, when the captains of the chariots saw Jehoshaphat, that they said, "Surely it is the king of Israel!" Therefore they turned aside to fight against him, and Jehoshaphat cried out.

33. And it happened, when the captains of the chariots saw that it was not the king of Israel, that they turned back from pursuing him.

34. Now a certain man drew a bow at random, and struck the king of Israel between the joints of his armor. So he said to the driver of his chariot, "Turn around and take me out of the battle, for I am wounded."

35. The battle increased that day; and the king was propped up in his chariot, facing the Syrians, and died at evening. The blood ran out from the wound onto the floor of the chariot.

36. Then, as the sun was going down, a shout went throughout the army, saying, "Every man to his city, and every man to his own country!"

37. So the king died, and was brought to Samaria. And they buried the king in Samaria.

38. Then someone washed the chariot at a pool in Samaria, and the dogs licked up his blood while the harlots bathed, according to the word of the LORD which He had spoken.

39. Now the rest of the acts of Ahab, and all that he did, the ivory house which he built and all the cities that he built, are they not written in the book of the chronicles of the kings of Israel?

40. So Ahab rested with his fathers. Then Ahaziah his son reigned in his place.

41. Jehoshaphat the son of Asa had become king over Judah in the fourth year of Ahab king of Israel.

42. Jehoshaphat was thirty-five years old when he became king, and he reigned twenty-five years in Jerusalem. His mother's name was Azubah the daughter of Shilhi.

43. And he walked in all the ways of his father Asa. He did not turn aside from them, doing what was right in the eyes of the LORD. Nevertheless the high places were not taken away, for the people offered sacrifices and burned incense on the high places.

44. Also Jehoshaphat made peace with the king of Israel.

45. Now the rest of the acts of Jehoshaphat, the might that he showed, and how he made war, are they not written in the book of the chronicles of the kings of Judah?

46. And the rest of the perverted persons, who remained in the days of his father Asa, he banished from the land.

47. There was then no king in Edom, only a deputy of the king.

48. Jehoshaphat made merchant ships to go to Ophir for gold; but they never sailed, for the ships were wrecked at Ezion Geber.

49. Then Ahaziah the son of Ahab said to Jehoshaphat, "Let my servants go with your servants in the ships." But Jehoshaphat would not.

50. And Jehoshaphat rested with his fathers, and was buried with his fathers in the City of David his father. Then Jehoram his son reigned in his place.

51. Ahaziah the son of Ahab became king over Israel in Samaria in the seventeenth year of Jehoshaphat king of Judah, and reigned two years over Israel.

52. He did evil in the sight of the LORD, and walked in the way of his father and in the way of his mother and in the way of Jeroboam the son of Nebat, who had made Israel sin;

53. for he served Baal and worshiped him, and provoked the LORD God of Israel to anger, according to all that his father had done.


# 1-samuel

## Chapter 1

1. Now there was a certain man of Ramathaim Zophim, of the mountains of Ephraim, and his name was Elkanah the son of Jeroham, the son of Elihu, the son of Tohu, the son of Zuph, an Ephraimite.

2. And he had two wives: the name of one was Hannah, and the name of the other Peninnah. Peninnah had children, but Hannah had no children.

3. This man went up from his city yearly to worship and sacrifice to the LORD of hosts in Shiloh. Also the two sons of Eli, Hophni and Phinehas, the priests of the LORD, were there.

4. And whenever the time came for Elkanah to make an offering, he would give portions to Peninnah his wife and to all her sons and daughters.

5. But to Hannah he would give a double portion, for he loved Hannah, although the LORD had closed her womb.

6. And her rival also provoked her severely, to make her miserable, because the LORD had closed her womb.

7. So it was, year by year, when she went up to the house of the LORD, that she provoked her; therefore she wept and did not eat.

8. Then Elkanah her husband said to her, "Hannah, why do you weep? Why do you not eat? And why is your heart grieved? Am I not better to you than ten sons?"

9. So Hannah arose after they had finished eating and drinking in Shiloh. Now Eli the priest was sitting on the seat by the doorpost of the tabernacle of the LORD.

10. And she was in bitterness of soul, and prayed to the LORD and wept in anguish.

11. Then she made a vow and said, "O LORD of hosts, if You will indeed look on the affliction of Your maidservant and remember me, and not forget Your maidservant, but will give Your maidservant a male child, then I will give him to the LORD all the days of his life, and no razor shall come upon his head."

12. And it happened, as she continued praying before the LORD, that Eli watched her mouth.

13. Now Hannah spoke in her heart; only her lips moved, but her voice was not heard. Therefore Eli thought she was drunk.

14. So Eli said to her, "How long will you be drunk? Put your wine away from you!"

15. But Hannah answered and said, "No, my lord, I am a woman of sorrowful spirit. I have drunk neither wine nor intoxicating drink, but have poured out my soul before the LORD.

16. Do not consider your maidservant a wicked woman, for out of the abundance of my complaint and grief I have spoken until now."

17. Then Eli answered and said, "Go in peace, and the God of Israel grant your petition which you have asked of Him."

18. And she said, "Let your maidservant find favor in your sight." So the woman went her way and ate, and her face was no longer sad.

19. Then they rose early in the morning and worshiped before the LORD, and returned and came to their house at Ramah. And Elkanah knew Hannah his wife, and the LORD remembered her.

20. So it came to pass in the process of time that Hannah conceived and bore a son, and called his name Samuel, saying, "Because I have asked for him from the LORD."

21. Now the man Elkanah and all his house went up to offer to the LORD the yearly sacrifice and his vow.

22. But Hannah did not go up, for she said to her husband, "Not until the child is weaned; then I will take him, that he may appear before the LORD and remain there forever."

23. So Elkanah her husband said to her, "Do what seems best to you; wait until you have weaned him. Only let the LORD establish His word." Then the woman stayed and nursed her son until she had weaned him.

24. Now when she had weaned him, she took him up with her, with three bulls, one ephah of flour, and a skin of wine, and brought him to the house of the LORD in Shiloh. And the child was young.

25. Then they slaughtered a bull, and brought the child to Eli.

26. And she said, "O my lord! As your soul lives, my lord, I am the woman who stood by you here, praying to the LORD.

27. For this child I prayed, and the LORD has granted me my petition which I asked of Him.

28. Therefore I also have lent him to the LORD; as long as he lives he shall be lent to the LORD." So they worshiped the LORD there.

## Chapter 2

1. And Hannah prayed and said: "My heart rejoices in the LORD; My horn is exalted in the LORD. I smile at my enemies, Because I rejoice in Your salvation.

2. "No one is holy like the LORD, For there is none besides You, Nor is there any rock like our God.

3. "Talk no more so very proudly; Let no arrogance come from your mouth, For the LORD is the God of knowledge; And by Him actions are weighed.

4. "The bows of the mighty men are broken, And those who stumbled are girded with strength.

5. Those who were full have hired themselves out for bread, And the hungry have ceased to hunger. Even the barren has borne seven, And she who has many children has become feeble.

6. "The LORD kills and makes alive; He brings down to the grave and brings up.

7. The LORD makes poor and makes rich; He brings low and lifts up.

8. He raises the poor from the dust And lifts the beggar from the ash heap, To set them among princes And make them inherit the throne of glory. "For the pillars of the earth are the LORD's, And He has set the world upon them.

9. He will guard the feet of His saints, But the wicked shall be silent in darkness. "For by strength no man shall prevail.

10. The adversaries of the LORD shall be broken in pieces; From heaven He will thunder against them. The LORD will judge the ends of the earth. "He will give strength to His king, And exalt the horn of His anointed."

11. Then Elkanah went to his house at Ramah. But the child ministered to the LORD before Eli the priest.

12. Now the sons of Eli were corrupt; they did not know the LORD.

13. And the priests' custom with the people was that when any man offered a sacrifice, the priest's servant would come with a three-pronged fleshhook in his hand while the meat was boiling.

14. Then he would thrust it into the pan, or kettle, or caldron, or pot; and the priest would take for himself all that the fleshhook brought up. So they did in Shiloh to all the Israelites who came there.

15. Also, before they burned the fat, the priest's servant would come and say to the man who sacrificed, "Give meat for roasting to the priest, for he will not take boiled meat from you, but raw."

16. And if the man said to him, "They should really burn the fat first; then you may take as much as your heart desires," he would then answer him, "No, but you must give it now; and if not, I will take it by force."

17. Therefore the sin of the young men was very great before the LORD, for men abhorred the offering of the LORD.

18. But Samuel ministered before the LORD, even as a child, wearing a linen ephod.

19. Moreover his mother used to make him a little robe, and bring it to him year by year when she came up with her husband to offer the yearly sacrifice.

20. And Eli would bless Elkanah and his wife, and say, "The LORD give you descendants from this woman for the loan that was given to the LORD." Then they would go to their own home.

21. And the LORD visited Hannah, so that she conceived and bore three sons and two daughters. Meanwhile the child Samuel grew before the LORD.

22. Now Eli was very old; and he heard everything his sons did to all Israel, and how they lay with the women who assembled at the door of the tabernacle of meeting.

23. So he said to them, "Why do you do such things? For I hear of your evil dealings from all the people.

24. No, my sons! For it is not a good report that I hear. You make the LORD's people transgress.

25. If one man sins against another, God will judge him. But if a man sins against the LORD, who will intercede for him?" Nevertheless they did not heed the voice of their father, because the LORD desired to kill them.

26. And the child Samuel grew in stature, and in favor both with the LORD and men.

27. Then a man of God came to Eli and said to him, "Thus says the LORD: "Did I not clearly reveal Myself to the house of your father when they were in Egypt in Pharaoh's house?

28. Did I not choose him out of all the tribes of Israel to be My priest, to offer upon My altar, to burn incense, and to wear an ephod before Me? And did I not give to the house of your father all the offerings of the children of Israel made by fire?

29. Why do you kick at My sacrifice and My offering which I have commanded in My dwelling place, and honor your sons more than Me, to make yourselves fat with the best of all the offerings of Israel My people?'

30. Therefore the LORD God of Israel says: "I said indeed that your house and the house of your father would walk before Me forever.' But now the LORD says: "Far be it from Me; for those who honor Me I will honor, and those who despise Me shall be lightly esteemed.

31. Behold, the days are coming that I will cut off your arm and the arm of your father's house, so that there will not be an old man in your house.

32. And you will see an enemy in My dwelling place, despite all the good which God does for Israel. And there shall not be an old man in your house forever.

33. But any of your men whom I do not cut off from My altar shall consume your eyes and grieve your heart. And all the descendants of your house shall die in the flower of their age.

34. Now this shall be a sign to you that will come upon your two sons, on Hophni and Phinehas: in one day they shall die, both of them.

35. Then I will raise up for Myself a faithful priest who shall do according to what is in My heart and in My mind. I will build him a sure house, and he shall walk before My anointed forever.

36. And it shall come to pass that everyone who is left in your house will come and bow down to him for a piece of silver and a morsel of bread, and say, "Please, put me in one of the priestly positions, that I may eat a piece of bread.""'

## Chapter 3

1. Now the boy Samuel ministered to the LORD before Eli. And the word of the LORD was rare in those days; there was no widespread revelation.

2. And it came to pass at that time, while Eli was lying down in his place, and when his eyes had begun to grow so dim that he could not see,

3. and before the lamp of God went out in the tabernacle of the LORD where the ark of God was, and while Samuel was lying down,

4. that the LORD called Samuel. And he answered, "Here I am!"

5. So he ran to Eli and said, "Here I am, for you called me." And he said, "I did not call; lie down again." And he went and lay down.

6. Then the LORD called yet again, "Samuel!" So Samuel arose and went to Eli, and said, "Here I am, for you called me." He answered, "I did not call, my son; lie down again."

7. (Now Samuel did not yet know the LORD, nor was the word of the LORD yet revealed to him.)

8. And the LORD called Samuel again the third time. So he arose and went to Eli, and said, "Here I am, for you did call me." Then Eli perceived that the LORD had called the boy.

9. Therefore Eli said to Samuel, "Go, lie down; and it shall be, if He calls you, that you must say, "Speak, LORD, for Your servant hears."' So Samuel went and lay down in his place.

10. Now the LORD came and stood and called as at other times, "Samuel! Samuel!" And Samuel answered, "Speak, for Your servant hears."

11. Then the LORD said to Samuel: "Behold, I will do something in Israel at which both ears of everyone who hears it will tingle.

12. In that day I will perform against Eli all that I have spoken concerning his house, from beginning to end.

13. For I have told him that I will judge his house forever for the iniquity which he knows, because his sons made themselves vile, and he did not restrain them.

14. And therefore I have sworn to the house of Eli that the iniquity of Eli's house shall not be atoned for by sacrifice or offering forever."

15. So Samuel lay down until morning, and opened the doors of the house of the LORD. And Samuel was afraid to tell Eli the vision.

16. Then Eli called Samuel and said, "Samuel, my son!" He answered, "Here I am."

17. And he said, "What is the word that the LORD spoke to you? Please do not hide it from me. God do so to you, and more also, if you hide anything from me of all the things that He said to you."

18. Then Samuel told him everything, and hid nothing from him. And he said, "It is the LORD. Let Him do what seems good to Him."

19. So Samuel grew, and the LORD was with him and let none of his words fall to the ground.

20. And all Israel from Dan to Beersheba knew that Samuel had been established as a prophet of the LORD.

21. Then the LORD appeared again in Shiloh. For the LORD revealed Himself to Samuel in Shiloh by the word of the LORD.

## Chapter 4

1. And the word of Samuel came to all Israel. Now Israel went out to battle against the Philistines, and encamped beside Ebenezer; and the Philistines encamped in Aphek.

2. Then the Philistines put themselves in battle array against Israel. And when they joined battle, Israel was defeated by the Philistines, who killed about four thousand men of the army in the field.

3. And when the people had come into the camp, the elders of Israel said, "Why has the LORD defeated us today before the Philistines? Let us bring the ark of the covenant of the LORD from Shiloh to us, that when it comes among us it may save us from the hand of our enemies."

4. So the people sent to Shiloh, that they might bring from there the ark of the covenant of the LORD of hosts, who dwells between the cherubim. And the two sons of Eli, Hophni and Phinehas, were there with the ark of the covenant of God.

5. And when the ark of the covenant of the LORD came into the camp, all Israel shouted so loudly that the earth shook.

6. Now when the Philistines heard the noise of the shout, they said, "What does the sound of this great shout in the camp of the Hebrews mean?" Then they understood that the ark of the LORD had come into the camp.

7. So the Philistines were afraid, for they said, "God has come into the camp!" And they said, "Woe to us! For such a thing has never happened before.

8. Woe to us! Who will deliver us from the hand of these mighty gods? These are the gods who struck the Egyptians with all the plagues in the wilderness.

9. Be strong and conduct yourselves like men, you Philistines, that you do not become servants of the Hebrews, as they have been to you. Conduct yourselves like men, and fight!"

10. So the Philistines fought, and Israel was defeated, and every man fled to his tent. There was a very great slaughter, and there fell of Israel thirty thousand foot soldiers.

11. Also the ark of God was captured; and the two sons of Eli, Hophni and Phinehas, died.

12. Then a man of Benjamin ran from the battle line the same day, and came to Shiloh with his clothes torn and dirt on his head.

13. Now when he came, there was Eli, sitting on a seat by the wayside watching, for his heart trembled for the ark of God. And when the man came into the city and told it, all the city cried out.

14. When Eli heard the noise of the outcry, he said, "What does the sound of this tumult mean?" And the man came quickly and told Eli.

15. Eli was ninety-eight years old, and his eyes were so dim that he could not see.

16. Then the man said to Eli, "I am he who came from the battle. And I fled today from the battle line." And he said, "What happened, my son?"

17. So the messenger answered and said, "Israel has fled before the Philistines, and there has been a great slaughter among the people. Also your two sons, Hophni and Phinehas, are dead; and the ark of God has been captured."

18. Then it happened, when he made mention of the ark of God, that Eli fell off the seat backward by the side of the gate; and his neck was broken and he died, for the man was old and heavy. And he had judged Israel forty years.

19. Now his daughter-in-law, Phinehas' wife, was with child, due to be delivered; and when she heard the news that the ark of God was captured, and that her father-in-law and her husband were dead, she bowed herself and gave birth, for her labor pains came upon her.

20. And about the time of her death the women who stood by her said to her, "Do not fear, for you have borne a son." But she did not answer, nor did she regard it.

21. Then she named the child Ichabod, saying, "The glory has departed from Israel!" because the ark of God had been captured and because of her father-in-law and her husband.

22. And she said, "The glory has departed from Israel, for the ark of God has been captured."

## Chapter 5

1. Then the Philistines took the ark of God and brought it from Ebenezer to Ashdod.

2. When the Philistines took the ark of God, they brought it into the house of Dagon and set it by Dagon.

3. And when the people of Ashdod arose early in the morning, there was Dagon, fallen on its face to the earth before the ark of the LORD. So they took Dagon and set it in its place again.

4. And when they arose early the next morning, there was Dagon, fallen on its face to the ground before the ark of the LORD. The head of Dagon and both the palms of its hands were broken off on the threshold; only Dagon's torso was left of it.

5. Therefore neither the priests of Dagon nor any who come into Dagon's house tread on the threshold of Dagon in Ashdod to this day.

6. But the hand of the LORD was heavy on the people of Ashdod, and He ravaged them and struck them with tumors, both Ashdod and its territory.

7. And when the men of Ashdod saw how it was, they said, "The ark of the God of Israel must not remain with us, for His hand is harsh toward us and Dagon our god."

8. Therefore they sent and gathered to themselves all the lords of the Philistines, and said, "What shall we do with the ark of the God of Israel?" And they answered, "Let the ark of the God of Israel be carried away to Gath." So they carried the ark of the God of Israel away.

9. So it was, after they had carried it away, that the hand of the LORD was against the city with a very great destruction; and He struck the men of the city, both small and great, and tumors broke out on them.

10. Therefore they sent the ark of God to Ekron. So it was, as the ark of God came to Ekron, that the Ekronites cried out, saying, "They have brought the ark of the God of Israel to us, to kill us and our people!"

11. So they sent and gathered together all the lords of the Philistines, and said, "Send away the ark of the God of Israel, and let it go back to its own place, so that it does not kill us and our people." For there was a deadly destruction throughout all the city; the hand of God was very heavy there.

12. And the men who did not die were stricken with the tumors, and the cry of the city went up to heaven.

## Chapter 6

1. Now the ark of the LORD was in the country of the Philistines seven months.

2. And the Philistines called for the priests and the diviners, saying, "What shall we do with the ark of the LORD? Tell us how we should send it to its place."

3. So they said, "If you send away the ark of the God of Israel, do not send it empty; but by all means return it to Him with a trespass offering. Then you will be healed, and it will be known to you why His hand is not removed from you."

4. Then they said, "What is the trespass offering which we shall return to Him?" They answered, "Five golden tumors and five golden rats, according to the number of the lords of the Philistines. For the same plague was on all of you and on your lords.

5. Therefore you shall make images of your tumors and images of your rats that ravage the land, and you shall give glory to the God of Israel; perhaps He will lighten His hand from you, from your gods, and from your land.

6. Why then do you harden your hearts as the Egyptians and Pharaoh hardened their hearts? When He did mighty things among them, did they not let the people go, that they might depart?

7. Now therefore, make a new cart, take two milk cows which have never been yoked, and hitch the cows to the cart; and take their calves home, away from them.

8. Then take the ark of the LORD and set it on the cart; and put the articles of gold which you are returning to Him as a trespass offering in a chest by its side. Then send it away, and let it go.

9. And watch: if it goes up the road to its own territory, to Beth Shemesh, then He has done us this great evil. But if not, then we shall know that it is not His hand that struck us--it happened to us by chance."

10. Then the men did so; they took two milk cows and hitched them to the cart, and shut up their calves at home.

11. And they set the ark of the LORD on the cart, and the chest with the gold rats and the images of their tumors.

12. Then the cows headed straight for the road to Beth Shemesh, and went along the highway, lowing as they went, and did not turn aside to the right hand or the left. And the lords of the Philistines went after them to the border of Beth Shemesh.

13. Now the people of Beth Shemesh were reaping their wheat harvest in the valley; and they lifted their eyes and saw the ark, and rejoiced to see it.

14. Then the cart came into the field of Joshua of Beth Shemesh, and stood there; a large stone was there. So they split the wood of the cart and offered the cows as a burnt offering to the LORD.

15. The Levites took down the ark of the LORD and the chest that was with it, in which were the articles of gold, and put them on the large stone. Then the men of Beth Shemesh offered burnt offerings and made sacrifices the same day to the LORD.

16. So when the five lords of the Philistines had seen it, they returned to Ekron the same day.

17. These are the golden tumors which the Philistines returned as a trespass offering to the LORD: one for Ashdod, one for Gaza, one for Ashkelon, one for Gath, one for Ekron;

18. and the golden rats, according to the number of all the cities of the Philistines belonging to the five lords, both fortified cities and country villages, even as far as the large stone of Abel on which they set the ark of the LORD, which stone remains to this day in the field of Joshua of Beth Shemesh.

19. Then He struck the men of Beth Shemesh, because they had looked into the ark of the LORD. He struck fifty thousand and seventy men of the people, and the people lamented because the LORD had struck the people with a great slaughter.

20. And the men of Beth Shemesh said, "Who is able to stand before this holy LORD God? And to whom shall it go up from us?"

21. So they sent messengers to the inhabitants of Kirjath Jearim, saying, "The Philistines have brought back the ark of the LORD; come down and take it up with you."

## Chapter 7

1. Then the men of Kirjath Jearim came and took the ark of the LORD, and brought it into the house of Abinadab on the hill, and consecrated Eleazar his son to keep the ark of the LORD.

2. So it was that the ark remained in Kirjath Jearim a long time; it was there twenty years. And all the house of Israel lamented after the LORD.

3. Then Samuel spoke to all the house of Israel, saying, "If you return to the LORD with all your hearts, then put away the foreign gods and the Ashtoreths from among you, and prepare your hearts for the LORD, and serve Him only; and He will deliver you from the hand of the Philistines."

4. So the children of Israel put away the Baals and the Ashtoreths, and served the LORD only.

5. And Samuel said, "Gather all Israel to Mizpah, and I will pray to the LORD for you."

6. So they gathered together at Mizpah, drew water, and poured it out before the LORD. And they fasted that day, and said there, "We have sinned against the LORD." And Samuel judged the children of Israel at Mizpah.

7. Now when the Philistines heard that the children of Israel had gathered together at Mizpah, the lords of the Philistines went up against Israel. And when the children of Israel heard of it, they were afraid of the Philistines.

8. So the children of Israel said to Samuel, "Do not cease to cry out to the LORD our God for us, that He may save us from the hand of the Philistines."

9. And Samuel took a suckling lamb and offered it as a whole burnt offering to the LORD. Then Samuel cried out to the LORD for Israel, and the LORD answered him.

10. Now as Samuel was offering up the burnt offering, the Philistines drew near to battle against Israel. But the LORD thundered with a loud thunder upon the Philistines that day, and so confused them that they were overcome before Israel.

11. And the men of Israel went out of Mizpah and pursued the Philistines, and drove them back as far as below Beth Car.

12. Then Samuel took a stone and set it up between Mizpah and Shen, and called its name Ebenezer, saying, "Thus far the LORD has helped us."

13. So the Philistines were subdued, and they did not come anymore into the territory of Israel. And the hand of the LORD was against the Philistines all the days of Samuel.

14. Then the cities which the Philistines had taken from Israel were restored to Israel, from Ekron to Gath; and Israel recovered its territory from the hands of the Philistines. Also there was peace between Israel and the Amorites.

15. And Samuel judged Israel all the days of his life.

16. He went from year to year on a circuit to Bethel, Gilgal, and Mizpah, and judged Israel in all those places.

17. But he always returned to Ramah, for his home was there. There he judged Israel, and there he built an altar to the LORD.

## Chapter 8

1. Now it came to pass when Samuel was old that he made his sons judges over Israel.

2. The name of his firstborn was Joel, and the name of his second, Abijah; they were judges in Beersheba.

3. But his sons did not walk in his ways; they turned aside after dishonest gain, took bribes, and perverted justice.

4. Then all the elders of Israel gathered together and came to Samuel at Ramah,

5. and said to him, "Look, you are old, and your sons do not walk in your ways. Now make us a king to judge us like all the nations."

6. But the thing displeased Samuel when they said, "Give us a king to judge us." So Samuel prayed to the LORD.

7. And the LORD said to Samuel, "Heed the voice of the people in all that they say to you; for they have not rejected you, but they have rejected Me, that I should not reign over them.

8. According to all the works which they have done since the day that I brought them up out of Egypt, even to this day--with which they have forsaken Me and served other gods--so they are doing to you also.

9. Now therefore, heed their voice. However, you shall solemnly forewarn them, and show them the behavior of the king who will reign over them."

10. So Samuel told all the words of the LORD to the people who asked him for a king.

11. And he said, "This will be the behavior of the king who will reign over you: He will take your sons and appoint them for his own chariots and to be his horsemen, and some will run before his chariots.

12. He will appoint captains over his thousands and captains over his fifties, will set some to plow his ground and reap his harvest, and some to make his weapons of war and equipment for his chariots.

13. He will take your daughters to be perfumers, cooks, and bakers.

14. And he will take the best of your fields, your vineyards, and your olive groves, and give them to his servants.

15. He will take a tenth of your grain and your vintage, and give it to his officers and servants.

16. And he will take your male servants, your female servants, your finest young men, and your donkeys, and put them to his work.

17. He will take a tenth of your sheep. And you will be his servants.

18. And you will cry out in that day because of your king whom you have chosen for yourselves, and the LORD will not hear you in that day."

19. Nevertheless the people refused to obey the voice of Samuel; and they said, "No, but we will have a king over us,

20. that we also may be like all the nations, and that our king may judge us and go out before us and fight our battles."

21. And Samuel heard all the words of the people, and he repeated them in the hearing of the LORD.

22. So the LORD said to Samuel, "Heed their voice, and make them a king." And Samuel said to the men of Israel, "Every man go to his city."

## Chapter 9

1. There was a man of Benjamin whose name was Kish the son of Abiel, the son of Zeror, the son of Bechorath, the son of Aphiah, a Benjamite, a mighty man of power.

2. And he had a choice and handsome son whose name was Saul. There was not a more handsome person than he among the children of Israel. From his shoulders upward he was taller than any of the people.

3. Now the donkeys of Kish, Saul's father, were lost. And Kish said to his son Saul, "Please take one of the servants with you, and arise, go and look for the donkeys."

4. So he passed through the mountains of Ephraim and through the land of Shalisha, but they did not find them. Then they passed through the land of Shaalim, and they were not there. Then he passed through the land of the Benjamites, but they did not find them.

5. When they had come to the land of Zuph, Saul said to his servant who was with him, "Come, let us return, lest my father cease caring about the donkeys and become worried about us."

6. And he said to him, "Look now, there is in this city a man of God, and he is an honorable man; all that he says surely comes to pass. So let us go there; perhaps he can show us the way that we should go."

7. Then Saul said to his servant, "But look, if we go, what shall we bring the man? For the bread in our vessels is all gone, and there is no present to bring to the man of God. What do we have?"

8. And the servant answered Saul again and said, "Look, I have here at hand one-fourth of a shekel of silver. I will give that to the man of God, to tell us our way."

9. (Formerly in Israel, when a man went to inquire of God, he spoke thus: "Come, let us go to the seer"; for he who is now called a prophet was formerly called a seer.)

10. Then Saul said to his servant, "Well said; come, let us go." So they went to the city where the man of God was.

11. As they went up the hill to the city, they met some young women going out to draw water, and said to them, "Is the seer here?"

12. And they answered them and said, "Yes, there he is, just ahead of you. Hurry now; for today he came to this city, because there is a sacrifice of the people today on the high place.

13. As soon as you come into the city, you will surely find him before he goes up to the high place to eat. For the people will not eat until he comes, because he must bless the sacrifice; afterward those who are invited will eat. Now therefore, go up, for about this time you will find him."

14. So they went up to the city. As they were coming into the city, there was Samuel, coming out toward them on his way up to the high place.

15. Now the LORD had told Samuel in his ear the day before Saul came, saying,

16. "Tomorrow about this time I will send you a man from the land of Benjamin, and you shall anoint him commander over My people Israel, that he may save My people from the hand of the Philistines; for I have looked upon My people, because their cry has come to Me."

17. So when Samuel saw Saul, the LORD said to him, "There he is, the man of whom I spoke to you. This one shall reign over My people."

18. Then Saul drew near to Samuel in the gate, and said, "Please tell me, where is the seer's house?"

19. Samuel answered Saul and said, "I am the seer. Go up before me to the high place, for you shall eat with me today; and tomorrow I will let you go and will tell you all that is in your heart.

20. But as for your donkeys that were lost three days ago, do not be anxious about them, for they have been found. And on whom is all the desire of Israel? Is it not on you and on all your father's house?"

21. And Saul answered and said, "Am I not a Benjamite, of the smallest of the tribes of Israel, and my family the least of all the families of the tribe of Benjamin? Why then do you speak like this to me?"

22. Now Samuel took Saul and his servant and brought them into the hall, and had them sit in the place of honor among those who were invited; there were about thirty persons.

23. And Samuel said to the cook, "Bring the portion which I gave you, of which I said to you, "Set it apart."'

24. So the cook took up the thigh with its upper part and set it before Saul. And Samuel said, "Here it is, what was kept back. It was set apart for you. Eat; for until this time it has been kept for you, since I said I invited the people." So Saul ate with Samuel that day.

25. When they had come down from the high place into the city, Samuel spoke with Saul on the top of the house.

26. They arose early; and it was about the dawning of the day that Samuel called to Saul on the top of the house, saying, "Get up, that I may send you on your way." And Saul arose, and both of them went outside, he and Samuel.

27. As they were going down to the outskirts of the city, Samuel said to Saul, "Tell the servant to go on ahead of us." And he went on. "But you stand here awhile, that I may announce to you the word of God."

## Chapter 10

1. Then Samuel took a flask of oil and poured it on his head, and kissed him and said: "Is it not because the LORD has anointed you commander over His inheritance?

2. When you have departed from me today, you will find two men by Rachel's tomb in the territory of Benjamin at Zelzah; and they will say to you, "The donkeys which you went to look for have been found. And now your father has ceased caring about the donkeys and is worrying about you, saying, "What shall I do about my son?"'

3. Then you shall go on forward from there and come to the terebinth tree of Tabor. There three men going up to God at Bethel will meet you, one carrying three young goats, another carrying three loaves of bread, and another carrying a skin of wine.

4. And they will greet you and give you two loaves of bread, which you shall receive from their hands.

5. After that you shall come to the hill of God where the Philistine garrison is. And it will happen, when you have come there to the city, that you will meet a group of prophets coming down from the high place with a stringed instrument, a tambourine, a flute, and a harp before them; and they will be prophesying.

6. Then the Spirit of the LORD will come upon you, and you will prophesy with them and be turned into another man.

7. And let it be, when these signs come to you, that you do as the occasion demands; for God is with you.

8. You shall go down before me to Gilgal; and surely I will come down to you to offer burnt offerings and make sacrifices of peace offerings. Seven days you shall wait, till I come to you and show you what you should do."

9. So it was, when he had turned his back to go from Samuel, that God gave him another heart; and all those signs came to pass that day.

10. When they came there to the hill, there was a group of prophets to meet him; then the Spirit of God came upon him, and he prophesied among them.

11. And it happened, when all who knew him formerly saw that he indeed prophesied among the prophets, that the people said to one another, "What is this that has come upon the son of Kish? Is Saul also among the prophets?"

12. Then a man from there answered and said, "But who is their father?" Therefore it became a proverb: "Is Saul also among the prophets?"

13. And when he had finished prophesying, he went to the high place.

14. Then Saul's uncle said to him and his servant, "Where did you go?" So he said, "To look for the donkeys. When we saw that they were nowhere to be found, we went to Samuel."

15. And Saul's uncle said, "Tell me, please, what Samuel said to you."

16. So Saul said to his uncle, "He told us plainly that the donkeys had been found." But about the matter of the kingdom, he did not tell him what Samuel had said.

17. Then Samuel called the people together to the LORD at Mizpah,

18. and said to the children of Israel, "Thus says the LORD God of Israel: "I brought up Israel out of Egypt, and delivered you from the hand of the Egyptians and from the hand of all kingdoms and from those who oppressed you.'

19. But you have today rejected your God, who Himself saved you from all your adversities and your tribulations; and you have said to Him, "No, set a king over us!' Now therefore, present yourselves before the LORD by your tribes and by your clans."

20. And when Samuel had caused all the tribes of Israel to come near, the tribe of Benjamin was chosen.

21. When he had caused the tribe of Benjamin to come near by their families, the family of Matri was chosen. And Saul the son of Kish was chosen. But when they sought him, he could not be found.

22. Therefore they inquired of the LORD further, "Has the man come here yet?" And the LORD answered, "There he is, hidden among the equipment."

23. So they ran and brought him from there; and when he stood among the people, he was taller than any of the people from his shoulders upward.

24. And Samuel said to all the people, "Do you see him whom the LORD has chosen, that there is no one like him among all the people?" So all the people shouted and said, "Long live the king!"

25. Then Samuel explained to the people the behavior of royalty, and wrote it in a book and laid it up before the LORD. And Samuel sent all the people away, every man to his house.

26. And Saul also went home to Gibeah; and valiant men went with him, whose hearts God had touched.

27. But some rebels said, "How can this man save us?" So they despised him, and brought him no presents. But he held his peace.

## Chapter 11

1. Then Nahash the Ammonite came up and encamped against Jabesh Gilead; and all the men of Jabesh said to Nahash, "Make a covenant with us, and we will serve you."

2. And Nahash the Ammonite answered them, "On this condition I will make a covenant with you, that I may put out all your right eyes, and bring reproach on all Israel."

3. Then the elders of Jabesh said to him, "Hold off for seven days, that we may send messengers to all the territory of Israel. And then, if there is no one to save us, we will come out to you."

4. So the messengers came to Gibeah of Saul and told the news in the hearing of the people. And all the people lifted up their voices and wept.

5. Now there was Saul, coming behind the herd from the field; and Saul said, "What troubles the people, that they weep?" And they told him the words of the men of Jabesh.

6. Then the Spirit of God came upon Saul when he heard this news, and his anger was greatly aroused.

7. So he took a yoke of oxen and cut them in pieces, and sent them throughout all the territory of Israel by the hands of messengers, saying, "Whoever does not go out with Saul and Samuel to battle, so it shall be done to his oxen." And the fear of the LORD fell on the people, and they came out with one consent.

8. When he numbered them in Bezek, the children of Israel were three hundred thousand, and the men of Judah thirty thousand.

9. And they said to the messengers who came, "Thus you shall say to the men of Jabesh Gilead: "Tomorrow, by the time the sun is hot, you shall have help."' Then the messengers came and reported it to the men of Jabesh, and they were glad.

10. Therefore the men of Jabesh said, "Tomorrow we will come out to you, and you may do with us whatever seems good to you."

11. So it was, on the next day, that Saul put the people in three companies; and they came into the midst of the camp in the morning watch, and killed Ammonites until the heat of the day. And it happened that those who survived were scattered, so that no two of them were left together.

12. Then the people said to Samuel, "Who is he who said, "Shall Saul reign over us?' Bring the men, that we may put them to death."

13. But Saul said, "Not a man shall be put to death this day, for today the LORD has accomplished salvation in Israel."

14. Then Samuel said to the people, "Come, let us go to Gilgal and renew the kingdom there."

15. So all the people went to Gilgal, and there they made Saul king before the LORD in Gilgal. There they made sacrifices of peace offerings before the LORD, and there Saul and all the men of Israel rejoiced greatly.

## Chapter 12

1. Now Samuel said to all Israel: "Indeed I have heeded your voice in all that you said to me, and have made a king over you.

2. And now here is the king, walking before you; and I am old and grayheaded, and look, my sons are with you. I have walked before you from my childhood to this day.

3. Here I am. Witness against me before the LORD and before His anointed: Whose ox have I taken, or whose donkey have I taken, or whom have I cheated? Whom have I oppressed, or from whose hand have I received any bribe with which to blind my eyes? I will restore it to you."

4. And they said, "You have not cheated us or oppressed us, nor have you taken anything from any man's hand."

5. Then he said to them, "The LORD is witness against you, and His anointed is witness this day, that you have not found anything in my hand." And they answered, "He is witness."

6. Then Samuel said to the people, "It is the LORD who raised up Moses and Aaron, and who brought your fathers up from the land of Egypt.

7. Now therefore, stand still, that I may reason with you before the LORD concerning all the righteous acts of the LORD which He did to you and your fathers:

8. When Jacob had gone into Egypt, and your fathers cried out to the LORD, then the LORD sent Moses and Aaron, who brought your fathers out of Egypt and made them dwell in this place.

9. And when they forgot the LORD their God, He sold them into the hand of Sisera, commander of the army of Hazor, into the hand of the Philistines, and into the hand of the king of Moab; and they fought against them.

10. Then they cried out to the LORD, and said, "We have sinned, because we have forsaken the LORD and served the Baals and Ashtoreths; but now deliver us from the hand of our enemies, and we will serve You.'

11. And the LORD sent Jerubbaal, Bedan, Jephthah, and Samuel, and delivered you out of the hand of your enemies on every side; and you dwelt in safety.

12. And when you saw that Nahash king of the Ammonites came against you, you said to me, "No, but a king shall reign over us,' when the LORD your God was your king.

13. "Now therefore, here is the king whom you have chosen and whom you have desired. And take note, the LORD has set a king over you.

14. If you fear the LORD and serve Him and obey His voice, and do not rebel against the commandment of the LORD, then both you and the king who reigns over you will continue following the LORD your God.

15. However, if you do not obey the voice of the LORD, but rebel against the commandment of the LORD, then the hand of the LORD will be against you, as it was against your fathers.

16. "Now therefore, stand and see this great thing which the LORD will do before your eyes:

17. Is today not the wheat harvest? I will call to the LORD, and He will send thunder and rain, that you may perceive and see that your wickedness is great, which you have done in the sight of the LORD, in asking a king for yourselves."

18. So Samuel called to the LORD, and the LORD sent thunder and rain that day; and all the people greatly feared the LORD and Samuel.

19. And all the people said to Samuel, "Pray for your servants to the LORD your God, that we may not die; for we have added to all our sins the evil of asking a king for ourselves."

20. Then Samuel said to the people, "Do not fear. You have done all this wickedness; yet do not turn aside from following the LORD, but serve the LORD with all your heart.

21. And do not turn aside; for then you would go after empty things which cannot profit or deliver, for they are nothing.

22. For the LORD will not forsake His people, for His great name's sake, because it has pleased the LORD to make you His people.

23. Moreover, as for me, far be it from me that I should sin against the LORD in ceasing to pray for you; but I will teach you the good and the right way.

24. Only fear the LORD, and serve Him in truth with all your heart; for consider what great things He has done for you.

25. But if you still do wickedly, you shall be swept away, both you and your king."

## Chapter 13

1. Saul reigned one year; and when he had reigned two years over Israel,

2. Saul chose for himself three thousand men of Israel. Two thousand were with Saul in Michmash and in the mountains of Bethel, and a thousand were with Jonathan in Gibeah of Benjamin. The rest of the people he sent away, every man to his tent.

3. And Jonathan attacked the garrison of the Philistines that was in Geba, and the Philistines heard of it. Then Saul blew the trumpet throughout all the land, saying, "Let the Hebrews hear!"

4. Now all Israel heard it said that Saul had attacked a garrison of the Philistines, and that Israel had also become an abomination to the Philistines. And the people were called together to Saul at Gilgal.

5. Then the Philistines gathered together to fight with Israel, thirty thousand chariots and six thousand horsemen, and people as the sand which is on the seashore in multitude. And they came up and encamped in Michmash, to the east of Beth Aven.

6. When the men of Israel saw that they were in danger (for the people were distressed), then the people hid in caves, in thickets, in rocks, in holes, and in pits.

7. And some of the Hebrews crossed over the Jordan to the land of Gad and Gilead. As for Saul, he was still in Gilgal, and all the people followed him trembling.

8. Then he waited seven days, according to the time set by Samuel. But Samuel did not come to Gilgal; and the people were scattered from him.

9. So Saul said, "Bring a burnt offering and peace offerings here to me." And he offered the burnt offering.

10. Now it happened, as soon as he had finished presenting the burnt offering, that Samuel came; and Saul went out to meet him, that he might greet him.

11. And Samuel said, "What have you done?" Saul said, "When I saw that the people were scattered from me, and that you did not come within the days appointed, and that the Philistines gathered together at Michmash,

12. then I said, "The Philistines will now come down on me at Gilgal, and I have not made supplication to the LORD.' Therefore I felt compelled, and offered a burnt offering."

13. And Samuel said to Saul, "You have done foolishly. You have not kept the commandment of the LORD your God, which He commanded you. For now the LORD would have established your kingdom over Israel forever.

14. But now your kingdom shall not continue. The LORD has sought for Himself a man after His own heart, and the LORD has commanded him to be commander over His people, because you have not kept what the LORD commanded you."

15. Then Samuel arose and went up from Gilgal to Gibeah of Benjamin. And Saul numbered the people present with him, about six hundred men.

16. Saul, Jonathan his son, and the people present with them remained in Gibeah of Benjamin. But the Philistines encamped in Michmash.

17. Then raiders came out of the camp of the Philistines in three companies. One company turned onto the road to Ophrah, to the land of Shual,

18. another company turned to the road to Beth Horon, and another company turned to the road of the border that overlooks the Valley of Zeboim toward the wilderness.

19. Now there was no blacksmith to be found throughout all the land of Israel, for the Philistines said, "Lest the Hebrews make swords or spears."

20. But all the Israelites would go down to the Philistines to sharpen each man's plowshare, his mattock, his ax, and his sickle;

21. and the charge for a sharpening was a pim for the plowshares, the mattocks, the forks, and the axes, and to set the points of the goads.

22. So it came about, on the day of battle, that there was neither sword nor spear found in the hand of any of the people who were with Saul and Jonathan. But they were found with Saul and Jonathan his son.

23. And the garrison of the Philistines went out to the pass of Michmash.

## Chapter 14

1. Now it happened one day that Jonathan the son of Saul said to the young man who bore his armor, "Come, let us go over to the Philistines' garrison that is on the other side." But he did not tell his father.

2. And Saul was sitting in the outskirts of Gibeah under a pomegranate tree which is in Migron. The people who were with him were about six hundred men.

3. Ahijah the son of Ahitub, Ichabod's brother, the son of Phinehas, the son of Eli, the LORD's priest in Shiloh, was wearing an ephod. But the people did not know that Jonathan had gone.

4. Between the passes, by which Jonathan sought to go over to the Philistines' garrison, there was a sharp rock on one side and a sharp rock on the other side. And the name of one was Bozez, and the name of the other Seneh.

5. The front of one faced northward opposite Michmash, and the other southward opposite Gibeah.

6. Then Jonathan said to the young man who bore his armor, "Come, let us go over to the garrison of these uncircumcised; it may be that the LORD will work for us. For nothing restrains the LORD from saving by many or by few."

7. So his armorbearer said to him, "Do all that is in your heart. Go then; here I am with you, according to your heart."

8. Then Jonathan said, "Very well, let us cross over to these men, and we will show ourselves to them.

9. If they say thus to us, "Wait until we come to you,' then we will stand still in our place and not go up to them.

10. But if they say thus, "Come up to us,' then we will go up. For the LORD has delivered them into our hand, and this will be a sign to us."

11. So both of them showed themselves to the garrison of the Philistines. And the Philistines said, "Look, the Hebrews are coming out of the holes where they have hidden."

12. Then the men of the garrison called to Jonathan and his armorbearer, and said, "Come up to us, and we will show you something." Jonathan said to his armorbearer, "Come up after me, for the LORD has delivered them into the hand of Israel."

13. And Jonathan climbed up on his hands and knees with his armorbearer after him; and they fell before Jonathan. And as he came after him, his armorbearer killed them.

14. That first slaughter which Jonathan and his armorbearer made was about twenty men within about half an acre of land.

15. And there was trembling in the camp, in the field, and among all the people. The garrison and the raiders also trembled; and the earth quaked, so that it was a very great trembling.

16. Now the watchmen of Saul in Gibeah of Benjamin looked, and there was the multitude, melting away; and they went here and there.

17. Then Saul said to the people who were with him, "Now call the roll and see who has gone from us." And when they had called the roll, surprisingly, Jonathan and his armorbearer were not there.

18. And Saul said to Ahijah, "Bring the ark of God here" (for at that time the ark of God was with the children of Israel).

19. Now it happened, while Saul talked to the priest, that the noise which was in the camp of the Philistines continued to increase; so Saul said to the priest, "Withdraw your hand."

20. Then Saul and all the people who were with him assembled, and they went to the battle; and indeed every man's sword was against his neighbor, and there was very great confusion.

21. Moreover the Hebrews who were with the Philistines before that time, who went up with them into the camp from the surrounding country, they also joined the Israelites who were with Saul and Jonathan.

22. Likewise all the men of Israel who had hidden in the mountains of Ephraim, when they heard that the Philistines fled, they also followed hard after them in the battle.

23. So the LORD saved Israel that day, and the battle shifted to Beth Aven.

24. And the men of Israel were distressed that day, for Saul had placed the people under oath, saying, "Cursed is the man who eats any food until evening, before I have taken vengeance on my enemies." So none of the people tasted food.

25. Now all the people of the land came to a forest; and there was honey on the ground.

26. And when the people had come into the woods, there was the honey, dripping; but no one put his hand to his mouth, for the people feared the oath.

27. But Jonathan had not heard his father charge the people with the oath; therefore he stretched out the end of the rod that was in his hand and dipped it in a honeycomb, and put his hand to his mouth; and his countenance brightened.

28. Then one of the people said, "Your father strictly charged the people with an oath, saying, "Cursed is the man who eats food this day."' And the people were faint.

29. But Jonathan said, "My father has troubled the land. Look now, how my countenance has brightened because I tasted a little of this honey.

30. How much better if the people had eaten freely today of the spoil of their enemies which they found! For now would there not have been a much greater slaughter among the Philistines?"

31. Now they had driven back the Philistines that day from Michmash to Aijalon. So the people were very faint.

32. And the people rushed on the spoil, and took sheep, oxen, and calves, and slaughtered them on the ground; and the people ate them with the blood.

33. Then they told Saul, saying, "Look, the people are sinning against the LORD by eating with the blood!" So he said, "You have dealt treacherously; roll a large stone to me this day."

34. Then Saul said, "Disperse yourselves among the people, and say to them, "Bring me here every man's ox and every man's sheep, slaughter them here, and eat; and do not sin against the LORD by eating with the blood."' So every one of the people brought his ox with him that night, and slaughtered it there.

35. Then Saul built an altar to the LORD. This was the first altar that he built to the LORD.

36. Now Saul said, "Let us go down after the Philistines by night, and plunder them until the morning light; and let us not leave a man of them." And they said, "Do whatever seems good to you." Then the priest said, "Let us draw near to God here."

37. So Saul asked counsel of God, "Shall I go down after the Philistines? Will You deliver them into the hand of Israel?" But He did not answer him that day.

38. And Saul said, "Come over here, all you chiefs of the people, and know and see what this sin was today.

39. For as the LORD lives, who saves Israel, though it be in Jonathan my son, he shall surely die." But not a man among all the people answered him.

40. Then he said to all Israel, "You be on one side, and my son Jonathan and I will be on the other side." And the people said to Saul, "Do what seems good to you."

41. Therefore Saul said to the LORD God of Israel, "Give a perfect lot." So Saul and Jonathan were taken, but the people escaped.

42. And Saul said, "Cast lots between my son Jonathan and me." So Jonathan was taken.

43. Then Saul said to Jonathan, "Tell me what you have done." And Jonathan told him, and said, "I only tasted a little honey with the end of the rod that was in my hand. So now I must die!"

44. Saul answered, "God do so and more also; for you shall surely die, Jonathan."

45. But the people said to Saul, "Shall Jonathan die, who has accomplished this great deliverance in Israel? Certainly not! As the LORD lives, not one hair of his head shall fall to the ground, for he has worked with God this day." So the people rescued Jonathan, and he did not die.

46. Then Saul returned from pursuing the Philistines, and the Philistines went to their own place.

47. So Saul established his sovereignty over Israel, and fought against all his enemies on every side, against Moab, against the people of Ammon, against Edom, against the kings of Zobah, and against the Philistines. Wherever he turned, he harassed them.

48. And he gathered an army and attacked the Amalekites, and delivered Israel from the hands of those who plundered them.

49. The sons of Saul were Jonathan, Jishui, and Malchishua. And the names of his two daughters were these: the name of the firstborn Merab, and the name of the younger Michal.

50. The name of Saul's wife was Ahinoam the daughter of Ahimaaz. And the name of the commander of his army was Abner the son of Ner, Saul's uncle.

51. Kish was the father of Saul, and Ner the father of Abner was the son of Abiel.

52. Now there was fierce war with the Philistines all the days of Saul. And when Saul saw any strong man or any valiant man, he took him for himself.

## Chapter 15

1. Samuel also said to Saul, "The LORD sent me to anoint you king over His people, over Israel. Now therefore, heed the voice of the words of the LORD.

2. Thus says the LORD of hosts: "I will punish Amalek for what he did to Israel, how he ambushed him on the way when he came up from Egypt.

3. Now go and attack Amalek, and utterly destroy all that they have, and do not spare them. But kill both man and woman, infant and nursing child, ox and sheep, camel and donkey."'

4. So Saul gathered the people together and numbered them in Telaim, two hundred thousand foot soldiers and ten thousand men of Judah.

5. And Saul came to a city of Amalek, and lay in wait in the valley.

6. Then Saul said to the Kenites, "Go, depart, get down from among the Amalekites, lest I destroy you with them. For you showed kindness to all the children of Israel when they came up out of Egypt." So the Kenites departed from among the Amalekites.

7. And Saul attacked the Amalekites, from Havilah all the way to Shur, which is east of Egypt.

8. He also took Agag king of the Amalekites alive, and utterly destroyed all the people with the edge of the sword.

9. But Saul and the people spared Agag and the best of the sheep, the oxen, the fatlings, the lambs, and all that was good, and were unwilling to utterly destroy them. But everything despised and worthless, that they utterly destroyed.

10. Now the word of the LORD came to Samuel, saying,

11. "I greatly regret that I have set up Saul as king, for he has turned back from following Me, and has not performed My commandments." And it grieved Samuel, and he cried out to the LORD all night.

12. So when Samuel rose early in the morning to meet Saul, it was told Samuel, saying, "Saul went to Carmel, and indeed, he set up a monument for himself; and he has gone on around, passed by, and gone down to Gilgal."

13. Then Samuel went to Saul, and Saul said to him, "Blessed are you of the LORD! I have performed the commandment of the LORD."

14. But Samuel said, "What then is this bleating of the sheep in my ears, and the lowing of the oxen which I hear?"

15. And Saul said, "They have brought them from the Amalekites; for the people spared the best of the sheep and the oxen, to sacrifice to the LORD your God; and the rest we have utterly destroyed."

16. Then Samuel said to Saul, "Be quiet! And I will tell you what the LORD said to me last night." And he said to him, "Speak on."

17. So Samuel said, "When you were little in your own eyes, were you not head of the tribes of Israel? And did not the LORD anoint you king over Israel?

18. Now the LORD sent you on a mission, and said, "Go, and utterly destroy the sinners, the Amalekites, and fight against them until they are consumed.'

19. Why then did you not obey the voice of the LORD? Why did you swoop down on the spoil, and do evil in the sight of the LORD?"

20. And Saul said to Samuel, "But I have obeyed the voice of the LORD, and gone on the mission on which the LORD sent me, and brought back Agag king of Amalek; I have utterly destroyed the Amalekites.

21. But the people took of the plunder, sheep and oxen, the best of the things which should have been utterly destroyed, to sacrifice to the LORD your God in Gilgal."

22. So Samuel said: "Has the LORD as great delight in burnt offerings and sacrifices, As in obeying the voice of the LORD? Behold, to obey is better than sacrifice, And to heed than the fat of rams.

23. For rebellion is as the sin of witchcraft, And stubbornness is as iniquity and idolatry. Because you have rejected the word of the LORD, He also has rejected you from being king."

24. Then Saul said to Samuel, "I have sinned, for I have transgressed the commandment of the LORD and your words, because I feared the people and obeyed their voice.

25. Now therefore, please pardon my sin, and return with me, that I may worship the LORD."

26. But Samuel said to Saul, "I will not return with you, for you have rejected the word of the LORD, and the LORD has rejected you from being king over Israel."

27. And as Samuel turned around to go away, Saul seized the edge of his robe, and it tore.

28. So Samuel said to him, "The LORD has torn the kingdom of Israel from you today, and has given it to a neighbor of yours, who is better than you.

29. And also the Strength of Israel will not lie nor relent. For He is not a man, that He should relent."

30. Then he said, "I have sinned; yet honor me now, please, before the elders of my people and before Israel, and return with me, that I may worship the LORD your God."

31. So Samuel turned back after Saul, and Saul worshiped the LORD.

32. Then Samuel said, "Bring Agag king of the Amalekites here to me." So Agag came to him cautiously. And Agag said, "Surely the bitterness of death is past."

33. But Samuel said, "As your sword has made women childless, so shall your mother be childless among women." And Samuel hacked Agag in pieces before the LORD in Gilgal.

34. Then Samuel went to Ramah, and Saul went up to his house at Gibeah of Saul.

35. And Samuel went no more to see Saul until the day of his death. Nevertheless Samuel mourned for Saul, and the LORD regretted that He had made Saul king over Israel.

## Chapter 16

1. Now the LORD said to Samuel, "How long will you mourn for Saul, seeing I have rejected him from reigning over Israel? Fill your horn with oil, and go; I am sending you to Jesse the Bethlehemite. For I have provided Myself a king among his sons."

2. And Samuel said, "How can I go? If Saul hears it, he will kill me." But the LORD said, "Take a heifer with you, and say, "I have come to sacrifice to the LORD.'

3. Then invite Jesse to the sacrifice, and I will show you what you shall do; you shall anoint for Me the one I name to you."

4. So Samuel did what the LORD said, and went to Bethlehem. And the elders of the town trembled at his coming, and said, "Do you come peaceably?"

5. And he said, "Peaceably; I have come to sacrifice to the LORD. Sanctify yourselves, and come with me to the sacrifice." Then he consecrated Jesse and his sons, and invited them to the sacrifice.

6. So it was, when they came, that he looked at Eliab and said, "Surely the LORD's anointed is before Him!"

7. But the LORD said to Samuel, "Do not look at his appearance or at his physical stature, because I have refused him. For the LORD does not see as man sees; for man looks at the outward appearance, but the LORD looks at the heart."

8. So Jesse called Abinadab, and made him pass before Samuel. And he said, "Neither has the LORD chosen this one."

9. Then Jesse made Shammah pass by. And he said, "Neither has the LORD chosen this one."

10. Thus Jesse made seven of his sons pass before Samuel. And Samuel said to Jesse, "The LORD has not chosen these."

11. And Samuel said to Jesse, "Are all the young men here?" Then he said, "There remains yet the youngest, and there he is, keeping the sheep." And Samuel said to Jesse, "Send and bring him. For we will not sit down till he comes here."

12. So he sent and brought him in. Now he was ruddy, with bright eyes, and good-looking. And the LORD said, "Arise, anoint him; for this is the one!"

13. Then Samuel took the horn of oil and anointed him in the midst of his brothers; and the Spirit of the LORD came upon David from that day forward. So Samuel arose and went to Ramah.

14. But the Spirit of the LORD departed from Saul, and a distressing spirit from the LORD troubled him.

15. And Saul's servants said to him, "Surely, a distressing spirit from God is troubling you.

16. Let our master now command your servants, who are before you, to seek out a man who is a skillful player on the harp. And it shall be that he will play it with his hand when the distressing spirit from God is upon you, and you shall be well."

17. So Saul said to his servants, "Provide me now a man who can play well, and bring him to me."

18. Then one of the servants answered and said, "Look, I have seen a son of Jesse the Bethlehemite, who is skillful in playing, a mighty man of valor, a man of war, prudent in speech, and a handsome person; and the LORD is with him."

19. Therefore Saul sent messengers to Jesse, and said, "Send me your son David, who is with the sheep."

20. And Jesse took a donkey loaded with bread, a skin of wine, and a young goat, and sent them by his son David to Saul.

21. So David came to Saul and stood before him. And he loved him greatly, and he became his armorbearer.

22. Then Saul sent to Jesse, saying, "Please let David stand before me, for he has found favor in my sight."

23. And so it was, whenever the spirit from God was upon Saul, that David would take a harp and play it with his hand. Then Saul would become refreshed and well, and the distressing spirit would depart from him.

## Chapter 17

1. Now the Philistines gathered their armies together to battle, and were gathered at Sochoh, which belongs to Judah; they encamped between Sochoh and Azekah, in Ephes Dammim.

2. And Saul and the men of Israel were gathered together, and they encamped in the Valley of Elah, and drew up in battle array against the Philistines.

3. The Philistines stood on a mountain on one side, and Israel stood on a mountain on the other side, with a valley between them.

4. And a champion went out from the camp of the Philistines, named Goliath, from Gath, whose height was six cubits and a span.

5. He had a bronze helmet on his head, and he was armed with a coat of mail, and the weight of the coat was five thousand shekels of bronze.

6. And he had bronze armor on his legs and a bronze javelin between his shoulders.

7. Now the staff of his spear was like a weaver's beam, and his iron spearhead weighed six hundred shekels; and a shield-bearer went before him.

8. Then he stood and cried out to the armies of Israel, and said to them, "Why have you come out to line up for battle? Am I not a Philistine, and you the servants of Saul? Choose a man for yourselves, and let him come down to me.

9. If he is able to fight with me and kill me, then we will be your servants. But if I prevail against him and kill him, then you shall be our servants and serve us."

10. And the Philistine said, "I defy the armies of Israel this day; give me a man, that we may fight together."

11. When Saul and all Israel heard these words of the Philistine, they were dismayed and greatly afraid.

12. Now David was the son of that Ephrathite of Bethlehem Judah, whose name was Jesse, and who had eight sons. And the man was old, advanced in years, in the days of Saul.

13. The three oldest sons of Jesse had gone to follow Saul to the battle. The names of his three sons who went to the battle were Eliab the firstborn, next to him Abinadab, and the third Shammah.

14. David was the youngest. And the three oldest followed Saul.

15. But David occasionally went and returned from Saul to feed his father's sheep at Bethlehem.

16. And the Philistine drew near and presented himself forty days, morning and evening.

17. Then Jesse said to his son David, "Take now for your brothers an ephah of this dried grain and these ten loaves, and run to your brothers at the camp.

18. And carry these ten cheeses to the captain of their thousand, and see how your brothers fare, and bring back news of them."

19. Now Saul and they and all the men of Israel were in the Valley of Elah, fighting with the Philistines.

20. So David rose early in the morning, left the sheep with a keeper, and took the things and went as Jesse had commanded him. And he came to the camp as the army was going out to the fight and shouting for the battle.

21. For Israel and the Philistines had drawn up in battle array, army against army.

22. And David left his supplies in the hand of the supply keeper, ran to the army, and came and greeted his brothers.

23. Then as he talked with them, there was the champion, the Philistine of Gath, Goliath by name, coming up from the armies of the Philistines; and he spoke according to the same words. So David heard them.

24. And all the men of Israel, when they saw the man, fled from him and were dreadfully afraid.

25. So the men of Israel said, "Have you seen this man who has come up? Surely he has come up to defy Israel; and it shall be that the man who kills him the king will enrich with great riches, will give him his daughter, and give his father's house exemption from taxes in Israel."

26. Then David spoke to the men who stood by him, saying, "What shall be done for the man who kills this Philistine and takes away the reproach from Israel? For who is this uncircumcised Philistine, that he should defy the armies of the living God?"

27. And the people answered him in this manner, saying, "So shall it be done for the man who kills him."

28. Now Eliab his oldest brother heard when he spoke to the men; and Eliab's anger was aroused against David, and he said, "Why did you come down here? And with whom have you left those few sheep in the wilderness? I know your pride and the insolence of your heart, for you have come down to see the battle."

29. And David said, "What have I done now? Is there not a cause?"

30. Then he turned from him toward another and said the same thing; and these people answered him as the first ones did.

31. Now when the words which David spoke were heard, they reported them to Saul; and he sent for him.

32. Then David said to Saul, "Let no man's heart fail because of him; your servant will go and fight with this Philistine."

33. And Saul said to David, "You are not able to go against this Philistine to fight with him; for you are a youth, and he a man of war from his youth."

34. But David said to Saul, "Your servant used to keep his father's sheep, and when a lion or a bear came and took a lamb out of the flock,

35. I went out after it and struck it, and delivered the lamb from its mouth; and when it arose against me, I caught it by its beard, and struck and killed it.

36. Your servant has killed both lion and bear; and this uncircumcised Philistine will be like one of them, seeing he has defied the armies of the living God."

37. Moreover David said, "The LORD, who delivered me from the paw of the lion and from the paw of the bear, He will deliver me from the hand of this Philistine." And Saul said to David, "Go, and the LORD be with you!"

38. So Saul clothed David with his armor, and he put a bronze helmet on his head; he also clothed him with a coat of mail.

39. David fastened his sword to his armor and tried to walk, for he had not tested them. And David said to Saul, "I cannot walk with these, for I have not tested them." So David took them off.

40. Then he took his staff in his hand; and he chose for himself five smooth stones from the brook, and put them in a shepherd's bag, in a pouch which he had, and his sling was in his hand. And he drew near to the Philistine.

41. So the Philistine came, and began drawing near to David, and the man who bore the shield went before him.

42. And when the Philistine looked about and saw David, he disdained him; for he was only a youth, ruddy and good-looking.

43. So the Philistine said to David, "Am I a dog, that you come to me with sticks?" And the Philistine cursed David by his gods.

44. And the Philistine said to David, "Come to me, and I will give your flesh to the birds of the air and the beasts of the field!"

45. Then David said to the Philistine, "You come to me with a sword, with a spear, and with a javelin. But I come to you in the name of the LORD of hosts, the God of the armies of Israel, whom you have defied.

46. This day the LORD will deliver you into my hand, and I will strike you and take your head from you. And this day I will give the carcasses of the camp of the Philistines to the birds of the air and the wild beasts of the earth, that all the earth may know that there is a God in Israel.

47. Then all this assembly shall know that the LORD does not save with sword and spear; for the battle is the LORD's, and He will give you into our hands."

48. So it was, when the Philistine arose and came and drew near to meet David, that David hurried and ran toward the army to meet the Philistine.

49. Then David put his hand in his bag and took out a stone; and he slung it and struck the Philistine in his forehead, so that the stone sank into his forehead, and he fell on his face to the earth.

50. So David prevailed over the Philistine with a sling and a stone, and struck the Philistine and killed him. But there was no sword in the hand of David.

51. Therefore David ran and stood over the Philistine, took his sword and drew it out of its sheath and killed him, and cut off his head with it. And when the Philistines saw that their champion was dead, they fled.

52. Now the men of Israel and Judah arose and shouted, and pursued the Philistines as far as the entrance of the valley and to the gates of Ekron. And the wounded of the Philistines fell along the road to Shaaraim, even as far as Gath and Ekron.

53. Then the children of Israel returned from chasing the Philistines, and they plundered their tents.

54. And David took the head of the Philistine and brought it to Jerusalem, but he put his armor in his tent.

55. When Saul saw David going out against the Philistine, he said to Abner, the commander of the army, "Abner, whose son is this youth?" And Abner said, "As your soul lives, O king, I do not know."

56. So the king said, "Inquire whose son this young man is."

57. Then, as David returned from the slaughter of the Philistine, Abner took him and brought him before Saul with the head of the Philistine in his hand.

58. And Saul said to him, "Whose son are you, young man?" So David answered, "I am the son of your servant Jesse the Bethlehemite."

## Chapter 18

1. Now when he had finished speaking to Saul, the soul of Jonathan was knit to the soul of David, and Jonathan loved him as his own soul.

2. Saul took him that day, and would not let him go home to his father's house anymore.

3. Then Jonathan and David made a covenant, because he loved him as his own soul.

4. And Jonathan took off the robe that was on him and gave it to David, with his armor, even to his sword and his bow and his belt.

5. So David went out wherever Saul sent him, and behaved wisely. And Saul set him over the men of war, and he was accepted in the sight of all the people and also in the sight of Saul's servants.

6. Now it had happened as they were coming home, when David was returning from the slaughter of the Philistine, that the women had come out of all the cities of Israel, singing and dancing, to meet King Saul, with tambourines, with joy, and with musical instruments.

7. So the women sang as they danced, and said: "Saul has slain his thousands, And David his ten thousands."

8. Then Saul was very angry, and the saying displeased him; and he said, "They have ascribed to David ten thousands, and to me they have ascribed only thousands. Now what more can he have but the kingdom?"

9. So Saul eyed David from that day forward.

10. And it happened on the next day that the distressing spirit from God came upon Saul, and he prophesied inside the house. So David played music with his hand, as at other times; but there was a spear in Saul's hand.

11. And Saul cast the spear, for he said, "I will pin David to the wall!" But David escaped his presence twice.

12. Now Saul was afraid of David, because the LORD was with him, but had departed from Saul.

13. Therefore Saul removed him from his presence, and made him his captain over a thousand; and he went out and came in before the people.

14. And David behaved wisely in all his ways, and the LORD was with him.

15. Therefore, when Saul saw that he behaved very wisely, he was afraid of him.

16. But all Israel and Judah loved David, because he went out and came in before them.

17. Then Saul said to David, "Here is my older daughter Merab; I will give her to you as a wife. Only be valiant for me, and fight the LORD's battles." For Saul thought, "Let my hand not be against him, but let the hand of the Philistines be against him."

18. So David said to Saul, "Who am I, and what is my life or my father's family in Israel, that I should be son-in-law to the king?"

19. But it happened at the time when Merab, Saul's daughter, should have been given to David, that she was given to Adriel the Meholathite as a wife.

20. Now Michal, Saul's daughter, loved David. And they told Saul, and the thing pleased him.

21. So Saul said, "I will give her to him, that she may be a snare to him, and that the hand of the Philistines may be against him." Therefore Saul said to David a second time, "You shall be my son-in-law today."

22. And Saul commanded his servants, "Communicate with David secretly, and say, "Look, the king has delight in you, and all his servants love you. Now therefore, become the king's son-in-law."'

23. So Saul's servants spoke those words in the hearing of David. And David said, "Does it seem to you a light thing to be a king's son-in-law, seeing I am a poor and lightly esteemed man?"

24. And the servants of Saul told him, saying, "In this manner David spoke."

25. Then Saul said, "Thus you shall say to David: "The king does not desire any dowry but one hundred foreskins of the Philistines, to take vengeance on the king's enemies."' But Saul thought to make David fall by the hand of the Philistines.

26. So when his servants told David these words, it pleased David well to become the king's son-in-law. Now the days had not expired;

27. therefore David arose and went, he and his men, and killed two hundred men of the Philistines. And David brought their foreskins, and they gave them in full count to the king, that he might become the king's son-in-law. Then Saul gave him Michal his daughter as a wife.

28. Thus Saul saw and knew that the LORD was with David, and that Michal, Saul's daughter, loved him;

29. and Saul was still more afraid of David. So Saul became David's enemy continually.

30. Then the princes of the Philistines went out to war. And so it was, whenever they went out, that David behaved more wisely than all the servants of Saul, so that his name became highly esteemed.

## Chapter 19

1. Now Saul spoke to Jonathan his son and to all his servants, that they should kill David; but Jonathan, Saul's son, delighted greatly in David.

2. So Jonathan told David, saying, "My father Saul seeks to kill you. Therefore please be on your guard until morning, and stay in a secret place and hide.

3. And I will go out and stand beside my father in the field where you are, and I will speak with my father about you. Then what I observe, I will tell you."

4. Thus Jonathan spoke well of David to Saul his father, and said to him, "Let not the king sin against his servant, against David, because he has not sinned against you, and because his works have been very good toward you.

5. For he took his life in his hands and killed the Philistine, and the LORD brought about a great deliverance for all Israel. You saw it and rejoiced. Why then will you sin against innocent blood, to kill David without a cause?"

6. So Saul heeded the voice of Jonathan, and Saul swore, "As the LORD lives, he shall not be killed."

7. Then Jonathan called David, and Jonathan told him all these things. So Jonathan brought David to Saul, and he was in his presence as in times past.

8. And there was war again; and David went out and fought with the Philistines, and struck them with a mighty blow, and they fled from him.

9. Now the distressing spirit from the LORD came upon Saul as he sat in his house with his spear in his hand. And David was playing music with his hand.

10. Then Saul sought to pin David to the wall with the spear, but he slipped away from Saul's presence; and he drove the spear into the wall. So David fled and escaped that night.

11. Saul also sent messengers to David's house to watch him and to kill him in the morning. And Michal, David's wife, told him, saying, "If you do not save your life tonight, tomorrow you will be killed."

12. So Michal let David down through a window. And he went and fled and escaped.

13. And Michal took an image and laid it in the bed, put a cover of goats' hair for his head, and covered it with clothes.

14. So when Saul sent messengers to take David, she said, "He is sick."

15. Then Saul sent the messengers back to see David, saying, "Bring him up to me in the bed, that I may kill him."

16. And when the messengers had come in, there was the image in the bed, with a cover of goats' hair for his head.

17. Then Saul said to Michal, "Why have you deceived me like this, and sent my enemy away, so that he has escaped?" And Michal answered Saul, "He said to me, "Let me go! Why should I kill you?"'

18. So David fled and escaped, and went to Samuel at Ramah, and told him all that Saul had done to him. And he and Samuel went and stayed in Naioth.

19. Now it was told Saul, saying, "Take note, David is at Naioth in Ramah!"

20. Then Saul sent messengers to take David. And when they saw the group of prophets prophesying, and Samuel standing as leader over them, the Spirit of God came upon the messengers of Saul, and they also prophesied.

21. And when Saul was told, he sent other messengers, and they prophesied likewise. Then Saul sent messengers again the third time, and they prophesied also.

22. Then he also went to Ramah, and came to the great well that is at Sechu. So he asked, and said, "Where are Samuel and David?" And someone said, "Indeed they are at Naioth in Ramah."

23. So he went there to Naioth in Ramah. Then the Spirit of God was upon him also, and he went on and prophesied until he came to Naioth in Ramah.

24. And he also stripped off his clothes and prophesied before Samuel in like manner, and lay down naked all that day and all that night. Therefore they say, "Is Saul also among the prophets?"

## Chapter 20

1. Then David fled from Naioth in Ramah, and went and said to Jonathan, "What have I done? What is my iniquity, and what is my sin before your father, that he seeks my life?"

2. So Jonathan said to him, "By no means! You shall not die! Indeed, my father will do nothing either great or small without first telling me. And why should my father hide this thing from me? It is not so!"

3. Then David took an oath again, and said, "Your father certainly knows that I have found favor in your eyes, and he has said, "Do not let Jonathan know this, lest he be grieved.' But truly, as the LORD lives and as your soul lives, there is but a step between me and death."

4. So Jonathan said to David, "Whatever you yourself desire, I will do it for you."

5. And David said to Jonathan, "Indeed tomorrow is the New Moon, and I should not fail to sit with the king to eat. But let me go, that I may hide in the field until the third day at evening.

6. If your father misses me at all, then say, "David earnestly asked permission of me that he might run over to Bethlehem, his city, for there is a yearly sacrifice there for all the family.'

7. If he says thus: "It is well,' your servant will be safe. But if he is very angry, be sure that evil is determined by him.

8. Therefore you shall deal kindly with your servant, for you have brought your servant into a covenant of the LORD with you. Nevertheless, if there is iniquity in me, kill me yourself, for why should you bring me to your father?"

9. But Jonathan said, "Far be it from you! For if I knew certainly that evil was determined by my father to come upon you, then would I not tell you?"

10. Then David said to Jonathan, "Who will tell me, or what if your father answers you roughly?"

11. And Jonathan said to David, "Come, let us go out into the field." So both of them went out into the field.

12. Then Jonathan said to David: "The LORD God of Israel is witness! When I have sounded out my father sometime tomorrow, or the third day, and indeed there is good toward David, and I do not send to you and tell you,

13. may the LORD do so and much more to Jonathan. But if it pleases my father to do you evil, then I will report it to you and send you away, that you may go in safety. And the LORD be with you as He has been with my father.

14. And you shall not only show me the kindness of the LORD while I still live, that I may not die;

15. but you shall not cut off your kindness from my house forever, no, not when the LORD has cut off every one of the enemies of David from the face of the earth."

16. So Jonathan made a covenant with the house of David, saying, "Let the LORD require it at the hand of David's enemies."

17. Now Jonathan again caused David to vow, because he loved him; for he loved him as he loved his own soul.

18. Then Jonathan said to David, "Tomorrow is the New Moon; and you will be missed, because your seat will be empty.

19. And when you have stayed three days, go down quickly and come to the place where you hid on the day of the deed; and remain by the stone Ezel.

20. Then I will shoot three arrows to the side, as though I shot at a target;

21. and there I will send a lad, saying, "Go, find the arrows.' If I expressly say to the lad, "Look, the arrows are on this side of you; get them and come'--then, as the LORD lives, there is safety for you and no harm.

22. But if I say thus to the young man, "Look, the arrows are beyond you'--go your way, for the LORD has sent you away.

23. And as for the matter which you and I have spoken of, indeed the LORD be between you and me forever."

24. Then David hid in the field. And when the New Moon had come, the king sat down to eat the feast.

25. Now the king sat on his seat, as at other times, on a seat by the wall. And Jonathan arose, and Abner sat by Saul's side, but David's place was empty.

26. Nevertheless Saul did not say anything that day, for he thought, "Something has happened to him; he is unclean, surely he is unclean."

27. And it happened the next day, the second day of the month, that David's place was empty. And Saul said to Jonathan his son, "Why has the son of Jesse not come to eat, either yesterday or today?"

28. So Jonathan answered Saul, "David earnestly asked permission of me to go to Bethlehem.

29. And he said, "Please let me go, for our family has a sacrifice in the city, and my brother has commanded me to be there. And now, if I have found favor in your eyes, please let me get away and see my brothers.' Therefore he has not come to the king's table."

30. Then Saul's anger was aroused against Jonathan, and he said to him, "You son of a perverse, rebellious woman! Do I not know that you have chosen the son of Jesse to your own shame and to the shame of your mother's nakedness?

31. For as long as the son of Jesse lives on the earth, you shall not be established, nor your kingdom. Now therefore, send and bring him to me, for he shall surely die."

32. And Jonathan answered Saul his father, and said to him, "Why should he be killed? What has he done?"

33. Then Saul cast a spear at him to kill him, by which Jonathan knew that it was determined by his father to kill David.

34. So Jonathan arose from the table in fierce anger, and ate no food the second day of the month, for he was grieved for David, because his father had treated him shamefully.

35. And so it was, in the morning, that Jonathan went out into the field at the time appointed with David, and a little lad was with him.

36. Then he said to his lad, "Now run, find the arrows which I shoot." As the lad ran, he shot an arrow beyond him.

37. When the lad had come to the place where the arrow was which Jonathan had shot, Jonathan cried out after the lad and said, "Is not the arrow beyond you?"

38. And Jonathan cried out after the lad, "Make haste, hurry, do not delay!" So Jonathan's lad gathered up the arrows and came back to his master.

39. But the lad did not know anything. Only Jonathan and David knew of the matter.

40. Then Jonathan gave his weapons to his lad, and said to him, "Go, carry them to the city."

41. As soon as the lad had gone, David arose from a place toward the south, fell on his face to the ground, and bowed down three times. And they kissed one another; and they wept together, but David more so.

42. Then Jonathan said to David, "Go in peace, since we have both sworn in the name of the LORD, saying, "May the LORD be between you and me, and between your descendants and my descendants, forever."' So he arose and departed, and Jonathan went into the city.

## Chapter 21

1. Now David came to Nob, to Ahimelech the priest. And Ahimelech was afraid when he met David, and said to him, "Why are you alone, and no one is with you?"

2. So David said to Ahimelech the priest, "The king has ordered me on some business, and said to me, "Do not let anyone know anything about the business on which I send you, or what I have commanded you.' And I have directed my young men to such and such a place.

3. Now therefore, what have you on hand? Give me five loaves of bread in my hand, or whatever can be found."

4. And the priest answered David and said, "There is no common bread on hand; but there is holy bread, if the young men have at least kept themselves from women."

5. Then David answered the priest, and said to him, "Truly, women have been kept from us about three days since I came out. And the vessels of the young men are holy, and the bread is in effect common, even though it was consecrated in the vessel this day."

6. So the priest gave him holy bread; for there was no bread there but the showbread which had been taken from before the LORD, in order to put hot bread in its place on the day when it was taken away.

7. Now a certain man of the servants of Saul was there that day, detained before the LORD. And his name was Doeg, an Edomite, the chief of the herdsmen who belonged to Saul.

8. And David said to Ahimelech, "Is there not here on hand a spear or a sword? For I have brought neither my sword nor my weapons with me, because the king's business required haste."

9. So the priest said, "The sword of Goliath the Philistine, whom you killed in the Valley of Elah, there it is, wrapped in a cloth behind the ephod. If you will take that, take it. For there is no other except that one here." And David said, "There is none like it; give it to me."

10. Then David arose and fled that day from before Saul, and went to Achish the king of Gath.

11. And the servants of Achish said to him, "Is this not David the king of the land? Did they not sing of him to one another in dances, saying: "Saul has slain his thousands, And David his ten thousands'?"

12. Now David took these words to heart, and was very much afraid of Achish the king of Gath.

13. So he changed his behavior before them, pretended madness in their hands, scratched on the doors of the gate, and let his saliva fall down on his beard.

14. Then Achish said to his servants, "Look, you see the man is insane. Why have you brought him to me?

15. Have I need of madmen, that you have brought this fellow to play the madman in my presence? Shall this fellow come into my house?"

## Chapter 22

1. David therefore departed from there and escaped to the cave of Adullam. So when his brothers and all his father's house heard it, they went down there to him.

2. And everyone who was in distress, everyone who was in debt, and everyone who was discontented gathered to him. So he became captain over them. And there were about four hundred men with him.

3. Then David went from there to Mizpah of Moab; and he said to the king of Moab, "Please let my father and mother come here with you, till I know what God will do for me."

4. So he brought them before the king of Moab, and they dwelt with him all the time that David was in the stronghold.

5. Now the prophet Gad said to David, "Do not stay in the stronghold; depart, and go to the land of Judah." So David departed and went into the forest of Hereth.

6. When Saul heard that David and the men who were with him had been discovered--now Saul was staying in Gibeah under a tamarisk tree in Ramah, with his spear in his hand, and all his servants standing about him--

7. then Saul said to his servants who stood about him, "Hear now, you Benjamites! Will the son of Jesse give every one of you fields and vineyards, and make you all captains of thousands and captains of hundreds?

8. All of you have conspired against me, and there is no one who reveals to me that my son has made a covenant with the son of Jesse; and there is not one of you who is sorry for me or reveals to me that my son has stirred up my servant against me, to lie in wait, as it is this day."

9. Then answered Doeg the Edomite, who was set over the servants of Saul, and said, "I saw the son of Jesse going to Nob, to Ahimelech the son of Ahitub.

10. And he inquired of the LORD for him, gave him provisions, and gave him the sword of Goliath the Philistine."

11. So the king sent to call Ahimelech the priest, the son of Ahitub, and all his father's house, the priests who were in Nob. And they all came to the king.

12. And Saul said, "Hear now, son of Ahitub!" He answered, "Here I am, my lord."

13. Then Saul said to him, "Why have you conspired against me, you and the son of Jesse, in that you have given him bread and a sword, and have inquired of God for him, that he should rise against me, to lie in wait, as it is this day?"

14. So Ahimelech answered the king and said, "And who among all your servants is as faithful as David, who is the king's son-in-law, who goes at your bidding, and is honorable in your house?

15. Did I then begin to inquire of God for him? Far be it from me! Let not the king impute anything to his servant, or to any in the house of my father. For your servant knew nothing of all this, little or much."

16. And the king said, "You shall surely die, Ahimelech, you and all your father's house!"

17. Then the king said to the guards who stood about him, "Turn and kill the priests of the LORD, because their hand also is with David, and because they knew when he fled and did not tell it to me." But the servants of the king would not lift their hands to strike the priests of the LORD.

18. And the king said to Doeg, "You turn and kill the priests!" So Doeg the Edomite turned and struck the priests, and killed on that day eighty-five men who wore a linen ephod.

19. Also Nob, the city of the priests, he struck with the edge of the sword, both men and women, children and nursing infants, oxen and donkeys and sheep--with the edge of the sword.

20. Now one of the sons of Ahimelech the son of Ahitub, named Abiathar, escaped and fled after David.

21. And Abiathar told David that Saul had killed the LORD's priests.

22. So David said to Abiathar, "I knew that day, when Doeg the Edomite was there, that he would surely tell Saul. I have caused the death of all the persons of your father's house.

23. Stay with me; do not fear. For he who seeks my life seeks your life, but with me you shall be safe."

## Chapter 23

1. Then they told David, saying, "Look, the Philistines are fighting against Keilah, and they are robbing the threshing floors."

2. Therefore David inquired of the LORD, saying, "Shall I go and attack these Philistines?" And the LORD said to David, "Go and attack the Philistines, and save Keilah."

3. But David's men said to him, "Look, we are afraid here in Judah. How much more then if we go to Keilah against the armies of the Philistines?"

4. Then David inquired of the LORD once again. And the LORD answered him and said, "Arise, go down to Keilah. For I will deliver the Philistines into your hand."

5. And David and his men went to Keilah and fought with the Philistines, struck them with a mighty blow, and took away their livestock. So David saved the inhabitants of Keilah.

6. Now it happened, when Abiathar the son of Ahimelech fled to David at Keilah, that he went down with an ephod in his hand.

7. And Saul was told that David had gone to Keilah. So Saul said, "God has delivered him into my hand, for he has shut himself in by entering a town that has gates and bars."

8. Then Saul called all the people together for war, to go down to Keilah to besiege David and his men.

9. When David knew that Saul plotted evil against him, he said to Abiathar the priest, "Bring the ephod here."

10. Then David said, "O LORD God of Israel, Your servant has certainly heard that Saul seeks to come to Keilah to destroy the city for my sake.

11. Will the men of Keilah deliver me into his hand? Will Saul come down, as Your servant has heard? O LORD God of Israel, I pray, tell Your servant." And the LORD said, "He will come down."

12. Then David said, "Will the men of Keilah deliver me and my men into the hand of Saul?" And the LORD said, "They will deliver you."

13. So David and his men, about six hundred, arose and departed from Keilah and went wherever they could go. Then it was told Saul that David had escaped from Keilah; so he halted the expedition.

14. And David stayed in strongholds in the wilderness, and remained in the mountains in the Wilderness of Ziph. Saul sought him every day, but God did not deliver him into his hand.

15. So David saw that Saul had come out to seek his life. And David was in the Wilderness of Ziph in a forest.

16. Then Jonathan, Saul's son, arose and went to David in the woods and strengthened his hand in God.

17. And he said to him, "Do not fear, for the hand of Saul my father shall not find you. You shall be king over Israel, and I shall be next to you. Even my father Saul knows that."

18. So the two of them made a covenant before the LORD. And David stayed in the woods, and Jonathan went to his own house.

19. Then the Ziphites came up to Saul at Gibeah, saying, "Is David not hiding with us in strongholds in the woods, in the hill of Hachilah, which is on the south of Jeshimon?

20. Now therefore, O king, come down according to all the desire of your soul to come down; and our part shall be to deliver him into the king's hand."

21. And Saul said, "Blessed are you of the LORD, for you have compassion on me.

22. Please go and find out for sure, and see the place where his hideout is, and who has seen him there. For I am told he is very crafty.

23. See therefore, and take knowledge of all the lurking places where he hides; and come back to me with certainty, and I will go with you. And it shall be, if he is in the land, that I will search for him throughout all the clans of Judah."

24. So they arose and went to Ziph before Saul. But David and his men were in the Wilderness of Maon, in the plain on the south of Jeshimon.

25. When Saul and his men went to seek him, they told David. Therefore he went down to the rock, and stayed in the Wilderness of Maon. And when Saul heard that, he pursued David in the Wilderness of Maon.

26. Then Saul went on one side of the mountain, and David and his men on the other side of the mountain. So David made haste to get away from Saul, for Saul and his men were encircling David and his men to take them.

27. But a messenger came to Saul, saying, "Hurry and come, for the Philistines have invaded the land!"

28. Therefore Saul returned from pursuing David, and went against the Philistines; so they called that place the Rock of Escape.

29. Then David went up from there and dwelt in strongholds at En Gedi.

## Chapter 24

1. Now it happened, when Saul had returned from following the Philistines, that it was told him, saying, "Take note! David is in the Wilderness of En Gedi."

2. Then Saul took three thousand chosen men from all Israel, and went to seek David and his men on the Rocks of the Wild Goats.

3. So he came to the sheepfolds by the road, where there was a cave; and Saul went in to attend to his needs. (David and his men were staying in the recesses of the cave.)

4. Then the men of David said to him, "This is the day of which the LORD said to you, "Behold, I will deliver your enemy into your hand, that you may do to him as it seems good to you."' And David arose and secretly cut off a corner of Saul's robe.

5. Now it happened afterward that David's heart troubled him because he had cut Saul's robe.

6. And he said to his men, "The LORD forbid that I should do this thing to my master, the LORD's anointed, to stretch out my hand against him, seeing he is the anointed of the LORD."

7. So David restrained his servants with these words, and did not allow them to rise against Saul. And Saul got up from the cave and went on his way.

8. David also arose afterward, went out of the cave, and called out to Saul, saying, "My lord the king!" And when Saul looked behind him, David stooped with his face to the earth, and bowed down.

9. And David said to Saul: "Why do you listen to the words of men who say, "Indeed David seeks your harm'?

10. Look, this day your eyes have seen that the LORD delivered you today into my hand in the cave, and someone urged me to kill you. But my eye spared you, and I said, "I will not stretch out my hand against my lord, for he is the LORD's anointed.'

11. Moreover, my father, see! Yes, see the corner of your robe in my hand! For in that I cut off the corner of your robe, and did not kill you, know and see that there is neither evil nor rebellion in my hand, and I have not sinned against you. Yet you hunt my life to take it.

12. Let the LORD judge between you and me, and let the LORD avenge me on you. But my hand shall not be against you.

13. As the proverb of the ancients says, "Wickedness proceeds from the wicked.' But my hand shall not be against you.

14. After whom has the king of Israel come out? Whom do you pursue? A dead dog? A flea?

15. Therefore let the LORD be judge, and judge between you and me, and see and plead my case, and deliver me out of your hand."

16. So it was, when David had finished speaking these words to Saul, that Saul said, "Is this your voice, my son David?" And Saul lifted up his voice and wept.

17. Then he said to David: "You are more righteous than I; for you have rewarded me with good, whereas I have rewarded you with evil.

18. And you have shown this day how you have dealt well with me; for when the LORD delivered me into your hand, you did not kill me.

19. For if a man finds his enemy, will he let him get away safely? Therefore may the LORD reward you with good for what you have done to me this day.

20. And now I know indeed that you shall surely be king, and that the kingdom of Israel shall be established in your hand.

21. Therefore swear now to me by the LORD that you will not cut off my descendants after me, and that you will not destroy my name from my father's house."

22. So David swore to Saul. And Saul went home, but David and his men went up to the stronghold.

## Chapter 25

1. Then Samuel died; and the Israelites gathered together and lamented for him, and buried him at his home in Ramah. And David arose and went down to the Wilderness of Paran.

2. Now there was a man in Maon whose business was in Carmel, and the man was very rich. He had three thousand sheep and a thousand goats. And he was shearing his sheep in Carmel.

3. The name of the man was Nabal, and the name of his wife Abigail. And she was a woman of good understanding and beautiful appearance; but the man was harsh and evil in his doings. He was of the house of Caleb.

4. When David heard in the wilderness that Nabal was shearing his sheep,

5. David sent ten young men; and David said to the young men, "Go up to Carmel, go to Nabal, and greet him in my name.

6. And thus you shall say to him who lives in prosperity: "Peace be to you, peace to your house, and peace to all that you have!

7. Now I have heard that you have shearers. Your shepherds were with us, and we did not hurt them, nor was there anything missing from them all the while they were in Carmel.

8. Ask your young men, and they will tell you. Therefore let my young men find favor in your eyes, for we come on a feast day. Please give whatever comes to your hand to your servants and to your son David."'

9. So when David's young men came, they spoke to Nabal according to all these words in the name of David, and waited.

10. Then Nabal answered David's servants, and said, "Who is David, and who is the son of Jesse? There are many servants nowadays who break away each one from his master.

11. Shall I then take my bread and my water and my meat that I have killed for my shearers, and give it to men when I do not know where they are from?"

12. So David's young men turned on their heels and went back; and they came and told him all these words.

13. Then David said to his men, "Every man gird on his sword." So every man girded on his sword, and David also girded on his sword. And about four hundred men went with David, and two hundred stayed with the supplies.

14. Now one of the young men told Abigail, Nabal's wife, saying, "Look, David sent messengers from the wilderness to greet our master; and he reviled them.

15. But the men were very good to us, and we were not hurt, nor did we miss anything as long as we accompanied them, when we were in the fields.

16. They were a wall to us both by night and day, all the time we were with them keeping the sheep.

17. Now therefore, know and consider what you will do, for harm is determined against our master and against all his household. For he is such a scoundrel that one cannot speak to him."

18. Then Abigail made haste and took two hundred loaves of bread, two skins of wine, five sheep already dressed, five seahs of roasted grain, one hundred clusters of raisins, and two hundred cakes of figs, and loaded them on donkeys.

19. And she said to her servants, "Go on before me; see, I am coming after you." But she did not tell her husband Nabal.

20. So it was, as she rode on the donkey, that she went down under cover of the hill; and there were David and his men, coming down toward her, and she met them.

21. Now David had said, "Surely in vain I have protected all that this fellow has in the wilderness, so that nothing was missed of all that belongs to him. And he has repaid me evil for good.

22. May God do so, and more also, to the enemies of David, if I leave one male of all who belong to him by morning light."

23. Now when Abigail saw David, she dismounted quickly from the donkey, fell on her face before David, and bowed down to the ground.

24. So she fell at his feet and said: "On me, my lord, on me let this iniquity be! And please let your maidservant speak in your ears, and hear the words of your maidservant.

25. Please, let not my lord regard this scoundrel Nabal. For as his name is, so is he: Nabal is his name, and folly is with him! But I, your maidservant, did not see the young men of my lord whom you sent.

26. Now therefore, my lord, as the LORD lives and as your soul lives, since the LORD has held you back from coming to bloodshed and from avenging yourself with your own hand, now then, let your enemies and those who seek harm for my lord be as Nabal.

27. And now this present which your maidservant has brought to my lord, let it be given to the young men who follow my lord.

28. Please forgive the trespass of your maidservant. For the LORD will certainly make for my lord an enduring house, because my lord fights the battles of the LORD, and evil is not found in you throughout your days.

29. Yet a man has risen to pursue you and seek your life, but the life of my lord shall be bound in the bundle of the living with the LORD your God; and the lives of your enemies He shall sling out, as from the pocket of a sling.

30. And it shall come to pass, when the LORD has done for my lord according to all the good that He has spoken concerning you, and has appointed you ruler over Israel,

31. that this will be no grief to you, nor offense of heart to my lord, either that you have shed blood without cause, or that my lord has avenged himself. But when the LORD has dealt well with my lord, then remember your maidservant."

32. Then David said to Abigail: "Blessed is the LORD God of Israel, who sent you this day to meet me!

33. And blessed is your advice and blessed are you, because you have kept me this day from coming to bloodshed and from avenging myself with my own hand.

34. For indeed, as the LORD God of Israel lives, who has kept me back from hurting you, unless you had hurried and come to meet me, surely by morning light no males would have been left to Nabal!"

35. So David received from her hand what she had brought him, and said to her, "Go up in peace to your house. See, I have heeded your voice and respected your person."

36. Now Abigail went to Nabal, and there he was, holding a feast in his house, like the feast of a king. And Nabal's heart was merry within him, for he was very drunk; therefore she told him nothing, little or much, until morning light.

37. So it was, in the morning, when the wine had gone from Nabal, and his wife had told him these things, that his heart died within him, and he became like a stone.

38. Then it happened, after about ten days, that the LORD struck Nabal, and he died.

39. So when David heard that Nabal was dead, he said, "Blessed be the LORD, who has pleaded the cause of my reproach from the hand of Nabal, and has kept His servant from evil! For the LORD has returned the wickedness of Nabal on his own head." And David sent and proposed to Abigail, to take her as his wife.

40. When the servants of David had come to Abigail at Carmel, they spoke to her saying, "David sent us to you, to ask you to become his wife."

41. Then she arose, bowed her face to the earth, and said, "Here is your maidservant, a servant to wash the feet of the servants of my lord."

42. So Abigail rose in haste and rode on a donkey, attended by five of her maidens; and she followed the messengers of David, and became his wife.

43. David also took Ahinoam of Jezreel, and so both of them were his wives.

44. But Saul had given Michal his daughter, David's wife, to Palti the son of Laish, who was from Gallim.

## Chapter 26

1. Now the Ziphites came to Saul at Gibeah, saying, "Is David not hiding in the hill of Hachilah, opposite Jeshimon?"

2. Then Saul arose and went down to the Wilderness of Ziph, having three thousand chosen men of Israel with him, to seek David in the Wilderness of Ziph.

3. And Saul encamped in the hill of Hachilah, which is opposite Jeshimon, by the road. But David stayed in the wilderness, and he saw that Saul came after him into the wilderness.

4. David therefore sent out spies, and understood that Saul had indeed come.

5. So David arose and came to the place where Saul had encamped. And David saw the place where Saul lay, and Abner the son of Ner, the commander of his army. Now Saul lay within the camp, with the people encamped all around him.

6. Then David answered, and said to Ahimelech the Hittite and to Abishai the son of Zeruiah, brother of Joab, saying, "Who will go down with me to Saul in the camp?" And Abishai said, "I will go down with you."

7. So David and Abishai came to the people by night; and there Saul lay sleeping within the camp, with his spear stuck in the ground by his head. And Abner and the people lay all around him.

8. Then Abishai said to David, "God has delivered your enemy into your hand this day. Now therefore, please, let me strike him at once with the spear, right to the earth; and I will not have to strike him a second time!"

9. But David said to Abishai, "Do not destroy him; for who can stretch out his hand against the LORD's anointed, and be guiltless?"

10. David said furthermore, "As the LORD lives, the LORD shall strike him, or his day shall come to die, or he shall go out to battle and perish.

11. The LORD forbid that I should stretch out my hand against the LORD's anointed. But please, take now the spear and the jug of water that are by his head, and let us go."

12. So David took the spear and the jug of water by Saul's head, and they got away; and no man saw or knew it or awoke. For they were all asleep, because a deep sleep from the LORD had fallen on them.

13. Now David went over to the other side, and stood on the top of a hill afar off, a great distance being between them.

14. And David called out to the people and to Abner the son of Ner, saying, "Do you not answer, Abner?" Then Abner answered and said, "Who are you, calling out to the king?"

15. So David said to Abner, "Are you not a man? And who is like you in Israel? Why then have you not guarded your lord the king? For one of the people came in to destroy your lord the king.

16. This thing that you have done is not good. As the LORD lives, you deserve to die, because you have not guarded your master, the LORD's anointed. And now see where the king's spear is, and the jug of water that was by his head."

17. Then Saul knew David's voice, and said, "Is that your voice, my son David?" David said, "It is my voice, my lord, O king."

18. And he said, "Why does my lord thus pursue his servant? For what have I done, or what evil is in my hand?

19. Now therefore, please, let my lord the king hear the words of his servant: If the LORD has stirred you up against me, let Him accept an offering. But if it is the children of men, may they be cursed before the LORD, for they have driven me out this day from sharing in the inheritance of the LORD, saying, "Go, serve other gods.'

20. So now, do not let my blood fall to the earth before the face of the LORD. For the king of Israel has come out to seek a flea, as when one hunts a partridge in the mountains."

21. Then Saul said, "I have sinned. Return, my son David. For I will harm you no more, because my life was precious in your eyes this day. Indeed I have played the fool and erred exceedingly."

22. And David answered and said, "Here is the king's spear. Let one of the young men come over and get it.

23. May the LORD repay every man for his righteousness and his faithfulness; for the LORD delivered you into my hand today, but I would not stretch out my hand against the LORD's anointed.

24. And indeed, as your life was valued much this day in my eyes, so let my life be valued much in the eyes of the LORD, and let Him deliver me out of all tribulation."

25. Then Saul said to David, "May you be blessed, my son David! You shall both do great things and also still prevail." So David went on his way, and Saul returned to his place.

## Chapter 27

1. And David said in his heart, "Now I shall perish someday by the hand of Saul. There is nothing better for me than that I should speedily escape to the land of the Philistines; and Saul will despair of me, to seek me anymore in any part of Israel. So I shall escape out of his hand."

2. Then David arose and went over with the six hundred men who were with him to Achish the son of Maoch, king of Gath.

3. So David dwelt with Achish at Gath, he and his men, each man with his household, and David with his two wives, Ahinoam the Jezreelitess, and Abigail the Carmelitess, Nabal's widow.

4. And it was told Saul that David had fled to Gath; so he sought him no more.

5. Then David said to Achish, "If I have now found favor in your eyes, let them give me a place in some town in the country, that I may dwell there. For why should your servant dwell in the royal city with you?"

6. So Achish gave him Ziklag that day. Therefore Ziklag has belonged to the kings of Judah to this day.

7. Now the time that David dwelt in the country of the Philistines was one full year and four months.

8. And David and his men went up and raided the Geshurites, the Girzites, and the Amalekites. For those nations were the inhabitants of the land from of old, as you go to Shur, even as far as the land of Egypt.

9. Whenever David attacked the land, he left neither man nor woman alive, but took away the sheep, the oxen, the donkeys, the camels, and the apparel, and returned and came to Achish.

10. Then Achish would say, "Where have you made a raid today?" And David would say, "Against the southern area of Judah, or against the southern area of the Jerahmeelites, or against the southern area of the Kenites."

11. David would save neither man nor woman alive, to bring news to Gath, saying, "Lest they should inform on us, saying, "Thus David did."' And thus was his behavior all the time he dwelt in the country of the Philistines.

12. So Achish believed David, saying, "He has made his people Israel utterly abhor him; therefore he will be my servant forever."

## Chapter 28

1. Now it happened in those days that the Philistines gathered their armies together for war, to fight with Israel. And Achish said to David, "You assuredly know that you will go out with me to battle, you and your men."

2. So David said to Achish, "Surely you know what your servant can do." And Achish said to David, "Therefore I will make you one of my chief guardians forever."

3. Now Samuel had died, and all Israel had lamented for him and buried him in Ramah, in his own city. And Saul had put the mediums and the spiritists out of the land.

4. Then the Philistines gathered together, and came and encamped at Shunem. So Saul gathered all Israel together, and they encamped at Gilboa.

5. When Saul saw the army of the Philistines, he was afraid, and his heart trembled greatly.

6. And when Saul inquired of the LORD, the LORD did not answer him, either by dreams or by Urim or by the prophets.

7. Then Saul said to his servants, "Find me a woman who is a medium, that I may go to her and inquire of her." And his servants said to him, "In fact, there is a woman who is a medium at En Dor."

8. So Saul disguised himself and put on other clothes, and he went, and two men with him; and they came to the woman by night. And he said, "Please conduct a s^eaance for me, and bring up for me the one I shall name to you."

9. Then the woman said to him, "Look, you know what Saul has done, how he has cut off the mediums and the spiritists from the land. Why then do you lay a snare for my life, to cause me to die?"

10. And Saul swore to her by the LORD, saying, "As the LORD lives, no punishment shall come upon you for this thing."

11. Then the woman said, "Whom shall I bring up for you?" And he said, "Bring up Samuel for me."

12. When the woman saw Samuel, she cried out with a loud voice. And the woman spoke to Saul, saying, "Why have you deceived me? For you are Saul!"

13. And the king said to her, "Do not be afraid. What did you see?" And the woman said to Saul, "I saw a spirit ascending out of the earth."

14. So he said to her, "What is his form?" And she said, "An old man is coming up, and he is covered with a mantle." And Saul perceived that it was Samuel, and he stooped with his face to the ground and bowed down.

15. Now Samuel said to Saul, "Why have you disturbed me by bringing me up?" And Saul answered, "I am deeply distressed; for the Philistines make war against me, and God has departed from me and does not answer me anymore, neither by prophets nor by dreams. Therefore I have called you, that you may reveal to me what I should do."

16. Then Samuel said: "So why do you ask me, seeing the LORD has departed from you and has become your enemy?

17. And the LORD has done for Himself as He spoke by me. For the LORD has torn the kingdom out of your hand and given it to your neighbor, David.

18. Because you did not obey the voice of the LORD nor execute His fierce wrath upon Amalek, therefore the LORD has done this thing to you this day.

19. Moreover the LORD will also deliver Israel with you into the hand of the Philistines. And tomorrow you and your sons will be with me. The LORD will also deliver the army of Israel into the hand of the Philistines."

20. Immediately Saul fell full length on the ground, and was dreadfully afraid because of the words of Samuel. And there was no strength in him, for he had eaten no food all day or all night.

21. And the woman came to Saul and saw that he was severely troubled, and said to him, "Look, your maidservant has obeyed your voice, and I have put my life in my hands and heeded the words which you spoke to me.

22. Now therefore, please, heed also the voice of your maidservant, and let me set a piece of bread before you; and eat, that you may have strength when you go on your way."

23. But he refused and said, "I will not eat." So his servants, together with the woman, urged him; and he heeded their voice. Then he arose from the ground and sat on the bed.

24. Now the woman had a fatted calf in the house, and she hastened to kill it. And she took flour and kneaded it, and baked unleavened bread from it.

25. So she brought it before Saul and his servants, and they ate. Then they rose and went away that night.

## Chapter 29

1. Then the Philistines gathered together all their armies at Aphek, and the Israelites encamped by a fountain which is in Jezreel.

2. And the lords of the Philistines passed in review by hundreds and by thousands, but David and his men passed in review at the rear with Achish.

3. Then the princes of the Philistines said, "What are these Hebrews doing here?" And Achish said to the princes of the Philistines, "Is this not David, the servant of Saul king of Israel, who has been with me these days, or these years? And to this day I have found no fault in him since he defected to me."

4. But the princes of the Philistines were angry with him; so the princes of the Philistines said to him, "Make this fellow return, that he may go back to the place which you have appointed for him, and do not let him go down with us to battle, lest in the battle he become our adversary. For with what could he reconcile himself to his master, if not with the heads of these men?

5. Is this not David, of whom they sang to one another in dances, saying: "Saul has slain his thousands, And David his ten thousands'?"

6. Then Achish called David and said to him, "Surely, as the LORD lives, you have been upright, and your going out and your coming in with me in the army is good in my sight. For to this day I have not found evil in you since the day of your coming to me. Nevertheless the lords do not favor you.

7. Therefore return now, and go in peace, that you may not displease the lords of the Philistines."

8. So David said to Achish, "But what have I done? And to this day what have you found in your servant as long as I have been with you, that I may not go and fight against the enemies of my lord the king?"

9. Then Achish answered and said to David, "I know that you are as good in my sight as an angel of God; nevertheless the princes of the Philistines have said, "He shall not go up with us to the battle.'

10. Now therefore, rise early in the morning with your master's servants who have come with you. And as soon as you are up early in the morning and have light, depart."

11. So David and his men rose early to depart in the morning, to return to the land of the Philistines. And the Philistines went up to Jezreel.

## Chapter 30

1. Now it happened, when David and his men came to Ziklag, on the third day, that the Amalekites had invaded the South and Ziklag, attacked Ziklag and burned it with fire,

2. and had taken captive the women and those who were there, from small to great; they did not kill anyone, but carried them away and went their way.

3. So David and his men came to the city, and there it was, burned with fire; and their wives, their sons, and their daughters had been taken captive.

4. Then David and the people who were with him lifted up their voices and wept, until they had no more power to weep.

5. And David's two wives, Ahinoam the Jezreelitess, and Abigail the widow of Nabal the Carmelite, had been taken captive.

6. Now David was greatly distressed, for the people spoke of stoning him, because the soul of all the people was grieved, every man for his sons and his daughters. But David strengthened himself in the LORD his God.

7. Then David said to Abiathar the priest, Ahimelech's son, "Please bring the ephod here to me." And Abiathar brought the ephod to David.

8. So David inquired of the LORD, saying, "Shall I pursue this troop? Shall I overtake them?" And He answered him, "Pursue, for you shall surely overtake them and without fail recover all."

9. So David went, he and the six hundred men who were with him, and came to the Brook Besor, where those stayed who were left behind.

10. But David pursued, he and four hundred men; for two hundred stayed behind, who were so weary that they could not cross the Brook Besor.

11. Then they found an Egyptian in the field, and brought him to David; and they gave him bread and he ate, and they let him drink water.

12. And they gave him a piece of a cake of figs and two clusters of raisins. So when he had eaten, his strength came back to him; for he had eaten no bread nor drunk water for three days and three nights.

13. Then David said to him, "To whom do you belong, and where are you from?" And he said, "I am a young man from Egypt, servant of an Amalekite; and my master left me behind, because three days ago I fell sick.

14. We made an invasion of the southern area of the Cherethites, in the territory which belongs to Judah, and of the southern area of Caleb; and we burned Ziklag with fire."

15. And David said to him, "Can you take me down to this troop?" So he said, "Swear to me by God that you will neither kill me nor deliver me into the hands of my master, and I will take you down to this troop."

16. And when he had brought him down, there they were, spread out over all the land, eating and drinking and dancing, because of all the great spoil which they had taken from the land of the Philistines and from the land of Judah.

17. Then David attacked them from twilight until the evening of the next day. Not a man of them escaped, except four hundred young men who rode on camels and fled.

18. So David recovered all that the Amalekites had carried away, and David rescued his two wives.

19. And nothing of theirs was lacking, either small or great, sons or daughters, spoil or anything which they had taken from them; David recovered all.

20. Then David took all the flocks and herds they had driven before those other livestock, and said, "This is David's spoil."

21. Now David came to the two hundred men who had been so weary that they could not follow David, whom they also had made to stay at the Brook Besor. So they went out to meet David and to meet the people who were with him. And when David came near the people, he greeted them.

22. Then all the wicked and worthless men of those who went with David answered and said, "Because they did not go with us, we will not give them any of the spoil that we have recovered, except for every man's wife and children, that they may lead them away and depart."

23. But David said, "My brethren, you shall not do so with what the LORD has given us, who has preserved us and delivered into our hand the troop that came against us.

24. For who will heed you in this matter? But as his part is who goes down to the battle, so shall his part be who stays by the supplies; they shall share alike."

25. So it was, from that day forward; he made it a statute and an ordinance for Israel to this day.

26. Now when David came to Ziklag, he sent some of the spoil to the elders of Judah, to his friends, saying, "Here is a present for you from the spoil of the enemies of the LORD"--

27. to those who were in Bethel, those who were in Ramoth of the South, those who were in Jattir,

28. those who were in Aroer, those who were in Siphmoth, those who were in Eshtemoa,

29. those who were in Rachal, those who were in the cities of the Jerahmeelites, those who were in the cities of the Kenites,

30. those who were in Hormah, those who were in Chorashan, those who were in Athach,

31. those who were in Hebron, and to all the places where David himself and his men were accustomed to rove.

## Chapter 31

1. Now the Philistines fought against Israel; and the men of Israel fled from before the Philistines, and fell slain on Mount Gilboa.

2. Then the Philistines followed hard after Saul and his sons. And the Philistines killed Jonathan, Abinadab, and Malchishua, Saul's sons.

3. The battle became fierce against Saul. The archers hit him, and he was severely wounded by the archers.

4. Then Saul said to his armorbearer, "Draw your sword, and thrust me through with it, lest these uncircumcised men come and thrust me through and abuse me." But his armorbearer would not, for he was greatly afraid. Therefore Saul took a sword and fell on it.

5. And when his armorbearer saw that Saul was dead, he also fell on his sword, and died with him.

6. So Saul, his three sons, his armorbearer, and all his men died together that same day.

7. And when the men of Israel who were on the other side of the valley, and those who were on the other side of the Jordan, saw that the men of Israel had fled and that Saul and his sons were dead, they forsook the cities and fled; and the Philistines came and dwelt in them.

8. So it happened the next day, when the Philistines came to strip the slain, that they found Saul and his three sons fallen on Mount Gilboa.

9. And they cut off his head and stripped off his armor, and sent word throughout the land of the Philistines, to proclaim it in the temple of their idols and among the people.

10. Then they put his armor in the temple of the Ashtoreths, and they fastened his body to the wall of Beth Shan.

11. Now when the inhabitants of Jabesh Gilead heard what the Philistines had done to Saul,

12. all the valiant men arose and traveled all night, and took the body of Saul and the bodies of his sons from the wall of Beth Shan; and they came to Jabesh and burned them there.

13. Then they took their bones and buried them under the tamarisk tree at Jabesh, and fasted seven days.


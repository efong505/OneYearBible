# 2-john

## Chapter 1

1. The Elder, To the elect lady and her children, whom I love in truth, and not only I, but also all those who have known the truth,

2. because of the truth which abides in us and will be with us forever:

3. Grace, mercy, and peace will be with you from God the Father and from the Lord Jesus Christ, the Son of the Father, in truth and love.

4. I rejoiced greatly that I have found some of your children walking in truth, as we received commandment from the Father.

5. And now I plead with you, lady, not as though I wrote a new commandment to you, but that which we have had from the beginning: that we love one another.

6. This is love, that we walk according to His commandments. This is the commandment, that as you have heard from the beginning, you should walk in it.

7. For many deceivers have gone out into the world who do not confess Jesus Christ as coming in the flesh. This is a deceiver and an antichrist.

8. Look to yourselves, that we do not lose those things we worked for, but that we may receive a full reward.

9. Whoever transgresses and does not abide in the doctrine of Christ does not have God. He who abides in the doctrine of Christ has both the Father and the Son.

10. If anyone comes to you and does not bring this doctrine, do not receive him into your house nor greet him;

11. for he who greets him shares in his evil deeds.

12. Having many things to write to you, I did not wish to do so with paper and ink; but I hope to come to you and speak face to face, that our joy may be full.

13. The children of your elect sister greet you. Amen.


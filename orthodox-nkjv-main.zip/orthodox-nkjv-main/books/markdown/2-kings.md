# 2-kings

## Chapter 1

1. Moab rebelled against Israel after the death of Ahab.

2. Now Ahaziah fell through the lattice of his upper room in Samaria, and was injured; so he sent messengers and said to them, "Go, inquire of Baal-Zebub, the god of Ekron, whether I shall recover from this injury."

3. But the angel of the LORD said to Elijah the Tishbite, "Arise, go up to meet the messengers of the king of Samaria, and say to them, "Is it because there is no God in Israel that you are going to inquire of Baal-Zebub, the god of Ekron?'

4. Now therefore, thus says the LORD: "You shall not come down from the bed to which you have gone up, but you shall surely die."' So Elijah departed.

5. And when the messengers returned to him, he said to them, "Why have you come back?"

6. So they said to him, "A man came up to meet us, and said to us, "Go, return to the king who sent you, and say to him, "Thus says the LORD: "Is it because there is no God in Israel that you are sending to inquire of Baal-Zebub, the god of Ekron? Therefore you shall not come down from the bed to which you have gone up, but you shall surely die."""

7. Then he said to them, "What kind of man was it who came up to meet you and told you these words?"

8. So they answered him, "A hairy man wearing a leather belt around his waist." And he said, "It is Elijah the Tishbite."

9. Then the king sent to him a captain of fifty with his fifty men. So he went up to him; and there he was, sitting on the top of a hill. And he spoke to him: "Man of God, the king has said, "Come down!"'

10. So Elijah answered and said to the captain of fifty, "If I am a man of God, then let fire come down from heaven and consume you and your fifty men." And fire came down from heaven and consumed him and his fifty.

11. Then he sent to him another captain of fifty with his fifty men. And he answered and said to him: "Man of God, thus has the king said, "Come down quickly!"'

12. So Elijah answered and said to them, "If I am a man of God, let fire come down from heaven and consume you and your fifty men." And the fire of God came down from heaven and consumed him and his fifty.

13. Again, he sent a third captain of fifty with his fifty men. And the third captain of fifty went up, and came and fell on his knees before Elijah, and pleaded with him, and said to him: "Man of God, please let my life and the life of these fifty servants of yours be precious in your sight.

14. Look, fire has come down from heaven and burned up the first two captains of fifties with their fifties. But let my life now be precious in your sight."

15. And the angel of the LORD said to Elijah, "Go down with him; do not be afraid of him." So he arose and went down with him to the king.

16. Then he said to him, "Thus says the LORD: "Because you have sent messengers to inquire of Baal-Zebub, the god of Ekron, is it because there is no God in Israel to inquire of His word? Therefore you shall not come down from the bed to which you have gone up, but you shall surely die."'

17. So Ahaziah died according to the word of the LORD which Elijah had spoken. Because he had no son, Jehoram became king in his place, in the second year of Jehoram the son of Jehoshaphat, king of Judah.

18. Now the rest of the acts of Ahaziah which he did, are they not written in the book of the chronicles of the kings of Israel?

## Chapter 2

1. And it came to pass, when the LORD was about to take up Elijah into heaven by a whirlwind, that Elijah went with Elisha from Gilgal.

2. Then Elijah said to Elisha, "Stay here, please, for the LORD has sent me on to Bethel." But Elisha said, "As the LORD lives, and as your soul lives, I will not leave you!" So they went down to Bethel.

3. Now the sons of the prophets who were at Bethel came out to Elisha, and said to him, "Do you know that the LORD will take away your master from over you today?" And he said, "Yes, I know; keep silent!"

4. Then Elijah said to him, "Elisha, stay here, please, for the LORD has sent me on to Jericho." But he said, "As the LORD lives, and as your soul lives, I will not leave you!" So they came to Jericho.

5. Now the sons of the prophets who were at Jericho came to Elisha and said to him, "Do you know that the LORD will take away your master from over you today?" So he answered, "Yes, I know; keep silent!"

6. Then Elijah said to him, "Stay here, please, for the LORD has sent me on to the Jordan." But he said, "As the LORD lives, and as your soul lives, I will not leave you!" So the two of them went on.

7. And fifty men of the sons of the prophets went and stood facing them at a distance, while the two of them stood by the Jordan.

8. Now Elijah took his mantle, rolled it up, and struck the water; and it was divided this way and that, so that the two of them crossed over on dry ground.

9. And so it was, when they had crossed over, that Elijah said to Elisha, "Ask! What may I do for you, before I am taken away from you?" Elisha said, "Please let a double portion of your spirit be upon me."

10. So he said, "You have asked a hard thing. Nevertheless, if you see me when I am taken from you, it shall be so for you; but if not, it shall not be so."

11. Then it happened, as they continued on and talked, that suddenly a chariot of fire appeared with horses of fire, and separated the two of them; and Elijah went up by a whirlwind into heaven.

12. And Elisha saw it, and he cried out, "My father, my father, the chariot of Israel and its horsemen!" So he saw him no more. And he took hold of his own clothes and tore them into two pieces.

13. He also took up the mantle of Elijah that had fallen from him, and went back and stood by the bank of the Jordan.

14. Then he took the mantle of Elijah that had fallen from him, and struck the water, and said, "Where is the LORD God of Elijah?" And when he also had struck the water, it was divided this way and that; and Elisha crossed over.

15. Now when the sons of the prophets who were from Jericho saw him, they said, "The spirit of Elijah rests on Elisha." And they came to meet him, and bowed to the ground before him.

16. Then they said to him, "Look now, there are fifty strong men with your servants. Please let them go and search for your master, lest perhaps the Spirit of the LORD has taken him up and cast him upon some mountain or into some valley." And he said, "You shall not send anyone."

17. But when they urged him till he was ashamed, he said, "Send them!" Therefore they sent fifty men, and they searched for three days but did not find him.

18. And when they came back to him, for he had stayed in Jericho, he said to them, "Did I not say to you, "Do not go'?"

19. Then the men of the city said to Elisha, "Please notice, the situation of this city is pleasant, as my lord sees; but the water is bad, and the ground barren."

20. And he said, "Bring me a new bowl, and put salt in it." So they brought it to him.

21. Then he went out to the source of the water, and cast in the salt there, and said, "Thus says the LORD: "I have healed this water; from it there shall be no more death or barrenness."'

22. So the water remains healed to this day, according to the word of Elisha which he spoke.

23. Then he went up from there to Bethel; and as he was going up the road, some youths came from the city and mocked him, and said to him, "Go up, you baldhead! Go up, you baldhead!"

24. So he turned around and looked at them, and pronounced a curse on them in the name of the LORD. And two female bears came out of the woods and mauled forty-two of the youths.

25. Then he went from there to Mount Carmel, and from there he returned to Samaria.

## Chapter 3

1. Now Jehoram the son of Ahab became king over Israel at Samaria in the eighteenth year of Jehoshaphat king of Judah, and reigned twelve years.

2. And he did evil in the sight of the LORD, but not like his father and mother; for he put away the sacred pillar of Baal that his father had made.

3. Nevertheless he persisted in the sins of Jeroboam the son of Nebat, who had made Israel sin; he did not depart from them.

4. Now Mesha king of Moab was a sheepbreeder, and he regularly paid the king of Israel one hundred thousand lambs and the wool of one hundred thousand rams.

5. But it happened, when Ahab died, that the king of Moab rebelled against the king of Israel.

6. So King Jehoram went out of Samaria at that time and mustered all Israel.

7. Then he went and sent to Jehoshaphat king of Judah, saying, "The king of Moab has rebelled against me. Will you go with me to fight against Moab?" And he said, "I will go up; I am as you are, my people as your people, my horses as your horses."

8. Then he said, "Which way shall we go up?" And he answered, "By way of the Wilderness of Edom."

9. So the king of Israel went with the king of Judah and the king of Edom, and they marched on that roundabout route seven days; and there was no water for the army, nor for the animals that followed them.

10. And the king of Israel said, "Alas! For the LORD has called these three kings together to deliver them into the hand of Moab."

11. But Jehoshaphat said, "Is there no prophet of the LORD here, that we may inquire of the LORD by him?" So one of the servants of the king of Israel answered and said, "Elisha the son of Shaphat is here, who poured water on the hands of Elijah."

12. And Jehoshaphat said, "The word of the LORD is with him." So the king of Israel and Jehoshaphat and the king of Edom went down to him.

13. Then Elisha said to the king of Israel, "What have I to do with you? Go to the prophets of your father and the prophets of your mother." But the king of Israel said to him, "No, for the LORD has called these three kings together to deliver them into the hand of Moab."

14. And Elisha said, "As the LORD of hosts lives, before whom I stand, surely were it not that I regard the presence of Jehoshaphat king of Judah, I would not look at you, nor see you.

15. But now bring me a musician." Then it happened, when the musician played, that the hand of the LORD came upon him.

16. And he said, "Thus says the LORD: "Make this valley full of ditches.'

17. For thus says the LORD: "You shall not see wind, nor shall you see rain; yet that valley shall be filled with water, so that you, your cattle, and your animals may drink.'

18. And this is a simple matter in the sight of the LORD; He will also deliver the Moabites into your hand.

19. Also you shall attack every fortified city and every choice city, and shall cut down every good tree, and stop up every spring of water, and ruin every good piece of land with stones."

20. Now it happened in the morning, when the grain offering was offered, that suddenly water came by way of Edom, and the land was filled with water.

21. And when all the Moabites heard that the kings had come up to fight against them, all who were able to bear arms and older were gathered; and they stood at the border.

22. Then they rose up early in the morning, and the sun was shining on the water; and the Moabites saw the water on the other side as red as blood.

23. And they said, "This is blood; the kings have surely struck swords and have killed one another; now therefore, Moab, to the spoil!"

24. So when they came to the camp of Israel, Israel rose up and attacked the Moabites, so that they fled before them; and they entered their land, killing the Moabites.

25. Then they destroyed the cities, and each man threw a stone on every good piece of land and filled it; and they stopped up all the springs of water and cut down all the good trees. But they left the stones of Kir Haraseth intact. However the slingers surrounded and attacked it.

26. And when the king of Moab saw that the battle was too fierce for him, he took with him seven hundred men who drew swords, to break through to the king of Edom, but they could not.

27. Then he took his eldest son who would have reigned in his place, and offered him as a burnt offering upon the wall; and there was great indignation against Israel. So they departed from him and returned to their own land.

## Chapter 4

1. A certain woman of the wives of the sons of the prophets cried out to Elisha, saying, "Your servant my husband is dead, and you know that your servant feared the LORD. And the creditor is coming to take my two sons to be his slaves."

2. So Elisha said to her, "What shall I do for you? Tell me, what do you have in the house?" And she said, "Your maidservant has nothing in the house but a jar of oil."

3. Then he said, "Go, borrow vessels from everywhere, from all your neighbors--empty vessels; do not gather just a few.

4. And when you have come in, you shall shut the door behind you and your sons; then pour it into all those vessels, and set aside the full ones."

5. So she went from him and shut the door behind her and her sons, who brought the vessels to her; and she poured it out.

6. Now it came to pass, when the vessels were full, that she said to her son, "Bring me another vessel." And he said to her, "There is not another vessel." So the oil ceased.

7. Then she came and told the man of God. And he said, "Go, sell the oil and pay your debt; and you and your sons live on the rest."

8. Now it happened one day that Elisha went to Shunem, where there was a notable woman, and she persuaded him to eat some food. So it was, as often as he passed by, he would turn in there to eat some food.

9. And she said to her husband, "Look now, I know that this is a holy man of God, who passes by us regularly.

10. Please, let us make a small upper room on the wall; and let us put a bed for him there, and a table and a chair and a lampstand; so it will be, whenever he comes to us, he can turn in there."

11. And it happened one day that he came there, and he turned in to the upper room and lay down there.

12. Then he said to Gehazi his servant, "Call this Shunammite woman." When he had called her, she stood before him.

13. And he said to him, "Say now to her, "Look, you have been concerned for us with all this care. What can I do for you? Do you want me to speak on your behalf to the king or to the commander of the army?"' She answered, "I dwell among my own people."

14. So he said, "What then is to be done for her?" And Gehazi answered, "Actually, she has no son, and her husband is old."

15. So he said, "Call her." When he had called her, she stood in the doorway.

16. Then he said, "About this time next year you shall embrace a son." And she said, "No, my lord. Man of God, do not lie to your maidservant!"

17. But the woman conceived, and bore a son when the appointed time had come, of which Elisha had told her.

18. And the child grew. Now it happened one day that he went out to his father, to the reapers.

19. And he said to his father, "My head, my head!" So he said to a servant, "Carry him to his mother."

20. When he had taken him and brought him to his mother, he sat on her knees till noon, and then died.

21. And she went up and laid him on the bed of the man of God, shut the door upon him, and went out.

22. Then she called to her husband, and said, "Please send me one of the young men and one of the donkeys, that I may run to the man of God and come back."

23. So he said, "Why are you going to him today? It is neither the New Moon nor the Sabbath." And she said, "It is well."

24. Then she saddled a donkey, and said to her servant, "Drive, and go forward; do not slacken the pace for me unless I tell you."

25. And so she departed, and went to the man of God at Mount Carmel. So it was, when the man of God saw her afar off, that he said to his servant Gehazi, "Look, the Shunammite woman!

26. Please run now to meet her, and say to her, "Is it well with you? Is it well with your husband? Is it well with the child?"' And she answered, "It is well."

27. Now when she came to the man of God at the hill, she caught him by the feet, but Gehazi came near to push her away. But the man of God said, "Let her alone; for her soul is in deep distress, and the LORD has hidden it from me, and has not told me."

28. So she said, "Did I ask a son of my lord? Did I not say, "Do not deceive me'?"

29. Then he said to Gehazi, "Get yourself ready, and take my staff in your hand, and be on your way. If you meet anyone, do not greet him; and if anyone greets you, do not answer him; but lay my staff on the face of the child."

30. And the mother of the child said, "As the LORD lives, and as your soul lives, I will not leave you." So he arose and followed her.

31. Now Gehazi went on ahead of them, and laid the staff on the face of the child; but there was neither voice nor hearing. Therefore he went back to meet him, and told him, saying, "The child has not awakened."

32. When Elisha came into the house, there was the child, lying dead on his bed.

33. He went in therefore, shut the door behind the two of them, and prayed to the LORD.

34. And he went up and lay on the child, and put his mouth on his mouth, his eyes on his eyes, and his hands on his hands; and he stretched himself out on the child, and the flesh of the child became warm.

35. He returned and walked back and forth in the house, and again went up and stretched himself out on him; then the child sneezed seven times, and the child opened his eyes.

36. And he called Gehazi and said, "Call this Shunammite woman." So he called her. And when she came in to him, he said, "Pick up your son."

37. So she went in, fell at his feet, and bowed to the ground; then she picked up her son and went out.

38. And Elisha returned to Gilgal, and there was a famine in the land. Now the sons of the prophets were sitting before him; and he said to his servant, "Put on the large pot, and boil stew for the sons of the prophets."

39. So one went out into the field to gather herbs, and found a wild vine, and gathered from it a lapful of wild gourds, and came and sliced them into the pot of stew, though they did not know what they were.

40. Then they served it to the men to eat. Now it happened, as they were eating the stew, that they cried out and said, "Man of God, there is death in the pot!" And they could not eat it.

41. So he said, "Then bring some flour." And he put it into the pot, and said, "Serve it to the people, that they may eat." And there was nothing harmful in the pot.

42. Then a man came from Baal Shalisha, and brought the man of God bread of the firstfruits, twenty loaves of barley bread, and newly ripened grain in his knapsack. And he said, "Give it to the people, that they may eat."

43. But his servant said, "What? Shall I set this before one hundred men?" He said again, "Give it to the people, that they may eat; for thus says the LORD: "They shall eat and have some left over."'

44. So he set it before them; and they ate and had some left over, according to the word of the LORD.

## Chapter 5

1. Now Naaman, commander of the army of the king of Syria, was a great and honorable man in the eyes of his master, because by him the LORD had given victory to Syria. He was also a mighty man of valor, but a leper.

2. And the Syrians had gone out on raids, and had brought back captive a young girl from the land of Israel. She waited on Naaman's wife.

3. Then she said to her mistress, "If only my master were with the prophet who is in Samaria! For he would heal him of his leprosy."

4. And Naaman went in and told his master, saying, "Thus and thus said the girl who is from the land of Israel."

5. Then the king of Syria said, "Go now, and I will send a letter to the king of Israel." So he departed and took with him ten talents of silver, six thousand shekels of gold, and ten changes of clothing.

6. Then he brought the letter to the king of Israel, which said, 4 Now be advised, when this letter comes to you, that I have sent Naaman my servant to you, that you may heal him of his leprosy.

7. And it happened, when the king of Israel read the letter, that he tore his clothes and said, "Am I God, to kill and make alive, that this man sends a man to me to heal him of his leprosy? Therefore please consider, and see how he seeks a quarrel with me."

8. So it was, when Elisha the man of God heard that the king of Israel had torn his clothes, that he sent to the king, saying, "Why have you torn your clothes? Please let him come to me, and he shall know that there is a prophet in Israel."

9. Then Naaman went with his horses and chariot, and he stood at the door of Elisha's house.

10. And Elisha sent a messenger to him, saying, "Go and wash in the Jordan seven times, and your flesh shall be restored to you, and you shall be clean."

11. But Naaman became furious, and went away and said, "Indeed, I said to myself, "He will surely come out to me, and stand and call on the name of the LORD his God, and wave his hand over the place, and heal the leprosy.'

12. Are not the Abanah and the Pharpar, the rivers of Damascus, better than all the waters of Israel? Could I not wash in them and be clean?" So he turned and went away in a rage.

13. And his servants came near and spoke to him, and said, "My father, if the prophet had told you to do something great, would you not have done it? How much more then, when he says to you, "Wash, and be clean'?"

14. So he went down and dipped seven times in the Jordan, according to the saying of the man of God; and his flesh was restored like the flesh of a little child, and he was clean.

15. And he returned to the man of God, he and all his aides, and came and stood before him; and he said, "Indeed, now I know that there is no God in all the earth, except in Israel; now therefore, please take a gift from your servant."

16. But he said, "As the LORD lives, before whom I stand, I will receive nothing." And he urged him to take it, but he refused.

17. So Naaman said, "Then, if not, please let your servant be given two mule-loads of earth; for your servant will no longer offer either burnt offering or sacrifice to other gods, but to the LORD.

18. Yet in this thing may the LORD pardon your servant: when my master goes into the temple of Rimmon to worship there, and he leans on my hand, and I bow down in the temple of Rimmon--when I bow down in the temple of Rimmon, may the LORD please pardon your servant in this thing."

19. Then he said to him, "Go in peace." So he departed from him a short distance.

20. But Gehazi, the servant of Elisha the man of God, said, "Look, my master has spared Naaman this Syrian, while not receiving from his hands what he brought; but as the LORD lives, I will run after him and take something from him."

21. So Gehazi pursued Naaman. When Naaman saw him running after him, he got down from the chariot to meet him, and said, "Is all well?"

22. And he said, "All is well. My master has sent me, saying, "Indeed, just now two young men of the sons of the prophets have come to me from the mountains of Ephraim. Please give them a talent of silver and two changes of garments."'

23. So Naaman said, "Please, take two talents." And he urged him, and bound two talents of silver in two bags, with two changes of garments, and handed them to two of his servants; and they carried them on ahead of him.

24. When he came to the citadel, he took them from their hand, and stored them away in the house; then he let the men go, and they departed.

25. Now he went in and stood before his master. Elisha said to him, "Where did you go, Gehazi?" And he said, "Your servant did not go anywhere."

26. Then he said to him, "Did not my heart go with you when the man turned back from his chariot to meet you? Is it time to receive money and to receive clothing, olive groves and vineyards, sheep and oxen, male and female servants?

27. Therefore the leprosy of Naaman shall cling to you and your descendants forever." And he went out from his presence leprous, as white as snow.

## Chapter 6

1. And the sons of the prophets said to Elisha, "See now, the place where we dwell with you is too small for us.

2. Please, let us go to the Jordan, and let every man take a beam from there, and let us make there a place where we may dwell." So he answered, "Go."

3. Then one said, "Please consent to go with your servants." And he answered, "I will go."

4. So he went with them. And when they came to the Jordan, they cut down trees.

5. But as one was cutting down a tree, the iron ax head fell into the water; and he cried out and said, "Alas, master! For it was borrowed."

6. So the man of God said, "Where did it fall?" And he showed him the place. So he cut off a stick, and threw it in there; and he made the iron float.

7. Therefore he said, "Pick it up for yourself." So he reached out his hand and took it.

8. Now the king of Syria was making war against Israel; and he consulted with his servants, saying, "My camp will be in such and such a place."

9. And the man of God sent to the king of Israel, saying, "Beware that you do not pass this place, for the Syrians are coming down there."

10. Then the king of Israel sent someone to the place of which the man of God had told him. Thus he warned him, and he was watchful there, not just once or twice.

11. Therefore the heart of the king of Syria was greatly troubled by this thing; and he called his servants and said to them, "Will you not show me which of us is for the king of Israel?"

12. And one of his servants said, "None, my lord, O king; but Elisha, the prophet who is in Israel, tells the king of Israel the words that you speak in your bedroom."

13. So he said, "Go and see where he is, that I may send and get him." And it was told him, saying, "Surely he is in Dothan."

14. Therefore he sent horses and chariots and a great army there, and they came by night and surrounded the city.

15. And when the servant of the man of God arose early and went out, there was an army, surrounding the city with horses and chariots. And his servant said to him, "Alas, my master! What shall we do?"

16. So he answered, "Do not fear, for those who are with us are more than those who are with them."

17. And Elisha prayed, and said, "LORD, I pray, open his eyes that he may see." Then the LORD opened the eyes of the young man, and he saw. And behold, the mountain was full of horses and chariots of fire all around Elisha.

18. So when the Syrians came down to him, Elisha prayed to the LORD, and said, "Strike this people, I pray, with blindness." And He struck them with blindness according to the word of Elisha.

19. Now Elisha said to them, "This is not the way, nor is this the city. Follow me, and I will bring you to the man whom you seek." But he led them to Samaria.

20. So it was, when they had come to Samaria, that Elisha said, "LORD, open the eyes of these men, that they may see." And the LORD opened their eyes, and they saw; and there they were, inside Samaria!

21. Now when the king of Israel saw them, he said to Elisha, "My father, shall I kill them? Shall I kill them?"

22. But he answered, "You shall not kill them. Would you kill those whom you have taken captive with your sword and your bow? Set food and water before them, that they may eat and drink and go to their master."

23. Then he prepared a great feast for them; and after they ate and drank, he sent them away and they went to their master. So the bands of Syrian raiders came no more into the land of Israel.

24. And it happened after this that Ben-Hadad king of Syria gathered all his army, and went up and besieged Samaria.

25. And there was a great famine in Samaria; and indeed they besieged it until a donkey's head was sold for eighty shekels of silver, and one-fourth of a kab of dove droppings for five shekels of silver.

26. Then, as the king of Israel was passing by on the wall, a woman cried out to him, saying, "Help, my lord, O king!"

27. And he said, "If the LORD does not help you, where can I find help for you? From the threshing floor or from the winepress?"

28. Then the king said to her, "What is troubling you?" And she answered, "This woman said to me, "Give your son, that we may eat him today, and we will eat my son tomorrow.'

29. So we boiled my son, and ate him. And I said to her on the next day, "Give your son, that we may eat him'; but she has hidden her son."

30. Now it happened, when the king heard the words of the woman, that he tore his clothes; and as he passed by on the wall, the people looked, and there underneath he had sackcloth on his body.

31. Then he said, "God do so to me and more also, if the head of Elisha the son of Shaphat remains on him today!"

32. But Elisha was sitting in his house, and the elders were sitting with him. And the king sent a man ahead of him, but before the messenger came to him, he said to the elders, "Do you see how this son of a murderer has sent someone to take away my head? Look, when the messenger comes, shut the door, and hold him fast at the door. Is not the sound of his master's feet behind him?"

33. And while he was still talking with them, there was the messenger, coming down to him; and then the king said, "Surely this calamity is from the LORD; why should I wait for the LORD any longer?"

## Chapter 7

1. Then Elisha said, "Hear the word of the LORD. Thus says the LORD: "Tomorrow about this time a seah of fine flour shall be sold for a shekel, and two seahs of barley for a shekel, at the gate of Samaria."'

2. So an officer on whose hand the king leaned answered the man of God and said, "Look, if the LORD would make windows in heaven, could this thing be?" And he said, "In fact, you shall see it with your eyes, but you shall not eat of it."

3. Now there were four leprous men at the entrance of the gate; and they said to one another, "Why are we sitting here until we die?

4. If we say, "We will enter the city,' the famine is in the city, and we shall die there. And if we sit here, we die also. Now therefore, come, let us surrender to the army of the Syrians. If they keep us alive, we shall live; and if they kill us, we shall only die."

5. And they rose at twilight to go to the camp of the Syrians; and when they had come to the outskirts of the Syrian camp, to their surprise no one was there.

6. For the LORD had caused the army of the Syrians to hear the noise of chariots and the noise of horses--the noise of a great army; so they said to one another, "Look, the king of Israel has hired against us the kings of the Hittites and the kings of the Egyptians to attack us!"

7. Therefore they arose and fled at twilight, and left the camp intact--their tents, their horses, and their donkeys--and they fled for their lives.

8. And when these lepers came to the outskirts of the camp, they went into one tent and ate and drank, and carried from it silver and gold and clothing, and went and hid them; then they came back and entered another tent, and carried some from there also, and went and hid it.

9. Then they said to one another, "We are not doing right. This day is a day of good news, and we remain silent. If we wait until morning light, some punishment will come upon us. Now therefore, come, let us go and tell the king's household."

10. So they went and called to the gatekeepers of the city, and told them, saying, "We went to the Syrian camp, and surprisingly no one was there, not a human sound--only horses and donkeys tied, and the tents intact."

11. And the gatekeepers called out, and they told it to the king's household inside.

12. So the king arose in the night and said to his servants, "Let me now tell you what the Syrians have done to us. They know that we are hungry; therefore they have gone out of the camp to hide themselves in the field, saying, "When they come out of the city, we shall catch them alive, and get into the city."'

13. And one of his servants answered and said, "Please, let several men take five of the remaining horses which are left in the city. Look, they may either become like all the multitude of Israel that are left in it; or indeed, I say, they may become like all the multitude of Israel left from those who are consumed; so let us send them and see."

14. Therefore they took two chariots with horses; and the king sent them in the direction of the Syrian army, saying, "Go and see."

15. And they went after them to the Jordan; and indeed all the road was full of garments and weapons which the Syrians had thrown away in their haste. So the messengers returned and told the king.

16. Then the people went out and plundered the tents of the Syrians. So a seah of fine flour was sold for a shekel, and two seahs of barley for a shekel, according to the word of the LORD.

17. Now the king had appointed the officer on whose hand he leaned to have charge of the gate. But the people trampled him in the gate, and he died, just as the man of God had said, who spoke when the king came down to him.

18. So it happened just as the man of God had spoken to the king, saying, "Two seahs of barley for a shekel, and a seah of fine flour for a shekel, shall be sold tomorrow about this time in the gate of Samaria."

19. Then that officer had answered the man of God, and said, "Now look, if the LORD would make windows in heaven, could such a thing be?" And he had said, "In fact, you shall see it with your eyes, but you shall not eat of it."

20. And so it happened to him, for the people trampled him in the gate, and he died.

## Chapter 8

1. Then Elisha spoke to the woman whose son he had restored to life, saying, "Arise and go, you and your household, and stay wherever you can; for the LORD has called for a famine, and furthermore, it will come upon the land for seven years."

2. So the woman arose and did according to the saying of the man of God, and she went with her household and dwelt in the land of the Philistines seven years.

3. It came to pass, at the end of seven years, that the woman returned from the land of the Philistines; and she went to make an appeal to the king for her house and for her land.

4. Then the king talked with Gehazi, the servant of the man of God, saying, "Tell me, please, all the great things Elisha has done."

5. Now it happened, as he was telling the king how he had restored the dead to life, that there was the woman whose son he had restored to life, appealing to the king for her house and for her land. And Gehazi said, "My lord, O king, this is the woman, and this is her son whom Elisha restored to life."

6. And when the king asked the woman, she told him. So the king appointed a certain officer for her, saying, "Restore all that was hers, and all the proceeds of the field from the day that she left the land until now."

7. Then Elisha went to Damascus, and Ben-Hadad king of Syria was sick; and it was told him, saying, "The man of God has come here."

8. And the king said to Hazael, "Take a present in your hand, and go to meet the man of God, and inquire of the LORD by him, saying, "Shall I recover from this disease?"'

9. So Hazael went to meet him and took a present with him, of every good thing of Damascus, forty camel-loads; and he came and stood before him, and said, "Your son Ben-Hadad king of Syria has sent me to you, saying, "Shall I recover from this disease?"'

10. And Elisha said to him, "Go, say to him, "You shall certainly recover.' However the LORD has shown me that he will really die."

11. Then he set his countenance in a stare until he was ashamed; and the man of God wept.

12. And Hazael said, "Why is my lord weeping?" He answered, "Because I know the evil that you will do to the children of Israel: Their strongholds you will set on fire, and their young men you will kill with the sword; and you will dash their children, and rip open their women with child."

13. So Hazael said, "But what is your servant--a dog, that he should do this gross thing?" And Elisha answered, "The LORD has shown me that you will become king over Syria."

14. Then he departed from Elisha, and came to his master, who said to him, "What did Elisha say to you?" And he answered, "He told me you would surely recover."

15. But it happened on the next day that he took a thick cloth and dipped it in water, and spread it over his face so that he died; and Hazael reigned in his place.

16. Now in the fifth year of Joram the son of Ahab, king of Israel, Jehoshaphat having been king of Judah, Jehoram the son of Jehoshaphat began to reign as king of Judah.

17. He was thirty-two years old when he became king, and he reigned eight years in Jerusalem.

18. And he walked in the way of the kings of Israel, just as the house of Ahab had done, for the daughter of Ahab was his wife; and he did evil in the sight of the LORD.

19. Yet the LORD would not destroy Judah, for the sake of His servant David, as He promised him to give a lamp to him and his sons forever.

20. In his days Edom revolted against Judah's authority, and made a king over themselves.

21. So Joram went to Zair, and all his chariots with him. Then he rose by night and attacked the Edomites who had surrounded him and the captains of the chariots; and the troops fled to their tents.

22. Thus Edom has been in revolt against Judah's authority to this day. And Libnah revolted at that time.

23. Now the rest of the acts of Joram, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

24. So Joram rested with his fathers, and was buried with his fathers in the City of David. Then Ahaziah his son reigned in his place.

25. In the twelfth year of Joram the son of Ahab, king of Israel, Ahaziah the son of Jehoram, king of Judah, began to reign.

26. Ahaziah was twenty-two years old when he became king, and he reigned one year in Jerusalem. His mother's name was Athaliah the granddaughter of Omri, king of Israel.

27. And he walked in the way of the house of Ahab, and did evil in the sight of the LORD, like the house of Ahab, for he was the son-in-law of the house of Ahab.

28. Now he went with Joram the son of Ahab to war against Hazael king of Syria at Ramoth Gilead; and the Syrians wounded Joram.

29. Then King Joram went back to Jezreel to recover from the wounds which the Syrians had inflicted on him at Ramah, when he fought against Hazael king of Syria. And Ahaziah the son of Jehoram, king of Judah, went down to see Joram the son of Ahab in Jezreel, because he was sick.

## Chapter 9

1. And Elisha the prophet called one of the sons of the prophets, and said to him, "Get yourself ready, take this flask of oil in your hand, and go to Ramoth Gilead.

2. Now when you arrive at that place, look there for Jehu the son of Jehoshaphat, the son of Nimshi, and go in and make him rise up from among his associates, and take him to an inner room.

3. Then take the flask of oil, and pour it on his head, and say, "Thus says the LORD: "I have anointed you king over Israel."' Then open the door and flee, and do not delay."

4. So the young man, the servant of the prophet, went to Ramoth Gilead.

5. And when he arrived, there were the captains of the army sitting; and he said, "I have a message for you, Commander." Jehu said, "For which one of us?" And he said, "For you, Commander."

6. Then he arose and went into the house. And he poured the oil on his head, and said to him, "Thus says the LORD God of Israel: "I have anointed you king over the people of the LORD, over Israel.

7. You shall strike down the house of Ahab your master, that I may avenge the blood of My servants the prophets, and the blood of all the servants of the LORD, at the hand of Jezebel.

8. For the whole house of Ahab shall perish; and I will cut off from Ahab all the males in Israel, both bond and free.

9. So I will make the house of Ahab like the house of Jeroboam the son of Nebat, and like the house of Baasha the son of Ahijah.

10. The dogs shall eat Jezebel on the plot of ground at Jezreel, and there shall be none to bury her."' And he opened the door and fled.

11. Then Jehu came out to the servants of his master, and one said to him, "Is all well? Why did this madman come to you?" And he said to them, "You know the man and his babble."

12. And they said, "A lie! Tell us now." So he said, "Thus and thus he spoke to me, saying, "Thus says the LORD: "I have anointed you king over Israel.""'

13. Then each man hastened to take his garment and put it under him on the top of the steps; and they blew trumpets, saying, "Jehu is king!"

14. So Jehu the son of Jehoshaphat, the son of Nimshi, conspired against Joram. (Now Joram had been defending Ramoth Gilead, he and all Israel, against Hazael king of Syria.

15. But King Joram had returned to Jezreel to recover from the wounds which the Syrians had inflicted on him when he fought with Hazael king of Syria.) And Jehu said, "If you are so minded, let no one leave or escape from the city to go and tell it in Jezreel."

16. So Jehu rode in a chariot and went to Jezreel, for Joram was laid up there; and Ahaziah king of Judah had come down to see Joram.

17. Now a watchman stood on the tower in Jezreel, and he saw the company of Jehu as he came, and said, "I see a company of men." And Joram said, "Get a horseman and send him to meet them, and let him say, "Is it peace?"'

18. So the horseman went to meet him, and said, "Thus says the king: "Is it peace?"' And Jehu said, "What have you to do with peace? Turn around and follow me." So the watchman reported, saying, "The messenger went to them, but is not coming back."

19. Then he sent out a second horseman who came to them, and said, "Thus says the king: "Is it peace?"' And Jehu answered, "What have you to do with peace? Turn around and follow me."

20. So the watchman reported, saying, "He went up to them and is not coming back; and the driving is like the driving of Jehu the son of Nimshi, for he drives furiously!"

21. Then Joram said, "Make ready." And his chariot was made ready. Then Joram king of Israel and Ahaziah king of Judah went out, each in his chariot; and they went out to meet Jehu, and met him on the property of Naboth the Jezreelite.

22. Now it happened, when Joram saw Jehu, that he said, "Is it peace, Jehu?" So he answered, "What peace, as long as the harlotries of your mother Jezebel and her witchcraft are so many?"

23. Then Joram turned around and fled, and said to Ahaziah, "Treachery, Ahaziah!"

24. Now Jehu drew his bow with full strength and shot Jehoram between his arms; and the arrow came out at his heart, and he sank down in his chariot.

25. Then Jehu said to Bidkar his captain, "Pick him up, and throw him into the tract of the field of Naboth the Jezreelite; for remember, when you and I were riding together behind Ahab his father, that the LORD laid this burden upon him:

26. "Surely I saw yesterday the blood of Naboth and the blood of his sons,' says the LORD, "and I will repay you in this plot,' says the LORD. Now therefore, take and throw him on the plot of ground, according to the word of the LORD."

27. But when Ahaziah king of Judah saw this, he fled by the road to Beth Haggan. So Jehu pursued him, and said, "Shoot him also in the chariot." And they shot him at the Ascent of Gur, which is by Ibleam. Then he fled to Megiddo, and died there.

28. And his servants carried him in the chariot to Jerusalem, and buried him in his tomb with his fathers in the City of David.

29. In the eleventh year of Joram the son of Ahab, Ahaziah had become king over Judah.

30. Now when Jehu had come to Jezreel, Jezebel heard of it; and she put paint on her eyes and adorned her head, and looked through a window.

31. Then, as Jehu entered at the gate, she said, "Is it peace, Zimri, murderer of your master?"

32. And he looked up at the window, and said, "Who is on my side? Who?" So two or three eunuchs looked out at him.

33. Then he said, "Throw her down." So they threw her down, and some of her blood spattered on the wall and on the horses; and he trampled her underfoot.

34. And when he had gone in, he ate and drank. Then he said, "Go now, see to this accursed woman, and bury her, for she was a king's daughter."

35. So they went to bury her, but they found no more of her than the skull and the feet and the palms of her hands.

36. Therefore they came back and told him. And he said, "This is the word of the LORD, which He spoke by His servant Elijah the Tishbite, saying, "On the plot of ground at Jezreel dogs shall eat the flesh of Jezebel;

37. and the corpse of Jezebel shall be as refuse on the surface of the field, in the plot at Jezreel, so that they shall not say, "Here lies Jezebel.""'

## Chapter 10

1. Now Ahab had seventy sons in Samaria. And Jehu wrote and sent letters to Samaria, to the rulers of Jezreel, to the elders, and to those who reared Ahab's sons, saying:

2. Now as soon as this letter comes to you, since your master's sons are with you, and you have chariots and horses, a fortified city also, and weapons,

3. choose the best qualified of your master's sons, set him on his father's throne, and fight for your master's house.

4. But they were exceedingly afraid, and said, "Look, two kings could not stand up to him; how then can we stand?"

5. And he who was in charge of the house, and he who was in charge of the city, the elders also, and those who reared the sons, sent to Jehu, saying, "We are your servants, we will do all you tell us; but we will not make anyone king. Do what is good in your sight."

6. Then he wrote a second letter to them, saying: 4 If you are for me and will obey my voice, take the heads of the men, your master's sons, and come to me at Jezreel by this time tomorrow. Now the king's sons, seventy persons, were with the great men of the city, who were rearing them.

7. So it was, when the letter came to them, that they took the king's sons and slaughtered seventy persons, put their heads in baskets and sent them to him at Jezreel.

8. Then a messenger came and told him, saying, "They have brought the heads of the king's sons." And he said, "Lay them in two heaps at the entrance of the gate until morning."

9. So it was, in the morning, that he went out and stood, and said to all the people, "You are righteous. Indeed I conspired against my master and killed him; but who killed all these?

10. Know now that nothing shall fall to the earth of the word of the LORD which the LORD spoke concerning the house of Ahab; for the LORD has done what He spoke by His servant Elijah."

11. So Jehu killed all who remained of the house of Ahab in Jezreel, and all his great men and his close acquaintances and his priests, until he left him none remaining.

12. And he arose and departed and went to Samaria. On the way, at Beth Eked of the Shepherds,

13. Jehu met with the brothers of Ahaziah king of Judah, and said, "Who are you?" So they answered, "We are the brothers of Ahaziah; we have come down to greet the sons of the king and the sons of the queen mother."

14. And he said, "Take them alive!" So they took them alive, and killed them at the well of Beth Eked, forty-two men; and he left none of them.

15. Now when he departed from there, he met Jehonadab the son of Rechab, coming to meet him; and he greeted him and said to him, "Is your heart right, as my heart is toward your heart?" And Jehonadab answered, "It is." Jehu said, "If it is, give me your hand." So he gave him his hand, and he took him up to him into the chariot.

16. Then he said, "Come with me, and see my zeal for the LORD." So they had him ride in his chariot.

17. And when he came to Samaria, he killed all who remained to Ahab in Samaria, till he had destroyed them, according to the word of the LORD which He spoke to Elijah.

18. Then Jehu gathered all the people together, and said to them, "Ahab served Baal a little, Jehu will serve him much.

19. Now therefore, call to me all the prophets of Baal, all his servants, and all his priests. Let no one be missing, for I have a great sacrifice for Baal. Whoever is missing shall not live." But Jehu acted deceptively, with the intent of destroying the worshipers of Baal.

20. And Jehu said, "Proclaim a solemn assembly for Baal." So they proclaimed it.

21. Then Jehu sent throughout all Israel; and all the worshipers of Baal came, so that there was not a man left who did not come. So they came into the temple of Baal, and the temple of Baal was full from one end to the other.

22. And he said to the one in charge of the wardrobe, "Bring out vestments for all the worshipers of Baal." So he brought out vestments for them.

23. Then Jehu and Jehonadab the son of Rechab went into the temple of Baal, and said to the worshipers of Baal, "Search and see that no servants of the LORD are here with you, but only the worshipers of Baal."

24. So they went in to offer sacrifices and burnt offerings. Now Jehu had appointed for himself eighty men on the outside, and had said, "If any of the men whom I have brought into your hands escapes, whoever lets him escape, it shall be his life for the life of the other."

25. Now it happened, as soon as he had made an end of offering the burnt offering, that Jehu said to the guard and to the captains, "Go in and kill them; let no one come out!" And they killed them with the edge of the sword; then the guards and the officers threw them out, and went into the inner room of the temple of Baal.

26. And they brought the sacred pillars out of the temple of Baal and burned them.

27. Then they broke down the sacred pillar of Baal, and tore down the temple of Baal and made it a refuse dump to this day.

28. Thus Jehu destroyed Baal from Israel.

29. However Jehu did not turn away from the sins of Jeroboam the son of Nebat, who had made Israel sin, that is, from the golden calves that were at Bethel and Dan.

30. And the LORD said to Jehu, "Because you have done well in doing what is right in My sight, and have done to the house of Ahab all that was in My heart, your sons shall sit on the throne of Israel to the fourth generation."

31. But Jehu took no heed to walk in the law of the LORD God of Israel with all his heart; for he did not depart from the sins of Jeroboam, who had made Israel sin.

32. In those days the LORD began to cut off parts of Israel; and Hazael conquered them in all the territory of Israel

33. from the Jordan eastward: all the land of Gilead--Gad, Reuben, and Manasseh--from Aroer, which is by the River Arnon, including Gilead and Bashan.

34. Now the rest of the acts of Jehu, all that he did, and all his might, are they not written in the book of the chronicles of the kings of Israel?

35. So Jehu rested with his fathers, and they buried him in Samaria. Then Jehoahaz his son reigned in his place.

36. And the period that Jehu reigned over Israel in Samaria was twenty-eight years.

## Chapter 11

1. When Athaliah the mother of Ahaziah saw that her son was dead, she arose and destroyed all the royal heirs.

2. But Jehosheba, the daughter of King Joram, sister of Ahaziah, took Joash the son of Ahaziah, and stole him away from among the king's sons who were being murdered; and they hid him and his nurse in the bedroom, from Athaliah, so that he was not killed.

3. So he was hidden with her in the house of the LORD for six years, while Athaliah reigned over the land.

4. In the seventh year Jehoiada sent and brought the captains of hundreds--of the bodyguards and the escorts--and brought them into the house of the LORD to him. And he made a covenant with them and took an oath from them in the house of the LORD, and showed them the king's son.

5. Then he commanded them, saying, "This is what you shall do: One-third of you who come on duty on the Sabbath shall be keeping watch over the king's house,

6. one-third shall be at the gate of Sur, and one-third at the gate behind the escorts. You shall keep the watch of the house, lest it be broken down.

7. The two contingents of you who go off duty on the Sabbath shall keep the watch of the house of the LORD for the king.

8. But you shall surround the king on all sides, every man with his weapons in his hand; and whoever comes within range, let him be put to death. You are to be with the king as he goes out and as he comes in."

9. So the captains of the hundreds did according to all that Jehoiada the priest commanded. Each of them took his men who were to be on duty on the Sabbath, with those who were going off duty on the Sabbath, and came to Jehoiada the priest.

10. And the priest gave the captains of hundreds the spears and shields which had belonged to King David, that were in the temple of the LORD.

11. Then the escorts stood, every man with his weapons in his hand, all around the king, from the right side of the temple to the left side of the temple, by the altar and the house.

12. And he brought out the king's son, put the crown on him, and gave him the Testimony; they made him king and anointed him, and they clapped their hands and said, "Long live the king!"

13. Now when Athaliah heard the noise of the escorts and the people, she came to the people in the temple of the LORD.

14. When she looked, there was the king standing by a pillar according to custom; and the leaders and the trumpeters were by the king. All the people of the land were rejoicing and blowing trumpets. So Athaliah tore her clothes and cried out, "Treason! Treason!"

15. And Jehoiada the priest commanded the captains of the hundreds, the officers of the army, and said to them, "Take her outside under guard, and slay with the sword whoever follows her." For the priest had said, "Do not let her be killed in the house of the LORD."

16. So they seized her; and she went by way of the horses' entrance into the king's house, and there she was killed.

17. Then Jehoiada made a covenant between the LORD, the king, and the people, that they should be the LORD's people, and also between the king and the people.

18. And all the people of the land went to the temple of Baal, and tore it down. They thoroughly broke in pieces its altars and images, and killed Mattan the priest of Baal before the altars. And the priest appointed officers over the house of the LORD.

19. Then he took the captains of hundreds, the bodyguards, the escorts, and all the people of the land; and they brought the king down from the house of the LORD, and went by way of the gate of the escorts to the king's house. Then he sat on the throne of the kings.

20. So all the people of the land rejoiced; and the city was quiet, for they had slain Athaliah with the sword in the king's house.

21. Jehoash was seven years old when he became king.

## Chapter 12

1. In the seventh year of Jehu, Jehoash became king, and he reigned forty years in Jerusalem. His mother's name was Zibiah of Beersheba.

2. Jehoash did what was right in the sight of the LORD all the days in which Jehoiada the priest instructed him.

3. But the high places were not taken away; the people still sacrificed and burned incense on the high places.

4. And Jehoash said to the priests, "All the money of the dedicated gifts that are brought into the house of the LORD--each man's census money, each man's assessment money--and all the money that a man purposes in his heart to bring into the house of the LORD,

5. let the priests take it themselves, each from his constituency; and let them repair the damages of the temple, wherever any dilapidation is found."

6. Now it was so, by the twenty-third year of King Jehoash, that the priests had not repaired the damages of the temple.

7. So King Jehoash called Jehoiada the priest and the other priests, and said to them, "Why have you not repaired the damages of the temple? Now therefore, do not take more money from your constituency, but deliver it for repairing the damages of the temple."

8. And the priests agreed that they would neither receive more money from the people, nor repair the damages of the temple.

9. Then Jehoiada the priest took a chest, bored a hole in its lid, and set it beside the altar, on the right side as one comes into the house of the LORD; and the priests who kept the door put there all the money brought into the house of the LORD.

10. So it was, whenever they saw that there was much money in the chest, that the king's scribe and the high priest came up and put it in bags, and counted the money that was found in the house of the LORD.

11. Then they gave the money, which had been apportioned, into the hands of those who did the work, who had the oversight of the house of the LORD; and they paid it out to the carpenters and builders who worked on the house of the LORD,

12. and to masons and stonecutters, and for buying timber and hewn stone, to repair the damage of the house of the LORD, and for all that was paid out to repair the temple.

13. However there were not made for the house of the LORD basins of silver, trimmers, sprinkling-bowls, trumpets, any articles of gold or articles of silver, from the money brought into the house of the LORD.

14. But they gave that to the workmen, and they repaired the house of the LORD with it.

15. Moreover they did not require an account from the men into whose hand they delivered the money to be paid to workmen, for they dealt faithfully.

16. The money from the trespass offerings and the money from the sin offerings was not brought into the house of the LORD. It belonged to the priests.

17. Hazael king of Syria went up and fought against Gath, and took it; then Hazael set his face to go up to Jerusalem.

18. And Jehoash king of Judah took all the sacred things that his fathers, Jehoshaphat and Jehoram and Ahaziah, kings of Judah, had dedicated, and his own sacred things, and all the gold found in the treasuries of the house of the LORD and in the king's house, and sent them to Hazael king of Syria. Then he went away from Jerusalem.

19. Now the rest of the acts of Joash, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

20. And his servants arose and formed a conspiracy, and killed Joash in the house of the Millo, which goes down to Silla.

21. For Jozachar the son of Shimeath and Jehozabad the son of Shomer, his servants, struck him. So he died, and they buried him with his fathers in the City of David. Then Amaziah his son reigned in his place.

## Chapter 13

1. In the twenty-third year of Joash the son of Ahaziah, king of Judah, Jehoahaz the son of Jehu became king over Israel in Samaria, and reigned seventeen years.

2. And he did evil in the sight of the LORD, and followed the sins of Jeroboam the son of Nebat, who had made Israel sin. He did not depart from them.

3. Then the anger of the LORD was aroused against Israel, and He delivered them into the hand of Hazael king of Syria, and into the hand of Ben-Hadad the son of Hazael, all their days.

4. So Jehoahaz pleaded with the LORD, and the LORD listened to him; for He saw the oppression of Israel, because the king of Syria oppressed them.

5. Then the LORD gave Israel a deliverer, so that they escaped from under the hand of the Syrians; and the children of Israel dwelt in their tents as before.

6. Nevertheless they did not depart from the sins of the house of Jeroboam, who had made Israel sin, but walked in them; and the wooden image also remained in Samaria.

7. For He left of the army of Jehoahaz only fifty horsemen, ten chariots, and ten thousand foot soldiers; for the king of Syria had destroyed them and made them like the dust at threshing.

8. Now the rest of the acts of Jehoahaz, all that he did, and his might, are they not written in the book of the chronicles of the kings of Israel?

9. So Jehoahaz rested with his fathers, and they buried him in Samaria. Then Joash his son reigned in his place.

10. In the thirty-seventh year of Joash king of Judah, Jehoash the son of Jehoahaz became king over Israel in Samaria, and reigned sixteen years.

11. And he did evil in the sight of the LORD. He did not depart from all the sins of Jeroboam the son of Nebat, who made Israel sin, but walked in them.

12. Now the rest of the acts of Joash, all that he did, and his might with which he fought against Amaziah king of Judah, are they not written in the book of the chronicles of the kings of Israel?

13. So Joash rested with his fathers. Then Jeroboam sat on his throne. And Joash was buried in Samaria with the kings of Israel.

14. Elisha had become sick with the illness of which he would die. Then Joash the king of Israel came down to him, and wept over his face, and said, "O my father, my father, the chariots of Israel and their horsemen!"

15. And Elisha said to him, "Take a bow and some arrows." So he took himself a bow and some arrows.

16. Then he said to the king of Israel, "Put your hand on the bow." So he put his hand on it, and Elisha put his hands on the king's hands.

17. And he said, "Open the east window"; and he opened it. Then Elisha said, "Shoot"; and he shot. And he said, "The arrow of the LORD's deliverance and the arrow of deliverance from Syria; for you must strike the Syrians at Aphek till you have destroyed them."

18. Then he said, "Take the arrows"; so he took them. And he said to the king of Israel, "Strike the ground"; so he struck three times, and stopped.

19. And the man of God was angry with him, and said, "You should have struck five or six times; then you would have struck Syria till you had destroyed it! But now you will strike Syria only three times."

20. Then Elisha died, and they buried him. And the raiding bands from Moab invaded the land in the spring of the year.

21. So it was, as they were burying a man, that suddenly they spied a band of raiders; and they put the man in the tomb of Elisha; and when the man was let down and touched the bones of Elisha, he revived and stood on his feet.

22. And Hazael king of Syria oppressed Israel all the days of Jehoahaz.

23. But the LORD was gracious to them, had compassion on them, and regarded them, because of His covenant with Abraham, Isaac, and Jacob, and would not yet destroy them or cast them from His presence.

24. Now Hazael king of Syria died. Then Ben-Hadad his son reigned in his place.

25. And Jehoash the son of Jehoahaz recaptured from the hand of Ben-Hadad, the son of Hazael, the cities which he had taken out of the hand of Jehoahaz his father by war. Three times Joash defeated him and recaptured the cities of Israel.

## Chapter 14

1. In the second year of Joash the son of Jehoahaz, king of Israel, Amaziah the son of Joash, king of Judah, became king.

2. He was twenty-five years old when he became king, and he reigned twenty-nine years in Jerusalem. His mother's name was Jehoaddan of Jerusalem.

3. And he did what was right in the sight of the LORD, yet not like his father David; he did everything as his father Joash had done.

4. However the high places were not taken away, and the people still sacrificed and burned incense on the high places.

5. Now it happened, as soon as the kingdom was established in his hand, that he executed his servants who had murdered his father the king.

6. But the children of the murderers he did not execute, according to what is written in the Book of the Law of Moses, in which the LORD commanded, saying, "Fathers shall not be put to death for their children, nor shall children be put to death for their fathers; but a person shall be put to death for his own sin."

7. He killed ten thousand Edomites in the Valley of Salt, and took Sela by war, and called its name Joktheel to this day.

8. Then Amaziah sent messengers to Jehoash the son of Jehoahaz, the son of Jehu, king of Israel, saying, "Come, let us face one another in battle."

9. And Jehoash king of Israel sent to Amaziah king of Judah, saying, "The thistle that was in Lebanon sent to the cedar that was in Lebanon, saying, "Give your daughter to my son as wife'; and a wild beast that was in Lebanon passed by and trampled the thistle.

10. You have indeed defeated Edom, and your heart has lifted you up. Glory in that, and stay at home; for why should you meddle with trouble so that you fall--you and Judah with you?"

11. But Amaziah would not heed. Therefore Jehoash king of Israel went out; so he and Amaziah king of Judah faced one another at Beth Shemesh, which belongs to Judah.

12. And Judah was defeated by Israel, and every man fled to his tent.

13. Then Jehoash king of Israel captured Amaziah king of Judah, the son of Jehoash, the son of Ahaziah, at Beth Shemesh; and he went to Jerusalem, and broke down the wall of Jerusalem from the Gate of Ephraim to the Corner Gate--four hundred cubits.

14. And he took all the gold and silver, all the articles that were found in the house of the LORD and in the treasuries of the king's house, and hostages, and returned to Samaria.

15. Now the rest of the acts of Jehoash which he did--his might, and how he fought with Amaziah king of Judah--are they not written in the book of the chronicles of the kings of Israel?

16. So Jehoash rested with his fathers, and was buried in Samaria with the kings of Israel. Then Jeroboam his son reigned in his place.

17. Amaziah the son of Joash, king of Judah, lived fifteen years after the death of Jehoash the son of Jehoahaz, king of Israel.

18. Now the rest of the acts of Amaziah, are they not written in the book of the chronicles of the kings of Judah?

19. And they formed a conspiracy against him in Jerusalem, and he fled to Lachish; but they sent after him to Lachish and killed him there.

20. Then they brought him on horses, and he was buried at Jerusalem with his fathers in the City of David.

21. And all the people of Judah took Azariah, who was sixteen years old, and made him king instead of his father Amaziah.

22. He built Elath and restored it to Judah, after the king rested with his fathers.

23. In the fifteenth year of Amaziah the son of Joash, king of Judah, Jeroboam the son of Joash, king of Israel, became king in Samaria, and reigned forty-one years.

24. And he did evil in the sight of the LORD; he did not depart from all the sins of Jeroboam the son of Nebat, who had made Israel sin.

25. He restored the territory of Israel from the entrance of Hamath to the Sea of the Arabah, according to the word of the LORD God of Israel, which He had spoken through His servant Jonah the son of Amittai, the prophet who was from Gath Hepher.

26. For the LORD saw that the affliction of Israel was very bitter; and whether bond or free, there was no helper for Israel.

27. And the LORD did not say that He would blot out the name of Israel from under heaven; but He saved them by the hand of Jeroboam the son of Joash.

28. Now the rest of the acts of Jeroboam, and all that he did--his might, how he made war, and how he recaptured for Israel, from Damascus and Hamath, what had belonged to Judah--are they not written in the book of the chronicles of the kings of Israel?

29. So Jeroboam rested with his fathers, the kings of Israel. Then Zechariah his son reigned in his place.

## Chapter 15

1. In the twenty-seventh year of Jeroboam king of Israel, Azariah the son of Amaziah, king of Judah, became king.

2. He was sixteen years old when he became king, and he reigned fifty-two years in Jerusalem. His mother's name was Jecholiah of Jerusalem.

3. And he did what was right in the sight of the LORD, according to all that his father Amaziah had done,

4. except that the high places were not removed; the people still sacrificed and burned incense on the high places.

5. Then the LORD struck the king, so that he was a leper until the day of his death; so he dwelt in an isolated house. And Jotham the king's son was over the royal house, judging the people of the land.

6. Now the rest of the acts of Azariah, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

7. So Azariah rested with his fathers, and they buried him with his fathers in the City of David. Then Jotham his son reigned in his place.

8. In the thirty-eighth year of Azariah king of Judah, Zechariah the son of Jeroboam reigned over Israel in Samaria six months.

9. And he did evil in the sight of the LORD, as his fathers had done; he did not depart from the sins of Jeroboam the son of Nebat, who had made Israel sin.

10. Then Shallum the son of Jabesh conspired against him, and struck and killed him in front of the people; and he reigned in his place.

11. Now the rest of the acts of Zechariah, indeed they are written in the book of the chronicles of the kings of Israel.

12. This was the word of the LORD which He spoke to Jehu, saying, "Your sons shall sit on the throne of Israel to the fourth generation." And so it was.

13. Shallum the son of Jabesh became king in the thirty-ninth year of Uzziah king of Judah; and he reigned a full month in Samaria.

14. For Menahem the son of Gadi went up from Tirzah, came to Samaria, and struck Shallum the son of Jabesh in Samaria and killed him; and he reigned in his place.

15. Now the rest of the acts of Shallum, and the conspiracy which he led, indeed they are written in the book of the chronicles of the kings of Israel.

16. Then from Tirzah, Menahem attacked Tiphsah, all who were there, and its territory. Because they did not surrender, therefore he attacked it. All the women there who were with child he ripped open.

17. In the thirty-ninth year of Azariah king of Judah, Menahem the son of Gadi became king over Israel, and reigned ten years in Samaria.

18. And he did evil in the sight of the LORD; he did not depart all his days from the sins of Jeroboam the son of Nebat, who had made Israel sin.

19. Pul king of Assyria came against the land; and Menahem gave Pul a thousand talents of silver, that his hand might be with him to strengthen the kingdom under his control.

20. And Menahem exacted the money from Israel, from all the very wealthy, from each man fifty shekels of silver, to give to the king of Assyria. So the king of Assyria turned back, and did not stay there in the land.

21. Now the rest of the acts of Menahem, and all that he did, are they not written in the book of the chronicles of the kings of Israel?

22. So Menahem rested with his fathers. Then Pekahiah his son reigned in his place.

23. In the fiftieth year of Azariah king of Judah, Pekahiah the son of Menahem became king over Israel in Samaria, and reigned two years.

24. And he did evil in the sight of the LORD; he did not depart from the sins of Jeroboam the son of Nebat, who had made Israel sin.

25. Then Pekah the son of Remaliah, an officer of his, conspired against him and killed him in Samaria, in the citadel of the king's house, along with Argob and Arieh; and with him were fifty men of Gilead. He killed him and reigned in his place.

26. Now the rest of the acts of Pekahiah, and all that he did, indeed they are written in the book of the chronicles of the kings of Israel.

27. In the fifty-second year of Azariah king of Judah, Pekah the son of Remaliah became king over Israel in Samaria, and reigned twenty years.

28. And he did evil in the sight of the LORD; he did not depart from the sins of Jeroboam the son of Nebat, who had made Israel sin.

29. In the days of Pekah king of Israel, Tiglath-Pileser king of Assyria came and took Ijon, Abel Beth Maachah, Janoah, Kedesh, Hazor, Gilead, and Galilee, all the land of Naphtali; and he carried them captive to Assyria.

30. Then Hoshea the son of Elah led a conspiracy against Pekah the son of Remaliah, and struck and killed him; so he reigned in his place in the twentieth year of Jotham the son of Uzziah.

31. Now the rest of the acts of Pekah, and all that he did, indeed they are written in the book of the chronicles of the kings of Israel.

32. In the second year of Pekah the son of Remaliah, king of Israel, Jotham the son of Uzziah, king of Judah, began to reign.

33. He was twenty-five years old when he became king, and he reigned sixteen years in Jerusalem. His mother's name was Jerusha the daughter of Zadok.

34. And he did what was right in the sight of the LORD; he did according to all that his father Uzziah had done.

35. However the high places were not removed; the people still sacrificed and burned incense on the high places. He built the Upper Gate of the house of the LORD.

36. Now the rest of the acts of Jotham, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

37. In those days the LORD began to send Rezin king of Syria and Pekah the son of Remaliah against Judah.

38. So Jotham rested with his fathers, and was buried with his fathers in the City of David his father. Then Ahaz his son reigned in his place.

## Chapter 16

1. In the seventeenth year of Pekah the son of Remaliah, Ahaz the son of Jotham, king of Judah, began to reign.

2. Ahaz was twenty years old when he became king, and he reigned sixteen years in Jerusalem; and he did not do what was right in the sight of the LORD his God, as his father David had done.

3. But he walked in the way of the kings of Israel; indeed he made his son pass through the fire, according to the abominations of the nations whom the LORD had cast out from before the children of Israel.

4. And he sacrificed and burned incense on the high places, on the hills, and under every green tree.

5. Then Rezin king of Syria and Pekah the son of Remaliah, king of Israel, came up to Jerusalem to make war; and they besieged Ahaz but could not overcome him.

6. At that time Rezin king of Syria captured Elath for Syria, and drove the men of Judah from Elath. Then the Edomites went to Elath, and dwell there to this day.

7. So Ahaz sent messengers to Tiglath-Pileser king of Assyria, saying, "I am your servant and your son. Come up and save me from the hand of the king of Syria and from the hand of the king of Israel, who rise up against me."

8. And Ahaz took the silver and gold that was found in the house of the LORD, and in the treasuries of the king's house, and sent it as a present to the king of Assyria.

9. So the king of Assyria heeded him; for the king of Assyria went up against Damascus and took it, carried its people captive to Kir, and killed Rezin.

10. Now King Ahaz went to Damascus to meet Tiglath-Pileser king of Assyria, and saw an altar that was at Damascus; and King Ahaz sent to Urijah the priest the design of the altar and its pattern, according to all its workmanship.

11. Then Urijah the priest built an altar according to all that King Ahaz had sent from Damascus. So Urijah the priest made it before King Ahaz came back from Damascus.

12. And when the king came back from Damascus, the king saw the altar; and the king approached the altar and made offerings on it.

13. So he burned his burnt offering and his grain offering; and he poured his drink offering and sprinkled the blood of his peace offerings on the altar.

14. He also brought the bronze altar which was before the LORD, from the front of the temple--from between the new altar and the house of the LORD--and put it on the north side of the new altar.

15. Then King Ahaz commanded Urijah the priest, saying, "On the great new altar burn the morning burnt offering, the evening grain offering, the king's burnt sacrifice, and his grain offering, with the burnt offering of all the people of the land, their grain offering, and their drink offerings; and sprinkle on it all the blood of the burnt offering and all the blood of the sacrifice. And the bronze altar shall be for me to inquire by."

16. Thus did Urijah the priest, according to all that King Ahaz commanded.

17. And King Ahaz cut off the panels of the carts, and removed the lavers from them; and he took down the Sea from the bronze oxen that were under it, and put it on a pavement of stones.

18. Also he removed the Sabbath pavilion which they had built in the temple, and he removed the king's outer entrance from the house of the LORD, on account of the king of Assyria.

19. Now the rest of the acts of Ahaz which he did, are they not written in the book of the chronicles of the kings of Judah?

20. So Ahaz rested with his fathers, and was buried with his fathers in the City of David. Then Hezekiah his son reigned in his place.

## Chapter 17

1. In the twelfth year of Ahaz king of Judah, Hoshea the son of Elah became king of Israel in Samaria, and he reigned nine years.

2. And he did evil in the sight of the LORD, but not as the kings of Israel who were before him.

3. Shalmaneser king of Assyria came up against him; and Hoshea became his vassal, and paid him tribute money.

4. And the king of Assyria uncovered a conspiracy by Hoshea; for he had sent messengers to So, king of Egypt, and brought no tribute to the king of Assyria, as he had done year by year. Therefore the king of Assyria shut him up, and bound him in prison.

5. Now the king of Assyria went throughout all the land, and went up to Samaria and besieged it for three years.

6. In the ninth year of Hoshea, the king of Assyria took Samaria and carried Israel away to Assyria, and placed them in Halah and by the Habor, the River of Gozan, and in the cities of the Medes.

7. For so it was that the children of Israel had sinned against the LORD their God, who had brought them up out of the land of Egypt, from under the hand of Pharaoh king of Egypt; and they had feared other gods,

8. and had walked in the statutes of the nations whom the LORD had cast out from before the children of Israel, and of the kings of Israel, which they had made.

9. Also the children of Israel secretly did against the LORD their God things that were not right, and they built for themselves high places in all their cities, from watchtower to fortified city.

10. They set up for themselves sacred pillars and wooden images on every high hill and under every green tree.

11. There they burned incense on all the high places, like the nations whom the LORD had carried away before them; and they did wicked things to provoke the LORD to anger,

12. for they served idols, of which the LORD had said to them, "You shall not do this thing."

13. Yet the LORD testified against Israel and against Judah, by all of His prophets, every seer, saying, "Turn from your evil ways, and keep My commandments and My statutes, according to all the law which I commanded your fathers, and which I sent to you by My servants the prophets."

14. Nevertheless they would not hear, but stiffened their necks, like the necks of their fathers, who did not believe in the LORD their God.

15. And they rejected His statutes and His covenant that He had made with their fathers, and His testimonies which He had testified against them; they followed idols, became idolaters, and went after the nations who were all around them, concerning whom the LORD had charged them that they should not do like them.

16. So they left all the commandments of the LORD their God, made for themselves a molded image and two calves, made a wooden image and worshiped all the host of heaven, and served Baal.

17. And they caused their sons and daughters to pass through the fire, practiced witchcraft and soothsaying, and sold themselves to do evil in the sight of the LORD, to provoke Him to anger.

18. Therefore the LORD was very angry with Israel, and removed them from His sight; there was none left but the tribe of Judah alone.

19. Also Judah did not keep the commandments of the LORD their God, but walked in the statutes of Israel which they made.

20. And the LORD rejected all the descendants of Israel, afflicted them, and delivered them into the hand of plunderers, until He had cast them from His sight.

21. For He tore Israel from the house of David, and they made Jeroboam the son of Nebat king. Then Jeroboam drove Israel from following the LORD, and made them commit a great sin.

22. For the children of Israel walked in all the sins of Jeroboam which he did; they did not depart from them,

23. until the LORD removed Israel out of His sight, as He had said by all His servants the prophets. So Israel was carried away from their own land to Assyria, as it is to this day.

24. Then the king of Assyria brought people from Babylon, Cuthah, Ava, Hamath, and from Sepharvaim, and placed them in the cities of Samaria instead of the children of Israel; and they took possession of Samaria and dwelt in its cities.

25. And it was so, at the beginning of their dwelling there, that they did not fear the LORD; therefore the LORD sent lions among them, which killed some of them.

26. So they spoke to the king of Assyria, saying, "The nations whom you have removed and placed in the cities of Samaria do not know the rituals of the God of the land; therefore He has sent lions among them, and indeed, they are killing them because they do not know the rituals of the God of the land."

27. Then the king of Assyria commanded, saying, "Send there one of the priests whom you brought from there; let him go and dwell there, and let him teach them the rituals of the God of the land."

28. Then one of the priests whom they had carried away from Samaria came and dwelt in Bethel, and taught them how they should fear the LORD.

29. However every nation continued to make gods of its own, and put them in the shrines on the high places which the Samaritans had made, every nation in the cities where they dwelt.

30. The men of Babylon made Succoth Benoth, the men of Cuth made Nergal, the men of Hamath made Ashima,

31. and the Avites made Nibhaz and Tartak; and the Sepharvites burned their children in fire to Adrammelech and Anammelech, the gods of Sepharvaim.

32. So they feared the LORD, and from every class they appointed for themselves priests of the high places, who sacrificed for them in the shrines of the high places.

33. They feared the LORD, yet served their own gods--according to the rituals of the nations from among whom they were carried away.

34. To this day they continue practicing the former rituals; they do not fear the LORD, nor do they follow their statutes or their ordinances, or the law and commandment which the LORD had commanded the children of Jacob, whom He named Israel,

35. with whom the LORD had made a covenant and charged them, saying: "You shall not fear other gods, nor bow down to them nor serve them nor sacrifice to them;

36. but the LORD, who brought you up from the land of Egypt with great power and an outstretched arm, Him you shall fear, Him you shall worship, and to Him you shall offer sacrifice.

37. And the statutes, the ordinances, the law, and the commandment which He wrote for you, you shall be careful to observe forever; you shall not fear other gods.

38. And the covenant that I have made with you, you shall not forget, nor shall you fear other gods.

39. But the LORD your God you shall fear; and He will deliver you from the hand of all your enemies."

40. However they did not obey, but they followed their former rituals.

41. So these nations feared the LORD, yet served their carved images; also their children and their children's children have continued doing as their fathers did, even to this day.

## Chapter 18

1. Now it came to pass in the third year of Hoshea the son of Elah, king of Israel, that Hezekiah the son of Ahaz, king of Judah, began to reign.

2. He was twenty-five years old when he became king, and he reigned twenty-nine years in Jerusalem. His mother's name was Abi the daughter of Zechariah.

3. And he did what was right in the sight of the LORD, according to all that his father David had done.

4. He removed the high places and broke the sacred pillars, cut down the wooden image and broke in pieces the bronze serpent that Moses had made; for until those days the children of Israel burned incense to it, and called it Nehushtan.

5. He trusted in the LORD God of Israel, so that after him was none like him among all the kings of Judah, nor who were before him.

6. For he held fast to the LORD; he did not depart from following Him, but kept His commandments, which the LORD had commanded Moses.

7. The LORD was with him; he prospered wherever he went. And he rebelled against the king of Assyria and did not serve him.

8. He subdued the Philistines, as far as Gaza and its territory, from watchtower to fortified city.

9. Now it came to pass in the fourth year of King Hezekiah, which was the seventh year of Hoshea the son of Elah, king of Israel, that Shalmaneser king of Assyria came up against Samaria and besieged it.

10. And at the end of three years they took it. In the sixth year of Hezekiah, that is, the ninth year of Hoshea king of Israel, Samaria was taken.

11. Then the king of Assyria carried Israel away captive to Assyria, and put them in Halah and by the Habor, the River of Gozan, and in the cities of the Medes,

12. because they did not obey the voice of the LORD their God, but transgressed His covenant and all that Moses the servant of the LORD had commanded; and they would neither hear nor do them.

13. And in the fourteenth year of King Hezekiah, Sennacherib king of Assyria came up against all the fortified cities of Judah and took them.

14. Then Hezekiah king of Judah sent to the king of Assyria at Lachish, saying, "I have done wrong; turn away from me; whatever you impose on me I will pay." And the king of Assyria assessed Hezekiah king of Judah three hundred talents of silver and thirty talents of gold.

15. So Hezekiah gave him all the silver that was found in the house of the LORD and in the treasuries of the king's house.

16. At that time Hezekiah stripped the gold from the doors of the temple of the LORD, and from the pillars which Hezekiah king of Judah had overlaid, and gave it to the king of Assyria.

17. Then the king of Assyria sent the Tartan, the Rabsaris, and the Rabshakeh from Lachish, with a great army against Jerusalem, to King Hezekiah. And they went up and came to Jerusalem. When they had come up, they went and stood by the aqueduct from the upper pool, which was on the highway to the Fuller's Field.

18. And when they had called to the king, Eliakim the son of Hilkiah, who was over the household, Shebna the scribe, and Joah the son of Asaph, the recorder, came out to them.

19. Then the Rabshakeh said to them, "Say now to Hezekiah, "Thus says the great king, the king of Assyria: "What confidence is this in which you trust?

20. You speak of having plans and power for war; but they are mere words. And in whom do you trust, that you rebel against me?

21. Now look! You are trusting in the staff of this broken reed, Egypt, on which if a man leans, it will go into his hand and pierce it. So is Pharaoh king of Egypt to all who trust in him.

22. But if you say to me, "We trust in the LORD our God,' is it not He whose high places and whose altars Hezekiah has taken away, and said to Judah and Jerusalem, "You shall worship before this altar in Jerusalem'?"'

23. Now therefore, I urge you, give a pledge to my master the king of Assyria, and I will give you two thousand horses--if you are able on your part to put riders on them!

24. How then will you repel one captain of the least of my master's servants, and put your trust in Egypt for chariots and horsemen?

25. Have I now come up without the LORD against this place to destroy it? The LORD said to me, "Go up against this land, and destroy it."'

26. Then Eliakim the son of Hilkiah, Shebna, and Joah said to the Rabshakeh, "Please speak to your servants in Aramaic, for we understand it; and do not speak to us in Hebrew in the hearing of the people who are on the wall."

27. But the Rabshakeh said to them, "Has my master sent me to your master and to you to speak these words, and not to the men who sit on the wall, who will eat and drink their own waste with you?"

28. Then the Rabshakeh stood and called out with a loud voice in Hebrew, and spoke, saying, "Hear the word of the great king, the king of Assyria!

29. Thus says the king: "Do not let Hezekiah deceive you, for he shall not be able to deliver you from his hand;

30. nor let Hezekiah make you trust in the LORD, saying, "The LORD will surely deliver us; this city shall not be given into the hand of the king of Assyria."'

31. Do not listen to Hezekiah; for thus says the king of Assyria: "Make peace with me by a present and come out to me; and every one of you eat from his own vine and every one from his own fig tree, and every one of you drink the waters of his own cistern;

32. until I come and take you away to a land like your own land, a land of grain and new wine, a land of bread and vineyards, a land of olive groves and honey, that you may live and not die. But do not listen to Hezekiah, lest he persuade you, saying, "The LORD will deliver us."

33. Has any of the gods of the nations at all delivered its land from the hand of the king of Assyria?

34. Where are the gods of Hamath and Arpad? Where are the gods of Sepharvaim and Hena and Ivah? Indeed, have they delivered Samaria from my hand?

35. Who among all the gods of the lands have delivered their countries from my hand, that the LORD should deliver Jerusalem from my hand?"'

36. But the people held their peace and answered him not a word; for the king's commandment was, "Do not answer him."

37. Then Eliakim the son of Hilkiah, who was over the household, Shebna the scribe, and Joah the son of Asaph, the recorder, came to Hezekiah with their clothes torn, and told him the words of the Rabshakeh.

## Chapter 19

1. And so it was, when King Hezekiah heard it, that he tore his clothes, covered himself with sackcloth, and went into the house of the LORD.

2. Then he sent Eliakim, who was over the household, Shebna the scribe, and the elders of the priests, covered with sackcloth, to Isaiah the prophet, the son of Amoz.

3. And they said to him, "Thus says Hezekiah: "This day is a day of trouble, and rebuke, and blasphemy; for the children have come to birth, but there is no strength to bring them forth.

4. It may be that the LORD your God will hear all the words of the Rabshakeh, whom his master the king of Assyria has sent to reproach the living God, and will rebuke the words which the LORD your God has heard. Therefore lift up your prayer for the remnant that is left."'

5. So the servants of King Hezekiah came to Isaiah.

6. And Isaiah said to them, "Thus you shall say to your master, "Thus says the LORD: "Do not be afraid of the words which you have heard, with which the servants of the king of Assyria have blasphemed Me.

7. Surely I will send a spirit upon him, and he shall hear a rumor and return to his own land; and I will cause him to fall by the sword in his own land.""'

8. Then the Rabshakeh returned and found the king of Assyria warring against Libnah, for he heard that he had departed from Lachish.

9. And the king heard concerning Tirhakah king of Ethiopia, "Look, he has come out to make war with you." So he again sent messengers to Hezekiah, saying,

10. "Thus you shall speak to Hezekiah king of Judah, saying: "Do not let your God in whom you trust deceive you, saying, "Jerusalem shall not be given into the hand of the king of Assyria."

11. Look! You have heard what the kings of Assyria have done to all lands by utterly destroying them; and shall you be delivered?

12. Have the gods of the nations delivered those whom my fathers have destroyed, Gozan and Haran and Rezeph, and the people of Eden who were in Telassar?

13. Where is the king of Hamath, the king of Arpad, and the king of the city of Sepharvaim, Hena, and Ivah?"'

14. And Hezekiah received the letter from the hand of the messengers, and read it; and Hezekiah went up to the house of the LORD, and spread it before the LORD.

15. Then Hezekiah prayed before the LORD, and said: "O LORD God of Israel, the One who dwells between the cherubim, You are God, You alone, of all the kingdoms of the earth. You have made heaven and earth.

16. Incline Your ear, O LORD, and hear; open Your eyes, O LORD, and see; and hear the words of Sennacherib, which he has sent to reproach the living God.

17. Truly, LORD, the kings of Assyria have laid waste the nations and their lands,

18. and have cast their gods into the fire; for they were not gods, but the work of men's hands--wood and stone. Therefore they destroyed them.

19. Now therefore, O LORD our God, I pray, save us from his hand, that all the kingdoms of the earth may know that You are the LORD God, You alone."

20. Then Isaiah the son of Amoz sent to Hezekiah, saying, "Thus says the LORD God of Israel: "Because you have prayed to Me against Sennacherib king of Assyria, I have heard.'

21. This is the word which the LORD has spoken concerning him: "The virgin, the daughter of Zion, Has despised you, laughed you to scorn; The daughter of Jerusalem Has shaken her head behind your back!

22. "Whom have you reproached and blasphemed? Against whom have you raised your voice, And lifted up your eyes on high? Against the Holy One of Israel.

23. By your messengers you have reproached the Lord, And said: "By the multitude of my chariots I have come up to the height of the mountains, To the limits of Lebanon; I will cut down its tall cedars And its choice cypress trees; I will enter the extremity of its borders, To its fruitful forest.

24. I have dug and drunk strange water, And with the soles of my feet I have dried up All the brooks of defense."

25. "Did you not hear long ago How I made it, From ancient times that I formed it? Now I have brought it to pass, That you should be For crushing fortified cities into heaps of ruins.

26. Therefore their inhabitants had little power; They were dismayed and confounded; They were as the grass of the field And the green herb, As the grass on the housetops And grain blighted before it is grown.

27. "But I know your dwelling place, Your going out and your coming in, And your rage against Me.

28. Because your rage against Me and your tumult Have come up to My ears, Therefore I will put My hook in your nose And My bridle in your lips, And I will turn you back By the way which you came.

29. "This shall be a sign to you: You shall eat this year such as grows of itself, And in the second year what springs from the same; Also in the third year sow and reap, Plant vineyards and eat the fruit of them.

30. And the remnant who have escaped of the house of Judah Shall again take root downward, And bear fruit upward.

31. For out of Jerusalem shall go a remnant, And those who escape from Mount Zion. The zeal of the LORD of hosts will do this.'

32. "Therefore thus says the LORD concerning the king of Assyria: "He shall not come into this city, Nor shoot an arrow there, Nor come before it with shield, Nor build a siege mound against it.

33. By the way that he came, By the same shall he return; And he shall not come into this city,' Says the LORD.

34. "For I will defend this city, to save it For My own sake and for My servant David's sake."'

35. And it came to pass on a certain night that the angel of the LORD went out, and killed in the camp of the Assyrians one hundred and eighty-five thousand; and when people arose early in the morning, there were the corpses--all dead.

36. So Sennacherib king of Assyria departed and went away, returned home, and remained at Nineveh.

37. Now it came to pass, as he was worshiping in the temple of Nisroch his god, that his sons Adrammelech and Sharezer struck him down with the sword; and they escaped into the land of Ararat. Then Esarhaddon his son reigned in his place.

## Chapter 20

1. In those days Hezekiah was sick and near death. And Isaiah the prophet, the son of Amoz, went to him and said to him, "Thus says the LORD: "Set your house in order, for you shall die, and not live."'

2. Then he turned his face toward the wall, and prayed to the LORD, saying,

3. "Remember now, O LORD, I pray, how I have walked before You in truth and with a loyal heart, and have done what was good in Your sight." And Hezekiah wept bitterly.

4. And it happened, before Isaiah had gone out into the middle court, that the word of the LORD came to him, saying,

5. "Return and tell Hezekiah the leader of My people, "Thus says the LORD, the God of David your father: "I have heard your prayer, I have seen your tears; surely I will heal you. On the third day you shall go up to the house of the LORD.

6. And I will add to your days fifteen years. I will deliver you and this city from the hand of the king of Assyria; and I will defend this city for My own sake, and for the sake of My servant David.""'

7. Then Isaiah said, "Take a lump of figs." So they took and laid it on the boil, and he recovered.

8. And Hezekiah said to Isaiah, "What is the sign that the LORD will heal me, and that I shall go up to the house of the LORD the third day?"

9. Then Isaiah said, "This is the sign to you from the LORD, that the LORD will do the thing which He has spoken: shall the shadow go forward ten degrees or go backward ten degrees?"

10. And Hezekiah answered, "It is an easy thing for the shadow to go down ten degrees; no, but let the shadow go backward ten degrees."

11. So Isaiah the prophet cried out to the LORD, and He brought the shadow ten degrees backward, by which it had gone down on the sundial of Ahaz.

12. At that time Berodach-Baladan the son of Baladan, king of Babylon, sent letters and a present to Hezekiah, for he heard that Hezekiah had been sick.

13. And Hezekiah was attentive to them, and showed them all the house of his treasures--the silver and gold, the spices and precious ointment, and all his armory--all that was found among his treasures. There was nothing in his house or in all his dominion that Hezekiah did not show them.

14. Then Isaiah the prophet went to King Hezekiah, and said to him, "What did these men say, and from where did they come to you?" So Hezekiah said, "They came from a far country, from Babylon."

15. And he said, "What have they seen in your house?" So Hezekiah answered, "They have seen all that is in my house; there is nothing among my treasures that I have not shown them."

16. Then Isaiah said to Hezekiah, "Hear the word of the LORD:

17. "Behold, the days are coming when all that is in your house, and what your fathers have accumulated until this day, shall be carried to Babylon; nothing shall be left,' says the LORD.

18. "And they shall take away some of your sons who will descend from you, whom you will beget; and they shall be eunuchs in the palace of the king of Babylon."'

19. So Hezekiah said to Isaiah, "The word of the LORD which you have spoken is good!" For he said, "Will there not be peace and truth at least in my days?"

20. Now the rest of the acts of Hezekiah--all his might, and how he made a pool and a tunnel and brought water into the city--are they not written in the book of the chronicles of the kings of Judah?

21. So Hezekiah rested with his fathers. Then Manasseh his son reigned in his place.

## Chapter 21

1. Manasseh was twelve years old when he became king, and he reigned fifty-five years in Jerusalem. His mother's name was Hephzibah.

2. And he did evil in the sight of the LORD, according to the abominations of the nations whom the LORD had cast out before the children of Israel.

3. For he rebuilt the high places which Hezekiah his father had destroyed; he raised up altars for Baal, and made a wooden image, as Ahab king of Israel had done; and he worshiped all the host of heaven and served them.

4. He also built altars in the house of the LORD, of which the LORD had said, "In Jerusalem I will put My name."

5. And he built altars for all the host of heaven in the two courts of the house of the LORD.

6. Also he made his son pass through the fire, practiced soothsaying, used witchcraft, and consulted spiritists and mediums. He did much evil in the sight of the LORD, to provoke Him to anger.

7. He even set a carved image of Asherah that he had made, in the house of which the LORD had said to David and to Solomon his son, "In this house and in Jerusalem, which I have chosen out of all the tribes of Israel, I will put My name forever;

8. and I will not make the feet of Israel wander anymore from the land which I gave their fathers--only if they are careful to do according to all that I have commanded them, and according to all the law that My servant Moses commanded them."

9. But they paid no attention, and Manasseh seduced them to do more evil than the nations whom the LORD had destroyed before the children of Israel.

10. And the LORD spoke by His servants the prophets, saying,

11. "Because Manasseh king of Judah has done these abominations (he has acted more wickedly than all the Amorites who were before him, and has also made Judah sin with his idols),

12. therefore thus says the LORD God of Israel: "Behold, I am bringing such calamity upon Jerusalem and Judah, that whoever hears of it, both his ears will tingle.

13. And I will stretch over Jerusalem the measuring line of Samaria and the plummet of the house of Ahab; I will wipe Jerusalem as one wipes a dish, wiping it and turning it upside down.

14. So I will forsake the remnant of My inheritance and deliver them into the hand of their enemies; and they shall become victims of plunder to all their enemies,

15. because they have done evil in My sight, and have provoked Me to anger since the day their fathers came out of Egypt, even to this day."'

16. Moreover Manasseh shed very much innocent blood, till he had filled Jerusalem from one end to another, besides his sin by which he made Judah sin, in doing evil in the sight of the LORD.

17. Now the rest of the acts of Manasseh--all that he did, and the sin that he committed--are they not written in the book of the chronicles of the kings of Judah?

18. So Manasseh rested with his fathers, and was buried in the garden of his own house, in the garden of Uzza. Then his son Amon reigned in his place.

19. Amon was twenty-two years old when he became king, and he reigned two years in Jerusalem. His mother's name was Meshullemeth the daughter of Haruz of Jotbah.

20. And he did evil in the sight of the LORD, as his father Manasseh had done.

21. So he walked in all the ways that his father had walked; and he served the idols that his father had served, and worshiped them.

22. He forsook the LORD God of his fathers, and did not walk in the way of the LORD.

23. Then the servants of Amon conspired against him, and killed the king in his own house.

24. But the people of the land executed all those who had conspired against King Amon. Then the people of the land made his son Josiah king in his place.

25. Now the rest of the acts of Amon which he did, are they not written in the book of the chronicles of the kings of Judah?

26. And he was buried in his tomb in the garden of Uzza. Then Josiah his son reigned in his place.

## Chapter 22

1. Josiah was eight years old when he became king, and he reigned thirty-one years in Jerusalem. His mother's name was Jedidah the daughter of Adaiah of Bozkath.

2. And he did what was right in the sight of the LORD, and walked in all the ways of his father David; he did not turn aside to the right hand or to the left.

3. Now it came to pass, in the eighteenth year of King Josiah, that the king sent Shaphan the scribe, the son of Azaliah, the son of Meshullam, to the house of the LORD, saying:

4. "Go up to Hilkiah the high priest, that he may count the money which has been brought into the house of the LORD, which the doorkeepers have gathered from the people.

5. And let them deliver it into the hand of those doing the work, who are the overseers in the house of the LORD; let them give it to those who are in the house of the LORD doing the work, to repair the damages of the house--

6. to carpenters and builders and masons--and to buy timber and hewn stone to repair the house.

7. However there need be no accounting made with them of the money delivered into their hand, because they deal faithfully."

8. Then Hilkiah the high priest said to Shaphan the scribe, "I have found the Book of the Law in the house of the LORD." And Hilkiah gave the book to Shaphan, and he read it.

9. So Shaphan the scribe went to the king, bringing the king word, saying, "Your servants have gathered the money that was found in the house, and have delivered it into the hand of those who do the work, who oversee the house of the LORD."

10. Then Shaphan the scribe showed the king, saying, "Hilkiah the priest has given me a book." And Shaphan read it before the king.

11. Now it happened, when the king heard the words of the Book of the Law, that he tore his clothes.

12. Then the king commanded Hilkiah the priest, Ahikam the son of Shaphan, Achbor the son of Michaiah, Shaphan the scribe, and Asaiah a servant of the king, saying,

13. "Go, inquire of the LORD for me, for the people and for all Judah, concerning the words of this book that has been found; for great is the wrath of the LORD that is aroused against us, because our fathers have not obeyed the words of this book, to do according to all that is written concerning us."

14. So Hilkiah the priest, Ahikam, Achbor, Shaphan, and Asaiah went to Huldah the prophetess, the wife of Shallum the son of Tikvah, the son of Harhas, keeper of the wardrobe. (She dwelt in Jerusalem in the Second Quarter.) And they spoke with her.

15. Then she said to them, "Thus says the LORD God of Israel, "Tell the man who sent you to Me,

16. "Thus says the LORD: "Behold, I will bring calamity on this place and on its inhabitants--all the words of the book which the king of Judah has read--

17. because they have forsaken Me and burned incense to other gods, that they might provoke Me to anger with all the works of their hands. Therefore My wrath shall be aroused against this place and shall not be quenched.""

18. But as for the king of Judah, who sent you to inquire of the LORD, in this manner you shall speak to him, "Thus says the LORD God of Israel: "Concerning the words which you have heard--

19. because your heart was tender, and you humbled yourself before the LORD when you heard what I spoke against this place and against its inhabitants, that they would become a desolation and a curse, and you tore your clothes and wept before Me, I also have heard you," says the LORD.

20. Surely, therefore, I will gather you to your fathers, and you shall be gathered to your grave in peace; and your eyes shall not see all the calamity which I will bring on this place.""' So they brought back word to the king.

## Chapter 23

1. Now the king sent them to gather all the elders of Judah and Jerusalem to him.

2. The king went up to the house of the LORD with all the men of Judah, and with him all the inhabitants of Jerusalem--the priests and the prophets and all the people, both small and great. And he read in their hearing all the words of the Book of the Covenant which had been found in the house of the LORD.

3. Then the king stood by a pillar and made a covenant before the LORD, to follow the LORD and to keep His commandments and His testimonies and His statutes, with all his heart and all his soul, to perform the words of this covenant that were written in this book. And all the people took a stand for the covenant.

4. And the king commanded Hilkiah the high priest, the priests of the second order, and the doorkeepers, to bring out of the temple of the LORD all the articles that were made for Baal, for Asherah, and for all the host of heaven; and he burned them outside Jerusalem in the fields of Kidron, and carried their ashes to Bethel.

5. Then he removed the idolatrous priests whom the kings of Judah had ordained to burn incense on the high places in the cities of Judah and in the places all around Jerusalem, and those who burned incense to Baal, to the sun, to the moon, to the constellations, and to all the host of heaven.

6. And he brought out the wooden image from the house of the LORD, to the Brook Kidron outside Jerusalem, burned it at the Brook Kidron and ground it to ashes, and threw its ashes on the graves of the common people.

7. Then he tore down the ritual booths of the perverted persons that were in the house of the LORD, where the women wove hangings for the wooden image.

8. And he brought all the priests from the cities of Judah, and defiled the high places where the priests had burned incense, from Geba to Beersheba; also he broke down the high places at the gates which were at the entrance of the Gate of Joshua the governor of the city, which were to the left of the city gate.

9. Nevertheless the priests of the high places did not come up to the altar of the LORD in Jerusalem, but they ate unleavened bread among their brethren.

10. And he defiled Topheth, which is in the Valley of the Son of Hinnom, that no man might make his son or his daughter pass through the fire to Molech.

11. Then he removed the horses that the kings of Judah had dedicated to the sun, at the entrance to the house of the LORD, by the chamber of Nathan-Melech, the officer who was in the court; and he burned the chariots of the sun with fire.

12. The altars that were on the roof, the upper chamber of Ahaz, which the kings of Judah had made, and the altars which Manasseh had made in the two courts of the house of the LORD, the king broke down and pulverized there, and threw their dust into the Brook Kidron.

13. Then the king defiled the high places that were east of Jerusalem, which were on the south of the Mount of Corruption, which Solomon king of Israel had built for Ashtoreth the abomination of the Sidonians, for Chemosh the abomination of the Moabites, and for Milcom the abomination of the people of Ammon.

14. And he broke in pieces the sacred pillars and cut down the wooden images, and filled their places with the bones of men.

15. Moreover the altar that was at Bethel, and the high place which Jeroboam the son of Nebat, who made Israel sin, had made, both that altar and the high place he broke down; and he burned the high place and crushed it to powder, and burned the wooden image.

16. As Josiah turned, he saw the tombs that were there on the mountain. And he sent and took the bones out of the tombs and burned them on the altar, and defiled it according to the word of the LORD which the man of God proclaimed, who proclaimed these words.

17. Then he said, "What gravestone is this that I see?" So the men of the city told him, "It is the tomb of the man of God who came from Judah and proclaimed these things which you have done against the altar of Bethel."

18. And he said, "Let him alone; let no one move his bones." So they let his bones alone, with the bones of the prophet who came from Samaria.

19. Now Josiah also took away all the shrines of the high places that were in the cities of Samaria, which the kings of Israel had made to provoke the LORD to anger; and he did to them according to all the deeds he had done in Bethel.

20. He executed all the priests of the high places who were there, on the altars, and burned men's bones on them; and he returned to Jerusalem.

21. Then the king commanded all the people, saying, "Keep the Passover to the LORD your God, as it is written in this Book of the Covenant."

22. Such a Passover surely had never been held since the days of the judges who judged Israel, nor in all the days of the kings of Israel and the kings of Judah.

23. But in the eighteenth year of King Josiah this Passover was held before the LORD in Jerusalem.

24. Moreover Josiah put away those who consulted mediums and spiritists, the household gods and idols, all the abominations that were seen in the land of Judah and in Jerusalem, that he might perform the words of the law which were written in the book that Hilkiah the priest found in the house of the LORD.

25. Now before him there was no king like him, who turned to the LORD with all his heart, with all his soul, and with all his might, according to all the Law of Moses; nor after him did any arise like him.

26. Nevertheless the LORD did not turn from the fierceness of His great wrath, with which His anger was aroused against Judah, because of all the provocations with which Manasseh had provoked Him.

27. And the LORD said, "I will also remove Judah from My sight, as I have removed Israel, and will cast off this city Jerusalem which I have chosen, and the house of which I said, "My name shall be there."'

28. Now the rest of the acts of Josiah, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

29. In his days Pharaoh Necho king of Egypt went to the aid of the king of Assyria, to the River Euphrates; and King Josiah went against him. And Pharaoh Necho killed him at Megiddo when he confronted him.

30. Then his servants moved his body in a chariot from Megiddo, brought him to Jerusalem, and buried him in his own tomb. And the people of the land took Jehoahaz the son of Josiah, anointed him, and made him king in his father's place.

31. Jehoahaz was twenty-three years old when he became king, and he reigned three months in Jerusalem. His mother's name was Hamutal the daughter of Jeremiah of Libnah.

32. And he did evil in the sight of the LORD, according to all that his fathers had done.

33. Now Pharaoh Necho put him in prison at Riblah in the land of Hamath, that he might not reign in Jerusalem; and he imposed on the land a tribute of one hundred talents of silver and a talent of gold.

34. Then Pharaoh Necho made Eliakim the son of Josiah king in place of his father Josiah, and changed his name to Jehoiakim. And Pharaoh took Jehoahaz and went to Egypt, and he died there.

35. So Jehoiakim gave the silver and gold to Pharaoh; but he taxed the land to give money according to the command of Pharaoh; he exacted the silver and gold from the people of the land, from every one according to his assessment, to give it to Pharaoh Necho.

36. Jehoiakim was twenty-five years old when he became king, and he reigned eleven years in Jerusalem. His mother's name was Zebudah the daughter of Pedaiah of Rumah.

37. And he did evil in the sight of the LORD, according to all that his fathers had done.

## Chapter 24

1. In his days Nebuchadnezzar king of Babylon came up, and Jehoiakim became his vassal for three years. Then he turned and rebelled against him.

2. And the LORD sent against him raiding bands of Chaldeans, bands of Syrians, bands of Moabites, and bands of the people of Ammon; He sent them against Judah to destroy it, according to the word of the LORD which He had spoken by His servants the prophets.

3. Surely at the commandment of the LORD this came upon Judah, to remove them from His sight because of the sins of Manasseh, according to all that he had done,

4. and also because of the innocent blood that he had shed; for he had filled Jerusalem with innocent blood, which the LORD would not pardon.

5. Now the rest of the acts of Jehoiakim, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

6. So Jehoiakim rested with his fathers. Then Jehoiachin his son reigned in his place.

7. And the king of Egypt did not come out of his land anymore, for the king of Babylon had taken all that belonged to the king of Egypt from the Brook of Egypt to the River Euphrates.

8. Jehoiachin was eighteen years old when he became king, and he reigned in Jerusalem three months. His mother's name was Nehushta the daughter of Elnathan of Jerusalem.

9. And he did evil in the sight of the LORD, according to all that his father had done.

10. At that time the servants of Nebuchadnezzar king of Babylon came up against Jerusalem, and the city was besieged.

11. And Nebuchadnezzar king of Babylon came against the city, as his servants were besieging it.

12. Then Jehoiachin king of Judah, his mother, his servants, his princes, and his officers went out to the king of Babylon; and the king of Babylon, in the eighth year of his reign, took him prisoner.

13. And he carried out from there all the treasures of the house of the LORD and the treasures of the king's house, and he cut in pieces all the articles of gold which Solomon king of Israel had made in the temple of the LORD, as the LORD had said.

14. Also he carried into captivity all Jerusalem: all the captains and all the mighty men of valor, ten thousand captives, and all the craftsmen and smiths. None remained except the poorest people of the land.

15. And he carried Jehoiachin captive to Babylon. The king's mother, the king's wives, his officers, and the mighty of the land he carried into captivity from Jerusalem to Babylon.

16. All the valiant men, seven thousand, and craftsmen and smiths, one thousand, all who were strong and fit for war, these the king of Babylon brought captive to Babylon.

17. Then the king of Babylon made Mattaniah, Jehoiachin's uncle, king in his place, and changed his name to Zedekiah.

18. Zedekiah was twenty-one years old when he became king, and he reigned eleven years in Jerusalem. His mother's name was Hamutal the daughter of Jeremiah of Libnah.

19. He also did evil in the sight of the LORD, according to all that Jehoiakim had done.

20. For because of the anger of the LORD this happened in Jerusalem and Judah, that He finally cast them out from His presence. Then Zedekiah rebelled against the king of Babylon.

## Chapter 25

1. Now it came to pass in the ninth year of his reign, in the tenth month, on the tenth day of the month, that Nebuchadnezzar king of Babylon and all his army came against Jerusalem and encamped against it; and they built a siege wall against it all around.

2. So the city was besieged until the eleventh year of King Zedekiah.

3. By the ninth day of the fourth month the famine had become so severe in the city that there was no food for the people of the land.

4. Then the city wall was broken through, and all the men of war fled at night by way of the gate between two walls, which was by the king's garden, even though the Chaldeans were still encamped all around against the city. And the king went by way of the plain.

5. But the army of the Chaldeans pursued the king, and they overtook him in the plains of Jericho. All his army was scattered from him.

6. So they took the king and brought him up to the king of Babylon at Riblah, and they pronounced judgment on him.

7. Then they killed the sons of Zedekiah before his eyes, put out the eyes of Zedekiah, bound him with bronze fetters, and took him to Babylon.

8. And in the fifth month, on the seventh day of the month (which was the nineteenth year of King Nebuchadnezzar king of Babylon), Nebuzaradan the captain of the guard, a servant of the king of Babylon, came to Jerusalem.

9. He burned the house of the LORD and the king's house; all the houses of Jerusalem, that is, all the houses of the great, he burned with fire.

10. And all the army of the Chaldeans who were with the captain of the guard broke down the walls of Jerusalem all around.

11. Then Nebuzaradan the captain of the guard carried away captive the rest of the people who remained in the city and the defectors who had deserted to the king of Babylon, with the rest of the multitude.

12. But the captain of the guard left some of the poor of the land as vinedressers and farmers.

13. The bronze pillars that were in the house of the LORD, and the carts and the bronze Sea that were in the house of the LORD, the Chaldeans broke in pieces, and carried their bronze to Babylon.

14. They also took away the pots, the shovels, the trimmers, the spoons, and all the bronze utensils with which the priests ministered.

15. The firepans and the basins, the things of solid gold and solid silver, the captain of the guard took away.

16. The two pillars, one Sea, and the carts, which Solomon had made for the house of the LORD, the bronze of all these articles was beyond measure.

17. The height of one pillar was eighteen cubits, and the capital on it was of bronze. The height of the capital was three cubits, and the network and pomegranates all around the capital were all of bronze. The second pillar was the same, with a network.

18. And the captain of the guard took Seraiah the chief priest, Zephaniah the second priest, and the three doorkeepers.

19. He also took out of the city an officer who had charge of the men of war, five men of the king's close associates who were found in the city, the chief recruiting officer of the army, who mustered the people of the land, and sixty men of the people of the land who were found in the city.

20. So Nebuzaradan, captain of the guard, took these and brought them to the king of Babylon at Riblah.

21. Then the king of Babylon struck them and put them to death at Riblah in the land of Hamath. Thus Judah was carried away captive from its own land.

22. Then he made Gedaliah the son of Ahikam, the son of Shaphan, governor over the people who remained in the land of Judah, whom Nebuchadnezzar king of Babylon had left.

23. Now when all the captains of the armies, they and their men, heard that the king of Babylon had made Gedaliah governor, they came to Gedaliah at Mizpah--Ishmael the son of Nethaniah, Johanan the son of Careah, Seraiah the son of Tanhumeth the Netophathite, and Jaazaniah the son of a Maachathite, they and their men.

24. And Gedaliah took an oath before them and their men, and said to them, "Do not be afraid of the servants of the Chaldeans. Dwell in the land and serve the king of Babylon, and it shall be well with you."

25. But it happened in the seventh month that Ishmael the son of Nethaniah, the son of Elishama, of the royal family, came with ten men and struck and killed Gedaliah, the Jews, as well as the Chaldeans who were with him at Mizpah.

26. And all the people, small and great, and the captains of the armies, arose and went to Egypt; for they were afraid of the Chaldeans.

27. Now it came to pass in the thirty-seventh year of the captivity of Jehoiachin king of Judah, in the twelfth month, on the twenty-seventh day of the month, that Evil-Merodach king of Babylon, in the year that he began to reign, released Jehoiachin king of Judah from prison.

28. He spoke kindly to him, and gave him a more prominent seat than those of the kings who were with him in Babylon.

29. So Jehoiachin changed from his prison garments, and he ate bread regularly before the king all the days of his life.

30. And as for his provisions, there was a regular ration given him by the king, a portion for each day, all the days of his life.


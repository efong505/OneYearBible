# 2-samuel

## Chapter 1

1. Now it came to pass after the death of Saul, when David had returned from the slaughter of the Amalekites, and David had stayed two days in Ziklag,

2. on the third day, behold, it happened that a man came from Saul's camp with his clothes torn and dust on his head. So it was, when he came to David, that he fell to the ground and prostrated himself.

3. And David said to him, "Where have you come from?" So he said to him, "I have escaped from the camp of Israel."

4. Then David said to him, "How did the matter go? Please tell me." And he answered, "The people have fled from the battle, many of the people are fallen and dead, and Saul and Jonathan his son are dead also."

5. So David said to the young man who told him, "How do you know that Saul and Jonathan his son are dead?"

6. Then the young man who told him said, "As I happened by chance to be on Mount Gilboa, there was Saul, leaning on his spear; and indeed the chariots and horsemen followed hard after him.

7. Now when he looked behind him, he saw me and called to me. And I answered, "Here I am.'

8. And he said to me, "Who are you?' So I answered him, "I am an Amalekite.'

9. He said to me again, "Please stand over me and kill me, for anguish has come upon me, but my life still remains in me.'

10. So I stood over him and killed him, because I was sure that he could not live after he had fallen. And I took the crown that was on his head and the bracelet that was on his arm, and have brought them here to my lord."

11. Therefore David took hold of his own clothes and tore them, and so did all the men who were with him.

12. And they mourned and wept and fasted until evening for Saul and for Jonathan his son, for the people of the LORD and for the house of Israel, because they had fallen by the sword.

13. Then David said to the young man who told him, "Where are you from?" And he answered, "I am the son of an alien, an Amalekite."

14. So David said to him, "How was it you were not afraid to put forth your hand to destroy the LORD's anointed?"

15. Then David called one of the young men and said, "Go near, and execute him!" And he struck him so that he died.

16. So David said to him, "Your blood is on your own head, for your own mouth has testified against you, saying, "I have killed the LORD's anointed."'

17. Then David lamented with this lamentation over Saul and over Jonathan his son,

18. and he told them to teach the children of Judah the Song of the Bow; indeed it is written in the Book of Jasher:

19. "The beauty of Israel is slain on your high places! How the mighty have fallen!

20. Tell it not in Gath, Proclaim it not in the streets of Ashkelon-- Lest the daughters of the Philistines rejoice, Lest the daughters of the uncircumcised triumph.

21. "O mountains of Gilboa, Let there be no dew nor rain upon you, Nor fields of offerings. For the shield of the mighty is cast away there! The shield of Saul, not anointed with oil.

22. From the blood of the slain, From the fat of the mighty, The bow of Jonathan did not turn back, And the sword of Saul did not return empty.

23. "Saul and Jonathan were beloved and pleasant in their lives, And in their death they were not divided; They were swifter than eagles, They were stronger than lions.

24. "O daughters of Israel, weep over Saul, Who clothed you in scarlet, with luxury; Who put ornaments of gold on your apparel.

25. "How the mighty have fallen in the midst of the battle! Jonathan was slain in your high places.

26. I am distressed for you, my brother Jonathan; You have been very pleasant to me; Your love to me was wonderful, Surpassing the love of women.

27. "How the mighty have fallen, And the weapons of war perished!"

## Chapter 2

1. It happened after this that David inquired of the LORD, saying, "Shall I go up to any of the cities of Judah?" And the LORD said to him, "Go up." David said, "Where shall I go up?" And He said, "To Hebron."

2. So David went up there, and his two wives also, Ahinoam the Jezreelitess, and Abigail the widow of Nabal the Carmelite.

3. And David brought up the men who were with him, every man with his household. So they dwelt in the cities of Hebron.

4. Then the men of Judah came, and there they anointed David king over the house of Judah. And they told David, saying, "The men of Jabesh Gilead were the ones who buried Saul."

5. So David sent messengers to the men of Jabesh Gilead, and said to them, "You are blessed of the LORD, for you have shown this kindness to your lord, to Saul, and have buried him.

6. And now may the LORD show kindness and truth to you. I also will repay you this kindness, because you have done this thing.

7. Now therefore, let your hands be strengthened, and be valiant; for your master Saul is dead, and also the house of Judah has anointed me king over them."

8. But Abner the son of Ner, commander of Saul's army, took Ishbosheth the son of Saul and brought him over to Mahanaim;

9. and he made him king over Gilead, over the Ashurites, over Jezreel, over Ephraim, over Benjamin, and over all Israel.

10. Ishbosheth, Saul's son, was forty years old when he began to reign over Israel, and he reigned two years. Only the house of Judah followed David.

11. And the time that David was king in Hebron over the house of Judah was seven years and six months.

12. Now Abner the son of Ner, and the servants of Ishbosheth the son of Saul, went out from Mahanaim to Gibeon.

13. And Joab the son of Zeruiah, and the servants of David, went out and met them by the pool of Gibeon. So they sat down, one on one side of the pool and the other on the other side of the pool.

14. Then Abner said to Joab, "Let the young men now arise and compete before us." And Joab said, "Let them arise."

15. So they arose and went over by number, twelve from Benjamin, followers of Ishbosheth the son of Saul, and twelve from the servants of David.

16. And each one grasped his opponent by the head and thrust his sword in his opponent's side; so they fell down together. Therefore that place was called the Field of Sharp Swords, which is in Gibeon.

17. So there was a very fierce battle that day, and Abner and the men of Israel were beaten before the servants of David.

18. Now the three sons of Zeruiah were there: Joab and Abishai and Asahel. And Asahel was as fleet of foot as a wild gazelle.

19. So Asahel pursued Abner, and in going he did not turn to the right hand or to the left from following Abner.

20. Then Abner looked behind him and said, "Are you Asahel?" He answered, "I am."

21. And Abner said to him, "Turn aside to your right hand or to your left, and lay hold on one of the young men and take his armor for yourself." But Asahel would not turn aside from following him.

22. So Abner said again to Asahel, "Turn aside from following me. Why should I strike you to the ground? How then could I face your brother Joab?"

23. However, he refused to turn aside. Therefore Abner struck him in the stomach with the blunt end of the spear, so that the spear came out of his back; and he fell down there and died on the spot. So it was that as many as came to the place where Asahel fell down and died, stood still.

24. Joab and Abishai also pursued Abner. And the sun was going down when they came to the hill of Ammah, which is before Giah by the road to the Wilderness of Gibeon.

25. Now the children of Benjamin gathered together behind Abner and became a unit, and took their stand on top of a hill.

26. Then Abner called to Joab and said, "Shall the sword devour forever? Do you not know that it will be bitter in the latter end? How long will it be then until you tell the people to return from pursuing their brethren?"

27. And Joab said, "As God lives, unless you had spoken, surely then by morning all the people would have given up pursuing their brethren."

28. So Joab blew a trumpet; and all the people stood still and did not pursue Israel anymore, nor did they fight anymore.

29. Then Abner and his men went on all that night through the plain, crossed over the Jordan, and went through all Bithron; and they came to Mahanaim.

30. So Joab returned from pursuing Abner. And when he had gathered all the people together, there were missing of David's servants nineteen men and Asahel.

31. But the servants of David had struck down, of Benjamin and Abner's men, three hundred and sixty men who died.

32. Then they took up Asahel and buried him in his father's tomb, which was in Bethlehem. And Joab and his men went all night, and they came to Hebron at daybreak.

## Chapter 3

1. Now there was a long war between the house of Saul and the house of David. But David grew stronger and stronger, and the house of Saul grew weaker and weaker.

2. Sons were born to David in Hebron: His firstborn was Amnon by Ahinoam the Jezreelitess;

3. his second, Chileab, by Abigail the widow of Nabal the Carmelite; the third, Absalom the son of Maacah, the daughter of Talmai, king of Geshur;

4. the fourth, Adonijah the son of Haggith; the fifth, Shephatiah the son of Abital;

5. and the sixth, Ithream, by David's wife Eglah. These were born to David in Hebron.

6. Now it was so, while there was war between the house of Saul and the house of David, that Abner was strengthening his hold on the house of Saul.

7. And Saul had a concubine, whose name was Rizpah, the daughter of Aiah. So Ishbosheth said to Abner, "Why have you gone in to my father's concubine?"

8. Then Abner became very angry at the words of Ishbosheth, and said, "Am I a dog's head that belongs to Judah? Today I show loyalty to the house of Saul your father, to his brothers, and to his friends, and have not delivered you into the hand of David; and you charge me today with a fault concerning this woman?

9. May God do so to Abner, and more also, if I do not do for David as the LORD has sworn to him--

10. to transfer the kingdom from the house of Saul, and set up the throne of David over Israel and over Judah, from Dan to Beersheba."

11. And he could not answer Abner another word, because he feared him.

12. Then Abner sent messengers on his behalf to David, saying, "Whose is the land?" saying also, "Make your covenant with me, and indeed my hand shall be with you to bring all Israel to you."

13. And David said, "Good, I will make a covenant with you. But one thing I require of you: you shall not see my face unless you first bring Michal, Saul's daughter, when you come to see my face."

14. So David sent messengers to Ishbosheth, Saul's son, saying, "Give me my wife Michal, whom I betrothed to myself for a hundred foreskins of the Philistines."

15. And Ishbosheth sent and took her from her husband, from Paltiel the son of Laish.

16. Then her husband went along with her to Bahurim, weeping behind her. So Abner said to him, "Go, return!" And he returned.

17. Now Abner had communicated with the elders of Israel, saying, "In time past you were seeking for David to be king over you.

18. Now then, do it! For the LORD has spoken of David, saying, "By the hand of My servant David, I will save My people Israel from the hand of the Philistines and the hand of all their enemies."'

19. And Abner also spoke in the hearing of Benjamin. Then Abner also went to speak in the hearing of David in Hebron all that seemed good to Israel and the whole house of Benjamin.

20. So Abner and twenty men with him came to David at Hebron. And David made a feast for Abner and the men who were with him.

21. Then Abner said to David, "I will arise and go, and gather all Israel to my lord the king, that they may make a covenant with you, and that you may reign over all that your heart desires." So David sent Abner away, and he went in peace.

22. At that moment the servants of David and Joab came from a raid and brought much spoil with them. But Abner was not with David in Hebron, for he had sent him away, and he had gone in peace.

23. When Joab and all the troops that were with him had come, they told Joab, saying, "Abner the son of Ner came to the king, and he sent him away, and he has gone in peace."

24. Then Joab came to the king and said, "What have you done? Look, Abner came to you; why is it that you sent him away, and he has already gone?

25. Surely you realize that Abner the son of Ner came to deceive you, to know your going out and your coming in, and to know all that you are doing."

26. And when Joab had gone from David's presence, he sent messengers after Abner, who brought him back from the well of Sirah. But David did not know it.

27. Now when Abner had returned to Hebron, Joab took him aside in the gate to speak with him privately, and there stabbed him in the stomach, so that he died for the blood of Asahel his brother.

28. Afterward, when David heard it, he said, "My kingdom and I are guiltless before the LORD forever of the blood of Abner the son of Ner.

29. Let it rest on the head of Joab and on all his father's house; and let there never fail to be in the house of Joab one who has a discharge or is a leper, who leans on a staff or falls by the sword, or who lacks bread."

30. So Joab and Abishai his brother killed Abner, because he had killed their brother Asahel at Gibeon in the battle.

31. Then David said to Joab and to all the people who were with him, "Tear your clothes, gird yourselves with sackcloth, and mourn for Abner." And King David followed the coffin.

32. So they buried Abner in Hebron; and the king lifted up his voice and wept at the grave of Abner, and all the people wept.

33. And the king sang a lament over Abner and said: "Should Abner die as a fool dies?

34. Your hands were not bound Nor your feet put into fetters; As a man falls before wicked men, so you fell." Then all the people wept over him again.

35. And when all the people came to persuade David to eat food while it was still day, David took an oath, saying, "God do so to me, and more also, if I taste bread or anything else till the sun goes down!"

36. Now all the people took note of it, and it pleased them, since whatever the king did pleased all the people.

37. For all the people and all Israel understood that day that it had not been the king's intent to kill Abner the son of Ner.

38. Then the king said to his servants, "Do you not know that a prince and a great man has fallen this day in Israel?

39. And I am weak today, though anointed king; and these men, the sons of Zeruiah, are too harsh for me. The LORD shall repay the evildoer according to his wickedness."

## Chapter 4

1. When Saul's son heard that Abner had died in Hebron, he lost heart, and all Israel was troubled.

2. Now Saul's son had two men who were captains of troops. The name of one was Baanah and the name of the other Rechab, the sons of Rimmon the Beerothite, of the children of Benjamin. (For Beeroth also was part of Benjamin,

3. because the Beerothites fled to Gittaim and have been sojourners there until this day.)

4. Jonathan, Saul's son, had a son who was lame in his feet. He was five years old when the news about Saul and Jonathan came from Jezreel; and his nurse took him up and fled. And it happened, as she made haste to flee, that he fell and became lame. His name was Mephibosheth.

5. Then the sons of Rimmon the Beerothite, Rechab and Baanah, set out and came at about the heat of the day to the house of Ishbosheth, who was lying on his bed at noon.

6. And they came there, all the way into the house, as though to get wheat, and they stabbed him in the stomach. Then Rechab and Baanah his brother escaped.

7. For when they came into the house, he was lying on his bed in his bedroom; then they struck him and killed him, beheaded him and took his head, and were all night escaping through the plain.

8. And they brought the head of Ishbosheth to David at Hebron, and said to the king, "Here is the head of Ishbosheth, the son of Saul your enemy, who sought your life; and the LORD has avenged my lord the king this day of Saul and his descendants."

9. But David answered Rechab and Baanah his brother, the sons of Rimmon the Beerothite, and said to them, "As the LORD lives, who has redeemed my life from all adversity,

10. when someone told me, saying, "Look, Saul is dead,' thinking to have brought good news, I arrested him and had him executed in Ziklag--the one who thought I would give him a reward for his news.

11. How much more, when wicked men have killed a righteous person in his own house on his bed? Therefore, shall I not now require his blood at your hand and remove you from the earth?"

12. So David commanded his young men, and they executed them, cut off their hands and feet, and hanged them by the pool in Hebron. But they took the head of Ishbosheth and buried it in the tomb of Abner in Hebron.

## Chapter 5

1. Then all the tribes of Israel came to David at Hebron and spoke, saying, "Indeed we are your bone and your flesh.

2. Also, in time past, when Saul was king over us, you were the one who led Israel out and brought them in; and the LORD said to you, "You shall shepherd My people Israel, and be ruler over Israel."'

3. Therefore all the elders of Israel came to the king at Hebron, and King David made a covenant with them at Hebron before the LORD. And they anointed David king over Israel.

4. David was thirty years old when he began to reign, and he reigned forty years.

5. In Hebron he reigned over Judah seven years and six months, and in Jerusalem he reigned thirty-three years over all Israel and Judah.

6. And the king and his men went to Jerusalem against the Jebusites, the inhabitants of the land, who spoke to David, saying, "You shall not come in here; but the blind and the lame will repel you," thinking, "David cannot come in here."

7. Nevertheless David took the stronghold of Zion (that is, the City of David).

8. Now David said on that day, "Whoever climbs up by way of the water shaft and defeats the Jebusites (the lame and the blind, who are hated by David's soul), he shall be chief and captain." Therefore they say, "The blind and the lame shall not come into the house."

9. Then David dwelt in the stronghold, and called it the City of David. And David built all around from the Millo and inward.

10. So David went on and became great, and the LORD God of hosts was with him.

11. Then Hiram king of Tyre sent messengers to David, and cedar trees, and carpenters and masons. And they built David a house.

12. So David knew that the LORD had established him as king over Israel, and that He had exalted His kingdom for the sake of His people Israel.

13. And David took more concubines and wives from Jerusalem, after he had come from Hebron. Also more sons and daughters were born to David.

14. Now these are the names of those who were born to him in Jerusalem: Shammua, Shobab, Nathan, Solomon,

15. Ibhar, Elishua, Nepheg, Japhia,

16. Elishama, Eliada, and Eliphelet.

17. Now when the Philistines heard that they had anointed David king over Israel, all the Philistines went up to search for David. And David heard of it and went down to the stronghold.

18. The Philistines also went and deployed themselves in the Valley of Rephaim.

19. So David inquired of the LORD, saying, "Shall I go up against the Philistines? Will You deliver them into my hand?" And the LORD said to David, "Go up, for I will doubtless deliver the Philistines into your hand."

20. So David went to Baal Perazim, and David defeated them there; and he said, "The LORD has broken through my enemies before me, like a breakthrough of water." Therefore he called the name of that place Baal Perazim.

21. And they left their images there, and David and his men carried them away.

22. Then the Philistines went up once again and deployed themselves in the Valley of Rephaim.

23. Therefore David inquired of the LORD, and He said, "You shall not go up; circle around behind them, and come upon them in front of the mulberry trees.

24. And it shall be, when you hear the sound of marching in the tops of the mulberry trees, then you shall advance quickly. For then the LORD will go out before you to strike the camp of the Philistines."

25. And David did so, as the LORD commanded him; and he drove back the Philistines from Geba as far as Gezer.

## Chapter 6

1. Again David gathered all the choice men of Israel, thirty thousand.

2. And David arose and went with all the people who were with him from Baale Judah to bring up from there the ark of God, whose name is called by the Name, the LORD of Hosts, who dwells between the cherubim.

3. So they set the ark of God on a new cart, and brought it out of the house of Abinadab, which was on the hill; and Uzzah and Ahio, the sons of Abinadab, drove the new cart.

4. And they brought it out of the house of Abinadab, which was on the hill, accompanying the ark of God; and Ahio went before the ark.

5. Then David and all the house of Israel played music before the LORD on all kinds of instruments of fir wood, on harps, on stringed instruments, on tambourines, on sistrums, and on cymbals.

6. And when they came to Nachon's threshing floor, Uzzah put out his hand to the ark of God and took hold of it, for the oxen stumbled.

7. Then the anger of the LORD was aroused against Uzzah, and God struck him there for his error; and he died there by the ark of God.

8. And David became angry because of the LORD's outbreak against Uzzah; and he called the name of the place Perez Uzzah to this day.

9. David was afraid of the LORD that day; and he said, "How can the ark of the LORD come to me?"

10. So David would not move the ark of the LORD with him into the City of David; but David took it aside into the house of Obed-Edom the Gittite.

11. The ark of the LORD remained in the house of Obed-Edom the Gittite three months. And the LORD blessed Obed-Edom and all his household.

12. Now it was told King David, saying, "The LORD has blessed the house of Obed-Edom and all that belongs to him, because of the ark of God." So David went and brought up the ark of God from the house of Obed-Edom to the City of David with gladness.

13. And so it was, when those bearing the ark of the LORD had gone six paces, that he sacrificed oxen and fatted sheep.

14. Then David danced before the LORD with all his might; and David was wearing a linen ephod.

15. So David and all the house of Israel brought up the ark of the LORD with shouting and with the sound of the trumpet.

16. Now as the ark of the LORD came into the City of David, Michal, Saul's daughter, looked through a window and saw King David leaping and whirling before the LORD; and she despised him in her heart.

17. So they brought the ark of the LORD, and set it in its place in the midst of the tabernacle that David had erected for it. Then David offered burnt offerings and peace offerings before the LORD.

18. And when David had finished offering burnt offerings and peace offerings, he blessed the people in the name of the LORD of hosts.

19. Then he distributed among all the people, among the whole multitude of Israel, both the women and the men, to everyone a loaf of bread, a piece of meat, and a cake of raisins. So all the people departed, everyone to his house.

20. Then David returned to bless his household. And Michal the daughter of Saul came out to meet David, and said, "How glorious was the king of Israel today, uncovering himself today in the eyes of the maids of his servants, as one of the base fellows shamelessly uncovers himself!"

21. So David said to Michal, "It was before the LORD, who chose me instead of your father and all his house, to appoint me ruler over the people of the LORD, over Israel. Therefore I will play music before the LORD.

22. And I will be even more undignified than this, and will be humble in my own sight. But as for the maidservants of whom you have spoken, by them I will be held in honor."

23. Therefore Michal the daughter of Saul had no children to the day of her death.

## Chapter 7

1. Now it came to pass when the king was dwelling in his house, and the LORD had given him rest from all his enemies all around,

2. that the king said to Nathan the prophet, "See now, I dwell in a house of cedar, but the ark of God dwells inside tent curtains."

3. Then Nathan said to the king, "Go, do all that is in your heart, for the LORD is with you."

4. But it happened that night that the word of the LORD came to Nathan, saying,

5. "Go and tell My servant David, "Thus says the LORD: "Would you build a house for Me to dwell in?

6. For I have not dwelt in a house since the time that I brought the children of Israel up from Egypt, even to this day, but have moved about in a tent and in a tabernacle.

7. Wherever I have moved about with all the children of Israel, have I ever spoken a word to anyone from the tribes of Israel, whom I commanded to shepherd My people Israel, saying, "Why have you not built Me a house of cedar?""

8. Now therefore, thus shall you say to My servant David, "Thus says the LORD of hosts: "I took you from the sheepfold, from following the sheep, to be ruler over My people, over Israel.

9. And I have been with you wherever you have gone, and have cut off all your enemies from before you, and have made you a great name, like the name of the great men who are on the earth.

10. Moreover I will appoint a place for My people Israel, and will plant them, that they may dwell in a place of their own and move no more; nor shall the sons of wickedness oppress them anymore, as previously,

11. since the time that I commanded judges to be over My people Israel, and have caused you to rest from all your enemies. Also the LORD tells you that He will make you a house.

12. "When your days are fulfilled and you rest with your fathers, I will set up your seed after you, who will come from your body, and I will establish his kingdom.

13. He shall build a house for My name, and I will establish the throne of his kingdom forever.

14. I will be his Father, and he shall be My son. If he commits iniquity, I will chasten him with the rod of men and with the blows of the sons of men.

15. But My mercy shall not depart from him, as I took it from Saul, whom I removed from before you.

16. And your house and your kingdom shall be established forever before you. Your throne shall be established forever.""'

17. According to all these words and according to all this vision, so Nathan spoke to David.

18. Then King David went in and sat before the LORD; and he said: "Who am I, O Lord GOD? And what is my house, that You have brought me this far?

19. And yet this was a small thing in Your sight, O Lord GOD; and You have also spoken of Your servant's house for a great while to come. Is this the manner of man, O Lord GOD?

20. Now what more can David say to You? For You, Lord GOD, know Your servant.

21. For Your word's sake, and according to Your own heart, You have done all these great things, to make Your servant know them.

22. Therefore You are great, O Lord GOD. For there is none like You, nor is there any God besides You, according to all that we have heard with our ears.

23. And who is like Your people, like Israel, the one nation on the earth whom God went to redeem for Himself as a people, to make for Himself a name--and to do for Yourself great and awesome deeds for Your land--before Your people whom You redeemed for Yourself from Egypt, the nations, and their gods?

24. For You have made Your people Israel Your very own people forever; and You, LORD, have become their God.

25. "Now, O LORD God, the word which You have spoken concerning Your servant and concerning his house, establish it forever and do as You have said.

26. So let Your name be magnified forever, saying, "The LORD of hosts is the God over Israel.' And let the house of Your servant David be established before You.

27. For You, O LORD of hosts, God of Israel, have revealed this to Your servant, saying, "I will build you a house.' Therefore Your servant has found it in his heart to pray this prayer to You.

28. "And now, O Lord GOD, You are God, and Your words are true, and You have promised this goodness to Your servant.

29. Now therefore, let it please You to bless the house of Your servant, that it may continue before You forever; for You, O Lord GOD, have spoken it, and with Your blessing let the house of Your servant be blessed forever."

## Chapter 8

1. After this it came to pass that David attacked the Philistines and subdued them. And David took Metheg Ammah from the hand of the Philistines.

2. Then he defeated Moab. Forcing them down to the ground, he measured them off with a line. With two lines he measured off those to be put to death, and with one full line those to be kept alive. So the Moabites became David's servants, and brought tribute.

3. David also defeated Hadadezer the son of Rehob, king of Zobah, as he went to recover his territory at the River Euphrates.

4. David took from him one thousand chariots, seven hundred horsemen, and twenty thousand foot soldiers. Also David hamstrung all the chariot horses, except that he spared enough of them for one hundred chariots.

5. When the Syrians of Damascus came to help Hadadezer king of Zobah, David killed twenty-two thousand of the Syrians.

6. Then David put garrisons in Syria of Damascus; and the Syrians became David's servants, and brought tribute. So the LORD preserved David wherever he went.

7. And David took the shields of gold that had belonged to the servants of Hadadezer, and brought them to Jerusalem.

8. Also from Betah and from Berothai, cities of Hadadezer, King David took a large amount of bronze.

9. When Toi king of Hamath heard that David had defeated all the army of Hadadezer,

10. then Toi sent Joram his son to King David, to greet him and bless him, because he had fought against Hadadezer and defeated him (for Hadadezer had been at war with Toi); and Joram brought with him articles of silver, articles of gold, and articles of bronze.

11. King David also dedicated these to the LORD, along with the silver and gold that he had dedicated from all the nations which he had subdued--

12. from Syria, from Moab, from the people of Ammon, from the Philistines, from Amalek, and from the spoil of Hadadezer the son of Rehob, king of Zobah.

13. And David made himself a name when he returned from killing eighteen thousand Syrians in the Valley of Salt.

14. He also put garrisons in Edom; throughout all Edom he put garrisons, and all the Edomites became David's servants. And the LORD preserved David wherever he went.

15. So David reigned over all Israel; and David administered judgment and justice to all his people.

16. Joab the son of Zeruiah was over the army; Jehoshaphat the son of Ahilud was recorder;

17. Zadok the son of Ahitub and Ahimelech the son of Abiathar were the priests; Seraiah was the scribe;

18. Benaiah the son of Jehoiada was over both the Cherethites and the Pelethites; and David's sons were chief ministers.

## Chapter 9

1. Now David said, "Is there still anyone who is left of the house of Saul, that I may show him kindness for Jonathan's sake?"

2. And there was a servant of the house of Saul whose name was Ziba. So when they had called him to David, the king said to him, "Are you Ziba?" He said, "At your service!"

3. Then the king said, "Is there not still someone of the house of Saul, to whom I may show the kindness of God?" And Ziba said to the king, "There is still a son of Jonathan who is lame in his feet."

4. So the king said to him, "Where is he?" And Ziba said to the king, "Indeed he is in the house of Machir the son of Ammiel, in Lo Debar."

5. Then King David sent and brought him out of the house of Machir the son of Ammiel, from Lo Debar.

6. Now when Mephibosheth the son of Jonathan, the son of Saul, had come to David, he fell on his face and prostrated himself. Then David said, "Mephibosheth?" And he answered, "Here is your servant!"

7. So David said to him, "Do not fear, for I will surely show you kindness for Jonathan your father's sake, and will restore to you all the land of Saul your grandfather; and you shall eat bread at my table continually."

8. Then he bowed himself, and said, "What is your servant, that you should look upon such a dead dog as I?"

9. And the king called to Ziba, Saul's servant, and said to him, "I have given to your master's son all that belonged to Saul and to all his house.

10. You therefore, and your sons and your servants, shall work the land for him, and you shall bring in the harvest, that your master's son may have food to eat. But Mephibosheth your master's son shall eat bread at my table always." Now Ziba had fifteen sons and twenty servants.

11. Then Ziba said to the king, "According to all that my lord the king has commanded his servant, so will your servant do." "As for Mephibosheth," said the king, "he shall eat at my table like one of the king's sons."

12. Mephibosheth had a young son whose name was Micha. And all who dwelt in the house of Ziba were servants of Mephibosheth.

13. So Mephibosheth dwelt in Jerusalem, for he ate continually at the king's table. And he was lame in both his feet.

## Chapter 10

1. It happened after this that the king of the people of Ammon died, and Hanun his son reigned in his place.

2. Then David said, "I will show kindness to Hanun the son of Nahash, as his father showed kindness to me." So David sent by the hand of his servants to comfort him concerning his father. And David's servants came into the land of the people of Ammon.

3. And the princes of the people of Ammon said to Hanun their lord, "Do you think that David really honors your father because he has sent comforters to you? Has David not rather sent his servants to you to search the city, to spy it out, and to overthrow it?"

4. Therefore Hanun took David's servants, shaved off half of their beards, cut off their garments in the middle, at their buttocks, and sent them away.

5. When they told David, he sent to meet them, because the men were greatly ashamed. And the king said, "Wait at Jericho until your beards have grown, and then return."

6. When the people of Ammon saw that they had made themselves repulsive to David, the people of Ammon sent and hired the Syrians of Beth Rehob and the Syrians of Zoba, twenty thousand foot soldiers; and from the king of Maacah one thousand men, and from Ish-Tob twelve thousand men.

7. Now when David heard of it, he sent Joab and all the army of the mighty men.

8. Then the people of Ammon came out and put themselves in battle array at the entrance of the gate. And the Syrians of Zoba, Beth Rehob, Ish-Tob, and Maacah were by themselves in the field.

9. When Joab saw that the battle line was against him before and behind, he chose some of Israel's best and put them in battle array against the Syrians.

10. And the rest of the people he put under the command of Abishai his brother, that he might set them in battle array against the people of Ammon.

11. Then he said, "If the Syrians are too strong for me, then you shall help me; but if the people of Ammon are too strong for you, then I will come and help you.

12. Be of good courage, and let us be strong for our people and for the cities of our God. And may the LORD do what is good in His sight."

13. So Joab and the people who were with him drew near for the battle against the Syrians, and they fled before him.

14. When the people of Ammon saw that the Syrians were fleeing, they also fled before Abishai, and entered the city. So Joab returned from the people of Ammon and went to Jerusalem.

15. When the Syrians saw that they had been defeated by Israel, they gathered together.

16. Then Hadadezer sent and brought out the Syrians who were beyond the River, and they came to Helam. And Shobach the commander of Hadadezer's army went before them.

17. When it was told David, he gathered all Israel, crossed over the Jordan, and came to Helam. And the Syrians set themselves in battle array against David and fought with him.

18. Then the Syrians fled before Israel; and David killed seven hundred charioteers and forty thousand horsemen of the Syrians, and struck Shobach the commander of their army, who died there.

19. And when all the kings who were servants to Hadadezer saw that they were defeated by Israel, they made peace with Israel and served them. So the Syrians were afraid to help the people of Ammon anymore.

## Chapter 11

1. It happened in the spring of the year, at the time when kings go out to battle, that David sent Joab and his servants with him, and all Israel; and they destroyed the people of Ammon and besieged Rabbah. But David remained at Jerusalem.

2. Then it happened one evening that David arose from his bed and walked on the roof of the king's house. And from the roof he saw a woman bathing, and the woman was very beautiful to behold.

3. So David sent and inquired about the woman. And someone said, "Is this not Bathsheba, the daughter of Eliam, the wife of Uriah the Hittite?"

4. Then David sent messengers, and took her; and she came to him, and he lay with her, for she was cleansed from her impurity; and she returned to her house.

5. And the woman conceived; so she sent and told David, and said, "I am with child."

6. Then David sent to Joab, saying, "Send me Uriah the Hittite." And Joab sent Uriah to David.

7. When Uriah had come to him, David asked how Joab was doing, and how the people were doing, and how the war prospered.

8. And David said to Uriah, "Go down to your house and wash your feet." So Uriah departed from the king's house, and a gift of food from the king followed him.

9. But Uriah slept at the door of the king's house with all the servants of his lord, and did not go down to his house.

10. So when they told David, saying, "Uriah did not go down to his house," David said to Uriah, "Did you not come from a journey? Why did you not go down to your house?"

11. And Uriah said to David, "The ark and Israel and Judah are dwelling in tents, and my lord Joab and the servants of my lord are encamped in the open fields. Shall I then go to my house to eat and drink, and to lie with my wife? As you live, and as your soul lives, I will not do this thing."

12. Then David said to Uriah, "Wait here today also, and tomorrow I will let you depart." So Uriah remained in Jerusalem that day and the next.

13. Now when David called him, he ate and drank before him; and he made him drunk. And at evening he went out to lie on his bed with the servants of his lord, but he did not go down to his house.

14. In the morning it happened that David wrote a letter to Joab and sent it by the hand of Uriah.

15. And he wrote in the letter, saying, "Set Uriah in the forefront of the hottest battle, and retreat from him, that he may be struck down and die."

16. So it was, while Joab besieged the city, that he assigned Uriah to a place where he knew there were valiant men.

17. Then the men of the city came out and fought with Joab. And some of the people of the servants of David fell; and Uriah the Hittite died also.

18. Then Joab sent and told David all the things concerning the war,

19. and charged the messenger, saying, "When you have finished telling the matters of the war to the king,

20. if it happens that the king's wrath rises, and he says to you: "Why did you approach so near to the city when you fought? Did you not know that they would shoot from the wall?

21. Who struck Abimelech the son of Jerubbesheth? Was it not a woman who cast a piece of a millstone on him from the wall, so that he died in Thebez? Why did you go near the wall?'--then you shall say, "Your servant Uriah the Hittite is dead also."'

22. So the messenger went, and came and told David all that Joab had sent by him.

23. And the messenger said to David, "Surely the men prevailed against us and came out to us in the field; then we drove them back as far as the entrance of the gate.

24. The archers shot from the wall at your servants; and some of the king's servants are dead, and your servant Uriah the Hittite is dead also."

25. Then David said to the messenger, "Thus you shall say to Joab: "Do not let this thing displease you, for the sword devours one as well as another. Strengthen your attack against the city, and overthrow it.' So encourage him."

26. When the wife of Uriah heard that Uriah her husband was dead, she mourned for her husband.

27. And when her mourning was over, David sent and brought her to his house, and she became his wife and bore him a son. But the thing that David had done displeased the LORD.

## Chapter 12

1. Then the LORD sent Nathan to David. And he came to him, and said to him: "There were two men in one city, one rich and the other poor.

2. The rich man had exceedingly many flocks and herds.

3. But the poor man had nothing, except one little ewe lamb which he had bought and nourished; and it grew up together with him and with his children. It ate of his own food and drank from his own cup and lay in his bosom; and it was like a daughter to him.

4. And a traveler came to the rich man, who refused to take from his own flock and from his own herd to prepare one for the wayfaring man who had come to him; but he took the poor man's lamb and prepared it for the man who had come to him."

5. So David's anger was greatly aroused against the man, and he said to Nathan, "As the LORD lives, the man who has done this shall surely die!

6. And he shall restore fourfold for the lamb, because he did this thing and because he had no pity."

7. Then Nathan said to David, "You are the man! Thus says the LORD God of Israel: "I anointed you king over Israel, and I delivered you from the hand of Saul.

8. I gave you your master's house and your master's wives into your keeping, and gave you the house of Israel and Judah. And if that had been too little, I also would have given you much more!

9. Why have you despised the commandment of the LORD, to do evil in His sight? You have killed Uriah the Hittite with the sword; you have taken his wife to be your wife, and have killed him with the sword of the people of Ammon.

10. Now therefore, the sword shall never depart from your house, because you have despised Me, and have taken the wife of Uriah the Hittite to be your wife.'

11. Thus says the LORD: "Behold, I will raise up adversity against you from your own house; and I will take your wives before your eyes and give them to your neighbor, and he shall lie with your wives in the sight of this sun.

12. For you did it secretly, but I will do this thing before all Israel, before the sun."'

13. So David said to Nathan, "I have sinned against the LORD." And Nathan said to David, "The LORD also has put away your sin; you shall not die.

14. However, because by this deed you have given great occasion to the enemies of the LORD to blaspheme, the child also who is born to you shall surely die."

15. Then Nathan departed to his house. And the LORD struck the child that Uriah's wife bore to David, and it became ill.

16. David therefore pleaded with God for the child, and David fasted and went in and lay all night on the ground.

17. So the elders of his house arose and went to him, to raise him up from the ground. But he would not, nor did he eat food with them.

18. Then on the seventh day it came to pass that the child died. And the servants of David were afraid to tell him that the child was dead. For they said, "Indeed, while the child was alive, we spoke to him, and he would not heed our voice. How can we tell him that the child is dead? He may do some harm!"

19. When David saw that his servants were whispering, David perceived that the child was dead. Therefore David said to his servants, "Is the child dead?" And they said, "He is dead."

20. So David arose from the ground, washed and anointed himself, and changed his clothes; and he went into the house of the LORD and worshiped. Then he went to his own house; and when he requested, they set food before him, and he ate.

21. Then his servants said to him, "What is this that you have done? You fasted and wept for the child while he was alive, but when the child died, you arose and ate food."

22. And he said, "While the child was alive, I fasted and wept; for I said, "Who can tell whether the LORD will be gracious to me, that the child may live?'

23. But now he is dead; why should I fast? Can I bring him back again? I shall go to him, but he shall not return to me."

24. Then David comforted Bathsheba his wife, and went in to her and lay with her. So she bore a son, and he called his name Solomon. Now the LORD loved him,

25. and He sent word by the hand of Nathan the prophet: So he called his name Jedidiah, because of the LORD.

26. Now Joab fought against Rabbah of the people of Ammon, and took the royal city.

27. And Joab sent messengers to David, and said, "I have fought against Rabbah, and I have taken the city's water supply.

28. Now therefore, gather the rest of the people together and encamp against the city and take it, lest I take the city and it be called after my name."

29. So David gathered all the people together and went to Rabbah, fought against it, and took it.

30. Then he took their king's crown from his head. Its weight was a talent of gold, with precious stones. And it was set on David's head. Also he brought out the spoil of the city in great abundance.

31. And he brought out the people who were in it, and put them to work with saws and iron picks and iron axes, and made them cross over to the brick works. So he did to all the cities of the people of Ammon. Then David and all the people returned to Jerusalem.

## Chapter 13

1. After this Absalom the son of David had a lovely sister, whose name was Tamar; and Amnon the son of David loved her.

2. Amnon was so distressed over his sister Tamar that he became sick; for she was a virgin. And it was improper for Amnon to do anything to her.

3. But Amnon had a friend whose name was Jonadab the son of Shimeah, David's brother. Now Jonadab was a very crafty man.

4. And he said to him, "Why are you, the king's son, becoming thinner day after day? Will you not tell me?" Amnon said to him, "I love Tamar, my brother Absalom's sister."

5. So Jonadab said to him, "Lie down on your bed and pretend to be ill. And when your father comes to see you, say to him, "Please let my sister Tamar come and give me food, and prepare the food in my sight, that I may see it and eat it from her hand."'

6. Then Amnon lay down and pretended to be ill; and when the king came to see him, Amnon said to the king, "Please let Tamar my sister come and make a couple of cakes for me in my sight, that I may eat from her hand."

7. And David sent home to Tamar, saying, "Now go to your brother Amnon's house, and prepare food for him."

8. So Tamar went to her brother Amnon's house; and he was lying down. Then she took flour and kneaded it, made cakes in his sight, and baked the cakes.

9. And she took the pan and placed them out before him, but he refused to eat. Then Amnon said, "Have everyone go out from me." And they all went out from him.

10. Then Amnon said to Tamar, "Bring the food into the bedroom, that I may eat from your hand." And Tamar took the cakes which she had made, and brought them to Amnon her brother in the bedroom.

11. Now when she had brought them to him to eat, he took hold of her and said to her, "Come, lie with me, my sister."

12. But she answered him, "No, my brother, do not force me, for no such thing should be done in Israel. Do not do this disgraceful thing!

13. And I, where could I take my shame? And as for you, you would be like one of the fools in Israel. Now therefore, please speak to the king; for he will not withhold me from you."

14. However, he would not heed her voice; and being stronger than she, he forced her and lay with her.

15. Then Amnon hated her exceedingly, so that the hatred with which he hated her was greater than the love with which he had loved her. And Amnon said to her, "Arise, be gone!"

16. So she said to him, "No, indeed! This evil of sending me away is worse than the other that you did to me." But he would not listen to her.

17. Then he called his servant who attended him, and said, "Here! Put this woman out, away from me, and bolt the door behind her."

18. Now she had on a robe of many colors, for the king's virgin daughters wore such apparel. And his servant put her out and bolted the door behind her.

19. Then Tamar put ashes on her head, and tore her robe of many colors that was on her, and laid her hand on her head and went away crying bitterly.

20. And Absalom her brother said to her, "Has Amnon your brother been with you? But now hold your peace, my sister. He is your brother; do not take this thing to heart." So Tamar remained desolate in her brother Absalom's house.

21. But when King David heard of all these things, he was very angry.

22. And Absalom spoke to his brother Amnon neither good nor bad. For Absalom hated Amnon, because he had forced his sister Tamar.

23. And it came to pass, after two full years, that Absalom had sheepshearers in Baal Hazor, which is near Ephraim; so Absalom invited all the king's sons.

24. Then Absalom came to the king and said, "Kindly note, your servant has sheepshearers; please, let the king and his servants go with your servant."

25. But the king said to Absalom, "No, my son, let us not all go now, lest we be a burden to you." Then he urged him, but he would not go; and he blessed him.

26. Then Absalom said, "If not, please let my brother Amnon go with us." And the king said to him, "Why should he go with you?"

27. But Absalom urged him; so he let Amnon and all the king's sons go with him.

28. Now Absalom had commanded his servants, saying, "Watch now, when Amnon's heart is merry with wine, and when I say to you, "Strike Amnon!' then kill him. Do not be afraid. Have I not commanded you? Be courageous and valiant."

29. So the servants of Absalom did to Amnon as Absalom had commanded. Then all the king's sons arose, and each one got on his mule and fled.

30. And it came to pass, while they were on the way, that news came to David, saying, "Absalom has killed all the king's sons, and not one of them is left!"

31. So the king arose and tore his garments and lay on the ground, and all his servants stood by with their clothes torn.

32. Then Jonadab the son of Shimeah, David's brother, answered and said, "Let not my lord suppose they have killed all the young men, the king's sons, for only Amnon is dead. For by the command of Absalom this has been determined from the day that he forced his sister Tamar.

33. Now therefore, let not my lord the king take the thing to his heart, to think that all the king's sons are dead. For only Amnon is dead."

34. Then Absalom fled. And the young man who was keeping watch lifted his eyes and looked, and there, many people were coming from the road on the hillside behind him.

35. And Jonadab said to the king, "Look, the king's sons are coming; as your servant said, so it is."

36. So it was, as soon as he had finished speaking, that the king's sons indeed came, and they lifted up their voice and wept. Also the king and all his servants wept very bitterly.

37. But Absalom fled and went to Talmai the son of Ammihud, king of Geshur. And David mourned for his son every day.

38. So Absalom fled and went to Geshur, and was there three years.

39. And King David longed to go to Absalom. For he had been comforted concerning Amnon, because he was dead.

## Chapter 14

1. So Joab the son of Zeruiah perceived that the king's heart was concerned about Absalom.

2. And Joab sent to Tekoa and brought from there a wise woman, and said to her, "Please pretend to be a mourner, and put on mourning apparel; do not anoint yourself with oil, but act like a woman who has been mourning a long time for the dead.

3. Go to the king and speak to him in this manner." So Joab put the words in her mouth.

4. And when the woman of Tekoa spoke to the king, she fell on her face to the ground and prostrated herself, and said, "Help, O king!"

5. Then the king said to her, "What troubles you?" And she answered, "Indeed I am a widow, my husband is dead.

6. Now your maidservant had two sons; and the two fought with each other in the field, and there was no one to part them, but the one struck the other and killed him.

7. And now the whole family has risen up against your maidservant, and they said, "Deliver him who struck his brother, that we may execute him for the life of his brother whom he killed; and we will destroy the heir also.' So they would extinguish my ember that is left, and leave to my husband neither name nor remnant on the earth."

8. Then the king said to the woman, "Go to your house, and I will give orders concerning you."

9. And the woman of Tekoa said to the king, "My lord, O king, let the iniquity be on me and on my father's house, and the king and his throne be guiltless."

10. So the king said, "Whoever says anything to you, bring him to me, and he shall not touch you anymore."

11. Then she said, "Please let the king remember the LORD your God, and do not permit the avenger of blood to destroy anymore, lest they destroy my son." And he said, "As the LORD lives, not one hair of your son shall fall to the ground."

12. Therefore the woman said, "Please, let your maidservant speak another word to my lord the king." And he said, "Say on."

13. So the woman said: "Why then have you schemed such a thing against the people of God? For the king speaks this thing as one who is guilty, in that the king does not bring his banished one home again.

14. For we will surely die and become like water spilled on the ground, which cannot be gathered up again. Yet God does not take away a life; but He devises means, so that His banished ones are not expelled from Him.

15. Now therefore, I have come to speak of this thing to my lord the king because the people have made me afraid. And your maidservant said, "I will now speak to the king; it may be that the king will perform the request of his maidservant.

16. For the king will hear and deliver his maidservant from the hand of the man who would destroy me and my son together from the inheritance of God.'

17. Your maidservant said, "The word of my lord the king will now be comforting; for as the angel of God, so is my lord the king in discerning good and evil. And may the LORD your God be with you."'

18. Then the king answered and said to the woman, "Please do not hide from me anything that I ask you." And the woman said, "Please, let my lord the king speak."

19. So the king said, "Is the hand of Joab with you in all this?" And the woman answered and said, "As you live, my lord the king, no one can turn to the right hand or to the left from anything that my lord the king has spoken. For your servant Joab commanded me, and he put all these words in the mouth of your maidservant.

20. To bring about this change of affairs your servant Joab has done this thing; but my lord is wise, according to the wisdom of the angel of God, to know everything that is in the earth."

21. And the king said to Joab, "All right, I have granted this thing. Go therefore, bring back the young man Absalom."

22. Then Joab fell to the ground on his face and bowed himself, and thanked the king. And Joab said, "Today your servant knows that I have found favor in your sight, my lord, O king, in that the king has fulfilled the request of his servant."

23. So Joab arose and went to Geshur, and brought Absalom to Jerusalem.

24. And the king said, "Let him return to his own house, but do not let him see my face." So Absalom returned to his own house, but did not see the king's face.

25. Now in all Israel there was no one who was praised as much as Absalom for his good looks. From the sole of his foot to the crown of his head there was no blemish in him.

26. And when he cut the hair of his head--at the end of every year he cut it because it was heavy on him--when he cut it, he weighed the hair of his head at two hundred shekels according to the king's standard.

27. To Absalom were born three sons, and one daughter whose name was Tamar. She was a woman of beautiful appearance.

28. And Absalom dwelt two full years in Jerusalem, but did not see the king's face.

29. Therefore Absalom sent for Joab, to send him to the king, but he would not come to him. And when he sent again the second time, he would not come.

30. So he said to his servants, "See, Joab's field is near mine, and he has barley there; go and set it on fire." And Absalom's servants set the field on fire.

31. Then Joab arose and came to Absalom's house, and said to him, "Why have your servants set my field on fire?"

32. And Absalom answered Joab, "Look, I sent to you, saying, "Come here, so that I may send you to the king, to say, "Why have I come from Geshur? It would be better for me to be there still."' Now therefore, let me see the king's face; but if there is iniquity in me, let him execute me."

33. So Joab went to the king and told him. And when he had called for Absalom, he came to the king and bowed himself on his face to the ground before the king. Then the king kissed Absalom.

## Chapter 15

1. After this it happened that Absalom provided himself with chariots and horses, and fifty men to run before him.

2. Now Absalom would rise early and stand beside the way to the gate. So it was, whenever anyone who had a lawsuit came to the king for a decision, that Absalom would call to him and say, "What city are you from?" And he would say, "Your servant is from such and such a tribe of Israel."

3. Then Absalom would say to him, "Look, your case is good and right; but there is no deputy of the king to hear you."

4. Moreover Absalom would say, "Oh, that I were made judge in the land, and everyone who has any suit or cause would come to me; then I would give him justice."

5. And so it was, whenever anyone came near to bow down to him, that he would put out his hand and take him and kiss him.

6. In this manner Absalom acted toward all Israel who came to the king for judgment. So Absalom stole the hearts of the men of Israel.

7. Now it came to pass after forty years that Absalom said to the king, "Please, let me go to Hebron and pay the vow which I made to the LORD.

8. For your servant took a vow while I dwelt at Geshur in Syria, saying, "If the LORD indeed brings me back to Jerusalem, then I will serve the LORD."'

9. And the king said to him, "Go in peace." So he arose and went to Hebron.

10. Then Absalom sent spies throughout all the tribes of Israel, saying, "As soon as you hear the sound of the trumpet, then you shall say, "Absalom reigns in Hebron!"'

11. And with Absalom went two hundred men invited from Jerusalem, and they went along innocently and did not know anything.

12. Then Absalom sent for Ahithophel the Gilonite, David's counselor, from his city--from Giloh--while he offered sacrifices. And the conspiracy grew strong, for the people with Absalom continually increased in number.

13. Now a messenger came to David, saying, "The hearts of the men of Israel are with Absalom."

14. So David said to all his servants who were with him at Jerusalem, "Arise, and let us flee, or we shall not escape from Absalom. Make haste to depart, lest he overtake us suddenly and bring disaster upon us, and strike the city with the edge of the sword."

15. And the king's servants said to the king, "We are your servants, ready to do whatever my lord the king commands."

16. Then the king went out with all his household after him. But the king left ten women, concubines, to keep the house.

17. And the king went out with all the people after him, and stopped at the outskirts.

18. Then all his servants passed before him; and all the Cherethites, all the Pelethites, and all the Gittites, six hundred men who had followed him from Gath, passed before the king.

19. Then the king said to Ittai the Gittite, "Why are you also going with us? Return and remain with the king. For you are a foreigner and also an exile from your own place.

20. In fact, you came only yesterday. Should I make you wander up and down with us today, since I go I know not where? Return, and take your brethren back. Mercy and truth be with you."

21. But Ittai answered the king and said, "As the LORD lives, and as my lord the king lives, surely in whatever place my lord the king shall be, whether in death or life, even there also your servant will be."

22. So David said to Ittai, "Go, and cross over." Then Ittai the Gittite and all his men and all the little ones who were with him crossed over.

23. And all the country wept with a loud voice, and all the people crossed over. The king himself also crossed over the Brook Kidron, and all the people crossed over toward the way of the wilderness.

24. There was Zadok also, and all the Levites with him, bearing the ark of the covenant of God. And they set down the ark of God, and Abiathar went up until all the people had finished crossing over from the city.

25. Then the king said to Zadok, "Carry the ark of God back into the city. If I find favor in the eyes of the LORD, He will bring me back and show me both it and His dwelling place.

26. But if He says thus: "I have no delight in you,' here I am, let Him do to me as seems good to Him."

27. The king also said to Zadok the priest, "Are you not a seer? Return to the city in peace, and your two sons with you, Ahimaaz your son, and Jonathan the son of Abiathar.

28. See, I will wait in the plains of the wilderness until word comes from you to inform me."

29. Therefore Zadok and Abiathar carried the ark of God back to Jerusalem. And they remained there.

30. So David went up by the Ascent of the Mount of Olives, and wept as he went up; and he had his head covered and went barefoot. And all the people who were with him covered their heads and went up, weeping as they went up.

31. Then someone told David, saying, "Ahithophel is among the conspirators with Absalom." And David said, "O LORD, I pray, turn the counsel of Ahithophel into foolishness!"

32. Now it happened when David had come to the top of the mountain, where he worshiped God--there was Hushai the Archite coming to meet him with his robe torn and dust on his head.

33. David said to him, "If you go on with me, then you will become a burden to me.

34. But if you return to the city, and say to Absalom, "I will be your servant, O king; as I was your father's servant previously, so I will now also be your servant,' then you may defeat the counsel of Ahithophel for me.

35. And do you not have Zadok and Abiathar the priests with you there? Therefore it will be that whatever you hear from the king's house, you shall tell to Zadok and Abiathar the priests.

36. Indeed they have there with them their two sons, Ahimaaz, Zadok's son, and Jonathan, Abiathar's son; and by them you shall send me everything you hear."

37. So Hushai, David's friend, went into the city. And Absalom came into Jerusalem.

## Chapter 16

1. When David was a little past the top of the mountain, there was Ziba the servant of Mephibosheth, who met him with a couple of saddled donkeys, and on them two hundred loaves of bread, one hundred clusters of raisins, one hundred summer fruits, and a skin of wine.

2. And the king said to Ziba, "What do you mean to do with these?" So Ziba said, "The donkeys are for the king's household to ride on, the bread and summer fruit for the young men to eat, and the wine for those who are faint in the wilderness to drink."

3. Then the king said, "And where is your master's son?" And Ziba said to the king, "Indeed he is staying in Jerusalem, for he said, "Today the house of Israel will restore the kingdom of my father to me."'

4. So the king said to Ziba, "Here, all that belongs to Mephibosheth is yours." And Ziba said, "I humbly bow before you, that I may find favor in your sight, my lord, O king!"

5. Now when King David came to Bahurim, there was a man from the family of the house of Saul, whose name was Shimei the son of Gera, coming from there. He came out, cursing continuously as he came.

6. And he threw stones at David and at all the servants of King David. And all the people and all the mighty men were on his right hand and on his left.

7. Also Shimei said thus when he cursed: "Come out! Come out! You bloodthirsty man, you rogue!

8. The LORD has brought upon you all the blood of the house of Saul, in whose place you have reigned; and the LORD has delivered the kingdom into the hand of Absalom your son. So now you are caught in your own evil, because you are a bloodthirsty man!"

9. Then Abishai the son of Zeruiah said to the king, "Why should this dead dog curse my lord the king? Please, let me go over and take off his head!"

10. But the king said, "What have I to do with you, you sons of Zeruiah? So let him curse, because the LORD has said to him, "Curse David.' Who then shall say, "Why have you done so?"'

11. And David said to Abishai and all his servants, "See how my son who came from my own body seeks my life. How much more now may this Benjamite? Let him alone, and let him curse; for so the LORD has ordered him.

12. It may be that the LORD will look on my affliction, and that the LORD will repay me with good for his cursing this day."

13. And as David and his men went along the road, Shimei went along the hillside opposite him and cursed as he went, threw stones at him and kicked up dust.

14. Now the king and all the people who were with him became weary; so they refreshed themselves there.

15. Meanwhile Absalom and all the people, the men of Israel, came to Jerusalem; and Ahithophel was with him.

16. And so it was, when Hushai the Archite, David's friend, came to Absalom, that Hushai said to Absalom, "Long live the king! Long live the king!"

17. So Absalom said to Hushai, "Is this your loyalty to your friend? Why did you not go with your friend?"

18. And Hushai said to Absalom, "No, but whom the LORD and this people and all the men of Israel choose, his I will be, and with him I will remain.

19. "Furthermore, whom should I serve? Should I not serve in the presence of his son? As I have served in your father's presence, so will I be in your presence."

20. Then Absalom said to Ahithophel, "Give advice as to what we should do."

21. And Ahithophel said to Absalom, "Go in to your father's concubines, whom he has left to keep the house; and all Israel will hear that you are abhorred by your father. Then the hands of all who are with you will be strong."

22. So they pitched a tent for Absalom on the top of the house, and Absalom went in to his father's concubines in the sight of all Israel.

23. Now the advice of Ahithophel, which he gave in those days, was as if one had inquired at the oracle of God. So was all the advice of Ahithophel both with David and with Absalom.

## Chapter 17

1. Moreover Ahithophel said to Absalom, "Now let me choose twelve thousand men, and I will arise and pursue David tonight.

2. I will come upon him while he is weary and weak, and make him afraid. And all the people who are with him will flee, and I will strike only the king.

3. Then I will bring back all the people to you. When all return except the man whom you seek, all the people will be at peace."

4. And the saying pleased Absalom and all the elders of Israel.

5. Then Absalom said, "Now call Hushai the Archite also, and let us hear what he says too."

6. And when Hushai came to Absalom, Absalom spoke to him, saying, "Ahithophel has spoken in this manner. Shall we do as he says? If not, speak up."

7. So Hushai said to Absalom: "The advice that Ahithophel has given is not good at this time.

8. For," said Hushai, "you know your father and his men, that they are mighty men, and they are enraged in their minds, like a bear robbed of her cubs in the field; and your father is a man of war, and will not camp with the people.

9. Surely by now he is hidden in some pit, or in some other place. And it will be, when some of them are overthrown at the first, that whoever hears it will say, "There is a slaughter among the people who follow Absalom.'

10. And even he who is valiant, whose heart is like the heart of a lion, will melt completely. For all Israel knows that your father is a mighty man, and those who are with him are valiant men.

11. Therefore I advise that all Israel be fully gathered to you, from Dan to Beersheba, like the sand that is by the sea for multitude, and that you go to battle in person.

12. So we will come upon him in some place where he may be found, and we will fall on him as the dew falls on the ground. And of him and all the men who are with him there shall not be left so much as one.

13. Moreover, if he has withdrawn into a city, then all Israel shall bring ropes to that city; and we will pull it into the river, until there is not one small stone found there."

14. So Absalom and all the men of Israel said, "The advice of Hushai the Archite is better than the advice of Ahithophel." For the LORD had purposed to defeat the good advice of Ahithophel, to the intent that the LORD might bring disaster on Absalom.

15. Then Hushai said to Zadok and Abiathar the priests, "Thus and so Ahithophel advised Absalom and the elders of Israel, and thus and so I have advised.

16. Now therefore, send quickly and tell David, saying, "Do not spend this night in the plains of the wilderness, but speedily cross over, lest the king and all the people who are with him be swallowed up."'

17. Now Jonathan and Ahimaaz stayed at En Rogel, for they dared not be seen coming into the city; so a female servant would come and tell them, and they would go and tell King David.

18. Nevertheless a lad saw them, and told Absalom. But both of them went away quickly and came to a man's house in Bahurim, who had a well in his court; and they went down into it.

19. Then the woman took and spread a covering over the well's mouth, and spread ground grain on it; and the thing was not known.

20. And when Absalom's servants came to the woman at the house, they said, "Where are Ahimaaz and Jonathan?" So the woman said to them, "They have gone over the water brook." And when they had searched and could not find them, they returned to Jerusalem.

21. Now it came to pass, after they had departed, that they came up out of the well and went and told King David, and said to David, "Arise and cross over the water quickly. For thus has Ahithophel advised against you."

22. So David and all the people who were with him arose and crossed over the Jordan. By morning light not one of them was left who had not gone over the Jordan.

23. Now when Ahithophel saw that his advice was not followed, he saddled a donkey, and arose and went home to his house, to his city. Then he put his household in order, and hanged himself, and died; and he was buried in his father's tomb.

24. Then David went to Mahanaim. And Absalom crossed over the Jordan, he and all the men of Israel with him.

25. And Absalom made Amasa captain of the army instead of Joab. This Amasa was the son of a man whose name was Jithra, an Israelite, who had gone in to Abigail the daughter of Nahash, sister of Zeruiah, Joab's mother.

26. So Israel and Absalom encamped in the land of Gilead.

27. Now it happened, when David had come to Mahanaim, that Shobi the son of Nahash from Rabbah of the people of Ammon, Machir the son of Ammiel from Lo Debar, and Barzillai the Gileadite from Rogelim,

28. brought beds and basins, earthen vessels and wheat, barley and flour, parched grain and beans, lentils and parched seeds,

29. honey and curds, sheep and cheese of the herd, for David and the people who were with him to eat. For they said, "The people are hungry and weary and thirsty in the wilderness."

## Chapter 18

1. And David numbered the people who were with him, and set captains of thousands and captains of hundreds over them.

2. Then David sent out one third of the people under the hand of Joab, one third under the hand of Abishai the son of Zeruiah, Joab's brother, and one third under the hand of Ittai the Gittite. And the king said to the people, "I also will surely go out with you myself."

3. But the people answered, "You shall not go out! For if we flee away, they will not care about us; nor if half of us die, will they care about us. But you are worth ten thousand of us now. For you are now more help to us in the city."

4. Then the king said to them, "Whatever seems best to you I will do." So the king stood beside the gate, and all the people went out by hundreds and by thousands.

5. Now the king had commanded Joab, Abishai, and Ittai, saying, "Deal gently for my sake with the young man Absalom." And all the people heard when the king gave all the captains orders concerning Absalom.

6. So the people went out into the field of battle against Israel. And the battle was in the woods of Ephraim.

7. The people of Israel were overthrown there before the servants of David, and a great slaughter of twenty thousand took place there that day.

8. For the battle there was scattered over the face of the whole countryside, and the woods devoured more people that day than the sword devoured.

9. Then Absalom met the servants of David. Absalom rode on a mule. The mule went under the thick boughs of a great terebinth tree, and his head caught in the terebinth; so he was left hanging between heaven and earth. And the mule which was under him went on.

10. Now a certain man saw it and told Joab, and said, "I just saw Absalom hanging in a terebinth tree!"

11. So Joab said to the man who told him, "You just saw him! And why did you not strike him there to the ground? I would have given you ten shekels of silver and a belt."

12. But the man said to Joab, "Though I were to receive a thousand shekels of silver in my hand, I would not raise my hand against the king's son. For in our hearing the king commanded you and Abishai and Ittai, saying, "Beware lest anyone touch the young man Absalom!'

13. Otherwise I would have dealt falsely against my own life. For there is nothing hidden from the king, and you yourself would have set yourself against me."

14. Then Joab said, "I cannot linger with you." And he took three spears in his hand and thrust them through Absalom's heart, while he was still alive in the midst of the terebinth tree.

15. And ten young men who bore Joab's armor surrounded Absalom, and struck and killed him.

16. So Joab blew the trumpet, and the people returned from pursuing Israel. For Joab held back the people.

17. And they took Absalom and cast him into a large pit in the woods, and laid a very large heap of stones over him. Then all Israel fled, everyone to his tent.

18. Now Absalom in his lifetime had taken and set up a pillar for himself, which is in the King's Valley. For he said, "I have no son to keep my name in remembrance." He called the pillar after his own name. And to this day it is called Absalom's Monument.

19. Then Ahimaaz the son of Zadok said, "Let me run now and take the news to the king, how the LORD has avenged him of his enemies."

20. And Joab said to him, "You shall not take the news this day, for you shall take the news another day. But today you shall take no news, because the king's son is dead."

21. Then Joab said to the Cushite, "Go, tell the king what you have seen." So the Cushite bowed himself to Joab and ran.

22. And Ahimaaz the son of Zadok said again to Joab, "But whatever happens, please let me also run after the Cushite." So Joab said, "Why will you run, my son, since you have no news ready?"

23. "But whatever happens," he said, "let me run." So he said to him, "Run." Then Ahimaaz ran by way of the plain, and outran the Cushite.

24. Now David was sitting between the two gates. And the watchman went up to the roof over the gate, to the wall, lifted his eyes and looked, and there was a man, running alone.

25. Then the watchman cried out and told the king. And the king said, "If he is alone, there is news in his mouth." And he came rapidly and drew near.

26. Then the watchman saw another man running, and the watchman called to the gatekeeper and said, "There is another man, running alone!" And the king said, "He also brings news."

27. So the watchman said, "I think the running of the first is like the running of Ahimaaz the son of Zadok." And the king said, "He is a good man, and comes with good news."

28. So Ahimaaz called out and said to the king, "All is well!" Then he bowed down with his face to the earth before the king, and said, "Blessed be the LORD your God, who has delivered up the men who raised their hand against my lord the king!"

29. The king said, "Is the young man Absalom safe?" Ahimaaz answered, "When Joab sent the king's servant and me your servant, I saw a great tumult, but I did not know what it was about."

30. And the king said, "Turn aside and stand here." So he turned aside and stood still.

31. Just then the Cushite came, and the Cushite said, "There is good news, my lord the king! For the LORD has avenged you this day of all those who rose against you."

32. And the king said to the Cushite, "Is the young man Absalom safe?" So the Cushite answered, "May the enemies of my lord the king, and all who rise against you to do harm, be like that young man!"

33. Then the king was deeply moved, and went up to the chamber over the gate, and wept. And as he went, he said thus: "O my son Absalom--my son, my son Absalom--if only I had died in your place! O Absalom my son, my son!"

## Chapter 19

1. And Joab was told, "Behold, the king is weeping and mourning for Absalom."

2. So the victory that day was turned into mourning for all the people. For the people heard it said that day, "The king is grieved for his son."

3. And the people stole back into the city that day, as people who are ashamed steal away when they flee in battle.

4. But the king covered his face, and the king cried out with a loud voice, "O my son Absalom! O Absalom, my son, my son!"

5. Then Joab came into the house to the king, and said, "Today you have disgraced all your servants who today have saved your life, the lives of your sons and daughters, the lives of your wives and the lives of your concubines,

6. in that you love your enemies and hate your friends. For you have declared today that you regard neither princes nor servants; for today I perceive that if Absalom had lived and all of us had died today, then it would have pleased you well.

7. Now therefore, arise, go out and speak comfort to your servants. For I swear by the LORD, if you do not go out, not one will stay with you this night. And that will be worse for you than all the evil that has befallen you from your youth until now."

8. Then the king arose and sat in the gate. And they told all the people, saying, "There is the king, sitting in the gate." So all the people came before the king. For everyone of Israel had fled to his tent.

9. Now all the people were in a dispute throughout all the tribes of Israel, saying, "The king saved us from the hand of our enemies, he delivered us from the hand of the Philistines, and now he has fled from the land because of Absalom.

10. But Absalom, whom we anointed over us, has died in battle. Now therefore, why do you say nothing about bringing back the king?"

11. So King David sent to Zadok and Abiathar the priests, saying, "Speak to the elders of Judah, saying, "Why are you the last to bring the king back to his house, since the words of all Israel have come to the king, to his very house?

12. You are my brethren, you are my bone and my flesh. Why then are you the last to bring back the king?'

13. And say to Amasa, "Are you not my bone and my flesh? God do so to me, and more also, if you are not commander of the army before me continually in place of Joab."'

14. So he swayed the hearts of all the men of Judah, just as the heart of one man, so that they sent this word to the king: "Return, you and all your servants!"

15. Then the king returned and came to the Jordan. And Judah came to Gilgal, to go to meet the king, to escort the king across the Jordan.

16. And Shimei the son of Gera, a Benjamite, who was from Bahurim, hurried and came down with the men of Judah to meet King David.

17. There were a thousand men of Benjamin with him, and Ziba the servant of the house of Saul, and his fifteen sons and his twenty servants with him; and they went over the Jordan before the king.

18. Then a ferryboat went across to carry over the king's household, and to do what he thought good. Now Shimei the son of Gera fell down before the king when he had crossed the Jordan.

19. Then he said to the king, "Do not let my lord impute iniquity to me, or remember what wrong your servant did on the day that my lord the king left Jerusalem, that the king should take it to heart.

20. For I, your servant, know that I have sinned. Therefore here I am, the first to come today of all the house of Joseph to go down to meet my lord the king."

21. But Abishai the son of Zeruiah answered and said, "Shall not Shimei be put to death for this, because he cursed the LORD's anointed?"

22. And David said, "What have I to do with you, you sons of Zeruiah, that you should be adversaries to me today? Shall any man be put to death today in Israel? For do I not know that today I am king over Israel?"

23. Therefore the king said to Shimei, "You shall not die." And the king swore to him.

24. Now Mephibosheth the son of Saul came down to meet the king. And he had not cared for his feet, nor trimmed his mustache, nor washed his clothes, from the day the king departed until the day he returned in peace.

25. So it was, when he had come to Jerusalem to meet the king, that the king said to him, "Why did you not go with me, Mephibosheth?"

26. And he answered, "My lord, O king, my servant deceived me. For your servant said, "I will saddle a donkey for myself, that I may ride on it and go to the king,' because your servant is lame.

27. And he has slandered your servant to my lord the king, but my lord the king is like the angel of God. Therefore do what is good in your eyes.

28. For all my father's house were but dead men before my lord the king. Yet you set your servant among those who eat at your own table. Therefore what right have I still to cry out anymore to the king?"

29. So the king said to him, "Why do you speak anymore of your matters? I have said, "You and Ziba divide the land."'

30. Then Mephibosheth said to the king, "Rather, let him take it all, inasmuch as my lord the king has come back in peace to his own house."

31. And Barzillai the Gileadite came down from Rogelim and went across the Jordan with the king, to escort him across the Jordan.

32. Now Barzillai was a very aged man, eighty years old. And he had provided the king with supplies while he stayed at Mahanaim, for he was a very rich man.

33. And the king said to Barzillai, "Come across with me, and I will provide for you while you are with me in Jerusalem."

34. But Barzillai said to the king, "How long have I to live, that I should go up with the king to Jerusalem?

35. I am today eighty years old. Can I discern between the good and bad? Can your servant taste what I eat or what I drink? Can I hear any longer the voice of singing men and singing women? Why then should your servant be a further burden to my lord the king?

36. Your servant will go a little way across the Jordan with the king. And why should the king repay me with such a reward?

37. Please let your servant turn back again, that I may die in my own city, near the grave of my father and mother. But here is your servant Chimham; let him cross over with my lord the king, and do for him what seems good to you."

38. And the king answered, "Chimham shall cross over with me, and I will do for him what seems good to you. Now whatever you request of me, I will do for you."

39. Then all the people went over the Jordan. And when the king had crossed over, the king kissed Barzillai and blessed him, and he returned to his own place.

40. Now the king went on to Gilgal, and Chimham went on with him. And all the people of Judah escorted the king, and also half the people of Israel.

41. Just then all the men of Israel came to the king, and said to the king, "Why have our brethren, the men of Judah, stolen you away and brought the king, his household, and all David's men with him across the Jordan?"

42. So all the men of Judah answered the men of Israel, "Because the king is a close relative of ours. Why then are you angry over this matter? Have we ever eaten at the king's expense? Or has he given us any gift?"

43. And the men of Israel answered the men of Judah, and said, "We have ten shares in the king; therefore we also have more right to David than you. Why then do you despise us--were we not the first to advise bringing back our king?" Yet the words of the men of Judah were fiercer than the words of the men of Israel.

## Chapter 20

1. And there happened to be there a rebel, whose name was Sheba the son of Bichri, a Benjamite. And he blew a trumpet, and said: "We have no share in David, Nor do we have inheritance in the son of Jesse; Every man to his tents, O Israel!"

2. So every man of Israel deserted David, and followed Sheba the son of Bichri. But the men of Judah, from the Jordan as far as Jerusalem, remained loyal to their king.

3. Now David came to his house at Jerusalem. And the king took the ten women, his concubines whom he had left to keep the house, and put them in seclusion and supported them, but did not go in to them. So they were shut up to the day of their death, living in widowhood.

4. And the king said to Amasa, "Assemble the men of Judah for me within three days, and be present here yourself."

5. So Amasa went to assemble the men of Judah. But he delayed longer than the set time which David had appointed him.

6. And David said to Abishai, "Now Sheba the son of Bichri will do us more harm than Absalom. Take your lord's servants and pursue him, lest he find for himself fortified cities, and escape us."

7. So Joab's men, with the Cherethites, the Pelethites, and all the mighty men, went out after him. And they went out of Jerusalem to pursue Sheba the son of Bichri.

8. When they were at the large stone which is in Gibeon, Amasa came before them. Now Joab was dressed in battle armor; on it was a belt with a sword fastened in its sheath at his hips; and as he was going forward, it fell out.

9. Then Joab said to Amasa, "Are you in health, my brother?" And Joab took Amasa by the beard with his right hand to kiss him.

10. But Amasa did not notice the sword that was in Joab's hand. And he struck him with it in the stomach, and his entrails poured out on the ground; and he did not strike him again. Thus he died. Then Joab and Abishai his brother pursued Sheba the son of Bichri.

11. Meanwhile one of Joab's men stood near Amasa, and said, "Whoever favors Joab and whoever is for David--follow Joab!"

12. But Amasa wallowed in his blood in the middle of the highway. And when the man saw that all the people stood still, he moved Amasa from the highway to the field and threw a garment over him, when he saw that everyone who came upon him halted.

13. When he was removed from the highway, all the people went on after Joab to pursue Sheba the son of Bichri.

14. And he went through all the tribes of Israel to Abel and Beth Maachah and all the Berites. So they were gathered together and also went after Sheba.

15. Then they came and besieged him in Abel of Beth Maachah; and they cast up a siege mound against the city, and it stood by the rampart. And all the people who were with Joab battered the wall to throw it down.

16. Then a wise woman cried out from the city, "Hear, hear! Please say to Joab, "Come nearby, that I may speak with you."'

17. When he had come near to her, the woman said, "Are you Joab?" He answered, "I am." Then she said to him, "Hear the words of your maidservant." And he answered, "I am listening."

18. So she spoke, saying, "They used to talk in former times, saying, "They shall surely seek guidance at Abel,' and so they would end disputes.

19. I am among the peaceable and faithful in Israel. You seek to destroy a city and a mother in Israel. Why would you swallow up the inheritance of the LORD?"

20. And Joab answered and said, "Far be it, far be it from me, that I should swallow up or destroy!

21. That is not so. But a man from the mountains of Ephraim, Sheba the son of Bichri by name, has raised his hand against the king, against David. Deliver him only, and I will depart from the city." So the woman said to Joab, "Watch, his head will be thrown to you over the wall."

22. Then the woman in her wisdom went to all the people. And they cut off the head of Sheba the son of Bichri, and threw it out to Joab. Then he blew a trumpet, and they withdrew from the city, every man to his tent. So Joab returned to the king at Jerusalem.

23. And Joab was over all the army of Israel; Benaiah the son of Jehoiada was over the Cherethites and the Pelethites;

24. Adoram was in charge of revenue; Jehoshaphat the son of Ahilud was recorder;

25. Sheva was scribe; Zadok and Abiathar were the priests;

26. and Ira the Jairite was a chief minister under David.

## Chapter 21

1. Now there was a famine in the days of David for three years, year after year; and David inquired of the LORD. And the LORD answered, "It is because of Saul and his bloodthirsty house, because he killed the Gibeonites."

2. So the king called the Gibeonites and spoke to them. Now the Gibeonites were not of the children of Israel, but of the remnant of the Amorites; the children of Israel had sworn protection to them, but Saul had sought to kill them in his zeal for the children of Israel and Judah.

3. Therefore David said to the Gibeonites, "What shall I do for you? And with what shall I make atonement, that you may bless the inheritance of the LORD?"

4. And the Gibeonites said to him, "We will have no silver or gold from Saul or from his house, nor shall you kill any man in Israel for us." So he said, "Whatever you say, I will do for you."

5. Then they answered the king, "As for the man who consumed us and plotted against us, that we should be destroyed from remaining in any of the territories of Israel,

6. let seven men of his descendants be delivered to us, and we will hang them before the LORD in Gibeah of Saul, whom the LORD chose." And the king said, "I will give them."

7. But the king spared Mephibosheth the son of Jonathan, the son of Saul, because of the LORD's oath that was between them, between David and Jonathan the son of Saul.

8. So the king took Armoni and Mephibosheth, the two sons of Rizpah the daughter of Aiah, whom she bore to Saul, and the five sons of Michal the daughter of Saul, whom she brought up for Adriel the son of Barzillai the Meholathite;

9. and he delivered them into the hands of the Gibeonites, and they hanged them on the hill before the LORD. So they fell, all seven together, and were put to death in the days of harvest, in the first days, in the beginning of barley harvest.

10. Now Rizpah the daughter of Aiah took sackcloth and spread it for herself on the rock, from the beginning of harvest until the late rains poured on them from heaven. And she did not allow the birds of the air to rest on them by day nor the beasts of the field by night.

11. And David was told what Rizpah the daughter of Aiah, the concubine of Saul, had done.

12. Then David went and took the bones of Saul, and the bones of Jonathan his son, from the men of Jabesh Gilead who had stolen them from the street of Beth Shan, where the Philistines had hung them up, after the Philistines had struck down Saul in Gilboa.

13. So he brought up the bones of Saul and the bones of Jonathan his son from there; and they gathered the bones of those who had been hanged.

14. They buried the bones of Saul and Jonathan his son in the country of Benjamin in Zelah, in the tomb of Kish his father. So they performed all that the king commanded. And after that God heeded the prayer for the land.

15. When the Philistines were at war again with Israel, David and his servants with him went down and fought against the Philistines; and David grew faint.

16. Then Ishbi-Benob, who was one of the sons of the giant, the weight of whose bronze spear was three hundred shekels, who was bearing a new sword, thought he could kill David.

17. But Abishai the son of Zeruiah came to his aid, and struck the Philistine and killed him. Then the men of David swore to him, saying, "You shall go out no more with us to battle, lest you quench the lamp of Israel."

18. Now it happened afterward that there was again a battle with the Philistines at Gob. Then Sibbechai the Hushathite killed Saph, who was one of the sons of the giant.

19. Again there was war at Gob with the Philistines, where Elhanan the son of Jaare-Oregim the Bethlehemite killed the brother of Goliath the Gittite, the shaft of whose spear was like a weaver's beam.

20. Yet again there was war at Gath, where there was a man of great stature, who had six fingers on each hand and six toes on each foot, twenty-four in number; and he also was born to the giant.

21. So when he defied Israel, Jonathan the son of Shimea, David's brother, killed him.

22. These four were born to the giant in Gath, and fell by the hand of David and by the hand of his servants.

## Chapter 22

1. Then David spoke to the LORD the words of this song, on the day when the LORD had delivered him from the hand of all his enemies, and from the hand of Saul.

2. And he said: "The LORD is my rock and my fortress and my deliverer;

3. The God of my strength, in whom I will trust; My shield and the horn of my salvation, My stronghold and my refuge; My Savior, You save me from violence.

4. I will call upon the LORD, who is worthy to be praised; So shall I be saved from my enemies.

5. "When the waves of death surrounded me, The floods of ungodliness made me afraid.

6. The sorrows of Sheol surrounded me; The snares of death confronted me.

7. In my distress I called upon the LORD, And cried out to my God; He heard my voice from His temple, And my cry entered His ears.

8. "Then the earth shook and trembled; The foundations of heaven quaked and were shaken, Because He was angry.

9. Smoke went up from His nostrils, And devouring fire from His mouth; Coals were kindled by it.

10. He bowed the heavens also, and came down With darkness under His feet.

11. He rode upon a cherub, and flew; And He was seen upon the wings of the wind.

12. He made darkness canopies around Him, Dark waters and thick clouds of the skies.

13. From the brightness before Him Coals of fire were kindled.

14. "The LORD thundered from heaven, And the Most High uttered His voice.

15. He sent out arrows and scattered them; Lightning bolts, and He vanquished them.

16. Then the channels of the sea were seen, The foundations of the world were uncovered, At the rebuke of the LORD, At the blast of the breath of His nostrils.

17. "He sent from above, He took me, He drew me out of many waters.

18. He delivered me from my strong enemy, From those who hated me; For they were too strong for me.

19. They confronted me in the day of my calamity, But the LORD was my support.

20. He also brought me out into a broad place; He delivered me because He delighted in me.

21. "The LORD rewarded me according to my righteousness; According to the cleanness of my hands He has recompensed me.

22. For I have kept the ways of the LORD, And have not wickedly departed from my God.

23. For all His judgments were before me; And as for His statutes, I did not depart from them.

24. I was also blameless before Him, And I kept myself from my iniquity.

25. Therefore the LORD has recompensed me according to my righteousness, According to my cleanness in His eyes.

26. "With the merciful You will show Yourself merciful; With a blameless man You will show Yourself blameless;

27. With the pure You will show Yourself pure; And with the devious You will show Yourself shrewd.

28. You will save the humble people; But Your eyes are on the haughty, that You may bring them down.

29. "For You are my lamp, O LORD; The LORD shall enlighten my darkness.

30. For by You I can run against a troop; By my God I can leap over a wall.

31. As for God, His way is perfect; The word of the LORD is proven; He is a shield to all who trust in Him.

32. "For who is God, except the LORD? And who is a rock, except our God?

33. God is my strength and power, And He makes my way perfect.

34. He makes my feet like the feet of deer, And sets me on my high places.

35. He teaches my hands to make war, So that my arms can bend a bow of bronze.

36. "You have also given me the shield of Your salvation; Your gentleness has made me great.

37. You enlarged my path under me; So my feet did not slip.

38. "I have pursued my enemies and destroyed them; Neither did I turn back again till they were destroyed.

39. And I have destroyed them and wounded them, So that they could not rise; They have fallen under my feet.

40. For You have armed me with strength for the battle; You have subdued under me those who rose against me.

41. You have also given me the necks of my enemies, So that I destroyed those who hated me.

42. They looked, but there was none to save; Even to the LORD, but He did not answer them.

43. Then I beat them as fine as the dust of the earth; I trod them like dirt in the streets, And I spread them out.

44. "You have also delivered me from the strivings of my people; You have kept me as the head of the nations. A people I have not known shall serve me.

45. The foreigners submit to me; As soon as they hear, they obey me.

46. The foreigners fade away, And come frightened from their hideouts.

47. "The LORD lives! Blessed be my Rock! Let God be exalted, The Rock of my salvation!

48. It is God who avenges me, And subdues the peoples under me;

49. He delivers me from my enemies. You also lift me up above those who rise against me; You have delivered me from the violent man.

50. Therefore I will give thanks to You, O LORD, among the Gentiles, And sing praises to Your name.

51. He is the tower of salvation to His king, And shows mercy to His anointed, To David and his descendants forevermore."

## Chapter 23

1. Now these are the last words of David. Thus says David the son of Jesse; Thus says the man raised up on high, The anointed of the God of Jacob, And the sweet psalmist of Israel:

2. "The Spirit of the LORD spoke by me, And His word was on my tongue.

3. The God of Israel said, The Rock of Israel spoke to me: "He who rules over men must be just, Ruling in the fear of God.

4. And he shall be like the light of the morning when the sun rises, A morning without clouds, Like the tender grass springing out of the earth, By clear shining after rain.'

5. "Although my house is not so with God, Yet He has made with me an everlasting covenant, Ordered in all things and secure. For this is all my salvation and all my desire; Will He not make it increase?

6. But the sons of rebellion shall all be as thorns thrust away, Because they cannot be taken with hands.

7. But the man who touches them Must be armed with iron and the shaft of a spear, And they shall be utterly burned with fire in their place."

8. These are the names of the mighty men whom David had: Josheb-Basshebeth the Tachmonite, chief among the captains. He was called Adino the Eznite, because he had killed eight hundred men at one time.

9. And after him was Eleazar the son of Dodo, the Ahohite, one of the three mighty men with David when they defied the Philistines who were gathered there for battle, and the men of Israel had retreated.

10. He arose and attacked the Philistines until his hand was weary, and his hand stuck to the sword. The LORD brought about a great victory that day; and the people returned after him only to plunder.

11. And after him was Shammah the son of Agee the Hararite. The Philistines had gathered together into a troop where there was a piece of ground full of lentils. So the people fled from the Philistines.

12. But he stationed himself in the middle of the field, defended it, and killed the Philistines. So the LORD brought about a great victory.

13. Then three of the thirty chief men went down at harvest time and came to David at the cave of Adullam. And the troop of Philistines encamped in the Valley of Rephaim.

14. David was then in the stronghold, and the garrison of the Philistines was then in Bethlehem.

15. And David said with longing, "Oh, that someone would give me a drink of the water from the well of Bethlehem, which is by the gate!"

16. So the three mighty men broke through the camp of the Philistines, drew water from the well of Bethlehem that was by the gate, and took it and brought it to David. Nevertheless he would not drink it, but poured it out to the LORD.

17. And he said, "Far be it from me, O LORD, that I should do this! Is this not the blood of the men who went in jeopardy of their lives?" Therefore he would not drink it. These things were done by the three mighty men.

18. Now Abishai the brother of Joab, the son of Zeruiah, was chief of another three. He lifted his spear against three hundred men, killed them, and won a name among these three.

19. Was he not the most honored of three? Therefore he became their captain. However, he did not attain to the first three.

20. Benaiah was the son of Jehoiada, the son of a valiant man from Kabzeel, who had done many deeds. He had killed two lion-like heroes of Moab. He also had gone down and killed a lion in the midst of a pit on a snowy day.

21. And he killed an Egyptian, a spectacular man. The Egyptian had a spear in his hand; so he went down to him with a staff, wrested the spear out of the Egyptian's hand, and killed him with his own spear.

22. These things Benaiah the son of Jehoiada did, and won a name among three mighty men.

23. He was more honored than the thirty, but he did not attain to the first three. And David appointed him over his guard.

24. Asahel the brother of Joab was one of the thirty; Elhanan the son of Dodo of Bethlehem,

25. Shammah the Harodite, Elika the Harodite,

26. Helez the Paltite, Ira the son of Ikkesh the Tekoite,

27. Abiezer the Anathothite, Mebunnai the Hushathite,

28. Zalmon the Ahohite, Maharai the Netophathite,

29. Heleb the son of Baanah (the Netophathite), Ittai the son of Ribai from Gibeah of the children of Benjamin,

30. Benaiah a Pirathonite, Hiddai from the brooks of Gaash,

31. Abi-Albon the Arbathite, Azmaveth the Barhumite,

32. Eliahba the Shaalbonite (of the sons of Jashen), Jonathan,

33. Shammah the Hararite, Ahiam the son of Sharar the Hararite,

34. Eliphelet the son of Ahasbai, the son of the Maachathite, Eliam the son of Ahithophel the Gilonite,

35. Hezrai the Carmelite, Paarai the Arbite,

36. Igal the son of Nathan of Zobah, Bani the Gadite,

37. Zelek the Ammonite, Naharai the Beerothite (armorbearer of Joab the son of Zeruiah),

38. Ira the Ithrite, Gareb the Ithrite,

39. and Uriah the Hittite: thirty-seven in all.

## Chapter 24

1. Again the anger of the LORD was aroused against Israel, and He moved David against them to say, "Go, number Israel and Judah."

2. So the king said to Joab the commander of the army who was with him, "Now go throughout all the tribes of Israel, from Dan to Beersheba, and count the people, that I may know the number of the people."

3. And Joab said to the king, "Now may the LORD your God add to the people a hundred times more than there are, and may the eyes of my lord the king see it. But why does my lord the king desire this thing?"

4. Nevertheless the king's word prevailed against Joab and against the captains of the army. Therefore Joab and the captains of the army went out from the presence of the king to count the people of Israel.

5. And they crossed over the Jordan and camped in Aroer, on the right side of the town which is in the midst of the ravine of Gad, and toward Jazer.

6. Then they came to Gilead and to the land of Tahtim Hodshi; they came to Dan Jaan and around to Sidon;

7. and they came to the stronghold of Tyre and to all the cities of the Hivites and the Canaanites. Then they went out to South Judah as far as Beersheba.

8. So when they had gone through all the land, they came to Jerusalem at the end of nine months and twenty days.

9. Then Joab gave the sum of the number of the people to the king. And there were in Israel eight hundred thousand valiant men who drew the sword, and the men of Judah were five hundred thousand men.

10. And David's heart condemned him after he had numbered the people. So David said to the LORD, "I have sinned greatly in what I have done; but now, I pray, O LORD, take away the iniquity of Your servant, for I have done very foolishly."

11. Now when David arose in the morning, the word of the LORD came to the prophet Gad, David's seer, saying,

12. "Go and tell David, "Thus says the LORD: "I offer you three things; choose one of them for yourself, that I may do it to you.""'

13. So Gad came to David and told him; and he said to him, "Shall seven years of famine come to you in your land? Or shall you flee three months before your enemies, while they pursue you? Or shall there be three days' plague in your land? Now consider and see what answer I should take back to Him who sent me."

14. And David said to Gad, "I am in great distress. Please let us fall into the hand of the LORD, for His mercies are great; but do not let me fall into the hand of man."

15. So the LORD sent a plague upon Israel from the morning till the appointed time. From Dan to Beersheba seventy thousand men of the people died.

16. And when the angel stretched out His hand over Jerusalem to destroy it, the LORD relented from the destruction, and said to the angel who was destroying the people, "It is enough; now restrain your hand." And the angel of the LORD was by the threshing floor of Araunah the Jebusite.

17. Then David spoke to the LORD when he saw the angel who was striking the people, and said, "Surely I have sinned, and I have done wickedly; but these sheep, what have they done? Let Your hand, I pray, be against me and against my father's house."

18. And Gad came that day to David and said to him, "Go up, erect an altar to the LORD on the threshing floor of Araunah the Jebusite."

19. So David, according to the word of Gad, went up as the LORD commanded.

20. Now Araunah looked, and saw the king and his servants coming toward him. So Araunah went out and bowed before the king with his face to the ground.

21. Then Araunah said, "Why has my lord the king come to his servant?" And David said, "To buy the threshing floor from you, to build an altar to the LORD, that the plague may be withdrawn from the people."

22. Now Araunah said to David, "Let my lord the king take and offer up whatever seems good to him. Look, here are oxen for burnt sacrifice, and threshing implements and the yokes of the oxen for wood.

23. All these, O king, Araunah has given to the king." And Araunah said to the king, "May the LORD your God accept you."

24. Then the king said to Araunah, "No, but I will surely buy it from you for a price; nor will I offer burnt offerings to the LORD my God with that which costs me nothing." So David bought the threshing floor and the oxen for fifty shekels of silver.

25. And David built there an altar to the LORD, and offered burnt offerings and peace offerings. So the LORD heeded the prayers for the land, and the plague was withdrawn from Israel.


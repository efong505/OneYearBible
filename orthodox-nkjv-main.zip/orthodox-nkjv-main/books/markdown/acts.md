# acts

## Chapter 1

1. The former account I made, O Theophilus, of all that Jesus began both to do and teach,

2. until the day in which He was taken up, after He through the Holy Spirit had given commandments to the apostles whom He had chosen,

3. to whom He also presented Himself alive after His suffering by many infallible proofs, being seen by them during forty days and speaking of the things pertaining to the kingdom of God.

4. And being assembled together with them, He commanded them not to depart from Jerusalem, but to wait for the Promise of the Father, "which," He said, "you have heard from Me;

5. for John truly baptized with water, but you shall be baptized with the Holy Spirit not many days from now."

6. Therefore, when they had come together, they asked Him, saying, "Lord, will You at this time restore the kingdom to Israel?"

7. And He said to them, "It is not for you to know times or seasons which the Father has put in His own authority.

8. But you shall receive power when the Holy Spirit has come upon you; and you shall be witnesses to Me in Jerusalem, and in all Judea and Samaria, and to the end of the earth."

9. Now when He had spoken these things, while they watched, He was taken up, and a cloud received Him out of their sight.

10. And while they looked steadfastly toward heaven as He went up, behold, two men stood by them in white apparel,

11. who also said, "Men of Galilee, why do you stand gazing up into heaven? This same Jesus, who was taken up from you into heaven, will so come in like manner as you saw Him go into heaven."

12. Then they returned to Jerusalem from the mount called Olivet, which is near Jerusalem, a Sabbath day's journey.

13. And when they had entered, they went up into the upper room where they were staying: Peter, James, John, and Andrew; Philip and Thomas; Bartholomew and Matthew; James the son of Alphaeus and Simon the Zealot; and Judas the son of James.

14. These all continued with one accord in prayer and supplication, with the women and Mary the mother of Jesus, and with His brothers.

15. And in those days Peter stood up in the midst of the disciples (altogether the number of names was about a hundred and twenty), and said,

16. "Men and brethren, this Scripture had to be fulfilled, which the Holy Spirit spoke before by the mouth of David concerning Judas, who became a guide to those who arrested Jesus;

17. for he was numbered with us and obtained a part in this ministry."

18. (Now this man purchased a field with the wages of iniquity; and falling headlong, he burst open in the middle and all his entrails gushed out.

19. And it became known to all those dwelling in Jerusalem; so that field is called in their own language, Akel Dama, that is, Field of Blood.)

20. "For it is written in the Book of Psalms: "Let his dwelling place be desolate, And let no one live in it'; and, "Let another take his office.'

21. "Therefore, of these men who have accompanied us all the time that the Lord Jesus went in and out among us,

22. beginning from the baptism of John to that day when He was taken up from us, one of these must become a witness with us of His resurrection."

23. And they proposed two: Joseph called Barsabas, who was surnamed Justus, and Matthias.

24. And they prayed and said, "You, O Lord, who know the hearts of all, show which of these two You have chosen

25. to take part in this ministry and apostleship from which Judas by transgression fell, that he might go to his own place."

26. And they cast their lots, and the lot fell on Matthias. And he was numbered with the eleven apostles.

## Chapter 2

1. When the Day of Pentecost had fully come, they were all with one accord in one place.

2. And suddenly there came a sound from heaven, as of a rushing mighty wind, and it filled the whole house where they were sitting.

3. Then there appeared to them divided tongues, as of fire, and one sat upon each of them.

4. And they were all filled with the Holy Spirit and began to speak with other tongues, as the Spirit gave them utterance.

5. And there were dwelling in Jerusalem Jews, devout men, from every nation under heaven.

6. And when this sound occurred, the multitude came together, and were confused, because everyone heard them speak in his own language.

7. Then they were all amazed and marveled, saying to one another, "Look, are not all these who speak Galileans?

8. And how is it that we hear, each in our own language in which we were born?

9. Parthians and Medes and Elamites, those dwelling in Mesopotamia, Judea and Cappadocia, Pontus and Asia,

10. Phrygia and Pamphylia, Egypt and the parts of Libya adjoining Cyrene, visitors from Rome, both Jews and proselytes,

11. Cretans and Arabs--we hear them speaking in our own tongues the wonderful works of God."

12. So they were all amazed and perplexed, saying to one another, "Whatever could this mean?"

13. Others mocking said, "They are full of new wine."

14. But Peter, standing up with the eleven, raised his voice and said to them, "Men of Judea and all who dwell in Jerusalem, let this be known to you, and heed my words.

15. For these are not drunk, as you suppose, since it is only the third hour of the day.

16. But this is what was spoken by the prophet Joel:

17. "And it shall come to pass in the last days, says God, That I will pour out of My Spirit on all flesh; Your sons and your daughters shall prophesy, Your young men shall see visions, Your old men shall dream dreams.

18. And on My menservants and on My maidservants I will pour out My Spirit in those days; And they shall prophesy.

19. I will show wonders in heaven above And signs in the earth beneath: Blood and fire and vapor of smoke.

20. The sun shall be turned into darkness, And the moon into blood, Before the coming of the great and awesome day of the LORD.

21. And it shall come to pass That whoever calls on the name of the LORD Shall be saved.'

22. "Men of Israel, hear these words: Jesus of Nazareth, a Man attested by God to you by miracles, wonders, and signs which God did through Him in your midst, as you yourselves also know--

23. Him, being delivered by the determined purpose and foreknowledge of God, you have taken by lawless hands, have crucified, and put to death;

24. whom God raised up, having loosed the pains of death, because it was not possible that He should be held by it.

25. For David says concerning Him: "I foresaw the LORD always before my face, For He is at my right hand, that I may not be shaken.

26. Therefore my heart rejoiced, and my tongue was glad; Moreover my flesh also will rest in hope.

27. For You will not leave my soul in Hades, Nor will You allow Your Holy One to see corruption.

28. You have made known to me the ways of life; You will make me full of joy in Your presence.'

29. "Men and brethren, let me speak freely to you of the patriarch David, that he is both dead and buried, and his tomb is with us to this day.

30. Therefore, being a prophet, and knowing that God had sworn with an oath to him that of the fruit of his body, according to the flesh, He would raise up the Christ to sit on his throne,

31. he, foreseeing this, spoke concerning the resurrection of the Christ, that His soul was not left in Hades, nor did His flesh see corruption.

32. This Jesus God has raised up, of which we are all witnesses.

33. Therefore being exalted to the right hand of God, and having received from the Father the promise of the Holy Spirit, He poured out this which you now see and hear.

34. "For David did not ascend into the heavens, but he says himself: "The LORD said to my Lord, "Sit at My right hand,

35. Till I make Your enemies Your footstool."'

36. "Therefore let all the house of Israel know assuredly that God has made this Jesus, whom you crucified, both Lord and Christ."

37. Now when they heard this, they were cut to the heart, and said to Peter and the rest of the apostles, "Men and brethren, what shall we do?"

38. Then Peter said to them, "Repent, and let every one of you be baptized in the name of Jesus Christ for the remission of sins; and you shall receive the gift of the Holy Spirit.

39. For the promise is to you and to your children, and to all who are afar off, as many as the Lord our God will call."

40. And with many other words he testified and exhorted them, saying, "Be saved from this perverse generation."

41. Then those who gladly received his word were baptized; and that day about three thousand souls were added to them.

42. And they continued steadfastly in the apostles' doctrine and fellowship, in the breaking of bread, and in prayers.

43. Then fear came upon every soul, and many wonders and signs were done through the apostles.

44. Now all who believed were together, and had all things in common,

45. and sold their possessions and goods, and divided them among all, as anyone had need.

46. So continuing daily with one accord in the temple, and breaking bread from house to house, they ate their food with gladness and simplicity of heart,

47. praising God and having favor with all the people. And the Lord added to the church daily those who were being saved.

## Chapter 3

1. Now Peter and John went up together to the temple at the hour of prayer, the ninth hour.

2. And a certain man lame from his mother's womb was carried, whom they laid daily at the gate of the temple which is called Beautiful, to ask alms from those who entered the temple;

3. who, seeing Peter and John about to go into the temple, asked for alms.

4. And fixing his eyes on him, with John, Peter said, "Look at us."

5. So he gave them his attention, expecting to receive something from them.

6. Then Peter said, "Silver and gold I do not have, but what I do have I give you: In the name of Jesus Christ of Nazareth, rise up and walk."

7. And he took him by the right hand and lifted him up, and immediately his feet and ankle bones received strength.

8. So he, leaping up, stood and walked and entered the temple with them--walking, leaping, and praising God.

9. And all the people saw him walking and praising God.

10. Then they knew that it was he who sat begging alms at the Beautiful Gate of the temple; and they were filled with wonder and amazement at what had happened to him.

11. Now as the lame man who was healed held on to Peter and John, all the people ran together to them in the porch which is called Solomon's, greatly amazed.

12. So when Peter saw it, he responded to the people: "Men of Israel, why do you marvel at this? Or why look so intently at us, as though by our own power or godliness we had made this man walk?

13. The God of Abraham, Isaac, and Jacob, the God of our fathers, glorified His Servant Jesus, whom you delivered up and denied in the presence of Pilate, when he was determined to let Him go.

14. But you denied the Holy One and the Just, and asked for a murderer to be granted to you,

15. and killed the Prince of life, whom God raised from the dead, of which we are witnesses.

16. And His name, through faith in His name, has made this man strong, whom you see and know. Yes, the faith which comes through Him has given him this perfect soundness in the presence of you all.

17. "Yet now, brethren, I know that you did it in ignorance, as did also your rulers.

18. But those things which God foretold by the mouth of all His prophets, that the Christ would suffer, He has thus fulfilled.

19. Repent therefore and be converted, that your sins may be blotted out, so that times of refreshing may come from the presence of the Lord,

20. and that He may send Jesus Christ, who was preached to you before,

21. whom heaven must receive until the times of restoration of all things, which God has spoken by the mouth of all His holy prophets since the world began.

22. For Moses truly said to the fathers, "The LORD your God will raise up for you a Prophet like me from your brethren. Him you shall hear in all things, whatever He says to you.

23. And it shall be that every soul who will not hear that Prophet shall be utterly destroyed from among the people.'

24. Yes, and all the prophets, from Samuel and those who follow, as many as have spoken, have also foretold these days.

25. You are sons of the prophets, and of the covenant which God made with our fathers, saying to Abraham, "And in your seed all the families of the earth shall be blessed.'

26. To you first, God, having raised up His Servant Jesus, sent Him to bless you, in turning away every one of you from your iniquities."

## Chapter 4

1. Now as they spoke to the people, the priests, the captain of the temple, and the Sadducees came upon them,

2. being greatly disturbed that they taught the people and preached in Jesus the resurrection from the dead.

3. And they laid hands on them, and put them in custody until the next day, for it was already evening.

4. However, many of those who heard the word believed; and the number of the men came to be about five thousand.

5. And it came to pass, on the next day, that their rulers, elders, and scribes,

6. as well as Annas the high priest, Caiaphas, John, and Alexander, and as many as were of the family of the high priest, were gathered together at Jerusalem.

7. And when they had set them in the midst, they asked, "By what power or by what name have you done this?"

8. Then Peter, filled with the Holy Spirit, said to them, "Rulers of the people and elders of Israel:

9. If we this day are judged for a good deed done to a helpless man, by what means he has been made well,

10. let it be known to you all, and to all the people of Israel, that by the name of Jesus Christ of Nazareth, whom you crucified, whom God raised from the dead, by Him this man stands here before you whole.

11. This is the "stone which was rejected by you builders, which has become the chief cornerstone.'

12. Nor is there salvation in any other, for there is no other name under heaven given among men by which we must be saved."

13. Now when they saw the boldness of Peter and John, and perceived that they were uneducated and untrained men, they marveled. And they realized that they had been with Jesus.

14. And seeing the man who had been healed standing with them, they could say nothing against it.

15. But when they had commanded them to go aside out of the council, they conferred among themselves,

16. saying, "What shall we do to these men? For, indeed, that a notable miracle has been done through them is evident to all who dwell in Jerusalem, and we cannot deny it.

17. But so that it spreads no further among the people, let us severely threaten them, that from now on they speak to no man in this name."

18. So they called them and commanded them not to speak at all nor teach in the name of Jesus.

19. But Peter and John answered and said to them, "Whether it is right in the sight of God to listen to you more than to God, you judge.

20. For we cannot but speak the things which we have seen and heard."

21. So when they had further threatened them, they let them go, finding no way of punishing them, because of the people, since they all glorified God for what had been done.

22. For the man was over forty years old on whom this miracle of healing had been performed.

23. And being let go, they went to their own companions and reported all that the chief priests and elders had said to them.

24. So when they heard that, they raised their voice to God with one accord and said: "Lord, You are God, who made heaven and earth and the sea, and all that is in them,

25. who by the mouth of Your servant David have said: "Why did the nations rage, And the people plot vain things?

26. The kings of the earth took their stand, And the rulers were gathered together Against the LORD and against His Christ.'

27. "For truly against Your holy Servant Jesus, whom You anointed, both Herod and Pontius Pilate, with the Gentiles and the people of Israel, were gathered together

28. to do whatever Your hand and Your purpose determined before to be done.

29. Now, Lord, look on their threats, and grant to Your servants that with all boldness they may speak Your word,

30. by stretching out Your hand to heal, and that signs and wonders may be done through the name of Your holy Servant Jesus."

31. And when they had prayed, the place where they were assembled together was shaken; and they were all filled with the Holy Spirit, and they spoke the word of God with boldness.

32. Now the multitude of those who believed were of one heart and one soul; neither did anyone say that any of the things he possessed was his own, but they had all things in common.

33. And with great power the apostles gave witness to the resurrection of the Lord Jesus. And great grace was upon them all.

34. Nor was there anyone among them who lacked; for all who were possessors of lands or houses sold them, and brought the proceeds of the things that were sold,

35. and laid them at the apostles' feet; and they distributed to each as anyone had need.

36. And Joses, who was also named Barnabas by the apostles (which is translated Son of Encouragement), a Levite of the country of Cyprus,

37. having land, sold it, and brought the money and laid it at the apostles' feet.

## Chapter 5

1. But a certain man named Ananias, with Sapphira his wife, sold a possession.

2. And he kept back part of the proceeds, his wife also being aware of it, and brought a certain part and laid it at the apostles' feet.

3. But Peter said, "Ananias, why has Satan filled your heart to lie to the Holy Spirit and keep back part of the price of the land for yourself?

4. While it remained, was it not your own? And after it was sold, was it not in your own control? Why have you conceived this thing in your heart? You have not lied to men but to God."

5. Then Ananias, hearing these words, fell down and breathed his last. So great fear came upon all those who heard these things.

6. And the young men arose and wrapped him up, carried him out, and buried him.

7. Now it was about three hours later when his wife came in, not knowing what had happened.

8. And Peter answered her, "Tell me whether you sold the land for so much?" She said, "Yes, for so much."

9. Then Peter said to her, "How is it that you have agreed together to test the Spirit of the Lord? Look, the feet of those who have buried your husband are at the door, and they will carry you out."

10. Then immediately she fell down at his feet and breathed her last. And the young men came in and found her dead, and carrying her out, buried her by her husband.

11. So great fear came upon all the church and upon all who heard these things.

12. And through the hands of the apostles many signs and wonders were done among the people. And they were all with one accord in Solomon's Porch.

13. Yet none of the rest dared join them, but the people esteemed them highly.

14. And believers were increasingly added to the Lord, multitudes of both men and women,

15. so that they brought the sick out into the streets and laid them on beds and couches, that at least the shadow of Peter passing by might fall on some of them.

16. Also a multitude gathered from the surrounding cities to Jerusalem, bringing sick people and those who were tormented by unclean spirits, and they were all healed.

17. Then the high priest rose up, and all those who were with him (which is the sect of the Sadducees), and they were filled with indignation,

18. and laid their hands on the apostles and put them in the common prison.

19. But at night an angel of the Lord opened the prison doors and brought them out, and said,

20. "Go, stand in the temple and speak to the people all the words of this life."

21. And when they heard that, they entered the temple early in the morning and taught. But the high priest and those with him came and called the council together, with all the elders of the children of Israel, and sent to the prison to have them brought.

22. But when the officers came and did not find them in the prison, they returned and reported,

23. saying, "Indeed we found the prison shut securely, and the guards standing outside before the doors; but when we opened them, we found no one inside!"

24. Now when the high priest, the captain of the temple, and the chief priests heard these things, they wondered what the outcome would be.

25. So one came and told them, saying, "Look, the men whom you put in prison are standing in the temple and teaching the people!"

26. Then the captain went with the officers and brought them without violence, for they feared the people, lest they should be stoned.

27. And when they had brought them, they set them before the council. And the high priest asked them,

28. saying, "Did we not strictly command you not to teach in this name? And look, you have filled Jerusalem with your doctrine, and intend to bring this Man's blood on us!"

29. But Peter and the other apostles answered and said: "We ought to obey God rather than men.

30. The God of our fathers raised up Jesus whom you murdered by hanging on a tree.

31. Him God has exalted to His right hand to be Prince and Savior, to give repentance to Israel and forgiveness of sins.

32. And we are His witnesses to these things, and so also is the Holy Spirit whom God has given to those who obey Him."

33. When they heard this, they were furious and plotted to kill them.

34. Then one in the council stood up, a Pharisee named Gamaliel, a teacher of the law held in respect by all the people, and commanded them to put the apostles outside for a little while.

35. And he said to them: "Men of Israel, take heed to yourselves what you intend to do regarding these men.

36. For some time ago Theudas rose up, claiming to be somebody. A number of men, about four hundred, joined him. He was slain, and all who obeyed him were scattered and came to nothing.

37. After this man, Judas of Galilee rose up in the days of the census, and drew away many people after him. He also perished, and all who obeyed him were dispersed.

38. And now I say to you, keep away from these men and let them alone; for if this plan or this work is of men, it will come to nothing;

39. but if it is of God, you cannot overthrow it--lest you even be found to fight against God."

40. And they agreed with him, and when they had called for the apostles and beaten them, they commanded that they should not speak in the name of Jesus, and let them go.

41. So they departed from the presence of the council, rejoicing that they were counted worthy to suffer shame for His name.

42. And daily in the temple, and in every house, they did not cease teaching and preaching Jesus as the Christ.

## Chapter 6

1. Now in those days, when the number of the disciples was multiplying, there arose a complaint against the Hebrews by the Hellenists, because their widows were neglected in the daily distribution.

2. Then the twelve summoned the multitude of the disciples and said, "It is not desirable that we should leave the word of God and serve tables.

3. Therefore, brethren, seek out from among you seven men of good reputation, full of the Holy Spirit and wisdom, whom we may appoint over this business;

4. but we will give ourselves continually to prayer and to the ministry of the word."

5. And the saying pleased the whole multitude. And they chose Stephen, a man full of faith and the Holy Spirit, and Philip, Prochorus, Nicanor, Timon, Parmenas, and Nicolas, a proselyte from Antioch,

6. whom they set before the apostles; and when they had prayed, they laid hands on them.

7. Then the word of God spread, and the number of the disciples multiplied greatly in Jerusalem, and a great many of the priests were obedient to the faith.

8. And Stephen, full of faith and power, did great wonders and signs among the people.

9. Then there arose some from what is called the Synagogue of the Freedmen (Cyrenians, Alexandrians, and those from Cilicia and Asia), disputing with Stephen.

10. And they were not able to resist the wisdom and the Spirit by which he spoke.

11. Then they secretly induced men to say, "We have heard him speak blasphemous words against Moses and God."

12. And they stirred up the people, the elders, and the scribes; and they came upon him, seized him, and brought him to the council.

13. They also set up false witnesses who said, "This man does not cease to speak blasphemous words against this holy place and the law;

14. for we have heard him say that this Jesus of Nazareth will destroy this place and change the customs which Moses delivered to us."

15. And all who sat in the council, looking steadfastly at him, saw his face as the face of an angel.

## Chapter 7

1. Then the high priest said, "Are these things so?"

2. And he said, "Brethren and fathers, listen: The God of glory appeared to our father Abraham when he was in Mesopotamia, before he dwelt in Haran,

3. and said to him, "Get out of your country and from your relatives, and come to a land that I will show you.'

4. Then he came out of the land of the Chaldeans and dwelt in Haran. And from there, when his father was dead, He moved him to this land in which you now dwell.

5. And God gave him no inheritance in it, not even enough to set his foot on. But even when Abraham had no child, He promised to give it to him for a possession, and to his descendants after him.

6. But God spoke in this way: that his descendants would dwell in a foreign land, and that they would bring them into bondage and oppress them four hundred years.

7. "And the nation to whom they will be in bondage I will judge,' said God, "and after that they shall come out and serve Me in this place.'

8. Then He gave him the covenant of circumcision; and so Abraham begot Isaac and circumcised him on the eighth day; and Isaac begot Jacob, and Jacob begot the twelve patriarchs.

9. "And the patriarchs, becoming envious, sold Joseph into Egypt. But God was with him

10. and delivered him out of all his troubles, and gave him favor and wisdom in the presence of Pharaoh, king of Egypt; and he made him governor over Egypt and all his house.

11. Now a famine and great trouble came over all the land of Egypt and Canaan, and our fathers found no sustenance.

12. But when Jacob heard that there was grain in Egypt, he sent out our fathers first.

13. And the second time Joseph was made known to his brothers, and Joseph's family became known to the Pharaoh.

14. Then Joseph sent and called his father Jacob and all his relatives to him, seventy-five people.

15. So Jacob went down to Egypt; and he died, he and our fathers.

16. And they were carried back to Shechem and laid in the tomb that Abraham bought for a sum of money from the sons of Hamor, the father of Shechem.

17. "But when the time of the promise drew near which God had sworn to Abraham, the people grew and multiplied in Egypt

18. till another king arose who did not know Joseph.

19. This man dealt treacherously with our people, and oppressed our forefathers, making them expose their babies, so that they might not live.

20. At this time Moses was born, and was well pleasing to God; and he was brought up in his father's house for three months.

21. But when he was set out, Pharaoh's daughter took him away and brought him up as her own son.

22. And Moses was learned in all the wisdom of the Egyptians, and was mighty in words and deeds.

23. "Now when he was forty years old, it came into his heart to visit his brethren, the children of Israel.

24. And seeing one of them suffer wrong, he defended and avenged him who was oppressed, and struck down the Egyptian.

25. For he supposed that his brethren would have understood that God would deliver them by his hand, but they did not understand.

26. And the next day he appeared to two of them as they were fighting, and tried to reconcile them, saying, "Men, you are brethren; why do you wrong one another?'

27. But he who did his neighbor wrong pushed him away, saying, "Who made you a ruler and a judge over us?

28. Do you want to kill me as you did the Egyptian yesterday?'

29. Then, at this saying, Moses fled and became a dweller in the land of Midian, where he had two sons.

30. "And when forty years had passed, an Angel of the Lord appeared to him in a flame of fire in a bush, in the wilderness of Mount Sinai.

31. When Moses saw it, he marveled at the sight; and as he drew near to observe, the voice of the Lord came to him,

32. saying, "I am the God of your fathers--the God of Abraham, the God of Isaac, and the God of Jacob.' And Moses trembled and dared not look.

33. "Then the LORD said to him, "Take your sandals off your feet, for the place where you stand is holy ground.

34. I have surely seen the oppression of My people who are in Egypt; I have heard their groaning and have come down to deliver them. And now come, I will send you to Egypt."'

35. "This Moses whom they rejected, saying, "Who made you a ruler and a judge?' is the one God sent to be a ruler and a deliverer by the hand of the Angel who appeared to him in the bush.

36. He brought them out, after he had shown wonders and signs in the land of Egypt, and in the Red Sea, and in the wilderness forty years.

37. "This is that Moses who said to the children of Israel, "The LORD your God will raise up for you a Prophet like me from your brethren. Him you shall hear.'

38. "This is he who was in the congregation in the wilderness with the Angel who spoke to him on Mount Sinai, and with our fathers, the one who received the living oracles to give to us,

39. whom our fathers would not obey, but rejected. And in their hearts they turned back to Egypt,

40. saying to Aaron, "Make us gods to go before us; as for this Moses who brought us out of the land of Egypt, we do not know what has become of him.'

41. And they made a calf in those days, offered sacrifices to the idol, and rejoiced in the works of their own hands.

42. Then God turned and gave them up to worship the host of heaven, as it is written in the book of the Prophets: "Did you offer Me slaughtered animals and sacrifices during forty years in the wilderness, O house of Israel?

43. You also took up the tabernacle of Moloch, And the star of your god Remphan, Images which you made to worship; And I will carry you away beyond Babylon.'

44. "Our fathers had the tabernacle of witness in the wilderness, as He appointed, instructing Moses to make it according to the pattern that he had seen,

45. which our fathers, having received it in turn, also brought with Joshua into the land possessed by the Gentiles, whom God drove out before the face of our fathers until the days of David,

46. who found favor before God and asked to find a dwelling for the God of Jacob.

47. But Solomon built Him a house.

48. "However, the Most High does not dwell in temples made with hands, as the prophet says:

49. "Heaven is My throne, And earth is My footstool. What house will you build for Me? says the LORD, Or what is the place of My rest?

50. Has My hand not made all these things?'

51. "You stiff-necked and uncircumcised in heart and ears! You always resist the Holy Spirit; as your fathers did, so do you.

52. Which of the prophets did your fathers not persecute? And they killed those who foretold the coming of the Just One, of whom you now have become the betrayers and murderers,

53. who have received the law by the direction of angels and have not kept it."

54. When they heard these things they were cut to the heart, and they gnashed at him with their teeth.

55. But he, being full of the Holy Spirit, gazed into heaven and saw the glory of God, and Jesus standing at the right hand of God,

56. and said, "Look! I see the heavens opened and the Son of Man standing at the right hand of God!"

57. Then they cried out with a loud voice, stopped their ears, and ran at him with one accord;

58. and they cast him out of the city and stoned him. And the witnesses laid down their clothes at the feet of a young man named Saul.

59. And they stoned Stephen as he was calling on God and saying, "Lord Jesus, receive my spirit."

60. Then he knelt down and cried out with a loud voice, "Lord, do not charge them with this sin." And when he had said this, he fell asleep.

## Chapter 8

1. Now Saul was consenting to his death. At that time a great persecution arose against the church which was at Jerusalem; and they were all scattered throughout the regions of Judea and Samaria, except the apostles.

2. And devout men carried Stephen to his burial, and made great lamentation over him.

3. As for Saul, he made havoc of the church, entering every house, and dragging off men and women, committing them to prison.

4. Therefore those who were scattered went everywhere preaching the word.

5. Then Philip went down to the city of Samaria and preached Christ to them.

6. And the multitudes with one accord heeded the things spoken by Philip, hearing and seeing the miracles which he did.

7. For unclean spirits, crying with a loud voice, came out of many who were possessed; and many who were paralyzed and lame were healed.

8. And there was great joy in that city.

9. But there was a certain man called Simon, who previously practiced sorcery in the city and astonished the people of Samaria, claiming that he was someone great,

10. to whom they all gave heed, from the least to the greatest, saying, "This man is the great power of God."

11. And they heeded him because he had astonished them with his sorceries for a long time.

12. But when they believed Philip as he preached the things concerning the kingdom of God and the name of Jesus Christ, both men and women were baptized.

13. Then Simon himself also believed; and when he was baptized he continued with Philip, and was amazed, seeing the miracles and signs which were done.

14. Now when the apostles who were at Jerusalem heard that Samaria had received the word of God, they sent Peter and John to them,

15. who, when they had come down, prayed for them that they might receive the Holy Spirit.

16. For as yet He had fallen upon none of them. They had only been baptized in the name of the Lord Jesus.

17. Then they laid hands on them, and they received the Holy Spirit.

18. And when Simon saw that through the laying on of the apostles' hands the Holy Spirit was given, he offered them money,

19. saying, "Give me this power also, that anyone on whom I lay hands may receive the Holy Spirit."

20. But Peter said to him, "Your money perish with you, because you thought that the gift of God could be purchased with money!

21. You have neither part nor portion in this matter, for your heart is not right in the sight of God.

22. Repent therefore of this your wickedness, and pray God if perhaps the thought of your heart may be forgiven you.

23. For I see that you are poisoned by bitterness and bound by iniquity."

24. Then Simon answered and said, "Pray to the Lord for me, that none of the things which you have spoken may come upon me."

25. So when they had testified and preached the word of the Lord, they returned to Jerusalem, preaching the gospel in many villages of the Samaritans.

26. Now an angel of the Lord spoke to Philip, saying, "Arise and go toward the south along the road which goes down from Jerusalem to Gaza." This is desert.

27. So he arose and went. And behold, a man of Ethiopia, a eunuch of great authority under Candace the queen of the Ethiopians, who had charge of all her treasury, and had come to Jerusalem to worship,

28. was returning. And sitting in his chariot, he was reading Isaiah the prophet.

29. Then the Spirit said to Philip, "Go near and overtake this chariot."

30. So Philip ran to him, and heard him reading the prophet Isaiah, and said, "Do you understand what you are reading?"

31. And he said, "How can I, unless someone guides me?" And he asked Philip to come up and sit with him.

32. The place in the Scripture which he read was this: "He was led as a sheep to the slaughter; And as a lamb before its shearer is silent, So He opened not His mouth.

33. In His humiliation His justice was taken away, And who will declare His generation? For His life is taken from the earth."

34. So the eunuch answered Philip and said, "I ask you, of whom does the prophet say this, of himself or of some other man?"

35. Then Philip opened his mouth, and beginning at this Scripture, preached Jesus to him.

36. Now as they went down the road, they came to some water. And the eunuch said, "See, here is water. What hinders me from being baptized?"

37. Then Philip said, "If you believe with all your heart, you may." And he answered and said, "I believe that Jesus Christ is the Son of God."

38. So he commanded the chariot to stand still. And both Philip and the eunuch went down into the water, and he baptized him.

39. Now when they came up out of the water, the Spirit of the Lord caught Philip away, so that the eunuch saw him no more; and he went on his way rejoicing.

40. But Philip was found at Azotus. And passing through, he preached in all the cities till he came to Caesarea.

## Chapter 9

1. Then Saul, still breathing threats and murder against the disciples of the Lord, went to the high priest

2. and asked letters from him to the synagogues of Damascus, so that if he found any who were of the Way, whether men or women, he might bring them bound to Jerusalem.

3. As he journeyed he came near Damascus, and suddenly a light shone around him from heaven.

4. Then he fell to the ground, and heard a voice saying to him, "Saul, Saul, why are you persecuting Me?"

5. And he said, "Who are You, Lord?" Then the Lord said, "I am Jesus, whom you are persecuting. It is hard for you to kick against the goads."

6. So he, trembling and astonished, said, "Lord, what do You want me to do?" Then the Lord said to him, "Arise and go into the city, and you will be told what you must do."

7. And the men who journeyed with him stood speechless, hearing a voice but seeing no one.

8. Then Saul arose from the ground, and when his eyes were opened he saw no one. But they led him by the hand and brought him into Damascus.

9. And he was three days without sight, and neither ate nor drank.

10. Now there was a certain disciple at Damascus named Ananias; and to him the Lord said in a vision, "Ananias." And he said, "Here I am, Lord."

11. So the Lord said to him, "Arise and go to the street called Straight, and inquire at the house of Judas for one called Saul of Tarsus, for behold, he is praying.

12. And in a vision he has seen a man named Ananias coming in and putting his hand on him, so that he might receive his sight."

13. Then Ananias answered, "Lord, I have heard from many about this man, how much harm he has done to Your saints in Jerusalem.

14. And here he has authority from the chief priests to bind all who call on Your name."

15. But the Lord said to him, "Go, for he is a chosen vessel of Mine to bear My name before Gentiles, kings, and the children of Israel.

16. For I will show him how many things he must suffer for My name's sake."

17. And Ananias went his way and entered the house; and laying his hands on him he said, "Brother Saul, the Lord Jesus, who appeared to you on the road as you came, has sent me that you may receive your sight and be filled with the Holy Spirit."

18. Immediately there fell from his eyes something like scales, and he received his sight at once; and he arose and was baptized.

19. So when he had received food, he was strengthened. Then Saul spent some days with the disciples at Damascus.

20. Immediately he preached the Christ in the synagogues, that He is the Son of God.

21. Then all who heard were amazed, and said, "Is this not he who destroyed those who called on this name in Jerusalem, and has come here for that purpose, so that he might bring them bound to the chief priests?"

22. But Saul increased all the more in strength, and confounded the Jews who dwelt in Damascus, proving that this Jesus is the Christ.

23. Now after many days were past, the Jews plotted to kill him.

24. But their plot became known to Saul. And they watched the gates day and night, to kill him.

25. Then the disciples took him by night and let him down through the wall in a large basket.

26. And when Saul had come to Jerusalem, he tried to join the disciples; but they were all afraid of him, and did not believe that he was a disciple.

27. But Barnabas took him and brought him to the apostles. And he declared to them how he had seen the Lord on the road, and that He had spoken to him, and how he had preached boldly at Damascus in the name of Jesus.

28. So he was with them at Jerusalem, coming in and going out.

29. And he spoke boldly in the name of the Lord Jesus and disputed against the Hellenists, but they attempted to kill him.

30. When the brethren found out, they brought him down to Caesarea and sent him out to Tarsus.

31. Then the churches throughout all Judea, Galilee, and Samaria had peace and were edified. And walking in the fear of the Lord and in the comfort of the Holy Spirit, they were multiplied.

32. Now it came to pass, as Peter went through all parts of the country, that he also came down to the saints who dwelt in Lydda.

33. There he found a certain man named Aeneas, who had been bedridden eight years and was paralyzed.

34. And Peter said to him, "Aeneas, Jesus the Christ heals you. Arise and make your bed." Then he arose immediately.

35. So all who dwelt at Lydda and Sharon saw him and turned to the Lord.

36. At Joppa there was a certain disciple named Tabitha, which is translated Dorcas. This woman was full of good works and charitable deeds which she did.

37. But it happened in those days that she became sick and died. When they had washed her, they laid her in an upper room.

38. And since Lydda was near Joppa, and the disciples had heard that Peter was there, they sent two men to him, imploring him not to delay in coming to them.

39. Then Peter arose and went with them. When he had come, they brought him to the upper room. And all the widows stood by him weeping, showing the tunics and garments which Dorcas had made while she was with them.

40. But Peter put them all out, and knelt down and prayed. And turning to the body he said, "Tabitha, arise." And she opened her eyes, and when she saw Peter she sat up.

41. Then he gave her his hand and lifted her up; and when he had called the saints and widows, he presented her alive.

42. And it became known throughout all Joppa, and many believed on the Lord.

43. So it was that he stayed many days in Joppa with Simon, a tanner.

## Chapter 10

1. There was a certain man in Caesarea called Cornelius, a centurion of what was called the Italian Regiment,

2. a devout man and one who feared God with all his household, who gave alms generously to the people, and prayed to God always.

3. About the ninth hour of the day he saw clearly in a vision an angel of God coming in and saying to him, "Cornelius!"

4. And when he observed him, he was afraid, and said, "What is it, lord?" So he said to him, "Your prayers and your alms have come up for a memorial before God.

5. Now send men to Joppa, and send for Simon whose surname is Peter.

6. He is lodging with Simon, a tanner, whose house is by the sea. He will tell you what you must do."

7. And when the angel who spoke to him had departed, Cornelius called two of his household servants and a devout soldier from among those who waited on him continually.

8. So when he had explained all these things to them, he sent them to Joppa.

9. The next day, as they went on their journey and drew near the city, Peter went up on the housetop to pray, about the sixth hour.

10. Then he became very hungry and wanted to eat; but while they made ready, he fell into a trance

11. and saw heaven opened and an object like a great sheet bound at the four corners, descending to him and let down to the earth.

12. In it were all kinds of four-footed animals of the earth, wild beasts, creeping things, and birds of the air.

13. And a voice came to him, "Rise, Peter; kill and eat."

14. But Peter said, "Not so, Lord! For I have never eaten anything common or unclean."

15. And a voice spoke to him again the second time, "What God has cleansed you must not call common."

16. This was done three times. And the object was taken up into heaven again.

17. Now while Peter wondered within himself what this vision which he had seen meant, behold, the men who had been sent from Cornelius had made inquiry for Simon's house, and stood before the gate.

18. And they called and asked whether Simon, whose surname was Peter, was lodging there.

19. While Peter thought about the vision, the Spirit said to him, "Behold, three men are seeking you.

20. Arise therefore, go down and go with them, doubting nothing; for I have sent them."

21. Then Peter went down to the men who had been sent to him from Cornelius, and said, "Yes, I am he whom you seek. For what reason have you come?"

22. And they said, "Cornelius the centurion, a just man, one who fears God and has a good reputation among all the nation of the Jews, was divinely instructed by a holy angel to summon you to his house, and to hear words from you."

23. Then he invited them in and lodged them. On the next day Peter went away with them, and some brethren from Joppa accompanied him.

24. And the following day they entered Caesarea. Now Cornelius was waiting for them, and had called together his relatives and close friends.

25. As Peter was coming in, Cornelius met him and fell down at his feet and worshiped him.

26. But Peter lifted him up, saying, "Stand up; I myself am also a man."

27. And as he talked with him, he went in and found many who had come together.

28. Then he said to them, "You know how unlawful it is for a Jewish man to keep company with or go to one of another nation. But God has shown me that I should not call any man common or unclean.

29. Therefore I came without objection as soon as I was sent for. I ask, then, for what reason have you sent for me?"

30. So Cornelius said, "Four days ago I was fasting until this hour; and at the ninth hour I prayed in my house, and behold, a man stood before me in bright clothing,

31. and said, "Cornelius, your prayer has been heard, and your alms are remembered in the sight of God.

32. Send therefore to Joppa and call Simon here, whose surname is Peter. He is lodging in the house of Simon, a tanner, by the sea. When he comes, he will speak to you.'

33. So I sent to you immediately, and you have done well to come. Now therefore, we are all present before God, to hear all the things commanded you by God."

34. Then Peter opened his mouth and said: "In truth I perceive that God shows no partiality.

35. But in every nation whoever fears Him and works righteousness is accepted by Him.

36. The word which God sent to the children of Israel, preaching peace through Jesus Christ--He is Lord of all--

37. that word you know, which was proclaimed throughout all Judea, and began from Galilee after the baptism which John preached:

38. how God anointed Jesus of Nazareth with the Holy Spirit and with power, who went about doing good and healing all who were oppressed by the devil, for God was with Him.

39. And we are witnesses of all things which He did both in the land of the Jews and in Jerusalem, whom they killed by hanging on a tree.

40. Him God raised up on the third day, and showed Him openly,

41. not to all the people, but to witnesses chosen before by God, even to us who ate and drank with Him after He arose from the dead.

42. And He commanded us to preach to the people, and to testify that it is He who was ordained by God to be Judge of the living and the dead.

43. To Him all the prophets witness that, through His name, whoever believes in Him will receive remission of sins."

44. While Peter was still speaking these words, the Holy Spirit fell upon all those who heard the word.

45. And those of the circumcision who believed were astonished, as many as came with Peter, because the gift of the Holy Spirit had been poured out on the Gentiles also.

46. For they heard them speak with tongues and magnify God. Then Peter answered,

47. "Can anyone forbid water, that these should not be baptized who have received the Holy Spirit just as we have?"

48. And he commanded them to be baptized in the name of the Lord. Then they asked him to stay a few days.

## Chapter 11

1. Now the apostles and brethren who were in Judea heard that the Gentiles had also received the word of God.

2. And when Peter came up to Jerusalem, those of the circumcision contended with him,

3. saying, "You went in to uncircumcised men and ate with them!"

4. But Peter explained it to them in order from the beginning, saying:

5. "I was in the city of Joppa praying; and in a trance I saw a vision, an object descending like a great sheet, let down from heaven by four corners; and it came to me.

6. When I observed it intently and considered, I saw four-footed animals of the earth, wild beasts, creeping things, and birds of the air.

7. And I heard a voice saying to me, "Rise, Peter; kill and eat.'

8. But I said, "Not so, Lord! For nothing common or unclean has at any time entered my mouth.'

9. But the voice answered me again from heaven, "What God has cleansed you must not call common.'

10. Now this was done three times, and all were drawn up again into heaven.

11. At that very moment, three men stood before the house where I was, having been sent to me from Caesarea.

12. Then the Spirit told me to go with them, doubting nothing. Moreover these six brethren accompanied me, and we entered the man's house.

13. And he told us how he had seen an angel standing in his house, who said to him, "Send men to Joppa, and call for Simon whose surname is Peter,

14. who will tell you words by which you and all your household will be saved.'

15. And as I began to speak, the Holy Spirit fell upon them, as upon us at the beginning.

16. Then I remembered the word of the Lord, how He said, "John indeed baptized with water, but you shall be baptized with the Holy Spirit.'

17. If therefore God gave them the same gift as He gave us when we believed on the Lord Jesus Christ, who was I that I could withstand God?"

18. When they heard these things they became silent; and they glorified God, saying, "Then God has also granted to the Gentiles repentance to life."

19. Now those who were scattered after the persecution that arose over Stephen traveled as far as Phoenicia, Cyprus, and Antioch, preaching the word to no one but the Jews only.

20. But some of them were men from Cyprus and Cyrene, who, when they had come to Antioch, spoke to the Hellenists, preaching the Lord Jesus.

21. And the hand of the Lord was with them, and a great number believed and turned to the Lord.

22. Then news of these things came to the ears of the church in Jerusalem, and they sent out Barnabas to go as far as Antioch.

23. When he came and had seen the grace of God, he was glad, and encouraged them all that with purpose of heart they should continue with the Lord.

24. For he was a good man, full of the Holy Spirit and of faith. And a great many people were added to the Lord.

25. Then Barnabas departed for Tarsus to seek Saul.

26. And when he had found him, he brought him to Antioch. So it was that for a whole year they assembled with the church and taught a great many people. And the disciples were first called Christians in Antioch.

27. And in these days prophets came from Jerusalem to Antioch.

28. Then one of them, named Agabus, stood up and showed by the Spirit that there was going to be a great famine throughout all the world, which also happened in the days of Claudius Caesar.

29. Then the disciples, each according to his ability, determined to send relief to the brethren dwelling in Judea.

30. This they also did, and sent it to the elders by the hands of Barnabas and Saul.

## Chapter 12

1. Now about that time Herod the king stretched out his hand to harass some from the church.

2. Then he killed James the brother of John with the sword.

3. And because he saw that it pleased the Jews, he proceeded further to seize Peter also. Now it was during the Days of Unleavened Bread.

4. So when he had arrested him, he put him in prison, and delivered him to four squads of soldiers to keep him, intending to bring him before the people after Passover.

5. Peter was therefore kept in prison, but constant prayer was offered to God for him by the church.

6. And when Herod was about to bring him out, that night Peter was sleeping, bound with two chains between two soldiers; and the guards before the door were keeping the prison.

7. Now behold, an angel of the Lord stood by him, and a light shone in the prison; and he struck Peter on the side and raised him up, saying, "Arise quickly!" And his chains fell off his hands.

8. Then the angel said to him, "Gird yourself and tie on your sandals"; and so he did. And he said to him, "Put on your garment and follow me."

9. So he went out and followed him, and did not know that what was done by the angel was real, but thought he was seeing a vision.

10. When they were past the first and the second guard posts, they came to the iron gate that leads to the city, which opened to them of its own accord; and they went out and went down one street, and immediately the angel departed from him.

11. And when Peter had come to himself, he said, "Now I know for certain that the Lord has sent His angel, and has delivered me from the hand of Herod and from all the expectation of the Jewish people."

12. So, when he had considered this, he came to the house of Mary, the mother of John whose surname was Mark, where many were gathered together praying.

13. And as Peter knocked at the door of the gate, a girl named Rhoda came to answer.

14. When she recognized Peter's voice, because of her gladness she did not open the gate, but ran in and announced that Peter stood before the gate.

15. But they said to her, "You are beside yourself!" Yet she kept insisting that it was so. So they said, "It is his angel."

16. Now Peter continued knocking; and when they opened the door and saw him, they were astonished.

17. But motioning to them with his hand to keep silent, he declared to them how the Lord had brought him out of the prison. And he said, "Go, tell these things to James and to the brethren." And he departed and went to another place.

18. Then, as soon as it was day, there was no small stir among the soldiers about what had become of Peter.

19. But when Herod had searched for him and not found him, he examined the guards and commanded that they should be put to death. And he went down from Judea to Caesarea, and stayed there.

20. Now Herod had been very angry with the people of Tyre and Sidon; but they came to him with one accord, and having made Blastus the king's personal aide their friend, they asked for peace, because their country was supplied with food by the king's country.

21. So on a set day Herod, arrayed in royal apparel, sat on his throne and gave an oration to them.

22. And the people kept shouting, "The voice of a god and not of a man!"

23. Then immediately an angel of the Lord struck him, because he did not give glory to God. And he was eaten by worms and died.

24. But the word of God grew and multiplied.

25. And Barnabas and Saul returned from Jerusalem when they had fulfilled their ministry, and they also took with them John whose surname was Mark.

## Chapter 13

1. Now in the church that was at Antioch there were certain prophets and teachers: Barnabas, Simeon who was called Niger, Lucius of Cyrene, Manaen who had been brought up with Herod the tetrarch, and Saul.

2. As they ministered to the Lord and fasted, the Holy Spirit said, "Now separate to Me Barnabas and Saul for the work to which I have called them."

3. Then, having fasted and prayed, and laid hands on them, they sent them away.

4. So, being sent out by the Holy Spirit, they went down to Seleucia, and from there they sailed to Cyprus.

5. And when they arrived in Salamis, they preached the word of God in the synagogues of the Jews. They also had John as their assistant.

6. Now when they had gone through the island to Paphos, they found a certain sorcerer, a false prophet, a Jew whose name was Bar-Jesus,

7. who was with the proconsul, Sergius Paulus, an intelligent man. This man called for Barnabas and Saul and sought to hear the word of God.

8. But Elymas the sorcerer (for so his name is translated) withstood them, seeking to turn the proconsul away from the faith.

9. Then Saul, who also is called Paul, filled with the Holy Spirit, looked intently at him

10. and said, "O full of all deceit and all fraud, you son of the devil, you enemy of all righteousness, will you not cease perverting the straight ways of the Lord?

11. And now, indeed, the hand of the Lord is upon you, and you shall be blind, not seeing the sun for a time." And immediately a dark mist fell on him, and he went around seeking someone to lead him by the hand.

12. Then the proconsul believed, when he saw what had been done, being astonished at the teaching of the Lord.

13. Now when Paul and his party set sail from Paphos, they came to Perga in Pamphylia; and John, departing from them, returned to Jerusalem.

14. But when they departed from Perga, they came to Antioch in Pisidia, and went into the synagogue on the Sabbath day and sat down.

15. And after the reading of the Law and the Prophets, the rulers of the synagogue sent to them, saying, "Men and brethren, if you have any word of exhortation for the people, say on."

16. Then Paul stood up, and motioning with his hand said, "Men of Israel, and you who fear God, listen:

17. The God of this people Israel chose our fathers, and exalted the people when they dwelt as strangers in the land of Egypt, and with an uplifted arm He brought them out of it.

18. Now for a time of about forty years He put up with their ways in the wilderness.

19. And when He had destroyed seven nations in the land of Canaan, He distributed their land to them by allotment.

20. "After that He gave them judges for about four hundred and fifty years, until Samuel the prophet.

21. And afterward they asked for a king; so God gave them Saul the son of Kish, a man of the tribe of Benjamin, for forty years.

22. And when He had removed him, He raised up for them David as king, to whom also He gave testimony and said, "I have found David the son of Jesse, a man after My own heart, who will do all My will.'

23. From this man's seed, according to the promise, God raised up for Israel a Savior--Jesus--

24. after John had first preached, before His coming, the baptism of repentance to all the people of Israel.

25. And as John was finishing his course, he said, "Who do you think I am? I am not He. But behold, there comes One after me, the sandals of whose feet I am not worthy to loose.'

26. "Men and brethren, sons of the family of Abraham, and those among you who fear God, to you the word of this salvation has been sent.

27. For those who dwell in Jerusalem, and their rulers, because they did not know Him, nor even the voices of the Prophets which are read every Sabbath, have fulfilled them in condemning Him.

28. And though they found no cause for death in Him, they asked Pilate that He should be put to death.

29. Now when they had fulfilled all that was written concerning Him, they took Him down from the tree and laid Him in a tomb.

30. But God raised Him from the dead.

31. He was seen for many days by those who came up with Him from Galilee to Jerusalem, who are His witnesses to the people.

32. And we declare to you glad tidings--that promise which was made to the fathers.

33. God has fulfilled this for us their children, in that He has raised up Jesus. As it is also written in the second Psalm: "You are My Son, Today I have begotten You.'

34. And that He raised Him from the dead, no more to return to corruption, He has spoken thus: "I will give you the sure mercies of David.'

35. Therefore He also says in another Psalm: "You will not allow Your Holy One to see corruption.'

36. "For David, after he had served his own generation by the will of God, fell asleep, was buried with his fathers, and saw corruption;

37. but He whom God raised up saw no corruption.

38. Therefore let it be known to you, brethren, that through this Man is preached to you the forgiveness of sins;

39. and by Him everyone who believes is justified from all things from which you could not be justified by the law of Moses.

40. Beware therefore, lest what has been spoken in the prophets come upon you:

41. "Behold, you despisers, Marvel and perish! For I work a work in your days, A work which you will by no means believe, Though one were to declare it to you."'

42. So when the Jews went out of the synagogue, the Gentiles begged that these words might be preached to them the next Sabbath.

43. Now when the congregation had broken up, many of the Jews and devout proselytes followed Paul and Barnabas, who, speaking to them, persuaded them to continue in the grace of God.

44. On the next Sabbath almost the whole city came together to hear the word of God.

45. But when the Jews saw the multitudes, they were filled with envy; and contradicting and blaspheming, they opposed the things spoken by Paul.

46. Then Paul and Barnabas grew bold and said, "It was necessary that the word of God should be spoken to you first; but since you reject it, and judge yourselves unworthy of everlasting life, behold, we turn to the Gentiles.

47. For so the Lord has commanded us: "I have set you as a light to the Gentiles, That you should be for salvation to the ends of the earth."'

48. Now when the Gentiles heard this, they were glad and glorified the word of the Lord. And as many as had been appointed to eternal life believed.

49. And the word of the Lord was being spread throughout all the region.

50. But the Jews stirred up the devout and prominent women and the chief men of the city, raised up persecution against Paul and Barnabas, and expelled them from their region.

51. But they shook off the dust from their feet against them, and came to Iconium.

52. And the disciples were filled with joy and with the Holy Spirit.

## Chapter 14

1. Now it happened in Iconium that they went together to the synagogue of the Jews, and so spoke that a great multitude both of the Jews and of the Greeks believed.

2. But the unbelieving Jews stirred up the Gentiles and poisoned their minds against the brethren.

3. Therefore they stayed there a long time, speaking boldly in the Lord, who was bearing witness to the word of His grace, granting signs and wonders to be done by their hands.

4. But the multitude of the city was divided: part sided with the Jews, and part with the apostles.

5. And when a violent attempt was made by both the Gentiles and Jews, with their rulers, to abuse and stone them,

6. they became aware of it and fled to Lystra and Derbe, cities of Lycaonia, and to the surrounding region.

7. And they were preaching the gospel there.

8. And in Lystra a certain man without strength in his feet was sitting, a cripple from his mother's womb, who had never walked.

9. This man heard Paul speaking. Paul, observing him intently and seeing that he had faith to be healed,

10. said with a loud voice, "Stand up straight on your feet!" And he leaped and walked.

11. Now when the people saw what Paul had done, they raised their voices, saying in the Lycaonian language, "The gods have come down to us in the likeness of men!"

12. And Barnabas they called Zeus, and Paul, Hermes, because he was the chief speaker.

13. Then the priest of Zeus, whose temple was in front of their city, brought oxen and garlands to the gates, intending to sacrifice with the multitudes.

14. But when the apostles Barnabas and Paul heard this, they tore their clothes and ran in among the multitude, crying out

15. and saying, "Men, why are you doing these things? We also are men with the same nature as you, and preach to you that you should turn from these useless things to the living God, who made the heaven, the earth, the sea, and all things that are in them,

16. who in bygone generations allowed all nations to walk in their own ways.

17. Nevertheless He did not leave Himself without witness, in that He did good, gave us rain from heaven and fruitful seasons, filling our hearts with food and gladness."

18. And with these sayings they could scarcely restrain the multitudes from sacrificing to them.

19. Then Jews from Antioch and Iconium came there; and having persuaded the multitudes, they stoned Paul and dragged him out of the city, supposing him to be dead.

20. However, when the disciples gathered around him, he rose up and went into the city. And the next day he departed with Barnabas to Derbe.

21. And when they had preached the gospel to that city and made many disciples, they returned to Lystra, Iconium, and Antioch,

22. strengthening the souls of the disciples, exhorting them to continue in the faith, and saying, "We must through many tribulations enter the kingdom of God."

23. So when they had appointed elders in every church, and prayed with fasting, they commended them to the Lord in whom they had believed.

24. And after they had passed through Pisidia, they came to Pamphylia.

25. Now when they had preached the word in Perga, they went down to Attalia.

26. From there they sailed to Antioch, where they had been commended to the grace of God for the work which they had completed.

27. Now when they had come and gathered the church together, they reported all that God had done with them, and that He had opened the door of faith to the Gentiles.

28. So they stayed there a long time with the disciples.

## Chapter 15

1. And certain men came down from Judea and taught the brethren, "Unless you are circumcised according to the custom of Moses, you cannot be saved."

2. Therefore, when Paul and Barnabas had no small dissension and dispute with them, they determined that Paul and Barnabas and certain others of them should go up to Jerusalem, to the apostles and elders, about this question.

3. So, being sent on their way by the church, they passed through Phoenicia and Samaria, describing the conversion of the Gentiles; and they caused great joy to all the brethren.

4. And when they had come to Jerusalem, they were received by the church and the apostles and the elders; and they reported all things that God had done with them.

5. But some of the sect of the Pharisees who believed rose up, saying, "It is necessary to circumcise them, and to command them to keep the law of Moses."

6. Now the apostles and elders came together to consider this matter.

7. And when there had been much dispute, Peter rose up and said to them: "Men and brethren, you know that a good while ago God chose among us, that by my mouth the Gentiles should hear the word of the gospel and believe.

8. So God, who knows the heart, acknowledged them by giving them the Holy Spirit, just as He did to us,

9. and made no distinction between us and them, purifying their hearts by faith.

10. Now therefore, why do you test God by putting a yoke on the neck of the disciples which neither our fathers nor we were able to bear?

11. But we believe that through the grace of the Lord Jesus Christ we shall be saved in the same manner as they."

12. Then all the multitude kept silent and listened to Barnabas and Paul declaring how many miracles and wonders God had worked through them among the Gentiles.

13. And after they had become silent, James answered, saying, "Men and brethren, listen to me:

14. Simon has declared how God at the first visited the Gentiles to take out of them a people for His name.

15. And with this the words of the prophets agree, just as it is written:

16. 'After this I will return And will rebuild the tabernacle of David, which has fallen down; I will rebuild its ruins, And I will set it up;

17. So that the rest of mankind may seek the LORD. Even all the Gentiles who are called by My name, Says the LORD who does all these things.'

18. "Known to God from eternity are all His works.

19. Therefore I judge that we should not trouble those from among the Gentiles who are turning to God,

20. but that we write to them to abstain from things polluted by idols, from sexual immorality, from things strangled, and from blood.

21. For Moses has had throughout many generations those who preach him in every city, being read in the synagogues every Sabbath."

22. Then it pleased the apostles and elders, with the whole church, to send chosen men of their own company to Antioch with Paul and Barnabas, namely, Judas who was also named Barsabas, and Silas, leading men among the brethren.

23. They wrote this, letter by them: The apostles, the elders, and the brethren, To the brethren who are of the Gentiles in Antioch, Syria, and Cilicia: Greetings.

24. Since we have heard that some who went out from us have troubled you with words, unsettling your souls, saying, "You must be circumcised and keep the law"--to whom we gave no such commandment--

25. it seemed good to us, being assembled with one accord, to send chosen men to you with our beloved Barnabas and Paul,

26. men who have risked their lives for the name of our Lord Jesus Christ.

27. We have therefore sent Judas and Silas, who will also report the same things by word of mouth.

28. For it seemed good to the Holy Spirit, and to us, to lay upon you no greater burden than these necessary things:

29. that you abstain from things offered to idols, from blood, from things strangled, and from sexual immorality. If you keep yourselves from these, you will do well. Farewell.

30. So when they were sent off, they came to Antioch; and when they had gathered the multitude together, they delivered the letter.

31. When they had read it, they rejoiced over its encouragement.

32. Now Judas and Silas, themselves being prophets also, exhorted and strengthened the brethren with many words.

33. And after they had stayed there for a time, they were sent back with greetings from the brethren to the apostles.

34. However, it seemed good to Silas to remain there.

35. Paul and Barnabas also remained in Antioch, teaching and preaching the word of the Lord, with many others also.

36. Then after some days Paul said to Barnabas, "Let us now go back and visit our brethren in every city where we have preached the word of the Lord, and see how they are doing."

37. Now Barnabas was determined to take with them John called Mark.

38. But Paul insisted that they should not take with them the one who had departed from them in Pamphylia, and had not gone with them to the work.

39. Then the contention became so sharp that they parted from one another. And so Barnabas took Mark and sailed to Cyprus;

40. but Paul chose Silas and departed, being commended by the brethren to the grace of God.

41. And he went through Syria and Cilicia, strengthening the churches.

## Chapter 16

1. Then he came to Derbe and Lystra. And behold, a certain disciple was there, named Timothy, the son of a certain Jewish woman who believed, but his father was Greek.

2. He was well spoken of by the brethren who were at Lystra and Iconium.

3. Paul wanted to have him go on with him. And he took him and circumcised him because of the Jews who were in that region, for they all knew that his father was Greek.

4. And as they went through the cities, they delivered to them the decrees to keep, which were determined by the apostles and elders at Jerusalem.

5. So the churches were strengthened in the faith, and increased in number daily.

6. Now when they had gone through Phrygia and the region of Galatia, they were forbidden by the Holy Spirit to preach the word in Asia.

7. After they had come to Mysia, they tried to go into Bithynia, but the Spirit did not permit them.

8. So passing by Mysia, they came down to Troas.

9. And a vision appeared to Paul in the night. A man of Macedonia stood and pleaded with him, saying, "Come over to Macedonia and help us."

10. Now after he had seen the vision, immediately we sought to go to Macedonia, concluding that the Lord had called us to preach the gospel to them.

11. Therefore, sailing from Troas, we ran a straight course to Samothrace, and the next day came to Neapolis,

12. and from there to Philippi, which is the foremost city of that part of Macedonia, a colony. And we were staying in that city for some days.

13. And on the Sabbath day we went out of the city to the riverside, where prayer was customarily made; and we sat down and spoke to the women who met there.

14. Now a certain woman named Lydia heard us. She was a seller of purple from the city of Thyatira, who worshiped God. The Lord opened her heart to heed the things spoken by Paul.

15. And when she and her household were baptized, she begged us, saying, "If you have judged me to be faithful to the Lord, come to my house and stay." So she persuaded us.

16. Now it happened, as we went to prayer, that a certain slave girl possessed with a spirit of divination met us, who brought her masters much profit by fortune-telling.

17. This girl followed Paul and us, and cried out, saying, "These men are the servants of the Most High God, who proclaim to us the way of salvation."

18. And this she did for many days. But Paul, greatly annoyed, turned and said to the spirit, "I command you in the name of Jesus Christ to come out of her." And he came out that very hour.

19. But when her masters saw that their hope of profit was gone, they seized Paul and Silas and dragged them into the marketplace to the authorities.

20. And they brought them to the magistrates, and said, "These men, being Jews, exceedingly trouble our city;

21. and they teach customs which are not lawful for us, being Romans, to receive or observe."

22. Then the multitude rose up together against them; and the magistrates tore off their clothes and commanded them to be beaten with rods.

23. And when they had laid many stripes on them, they threw them into prison, commanding the jailer to keep them securely.

24. Having received such a charge, he put them into the inner prison and fastened their feet in the stocks.

25. But at midnight Paul and Silas were praying and singing hymns to God, and the prisoners were listening to them.

26. Suddenly there was a great earthquake, so that the foundations of the prison were shaken; and immediately all the doors were opened and everyone's chains were loosed.

27. And the keeper of the prison, awaking from sleep and seeing the prison doors open, supposing the prisoners had fled, drew his sword and was about to kill himself.

28. But Paul called with a loud voice, saying, "Do yourself no harm, for we are all here."

29. Then he called for a light, ran in, and fell down trembling before Paul and Silas.

30. And he brought them out and said, "Sirs, what must I do to be saved?"

31. So they said, "Believe on the Lord Jesus Christ, and you will be saved, you and your household."

32. Then they spoke the word of the Lord to him and to all who were in his house.

33. And he took them the same hour of the night and washed their stripes. And immediately he and all his family were baptized.

34. Now when he had brought them into his house, he set food before them; and he rejoiced, having believed in God with all his household.

35. And when it was day, the magistrates sent the officers, saying, "Let those men go."

36. So the keeper of the prison reported these words to Paul, saying, "The magistrates have sent to let you go. Now therefore depart, and go in peace."

37. But Paul said to them, "They have beaten us openly, uncondemned Romans, and have thrown us into prison. And now do they put us out secretly? No indeed! Let them come themselves and get us out."

38. And the officers told these words to the magistrates, and they were afraid when they heard that they were Romans.

39. Then they came and pleaded with them and brought them out, and asked them to depart from the city.

40. So they went out of the prison and entered the house of Lydia; and when they had seen the brethren, they encouraged them and departed.

## Chapter 17

1. Now when they had passed through Amphipolis and Apollonia, they came to Thessalonica, where there was a synagogue of the Jews.

2. Then Paul, as his custom was, went in to them, and for three Sabbaths reasoned with them from the Scriptures,

3. explaining and demonstrating that the Christ had to suffer and rise again from the dead, and saying, "This Jesus whom I preach to you is the Christ."

4. And some of them were persuaded; and a great multitude of the devout Greeks, and not a few of the leading women, joined Paul and Silas.

5. But the Jews who were not persuaded, becoming envious, took some of the evil men from the marketplace, and gathering a mob, set all the city in an uproar and attacked the house of Jason, and sought to bring them out to the people.

6. But when they did not find them, they dragged Jason and some brethren to the rulers of the city, crying out, "These who have turned the world upside down have come here too.

7. Jason has harbored them, and these are all acting contrary to the decrees of Caesar, saying there is another king--Jesus."

8. And they troubled the crowd and the rulers of the city when they heard these things.

9. So when they had taken security from Jason and the rest, they let them go.

10. Then the brethren immediately sent Paul and Silas away by night to Berea. When they arrived, they went into the synagogue of the Jews.

11. These were more fair-minded than those in Thessalonica, in that they received the word with all readiness, and searched the Scriptures daily to find out whether these things were so.

12. Therefore many of them believed, and also not a few of the Greeks, prominent women as well as men.

13. But when the Jews from Thessalonica learned that the word of God was preached by Paul at Berea, they came there also and stirred up the crowds.

14. Then immediately the brethren sent Paul away, to go to the sea; but both Silas and Timothy remained there.

15. So those who conducted Paul brought him to Athens; and receiving a command for Silas and Timothy to come to him with all speed, they departed.

16. Now while Paul waited for them at Athens, his spirit was provoked within him when he saw that the city was given over to idols.

17. Therefore he reasoned in the synagogue with the Jews and with the Gentile worshipers, and in the marketplace daily with those who happened to be there.

18. Then certain Epicurean and Stoic philosophers encountered him. And some said, "What does this babbler want to say?" Others said, "He seems to be a proclaimer of foreign gods," because he preached to them Jesus and the resurrection.

19. And they took him and brought him to the Areopagus, saying, "May we know what this new doctrine is of which you speak?

20. For you are bringing some strange things to our ears. Therefore we want to know what these things mean."

21. For all the Athenians and the foreigners who were there spent their time in nothing else but either to tell or to hear some new thing.

22. Then Paul stood in the midst of the Areopagus and said, "Men of Athens, I perceive that in all things you are very religious;

23. for as I was passing through and considering the objects of your worship, I even found an altar with this inscription: TO THE UNKNOWN GOD. Therefore, the One whom you worship without knowing, Him I proclaim to you:

24. God, who made the world and everything in it, since He is Lord of heaven and earth, does not dwell in temples made with hands.

25. Nor is He worshiped with men's hands, as though He needed anything, since He gives to all life, breath, and all things.

26. And He has made from one blood every nation of men to dwell on all the face of the earth, and has determined their preappointed times and the boundaries of their dwellings,

27. so that they should seek the Lord, in the hope that they might grope for Him and find Him, though He is not far from each one of us;

28. for in Him we live and move and have our being, as also some of your own poets have said, "For we are also His offspring.'

29. Therefore, since we are the offspring of God, we ought not to think that the Divine Nature is like gold or silver or stone, something shaped by art and man's devising.

30. Truly, these times of ignorance God overlooked, but now commands all men everywhere to repent,

31. because He has appointed a day on which He will judge the world in righteousness by the Man whom He has ordained. He has given assurance of this to all by raising Him from the dead."

32. And when they heard of the resurrection of the dead, some mocked, while others said, "We will hear you again on this matter."

33. So Paul departed from among them.

34. However, some men joined him and believed, among them Dionysius the Areopagite, a woman named Damaris, and others with them.

## Chapter 18

1. After these things Paul departed from Athens and went to Corinth.

2. And he found a certain Jew named Aquila, born in Pontus, who had recently come from Italy with his wife Priscilla (because Claudius had commanded all the Jews to depart from Rome); and he came to them.

3. So, because he was of the same trade, he stayed with them and worked; for by occupation they were tentmakers.

4. And he reasoned in the synagogue every Sabbath, and persuaded both Jews and Greeks.

5. When Silas and Timothy had come from Macedonia, Paul was compelled by the Spirit, and testified to the Jews that Jesus is the Christ.

6. But when they opposed him and blasphemed, he shook his garments and said to them, "Your blood be upon your own heads; I am clean. From now on I will go to the Gentiles."

7. And he departed from there and entered the house of a certain man named Justus, one who worshiped God, whose house was next door to the synagogue.

8. Then Crispus, the ruler of the synagogue, believed on the Lord with all his household. And many of the Corinthians, hearing, believed and were baptized.

9. Now the Lord spoke to Paul in the night by a vision, "Do not be afraid, but speak, and do not keep silent;

10. for I am with you, and no one will attack you to hurt you; for I have many people in this city."

11. And he continued there a year and six months, teaching the word of God among them.

12. When Gallio was proconsul of Achaia, the Jews with one accord rose up against Paul and brought him to the judgment seat,

13. saying, "This fellow persuades men to worship God contrary to the law."

14. And when Paul was about to open his mouth, Gallio said to the Jews, "If it were a matter of wrongdoing or wicked crimes, O Jews, there would be reason why I should bear with you.

15. But if it is a question of words and names and your own law, look to it yourselves; for I do not want to be a judge of such matters."

16. And he drove them from the judgment seat.

17. Then all the Greeks took Sosthenes, the ruler of the synagogue, and beat him before the judgment seat. But Gallio took no notice of these things.

18. So Paul still remained a good while. Then he took leave of the brethren and sailed for Syria, and Priscilla and Aquila were with him. He had his hair cut off at Cenchrea, for he had taken a vow.

19. And he came to Ephesus, and left them there; but he himself entered the synagogue and reasoned with the Jews.

20. When they asked him to stay a longer time with them, he did not consent,

21. but took leave of them, saying, "I must by all means keep this coming feast in Jerusalem; but I will return again to you, God willing." And he sailed from Ephesus.

22. And when he had landed at Caesarea, and gone up and greeted the church, he went down to Antioch.

23. After he had spent some time there, he departed and went over the region of Galatia and Phrygia in order, strengthening all the disciples.

24. Now a certain Jew named Apollos, born at Alexandria, an eloquent man and mighty in the Scriptures, came to Ephesus.

25. This man had been instructed in the way of the Lord; and being fervent in spirit, he spoke and taught accurately the things of the Lord, though he knew only the baptism of John.

26. So he began to speak boldly in the synagogue. When Aquila and Priscilla heard him, they took him aside and explained to him the way of God more accurately.

27. And when he desired to cross to Achaia, the brethren wrote, exhorting the disciples to receive him; and when he arrived, he greatly helped those who had believed through grace;

28. for he vigorously refuted the Jews publicly, showing from the Scriptures that Jesus is the Christ.

## Chapter 19

1. And it happened, while Apollos was at Corinth, that Paul, having passed through the upper regions, came to Ephesus. And finding some disciples

2. he said to them, "Did you receive the Holy Spirit when you believed?" So they said to him, "We have not so much as heard whether there is a Holy Spirit."

3. And he said to them, "Into what then were you baptized?" So they said, "Into John's baptism."

4. Then Paul said, "John indeed baptized with a baptism of repentance, saying to the people that they should believe on Him who would come after him, that is, on Christ Jesus."

5. When they heard this, they were baptized in the name of the Lord Jesus.

6. And when Paul had laid hands on them, the Holy Spirit came upon them, and they spoke with tongues and prophesied.

7. Now the men were about twelve in all.

8. And he went into the synagogue and spoke boldly for three months, reasoning and persuading concerning the things of the kingdom of God.

9. But when some were hardened and did not believe, but spoke evil of the Way before the multitude, he departed from them and withdrew the disciples, reasoning daily in the school of Tyrannus.

10. And this continued for two years, so that all who dwelt in Asia heard the word of the Lord Jesus, both Jews and Greeks.

11. Now God worked unusual miracles by the hands of Paul,

12. so that even handkerchiefs or aprons were brought from his body to the sick, and the diseases left them and the evil spirits went out of them.

13. Then some of the itinerant Jewish exorcists took it upon themselves to call the name of the Lord Jesus over those who had evil spirits, saying, "We exorcise you by the Jesus whom Paul preaches."

14. Also there were seven sons of Sceva, a Jewish chief priest, who did so.

15. And the evil spirit answered and said, "Jesus I know, and Paul I know; but who are you?"

16. Then the man in whom the evil spirit was leaped on them, overpowered them, and prevailed against them, so that they fled out of that house naked and wounded.

17. This became known both to all Jews and Greeks dwelling in Ephesus; and fear fell on them all, and the name of the Lord Jesus was magnified.

18. And many who had believed came confessing and telling their deeds.

19. Also, many of those who had practiced magic brought their books together and burned them in the sight of all. And they counted up the value of them, and it totaled fifty thousand pieces of silver.

20. So the word of the Lord grew mightily and prevailed.

21. When these things were accomplished, Paul purposed in the Spirit, when he had passed through Macedonia and Achaia, to go to Jerusalem, saying, "After I have been there, I must also see Rome."

22. So he sent into Macedonia two of those who ministered to him, Timothy and Erastus, but he himself stayed in Asia for a time.

23. And about that time there arose a great commotion about the Way.

24. For a certain man named Demetrius, a silversmith, who made silver shrines of Diana, brought no small profit to the craftsmen.

25. He called them together with the workers of similar occupation, and said: "Men, you know that we have our prosperity by this trade.

26. Moreover you see and hear that not only at Ephesus, but throughout almost all Asia, this Paul has persuaded and turned away many people, saying that they are not gods which are made with hands.

27. So not only is this trade of ours in danger of falling into disrepute, but also the temple of the great goddess Diana may be despised and her magnificence destroyed, whom all Asia and the world worship."

28. Now when they heard this, they were full of wrath and cried out, saying, "Great is Diana of the Ephesians!"

29. So the whole city was filled with confusion, and rushed into the theater with one accord, having seized Gaius and Aristarchus, Macedonians, Paul's travel companions.

30. And when Paul wanted to go in to the people, the disciples would not allow him.

31. Then some of the officials of Asia, who were his friends, sent to him pleading that he would not venture into the theater.

32. Some therefore cried one thing and some another, for the assembly was confused, and most of them did not know why they had come together.

33. And they drew Alexander out of the multitude, the Jews putting him forward. And Alexander motioned with his hand, and wanted to make his defense to the people.

34. But when they found out that he was a Jew, all with one voice cried out for about two hours, "Great is Diana of the Ephesians!"

35. And when the city clerk had quieted the crowd, he said: "Men of Ephesus, what man is there who does not know that the city of the Ephesians is temple guardian of the great goddess Diana, and of the image which fell down from Zeus?

36. Therefore, since these things cannot be denied, you ought to be quiet and do nothing rashly.

37. For you have brought these men here who are neither robbers of temples nor blasphemers of your goddess.

38. Therefore, if Demetrius and his fellow craftsmen have a case against anyone, the courts are open and there are proconsuls. Let them bring charges against one another.

39. But if you have any other inquiry to make, it shall be determined in the lawful assembly.

40. For we are in danger of being called in question for today's uproar, there being no reason which we may give to account for this disorderly gathering."

41. And when he had said these things, he dismissed the assembly.

## Chapter 20

1. After the uproar had ceased, Paul called the disciples to himself, embraced them, and departed to go to Macedonia.

2. Now when he had gone over that region and encouraged them with many words, he came to Greece

3. and stayed three months. And when the Jews plotted against him as he was about to sail to Syria, he decided to return through Macedonia.

4. And Sopater of Berea accompanied him to Asia--also Aristarchus and Secundus of the Thessalonians, and Gaius of Derbe, and Timothy, and Tychicus and Trophimus of Asia.

5. These men, going ahead, waited for us at Troas.

6. But we sailed away from Philippi after the Days of Unleavened Bread, and in five days joined them at Troas, where we stayed seven days.

7. Now on the first day of the week, when the disciples came together to break bread, Paul, ready to depart the next day, spoke to them and continued his message until midnight.

8. There were many lamps in the upper room where they were gathered together.

9. And in a window sat a certain young man named Eutychus, who was sinking into a deep sleep. He was overcome by sleep; and as Paul continued speaking, he fell down from the third story and was taken up dead.

10. But Paul went down, fell on him, and embracing him said, "Do not trouble yourselves, for his life is in him."

11. Now when he had come up, had broken bread and eaten, and talked a long while, even till daybreak, he departed.

12. And they brought the young man in alive, and they were not a little comforted.

13. Then we went ahead to the ship and sailed to Assos, there intending to take Paul on board; for so he had given orders, intending himself to go on foot.

14. And when he met us at Assos, we took him on board and came to Mitylene.

15. We sailed from there, and the next day came opposite Chios. The following day we arrived at Samos and stayed at Trogyllium. The next day we came to Miletus.

16. For Paul had decided to sail past Ephesus, so that he would not have to spend time in Asia; for he was hurrying to be at Jerusalem, if possible, on the Day of Pentecost.

17. From Miletus he sent to Ephesus and called for the elders of the church.

18. And when they had come to him, he said to them: "You know, from the first day that I came to Asia, in what manner I always lived among you,

19. serving the Lord with all humility, with many tears and trials which happened to me by the plotting of the Jews;

20. how I kept back nothing that was helpful, but proclaimed it to you, and taught you publicly and from house to house,

21. testifying to Jews, and also to Greeks, repentance toward God and faith toward our Lord Jesus Christ.

22. And see, now I go bound in the spirit to Jerusalem, not knowing the things that will happen to me there,

23. except that the Holy Spirit testifies in every city, saying that chains and tribulations await me.

24. But none of these things move me; nor do I count my life dear to myself, so that I may finish my race with joy, and the ministry which I received from the Lord Jesus, to testify to the gospel of the grace of God.

25. "And indeed, now I know that you all, among whom I have gone preaching the kingdom of God, will see my face no more.

26. Therefore I testify to you this day that I am innocent of the blood of all men.

27. For I have not shunned to declare to you the whole counsel of God.

28. Therefore take heed to yourselves and to all the flock, among which the Holy Spirit has made you overseers, to shepherd the church of God which He purchased with His own blood.

29. For I know this, that after my departure savage wolves will come in among you, not sparing the flock.

30. Also from among yourselves men will rise up, speaking perverse things, to draw away the disciples after themselves.

31. Therefore watch, and remember that for three years I did not cease to warn everyone night and day with tears.

32. "So now, brethren, I commend you to God and to the word of His grace, which is able to build you up and give you an inheritance among all those who are sanctified.

33. I have coveted no one's silver or gold or apparel.

34. Yes, you yourselves know that these hands have provided for my necessities, and for those who were with me.

35. I have shown you in every way, by laboring like this, that you must support the weak. And remember the words of the Lord Jesus, that He said, "It is more blessed to give than to receive."'

36. And when he had said these things, he knelt down and prayed with them all.

37. Then they all wept freely, and fell on Paul's neck and kissed him,

38. sorrowing most of all for the words which he spoke, that they would see his face no more. And they accompanied him to the ship.

## Chapter 21

1. Now it came to pass, that when we had departed from them and set sail, running a straight course we came to Cos, the following day to Rhodes, and from there to Patara.

2. And finding a ship sailing over to Phoenicia, we went aboard and set sail.

3. When we had sighted Cyprus, we passed it on the left, sailed to Syria, and landed at Tyre; for there the ship was to unload her cargo.

4. And finding disciples, we stayed there seven days. They told Paul through the Spirit not to go up to Jerusalem.

5. When we had come to the end of those days, we departed and went on our way; and they all accompanied us, with wives and children, till we were out of the city. And we knelt down on the shore and prayed.

6. When we had taken our leave of one another, we boarded the ship, and they returned home.

7. And when we had finished our voyage from Tyre, we came to Ptolemais, greeted the brethren, and stayed with them one day.

8. On the next day we who were Paul's companions departed and came to Caesarea, and entered the house of Philip the evangelist, who was one of the seven, and stayed with him.

9. Now this man had four virgin daughters who prophesied.

10. And as we stayed many days, a certain prophet named Agabus came down from Judea.

11. When he had come to us, he took Paul's belt, bound his own hands and feet, and said, "Thus says the Holy Spirit, "So shall the Jews at Jerusalem bind the man who owns this belt, and deliver him into the hands of the Gentiles."'

12. Now when we heard these things, both we and those from that place pleaded with him not to go up to Jerusalem.

13. Then Paul answered, "What do you mean by weeping and breaking my heart? For I am ready not only to be bound, but also to die at Jerusalem for the name of the Lord Jesus."

14. So when he would not be persuaded, we ceased, saying, "The will of the Lord be done."

15. And after those days we packed and went up to Jerusalem.

16. Also some of the disciples from Caesarea went with us and brought with them a certain Mnason of Cyprus, an early disciple, with whom we were to lodge.

17. And when we had come to Jerusalem, the brethren received us gladly.

18. On the following day Paul went in with us to James, and all the elders were present.

19. When he had greeted them, he told in detail those things which God had done among the Gentiles through his ministry.

20. And when they heard it, they glorified the Lord. And they said to him, "You see, brother, how many myriads of Jews there are who have believed, and they are all zealous for the law;

21. but they have been informed about you that you teach all the Jews who are among the Gentiles to forsake Moses, saying that they ought not to circumcise their children nor to walk according to the customs.

22. What then? The assembly must certainly meet, for they will hear that you have come.

23. Therefore do what we tell you: We have four men who have taken a vow.

24. Take them and be purified with them, and pay their expenses so that they may shave their heads, and that all may know that those things of which they were informed concerning you are nothing, but that you yourself also walk orderly and keep the law.

25. But concerning the Gentiles who believe, we have written and decided that they should observe no such thing, except that they should keep themselves from things offered to idols, from blood, from things strangled, and from sexual immorality."

26. Then Paul took the men, and the next day, having been purified with them, entered the temple to announce the expiration of the days of purification, at which time an offering should be made for each one of them.

27. Now when the seven days were almost ended, the Jews from Asia, seeing him in the temple, stirred up the whole crowd and laid hands on him,

28. crying out, "Men of Israel, help! This is the man who teaches all men everywhere against the people, the law, and this place; and furthermore he also brought Greeks into the temple and has defiled this holy place."

29. (For they had previously seen Trophimus the Ephesian with him in the city, whom they supposed that Paul had brought into the temple.)

30. And all the city was disturbed; and the people ran together, seized Paul, and dragged him out of the temple; and immediately the doors were shut.

31. Now as they were seeking to kill him, news came to the commander of the garrison that all Jerusalem was in an uproar.

32. He immediately took soldiers and centurions, and ran down to them. And when they saw the commander and the soldiers, they stopped beating Paul.

33. Then the commander came near and took him, and commanded him to be bound with two chains; and he asked who he was and what he had done.

34. And some among the multitude cried one thing and some another. So when he could not ascertain the truth because of the tumult, he commanded him to be taken into the barracks.

35. When he reached the stairs, he had to be carried by the soldiers because of the violence of the mob.

36. For the multitude of the people followed after, crying out, "Away with him!"

37. Then as Paul was about to be led into the barracks, he said to the commander, "May I speak to you?" He replied, "Can you speak Greek?

38. Are you not the Egyptian who some time ago stirred up a rebellion and led the four thousand assassins out into the wilderness?"

39. But Paul said, "I am a Jew from Tarsus, in Cilicia, a citizen of no mean city; and I implore you, permit me to speak to the people."

40. So when he had given him permission, Paul stood on the stairs and motioned with his hand to the people. And when there was a great silence, he spoke to them in the Hebrew language, saying,

## Chapter 22

1. "Brethren and fathers, hear my defense before you now."

2. And when they heard that he spoke to them in the Hebrew language, they kept all the more silent. Then he said:

3. "I am indeed a Jew, born in Tarsus of Cilicia, but brought up in this city at the feet of Gamaliel, taught according to the strictness of our fathers' law, and was zealous toward God as you all are today.

4. I persecuted this Way to the death, binding and delivering into prisons both men and women,

5. as also the high priest bears me witness, and all the council of the elders, from whom I also received letters to the brethren, and went to Damascus to bring in chains even those who were there to Jerusalem to be punished.

6. "Now it happened, as I journeyed and came near Damascus at about noon, suddenly a great light from heaven shone around me.

7. And I fell to the ground and heard a voice saying to me, "Saul, Saul, why are you persecuting Me?'

8. So I answered, "Who are You, Lord?' And He said to me, "I am Jesus of Nazareth, whom you are persecuting.'

9. "And those who were with me indeed saw the light and were afraid, but they did not hear the voice of Him who spoke to me.

10. So I said, "What shall I do, Lord?' And the Lord said to me, "Arise and go into Damascus, and there you will be told all things which are appointed for you to do.'

11. And since I could not see for the glory of that light, being led by the hand of those who were with me, I came into Damascus.

12. "Then a certain Ananias, a devout man according to the law, having a good testimony with all the Jews who dwelt there,

13. came to me; and he stood and said to me, "Brother Saul, receive your sight.' And at that same hour I looked up at him.

14. Then he said, "The God of our fathers has chosen you that you should know His will, and see the Just One, and hear the voice of His mouth.

15. For you will be His witness to all men of what you have seen and heard.

16. And now why are you waiting? Arise and be baptized, and wash away your sins, calling on the name of the Lord.'

17. "Now it happened, when I returned to Jerusalem and was praying in the temple, that I was in a trance

18. and saw Him saying to me, "Make haste and get out of Jerusalem quickly, for they will not receive your testimony concerning Me.'

19. So I said, "Lord, they know that in every synagogue I imprisoned and beat those who believe on You.

20. And when the blood of Your martyr Stephen was shed, I also was standing by consenting to his death, and guarding the clothes of those who were killing him.'

21. Then He said to me, "Depart, for I will send you far from here to the Gentiles."'

22. And they listened to him until this word, and then they raised their voices and said, "Away with such a fellow from the earth, for he is not fit to live!"

23. Then, as they cried out and tore off their clothes and threw dust into the air,

24. the commander ordered him to be brought into the barracks, and said that he should be examined under scourging, so that he might know why they shouted so against him.

25. And as they bound him with thongs, Paul said to the centurion who stood by, "Is it lawful for you to scourge a man who is a Roman, and uncondemned?"

26. When the centurion heard that, he went and told the commander, saying, "Take care what you do, for this man is a Roman."

27. Then the commander came and said to him, "Tell me, are you a Roman?" He said, "Yes."

28. The commander answered, "With a large sum I obtained this citizenship." And Paul said, "But I was born a citizen."

29. Then immediately those who were about to examine him withdrew from him; and the commander was also afraid after he found out that he was a Roman, and because he had bound him.

30. The next day, because he wanted to know for certain why he was accused by the Jews, he released him from his bonds, and commanded the chief priests and all their council to appear, and brought Paul down and set him before them.

## Chapter 23

1. Then Paul, looking earnestly at the council, said, "Men and brethren, I have lived in all good conscience before God until this day."

2. And the high priest Ananias commanded those who stood by him to strike him on the mouth.

3. Then Paul said to him, "God will strike you, you whitewashed wall! For you sit to judge me according to the law, and do you command me to be struck contrary to the law?"

4. And those who stood by said, "Do you revile God's high priest?"

5. Then Paul said, "I did not know, brethren, that he was the high priest; for it is written, "You shall not speak evil of a ruler of your people."'

6. But when Paul perceived that one part were Sadducees and the other Pharisees, he cried out in the council, "Men and brethren, I am a Pharisee, the son of a Pharisee; concerning the hope and resurrection of the dead I am being judged!"

7. And when he had said this, a dissension arose between the Pharisees and the Sadducees; and the assembly was divided.

8. For Sadducees say that there is no resurrection--and no angel or spirit; but the Pharisees confess both.

9. Then there arose a loud outcry. And the scribes of the Pharisees' party arose and protested, saying, "We find no evil in this man; but if a spirit or an angel has spoken to him, let us not fight against God."

10. Now when there arose a great dissension, the commander, fearing lest Paul might be pulled to pieces by them, commanded the soldiers to go down and take him by force from among them, and bring him into the barracks.

11. But the following night the Lord stood by him and said, "Be of good cheer, Paul; for as you have testified for Me in Jerusalem, so you must also bear witness at Rome."

12. And when it was day, some of the Jews banded together and bound themselves under an oath, saying that they would neither eat nor drink till they had killed Paul.

13. Now there were more than forty who had formed this conspiracy.

14. They came to the chief priests and elders, and said, "We have bound ourselves under a great oath that we will eat nothing until we have killed Paul.

15. Now you, therefore, together with the council, suggest to the commander that he be brought down to you tomorrow, as though you were going to make further inquiries concerning him; but we are ready to kill him before he comes near."

16. So when Paul's sister's son heard of their ambush, he went and entered the barracks and told Paul.

17. Then Paul called one of the centurions to him and said, "Take this young man to the commander, for he has something to tell him."

18. So he took him and brought him to the commander and said, "Paul the prisoner called me to him and asked me to bring this young man to you. He has something to say to you."

19. Then the commander took him by the hand, went aside, and asked privately, "What is it that you have to tell me?"

20. And he said, "The Jews have agreed to ask that you bring Paul down to the council tomorrow, as though they were going to inquire more fully about him.

21. But do not yield to them, for more than forty of them lie in wait for him, men who have bound themselves by an oath that they will neither eat nor drink till they have killed him; and now they are ready, waiting for the promise from you."

22. So the commander let the young man depart, and commanded him, "Tell no one that you have revealed these things to me."

23. And he called for two centurions, saying, "Prepare two hundred soldiers, seventy horsemen, and two hundred spearmen to go to Caesarea at the third hour of the night;

24. and provide mounts to set Paul on, and bring him safely to Felix the governor."

25. He wrote a letter in the following manner:

26. Claudius Lysias, To the most excellent governor Felix: Greetings.

27. This man was seized by the Jews and was about to be killed by them. Coming with the troops I rescued him, having learned that he was a Roman.

28. And when I wanted to know the reason they accused him, I brought him before their council.

29. I found out that he was accused concerning questions of their law, but had nothing charged against him deserving of death or chains.

30. And when it was told me that the Jews lay in wait for the man, I sent him immediately to you, and also commanded his accusers to state before you the charges against him. Farewell.

31. Then the soldiers, as they were commanded, took Paul and brought him by night to Antipatris.

32. The next day they left the horsemen to go on with him, and returned to the barracks.

33. When they came to Caesarea and had delivered the letter to the governor, they also presented Paul to him.

34. And when the governor had read it, he asked what province he was from. And when he understood that he was from Cilicia,

35. he said, "I will hear you when your accusers also have come." And he commanded him to be kept in Herod's Praetorium.

## Chapter 24

1. Now after five days Ananias the high priest came down with the elders and a certain orator named Tertullus. These gave evidence to the governor against Paul.

2. And when he was called upon, Tertullus began his accusation, saying: "Seeing that through you we enjoy great peace, and prosperity is being brought to this nation by your foresight,

3. we accept it always and in all places, most noble Felix, with all thankfulness.

4. Nevertheless, not to be tedious to you any further, I beg you to hear, by your courtesy, a few words from us.

5. For we have found this man a plague, a creator of dissension among all the Jews throughout the world, and a ringleader of the sect of the Nazarenes.

6. He even tried to profane the temple, and we seized him, and wanted to judge him according to our law.

7. But the commander Lysias came by and with great violence took him out of our hands,

8. commanding his accusers to come to you. By examining him yourself you may ascertain all these things of which we accuse him."

9. And the Jews also assented, maintaining that these things were so.

10. Then Paul, after the governor had nodded to him to speak, answered: "Inasmuch as I know that you have been for many years a judge of this nation, I do the more cheerfully answer for myself,

11. because you may ascertain that it is no more than twelve days since I went up to Jerusalem to worship.

12. And they neither found me in the temple disputing with anyone nor inciting the crowd, either in the synagogues or in the city.

13. Nor can they prove the things of which they now accuse me.

14. But this I confess to you, that according to the Way which they call a sect, so I worship the God of my fathers, believing all things which are written in the Law and in the Prophets.

15. I have hope in God, which they themselves also accept, that there will be a resurrection of the dead, both of the just and the unjust.

16. This being so, I myself always strive to have a conscience without offense toward God and men.

17. "Now after many years I came to bring alms and offerings to my nation,

18. in the midst of which some Jews from Asia found me purified in the temple, neither with a mob nor with tumult.

19. They ought to have been here before you to object if they had anything against me.

20. Or else let those who are here themselves say if they found any wrongdoing in me while I stood before the council,

21. unless it is for this one statement which I cried out, standing among them, "Concerning the resurrection of the dead I am being judged by you this day."'

22. But when Felix heard these things, having more accurate knowledge of the Way, he adjourned the proceedings and said, "When Lysias the commander comes down, I will make a decision on your case."

23. So he commanded the centurion to keep Paul and to let him have liberty, and told him not to forbid any of his friends to provide for or visit him.

24. And after some days, when Felix came with his wife Drusilla, who was Jewish, he sent for Paul and heard him concerning the faith in Christ.

25. Now as he reasoned about righteousness, self-control, and the judgment to come, Felix was afraid and answered, "Go away for now; when I have a convenient time I will call for you."

26. Meanwhile he also hoped that money would be given him by Paul, that he might release him. Therefore he sent for him more often and conversed with him.

27. But after two years Porcius Festus succeeded Felix; and Felix, wanting to do the Jews a favor, left Paul bound.

## Chapter 25

1. Now when Festus had come to the province, after three days he went up from Caesarea to Jerusalem.

2. Then the high priest and the chief men of the Jews informed him against Paul; and they petitioned him,

3. asking a favor against him, that he would summon him to Jerusalem--while they lay in ambush along the road to kill him.

4. But Festus answered that Paul should be kept at Caesarea, and that he himself was going there shortly.

5. "Therefore," he said, "let those who have authority among you go down with me and accuse this man, to see if there is any fault in him."

6. And when he had remained among them more than ten days, he went down to Caesarea. And the next day, sitting on the judgment seat, he commanded Paul to be brought.

7. When he had come, the Jews who had come down from Jerusalem stood about and laid many serious complaints against Paul, which they could not prove,

8. while he answered for himself, "Neither against the law of the Jews, nor against the temple, nor against Caesar have I offended in anything at all."

9. But Festus, wanting to do the Jews a favor, answered Paul and said, "Are you willing to go up to Jerusalem and there be judged before me concerning these things?"

10. So Paul said, "I stand at Caesar's judgment seat, where I ought to be judged. To the Jews I have done no wrong, as you very well know.

11. For if I am an offender, or have committed anything deserving of death, I do not object to dying; but if there is nothing in these things of which these men accuse me, no one can deliver me to them. I appeal to Caesar."

12. Then Festus, when he had conferred with the council, answered, "You have appealed to Caesar? To Caesar you shall go!"

13. And after some days King Agrippa and Bernice came to Caesarea to greet Festus.

14. When they had been there many days, Festus laid Paul's case before the king, saying: "There is a certain man left a prisoner by Felix,

15. about whom the chief priests and the elders of the Jews informed me, when I was in Jerusalem, asking for a judgment against him.

16. To them I answered, "It is not the custom of the Romans to deliver any man to destruction before the accused meets the accusers face to face, and has opportunity to answer for himself concerning the charge against him.'

17. Therefore when they had come together, without any delay, the next day I sat on the judgment seat and commanded the man to be brought in.

18. When the accusers stood up, they brought no accusation against him of such things as I supposed,

19. but had some questions against him about their own religion and about a certain Jesus, who had died, whom Paul affirmed to be alive.

20. And because I was uncertain of such questions, I asked whether he was willing to go to Jerusalem and there be judged concerning these matters.

21. But when Paul appealed to be reserved for the decision of Augustus, I commanded him to be kept till I could send him to Caesar."

22. Then Agrippa said to Festus, "I also would like to hear the man myself." "Tomorrow," he said, "you shall hear him."

23. So the next day, when Agrippa and Bernice had come with great pomp, and had entered the auditorium with the commanders and the prominent men of the city, at Festus' command Paul was brought in.

24. And Festus said: "King Agrippa and all the men who are here present with us, you see this man about whom the whole assembly of the Jews petitioned me, both at Jerusalem and here, crying out that he was not fit to live any longer.

25. But when I found that he had committed nothing deserving of death, and that he himself had appealed to Augustus, I decided to send him.

26. I have nothing certain to write to my lord concerning him. Therefore I have brought him out before you, and especially before you, King Agrippa, so that after the examination has taken place I may have something to write.

27. For it seems to me unreasonable to send a prisoner and not to specify the charges against him."

## Chapter 26

1. Then Agrippa said to Paul, "You are permitted to speak for yourself." So Paul stretched out his hand and answered for himself:

2. "I think myself happy, King Agrippa, because today I shall answer for myself before you concerning all the things of which I am accused by the Jews,

3. especially because you are expert in all customs and questions which have to do with the Jews. Therefore I beg you to hear me patiently.

4. "My manner of life from my youth, which was spent from the beginning among my own nation at Jerusalem, all the Jews know.

5. They knew me from the first, if they were willing to testify, that according to the strictest sect of our religion I lived a Pharisee.

6. And now I stand and am judged for the hope of the promise made by God to our fathers.

7. To this promise our twelve tribes, earnestly serving God night and day, hope to attain. For this hope's sake, King Agrippa, I am accused by the Jews.

8. Why should it be thought incredible by you that God raises the dead?

9. "Indeed, I myself thought I must do many things contrary to the name of Jesus of Nazareth.

10. This I also did in Jerusalem, and many of the saints I shut up in prison, having received authority from the chief priests; and when they were put to death, I cast my vote against them.

11. And I punished them often in every synagogue and compelled them to blaspheme; and being exceedingly enraged against them, I persecuted them even to foreign cities.

12. "While thus occupied, as I journeyed to Damascus with authority and commission from the chief priests,

13. at midday, O king, along the road I saw a light from heaven, brighter than the sun, shining around me and those who journeyed with me.

14. And when we all had fallen to the ground, I heard a voice speaking to me and saying in the Hebrew language, "Saul, Saul, why are you persecuting Me? It is hard for you to kick against the goads.'

15. So I said, "Who are You, Lord?' And He said, "I am Jesus, whom you are persecuting.

16. But rise and stand on your feet; for I have appeared to you for this purpose, to make you a minister and a witness both of the things which you have seen and of the things which I will yet reveal to you.

17. I will deliver you from the Jewish people, as well as from the Gentiles, to whom I now send you,

18. to open their eyes, in order to turn them from darkness to light, and from the power of Satan to God, that they may receive forgiveness of sins and an inheritance among those who are sanctified by faith in Me.'

19. "Therefore, King Agrippa, I was not disobedient to the heavenly vision,

20. but declared first to those in Damascus and in Jerusalem, and throughout all the region of Judea, and then to the Gentiles, that they should repent, turn to God, and do works befitting repentance.

21. For these reasons the Jews seized me in the temple and tried to kill me.

22. Therefore, having obtained help from God, to this day I stand, witnessing both to small and great, saying no other things than those which the prophets and Moses said would come--

23. that the Christ would suffer, that He would be the first to rise from the dead, and would proclaim light to the Jewish people and to the Gentiles."

24. Now as he thus made his defense, Festus said with a loud voice, "Paul, you are beside yourself! Much learning is driving you mad!"

25. But he said, "I am not mad, most noble Festus, but speak the words of truth and reason.

26. For the king, before whom I also speak freely, knows these things; for I am convinced that none of these things escapes his attention, since this thing was not done in a corner.

27. King Agrippa, do you believe the prophets? I know that you do believe."

28. Then Agrippa said to Paul, "You almost persuade me to become a Christian."

29. And Paul said, "I would to God that not only you, but also all who hear me today, might become both almost and altogether such as I am, except for these chains."

30. When he had said these things, the king stood up, as well as the governor and Bernice and those who sat with them;

31. and when they had gone aside, they talked among themselves, saying, "This man is doing nothing deserving of death or chains."

32. Then Agrippa said to Festus, "This man might have been set free if he had not appealed to Caesar."

## Chapter 27

1. And when it was decided that we should sail to Italy, they delivered Paul and some other prisoners to one named Julius, a centurion of the Augustan Regiment.

2. So, entering a ship of Adramyttium, we put to sea, meaning to sail along the coasts of Asia. Aristarchus, a Macedonian of Thessalonica, was with us.

3. And the next day we landed at Sidon. And Julius treated Paul kindly and gave him liberty to go to his friends and receive care.

4. When we had put to sea from there, we sailed under the shelter of Cyprus, because the winds were contrary.

5. And when we had sailed over the sea which is off Cilicia and Pamphylia, we came to Myra, a city of Lycia.

6. There the centurion found an Alexandrian ship sailing to Italy, and he put us on board.

7. When we had sailed slowly many days, and arrived with difficulty off Cnidus, the wind not permitting us to proceed, we sailed under the shelter of Crete off Salmone.

8. Passing it with difficulty, we came to a place called Fair Havens, near the city of Lasea.

9. Now when much time had been spent, and sailing was now dangerous because the Fast was already over, Paul advised them,

10. saying, "Men, I perceive that this voyage will end with disaster and much loss, not only of the cargo and ship, but also our lives."

11. Nevertheless the centurion was more persuaded by the helmsman and the owner of the ship than by the things spoken by Paul.

12. And because the harbor was not suitable to winter in, the majority advised to set sail from there also, if by any means they could reach Phoenix, a harbor of Crete opening toward the southwest and northwest, and winter there.

13. When the south wind blew softly, supposing that they had obtained their desire, putting out to sea, they sailed close by Crete.

14. But not long after, a tempestuous head wind arose, called Euroclydon.

15. So when the ship was caught, and could not head into the wind, we let her drive.

16. And running under the shelter of an island called Clauda, we secured the skiff with difficulty.

17. When they had taken it on board, they used cables to undergird the ship; and fearing lest they should run aground on the Syrtis Sands, they struck sail and so were driven.

18. And because we were exceedingly tempest-tossed, the next day they lightened the ship.

19. On the third day we threw the ship's tackle overboard with our own hands.

20. Now when neither sun nor stars appeared for many days, and no small tempest beat on us, all hope that we would be saved was finally given up.

21. But after long abstinence from food, then Paul stood in the midst of them and said, "Men, you should have listened to me, and not have sailed from Crete and incurred this disaster and loss.

22. And now I urge you to take heart, for there will be no loss of life among you, but only of the ship.

23. For there stood by me this night an angel of the God to whom I belong and whom I serve,

24. saying, "Do not be afraid, Paul; you must be brought before Caesar; and indeed God has granted you all those who sail with you.'

25. Therefore take heart, men, for I believe God that it will be just as it was told me.

26. However, we must run aground on a certain island."

27. Now when the fourteenth night had come, as we were driven up and down in the Adriatic Sea, about midnight the sailors sensed that they were drawing near some land.

28. And they took soundings and found it to be twenty fathoms; and when they had gone a little farther, they took soundings again and found it to be fifteen fathoms.

29. Then, fearing lest we should run aground on the rocks, they dropped four anchors from the stern, and prayed for day to come.

30. And as the sailors were seeking to escape from the ship, when they had let down the skiff into the sea, under pretense of putting out anchors from the prow,

31. Paul said to the centurion and the soldiers, "Unless these men stay in the ship, you cannot be saved."

32. Then the soldiers cut away the ropes of the skiff and let it fall off.

33. And as day was about to dawn, Paul implored them all to take food, saying, "Today is the fourteenth day you have waited and continued without food, and eaten nothing.

34. Therefore I urge you to take nourishment, for this is for your survival, since not a hair will fall from the head of any of you."

35. And when he had said these things, he took bread and gave thanks to God in the presence of them all; and when he had broken it he began to eat.

36. Then they were all encouraged, and also took food themselves.

37. And in all we were two hundred and seventy-six persons on the ship.

38. So when they had eaten enough, they lightened the ship and threw out the wheat into the sea.

39. When it was day, they did not recognize the land; but they observed a bay with a beach, onto which they planned to run the ship if possible.

40. And they let go the anchors and left them in the sea, meanwhile loosing the rudder ropes; and they hoisted the mainsail to the wind and made for shore.

41. But striking a place where two seas met, they ran the ship aground; and the prow stuck fast and remained immovable, but the stern was being broken up by the violence of the waves.

42. And the soldiers' plan was to kill the prisoners, lest any of them should swim away and escape.

43. But the centurion, wanting to save Paul, kept them from their purpose, and commanded that those who could swim should jump overboard first and get to land,

44. and the rest, some on boards and some on parts of the ship. And so it was that they all escaped safely to land.

## Chapter 28

1. Now when they had escaped, they then found out that the island was called Malta.

2. And the natives showed us unusual kindness; for they kindled a fire and made us all welcome, because of the rain that was falling and because of the cold.

3. But when Paul had gathered a bundle of sticks and laid them on the fire, a viper came out because of the heat, and fastened on his hand.

4. So when the natives saw the creature hanging from his hand, they said to one another, "No doubt this man is a murderer, whom, though he has escaped the sea, yet justice does not allow to live."

5. But he shook off the creature into the fire and suffered no harm.

6. However, they were expecting that he would swell up or suddenly fall down dead. But after they had looked for a long time and saw no harm come to him, they changed their minds and said that he was a god.

7. In that region there was an estate of the leading citizen of the island, whose name was Publius, who received us and entertained us courteously for three days.

8. And it happened that the father of Publius lay sick of a fever and dysentery. Paul went in to him and prayed, and he laid his hands on him and healed him.

9. So when this was done, the rest of those on the island who had diseases also came and were healed.

10. They also honored us in many ways; and when we departed, they provided such things as were necessary.

11. After three months we sailed in an Alexandrian ship whose figurehead was the Twin Brothers, which had wintered at the island.

12. And landing at Syracuse, we stayed three days.

13. From there we circled round and reached Rhegium. And after one day the south wind blew; and the next day we came to Puteoli,

14. where we found brethren, and were invited to stay with them seven days. And so we went toward Rome.

15. And from there, when the brethren heard about us, they came to meet us as far as Appii Forum and Three Inns. When Paul saw them, he thanked God and took courage.

16. Now when we came to Rome, the centurion delivered the prisoners to the captain of the guard; but Paul was permitted to dwell by himself with the soldier who guarded him.

17. And it came to pass after three days that Paul called the leaders of the Jews together. So when they had come together, he said to them: "Men and brethren, though I have done nothing against our people or the customs of our fathers, yet I was delivered as a prisoner from Jerusalem into the hands of the Romans,

18. who, when they had examined me, wanted to let me go, because there was no cause for putting me to death.

19. But when the Jews spoke against it, I was compelled to appeal to Caesar, not that I had anything of which to accuse my nation.

20. For this reason therefore I have called for you, to see you and speak with you, because for the hope of Israel I am bound with this chain."

21. Then they said to him, "We neither received letters from Judea concerning you, nor have any of the brethren who came reported or spoken any evil of you.

22. But we desire to hear from you what you think; for concerning this sect, we know that it is spoken against everywhere."

23. So when they had appointed him a day, many came to him at his lodging, to whom he explained and solemnly testified of the kingdom of God, persuading them concerning Jesus from both the Law of Moses and the Prophets, from morning till evening.

24. And some were persuaded by the things which were spoken, and some disbelieved.

25. So when they did not agree among themselves, they departed after Paul had said one word: "The Holy Spirit spoke rightly through Isaiah the prophet to our fathers,

26. saying, "Go to this people and say: "Hearing you will hear, and shall not understand; And seeing you will see, and not perceive;

27. For the hearts of this people have grown dull. Their ears are hard of hearing, And their eyes they have closed, Lest they should see with their eyes and hear with their ears, Lest they should understand with their hearts and turn, So that I should heal them."'

28. "Therefore let it be known to you that the salvation of God has been sent to the Gentiles, and they will hear it!"

29. And when he had said these words, the Jews departed and had a great dispute among themselves.

30. Then Paul dwelt two whole years in his own rented house, and received all who came to him,

31. preaching the kingdom of God and teaching the things which concern the Lord Jesus Christ with all confidence, no one forbidding him.


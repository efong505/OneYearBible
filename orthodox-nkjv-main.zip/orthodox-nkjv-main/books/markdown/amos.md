# amos

## Chapter 1

1. The words of Amos, who was among the sheepbreeders of Tekoa, which he saw concerning Israel in the days of Uzziah king of Judah, and in the days of Jeroboam the son of Joash, king of Israel, two years before the earthquake.

2. And he said: "The LORD roars from Zion, And utters His voice from Jerusalem; The pastures of the shepherds mourn, And the top of Carmel withers."

3. Thus says the LORD: "For three transgressions of Damascus, and for four, I will not turn away its punishment, Because they have threshed Gilead with implements of iron.

4. But I will send a fire into the house of Hazael, Which shall devour the palaces of Ben-Hadad.

5. I will also break the gate bar of Damascus, And cut off the inhabitant from the Valley of Aven, And the one who holds the scepter from Beth Eden. The people of Syria shall go captive to Kir," Says the LORD.

6. Thus says the LORD: "For three transgressions of Gaza, and for four, I will not turn away its punishment, Because they took captive the whole captivity To deliver them up to Edom.

7. But I will send a fire upon the wall of Gaza, Which shall devour its palaces.

8. I will cut off the inhabitant from Ashdod, And the one who holds the scepter from Ashkelon; I will turn My hand against Ekron, And the remnant of the Philistines shall perish," Says the Lord GOD.

9. Thus says the LORD: "For three transgressions of Tyre, and for four, I will not turn away its punishment, Because they delivered up the whole captivity to Edom, And did not remember the covenant of brotherhood.

10. But I will send a fire upon the wall of Tyre, Which shall devour its palaces."

11. Thus says the LORD: "For three transgressions of Edom, and for four, I will not turn away its punishment, Because he pursued his brother with the sword, And cast off all pity; His anger tore perpetually, And he kept his wrath forever.

12. But I will send a fire upon Teman, Which shall devour the palaces of Bozrah."

13. Thus says the LORD: "For three transgressions of the people of Ammon, and for four, I will not turn away its punishment, Because they ripped open the women with child in Gilead, That they might enlarge their territory.

14. But I will kindle a fire in the wall of Rabbah, And it shall devour its palaces, Amid shouting in the day of battle, And a tempest in the day of the whirlwind.

15. Their king shall go into captivity, He and his princes together," Says the LORD.

## Chapter 2

1. Thus says the LORD: "For three transgressions of Moab, and for four, I will not turn away its punishment, Because he burned the bones of the king of Edom to lime.

2. But I will send a fire upon Moab, And it shall devour the palaces of Kerioth; Moab shall die with tumult, With shouting and trumpet sound.

3. And I will cut off the judge from its midst, And slay all its princes with him," Says the LORD.

4. Thus says the LORD: "For three transgressions of Judah, and for four, I will not turn away its punishment, Because they have despised the law of the LORD, And have not kept His commandments. Their lies lead them astray, Lies which their fathers followed.

5. But I will send a fire upon Judah, And it shall devour the palaces of Jerusalem."

6. Thus says the LORD: "For three transgressions of Israel, and for four, I will not turn away its punishment, Because they sell the righteous for silver, And the poor for a pair of sandals.

7. They pant after the dust of the earth which is on the head of the poor, And pervert the way of the humble. A man and his father go in to the same girl, To defile My holy name.

8. They lie down by every altar on clothes taken in pledge, And drink the wine of the condemned in the house of their god.

9. "Yet it was I who destroyed the Amorite before them, Whose height was like the height of the cedars, And he was as strong as the oaks; Yet I destroyed his fruit above And his roots beneath.

10. Also it was I who brought you up from the land of Egypt, And led you forty years through the wilderness, To possess the land of the Amorite.

11. I raised up some of your sons as prophets, And some of your young men as Nazirites. Is it not so, O you children of Israel?" Says the LORD.

12. "But you gave the Nazirites wine to drink, And commanded the prophets saying, "Do not prophesy!'

13. "Behold, I am weighed down by you, As a cart full of sheaves is weighed down.

14. Therefore flight shall perish from the swift, The strong shall not strengthen his power, Nor shall the mighty deliver himself;

15. He shall not stand who handles the bow, The swift of foot shall not escape, Nor shall he who rides a horse deliver himself.

16. The most courageous men of might Shall flee naked in that day," Says the LORD.

## Chapter 3

1. Hear this word that the LORD has spoken against you, O children of Israel, against the whole family which I brought up from the land of Egypt, saying:

2. "You only have I known of all the families of the earth; Therefore I will punish you for all your iniquities."

3. Can two walk together, unless they are agreed?

4. Will a lion roar in the forest, when he has no prey? Will a young lion cry out of his den, if he has caught nothing?

5. Will a bird fall into a snare on the earth, where there is no trap for it? Will a snare spring up from the earth, if it has caught nothing at all?

6. If a trumpet is blown in a city, will not the people be afraid? If there is calamity in a city, will not the LORD have done it?

7. Surely the Lord GOD does nothing, Unless He reveals His secret to His servants the prophets.

8. A lion has roared! Who will not fear? The Lord GOD has spoken! Who can but prophesy?

9. "Proclaim in the palaces at Ashdod, And in the palaces in the land of Egypt, and say: "Assemble on the mountains of Samaria; See great tumults in her midst, And the oppressed within her.

10. For they do not know to do right,' Says the LORD, "Who store up violence and robbery in their palaces."'

11. Therefore thus says the Lord GOD: "An adversary shall be all around the land; He shall sap your strength from you, And your palaces shall be plundered."

12. Thus says the LORD: "As a shepherd takes from the mouth of a lion Two legs or a piece of an ear, So shall the children of Israel be taken out Who dwell in Samaria-- In the corner of a bed and on the edge of a couch!

13. Hear and testify against the house of Jacob," Says the Lord GOD, the God of hosts,

14. "That in the day I punish Israel for their transgressions, I will also visit destruction on the altars of Bethel; And the horns of the altar shall be cut off And fall to the ground.

15. I will destroy the winter house along with the summer house; The houses of ivory shall perish, And the great houses shall have an end," Says the LORD.

## Chapter 4

1. Hear this word, you cows of Bashan, who are on the mountain of Samaria, Who oppress the poor, Who crush the needy, Who say to your husbands, "Bring wine, let us drink!"

2. The Lord GOD has sworn by His holiness: "Behold, the days shall come upon you When He will take you away with fishhooks, And your posterity with fishhooks.

3. You will go out through broken walls, Each one straight ahead of her, And you will be cast into Harmon," Says the LORD.

4. "Come to Bethel and transgress, At Gilgal multiply transgression; Bring your sacrifices every morning, Your tithes every three days.

5. Offer a sacrifice of thanksgiving with leaven, Proclaim and announce the freewill offerings; For this you love, You children of Israel!" Says the Lord GOD.

6. "Also I gave you cleanness of teeth in all your cities. And lack of bread in all your places; Yet you have not returned to Me," Says the LORD.

7. "I also withheld rain from you, When there were still three months to the harvest. I made it rain on one city, I withheld rain from another city. One part was rained upon, And where it did not rain the part withered.

8. So two or three cities wandered to another city to drink water, But they were not satisfied; Yet you have not returned to Me," Says the LORD.

9. "I blasted you with blight and mildew. When your gardens increased, Your vineyards, Your fig trees, And your olive trees, The locust devoured them; Yet you have not returned to Me," Says the LORD.

10. "I sent among you a plague after the manner of Egypt; Your young men I killed with a sword, Along with your captive horses; I made the stench of your camps come up into your nostrils; Yet you have not returned to Me," Says the LORD.

11. "I overthrew some of you, As God overthrew Sodom and Gomorrah, And you were like a firebrand plucked from the burning; Yet you have not returned to Me," Says the LORD.

12. "Therefore thus will I do to you, O Israel; Because I will do this to you, Prepare to meet your God, O Israel!"

13. For behold, He who forms mountains, And creates the wind, Who declares to man what his thought is, And makes the morning darkness, Who treads the high places of the earth-- The LORD God of hosts is His name.

## Chapter 5

1. Hear this word which I take up against you, a lamentation, O house of Israel:

2. The virgin of Israel has fallen; She will rise no more. She lies forsaken on her land; There is no one to raise her up.

3. For thus says the Lord GOD: "The city that goes out by a thousand Shall have a hundred left, And that which goes out by a hundred Shall have ten left to the house of Israel."

4. For thus says the LORD to the house of Israel: "Seek Me and live;

5. But do not seek Bethel, Nor enter Gilgal, Nor pass over to Beersheba; For Gilgal shall surely go into captivity, And Bethel shall come to nothing.

6. Seek the LORD and live, Lest He break out like fire in the house of Joseph, And devour it, With no one to quench it in Bethel--

7. You who turn justice to wormwood, And lay righteousness to rest in the earth!"

8. He made the Pleiades and Orion; He turns the shadow of death into morning And makes the day dark as night; He calls for the waters of the sea And pours them out on the face of the earth; The LORD is His name.

9. He rains ruin upon the strong, So that fury comes upon the fortress.

10. They hate the one who rebukes in the gate, And they abhor the one who speaks uprightly.

11. Therefore, because you tread down the poor And take grain taxes from him, Though you have built houses of hewn stone, Yet you shall not dwell in them; You have planted pleasant vineyards, But you shall not drink wine from them.

12. For I know your manifold transgressions And your mighty sins: Afflicting the just and taking bribes; Diverting the poor from justice at the gate.

13. Therefore the prudent keep silent at that time, For it is an evil time.

14. Seek good and not evil, That you may live; So the LORD God of hosts will be with you, As you have spoken.

15. Hate evil, love good; Establish justice in the gate. It may be that the LORD God of hosts Will be gracious to the remnant of Joseph.

16. Therefore the LORD God of hosts, the Lord, says this: "There shall be wailing in all streets, And they shall say in all the highways, "Alas! Alas!' They shall call the farmer to mourning, And skillful lamenters to wailing.

17. In all vineyards there shall be wailing, For I will pass through you," Says the LORD.

18. Woe to you who desire the day of the LORD! For what good is the day of the LORD to you? It will be darkness, and not light.

19. It will be as though a man fled from a lion, And a bear met him! Or as though he went into the house, Leaned his hand on the wall, And a serpent bit him!

20. Is not the day of the LORD darkness, and not light? Is it not very dark, with no brightness in it?

21. "I hate, I despise your feast days, And I do not savor your sacred assemblies.

22. Though you offer Me burnt offerings and your grain offerings, I will not accept them, Nor will I regard your fattened peace offerings.

23. Take away from Me the noise of your songs, For I will not hear the melody of your stringed instruments.

24. But let justice run down like water, And righteousness like a mighty stream.

25. "Did you offer Me sacrifices and offerings In the wilderness forty years, O house of Israel?

26. You also carried Sikkuth your king And Chiun, your idols, The star of your gods, Which you made for yourselves.

27. Therefore I will send you into captivity beyond Damascus," Says the LORD, whose name is the God of hosts.

## Chapter 6

1. Woe to you who are at ease in Zion, And trust in Mount Samaria, Notable persons in the chief nation, To whom the house of Israel comes!

2. Go over to Calneh and see; And from there go to Hamath the great; Then go down to Gath of the Philistines. Are you better than these kingdoms? Or is their territory greater than your territory?

3. Woe to you who put far off the day of doom, Who cause the seat of violence to come near;

4. Who lie on beds of ivory, Stretch out on your couches, Eat lambs from the flock And calves from the midst of the stall;

5. Who sing idly to the sound of stringed instruments, And invent for yourselves musical instruments like David;

6. Who drink wine from bowls, And anoint yourselves with the best ointments, But are not grieved for the affliction of Joseph.

7. Therefore they shall now go captive as the first of the captives, And those who recline at banquets shall be removed.

8. The Lord GOD has sworn by Himself, The LORD God of hosts says: "I abhor the pride of Jacob, And hate his palaces; Therefore I will deliver up the city And all that is in it."

9. Then it shall come to pass, that if ten men remain in one house, they shall die.

10. And when a relative of the dead, with one who will burn the bodies, picks up the bodies to take them out of the house, he will say to one inside the house, "Are there any more with you?" Then someone will say, "None." And he will say, "Hold your tongue! For we dare not mention the name of the LORD."

11. For behold, the LORD gives a command: He will break the great house into bits, And the little house into pieces.

12. Do horses run on rocks? Does one plow there with oxen? Yet you have turned justice into gall, And the fruit of righteousness into wormwood,

13. You who rejoice over Lo Debar, Who say, "Have we not taken Karnaim for ourselves By our own strength?"

14. "But, behold, I will raise up a nation against you, O house of Israel," Says the LORD God of hosts; "And they will afflict you from the entrance of Hamath To the Valley of the Arabah."

## Chapter 7

1. Thus the Lord GOD showed me: Behold, He formed locust swarms at the beginning of the late crop; indeed it was the late crop after the king's mowings.

2. And so it was, when they had finished eating the grass of the land, that I said: "O Lord GOD, forgive, I pray! Oh, that Jacob may stand, For he is small!"

3. So the LORD relented concerning this. "It shall not be," said the LORD.

4. Thus the Lord GOD showed me: Behold, the Lord GOD called for conflict by fire, and it consumed the great deep and devoured the territory.

5. Then I said: "O Lord GOD, cease, I pray! Oh, that Jacob may stand, For he is small!"

6. So the LORD relented concerning this. "This also shall not be," said the Lord GOD.

7. Thus He showed me: Behold, the Lord stood on a wall made with a plumb line, with a plumb line in His hand.

8. And the LORD said to me, "Amos, what do you see?" And I said, "A plumb line." Then the Lord said: "Behold, I am setting a plumb line In the midst of My people Israel; I will not pass by them anymore.

9. The high places of Isaac shall be desolate, And the sanctuaries of Israel shall be laid waste. I will rise with the sword against the house of Jeroboam."

10. Then Amaziah the priest of Bethel sent to Jeroboam king of Israel, saying, "Amos has conspired against you in the midst of the house of Israel. The land is not able to bear all his words.

11. For thus Amos has said: "Jeroboam shall die by the sword, And Israel shall surely be led away captive From their own land."'

12. Then Amaziah said to Amos: "Go, you seer! Flee to the land of Judah. There eat bread, And there prophesy.

13. But never again prophesy at Bethel, For it is the king's sanctuary, And it is the royal residence."

14. Then Amos answered, and said to Amaziah: "I was no prophet, Nor was I a son of a prophet, But I was a sheepbreeder And a tender of sycamore fruit.

15. Then the LORD took me as I followed the flock, And the LORD said to me, "Go, prophesy to My people Israel.'

16. Now therefore, hear the word of the LORD: You say, "Do not prophesy against Israel, And do not spout against the house of Isaac.'

17. "Therefore thus says the LORD: "Your wife shall be a harlot in the city; Your sons and daughters shall fall by the sword; Your land shall be divided by survey line; You shall die in a defiled land; And Israel shall surely be led away captive From his own land."'

## Chapter 8

1. Thus the Lord GOD showed me: Behold, a basket of summer fruit.

2. And He said, "Amos, what do you see?" So I said, "A basket of summer fruit." Then the LORD said to me: "The end has come upon My people Israel; I will not pass by them anymore.

3. And the songs of the temple Shall be wailing in that day," Says the Lord GOD-- "Many dead bodies everywhere, They shall be thrown out in silence."

4. Hear this, you who swallow up the needy, And make the poor of the land fail,

5. Saying: "When will the New Moon be past, That we may sell grain? And the Sabbath, That we may trade wheat? Making the ephah small and the shekel large, Falsifying the scales by deceit,

6. That we may buy the poor for silver, And the needy for a pair of sandals-- Even sell the bad wheat?"

7. The LORD has sworn by the pride of Jacob: "Surely I will never forget any of their works.

8. Shall the land not tremble for this, And everyone mourn who dwells in it? All of it shall swell like the River, Heave and subside Like the River of Egypt.

9. "And it shall come to pass in that day," says the Lord GOD, "That I will make the sun go down at noon, And I will darken the earth in broad daylight;

10. I will turn your feasts into mourning, And all your songs into lamentation; I will bring sackcloth on every waist, And baldness on every head; I will make it like mourning for an only son, And its end like a bitter day.

11. "Behold, the days are coming," says the Lord GOD, "That I will send a famine on the land, Not a famine of bread, Nor a thirst for water, But of hearing the words of the LORD.

12. They shall wander from sea to sea, And from north to east; They shall run to and fro, seeking the word of the LORD, But shall not find it.

13. "In that day the fair virgins And strong young men Shall faint from thirst.

14. Those who swear by the sin of Samaria, Who say, "As your god lives, O Dan!' And, "As the way of Beersheba lives!' They shall fall and never rise again."

## Chapter 9

1. I saw the Lord standing by the altar, and He said: "Strike the doorposts, that the thresholds may shake, And break them on the heads of them all. I will slay the last of them with the sword. He who flees from them shall not get away, And he who escapes from them shall not be delivered.

2. "Though they dig into hell, From there My hand shall take them; Though they climb up to heaven, From there I will bring them down;

3. And though they hide themselves on top of Carmel, From there I will search and take them; Though they hide from My sight at the bottom of the sea, From there I will command the serpent, and it shall bite them;

4. Though they go into captivity before their enemies, From there I will command the sword, And it shall slay them. I will set My eyes on them for harm and not for good."

5. The Lord GOD of hosts, He who touches the earth and it melts, And all who dwell there mourn; All of it shall swell like the River, And subside like the River of Egypt.

6. He who builds His layers in the sky, And has founded His strata in the earth; Who calls for the waters of the sea, And pours them out on the face of the earth-- The LORD is His name.

7. "Are you not like the people of Ethiopia to Me, O children of Israel?" says the LORD. "Did I not bring up Israel from the land of Egypt, The Philistines from Caphtor, And the Syrians from Kir?

8. "Behold, the eyes of the Lord GOD are on the sinful kingdom, And I will destroy it from the face of the earth; Yet I will not utterly destroy the house of Jacob," Says the LORD.

9. "For surely I will command, And will sift the house of Israel among all nations, As grain is sifted in a sieve; Yet not the smallest grain shall fall to the ground.

10. All the sinners of My people shall die by the sword, Who say, "The calamity shall not overtake nor confront us.'

11. "On that day I will raise up The tabernacle of David, which has fallen down, And repair its damages; I will raise up its ruins, And rebuild it as in the days of old;

12. That they may possess the remnant of Edom, And all the Gentiles who are called by My name," Says the LORD who does this thing.

13. "Behold, the days are coming," says the LORD, "When the plowman shall overtake the reaper, And the treader of grapes him who sows seed; The mountains shall drip with sweet wine, And all the hills shall flow with it.

14. I will bring back the captives of My people Israel; They shall build the waste cities and inhabit them; They shall plant vineyards and drink wine from them; They shall also make gardens and eat fruit from them.

15. I will plant them in their land, And no longer shall they be pulled up From the land I have given them," Says the LORD your God.


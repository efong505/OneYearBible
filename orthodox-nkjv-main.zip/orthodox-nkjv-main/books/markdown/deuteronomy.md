# deuteronomy

## Chapter 1

1. These are the words which Moses spoke to all Israel on this side of the Jordan in the wilderness, in the plain opposite Suph, between Paran, Tophel, Laban, Hazeroth, and Dizahab.

2. It is eleven days' journey from Horeb by way of Mount Seir to Kadesh Barnea.

3. Now it came to pass in the fortieth year, in the eleventh month, on the first day of the month, that Moses spoke to the children of Israel according to all that the LORD had given him as commandments to them,

4. after he had killed Sihon king of the Amorites, who dwelt in Heshbon, and Og king of Bashan, who dwelt at Ashtaroth in Edrei.

5. On this side of the Jordan in the land of Moab, Moses began to explain this law, saying,

6. "The LORD our God spoke to us in Horeb, saying: "You have dwelt long enough at this mountain.

7. Turn and take your journey, and go to the mountains of the Amorites, to all the neighboring places in the plain, in the mountains and in the lowland, in the South and on the seacoast, to the land of the Canaanites and to Lebanon, as far as the great river, the River Euphrates.

8. See, I have set the land before you; go in and possess the land which the LORD swore to your fathers--to Abraham, Isaac, and Jacob--to give to them and their descendants after them.'

9. "And I spoke to you at that time, saying: "I alone am not able to bear you.

10. The LORD your God has multiplied you, and here you are today, as the stars of heaven in multitude.

11. May the LORD God of your fathers make you a thousand times more numerous than you are, and bless you as He has promised you!

12. How can I alone bear your problems and your burdens and your complaints?

13. Choose wise, understanding, and knowledgeable men from among your tribes, and I will make them heads over you.'

14. And you answered me and said, "The thing which you have told us to do is good.'

15. So I took the heads of your tribes, wise and knowledgeable men, and made them heads over you, leaders of thousands, leaders of hundreds, leaders of fifties, leaders of tens, and officers for your tribes.

16. "Then I commanded your judges at that time, saying, "Hear the cases between your brethren, and judge righteously between a man and his brother or the stranger who is with him.

17. You shall not show partiality in judgment; you shall hear the small as well as the great; you shall not be afraid in any man's presence, for the judgment is God's. The case that is too hard for you, bring to me, and I will hear it.'

18. And I commanded you at that time all the things which you should do.

19. "So we departed from Horeb, and went through all that great and terrible wilderness which you saw on the way to the mountains of the Amorites, as the LORD our God had commanded us. Then we came to Kadesh Barnea.

20. And I said to you, "You have come to the mountains of the Amorites, which the LORD our God is giving us.

21. Look, the LORD your God has set the land before you; go up and possess it, as the LORD God of your fathers has spoken to you; do not fear or be discouraged.'

22. "And every one of you came near to me and said, "Let us send men before us, and let them search out the land for us, and bring back word to us of the way by which we should go up, and of the cities into which we shall come.'

23. "The plan pleased me well; so I took twelve of your men, one man from each tribe.

24. And they departed and went up into the mountains, and came to the Valley of Eshcol, and spied it out.

25. They also took some of the fruit of the land in their hands and brought it down to us; and they brought back word to us, saying, "It is a good land which the LORD our God is giving us.'

26. "Nevertheless you would not go up, but rebelled against the command of the LORD your God;

27. and you complained in your tents, and said, "Because the LORD hates us, He has brought us out of the land of Egypt to deliver us into the hand of the Amorites, to destroy us.

28. Where can we go up? Our brethren have discouraged our hearts, saying, "The people are greater and taller than we; the cities are great and fortified up to heaven; moreover we have seen the sons of the Anakim there."'

29. "Then I said to you, "Do not be terrified, or afraid of them.

30. The LORD your God, who goes before you, He will fight for you, according to all He did for you in Egypt before your eyes,

31. and in the wilderness where you saw how the LORD your God carried you, as a man carries his son, in all the way that you went until you came to this place.'

32. Yet, for all that, you did not believe the LORD your God,

33. who went in the way before you to search out a place for you to pitch your tents, to show you the way you should go, in the fire by night and in the cloud by day.

34. "And the LORD heard the sound of your words, and was angry, and took an oath, saying,

35. "Surely not one of these men of this evil generation shall see that good land of which I swore to give to your fathers,

36. except Caleb the son of Jephunneh; he shall see it, and to him and his children I am giving the land on which he walked, because he wholly followed the LORD.'

37. The LORD was also angry with me for your sakes, saying, "Even you shall not go in there.

38. Joshua the son of Nun, who stands before you, he shall go in there. Encourage him, for he shall cause Israel to inherit it.

39. "Moreover your little ones and your children, who you say will be victims, who today have no knowledge of good and evil, they shall go in there; to them I will give it, and they shall possess it.

40. But as for you, turn and take your journey into the wilderness by the Way of the Red Sea.'

41. "Then you answered and said to me, "We have sinned against the LORD; we will go up and fight, just as the LORD our God commanded us.' And when everyone of you had girded on his weapons of war, you were ready to go up into the mountain.

42. "And the LORD said to me, "Tell them, "Do not go up nor fight, for I am not among you; lest you be defeated before your enemies."'

43. So I spoke to you; yet you would not listen, but rebelled against the command of the LORD, and presumptuously went up into the mountain.

44. And the Amorites who dwelt in that mountain came out against you and chased you as bees do, and drove you back from Seir to Hormah.

45. Then you returned and wept before the LORD, but the LORD would not listen to your voice nor give ear to you.

46. "So you remained in Kadesh many days, according to the days that you spent there.

## Chapter 2

1. "Then we turned and journeyed into the wilderness of the Way of the Red Sea, as the LORD spoke to me, and we skirted Mount Seir for many days.

2. "And the LORD spoke to me, saying:

3. "You have skirted this mountain long enough; turn northward.

4. And command the people, saying, "You are about to pass through the territory of your brethren, the descendants of Esau, who live in Seir; and they will be afraid of you. Therefore watch yourselves carefully.

5. Do not meddle with them, for I will not give you any of their land, no, not so much as one footstep, because I have given Mount Seir to Esau as a possession.

6. You shall buy food from them with money, that you may eat; and you shall also buy water from them with money, that you may drink.

7. "For the LORD your God has blessed you in all the work of your hand. He knows your trudging through this great wilderness. These forty years the LORD your God has been with you; you have lacked nothing."'

8. "And when we passed beyond our brethren, the descendants of Esau who dwell in Seir, away from the road of the plain, away from Elath and Ezion Geber, we turned and passed by way of the Wilderness of Moab.

9. Then the LORD said to me, "Do not harass Moab, nor contend with them in battle, for I will not give you any of their land as a possession, because I have given Ar to the descendants of Lot as a possession."'

10. (The Emim had dwelt there in times past, a people as great and numerous and tall as the Anakim.

11. They were also regarded as giants, like the Anakim, but the Moabites call them Emim.

12. The Horites formerly dwelt in Seir, but the descendants of Esau dispossessed them and destroyed them from before them, and dwelt in their place, just as Israel did to the land of their possession which the LORD gave them.)

13. ""Now rise and cross over the Valley of the Zered.' So we crossed over the Valley of the Zered.

14. And the time we took to come from Kadesh Barnea until we crossed over the Valley of the Zered was thirty-eight years, until all the generation of the men of war was consumed from the midst of the camp, just as the LORD had sworn to them.

15. For indeed the hand of the LORD was against them, to destroy them from the midst of the camp until they were consumed.

16. "So it was, when all the men of war had finally perished from among the people,

17. that the LORD spoke to me, saying:

18. "This day you are to cross over at Ar, the boundary of Moab.

19. And when you come near the people of Ammon, do not harass them or meddle with them, for I will not give you any of the land of the people of Ammon as a possession, because I have given it to the descendants of Lot as a possession."'

20. (That was also regarded as a land of giants; giants formerly dwelt there. But the Ammonites call them Zamzummim,

21. a people as great and numerous and tall as the Anakim. But the LORD destroyed them before them, and they dispossessed them and dwelt in their place,

22. just as He had done for the descendants of Esau, who dwelt in Seir, when He destroyed the Horites from before them. They dispossessed them and dwelt in their place, even to this day.

23. And the Avim, who dwelt in villages as far as Gaza--the Caphtorim, who came from Caphtor, destroyed them and dwelt in their place.)

24. ""Rise, take your journey, and cross over the River Arnon. Look, I have given into your hand Sihon the Amorite, king of Heshbon, and his land. Begin to possess it, and engage him in battle.

25. This day I will begin to put the dread and fear of you upon the nations under the whole heaven, who shall hear the report of you, and shall tremble and be in anguish because of you.'

26. "And I sent messengers from the Wilderness of Kedemoth to Sihon king of Heshbon, with words of peace, saying,

27. "Let me pass through your land; I will keep strictly to the road, and I will turn neither to the right nor to the left.

28. You shall sell me food for money, that I may eat, and give me water for money, that I may drink; only let me pass through on foot,

29. just as the descendants of Esau who dwell in Seir and the Moabites who dwell in Ar did for me, until I cross the Jordan to the land which the LORD our God is giving us.'

30. "But Sihon king of Heshbon would not let us pass through, for the LORD your God hardened his spirit and made his heart obstinate, that He might deliver him into your hand, as it is this day.

31. "And the LORD said to me, "See, I have begun to give Sihon and his land over to you. Begin to possess it, that you may inherit his land.'

32. Then Sihon and all his people came out against us to fight at Jahaz.

33. And the LORD our God delivered him over to us; so we defeated him, his sons, and all his people.

34. We took all his cities at that time, and we utterly destroyed the men, women, and little ones of every city; we left none remaining.

35. We took only the livestock as plunder for ourselves, with the spoil of the cities which we took.

36. From Aroer, which is on the bank of the River Arnon, and from the city that is in the ravine, as far as Gilead, there was not one city too strong for us; the LORD our God delivered all to us.

37. Only you did not go near the land of the people of Ammon--anywhere along the River Jabbok, or to the cities of the mountains, or wherever the LORD our God had forbidden us.

## Chapter 3

1. "Then we turned and went up the road to Bashan; and Og king of Bashan came out against us, he and all his people, to battle at Edrei.

2. And the LORD said to me, "Do not fear him, for I have delivered him and all his people and his land into your hand; you shall do to him as you did to Sihon king of the Amorites, who dwelt at Heshbon.'

3. "So the LORD our God also delivered into our hands Og king of Bashan, with all his people, and we attacked him until he had no survivors remaining.

4. And we took all his cities at that time; there was not a city which we did not take from them: sixty cities, all the region of Argob, the kingdom of Og in Bashan.

5. All these cities were fortified with high walls, gates, and bars, besides a great many rural towns.

6. And we utterly destroyed them, as we did to Sihon king of Heshbon, utterly destroying the men, women, and children of every city.

7. But all the livestock and the spoil of the cities we took as booty for ourselves.

8. "And at that time we took the land from the hand of the two kings of the Amorites who were on this side of the Jordan, from the River Arnon to Mount Hermon

9. (the Sidonians call Hermon Sirion, and the Amorites call it Senir),

10. all the cities of the plain, all Gilead, and all Bashan, as far as Salcah and Edrei, cities of the kingdom of Og in Bashan.

11. "For only Og king of Bashan remained of the remnant of the giants. Indeed his bedstead was an iron bedstead. (Is it not in Rabbah of the people of Ammon?) Nine cubits is its length and four cubits its width, according to the standard cubit.

12. "And this land, which we possessed at that time, from Aroer, which is by the River Arnon, and half the mountains of Gilead and its cities, I gave to the Reubenites and the Gadites.

13. The rest of Gilead, and all Bashan, the kingdom of Og, I gave to half the tribe of Manasseh. (All the region of Argob, with all Bashan, was called the land of the giants.

14. Jair the son of Manasseh took all the region of Argob, as far as the border of the Geshurites and the Maachathites, and called Bashan after his own name, Havoth Jair, to this day.)

15. "Also I gave Gilead to Machir.

16. And to the Reubenites and the Gadites I gave from Gilead as far as the River Arnon, the middle of the river as the border, as far as the River Jabbok, the border of the people of Ammon;

17. the plain also, with the Jordan as the border, from Chinnereth as far as the east side of the Sea of the Arabah (the Salt Sea), below the slopes of Pisgah.

18. "Then I commanded you at that time, saying: "The LORD your God has given you this land to possess. All you men of valor shall cross over armed before your brethren, the children of Israel.

19. But your wives, your little ones, and your livestock (I know that you have much livestock) shall stay in your cities which I have given you,

20. until the LORD has given rest to your brethren as to you, and they also possess the land which the LORD your God is giving them beyond the Jordan. Then each of you may return to his possession which I have given you.'

21. "And I commanded Joshua at that time, saying, "Your eyes have seen all that the LORD your God has done to these two kings; so will the LORD do to all the kingdoms through which you pass.

22. You must not fear them, for the LORD your God Himself fights for you.'

23. "Then I pleaded with the LORD at that time, saying:

24. "O Lord GOD, You have begun to show Your servant Your greatness and Your mighty hand, for what god is there in heaven or on earth who can do anything like Your works and Your mighty deeds?

25. I pray, let me cross over and see the good land beyond the Jordan, those pleasant mountains, and Lebanon.'

26. "But the LORD was angry with me on your account, and would not listen to me. So the LORD said to me: "Enough of that! Speak no more to Me of this matter.

27. Go up to the top of Pisgah, and lift your eyes toward the west, the north, the south, and the east; behold it with your eyes, for you shall not cross over this Jordan.

28. But command Joshua, and encourage him and strengthen him; for he shall go over before this people, and he shall cause them to inherit the land which you will see.'

29. "So we stayed in the valley opposite Beth Peor.

## Chapter 4

1. "Now, O Israel, listen to the statutes and the judgments which I teach you to observe, that you may live, and go in and possess the land which the LORD God of your fathers is giving you.

2. You shall not add to the word which I command you, nor take from it, that you may keep the commandments of the LORD your God which I command you.

3. Your eyes have seen what the LORD did at Baal Peor; for the LORD your God has destroyed from among you all the men who followed Baal of Peor.

4. But you who held fast to the LORD your God are alive today, every one of you.

5. "Surely I have taught you statutes and judgments, just as the LORD my God commanded me, that you should act according to them in the land which you go to possess.

6. Therefore be careful to observe them; for this is your wisdom and your understanding in the sight of the peoples who will hear all these statutes, and say, "Surely this great nation is a wise and understanding people.'

7. "For what great nation is there that has God so near to it, as the LORD our God is to us, for whatever reason we may call upon Him?

8. And what great nation is there that has such statutes and righteous judgments as are in all this law which I set before you this day?

9. Only take heed to yourself, and diligently keep yourself, lest you forget the things your eyes have seen, and lest they depart from your heart all the days of your life. And teach them to your children and your grandchildren,

10. especially concerning the day you stood before the LORD your God in Horeb, when the LORD said to me, "Gather the people to Me, and I will let them hear My words, that they may learn to fear Me all the days they live on the earth, and that they may teach their children.'

11. "Then you came near and stood at the foot of the mountain, and the mountain burned with fire to the midst of heaven, with darkness, cloud, and thick darkness.

12. And the LORD spoke to you out of the midst of the fire. You heard the sound of the words, but saw no form; you only heard a voice.

13. So He declared to you His covenant which He commanded you to perform, the Ten Commandments; and He wrote them on two tablets of stone.

14. And the LORD commanded me at that time to teach you statutes and judgments, that you might observe them in the land which you cross over to possess.

15. "Take careful heed to yourselves, for you saw no form when the LORD spoke to you at Horeb out of the midst of the fire,

16. lest you act corruptly and make for yourselves a carved image in the form of any figure: the likeness of male or female,

17. the likeness of any animal that is on the earth or the likeness of any winged bird that flies in the air,

18. the likeness of anything that creeps on the ground or the likeness of any fish that is in the water beneath the earth.

19. And take heed, lest you lift your eyes to heaven, and when you see the sun, the moon, and the stars, all the host of heaven, you feel driven to worship them and serve them, which the LORD your God has given to all the peoples under the whole heaven as a heritage.

20. But the LORD has taken you and brought you out of the iron furnace, out of Egypt, to be His people, an inheritance, as you are this day.

21. Furthermore the LORD was angry with me for your sakes, and swore that I would not cross over the Jordan, and that I would not enter the good land which the LORD your God is giving you as an inheritance.

22. But I must die in this land, I must not cross over the Jordan; but you shall cross over and possess that good land.

23. Take heed to yourselves, lest you forget the covenant of the LORD your God which He made with you, and make for yourselves a carved image in the form of anything which the LORD your God has forbidden you.

24. For the LORD your God is a consuming fire, a jealous God.

25. "When you beget children and grandchildren and have grown old in the land, and act corruptly and make a carved image in the form of anything, and do evil in the sight of the LORD your God to provoke Him to anger,

26. I call heaven and earth to witness against you this day, that you will soon utterly perish from the land which you cross over the Jordan to possess; you will not prolong your days in it, but will be utterly destroyed.

27. And the LORD will scatter you among the peoples, and you will be left few in number among the nations where the LORD will drive you.

28. And there you will serve gods, the work of men's hands, wood and stone, which neither see nor hear nor eat nor smell.

29. But from there you will seek the LORD your God, and you will find Him if you seek Him with all your heart and with all your soul.

30. When you are in distress, and all these things come upon you in the latter days, when you turn to the LORD your God and obey His voice

31. (for the LORD your God is a merciful God), He will not forsake you nor destroy you, nor forget the covenant of your fathers which He swore to them.

32. "For ask now concerning the days that are past, which were before you, since the day that God created man on the earth, and ask from one end of heaven to the other, whether any great thing like this has happened, or anything like it has been heard.

33. Did any people ever hear the voice of God speaking out of the midst of the fire, as you have heard, and live?

34. Or did God ever try to go and take for Himself a nation from the midst of another nation, by trials, by signs, by wonders, by war, by a mighty hand and an outstretched arm, and by great terrors, according to all that the LORD your God did for you in Egypt before your eyes?

35. To you it was shown, that you might know that the LORD Himself is God; there is none other besides Him.

36. Out of heaven He let you hear His voice, that He might instruct you; on earth He showed you His great fire, and you heard His words out of the midst of the fire.

37. And because He loved your fathers, therefore He chose their descendants after them; and He brought you out of Egypt with His Presence, with His mighty power,

38. driving out from before you nations greater and mightier than you, to bring you in, to give you their land as an inheritance, as it is this day.

39. Therefore know this day, and consider it in your heart, that the LORD Himself is God in heaven above and on the earth beneath; there is no other.

40. You shall therefore keep His statutes and His commandments which I command you today, that it may go well with you and with your children after you, and that you may prolong your days in the land which the LORD your God is giving you for all time."

41. Then Moses set apart three cities on this side of the Jordan, toward the rising of the sun,

42. that the manslayer might flee there, who kills his neighbor unintentionally, without having hated him in time past, and that by fleeing to one of these cities he might live:

43. Bezer in the wilderness on the plateau for the Reubenites, Ramoth in Gilead for the Gadites, and Golan in Bashan for the Manassites.

44. Now this is the law which Moses set before the children of Israel.

45. These are the testimonies, the statutes, and the judgments which Moses spoke to the children of Israel after they came out of Egypt,

46. on this side of the Jordan, in the valley opposite Beth Peor, in the land of Sihon king of the Amorites, who dwelt at Heshbon, whom Moses and the children of Israel defeated after they came out of Egypt.

47. And they took possession of his land and the land of Og king of Bashan, two kings of the Amorites, who were on this side of the Jordan, toward the rising of the sun,

48. from Aroer, which is on the bank of the River Arnon, even to Mount Sion (that is, Hermon),

49. and all the plain on the east side of the Jordan as far as the Sea of the Arabah, below the slopes of Pisgah.

## Chapter 5

1. And Moses called all Israel, and said to them: "Hear, O Israel, the statutes and judgments which I speak in your hearing today, that you may learn them and be careful to observe them.

2. The LORD our God made a covenant with us in Horeb.

3. The LORD did not make this covenant with our fathers, but with us, those who are here today, all of us who are alive.

4. The LORD talked with you face to face on the mountain from the midst of the fire.

5. I stood between the LORD and you at that time, to declare to you the word of the LORD; for you were afraid because of the fire, and you did not go up the mountain. He said:

6. "I am the LORD your God who brought you out of the land of Egypt, out of the house of bondage.

7. "You shall have no other gods before Me.

8. "You shall not make for yourself a carved image--any likeness of anything that is in heaven above, or that is in the earth beneath, or that is in the water under the earth;

9. you shall not bow down to them nor serve them. For I, the LORD your God, am a jealous God, visiting the iniquity of the fathers upon the children to the third and fourth generations of those who hate Me,

10. but showing mercy to thousands, to those who love Me and keep My commandments.

11. "You shall not take the name of the LORD your God in vain, for the LORD will not hold him guiltless who takes His name in vain.

12. "Observe the Sabbath day, to keep it holy, as the LORD your God commanded you.

13. Six days you shall labor and do all your work,

14. but the seventh day is the Sabbath of the LORD your God. In it you shall do no work: you, nor your son, nor your daughter, nor your male servant, nor your female servant, nor your ox, nor your donkey, nor any of your cattle, nor your stranger who is within your gates, that your male servant and your female servant may rest as well as you.

15. And remember that you were a slave in the land of Egypt, and the LORD your God brought you out from there by a mighty hand and by an outstretched arm; therefore the LORD your God commanded you to keep the Sabbath day.

16. "Honor your father and your mother, as the LORD your God has commanded you, that your days may be long, and that it may be well with you in the land which the LORD your God is giving you.

17. "You shall not murder.

18. "You shall not commit adultery.

19. "You shall not steal.

20. "You shall not bear false witness against your neighbor.

21. "You shall not covet your neighbor's wife; and you shall not desire your neighbor's house, his field, his male servant, his female servant, his ox, his donkey, or anything that is your neighbor's.'

22. "These words the LORD spoke to all your assembly, in the mountain from the midst of the fire, the cloud, and the thick darkness, with a loud voice; and He added no more. And He wrote them on two tablets of stone and gave them to me.

23. "So it was, when you heard the voice from the midst of the darkness, while the mountain was burning with fire, that you came near to me, all the heads of your tribes and your elders.

24. And you said: "Surely the LORD our God has shown us His glory and His greatness, and we have heard His voice from the midst of the fire. We have seen this day that God speaks with man; yet he still lives.

25. Now therefore, why should we die? For this great fire will consume us; if we hear the voice of the LORD our God anymore, then we shall die.

26. For who is there of all flesh who has heard the voice of the living God speaking from the midst of the fire, as we have, and lived?

27. You go near and hear all that the LORD our God may say, and tell us all that the LORD our God says to you, and we will hear and do it.'

28. "Then the LORD heard the voice of your words when you spoke to me, and the LORD said to me: "I have heard the voice of the words of this people which they have spoken to you. They are right in all that they have spoken.

29. Oh, that they had such a heart in them that they would fear Me and always keep all My commandments, that it might be well with them and with their children forever!

30. Go and say to them, "Return to your tents."

31. But as for you, stand here by Me, and I will speak to you all the commandments, the statutes, and the judgments which you shall teach them, that they may observe them in the land which I am giving them to possess.'

32. "Therefore you shall be careful to do as the LORD your God has commanded you; you shall not turn aside to the right hand or to the left.

33. You shall walk in all the ways which the LORD your God has commanded you, that you may live and that it may be well with you, and that you may prolong your days in the land which you shall possess.

## Chapter 6

1. "Now this is the commandment, and these are the statutes and judgments which the LORD your God has commanded to teach you, that you may observe them in the land which you are crossing over to possess,

2. that you may fear the LORD your God, to keep all His statutes and His commandments which I command you, you and your son and your grandson, all the days of your life, and that your days may be prolonged.

3. Therefore hear, O Israel, and be careful to observe it, that it may be well with you, and that you may multiply greatly as the LORD God of your fathers has promised you--"a land flowing with milk and honey.'

4. "Hear, O Israel: The LORD our God, the LORD is one!

5. You shall love the LORD your God with all your heart, with all your soul, and with all your strength.

6. "And these words which I command you today shall be in your heart.

7. You shall teach them diligently to your children, and shall talk of them when you sit in your house, when you walk by the way, when you lie down, and when you rise up.

8. You shall bind them as a sign on your hand, and they shall be as frontlets between your eyes.

9. You shall write them on the doorposts of your house and on your gates.

10. "So it shall be, when the LORD your God brings you into the land of which He swore to your fathers, to Abraham, Isaac, and Jacob, to give you large and beautiful cities which you did not build,

11. houses full of all good things, which you did not fill, hewn-out wells which you did not dig, vineyards and olive trees which you did not plant--when you have eaten and are full--

12. then beware, lest you forget the LORD who brought you out of the land of Egypt, from the house of bondage.

13. You shall fear the LORD your God and serve Him, and shall take oaths in His name.

14. You shall not go after other gods, the gods of the peoples who are all around you

15. (for the LORD your God is a jealous God among you), lest the anger of the LORD your God be aroused against you and destroy you from the face of the earth.

16. "You shall not tempt the LORD your God as you tempted Him in Massah.

17. You shall diligently keep the commandments of the LORD your God, His testimonies, and His statutes which He has commanded you.

18. And you shall do what is right and good in the sight of the LORD, that it may be well with you, and that you may go in and possess the good land of which the LORD swore to your fathers,

19. to cast out all your enemies from before you, as the LORD has spoken.

20. "When your son asks you in time to come, saying, "What is the meaning of the testimonies, the statutes, and the judgments which the LORD our God has commanded you?'

21. then you shall say to your son: "We were slaves of Pharaoh in Egypt, and the LORD brought us out of Egypt with a mighty hand;

22. and the LORD showed signs and wonders before our eyes, great and severe, against Egypt, Pharaoh, and all his household.

23. Then He brought us out from there, that He might bring us in, to give us the land of which He swore to our fathers.

24. And the LORD commanded us to observe all these statutes, to fear the LORD our God, for our good always, that He might preserve us alive, as it is this day.

25. Then it will be righteousness for us, if we are careful to observe all these commandments before the LORD our God, as He has commanded us.'

## Chapter 7

1. "When the LORD your God brings you into the land which you go to possess, and has cast out many nations before you, the Hittites and the Girgashites and the Amorites and the Canaanites and the Perizzites and the Hivites and the Jebusites, seven nations greater and mightier than you,

2. and when the LORD your God delivers them over to you, you shall conquer them and utterly destroy them. You shall make no covenant with them nor show mercy to them.

3. Nor shall you make marriages with them. You shall not give your daughter to their son, nor take their daughter for your son.

4. For they will turn your sons away from following Me, to serve other gods; so the anger of the LORD will be aroused against you and destroy you suddenly.

5. But thus you shall deal with them: you shall destroy their altars, and break down their sacred pillars, and cut down their wooden images, and burn their carved images with fire.

6. "For you are a holy people to the LORD your God; the LORD your God has chosen you to be a people for Himself, a special treasure above all the peoples on the face of the earth.

7. The LORD did not set His love on you nor choose you because you were more in number than any other people, for you were the least of all peoples;

8. but because the LORD loves you, and because He would keep the oath which He swore to your fathers, the LORD has brought you out with a mighty hand, and redeemed you from the house of bondage, from the hand of Pharaoh king of Egypt.

9. "Therefore know that the LORD your God, He is God, the faithful God who keeps covenant and mercy for a thousand generations with those who love Him and keep His commandments;

10. and He repays those who hate Him to their face, to destroy them. He will not be slack with him who hates Him; He will repay him to his face.

11. Therefore you shall keep the commandment, the statutes, and the judgments which I command you today, to observe them.

12. "Then it shall come to pass, because you listen to these judgments, and keep and do them, that the LORD your God will keep with you the covenant and the mercy which He swore to your fathers.

13. And He will love you and bless you and multiply you; He will also bless the fruit of your womb and the fruit of your land, your grain and your new wine and your oil, the increase of your cattle and the offspring of your flock, in the land of which He swore to your fathers to give you.

14. You shall be blessed above all peoples; there shall not be a male or female barren among you or among your livestock.

15. And the LORD will take away from you all sickness, and will afflict you with none of the terrible diseases of Egypt which you have known, but will lay them on all those who hate you.

16. Also you shall destroy all the peoples whom the LORD your God delivers over to you; your eye shall have no pity on them; nor shall you serve their gods, for that will be a snare to you.

17. "If you should say in your heart, "These nations are greater than I; how can I dispossess them?'--

18. you shall not be afraid of them, but you shall remember well what the LORD your God did to Pharaoh and to all Egypt:

19. the great trials which your eyes saw, the signs and the wonders, the mighty hand and the outstretched arm, by which the LORD your God brought you out. So shall the LORD your God do to all the peoples of whom you are afraid.

20. Moreover the LORD your God will send the hornet among them until those who are left, who hide themselves from you, are destroyed.

21. You shall not be terrified of them; for the LORD your God, the great and awesome God, is among you.

22. And the LORD your God will drive out those nations before you little by little; you will be unable to destroy them at once, lest the beasts of the field become too numerous for you.

23. But the LORD your God will deliver them over to you, and will inflict defeat upon them until they are destroyed.

24. And He will deliver their kings into your hand, and you will destroy their name from under heaven; no one shall be able to stand against you until you have destroyed them.

25. You shall burn the carved images of their gods with fire; you shall not covet the silver or gold that is on them, nor take it for yourselves, lest you be snared by it; for it is an abomination to the LORD your God.

26. Nor shall you bring an abomination into your house, lest you be doomed to destruction like it. You shall utterly detest it and utterly abhor it, for it is an accursed thing.

## Chapter 8

1. "Every commandment which I command you today you must be careful to observe, that you may live and multiply, and go in and possess the land of which the LORD swore to your fathers.

2. And you shall remember that the LORD your God led you all the way these forty years in the wilderness, to humble you and test you, to know what was in your heart, whether you would keep His commandments or not.

3. So He humbled you, allowed you to hunger, and fed you with manna which you did not know nor did your fathers know, that He might make you know that man shall not live by bread alone; but man lives by every word that proceeds from the mouth of the LORD.

4. Your garments did not wear out on you, nor did your foot swell these forty years.

5. You should know in your heart that as a man chastens his son, so the LORD your God chastens you.

6. "Therefore you shall keep the commandments of the LORD your God, to walk in His ways and to fear Him.

7. For the LORD your God is bringing you into a good land, a land of brooks of water, of fountains and springs, that flow out of valleys and hills;

8. a land of wheat and barley, of vines and fig trees and pomegranates, a land of olive oil and honey;

9. a land in which you will eat bread without scarcity, in which you will lack nothing; a land whose stones are iron and out of whose hills you can dig copper.

10. When you have eaten and are full, then you shall bless the LORD your God for the good land which He has given you.

11. "Beware that you do not forget the LORD your God by not keeping His commandments, His judgments, and His statutes which I command you today,

12. lest--when you have eaten and are full, and have built beautiful houses and dwell in them;

13. and when your herds and your flocks multiply, and your silver and your gold are multiplied, and all that you have is multiplied;

14. when your heart is lifted up, and you forget the LORD your God who brought you out of the land of Egypt, from the house of bondage;

15. who led you through that great and terrible wilderness, in which were fiery serpents and scorpions and thirsty land where there was no water; who brought water for you out of the flinty rock;

16. who fed you in the wilderness with manna, which your fathers did not know, that He might humble you and that He might test you, to do you good in the end--

17. then you say in your heart, "My power and the might of my hand have gained me this wealth.'

18. "And you shall remember the LORD your God, for it is He who gives you power to get wealth, that He may establish His covenant which He swore to your fathers, as it is this day.

19. Then it shall be, if you by any means forget the LORD your God, and follow other gods, and serve them and worship them, I testify against you this day that you shall surely perish.

20. As the nations which the LORD destroys before you, so you shall perish, because you would not be obedient to the voice of the LORD your God.

## Chapter 9

1. "Hear, O Israel: You are to cross over the Jordan today, and go in to dispossess nations greater and mightier than yourself, cities great and fortified up to heaven,

2. a people great and tall, the descendants of the Anakim, whom you know, and of whom you heard it said, "Who can stand before the descendants of Anak?'

3. Therefore understand today that the LORD your God is He who goes over before you as a consuming fire. He will destroy them and bring them down before you; so you shall drive them out and destroy them quickly, as the LORD has said to you.

4. "Do not think in your heart, after the LORD your God has cast them out before you, saying, "Because of my righteousness the LORD has brought me in to possess this land'; but it is because of the wickedness of these nations that the LORD is driving them out from before you.

5. It is not because of your righteousness or the uprightness of your heart that you go in to possess their land, but because of the wickedness of these nations that the LORD your God drives them out from before you, and that He may fulfill the word which the LORD swore to your fathers, to Abraham, Isaac, and Jacob.

6. Therefore understand that the LORD your God is not giving you this good land to possess because of your righteousness, for you are a stiff-necked people.

7. "Remember! Do not forget how you provoked the LORD your God to wrath in the wilderness. From the day that you departed from the land of Egypt until you came to this place, you have been rebellious against the LORD.

8. Also in Horeb you provoked the LORD to wrath, so that the LORD was angry enough with you to have destroyed you.

9. When I went up into the mountain to receive the tablets of stone, the tablets of the covenant which the LORD made with you, then I stayed on the mountain forty days and forty nights. I neither ate bread nor drank water.

10. Then the LORD delivered to me two tablets of stone written with the finger of God, and on them were all the words which the LORD had spoken to you on the mountain from the midst of the fire in the day of the assembly.

11. And it came to pass, at the end of forty days and forty nights, that the LORD gave me the two tablets of stone, the tablets of the covenant.

12. "Then the LORD said to me, "Arise, go down quickly from here, for your people whom you brought out of Egypt have acted corruptly; they have quickly turned aside from the way which I commanded them; they have made themselves a molded image.'

13. "Furthermore the LORD spoke to me, saying, "I have seen this people, and indeed they are a stiff-necked people.

14. Let Me alone, that I may destroy them and blot out their name from under heaven; and I will make of you a nation mightier and greater than they.'

15. "So I turned and came down from the mountain, and the mountain burned with fire; and the two tablets of the covenant were in my two hands.

16. And I looked, and behold, you had sinned against the LORD your God--had made for yourselves a molded calf! You had turned aside quickly from the way which the LORD had commanded you.

17. Then I took the two tablets and threw them out of my two hands and broke them before your eyes.

18. And I fell down before the LORD, as at the first, forty days and forty nights; I neither ate bread nor drank water, because of all your sin which you committed in doing wickedly in the sight of the LORD, to provoke Him to anger.

19. For I was afraid of the anger and hot displeasure with which the LORD was angry with you, to destroy you. But the LORD listened to me at that time also.

20. And the LORD was very angry with Aaron and would have destroyed him; so I prayed for Aaron also at the same time.

21. Then I took your sin, the calf which you had made, and burned it with fire and crushed it and ground it very small, until it was as fine as dust; and I threw its dust into the brook that descended from the mountain.

22. "Also at Taberah and Massah and Kibroth Hattaavah you provoked the LORD to wrath.

23. Likewise, when the LORD sent you from Kadesh Barnea, saying, "Go up and possess the land which I have given you,' then you rebelled against the commandment of the LORD your God, and you did not believe Him nor obey His voice.

24. You have been rebellious against the LORD from the day that I knew you.

25. "Thus I prostrated myself before the LORD; forty days and forty nights I kept prostrating myself, because the LORD had said He would destroy you.

26. Therefore I prayed to the LORD, and said: "O Lord GOD, do not destroy Your people and Your inheritance whom You have redeemed through Your greatness, whom You have brought out of Egypt with a mighty hand.

27. Remember Your servants, Abraham, Isaac, and Jacob; do not look on the stubbornness of this people, or on their wickedness or their sin,

28. lest the land from which You brought us should say, "Because the LORD was not able to bring them to the land which He promised them, and because He hated them, He has brought them out to kill them in the wilderness."

29. Yet they are Your people and Your inheritance, whom You brought out by Your mighty power and by Your outstretched arm.'

## Chapter 10

1. "At that time the LORD said to me, "Hew for yourself two tablets of stone like the first, and come up to Me on the mountain and make yourself an ark of wood.

2. And I will write on the tablets the words that were on the first tablets, which you broke; and you shall put them in the ark.'

3. "So I made an ark of acacia wood, hewed two tablets of stone like the first, and went up the mountain, having the two tablets in my hand.

4. And He wrote on the tablets according to the first writing, the Ten Commandments, which the LORD had spoken to you in the mountain from the midst of the fire in the day of the assembly; and the LORD gave them to me.

5. Then I turned and came down from the mountain, and put the tablets in the ark which I had made; and there they are, just as the LORD commanded me."

6. (Now the children of Israel journeyed from the wells of Bene Jaakan to Moserah, where Aaron died, and where he was buried; and Eleazar his son ministered as priest in his stead.

7. From there they journeyed to Gudgodah, and from Gudgodah to Jotbathah, a land of rivers of water.

8. At that time the LORD separated the tribe of Levi to bear the ark of the covenant of the LORD, to stand before the LORD to minister to Him and to bless in His name, to this day.

9. Therefore Levi has no portion nor inheritance with his brethren; the LORD is his inheritance, just as the LORD your God promised him.)

10. "As at the first time, I stayed in the mountain forty days and forty nights; the LORD also heard me at that time, and the LORD chose not to destroy you.

11. Then the LORD said to me, "Arise, begin your journey before the people, that they may go in and possess the land which I swore to their fathers to give them.'

12. "And now, Israel, what does the LORD your God require of you, but to fear the LORD your God, to walk in all His ways and to love Him, to serve the LORD your God with all your heart and with all your soul,

13. and to keep the commandments of the LORD and His statutes which I command you today for your good?

14. Indeed heaven and the highest heavens belong to the LORD your God, also the earth with all that is in it.

15. The LORD delighted only in your fathers, to love them; and He chose their descendants after them, you above all peoples, as it is this day.

16. Therefore circumcise the foreskin of your heart, and be stiff-necked no longer.

17. For the LORD your God is God of gods and Lord of lords, the great God, mighty and awesome, who shows no partiality nor takes a bribe.

18. He administers justice for the fatherless and the widow, and loves the stranger, giving him food and clothing.

19. Therefore love the stranger, for you were strangers in the land of Egypt.

20. You shall fear the LORD your God; you shall serve Him, and to Him you shall hold fast, and take oaths in His name.

21. He is your praise, and He is your God, who has done for you these great and awesome things which your eyes have seen.

22. Your fathers went down to Egypt with seventy persons, and now the LORD your God has made you as the stars of heaven in multitude.

## Chapter 11

1. "Therefore you shall love the LORD your God, and keep His charge, His statutes, His judgments, and His commandments always.

2. Know today that I do not speak with your children, who have not known and who have not seen the chastening of the LORD your God, His greatness and His mighty hand and His outstretched arm--

3. His signs and His acts which He did in the midst of Egypt, to Pharaoh king of Egypt, and to all his land;

4. what He did to the army of Egypt, to their horses and their chariots: how He made the waters of the Red Sea overflow them as they pursued you, and how the LORD has destroyed them to this day;

5. what He did for you in the wilderness until you came to this place;

6. and what He did to Dathan and Abiram the sons of Eliab, the son of Reuben: how the earth opened its mouth and swallowed them up, their households, their tents, and all the substance that was in their possession, in the midst of all Israel--

7. but your eyes have seen every great act of the LORD which He did.

8. "Therefore you shall keep every commandment which I command you today, that you may be strong, and go in and possess the land which you cross over to possess,

9. and that you may prolong your days in the land which the LORD swore to give your fathers, to them and their descendants, "a land flowing with milk and honey.'

10. For the land which you go to possess is not like the land of Egypt from which you have come, where you sowed your seed and watered it by foot, as a vegetable garden;

11. but the land which you cross over to possess is a land of hills and valleys, which drinks water from the rain of heaven,

12. a land for which the LORD your God cares; the eyes of the LORD your God are always on it, from the beginning of the year to the very end of the year.

13. "And it shall be that if you earnestly obey My commandments which I command you today, to love the LORD your God and serve Him with all your heart and with all your soul,

14. then I will give you the rain for your land in its season, the early rain and the latter rain, that you may gather in your grain, your new wine, and your oil.

15. And I will send grass in your fields for your livestock, that you may eat and be filled.'

16. Take heed to yourselves, lest your heart be deceived, and you turn aside and serve other gods and worship them,

17. lest the LORD's anger be aroused against you, and He shut up the heavens so that there be no rain, and the land yield no produce, and you perish quickly from the good land which the LORD is giving you.

18. "Therefore you shall lay up these words of mine in your heart and in your soul, and bind them as a sign on your hand, and they shall be as frontlets between your eyes.

19. You shall teach them to your children, speaking of them when you sit in your house, when you walk by the way, when you lie down, and when you rise up.

20. And you shall write them on the doorposts of your house and on your gates,

21. that your days and the days of your children may be multiplied in the land of which the LORD swore to your fathers to give them, like the days of the heavens above the earth.

22. "For if you carefully keep all these commandments which I command you to do--to love the LORD your God, to walk in all His ways, and to hold fast to Him--

23. then the LORD will drive out all these nations from before you, and you will dispossess greater and mightier nations than yourselves.

24. Every place on which the sole of your foot treads shall be yours: from the wilderness and Lebanon, from the river, the River Euphrates, even to the Western Sea, shall be your territory.

25. No man shall be able to stand against you; the LORD your God will put the dread of you and the fear of you upon all the land where you tread, just as He has said to you.

26. "Behold, I set before you today a blessing and a curse:

27. the blessing, if you obey the commandments of the LORD your God which I command you today;

28. and the curse, if you do not obey the commandments of the LORD your God, but turn aside from the way which I command you today, to go after other gods which you have not known.

29. Now it shall be, when the LORD your God has brought you into the land which you go to possess, that you shall put the blessing on Mount Gerizim and the curse on Mount Ebal.

30. Are they not on the other side of the Jordan, toward the setting sun, in the land of the Canaanites who dwell in the plain opposite Gilgal, beside the terebinth trees of Moreh?

31. For you will cross over the Jordan and go in to possess the land which the LORD your God is giving you, and you will possess it and dwell in it.

32. And you shall be careful to observe all the statutes and judgments which I set before you today.

## Chapter 12

1. "These are the statutes and judgments which you shall be careful to observe in the land which the LORD God of your fathers is giving you to possess, all the days that you live on the earth.

2. You shall utterly destroy all the places where the nations which you shall dispossess served their gods, on the high mountains and on the hills and under every green tree.

3. And you shall destroy their altars, break their sacred pillars, and burn their wooden images with fire; you shall cut down the carved images of their gods and destroy their names from that place.

4. You shall not worship the LORD your God with such things.

5. "But you shall seek the place where the LORD your God chooses, out of all your tribes, to put His name for His dwelling place; and there you shall go.

6. There you shall take your burnt offerings, your sacrifices, your tithes, the heave offerings of your hand, your vowed offerings, your freewill offerings, and the firstborn of your herds and flocks.

7. And there you shall eat before the LORD your God, and you shall rejoice in all to which you have put your hand, you and your households, in which the LORD your God has blessed you.

8. "You shall not at all do as we are doing here today--every man doing whatever is right in his own eyes--

9. for as yet you have not come to the rest and the inheritance which the LORD your God is giving you.

10. But when you cross over the Jordan and dwell in the land which the LORD your God is giving you to inherit, and He gives you rest from all your enemies round about, so that you dwell in safety,

11. then there will be the place where the LORD your God chooses to make His name abide. There you shall bring all that I command you: your burnt offerings, your sacrifices, your tithes, the heave offerings of your hand, and all your choice offerings which you vow to the LORD.

12. And you shall rejoice before the LORD your God, you and your sons and your daughters, your male and female servants, and the Levite who is within your gates, since he has no portion nor inheritance with you.

13. Take heed to yourself that you do not offer your burnt offerings in every place that you see;

14. but in the place which the LORD chooses, in one of your tribes, there you shall offer your burnt offerings, and there you shall do all that I command you.

15. "However, you may slaughter and eat meat within all your gates, whatever your heart desires, according to the blessing of the LORD your God which He has given you; the unclean and the clean may eat of it, of the gazelle and the deer alike.

16. Only you shall not eat the blood; you shall pour it on the earth like water.

17. You may not eat within your gates the tithe of your grain or your new wine or your oil, of the firstborn of your herd or your flock, of any of your offerings which you vow, of your freewill offerings, or of the heave offering of your hand.

18. But you must eat them before the LORD your God in the place which the LORD your God chooses, you and your son and your daughter, your male servant and your female servant, and the Levite who is within your gates; and you shall rejoice before the LORD your God in all to which you put your hands.

19. Take heed to yourself that you do not forsake the Levite as long as you live in your land.

20. "When the LORD your God enlarges your border as He has promised you, and you say, "Let me eat meat,' because you long to eat meat, you may eat as much meat as your heart desires.

21. If the place where the LORD your God chooses to put His name is too far from you, then you may slaughter from your herd and from your flock which the LORD has given you, just as I have commanded you, and you may eat within your gates as much as your heart desires.

22. Just as the gazelle and the deer are eaten, so you may eat them; the unclean and the clean alike may eat them.

23. Only be sure that you do not eat the blood, for the blood is the life; you may not eat the life with the meat.

24. You shall not eat it; you shall pour it on the earth like water.

25. You shall not eat it, that it may go well with you and your children after you, when you do what is right in the sight of the LORD.

26. Only the holy things which you have, and your vowed offerings, you shall take and go to the place which the LORD chooses.

27. And you shall offer your burnt offerings, the meat and the blood, on the altar of the LORD your God; and the blood of your sacrifices shall be poured out on the altar of the LORD your God, and you shall eat the meat.

28. Observe and obey all these words which I command you, that it may go well with you and your children after you forever, when you do what is good and right in the sight of the LORD your God.

29. "When the LORD your God cuts off from before you the nations which you go to dispossess, and you displace them and dwell in their land,

30. take heed to yourself that you are not ensnared to follow them, after they are destroyed from before you, and that you do not inquire after their gods, saying, "How did these nations serve their gods? I also will do likewise.'

31. You shall not worship the LORD your God in that way; for every abomination to the LORD which He hates they have done to their gods; for they burn even their sons and daughters in the fire to their gods.

32. "Whatever I command you, be careful to observe it; you shall not add to it nor take away from it.

## Chapter 13

1. "If there arises among you a prophet or a dreamer of dreams, and he gives you a sign or a wonder,

2. and the sign or the wonder comes to pass, of which he spoke to you, saying, "Let us go after other gods'--which you have not known--"and let us serve them,'

3. you shall not listen to the words of that prophet or that dreamer of dreams, for the LORD your God is testing you to know whether you love the LORD your God with all your heart and with all your soul.

4. You shall walk after the LORD your God and fear Him, and keep His commandments and obey His voice; you shall serve Him and hold fast to Him.

5. But that prophet or that dreamer of dreams shall be put to death, because he has spoken in order to turn you away from the LORD your God, who brought you out of the land of Egypt and redeemed you from the house of bondage, to entice you from the way in which the LORD your God commanded you to walk. So you shall put away the evil from your midst.

6. "If your brother, the son of your mother, your son or your daughter, the wife of your bosom, or your friend who is as your own soul, secretly entices you, saying, "Let us go and serve other gods,' which you have not known, neither you nor your fathers,

7. of the gods of the people which are all around you, near to you or far off from you, from one end of the earth to the other end of the earth,

8. you shall not consent to him or listen to him, nor shall your eye pity him, nor shall you spare him or conceal him;

9. but you shall surely kill him; your hand shall be first against him to put him to death, and afterward the hand of all the people.

10. And you shall stone him with stones until he dies, because he sought to entice you away from the LORD your God, who brought you out of the land of Egypt, from the house of bondage.

11. So all Israel shall hear and fear, and not again do such wickedness as this among you.

12. "If you hear someone in one of your cities, which the LORD your God gives you to dwell in, saying,

13. "Corrupt men have gone out from among you and enticed the inhabitants of their city, saying, "Let us go and serve other gods"'--which you have not known--

14. then you shall inquire, search out, and ask diligently. And if it is indeed true and certain that such an abomination was committed among you,

15. you shall surely strike the inhabitants of that city with the edge of the sword, utterly destroying it, all that is in it and its livestock--with the edge of the sword.

16. And you shall gather all its plunder into the middle of the street, and completely burn with fire the city and all its plunder, for the LORD your God. It shall be a heap forever; it shall not be built again.

17. So none of the accursed things shall remain in your hand, that the LORD may turn from the fierceness of His anger and show you mercy, have compassion on you and multiply you, just as He swore to your fathers,

18. because you have listened to the voice of the LORD your God, to keep all His commandments which I command you today, to do what is right in the eyes of the LORD your God.

## Chapter 14

1. "You are the children of the LORD your God; you shall not cut yourselves nor shave the front of your head for the dead.

2. For you are a holy people to the LORD your God, and the LORD has chosen you to be a people for Himself, a special treasure above all the peoples who are on the face of the earth.

3. "You shall not eat any detestable thing.

4. These are the animals which you may eat: the ox, the sheep, the goat,

5. the deer, the gazelle, the roe deer, the wild goat, the mountain goat, the antelope, and the mountain sheep.

6. And you may eat every animal with cloven hooves, having the hoof split into two parts, and that chews the cud, among the animals.

7. Nevertheless, of those that chew the cud or have cloven hooves, you shall not eat, such as these: the camel, the hare, and the rock hyrax; for they chew the cud but do not have cloven hooves; they are unclean for you.

8. Also the swine is unclean for you, because it has cloven hooves, yet does not chew the cud; you shall not eat their flesh or touch their dead carcasses.

9. "These you may eat of all that are in the waters: you may eat all that have fins and scales.

10. And whatever does not have fins and scales you shall not eat; it is unclean for you.

11. "All clean birds you may eat.

12. But these you shall not eat: the eagle, the vulture, the buzzard,

13. the red kite, the falcon, and the kite after their kinds;

14. every raven after its kind;

15. the ostrich, the short-eared owl, the sea gull, and the hawk after their kinds;

16. the little owl, the screech owl, the white owl,

17. the jackdaw, the carrion vulture, the fisher owl,

18. the stork, the heron after its kind, and the hoopoe and the bat.

19. "Also every creeping thing that flies is unclean for you; they shall not be eaten.

20. "You may eat all clean birds.

21. "You shall not eat anything that dies of itself; you may give it to the alien who is within your gates, that he may eat it, or you may sell it to a foreigner; for you are a holy people to the LORD your God. "You shall not boil a young goat in its mother's milk.

22. "You shall truly tithe all the increase of your grain that the field produces year by year.

23. And you shall eat before the LORD your God, in the place where He chooses to make His name abide, the tithe of your grain and your new wine and your oil, of the firstborn of your herds and your flocks, that you may learn to fear the LORD your God always.

24. But if the journey is too long for you, so that you are not able to carry the tithe, or if the place where the LORD your God chooses to put His name is too far from you, when the LORD your God has blessed you,

25. then you shall exchange it for money, take the money in your hand, and go to the place which the LORD your God chooses.

26. And you shall spend that money for whatever your heart desires: for oxen or sheep, for wine or similar drink, for whatever your heart desires; you shall eat there before the LORD your God, and you shall rejoice, you and your household.

27. You shall not forsake the Levite who is within your gates, for he has no part nor inheritance with you.

28. "At the end of every third year you shall bring out the tithe of your produce of that year and store it up within your gates.

29. And the Levite, because he has no portion nor inheritance with you, and the stranger and the fatherless and the widow who are within your gates, may come and eat and be satisfied, that the LORD your God may bless you in all the work of your hand which you do.

## Chapter 15

1. "At the end of every seven years you shall grant a release of debts.

2. And this is the form of the release: Every creditor who has lent anything to his neighbor shall release it; he shall not require it of his neighbor or his brother, because it is called the LORD's release.

3. Of a foreigner you may require it; but you shall give up your claim to what is owed by your brother,

4. except when there may be no poor among you; for the LORD will greatly bless you in the land which the LORD your God is giving you to possess as an inheritance--

5. only if you carefully obey the voice of the LORD your God, to observe with care all these commandments which I command you today.

6. For the LORD your God will bless you just as He promised you; you shall lend to many nations, but you shall not borrow; you shall reign over many nations, but they shall not reign over you.

7. "If there is among you a poor man of your brethren, within any of the gates in your land which the LORD your God is giving you, you shall not harden your heart nor shut your hand from your poor brother,

8. but you shall open your hand wide to him and willingly lend him sufficient for his need, whatever he needs.

9. Beware lest there be a wicked thought in your heart, saying, "The seventh year, the year of release, is at hand,' and your eye be evil against your poor brother and you give him nothing, and he cry out to the LORD against you, and it become sin among you.

10. You shall surely give to him, and your heart should not be grieved when you give to him, because for this thing the LORD your God will bless you in all your works and in all to which you put your hand.

11. For the poor will never cease from the land; therefore I command you, saying, "You shall open your hand wide to your brother, to your poor and your needy, in your land.'

12. "If your brother, a Hebrew man, or a Hebrew woman, is sold to you and serves you six years, then in the seventh year you shall let him go free from you.

13. And when you send him away free from you, you shall not let him go away empty-handed;

14. you shall supply him liberally from your flock, from your threshing floor, and from your winepress. From what the LORD has blessed you with, you shall give to him.

15. You shall remember that you were a slave in the land of Egypt, and the LORD your God redeemed you; therefore I command you this thing today.

16. And if it happens that he says to you, "I will not go away from you,' because he loves you and your house, since he prospers with you,

17. then you shall take an awl and thrust it through his ear to the door, and he shall be your servant forever. Also to your female servant you shall do likewise.

18. It shall not seem hard to you when you send him away free from you; for he has been worth a double hired servant in serving you six years. Then the LORD your God will bless you in all that you do.

19. "All the firstborn males that come from your herd and your flock you shall sanctify to the LORD your God; you shall do no work with the firstborn of your herd, nor shear the firstborn of your flock.

20. You and your household shall eat it before the LORD your God year by year in the place which the LORD chooses.

21. But if there is a defect in it, if it is lame or blind or has any serious defect, you shall not sacrifice it to the LORD your God.

22. You may eat it within your gates; the unclean and the clean person alike may eat it, as if it were a gazelle or a deer.

23. Only you shall not eat its blood; you shall pour it on the ground like water.

## Chapter 16

1. "Observe the month of Abib, and keep the Passover to the LORD your God, for in the month of Abib the LORD your God brought you out of Egypt by night.

2. Therefore you shall sacrifice the Passover to the LORD your God, from the flock and the herd, in the place where the LORD chooses to put His name.

3. You shall eat no leavened bread with it; seven days you shall eat unleavened bread with it, that is, the bread of affliction (for you came out of the land of Egypt in haste), that you may remember the day in which you came out of the land of Egypt all the days of your life.

4. And no leaven shall be seen among you in all your territory for seven days, nor shall any of the meat which you sacrifice the first day at twilight remain overnight until morning.

5. "You may not sacrifice the Passover within any of your gates which the LORD your God gives you;

6. but at the place where the LORD your God chooses to make His name abide, there you shall sacrifice the Passover at twilight, at the going down of the sun, at the time you came out of Egypt.

7. And you shall roast and eat it in the place which the LORD your God chooses, and in the morning you shall turn and go to your tents.

8. Six days you shall eat unleavened bread, and on the seventh day there shall be a sacred assembly to the LORD your God. You shall do no work on it.

9. "You shall count seven weeks for yourself; begin to count the seven weeks from the time you begin to put the sickle to the grain.

10. Then you shall keep the Feast of Weeks to the LORD your God with the tribute of a freewill offering from your hand, which you shall give as the LORD your God blesses you.

11. You shall rejoice before the LORD your God, you and your son and your daughter, your male servant and your female servant, the Levite who is within your gates, the stranger and the fatherless and the widow who are among you, at the place where the LORD your God chooses to make His name abide.

12. And you shall remember that you were a slave in Egypt, and you shall be careful to observe these statutes.

13. "You shall observe the Feast of Tabernacles seven days, when you have gathered from your threshing floor and from your winepress.

14. And you shall rejoice in your feast, you and your son and your daughter, your male servant and your female servant and the Levite, the stranger and the fatherless and the widow, who are within your gates.

15. Seven days you shall keep a sacred feast to the LORD your God in the place which the LORD chooses, because the LORD your God will bless you in all your produce and in all the work of your hands, so that you surely rejoice.

16. "Three times a year all your males shall appear before the LORD your God in the place which He chooses: at the Feast of Unleavened Bread, at the Feast of Weeks, and at the Feast of Tabernacles; and they shall not appear before the LORD empty-handed.

17. Every man shall give as he is able, according to the blessing of the LORD your God which He has given you.

18. "You shall appoint judges and officers in all your gates, which the LORD your God gives you, according to your tribes, and they shall judge the people with just judgment.

19. You shall not pervert justice; you shall not show partiality, nor take a bribe, for a bribe blinds the eyes of the wise and twists the words of the righteous.

20. You shall follow what is altogether just, that you may live and inherit the land which the LORD your God is giving you.

21. "You shall not plant for yourself any tree, as a wooden image, near the altar which you build for yourself to the LORD your God.

22. You shall not set up a sacred pillar, which the LORD your God hates.

## Chapter 17

1. "You shall not sacrifice to the LORD your God a bull or sheep which has any blemish or defect, for that is an abomination to the LORD your God.

2. "If there is found among you, within any of your gates which the LORD your God gives you, a man or a woman who has been wicked in the sight of the LORD your God, in transgressing His covenant,

3. who has gone and served other gods and worshiped them, either the sun or moon or any of the host of heaven, which I have not commanded,

4. and it is told you, and you hear of it, then you shall inquire diligently. And if it is indeed true and certain that such an abomination has been committed in Israel,

5. then you shall bring out to your gates that man or woman who has committed that wicked thing, and shall stone to death that man or woman with stones.

6. Whoever is deserving of death shall be put to death on the testimony of two or three witnesses; he shall not be put to death on the testimony of one witness.

7. The hands of the witnesses shall be the first against him to put him to death, and afterward the hands of all the people. So you shall put away the evil from among you.

8. "If a matter arises which is too hard for you to judge, between degrees of guilt for bloodshed, between one judgment or another, or between one punishment or another, matters of controversy within your gates, then you shall arise and go up to the place which the LORD your God chooses.

9. And you shall come to the priests, the Levites, and to the judge there in those days, and inquire of them; they shall pronounce upon you the sentence of judgment.

10. You shall do according to the sentence which they pronounce upon you in that place which the LORD chooses. And you shall be careful to do according to all that they order you.

11. According to the sentence of the law in which they instruct you, according to the judgment which they tell you, you shall do; you shall not turn aside to the right hand or to the left from the sentence which they pronounce upon you.

12. Now the man who acts presumptuously and will not heed the priest who stands to minister there before the LORD your God, or the judge, that man shall die. So you shall put away the evil from Israel.

13. And all the people shall hear and fear, and no longer act presumptuously.

14. "When you come to the land which the LORD your God is giving you, and possess it and dwell in it, and say, "I will set a king over me like all the nations that are around me,'

15. you shall surely set a king over you whom the LORD your God chooses; one from among your brethren you shall set as king over you; you may not set a foreigner over you, who is not your brother.

16. But he shall not multiply horses for himself, nor cause the people to return to Egypt to multiply horses, for the LORD has said to you, "You shall not return that way again.'

17. Neither shall he multiply wives for himself, lest his heart turn away; nor shall he greatly multiply silver and gold for himself.

18. "Also it shall be, when he sits on the throne of his kingdom, that he shall write for himself a copy of this law in a book, from the one before the priests, the Levites.

19. And it shall be with him, and he shall read it all the days of his life, that he may learn to fear the LORD his God and be careful to observe all the words of this law and these statutes,

20. that his heart may not be lifted above his brethren, that he may not turn aside from the commandment to the right hand or to the left, and that he may prolong his days in his kingdom, he and his children in the midst of Israel.

## Chapter 18

1. "The priests, the Levites--all the tribe of Levi--shall have no part nor inheritance with Israel; they shall eat the offerings of the LORD made by fire, and His portion.

2. Therefore they shall have no inheritance among their brethren; the LORD is their inheritance, as He said to them.

3. "And this shall be the priest's due from the people, from those who offer a sacrifice, whether it is bull or sheep: they shall give to the priest the shoulder, the cheeks, and the stomach.

4. The firstfruits of your grain and your new wine and your oil, and the first of the fleece of your sheep, you shall give him.

5. For the LORD your God has chosen him out of all your tribes to stand to minister in the name of the LORD, him and his sons forever.

6. "So if a Levite comes from any of your gates, from where he dwells among all Israel, and comes with all the desire of his mind to the place which the LORD chooses,

7. then he may serve in the name of the LORD his God as all his brethren the Levites do, who stand there before the LORD.

8. They shall have equal portions to eat, besides what comes from the sale of his inheritance.

9. "When you come into the land which the LORD your God is giving you, you shall not learn to follow the abominations of those nations.

10. There shall not be found among you anyone who makes his son or his daughter pass through the fire, or one who practices witchcraft, or a soothsayer, or one who interprets omens, or a sorcerer,

11. or one who conjures spells, or a medium, or a spiritist, or one who calls up the dead.

12. For all who do these things are an abomination to the LORD, and because of these abominations the LORD your God drives them out from before you.

13. You shall be blameless before the LORD your God.

14. For these nations which you will dispossess listened to soothsayers and diviners; but as for you, the LORD your God has not appointed such for you.

15. "The LORD your God will raise up for you a Prophet like me from your midst, from your brethren. Him you shall hear,

16. according to all you desired of the LORD your God in Horeb in the day of the assembly, saying, "Let me not hear again the voice of the LORD my God, nor let me see this great fire anymore, lest I die.'

17. "And the LORD said to me: "What they have spoken is good.

18. I will raise up for them a Prophet like you from among their brethren, and will put My words in His mouth, and He shall speak to them all that I command Him.

19. And it shall be that whoever will not hear My words, which He speaks in My name, I will require it of him.

20. But the prophet who presumes to speak a word in My name, which I have not commanded him to speak, or who speaks in the name of other gods, that prophet shall die.'

21. And if you say in your heart, "How shall we know the word which the LORD has not spoken?'--

22. when a prophet speaks in the name of the LORD, if the thing does not happen or come to pass, that is the thing which the LORD has not spoken; the prophet has spoken it presumptuously; you shall not be afraid of him.

## Chapter 19

1. "When the LORD your God has cut off the nations whose land the LORD your God is giving you, and you dispossess them and dwell in their cities and in their houses,

2. you shall separate three cities for yourself in the midst of your land which the LORD your God is giving you to possess.

3. You shall prepare roads for yourself, and divide into three parts the territory of your land which the LORD your God is giving you to inherit, that any manslayer may flee there.

4. "And this is the case of the manslayer who flees there, that he may live: Whoever kills his neighbor unintentionally, not having hated him in time past--

5. as when a man goes to the woods with his neighbor to cut timber, and his hand swings a stroke with the ax to cut down the tree, and the head slips from the handle and strikes his neighbor so that he dies--he shall flee to one of these cities and live;

6. lest the avenger of blood, while his anger is hot, pursue the manslayer and overtake him, because the way is long, and kill him, though he was not deserving of death, since he had not hated the victim in time past.

7. Therefore I command you, saying, "You shall separate three cities for yourself.'

8. "Now if the LORD your God enlarges your territory, as He swore to your fathers, and gives you the land which He promised to give to your fathers,

9. and if you keep all these commandments and do them, which I command you today, to love the LORD your God and to walk always in His ways, then you shall add three more cities for yourself besides these three,

10. lest innocent blood be shed in the midst of your land which the LORD your God is giving you as an inheritance, and thus guilt of bloodshed be upon you.

11. "But if anyone hates his neighbor, lies in wait for him, rises against him and strikes him mortally, so that he dies, and he flees to one of these cities,

12. then the elders of his city shall send and bring him from there, and deliver him over to the hand of the avenger of blood, that he may die.

13. Your eye shall not pity him, but you shall put away the guilt of innocent blood from Israel, that it may go well with you.

14. "You shall not remove your neighbor's landmark, which the men of old have set, in your inheritance which you will inherit in the land that the LORD your God is giving you to possess.

15. "One witness shall not rise against a man concerning any iniquity or any sin that he commits; by the mouth of two or three witnesses the matter shall be established.

16. If a false witness rises against any man to testify against him of wrongdoing,

17. then both men in the controversy shall stand before the LORD, before the priests and the judges who serve in those days.

18. And the judges shall make careful inquiry, and indeed, if the witness is a false witness, who has testified falsely against his brother,

19. then you shall do to him as he thought to have done to his brother; so you shall put away the evil from among you.

20. And those who remain shall hear and fear, and hereafter they shall not again commit such evil among you.

21. Your eye shall not pity: life shall be for life, eye for eye, tooth for tooth, hand for hand, foot for foot.

## Chapter 20

1. "When you go out to battle against your enemies, and see horses and chariots and people more numerous than you, do not be afraid of them; for the LORD your God is with you, who brought you up from the land of Egypt.

2. So it shall be, when you are on the verge of battle, that the priest shall approach and speak to the people.

3. And he shall say to them, "Hear, O Israel: Today you are on the verge of battle with your enemies. Do not let your heart faint, do not be afraid, and do not tremble or be terrified because of them;

4. for the LORD your God is He who goes with you, to fight for you against your enemies, to save you.'

5. "Then the officers shall speak to the people, saying: "What man is there who has built a new house and has not dedicated it? Let him go and return to his house, lest he die in the battle and another man dedicate it.

6. Also what man is there who has planted a vineyard and has not eaten of it? Let him go and return to his house, lest he die in the battle and another man eat of it.

7. And what man is there who is betrothed to a woman and has not married her? Let him go and return to his house, lest he die in the battle and another man marry her.'

8. "The officers shall speak further to the people, and say, "What man is there who is fearful and fainthearted? Let him go and return to his house, lest the heart of his brethren faint like his heart.'

9. And so it shall be, when the officers have finished speaking to the people, that they shall make captains of the armies to lead the people.

10. "When you go near a city to fight against it, then proclaim an offer of peace to it.

11. And it shall be that if they accept your offer of peace, and open to you, then all the people who are found in it shall be placed under tribute to you, and serve you.

12. Now if the city will not make peace with you, but war against you, then you shall besiege it.

13. And when the LORD your God delivers it into your hands, you shall strike every male in it with the edge of the sword.

14. But the women, the little ones, the livestock, and all that is in the city, all its spoil, you shall plunder for yourself; and you shall eat the enemies' plunder which the LORD your God gives you.

15. Thus you shall do to all the cities which are very far from you, which are not of the cities of these nations.

16. "But of the cities of these peoples which the LORD your God gives you as an inheritance, you shall let nothing that breathes remain alive,

17. but you shall utterly destroy them: the Hittite and the Amorite and the Canaanite and the Perizzite and the Hivite and the Jebusite, just as the LORD your God has commanded you,

18. lest they teach you to do according to all their abominations which they have done for their gods, and you sin against the LORD your God.

19. "When you besiege a city for a long time, while making war against it to take it, you shall not destroy its trees by wielding an ax against them; if you can eat of them, do not cut them down to use in the siege, for the tree of the field is man's food.

20. Only the trees which you know are not trees for food you may destroy and cut down, to build siegeworks against the city that makes war with you, until it is subdued.

## Chapter 21

1. "If anyone is found slain, lying in the field in the land which the LORD your God is giving you to possess, and it is not known who killed him,

2. then your elders and your judges shall go out and measure the distance from the slain man to the surrounding cities.

3. And it shall be that the elders of the city nearest to the slain man will take a heifer which has not been worked and which has not pulled with a yoke.

4. The elders of that city shall bring the heifer down to a valley with flowing water, which is neither plowed nor sown, and they shall break the heifer's neck there in the valley.

5. Then the priests, the sons of Levi, shall come near, for the LORD your God has chosen them to minister to Him and to bless in the name of the LORD; by their word every controversy and every assault shall be settled.

6. And all the elders of that city nearest to the slain man shall wash their hands over the heifer whose neck was broken in the valley.

7. Then they shall answer and say, "Our hands have not shed this blood, nor have our eyes seen it.

8. Provide atonement, O LORD, for Your people Israel, whom You have redeemed, and do not lay innocent blood to the charge of Your people Israel.' And atonement shall be provided on their behalf for the blood.

9. So you shall put away the guilt of innocent blood from among you when you do what is right in the sight of the LORD.

10. "When you go out to war against your enemies, and the LORD your God delivers them into your hand, and you take them captive,

11. and you see among the captives a beautiful woman, and desire her and would take her for your wife,

12. then you shall bring her home to your house, and she shall shave her head and trim her nails.

13. She shall put off the clothes of her captivity, remain in your house, and mourn her father and her mother a full month; after that you may go in to her and be her husband, and she shall be your wife.

14. And it shall be, if you have no delight in her, then you shall set her free, but you certainly shall not sell her for money; you shall not treat her brutally, because you have humbled her.

15. "If a man has two wives, one loved and the other unloved, and they have borne him children, both the loved and the unloved, and if the firstborn son is of her who is unloved,

16. then it shall be, on the day he bequeaths his possessions to his sons, that he must not bestow firstborn status on the son of the loved wife in preference to the son of the unloved, the true firstborn.

17. But he shall acknowledge the son of the unloved wife as the firstborn by giving him a double portion of all that he has, for he is the beginning of his strength; the right of the firstborn is his.

18. "If a man has a stubborn and rebellious son who will not obey the voice of his father or the voice of his mother, and who, when they have chastened him, will not heed them,

19. then his father and his mother shall take hold of him and bring him out to the elders of his city, to the gate of his city.

20. And they shall say to the elders of his city, "This son of ours is stubborn and rebellious; he will not obey our voice; he is a glutton and a drunkard.'

21. Then all the men of his city shall stone him to death with stones; so you shall put away the evil from among you, and all Israel shall hear and fear.

22. "If a man has committed a sin deserving of death, and he is put to death, and you hang him on a tree,

23. his body shall not remain overnight on the tree, but you shall surely bury him that day, so that you do not defile the land which the LORD your God is giving you as an inheritance; for he who is hanged is accursed of God.

## Chapter 22

1. "You shall not see your brother's ox or his sheep going astray, and hide yourself from them; you shall certainly bring them back to your brother.

2. And if your brother is not near you, or if you do not know him, then you shall bring it to your own house, and it shall remain with you until your brother seeks it; then you shall restore it to him.

3. You shall do the same with his donkey, and so shall you do with his garment; with any lost thing of your brother's, which he has lost and you have found, you shall do likewise; you must not hide yourself.

4. "You shall not see your brother's donkey or his ox fall down along the road, and hide yourself from them; you shall surely help him lift them up again.

5. "A woman shall not wear anything that pertains to a man, nor shall a man put on a woman's garment, for all who do so are an abomination to the LORD your God.

6. "If a bird's nest happens to be before you along the way, in any tree or on the ground, with young ones or eggs, with the mother sitting on the young or on the eggs, you shall not take the mother with the young;

7. you shall surely let the mother go, and take the young for yourself, that it may be well with you and that you may prolong your days.

8. "When you build a new house, then you shall make a parapet for your roof, that you may not bring guilt of bloodshed on your household if anyone falls from it.

9. "You shall not sow your vineyard with different kinds of seed, lest the yield of the seed which you have sown and the fruit of your vineyard be defiled.

10. "You shall not plow with an ox and a donkey together.

11. "You shall not wear a garment of different sorts, such as wool and linen mixed together.

12. "You shall make tassels on the four corners of the clothing with which you cover yourself.

13. "If any man takes a wife, and goes in to her, and detests her,

14. and charges her with shameful conduct, and brings a bad name on her, and says, "I took this woman, and when I came to her I found she was not a virgin,'

15. then the father and mother of the young woman shall take and bring out the evidence of the young woman's virginity to the elders of the city at the gate.

16. And the young woman's father shall say to the elders, "I gave my daughter to this man as wife, and he detests her.

17. Now he has charged her with shameful conduct, saying, "I found your daughter was not a virgin," and yet these are the evidences of my daughter's virginity.' And they shall spread the cloth before the elders of the city.

18. Then the elders of that city shall take that man and punish him;

19. and they shall fine him one hundred shekels of silver and give them to the father of the young woman, because he has brought a bad name on a virgin of Israel. And she shall be his wife; he cannot divorce her all his days.

20. "But if the thing is true, and evidences of virginity are not found for the young woman,

21. then they shall bring out the young woman to the door of her father's house, and the men of her city shall stone her to death with stones, because she has done a disgraceful thing in Israel, to play the harlot in her father's house. So you shall put away the evil from among you.

22. "If a man is found lying with a woman married to a husband, then both of them shall die--the man that lay with the woman, and the woman; so you shall put away the evil from Israel.

23. "If a young woman who is a virgin is betrothed to a husband, and a man finds her in the city and lies with her,

24. then you shall bring them both out to the gate of that city, and you shall stone them to death with stones, the young woman because she did not cry out in the city, and the man because he humbled his neighbor's wife; so you shall put away the evil from among you.

25. "But if a man finds a betrothed young woman in the countryside, and the man forces her and lies with her, then only the man who lay with her shall die.

26. But you shall do nothing to the young woman; there is in the young woman no sin deserving of death, for just as when a man rises against his neighbor and kills him, even so is this matter.

27. For he found her in the countryside, and the betrothed young woman cried out, but there was no one to save her.

28. "If a man finds a young woman who is a virgin, who is not betrothed, and he seizes her and lies with her, and they are found out,

29. then the man who lay with her shall give to the young woman's father fifty shekels of silver, and she shall be his wife because he has humbled her; he shall not be permitted to divorce her all his days.

30. "A man shall not take his father's wife, nor uncover his father's bed.

## Chapter 23

1. "He who is emasculated by crushing or mutilation shall not enter the assembly of the LORD.

2. "One of illegitimate birth shall not enter the assembly of the LORD; even to the tenth generation none of his descendants shall enter the assembly of the LORD.

3. "An Ammonite or Moabite shall not enter the assembly of the LORD; even to the tenth generation none of his descendants shall enter the assembly of the LORD forever,

4. because they did not meet you with bread and water on the road when you came out of Egypt, and because they hired against you Balaam the son of Beor from Pethor of Mesopotamia, to curse you.

5. Nevertheless the LORD your God would not listen to Balaam, but the LORD your God turned the curse into a blessing for you, because the LORD your God loves you.

6. You shall not seek their peace nor their prosperity all your days forever.

7. "You shall not abhor an Edomite, for he is your brother. You shall not abhor an Egyptian, because you were an alien in his land.

8. The children of the third generation born to them may enter the assembly of the LORD.

9. "When the army goes out against your enemies, then keep yourself from every wicked thing.

10. If there is any man among you who becomes unclean by some occurrence in the night, then he shall go outside the camp; he shall not come inside the camp.

11. But it shall be, when evening comes, that he shall wash with water; and when the sun sets, he may come into the camp.

12. "Also you shall have a place outside the camp, where you may go out;

13. and you shall have an implement among your equipment, and when you sit down outside, you shall dig with it and turn and cover your refuse.

14. For the LORD your God walks in the midst of your camp, to deliver you and give your enemies over to you; therefore your camp shall be holy, that He may see no unclean thing among you, and turn away from you.

15. "You shall not give back to his master the slave who has escaped from his master to you.

16. He may dwell with you in your midst, in the place which he chooses within one of your gates, where it seems best to him; you shall not oppress him.

17. "There shall be no ritual harlot of the daughters of Israel, or a perverted one of the sons of Israel.

18. You shall not bring the wages of a harlot or the price of a dog to the house of the LORD your God for any vowed offering, for both of these are an abomination to the LORD your God.

19. "You shall not charge interest to your brother--interest on money or food or anything that is lent out at interest.

20. To a foreigner you may charge interest, but to your brother you shall not charge interest, that the LORD your God may bless you in all to which you set your hand in the land which you are entering to possess.

21. "When you make a vow to the LORD your God, you shall not delay to pay it; for the LORD your God will surely require it of you, and it would be sin to you.

22. But if you abstain from vowing, it shall not be sin to you.

23. That which has gone from your lips you shall keep and perform, for you voluntarily vowed to the LORD your God what you have promised with your mouth.

24. "When you come into your neighbor's vineyard, you may eat your fill of grapes at your pleasure, but you shall not put any in your container.

25. When you come into your neighbor's standing grain, you may pluck the heads with your hand, but you shall not use a sickle on your neighbor's standing grain.

## Chapter 24

1. "When a man takes a wife and marries her, and it happens that she finds no favor in his eyes because he has found some uncleanness in her, and he writes her a certificate of divorce, puts it in her hand, and sends her out of his house,

2. when she has departed from his house, and goes and becomes another man's wife,

3. if the latter husband detests her and writes her a certificate of divorce, puts it in her hand, and sends her out of his house, or if the latter husband dies who took her as his wife,

4. then her former husband who divorced her must not take her back to be his wife after she has been defiled; for that is an abomination before the LORD, and you shall not bring sin on the land which the LORD your God is giving you as an inheritance.

5. "When a man has taken a new wife, he shall not go out to war or be charged with any business; he shall be free at home one year, and bring happiness to his wife whom he has taken.

6. "No man shall take the lower or the upper millstone in pledge, for he takes one's living in pledge.

7. "If a man is found kidnapping any of his brethren of the children of Israel, and mistreats him or sells him, then that kidnapper shall die; and you shall put away the evil from among you.

8. "Take heed in an outbreak of leprosy, that you carefully observe and do according to all that the priests, the Levites, shall teach you; just as I commanded them, so you shall be careful to do.

9. Remember what the LORD your God did to Miriam on the way when you came out of Egypt!

10. "When you lend your brother anything, you shall not go into his house to get his pledge.

11. You shall stand outside, and the man to whom you lend shall bring the pledge out to you.

12. And if the man is poor, you shall not keep his pledge overnight.

13. You shall in any case return the pledge to him again when the sun goes down, that he may sleep in his own garment and bless you; and it shall be righteousness to you before the LORD your God.

14. "You shall not oppress a hired servant who is poor and needy, whether one of your brethren or one of the aliens who is in your land within your gates.

15. Each day you shall give him his wages, and not let the sun go down on it, for he is poor and has set his heart on it; lest he cry out against you to the LORD, and it be sin to you.

16. "Fathers shall not be put to death for their children, nor shall children be put to death for their fathers; a person shall be put to death for his own sin.

17. "You shall not pervert justice due the stranger or the fatherless, nor take a widow's garment as a pledge.

18. But you shall remember that you were a slave in Egypt, and the LORD your God redeemed you from there; therefore I command you to do this thing.

19. "When you reap your harvest in your field, and forget a sheaf in the field, you shall not go back to get it; it shall be for the stranger, the fatherless, and the widow, that the LORD your God may bless you in all the work of your hands.

20. When you beat your olive trees, you shall not go over the boughs again; it shall be for the stranger, the fatherless, and the widow.

21. When you gather the grapes of your vineyard, you shall not glean it afterward; it shall be for the stranger, the fatherless, and the widow.

22. And you shall remember that you were a slave in the land of Egypt; therefore I command you to do this thing.

## Chapter 25

1. "If there is a dispute between men, and they come to court, that the judges may judge them, and they justify the righteous and condemn the wicked,

2. then it shall be, if the wicked man deserves to be beaten, that the judge will cause him to lie down and be beaten in his presence, according to his guilt, with a certain number of blows.

3. Forty blows he may give him and no more, lest he should exceed this and beat him with many blows above these, and your brother be humiliated in your sight.

4. "You shall not muzzle an ox while it treads out the grain.

5. "If brothers dwell together, and one of them dies and has no son, the widow of the dead man shall not be married to a stranger outside the family; her husband's brother shall go in to her, take her as his wife, and perform the duty of a husband's brother to her.

6. And it shall be that the firstborn son which she bears will succeed to the name of his dead brother, that his name may not be blotted out of Israel.

7. But if the man does not want to take his brother's wife, then let his brother's wife go up to the gate to the elders, and say, "My husband's brother refuses to raise up a name to his brother in Israel; he will not perform the duty of my husband's brother.'

8. Then the elders of his city shall call him and speak to him. But if he stands firm and says, "I do not want to take her,'

9. then his brother's wife shall come to him in the presence of the elders, remove his sandal from his foot, spit in his face, and answer and say, "So shall it be done to the man who will not build up his brother's house.'

10. And his name shall be called in Israel, "The house of him who had his sandal removed.'

11. "If two men fight together, and the wife of one draws near to rescue her husband from the hand of the one attacking him, and puts out her hand and seizes him by the genitals,

12. then you shall cut off her hand; your eye shall not pity her.

13. "You shall not have in your bag differing weights, a heavy and a light.

14. You shall not have in your house differing measures, a large and a small.

15. You shall have a perfect and just weight, a perfect and just measure, that your days may be lengthened in the land which the LORD your God is giving you.

16. For all who do such things, all who behave unrighteously, are an abomination to the LORD your God.

17. "Remember what Amalek did to you on the way as you were coming out of Egypt,

18. how he met you on the way and attacked your rear ranks, all the stragglers at your rear, when you were tired and weary; and he did not fear God.

19. Therefore it shall be, when the LORD your God has given you rest from your enemies all around, in the land which the LORD your God is giving you to possess as an inheritance, that you will blot out the remembrance of Amalek from under heaven. You shall not forget.

## Chapter 26

1. "And it shall be, when you come into the land which the LORD your God is giving you as an inheritance, and you possess it and dwell in it,

2. that you shall take some of the first of all the produce of the ground, which you shall bring from your land that the LORD your God is giving you, and put it in a basket and go to the place where the LORD your God chooses to make His name abide.

3. And you shall go to the one who is priest in those days, and say to him, "I declare today to the LORD your God that I have come to the country which the LORD swore to our fathers to give us.'

4. "Then the priest shall take the basket out of your hand and set it down before the altar of the LORD your God.

5. And you shall answer and say before the LORD your God: "My father was a Syrian, about to perish, and he went down to Egypt and dwelt there, few in number; and there he became a nation, great, mighty, and populous.

6. But the Egyptians mistreated us, afflicted us, and laid hard bondage on us.

7. Then we cried out to the LORD God of our fathers, and the LORD heard our voice and looked on our affliction and our labor and our oppression.

8. So the LORD brought us out of Egypt with a mighty hand and with an outstretched arm, with great terror and with signs and wonders.

9. He has brought us to this place and has given us this land, "a land flowing with milk and honey";

10. and now, behold, I have brought the firstfruits of the land which you, O LORD, have given me.' "Then you shall set it before the LORD your God, and worship before the LORD your God.

11. So you shall rejoice in every good thing which the LORD your God has given to you and your house, you and the Levite and the stranger who is among you.

12. "When you have finished laying aside all the tithe of your increase in the third year--the year of tithing--and have given it to the Levite, the stranger, the fatherless, and the widow, so that they may eat within your gates and be filled,

13. then you shall say before the LORD your God: "I have removed the holy tithe from my house, and also have given them to the Levite, the stranger, the fatherless, and the widow, according to all Your commandments which You have commanded me; I have not transgressed Your commandments, nor have I forgotten them.

14. I have not eaten any of it when in mourning, nor have I removed any of it for an unclean use, nor given any of it for the dead. I have obeyed the voice of the LORD my God, and have done according to all that You have commanded me.

15. Look down from Your holy habitation, from heaven, and bless Your people Israel and the land which You have given us, just as You swore to our fathers, "a land flowing with milk and honey."'

16. "This day the LORD your God commands you to observe these statutes and judgments; therefore you shall be careful to observe them with all your heart and with all your soul.

17. Today you have proclaimed the LORD to be your God, and that you will walk in His ways and keep His statutes, His commandments, and His judgments, and that you will obey His voice.

18. Also today the LORD has proclaimed you to be His special people, just as He promised you, that you should keep all His commandments,

19. and that He will set you high above all nations which He has made, in praise, in name, and in honor, and that you may be a holy people to the LORD your God, just as He has spoken."

## Chapter 27

1. Now Moses, with the elders of Israel, commanded the people, saying: "Keep all the commandments which I command you today.

2. And it shall be, on the day when you cross over the Jordan to the land which the LORD your God is giving you, that you shall set up for yourselves large stones, and whitewash them with lime.

3. You shall write on them all the words of this law, when you have crossed over, that you may enter the land which the LORD your God is giving you, "a land flowing with milk and honey,' just as the LORD God of your fathers promised you.

4. Therefore it shall be, when you have crossed over the Jordan, that on Mount Ebal you shall set up these stones, which I command you today, and you shall whitewash them with lime.

5. And there you shall build an altar to the LORD your God, an altar of stones; you shall not use an iron tool on them.

6. You shall build with whole stones the altar of the LORD your God, and offer burnt offerings on it to the LORD your God.

7. You shall offer peace offerings, and shall eat there, and rejoice before the LORD your God.

8. And you shall write very plainly on the stones all the words of this law."

9. Then Moses and the priests, the Levites, spoke to all Israel, saying, "Take heed and listen, O Israel: This day you have become the people of the LORD your God.

10. Therefore you shall obey the voice of the LORD your God, and observe His commandments and His statutes which I command you today."

11. And Moses commanded the people on the same day, saying,

12. "These shall stand on Mount Gerizim to bless the people, when you have crossed over the Jordan: Simeon, Levi, Judah, Issachar, Joseph, and Benjamin;

13. and these shall stand on Mount Ebal to curse: Reuben, Gad, Asher, Zebulun, Dan, and Naphtali.

14. "And the Levites shall speak with a loud voice and say to all the men of Israel:

15. "Cursed is the one who makes a carved or molded image, an abomination to the LORD, the work of the hands of the craftsman, and sets it up in secret.' "And all the people shall answer and say, "Amen!'

16. "Cursed is the one who treats his father or his mother with contempt.' "And all the people shall say, "Amen!'

17. "Cursed is the one who moves his neighbor's landmark.' "And all the people shall say, "Amen!'

18. "Cursed is the one who makes the blind to wander off the road.' "And all the people shall say, "Amen!'

19. "Cursed is the one who perverts the justice due the stranger, the fatherless, and widow.' "And all the people shall say, "Amen!'

20. "Cursed is the one who lies with his father's wife, because he has uncovered his father's bed.' "And all the people shall say, "Amen!'

21. "Cursed is the one who lies with any kind of animal.' "And all the people shall say, "Amen!'

22. "Cursed is the one who lies with his sister, the daughter of his father or the daughter of his mother.' "And all the people shall say, "Amen!'

23. "Cursed is the one who lies with his mother-in-law.' "And all the people shall say, "Amen!'

24. "Cursed is the one who attacks his neighbor secretly.' "And all the people shall say, "Amen!'

25. "Cursed is the one who takes a bribe to slay an innocent person.' "And all the people shall say, "Amen!'

26. "Cursed is the one who does not confirm all the words of this law.' "And all the people shall say, "Amen!"'

## Chapter 28

1. "Now it shall come to pass, if you diligently obey the voice of the LORD your God, to observe carefully all His commandments which I command you today, that the LORD your God will set you high above all nations of the earth.

2. And all these blessings shall come upon you and overtake you, because you obey the voice of the LORD your God:

3. "Blessed shall you be in the city, and blessed shall you be in the country.

4. "Blessed shall be the fruit of your body, the produce of your ground and the increase of your herds, the increase of your cattle and the offspring of your flocks.

5. "Blessed shall be your basket and your kneading bowl.

6. "Blessed shall you be when you come in, and blessed shall you be when you go out.

7. "The LORD will cause your enemies who rise against you to be defeated before your face; they shall come out against you one way and flee before you seven ways.

8. "The LORD will command the blessing on you in your storehouses and in all to which you set your hand, and He will bless you in the land which the LORD your God is giving you.

9. "The LORD will establish you as a holy people to Himself, just as He has sworn to you, if you keep the commandments of the LORD your God and walk in His ways.

10. Then all peoples of the earth shall see that you are called by the name of the LORD, and they shall be afraid of you.

11. And the LORD will grant you plenty of goods, in the fruit of your body, in the increase of your livestock, and in the produce of your ground, in the land of which the LORD swore to your fathers to give you.

12. The LORD will open to you His good treasure, the heavens, to give the rain to your land in its season, and to bless all the work of your hand. You shall lend to many nations, but you shall not borrow.

13. And the LORD will make you the head and not the tail; you shall be above only, and not be beneath, if you heed the commandments of the LORD your God, which I command you today, and are careful to observe them.

14. So you shall not turn aside from any of the words which I command you this day, to the right or the left, to go after other gods to serve them.

15. "But it shall come to pass, if you do not obey the voice of the LORD your God, to observe carefully all His commandments and His statutes which I command you today, that all these curses will come upon you and overtake you:

16. "Cursed shall you be in the city, and cursed shall you be in the country.

17. "Cursed shall be your basket and your kneading bowl.

18. "Cursed shall be the fruit of your body and the produce of your land, the increase of your cattle and the offspring of your flocks.

19. "Cursed shall you be when you come in, and cursed shall you be when you go out.

20. "The LORD will send on you cursing, confusion, and rebuke in all that you set your hand to do, until you are destroyed and until you perish quickly, because of the wickedness of your doings in which you have forsaken Me.

21. The LORD will make the plague cling to you until He has consumed you from the land which you are going to possess.

22. The LORD will strike you with consumption, with fever, with inflammation, with severe burning fever, with the sword, with scorching, and with mildew; they shall pursue you until you perish.

23. And your heavens which are over your head shall be bronze, and the earth which is under you shall be iron.

24. The LORD will change the rain of your land to powder and dust; from the heaven it shall come down on you until you are destroyed.

25. "The LORD will cause you to be defeated before your enemies; you shall go out one way against them and flee seven ways before them; and you shall become troublesome to all the kingdoms of the earth.

26. Your carcasses shall be food for all the birds of the air and the beasts of the earth, and no one shall frighten them away.

27. The LORD will strike you with the boils of Egypt, with tumors, with the scab, and with the itch, from which you cannot be healed.

28. The LORD will strike you with madness and blindness and confusion of heart.

29. And you shall grope at noonday, as a blind man gropes in darkness; you shall not prosper in your ways; you shall be only oppressed and plundered continually, and no one shall save you.

30. "You shall betroth a wife, but another man shall lie with her; you shall build a house, but you shall not dwell in it; you shall plant a vineyard, but shall not gather its grapes.

31. Your ox shall be slaughtered before your eyes, but you shall not eat of it; your donkey shall be violently taken away from before you, and shall not be restored to you; your sheep shall be given to your enemies, and you shall have no one to rescue them.

32. Your sons and your daughters shall be given to another people, and your eyes shall look and fail with longing for them all day long; and there shall be no strength in your hand.

33. A nation whom you have not known shall eat the fruit of your land and the produce of your labor, and you shall be only oppressed and crushed continually.

34. So you shall be driven mad because of the sight which your eyes see.

35. The LORD will strike you in the knees and on the legs with severe boils which cannot be healed, and from the sole of your foot to the top of your head.

36. "The LORD will bring you and the king whom you set over you to a nation which neither you nor your fathers have known, and there you shall serve other gods--wood and stone.

37. And you shall become an astonishment, a proverb, and a byword among all nations where the LORD will drive you.

38. "You shall carry much seed out to the field but gather little in, for the locust shall consume it.

39. You shall plant vineyards and tend them, but you shall neither drink of the wine nor gather the grapes; for the worms shall eat them.

40. You shall have olive trees throughout all your territory, but you shall not anoint yourself with the oil; for your olives shall drop off.

41. You shall beget sons and daughters, but they shall not be yours; for they shall go into captivity.

42. Locusts shall consume all your trees and the produce of your land.

43. "The alien who is among you shall rise higher and higher above you, and you shall come down lower and lower.

44. He shall lend to you, but you shall not lend to him; he shall be the head, and you shall be the tail.

45. "Moreover all these curses shall come upon you and pursue and overtake you, until you are destroyed, because you did not obey the voice of the LORD your God, to keep His commandments and His statutes which He commanded you.

46. And they shall be upon you for a sign and a wonder, and on your descendants forever.

47. "Because you did not serve the LORD your God with joy and gladness of heart, for the abundance of everything,

48. therefore you shall serve your enemies, whom the LORD will send against you, in hunger, in thirst, in nakedness, and in need of everything; and He will put a yoke of iron on your neck until He has destroyed you.

49. The LORD will bring a nation against you from afar, from the end of the earth, as swift as the eagle flies, a nation whose language you will not understand,

50. a nation of fierce countenance, which does not respect the elderly nor show favor to the young.

51. And they shall eat the increase of your livestock and the produce of your land, until you are destroyed; they shall not leave you grain or new wine or oil, or the increase of your cattle or the offspring of your flocks, until they have destroyed you.

52. "They shall besiege you at all your gates until your high and fortified walls, in which you trust, come down throughout all your land; and they shall besiege you at all your gates throughout all your land which the LORD your God has given you.

53. You shall eat the fruit of your own body, the flesh of your sons and your daughters whom the LORD your God has given you, in the siege and desperate straits in which your enemy shall distress you.

54. The sensitive and very refined man among you will be hostile toward his brother, toward the wife of his bosom, and toward the rest of his children whom he leaves behind,

55. so that he will not give any of them the flesh of his children whom he will eat, because he has nothing left in the siege and desperate straits in which your enemy shall distress you at all your gates.

56. The tender and delicate woman among you, who would not venture to set the sole of her foot on the ground because of her delicateness and sensitivity, will refuse to the husband of her bosom, and to her son and her daughter,

57. her placenta which comes out from between her feet and her children whom she bears; for she will eat them secretly for lack of everything in the siege and desperate straits in which your enemy shall distress you at all your gates.

58. "If you do not carefully observe all the words of this law that are written in this book, that you may fear this glorious and awesome name, THE LORD YOUR GOD,

59. then the LORD will bring upon you and your descendants extraordinary plagues--great and prolonged plagues--and serious and prolonged sicknesses.

60. Moreover He will bring back on you all the diseases of Egypt, of which you were afraid, and they shall cling to you.

61. Also every sickness and every plague, which is not written in this Book of the Law, will the LORD bring upon you until you are destroyed.

62. You shall be left few in number, whereas you were as the stars of heaven in multitude, because you would not obey the voice of the LORD your God.

63. And it shall be, that just as the LORD rejoiced over you to do you good and multiply you, so the LORD will rejoice over you to destroy you and bring you to nothing; and you shall be plucked from off the land which you go to possess.

64. "Then the LORD will scatter you among all peoples, from one end of the earth to the other, and there you shall serve other gods, which neither you nor your fathers have known--wood and stone.

65. And among those nations you shall find no rest, nor shall the sole of your foot have a resting place; but there the LORD will give you a trembling heart, failing eyes, and anguish of soul.

66. Your life shall hang in doubt before you; you shall fear day and night, and have no assurance of life.

67. In the morning you shall say, "Oh, that it were evening!' And at evening you shall say, "Oh, that it were morning!' because of the fear which terrifies your heart, and because of the sight which your eyes see.

68. "And the LORD will take you back to Egypt in ships, by the way of which I said to you, "You shall never see it again.' And there you shall be offered for sale to your enemies as male and female slaves, but no one will buy you."

## Chapter 29

1. These are the words of the covenant which the LORD commanded Moses to make with the children of Israel in the land of Moab, besides the covenant which He made with them in Horeb.

2. Now Moses called all Israel and said to them: "You have seen all that the LORD did before your eyes in the land of Egypt, to Pharaoh and to all his servants and to all his land--

3. the great trials which your eyes have seen, the signs, and those great wonders.

4. Yet the LORD has not given you a heart to perceive and eyes to see and ears to hear, to this very day.

5. And I have led you forty years in the wilderness. Your clothes have not worn out on you, and your sandals have not worn out on your feet.

6. You have not eaten bread, nor have you drunk wine or similar drink, that you may know that I am the LORD your God.

7. And when you came to this place, Sihon king of Heshbon and Og king of Bashan came out against us to battle, and we conquered them.

8. We took their land and gave it as an inheritance to the Reubenites, to the Gadites, and to half the tribe of Manasseh.

9. Therefore keep the words of this covenant, and do them, that you may prosper in all that you do.

10. "All of you stand today before the LORD your God: your leaders and your tribes and your elders and your officers, all the men of Israel,

11. your little ones and your wives--also the stranger who is in your camp, from the one who cuts your wood to the one who draws your water--

12. that you may enter into covenant with the LORD your God, and into His oath, which the LORD your God makes with you today,

13. that He may establish you today as a people for Himself, and that He may be God to you, just as He has spoken to you, and just as He has sworn to your fathers, to Abraham, Isaac, and Jacob.

14. "I make this covenant and this oath, not with you alone,

15. but with him who stands here with us today before the LORD our God, as well as with him who is not here with us today

16. (for you know that we dwelt in the land of Egypt and that we came through the nations which you passed by,

17. and you saw their abominations and their idols which were among them--wood and stone and silver and gold);

18. so that there may not be among you man or woman or family or tribe, whose heart turns away today from the LORD our God, to go and serve the gods of these nations, and that there may not be among you a root bearing bitterness or wormwood;

19. and so it may not happen, when he hears the words of this curse, that he blesses himself in his heart, saying, "I shall have peace, even though I follow the dictates of my heart'--as though the drunkard could be included with the sober.

20. "The LORD would not spare him; for then the anger of the LORD and His jealousy would burn against that man, and every curse that is written in this book would settle on him, and the LORD would blot out his name from under heaven.

21. And the LORD would separate him from all the tribes of Israel for adversity, according to all the curses of the covenant that are written in this Book of the Law,

22. so that the coming generation of your children who rise up after you, and the foreigner who comes from a far land, would say, when they see the plagues of that land and the sicknesses which the LORD has laid on it:

23. "The whole land is brimstone, salt, and burning; it is not sown, nor does it bear, nor does any grass grow there, like the overthrow of Sodom and Gomorrah, Admah, and Zeboiim, which the LORD overthrew in His anger and His wrath.'

24. All nations would say, "Why has the LORD done so to this land? What does the heat of this great anger mean?'

25. Then people would say: "Because they have forsaken the covenant of the LORD God of their fathers, which He made with them when He brought them out of the land of Egypt;

26. for they went and served other gods and worshiped them, gods that they did not know and that He had not given to them.

27. Then the anger of the LORD was aroused against this land, to bring on it every curse that is written in this book.

28. And the LORD uprooted them from their land in anger, in wrath, and in great indignation, and cast them into another land, as it is this day.'

29. "The secret things belong to the LORD our God, but those things which are revealed belong to us and to our children forever, that we may do all the words of this law.

## Chapter 30

1. "Now it shall come to pass, when all these things come upon you, the blessing and the curse which I have set before you, and you call them to mind among all the nations where the LORD your God drives you,

2. and you return to the LORD your God and obey His voice, according to all that I command you today, you and your children, with all your heart and with all your soul,

3. that the LORD your God will bring you back from captivity, and have compassion on you, and gather you again from all the nations where the LORD your God has scattered you.

4. If any of you are driven out to the farthest parts under heaven, from there the LORD your God will gather you, and from there He will bring you.

5. Then the LORD your God will bring you to the land which your fathers possessed, and you shall possess it. He will prosper you and multiply you more than your fathers.

6. And the LORD your God will circumcise your heart and the heart of your descendants, to love the LORD your God with all your heart and with all your soul, that you may live.

7. "Also the LORD your God will put all these curses on your enemies and on those who hate you, who persecuted you.

8. And you will again obey the voice of the LORD and do all His commandments which I command you today.

9. The LORD your God will make you abound in all the work of your hand, in the fruit of your body, in the increase of your livestock, and in the produce of your land for good. For the LORD will again rejoice over you for good as He rejoiced over your fathers,

10. if you obey the voice of the LORD your God, to keep His commandments and His statutes which are written in this Book of the Law, and if you turn to the LORD your God with all your heart and with all your soul.

11. "For this commandment which I command you today is not too mysterious for you, nor is it far off.

12. It is not in heaven, that you should say, "Who will ascend into heaven for us and bring it to us, that we may hear it and do it?'

13. Nor is it beyond the sea, that you should say, "Who will go over the sea for us and bring it to us, that we may hear it and do it?'

14. But the word is very near you, in your mouth and in your heart, that you may do it.

15. "See, I have set before you today life and good, death and evil,

16. in that I command you today to love the LORD your God, to walk in His ways, and to keep His commandments, His statutes, and His judgments, that you may live and multiply; and the LORD your God will bless you in the land which you go to possess.

17. But if your heart turns away so that you do not hear, and are drawn away, and worship other gods and serve them,

18. I announce to you today that you shall surely perish; you shall not prolong your days in the land which you cross over the Jordan to go in and possess.

19. I call heaven and earth as witnesses today against you, that I have set before you life and death, blessing and cursing; therefore choose life, that both you and your descendants may live;

20. that you may love the LORD your God, that you may obey His voice, and that you may cling to Him, for He is your life and the length of your days; and that you may dwell in the land which the LORD swore to your fathers, to Abraham, Isaac, and Jacob, to give them."

## Chapter 31

1. Then Moses went and spoke these words to all Israel.

2. And he said to them: "I am one hundred and twenty years old today. I can no longer go out and come in. Also the LORD has said to me, "You shall not cross over this Jordan.'

3. The LORD your God Himself crosses over before you; He will destroy these nations from before you, and you shall dispossess them. Joshua himself crosses over before you, just as the LORD has said.

4. And the LORD will do to them as He did to Sihon and Og, the kings of the Amorites and their land, when He destroyed them.

5. The LORD will give them over to you, that you may do to them according to every commandment which I have commanded you.

6. Be strong and of good courage, do not fear nor be afraid of them; for the LORD your God, He is the One who goes with you. He will not leave you nor forsake you."

7. Then Moses called Joshua and said to him in the sight of all Israel, "Be strong and of good courage, for you must go with this people to the land which the LORD has sworn to their fathers to give them, and you shall cause them to inherit it.

8. And the LORD, He is the One who goes before you. He will be with you, He will not leave you nor forsake you; do not fear nor be dismayed."

9. So Moses wrote this law and delivered it to the priests, the sons of Levi, who bore the ark of the covenant of the LORD, and to all the elders of Israel.

10. And Moses commanded them, saying: "At the end of every seven years, at the appointed time in the year of release, at the Feast of Tabernacles,

11. when all Israel comes to appear before the LORD your God in the place which He chooses, you shall read this law before all Israel in their hearing.

12. Gather the people together, men and women and little ones, and the stranger who is within your gates, that they may hear and that they may learn to fear the LORD your God and carefully observe all the words of this law,

13. and that their children, who have not known it, may hear and learn to fear the LORD your God as long as you live in the land which you cross the Jordan to possess."

14. Then the LORD said to Moses, "Behold, the days approach when you must die; call Joshua, and present yourselves in the tabernacle of meeting, that I may inaugurate him." So Moses and Joshua went and presented themselves in the tabernacle of meeting.

15. Now the LORD appeared at the tabernacle in a pillar of cloud, and the pillar of cloud stood above the door of the tabernacle.

16. And the LORD said to Moses: "Behold, you will rest with your fathers; and this people will rise and play the harlot with the gods of the foreigners of the land, where they go to be among them, and they will forsake Me and break My covenant which I have made with them.

17. Then My anger shall be aroused against them in that day, and I will forsake them, and I will hide My face from them, and they shall be devoured. And many evils and troubles shall befall them, so that they will say in that day, "Have not these evils come upon us because our God is not among us?'

18. And I will surely hide My face in that day because of all the evil which they have done, in that they have turned to other gods.

19. "Now therefore, write down this song for yourselves, and teach it to the children of Israel; put it in their mouths, that this song may be a witness for Me against the children of Israel.

20. When I have brought them to the land flowing with milk and honey, of which I swore to their fathers, and they have eaten and filled themselves and grown fat, then they will turn to other gods and serve them; and they will provoke Me and break My covenant.

21. Then it shall be, when many evils and troubles have come upon them, that this song will testify against them as a witness; for it will not be forgotten in the mouths of their descendants, for I know the inclination of their behavior today, even before I have brought them to the land of which I swore to give them."

22. Therefore Moses wrote this song the same day, and taught it to the children of Israel.

23. Then He inaugurated Joshua the son of Nun, and said, "Be strong and of good courage; for you shall bring the children of Israel into the land of which I swore to them, and I will be with you."

24. So it was, when Moses had completed writing the words of this law in a book, when they were finished,

25. that Moses commanded the Levites, who bore the ark of the covenant of the LORD, saying:

26. "Take this Book of the Law, and put it beside the ark of the covenant of the LORD your God, that it may be there as a witness against you;

27. for I know your rebellion and your stiff neck. If today, while I am yet alive with you, you have been rebellious against the LORD, then how much more after my death?

28. Gather to me all the elders of your tribes, and your officers, that I may speak these words in their hearing and call heaven and earth to witness against them.

29. For I know that after my death you will become utterly corrupt, and turn aside from the way which I have commanded you. And evil will befall you in the latter days, because you will do evil in the sight of the LORD, to provoke Him to anger through the work of your hands."

30. Then Moses spoke in the hearing of all the assembly of Israel the words of this song until they were ended:

## Chapter 32

1. "Give ear, O heavens, and I will speak; And hear, O earth, the words of my mouth.

2. Let my teaching drop as the rain, My speech distill as the dew, As raindrops on the tender herb, And as showers on the grass.

3. For I proclaim the name of the LORD: Ascribe greatness to our God.

4. He is the Rock, His work is perfect; For all His ways are justice, A God of truth and without injustice; Righteous and upright is He.

5. "They have corrupted themselves; They are not His children, Because of their blemish: A perverse and crooked generation.

6. Do you thus deal with the LORD, O foolish and unwise people? Is He not your Father, who bought you? Has He not made you and established you?

7. "Remember the days of old, Consider the years of many generations. Ask your father, and he will show you; Your elders, and they will tell you:

8. When the Most High divided their inheritance to the nations, When He separated the sons of Adam, He set the boundaries of the peoples According to the number of the children of Israel.

9. For the LORD's portion is His people; Jacob is the place of His inheritance.

10. "He found him in a desert land And in the wasteland, a howling wilderness; He encircled him, He instructed him, He kept him as the apple of His eye.

11. As an eagle stirs up its nest, Hovers over its young, Spreading out its wings, taking them up, Carrying them on its wings,

12. So the LORD alone led him, And there was no foreign god with him.

13. "He made him ride in the heights of the earth, That he might eat the produce of the fields; He made him draw honey from the rock, And oil from the flinty rock;

14. Curds from the cattle, and milk of the flock, With fat of lambs; And rams of the breed of Bashan, and goats, With the choicest wheat; And you drank wine, the blood of the grapes.

15. "But Jeshurun grew fat and kicked; You grew fat, you grew thick, You are obese! Then he forsook God who made him, And scornfully esteemed the Rock of his salvation.

16. They provoked Him to jealousy with foreign gods; With abominations they provoked Him to anger.

17. They sacrificed to demons, not to God, To gods they did not know, To new gods, new arrivals That your fathers did not fear.

18. Of the Rock who begot you, you are unmindful, And have forgotten the God who fathered you.

19. "And when the LORD saw it, He spurned them, Because of the provocation of His sons and His daughters.

20. And He said: "I will hide My face from them, I will see what their end will be, For they are a perverse generation, Children in whom is no faith.

21. They have provoked Me to jealousy by what is not God; They have moved Me to anger by their foolish idols. But I will provoke them to jealousy by those who are not a nation; I will move them to anger by a foolish nation.

22. For a fire is kindled in My anger, And shall burn to the lowest hell; It shall consume the earth with her increase, And set on fire the foundations of the mountains.

23. "I will heap disasters on them; I will spend My arrows on them.

24. They shall be wasted with hunger, Devoured by pestilence and bitter destruction; I will also send against them the teeth of beasts, With the poison of serpents of the dust.

25. The sword shall destroy outside; There shall be terror within For the young man and virgin, The nursing child with the man of gray hairs.

26. I would have said, "I will dash them in pieces, I will make the memory of them to cease from among men,"

27. Had I not feared the wrath of the enemy, Lest their adversaries should misunderstand, Lest they should say, "Our hand is high; And it is not the LORD who has done all this."'

28. "For they are a nation void of counsel, Nor is there any understanding in them.

29. Oh, that they were wise, that they understood this, That they would consider their latter end!

30. How could one chase a thousand, And two put ten thousand to flight, Unless their Rock had sold them, And the LORD had surrendered them?

31. For their rock is not like our Rock, Even our enemies themselves being judges.

32. For their vine is of the vine of Sodom And of the fields of Gomorrah; Their grapes are grapes of gall, Their clusters are bitter.

33. Their wine is the poison of serpents, And the cruel venom of cobras.

34. "Is this not laid up in store with Me, Sealed up among My treasures?

35. Vengeance is Mine, and recompense; Their foot shall slip in due time; For the day of their calamity is at hand, And the things to come hasten upon them.'

36. "For the LORD will judge His people And have compassion on His servants, When He sees that their power is gone, And there is no one remaining, bond or free.

37. He will say: "Where are their gods, The rock in which they sought refuge?

38. Who ate the fat of their sacrifices, And drank the wine of their drink offering? Let them rise and help you, And be your refuge.

39. "Now see that I, even I, am He, And there is no God besides Me; I kill and I make alive; I wound and I heal; Nor is there any who can deliver from My hand.

40. For I raise My hand to heaven, And say, "As I live forever,

41. If I whet My glittering sword, And My hand takes hold on judgment, I will render vengeance to My enemies, And repay those who hate Me.

42. I will make My arrows drunk with blood, And My sword shall devour flesh, With the blood of the slain and the captives, From the heads of the leaders of the enemy."'

43. "Rejoice, O Gentiles, with His people; For He will avenge the blood of His servants, And render vengeance to His adversaries; He will provide atonement for His land and His people."

44. So Moses came with Joshua the son of Nun and spoke all the words of this song in the hearing of the people.

45. Moses finished speaking all these words to all Israel,

46. and he said to them: "Set your hearts on all the words which I testify among you today, which you shall command your children to be careful to observe--all the words of this law.

47. For it is not a futile thing for you, because it is your life, and by this word you shall prolong your days in the land which you cross over the Jordan to possess."

48. Then the LORD spoke to Moses that very same day, saying:

49. "Go up this mountain of the Abarim, Mount Nebo, which is in the land of Moab, across from Jericho; view the land of Canaan, which I give to the children of Israel as a possession;

50. and die on the mountain which you ascend, and be gathered to your people, just as Aaron your brother died on Mount Hor and was gathered to his people;

51. because you trespassed against Me among the children of Israel at the waters of Meribah Kadesh, in the Wilderness of Zin, because you did not hallow Me in the midst of the children of Israel.

52. Yet you shall see the land before you, though you shall not go there, into the land which I am giving to the children of Israel."

## Chapter 33

1. Now this is the blessing with which Moses the man of God blessed the children of Israel before his death.

2. And he said: "The LORD came from Sinai, And dawned on them from Seir; He shone forth from Mount Paran, And He came with ten thousands of saints; From His right hand Came a fiery law for them.

3. Yes, He loves the people; All His saints are in Your hand; They sit down at Your feet; everyone receives Your words.

4. Moses commanded a law for us, A heritage of the congregation of Jacob.

5. And He was King in Jeshurun, When the leaders of the people were gathered, All the tribes of Israel together.

6. "Let Reuben live, and not die, Nor let his men be few."

7. And this he said of Judah: "Hear, LORD, the voice of Judah, And bring him to his people; Let his hands be sufficient for him, And may You be a help against his enemies."

8. And of Levi he said: "Let Your Thummim and Your Urim be with Your holy one, Whom You tested at Massah, And with whom You contended at the waters of Meribah,

9. Who says of his father and mother, "I have not seen them'; Nor did he acknowledge his brothers, Or know his own children; For they have observed Your word And kept Your covenant.

10. They shall teach Jacob Your judgments, And Israel Your law. They shall put incense before You, And a whole burnt sacrifice on Your altar.

11. Bless his substance, LORD, And accept the work of his hands; Strike the loins of those who rise against him, And of those who hate him, that they rise not again."

12. Of Benjamin he said: "The beloved of the LORD shall dwell in safety by Him, Who shelters him all the day long; And he shall dwell between His shoulders."

13. And of Joseph he said: "Blessed of the LORD is his land, With the precious things of heaven, with the dew, And the deep lying beneath,

14. With the precious fruits of the sun, With the precious produce of the months,

15. With the best things of the ancient mountains, With the precious things of the everlasting hills,

16. With the precious things of the earth and its fullness, And the favor of Him who dwelt in the bush. Let the blessing come "on the head of Joseph, And on the crown of the head of him who was separate from his brothers.'

17. His glory is like a firstborn bull, And his horns like the horns of the wild ox; Together with them He shall push the peoples To the ends of the earth; They are the ten thousands of Ephraim, And they are the thousands of Manasseh."

18. And of Zebulun he said: "Rejoice, Zebulun, in your going out, And Issachar in your tents!

19. They shall call the peoples to the mountain; There they shall offer sacrifices of righteousness; For they shall partake of the abundance of the seas And of treasures hidden in the sand."

20. And of Gad he said: "Blessed is he who enlarges Gad; He dwells as a lion, And tears the arm and the crown of his head.

21. He provided the first part for himself, Because a lawgiver's portion was reserved there. He came with the heads of the people; He administered the justice of the LORD, And His judgments with Israel."

22. And of Dan he said: "Dan is a lion's whelp; He shall leap from Bashan."

23. And of Naphtali he said: "O Naphtali, satisfied with favor, And full of the blessing of the LORD, Possess the west and the south."

24. And of Asher he said: "Asher is most blessed of sons; Let him be favored by his brothers, And let him dip his foot in oil.

25. Your sandals shall be iron and bronze; As your days, so shall your strength be.

26. "There is no one like the God of Jeshurun, Who rides the heavens to help you, And in His excellency on the clouds.

27. The eternal God is your refuge, And underneath are the everlasting arms; He will thrust out the enemy from before you, And will say, "Destroy!'

28. Then Israel shall dwell in safety, The fountain of Jacob alone, In a land of grain and new wine; His heavens shall also drop dew.

29. Happy are you, O Israel! Who is like you, a people saved by the LORD, The shield of your help And the sword of your majesty! Your enemies shall submit to you, And you shall tread down their high places."

## Chapter 34

1. Then Moses went up from the plains of Moab to Mount Nebo, to the top of Pisgah, which is across from Jericho. And the LORD showed him all the land of Gilead as far as Dan,

2. all Naphtali and the land of Ephraim and Manasseh, all the land of Judah as far as the Western Sea,

3. the South, and the plain of the Valley of Jericho, the city of palm trees, as far as Zoar.

4. Then the LORD said to him, "This is the land of which I swore to give Abraham, Isaac, and Jacob, saying, "I will give it to your descendants.' I have caused you to see it with your eyes, but you shall not cross over there."

5. So Moses the servant of the LORD died there in the land of Moab, according to the word of the LORD.

6. And He buried him in a valley in the land of Moab, opposite Beth Peor; but no one knows his grave to this day.

7. Moses was one hundred and twenty years old when he died. His eyes were not dim nor his natural vigor diminished.

8. And the children of Israel wept for Moses in the plains of Moab thirty days. So the days of weeping and mourning for Moses ended.

9. Now Joshua the son of Nun was full of the spirit of wisdom, for Moses had laid his hands on him; so the children of Israel heeded him, and did as the LORD had commanded Moses.

10. But since then there has not arisen in Israel a prophet like Moses, whom the LORD knew face to face,

11. in all the signs and wonders which the LORD sent him to do in the land of Egypt, before Pharaoh, before all his servants, and in all his land,

12. and by all that mighty power and all the great terror which Moses performed in the sight of all Israel.


# exodus

## Chapter 1

1. Now these are the names of the children of Israel who came to Egypt; each man and his household came with Jacob:

2. Reuben, Simeon, Levi, and Judah;

3. Issachar, Zebulun, and Benjamin;

4. Dan, Naphtali, Gad, and Asher.

5. All those who were descendants of Jacob were seventy persons (for Joseph was in Egypt already).

6. And Joseph died, all his brothers, and all that generation.

7. But the children of Israel were fruitful and increased abundantly, multiplied and grew exceedingly mighty; and the land was filled with them.

8. Now there arose a new king over Egypt, who did not know Joseph.

9. And he said to his people, "Look, the people of the children of Israel are more and mightier than we;

10. come, let us deal shrewdly with them, lest they multiply, and it happen, in the event of war, that they also join our enemies and fight against us, and so go up out of the land."

11. Therefore they set taskmasters over them to afflict them with their burdens. And they built for Pharaoh supply cities, Pithom and Raamses.

12. But the more they afflicted them, the more they multiplied and grew. And they were in dread of the children of Israel.

13. So the Egyptians made the children of Israel serve with rigor.

14. And they made their lives bitter with hard bondage--in mortar, in brick, and in all manner of service in the field. All their service in which they made them serve was with rigor.

15. Then the king of Egypt spoke to the Hebrew midwives, of whom the name of one was Shiphrah and the name of the other Puah;

16. and he said, "When you do the duties of a midwife for the Hebrew women, and see them on the birthstools, if it is a son, then you shall kill him; but if it is a daughter, then she shall live."

17. But the midwives feared God, and did not do as the king of Egypt commanded them, but saved the male children alive.

18. So the king of Egypt called for the midwives and said to them, "Why have you done this thing, and saved the male children alive?"

19. And the midwives said to Pharaoh, "Because the Hebrew women are not like the Egyptian women; for they are lively and give birth before the midwives come to them."

20. Therefore God dealt well with the midwives, and the people multiplied and grew very mighty.

21. And so it was, because the midwives feared God, that He provided households for them.

22. So Pharaoh commanded all his people, saying, "Every son who is born you shall cast into the river, and every daughter you shall save alive."

## Chapter 2

1. And a man of the house of Levi went and took as wife a daughter of Levi.

2. So the woman conceived and bore a son. And when she saw that he was a beautiful child, she hid him three months.

3. But when she could no longer hide him, she took an ark of bulrushes for him, daubed it with asphalt and pitch, put the child in it, and laid it in the reeds by the river's bank.

4. And his sister stood afar off, to know what would be done to him.

5. Then the daughter of Pharaoh came down to bathe at the river. And her maidens walked along the riverside; and when she saw the ark among the reeds, she sent her maid to get it.

6. And when she opened it, she saw the child, and behold, the baby wept. So she had compassion on him, and said, "This is one of the Hebrews' children."

7. Then his sister said to Pharaoh's daughter, "Shall I go and call a nurse for you from the Hebrew women, that she may nurse the child for you?"

8. And Pharaoh's daughter said to her, "Go." So the maiden went and called the child's mother.

9. Then Pharaoh's daughter said to her, "Take this child away and nurse him for me, and I will give you your wages." So the woman took the child and nursed him.

10. And the child grew, and she brought him to Pharaoh's daughter, and he became her son. So she called his name Moses, saying, "Because I drew him out of the water."

11. Now it came to pass in those days, when Moses was grown, that he went out to his brethren and looked at their burdens. And he saw an Egyptian beating a Hebrew, one of his brethren.

12. So he looked this way and that way, and when he saw no one, he killed the Egyptian and hid him in the sand.

13. And when he went out the second day, behold, two Hebrew men were fighting, and he said to the one who did the wrong, "Why are you striking your companion?"

14. Then he said, "Who made you a prince and a judge over us? Do you intend to kill me as you killed the Egyptian?" So Moses feared and said, "Surely this thing is known!"

15. When Pharaoh heard of this matter, he sought to kill Moses. But Moses fled from the face of Pharaoh and dwelt in the land of Midian; and he sat down by a well.

16. Now the priest of Midian had seven daughters. And they came and drew water, and they filled the troughs to water their father's flock.

17. Then the shepherds came and drove them away; but Moses stood up and helped them, and watered their flock.

18. When they came to Reuel their father, he said, "How is it that you have come so soon today?"

19. And they said, "An Egyptian delivered us from the hand of the shepherds, and he also drew enough water for us and watered the flock."

20. So he said to his daughters, "And where is he? Why is it that you have left the man? Call him, that he may eat bread."

21. Then Moses was content to live with the man, and he gave Zipporah his daughter to Moses.

22. And she bore him a son. He called his name Gershom, for he said, "I have been a stranger in a foreign land."

23. Now it happened in the process of time that the king of Egypt died. Then the children of Israel groaned because of the bondage, and they cried out; and their cry came up to God because of the bondage.

24. So God heard their groaning, and God remembered His covenant with Abraham, with Isaac, and with Jacob.

25. And God looked upon the children of Israel, and God acknowledged them.

## Chapter 3

1. Now Moses was tending the flock of Jethro his father-in-law, the priest of Midian. And he led the flock to the back of the desert, and came to Horeb, the mountain of God.

2. And the Angel of the LORD appeared to him in a flame of fire from the midst of a bush. So he looked, and behold, the bush was burning with fire, but the bush was not consumed.

3. Then Moses said, "I will now turn aside and see this great sight, why the bush does not burn."

4. So when the LORD saw that he turned aside to look, God called to him from the midst of the bush and said, "Moses, Moses!" And he said, "Here I am."

5. Then He said, "Do not draw near this place. Take your sandals off your feet, for the place where you stand is holy ground."

6. Moreover He said, "I am the God of your father--the God of Abraham, the God of Isaac, and the God of Jacob." And Moses hid his face, for he was afraid to look upon God.

7. And the LORD said: "I have surely seen the oppression of My people who are in Egypt, and have heard their cry because of their taskmasters, for I know their sorrows.

8. So I have come down to deliver them out of the hand of the Egyptians, and to bring them up from that land to a good and large land, to a land flowing with milk and honey, to the place of the Canaanites and the Hittites and the Amorites and the Perizzites and the Hivites and the Jebusites.

9. Now therefore, behold, the cry of the children of Israel has come to Me, and I have also seen the oppression with which the Egyptians oppress them.

10. Come now, therefore, and I will send you to Pharaoh that you may bring My people, the children of Israel, out of Egypt."

11. But Moses said to God, "Who am I that I should go to Pharaoh, and that I should bring the children of Israel out of Egypt?"

12. So He said, "I will certainly be with you. And this shall be a sign to you that I have sent you: When you have brought the people out of Egypt, you shall serve God on this mountain."

13. Then Moses said to God, "Indeed, when I come to the children of Israel and say to them, "The God of your fathers has sent me to you,' and they say to me, "What is His name?' what shall I say to them?"

14. And God said to Moses, "I AM WHO I AM." And He said, "Thus you shall say to the children of Israel, "I AM has sent me to you."'

15. Moreover God said to Moses, "Thus you shall say to the children of Israel: "The LORD God of your fathers, the God of Abraham, the God of Isaac, and the God of Jacob, has sent me to you. This is My name forever, and this is My memorial to all generations.'

16. Go and gather the elders of Israel together, and say to them, "The LORD God of your fathers, the God of Abraham, of Isaac, and of Jacob, appeared to me, saying, "I have surely visited you and seen what is done to you in Egypt;

17. and I have said I will bring you up out of the affliction of Egypt to the land of the Canaanites and the Hittites and the Amorites and the Perizzites and the Hivites and the Jebusites, to a land flowing with milk and honey."'

18. Then they will heed your voice; and you shall come, you and the elders of Israel, to the king of Egypt; and you shall say to him, "The LORD God of the Hebrews has met with us; and now, please, let us go three days' journey into the wilderness, that we may sacrifice to the LORD our God.'

19. But I am sure that the king of Egypt will not let you go, no, not even by a mighty hand.

20. So I will stretch out My hand and strike Egypt with all My wonders which I will do in its midst; and after that he will let you go.

21. And I will give this people favor in the sight of the Egyptians; and it shall be, when you go, that you shall not go empty-handed.

22. But every woman shall ask of her neighbor, namely, of her who dwells near her house, articles of silver, articles of gold, and clothing; and you shall put them on your sons and on your daughters. So you shall plunder the Egyptians."

## Chapter 4

1. Then Moses answered and said, "But suppose they will not believe me or listen to my voice; suppose they say, "The LORD has not appeared to you."'

2. So the LORD said to him, "What is that in your hand?" He said, "A rod."

3. And He said, "Cast it on the ground." So he cast it on the ground, and it became a serpent; and Moses fled from it.

4. Then the LORD said to Moses, "Reach out your hand and take it by the tail" (and he reached out his hand and caught it, and it became a rod in his hand),

5. "that they may believe that the LORD God of their fathers, the God of Abraham, the God of Isaac, and the God of Jacob, has appeared to you."

6. Furthermore the LORD said to him, "Now put your hand in your bosom." And he put his hand in his bosom, and when he took it out, behold, his hand was leprous, like snow.

7. And He said, "Put your hand in your bosom again." So he put his hand in his bosom again, and drew it out of his bosom, and behold, it was restored like his other flesh.

8. "Then it will be, if they do not believe you, nor heed the message of the first sign, that they may believe the message of the latter sign.

9. And it shall be, if they do not believe even these two signs, or listen to your voice, that you shall take water from the river and pour it on the dry land. The water which you take from the river will become blood on the dry land."

10. Then Moses said to the LORD, "O my Lord, I am not eloquent, neither before nor since You have spoken to Your servant; but I am slow of speech and slow of tongue."

11. So the LORD said to him, "Who has made man's mouth? Or who makes the mute, the deaf, the seeing, or the blind? Have not I, the LORD?

12. Now therefore, go, and I will be with your mouth and teach you what you shall say."

13. But he said, "O my Lord, please send by the hand of whomever else You may send."

14. So the anger of the LORD was kindled against Moses, and He said: "Is not Aaron the Levite your brother? I know that he can speak well. And look, he is also coming out to meet you. When he sees you, he will be glad in his heart.

15. Now you shall speak to him and put the words in his mouth. And I will be with your mouth and with his mouth, and I will teach you what you shall do.

16. So he shall be your spokesman to the people. And he himself shall be as a mouth for you, and you shall be to him as God.

17. And you shall take this rod in your hand, with which you shall do the signs."

18. So Moses went and returned to Jethro his father-in-law, and said to him, "Please let me go and return to my brethren who are in Egypt, and see whether they are still alive." And Jethro said to Moses, "Go in peace."

19. Now the LORD said to Moses in Midian, "Go, return to Egypt; for all the men who sought your life are dead."

20. Then Moses took his wife and his sons and set them on a donkey, and he returned to the land of Egypt. And Moses took the rod of God in his hand.

21. And the LORD said to Moses, "When you go back to Egypt, see that you do all those wonders before Pharaoh which I have put in your hand. But I will harden his heart, so that he will not let the people go.

22. Then you shall say to Pharaoh, "Thus says the LORD: "Israel is My son, My firstborn.

23. So I say to you, let My son go that he may serve Me. But if you refuse to let him go, indeed I will kill your son, your firstborn.""'

24. And it came to pass on the way, at the encampment, that the LORD met him and sought to kill him.

25. Then Zipporah took a sharp stone and cut off the foreskin of her son and cast it at Moses' feet, and said, "Surely you are a husband of blood to me!"

26. So He let him go. Then she said, "You are a husband of blood!"--because of the circumcision.

27. And the LORD said to Aaron, "Go into the wilderness to meet Moses." So he went and met him on the mountain of God, and kissed him.

28. So Moses told Aaron all the words of the LORD who had sent him, and all the signs which He had commanded him.

29. Then Moses and Aaron went and gathered together all the elders of the children of Israel.

30. And Aaron spoke all the words which the LORD had spoken to Moses. Then he did the signs in the sight of the people.

31. So the people believed; and when they heard that the LORD had visited the children of Israel and that He had looked on their affliction, then they bowed their heads and worshiped.

## Chapter 5

1. Afterward Moses and Aaron went in and told Pharaoh, "Thus says the LORD God of Israel: "Let My people go, that they may hold a feast to Me in the wilderness."'

2. And Pharaoh said, "Who is the LORD, that I should obey His voice to let Israel go? I do not know the LORD, nor will I let Israel go."

3. So they said, "The God of the Hebrews has met with us. Please, let us go three days' journey into the desert and sacrifice to the LORD our God, lest He fall upon us with pestilence or with the sword."

4. Then the king of Egypt said to them, "Moses and Aaron, why do you take the people from their work? Get back to your labor."

5. And Pharaoh said, "Look, the people of the land are many now, and you make them rest from their labor!"

6. So the same day Pharaoh commanded the taskmasters of the people and their officers, saying,

7. "You shall no longer give the people straw to make brick as before. Let them go and gather straw for themselves.

8. And you shall lay on them the quota of bricks which they made before. You shall not reduce it. For they are idle; therefore they cry out, saying, "Let us go and sacrifice to our God.'

9. Let more work be laid on the men, that they may labor in it, and let them not regard false words."

10. And the taskmasters of the people and their officers went out and spoke to the people, saying, "Thus says Pharaoh: "I will not give you straw.

11. Go, get yourselves straw where you can find it; yet none of your work will be reduced."'

12. So the people were scattered abroad throughout all the land of Egypt to gather stubble instead of straw.

13. And the taskmasters forced them to hurry, saying, "Fulfill your work, your daily quota, as when there was straw."

14. Also the officers of the children of Israel, whom Pharaoh's taskmasters had set over them, were beaten and were asked, "Why have you not fulfilled your task in making brick both yesterday and today, as before?"

15. Then the officers of the children of Israel came and cried out to Pharaoh, saying, "Why are you dealing thus with your servants?

16. There is no straw given to your servants, and they say to us, "Make brick!' And indeed your servants are beaten, but the fault is in your own people."

17. But he said, "You are idle! Idle! Therefore you say, "Let us go and sacrifice to the LORD.'

18. Therefore go now and work; for no straw shall be given you, yet you shall deliver the quota of bricks."

19. And the officers of the children of Israel saw that they were in trouble after it was said, "You shall not reduce any bricks from your daily quota."

20. Then, as they came out from Pharaoh, they met Moses and Aaron who stood there to meet them.

21. And they said to them, "Let the LORD look on you and judge, because you have made us abhorrent in the sight of Pharaoh and in the sight of his servants, to put a sword in their hand to kill us."

22. So Moses returned to the LORD and said, "Lord, why have You brought trouble on this people? Why is it You have sent me?

23. For since I came to Pharaoh to speak in Your name, he has done evil to this people; neither have You delivered Your people at all."

## Chapter 6

1. Then the LORD said to Moses, "Now you shall see what I will do to Pharaoh. For with a strong hand he will let them go, and with a strong hand he will drive them out of his land."

2. And God spoke to Moses and said to him: "I am the LORD.

3. I appeared to Abraham, to Isaac, and to Jacob, as God Almighty, but by My name LORD I was not known to them.

4. I have also established My covenant with them, to give them the land of Canaan, the land of their pilgrimage, in which they were strangers.

5. And I have also heard the groaning of the children of Israel whom the Egyptians keep in bondage, and I have remembered My covenant.

6. Therefore say to the children of Israel: "I am the LORD; I will bring you out from under the burdens of the Egyptians, I will rescue you from their bondage, and I will redeem you with an outstretched arm and with great judgments.

7. I will take you as My people, and I will be your God. Then you shall know that I am the LORD your God who brings you out from under the burdens of the Egyptians.

8. And I will bring you into the land which I swore to give to Abraham, Isaac, and Jacob; and I will give it to you as a heritage: I am the LORD."'

9. So Moses spoke thus to the children of Israel; but they did not heed Moses, because of anguish of spirit and cruel bondage.

10. And the LORD spoke to Moses, saying,

11. "Go in, tell Pharaoh king of Egypt to let the children of Israel go out of his land."

12. And Moses spoke before the LORD, saying, "The children of Israel have not heeded me. How then shall Pharaoh heed me, for I am of uncircumcised lips?"

13. Then the LORD spoke to Moses and Aaron, and gave them a command for the children of Israel and for Pharaoh king of Egypt, to bring the children of Israel out of the land of Egypt.

14. These are the heads of their fathers' houses: The sons of Reuben, the firstborn of Israel, were Hanoch, Pallu, Hezron, and Carmi. These are the families of Reuben.

15. And the sons of Simeon were Jemuel, Jamin, Ohad, Jachin, Zohar, and Shaul the son of a Canaanite woman. These are the families of Simeon.

16. These are the names of the sons of Levi according to their generations: Gershon, Kohath, and Merari. And the years of the life of Levi were one hundred and thirty-seven.

17. The sons of Gershon were Libni and Shimi according to their families.

18. And the sons of Kohath were Amram, Izhar, Hebron, and Uzziel. And the years of the life of Kohath were one hundred and thirty-three.

19. The sons of Merari were Mahli and Mushi. These are the families of Levi according to their generations.

20. Now Amram took for himself Jochebed, his father's sister, as wife; and she bore him Aaron and Moses. And the years of the life of Amram were one hundred and thirty-seven.

21. The sons of Izhar were Korah, Nepheg, and Zichri.

22. And the sons of Uzziel were Mishael, Elzaphan, and Zithri.

23. Aaron took to himself Elisheba, daughter of Amminadab, sister of Nahshon, as wife; and she bore him Nadab, Abihu, Eleazar, and Ithamar.

24. And the sons of Korah were Assir, Elkanah, and Abiasaph. These are the families of the Korahites.

25. Eleazar, Aaron's son, took for himself one of the daughters of Putiel as wife; and she bore him Phinehas. These are the heads of the fathers' houses of the Levites according to their families.

26. These are the same Aaron and Moses to whom the LORD said, "Bring out the children of Israel from the land of Egypt according to their armies."

27. These are the ones who spoke to Pharaoh king of Egypt, to bring out the children of Israel from Egypt. These are the same Moses and Aaron.

28. And it came to pass, on the day the LORD spoke to Moses in the land of Egypt,

29. that the LORD spoke to Moses, saying, "I am the LORD. Speak to Pharaoh king of Egypt all that I say to you."

30. But Moses said before the LORD, "Behold, I am of uncircumcised lips, and how shall Pharaoh heed me?"

## Chapter 7

1. So the LORD said to Moses: "See, I have made you as God to Pharaoh, and Aaron your brother shall be your prophet.

2. You shall speak all that I command you. And Aaron your brother shall tell Pharaoh to send the children of Israel out of his land.

3. And I will harden Pharaoh's heart, and multiply My signs and My wonders in the land of Egypt.

4. But Pharaoh will not heed you, so that I may lay My hand on Egypt and bring My armies and My people, the children of Israel, out of the land of Egypt by great judgments.

5. And the Egyptians shall know that I am the LORD, when I stretch out My hand on Egypt and bring out the children of Israel from among them."

6. Then Moses and Aaron did so; just as the LORD commanded them, so they did.

7. And Moses was eighty years old and Aaron eighty-three years old when they spoke to Pharaoh.

8. Then the LORD spoke to Moses and Aaron, saying,

9. "When Pharaoh speaks to you, saying, "Show a miracle for yourselves,' then you shall say to Aaron, "Take your rod and cast it before Pharaoh, and let it become a serpent."'

10. So Moses and Aaron went in to Pharaoh, and they did so, just as the LORD commanded. And Aaron cast down his rod before Pharaoh and before his servants, and it became a serpent.

11. But Pharaoh also called the wise men and the sorcerers; so the magicians of Egypt, they also did in like manner with their enchantments.

12. For every man threw down his rod, and they became serpents. But Aaron's rod swallowed up their rods.

13. And Pharaoh's heart grew hard, and he did not heed them, as the LORD had said.

14. So the LORD said to Moses: "Pharaoh's heart is hard; he refuses to let the people go.

15. Go to Pharaoh in the morning, when he goes out to the water, and you shall stand by the river's bank to meet him; and the rod which was turned to a serpent you shall take in your hand.

16. And you shall say to him, "The LORD God of the Hebrews has sent me to you, saying, "Let My people go, that they may serve Me in the wilderness"; but indeed, until now you would not hear!

17. Thus says the LORD: "By this you shall know that I am the LORD. Behold, I will strike the waters which are in the river with the rod that is in my hand, and they shall be turned to blood.

18. And the fish that are in the river shall die, the river shall stink, and the Egyptians will loathe to drink the water of the river.""'

19. Then the LORD spoke to Moses, "Say to Aaron, "Take your rod and stretch out your hand over the waters of Egypt, over their streams, over their rivers, over their ponds, and over all their pools of water, that they may become blood. And there shall be blood throughout all the land of Egypt, both in buckets of wood and pitchers of stone."'

20. And Moses and Aaron did so, just as the LORD commanded. So he lifted up the rod and struck the waters that were in the river, in the sight of Pharaoh and in the sight of his servants. And all the waters that were in the river were turned to blood.

21. The fish that were in the river died, the river stank, and the Egyptians could not drink the water of the river. So there was blood throughout all the land of Egypt.

22. Then the magicians of Egypt did so with their enchantments; and Pharaoh's heart grew hard, and he did not heed them, as the LORD had said.

23. And Pharaoh turned and went into his house. Neither was his heart moved by this.

24. So all the Egyptians dug all around the river for water to drink, because they could not drink the water of the river.

25. And seven days passed after the LORD had struck the river.

## Chapter 8

1. And the LORD spoke to Moses, "Go to Pharaoh and say to him, "Thus says the LORD: "Let My people go, that they may serve Me.

2. But if you refuse to let them go, behold, I will smite all your territory with frogs.

3. So the river shall bring forth frogs abundantly, which shall go up and come into your house, into your bedroom, on your bed, into the houses of your servants, on your people, into your ovens, and into your kneading bowls.

4. And the frogs shall come up on you, on your people, and on all your servants.""'

5. Then the LORD spoke to Moses, "Say to Aaron, "Stretch out your hand with your rod over the streams, over the rivers, and over the ponds, and cause frogs to come up on the land of Egypt."'

6. So Aaron stretched out his hand over the waters of Egypt, and the frogs came up and covered the land of Egypt.

7. And the magicians did so with their enchantments, and brought up frogs on the land of Egypt.

8. Then Pharaoh called for Moses and Aaron, and said, "Entreat the LORD that He may take away the frogs from me and from my people; and I will let the people go, that they may sacrifice to the LORD."

9. And Moses said to Pharaoh, "Accept the honor of saying when I shall intercede for you, for your servants, and for your people, to destroy the frogs from you and your houses, that they may remain in the river only."

10. So he said, "Tomorrow." And he said, "Let it be according to your word, that you may know that there is no one like the LORD our God.

11. And the frogs shall depart from you, from your houses, from your servants, and from your people. They shall remain in the river only."

12. Then Moses and Aaron went out from Pharaoh. And Moses cried out to the LORD concerning the frogs which He had brought against Pharaoh.

13. So the LORD did according to the word of Moses. And the frogs died out of the houses, out of the courtyards, and out of the fields.

14. They gathered them together in heaps, and the land stank.

15. But when Pharaoh saw that there was relief, he hardened his heart and did not heed them, as the LORD had said.

16. So the LORD said to Moses, "Say to Aaron, "Stretch out your rod, and strike the dust of the land, so that it may become lice throughout all the land of Egypt."'

17. And they did so. For Aaron stretched out his hand with his rod and struck the dust of the earth, and it became lice on man and beast. All the dust of the land became lice throughout all the land of Egypt.

18. Now the magicians so worked with their enchantments to bring forth lice, but they could not. So there were lice on man and beast.

19. Then the magicians said to Pharaoh, "This is the finger of God." But Pharaoh's heart grew hard, and he did not heed them, just as the LORD had said.

20. And the LORD said to Moses, "Rise early in the morning and stand before Pharaoh as he comes out to the water. Then say to him, "Thus says the LORD: "Let My people go, that they may serve Me.

21. Or else, if you will not let My people go, behold, I will send swarms of flies on you and your servants, on your people and into your houses. The houses of the Egyptians shall be full of swarms of flies, and also the ground on which they stand.

22. And in that day I will set apart the land of Goshen, in which My people dwell, that no swarms of flies shall be there, in order that you may know that I am the LORD in the midst of the land.

23. I will make a difference between My people and your people. Tomorrow this sign shall be.""'

24. And the LORD did so. Thick swarms of flies came into the house of Pharaoh, into his servants' houses, and into all the land of Egypt. The land was corrupted because of the swarms of flies.

25. Then Pharaoh called for Moses and Aaron, and said, "Go, sacrifice to your God in the land."

26. And Moses said, "It is not right to do so, for we would be sacrificing the abomination of the Egyptians to the LORD our God. If we sacrifice the abomination of the Egyptians before their eyes, then will they not stone us?

27. We will go three days' journey into the wilderness and sacrifice to the LORD our God as He will command us."

28. So Pharaoh said, "I will let you go, that you may sacrifice to the LORD your God in the wilderness; only you shall not go very far away. Intercede for me."

29. Then Moses said, "Indeed I am going out from you, and I will entreat the LORD, that the swarms of flies may depart tomorrow from Pharaoh, from his servants, and from his people. But let Pharaoh not deal deceitfully anymore in not letting the people go to sacrifice to the LORD."

30. So Moses went out from Pharaoh and entreated the LORD.

31. And the LORD did according to the word of Moses; He removed the swarms of flies from Pharaoh, from his servants, and from his people. Not one remained.

32. But Pharaoh hardened his heart at this time also; neither would he let the people go.

## Chapter 9

1. Then the LORD said to Moses, "Go in to Pharaoh and tell him, "Thus says the LORD God of the Hebrews: "Let My people go, that they may serve Me.

2. For if you refuse to let them go, and still hold them,

3. behold, the hand of the LORD will be on your cattle in the field, on the horses, on the donkeys, on the camels, on the oxen, and on the sheep--a very severe pestilence.

4. And the LORD will make a difference between the livestock of Israel and the livestock of Egypt. So nothing shall die of all that belongs to the children of Israel.""'

5. Then the LORD appointed a set time, saying, "Tomorrow the LORD will do this thing in the land."

6. So the LORD did this thing on the next day, and all the livestock of Egypt died; but of the livestock of the children of Israel, not one died.

7. Then Pharaoh sent, and indeed, not even one of the livestock of the Israelites was dead. But the heart of Pharaoh became hard, and he did not let the people go.

8. So the LORD said to Moses and Aaron, "Take for yourselves handfuls of ashes from a furnace, and let Moses scatter it toward the heavens in the sight of Pharaoh.

9. And it will become fine dust in all the land of Egypt, and it will cause boils that break out in sores on man and beast throughout all the land of Egypt."

10. Then they took ashes from the furnace and stood before Pharaoh, and Moses scattered them toward heaven. And they caused boils that break out in sores on man and beast.

11. And the magicians could not stand before Moses because of the boils, for the boils were on the magicians and on all the Egyptians.

12. But the LORD hardened the heart of Pharaoh; and he did not heed them, just as the LORD had spoken to Moses.

13. Then the LORD said to Moses, "Rise early in the morning and stand before Pharaoh, and say to him, "Thus says the LORD God of the Hebrews: "Let My people go, that they may serve Me,

14. for at this time I will send all My plagues to your very heart, and on your servants and on your people, that you may know that there is none like Me in all the earth.

15. Now if I had stretched out My hand and struck you and your people with pestilence, then you would have been cut off from the earth.

16. But indeed for this purpose I have raised you up, that I may show My power in you, and that My name may be declared in all the earth.

17. As yet you exalt yourself against My people in that you will not let them go.

18. Behold, tomorrow about this time I will cause very heavy hail to rain down, such as has not been in Egypt since its founding until now.

19. Therefore send now and gather your livestock and all that you have in the field, for the hail shall come down on every man and every animal which is found in the field and is not brought home; and they shall die.""'

20. He who feared the word of the LORD among the servants of Pharaoh made his servants and his livestock flee to the houses.

21. But he who did not regard the word of the LORD left his servants and his livestock in the field.

22. Then the LORD said to Moses, "Stretch out your hand toward heaven, that there may be hail in all the land of Egypt--on man, on beast, and on every herb of the field, throughout the land of Egypt."

23. And Moses stretched out his rod toward heaven; and the LORD sent thunder and hail, and fire darted to the ground. And the LORD rained hail on the land of Egypt.

24. So there was hail, and fire mingled with the hail, so very heavy that there was none like it in all the land of Egypt since it became a nation.

25. And the hail struck throughout the whole land of Egypt, all that was in the field, both man and beast; and the hail struck every herb of the field and broke every tree of the field.

26. Only in the land of Goshen, where the children of Israel were, there was no hail.

27. And Pharaoh sent and called for Moses and Aaron, and said to them, "I have sinned this time. The LORD is righteous, and my people and I are wicked.

28. Entreat the LORD, that there may be no more mighty thundering and hail, for it is enough. I will let you go, and you shall stay no longer."

29. So Moses said to him, "As soon as I have gone out of the city, I will spread out my hands to the LORD; the thunder will cease, and there will be no more hail, that you may know that the earth is the LORD's.

30. But as for you and your servants, I know that you will not yet fear the LORD God."

31. Now the flax and the barley were struck, for the barley was in the head and the flax was in bud.

32. But the wheat and the spelt were not struck, for they are late crops.

33. So Moses went out of the city from Pharaoh and spread out his hands to the LORD; then the thunder and the hail ceased, and the rain was not poured on the earth.

34. And when Pharaoh saw that the rain, the hail, and the thunder had ceased, he sinned yet more; and he hardened his heart, he and his servants.

35. So the heart of Pharaoh was hard; neither would he let the children of Israel go, as the LORD had spoken by Moses.

## Chapter 10

1. Now the LORD said to Moses, "Go in to Pharaoh; for I have hardened his heart and the hearts of his servants, that I may show these signs of Mine before him,

2. and that you may tell in the hearing of your son and your son's son the mighty things I have done in Egypt, and My signs which I have done among them, that you may know that I am the LORD."

3. So Moses and Aaron came in to Pharaoh and said to him, "Thus says the LORD God of the Hebrews: "How long will you refuse to humble yourself before Me? Let My people go, that they may serve Me.

4. Or else, if you refuse to let My people go, behold, tomorrow I will bring locusts into your territory.

5. And they shall cover the face of the earth, so that no one will be able to see the earth; and they shall eat the residue of what is left, which remains to you from the hail, and they shall eat every tree which grows up for you out of the field.

6. They shall fill your houses, the houses of all your servants, and the houses of all the Egyptians--which neither your fathers nor your fathers' fathers have seen, since the day that they were on the earth to this day."' And he turned and went out from Pharaoh.

7. Then Pharaoh's servants said to him, "How long shall this man be a snare to us? Let the men go, that they may serve the LORD their God. Do you not yet know that Egypt is destroyed?"

8. So Moses and Aaron were brought again to Pharaoh, and he said to them, "Go, serve the LORD your God. Who are the ones that are going?"

9. And Moses said, "We will go with our young and our old; with our sons and our daughters, with our flocks and our herds we will go, for we must hold a feast to the LORD."

10. Then he said to them, "The LORD had better be with you when I let you and your little ones go! Beware, for evil is ahead of you.

11. Not so! Go now, you who are men, and serve the LORD, for that is what you desired." And they were driven out from Pharaoh's presence.

12. Then the LORD said to Moses, "Stretch out your hand over the land of Egypt for the locusts, that they may come upon the land of Egypt, and eat every herb of the land--all that the hail has left."

13. So Moses stretched out his rod over the land of Egypt, and the LORD brought an east wind on the land all that day and all that night. When it was morning, the east wind brought the locusts.

14. And the locusts went up over all the land of Egypt and rested on all the territory of Egypt. They were very severe; previously there had been no such locusts as they, nor shall there be such after them.

15. For they covered the face of the whole earth, so that the land was darkened; and they ate every herb of the land and all the fruit of the trees which the hail had left. So there remained nothing green on the trees or on the plants of the field throughout all the land of Egypt.

16. Then Pharaoh called for Moses and Aaron in haste, and said, "I have sinned against the LORD your God and against you.

17. Now therefore, please forgive my sin only this once, and entreat the LORD your God, that He may take away from me this death only."

18. So he went out from Pharaoh and entreated the LORD.

19. And the LORD turned a very strong west wind, which took the locusts away and blew them into the Red Sea. There remained not one locust in all the territory of Egypt.

20. But the LORD hardened Pharaoh's heart, and he did not let the children of Israel go.

21. Then the LORD said to Moses, "Stretch out your hand toward heaven, that there may be darkness over the land of Egypt, darkness which may even be felt."

22. So Moses stretched out his hand toward heaven, and there was thick darkness in all the land of Egypt three days.

23. They did not see one another; nor did anyone rise from his place for three days. But all the children of Israel had light in their dwellings.

24. Then Pharaoh called to Moses and said, "Go, serve the LORD; only let your flocks and your herds be kept back. Let your little ones also go with you."

25. But Moses said, "You must also give us sacrifices and burnt offerings, that we may sacrifice to the LORD our God.

26. Our livestock also shall go with us; not a hoof shall be left behind. For we must take some of them to serve the LORD our God, and even we do not know with what we must serve the LORD until we arrive there."

27. But the LORD hardened Pharaoh's heart, and he would not let them go.

28. Then Pharaoh said to him, "Get away from me! Take heed to yourself and see my face no more! For in the day you see my face you shall die!"

29. So Moses said, "You have spoken well. I will never see your face again."

## Chapter 11

1. And the LORD said to Moses, "I will bring one more plague on Pharaoh and on Egypt. Afterward he will let you go from here. When he lets you go, he will surely drive you out of here altogether.

2. Speak now in the hearing of the people, and let every man ask from his neighbor and every woman from her neighbor, articles of silver and articles of gold."

3. And the LORD gave the people favor in the sight of the Egyptians. Moreover the man Moses was very great in the land of Egypt, in the sight of Pharaoh's servants and in the sight of the people.

4. Then Moses said, "Thus says the LORD: "About midnight I will go out into the midst of Egypt;

5. and all the firstborn in the land of Egypt shall die, from the firstborn of Pharaoh who sits on his throne, even to the firstborn of the female servant who is behind the handmill, and all the firstborn of the animals.

6. Then there shall be a great cry throughout all the land of Egypt, such as was not like it before, nor shall be like it again.

7. But against none of the children of Israel shall a dog move its tongue, against man or beast, that you may know that the LORD does make a difference between the Egyptians and Israel.'

8. And all these your servants shall come down to me and bow down to me, saying, "Get out, and all the people who follow you!' After that I will go out." Then he went out from Pharaoh in great anger.

9. But the LORD said to Moses, "Pharaoh will not heed you, so that My wonders may be multiplied in the land of Egypt."

10. So Moses and Aaron did all these wonders before Pharaoh; and the LORD hardened Pharaoh's heart, and he did not let the children of Israel go out of his land.

## Chapter 12

1. Now the LORD spoke to Moses and Aaron in the land of Egypt, saying,

2. "This month shall be your beginning of months; it shall be the first month of the year to you.

3. Speak to all the congregation of Israel, saying: "On the tenth of this month every man shall take for himself a lamb, according to the house of his father, a lamb for a household.

4. And if the household is too small for the lamb, let him and his neighbor next to his house take it according to the number of the persons; according to each man's need you shall make your count for the lamb.

5. Your lamb shall be without blemish, a male of the first year. You may take it from the sheep or from the goats.

6. Now you shall keep it until the fourteenth day of the same month. Then the whole assembly of the congregation of Israel shall kill it at twilight.

7. And they shall take some of the blood and put it on the two doorposts and on the lintel of the houses where they eat it.

8. Then they shall eat the flesh on that night; roasted in fire, with unleavened bread and with bitter herbs they shall eat it.

9. Do not eat it raw, nor boiled at all with water, but roasted in fire--its head with its legs and its entrails.

10. You shall let none of it remain until morning, and what remains of it until morning you shall burn with fire.

11. And thus you shall eat it: with a belt on your waist, your sandals on your feet, and your staff in your hand. So you shall eat it in haste. It is the LORD's Passover.

12. "For I will pass through the land of Egypt on that night, and will strike all the firstborn in the land of Egypt, both man and beast; and against all the gods of Egypt I will execute judgment: I am the LORD.

13. Now the blood shall be a sign for you on the houses where you are. And when I see the blood, I will pass over you; and the plague shall not be on you to destroy you when I strike the land of Egypt.

14. "So this day shall be to you a memorial; and you shall keep it as a feast to the LORD throughout your generations. You shall keep it as a feast by an everlasting ordinance.

15. Seven days you shall eat unleavened bread. On the first day you shall remove leaven from your houses. For whoever eats leavened bread from the first day until the seventh day, that person shall be cut off from Israel.

16. On the first day there shall be a holy convocation, and on the seventh day there shall be a holy convocation for you. No manner of work shall be done on them; but that which everyone must eat--that only may be prepared by you.

17. So you shall observe the Feast of Unleavened Bread, for on this same day I will have brought your armies out of the land of Egypt. Therefore you shall observe this day throughout your generations as an everlasting ordinance.

18. In the first month, on the fourteenth day of the month at evening, you shall eat unleavened bread, until the twenty-first day of the month at evening.

19. For seven days no leaven shall be found in your houses, since whoever eats what is leavened, that same person shall be cut off from the congregation of Israel, whether he is a stranger or a native of the land.

20. You shall eat nothing leavened; in all your dwellings you shall eat unleavened bread."'

21. Then Moses called for all the elders of Israel and said to them, "Pick out and take lambs for yourselves according to your families, and kill the Passover lamb.

22. And you shall take a bunch of hyssop, dip it in the blood that is in the basin, and strike the lintel and the two doorposts with the blood that is in the basin. And none of you shall go out of the door of his house until morning.

23. For the LORD will pass through to strike the Egyptians; and when He sees the blood on the lintel and on the two doorposts, the LORD will pass over the door and not allow the destroyer to come into your houses to strike you.

24. And you shall observe this thing as an ordinance for you and your sons forever.

25. It will come to pass when you come to the land which the LORD will give you, just as He promised, that you shall keep this service.

26. And it shall be, when your children say to you, "What do you mean by this service?'

27. that you shall say, "It is the Passover sacrifice of the LORD, who passed over the houses of the children of Israel in Egypt when He struck the Egyptians and delivered our households."' So the people bowed their heads and worshiped.

28. Then the children of Israel went away and did so; just as the LORD had commanded Moses and Aaron, so they did.

29. And it came to pass at midnight that the LORD struck all the firstborn in the land of Egypt, from the firstborn of Pharaoh who sat on his throne to the firstborn of the captive who was in the dungeon, and all the firstborn of livestock.

30. So Pharaoh rose in the night, he, all his servants, and all the Egyptians; and there was a great cry in Egypt, for there was not a house where there was not one dead.

31. Then he called for Moses and Aaron by night, and said, "Rise, go out from among my people, both you and the children of Israel. And go, serve the LORD as you have said.

32. Also take your flocks and your herds, as you have said, and be gone; and bless me also."

33. And the Egyptians urged the people, that they might send them out of the land in haste. For they said, "We shall all be dead."

34. So the people took their dough before it was leavened, having their kneading bowls bound up in their clothes on their shoulders.

35. Now the children of Israel had done according to the word of Moses, and they had asked from the Egyptians articles of silver, articles of gold, and clothing.

36. And the LORD had given the people favor in the sight of the Egyptians, so that they granted them what they requested. Thus they plundered the Egyptians.

37. Then the children of Israel journeyed from Rameses to Succoth, about six hundred thousand men on foot, besides children.

38. A mixed multitude went up with them also, and flocks and herds--a great deal of livestock.

39. And they baked unleavened cakes of the dough which they had brought out of Egypt; for it was not leavened, because they were driven out of Egypt and could not wait, nor had they prepared provisions for themselves.

40. Now the sojourn of the children of Israel who lived in Egypt was four hundred and thirty years.

41. And it came to pass at the end of the four hundred and thirty years--on that very same day--it came to pass that all the armies of the LORD went out from the land of Egypt.

42. It is a night of solemn observance to the LORD for bringing them out of the land of Egypt. This is that night of the LORD, a solemn observance for all the children of Israel throughout their generations.

43. And the LORD said to Moses and Aaron, "This is the ordinance of the Passover: No foreigner shall eat it.

44. But every man's servant who is bought for money, when you have circumcised him, then he may eat it.

45. A sojourner and a hired servant shall not eat it.

46. In one house it shall be eaten; you shall not carry any of the flesh outside the house, nor shall you break one of its bones.

47. All the congregation of Israel shall keep it.

48. And when a stranger dwells with you and wants to keep the Passover to the LORD, let all his males be circumcised, and then let him come near and keep it; and he shall be as a native of the land. For no uncircumcised person shall eat it.

49. One law shall be for the native-born and for the stranger who dwells among you."

50. Thus all the children of Israel did; as the LORD commanded Moses and Aaron, so they did.

51. And it came to pass, on that very same day, that the LORD brought the children of Israel out of the land of Egypt according to their armies.

## Chapter 13

1. Then the LORD spoke to Moses, saying,

2. "Consecrate to Me all the firstborn, whatever opens the womb among the children of Israel, both of man and beast; it is Mine."

3. And Moses said to the people: "Remember this day in which you went out of Egypt, out of the house of bondage; for by strength of hand the LORD brought you out of this place. No leavened bread shall be eaten.

4. On this day you are going out, in the month Abib.

5. And it shall be, when the LORD brings you into the land of the Canaanites and the Hittites and the Amorites and the Hivites and the Jebusites, which He swore to your fathers to give you, a land flowing with milk and honey, that you shall keep this service in this month.

6. Seven days you shall eat unleavened bread, and on the seventh day there shall be a feast to the LORD.

7. Unleavened bread shall be eaten seven days. And no leavened bread shall be seen among you, nor shall leaven be seen among you in all your quarters.

8. And you shall tell your son in that day, saying, "This is done because of what the LORD did for me when I came up from Egypt.'

9. It shall be as a sign to you on your hand and as a memorial between your eyes, that the LORD's law may be in your mouth; for with a strong hand the LORD has brought you out of Egypt.

10. You shall therefore keep this ordinance in its season from year to year.

11. "And it shall be, when the LORD brings you into the land of the Canaanites, as He swore to you and your fathers, and gives it to you,

12. that you shall set apart to the LORD all that open the womb, that is, every firstborn that comes from an animal which you have; the males shall be the LORD's.

13. But every firstborn of a donkey you shall redeem with a lamb; and if you will not redeem it, then you shall break its neck. And all the firstborn of man among your sons you shall redeem.

14. So it shall be, when your son asks you in time to come, saying, "What is this?' that you shall say to him, "By strength of hand the LORD brought us out of Egypt, out of the house of bondage.

15. And it came to pass, when Pharaoh was stubborn about letting us go, that the LORD killed all the firstborn in the land of Egypt, both the firstborn of man and the firstborn of beast. Therefore I sacrifice to the LORD all males that open the womb, but all the firstborn of my sons I redeem.'

16. It shall be as a sign on your hand and as frontlets between your eyes, for by strength of hand the LORD brought us out of Egypt."

17. Then it came to pass, when Pharaoh had let the people go, that God did not lead them by way of the land of the Philistines, although that was near; for God said, "Lest perhaps the people change their minds when they see war, and return to Egypt."

18. So God led the people around by way of the wilderness of the Red Sea. And the children of Israel went up in orderly ranks out of the land of Egypt.

19. And Moses took the bones of Joseph with him, for he had placed the children of Israel under solemn oath, saying, "God will surely visit you, and you shall carry up my bones from here with you."

20. So they took their journey from Succoth and camped in Etham at the edge of the wilderness.

21. And the LORD went before them by day in a pillar of cloud to lead the way, and by night in a pillar of fire to give them light, so as to go by day and night.

22. He did not take away the pillar of cloud by day or the pillar of fire by night from before the people.

## Chapter 14

1. Now the LORD spoke to Moses, saying:

2. "Speak to the children of Israel, that they turn and camp before Pi Hahiroth, between Migdol and the sea, opposite Baal Zephon; you shall camp before it by the sea.

3. For Pharaoh will say of the children of Israel, "They are bewildered by the land; the wilderness has closed them in.'

4. Then I will harden Pharaoh's heart, so that he will pursue them; and I will gain honor over Pharaoh and over all his army, that the Egyptians may know that I am the LORD." And they did so.

5. Now it was told the king of Egypt that the people had fled, and the heart of Pharaoh and his servants was turned against the people; and they said, "Why have we done this, that we have let Israel go from serving us?"

6. So he made ready his chariot and took his people with him.

7. Also, he took six hundred choice chariots, and all the chariots of Egypt with captains over every one of them.

8. And the LORD hardened the heart of Pharaoh king of Egypt, and he pursued the children of Israel; and the children of Israel went out with boldness.

9. So the Egyptians pursued them, all the horses and chariots of Pharaoh, his horsemen and his army, and overtook them camping by the sea beside Pi Hahiroth, before Baal Zephon.

10. And when Pharaoh drew near, the children of Israel lifted their eyes, and behold, the Egyptians marched after them. So they were very afraid, and the children of Israel cried out to the LORD.

11. Then they said to Moses, "Because there were no graves in Egypt, have you taken us away to die in the wilderness? Why have you so dealt with us, to bring us up out of Egypt?

12. Is this not the word that we told you in Egypt, saying, "Let us alone that we may serve the Egyptians'? For it would have been better for us to serve the Egyptians than that we should die in the wilderness."

13. And Moses said to the people, "Do not be afraid. Stand still, and see the salvation of the LORD, which He will accomplish for you today. For the Egyptians whom you see today, you shall see again no more forever.

14. The LORD will fight for you, and you shall hold your peace."

15. And the LORD said to Moses, "Why do you cry to Me? Tell the children of Israel to go forward.

16. But lift up your rod, and stretch out your hand over the sea and divide it. And the children of Israel shall go on dry ground through the midst of the sea.

17. And I indeed will harden the hearts of the Egyptians, and they shall follow them. So I will gain honor over Pharaoh and over all his army, his chariots, and his horsemen.

18. Then the Egyptians shall know that I am the LORD, when I have gained honor for Myself over Pharaoh, his chariots, and his horsemen."

19. And the Angel of God, who went before the camp of Israel, moved and went behind them; and the pillar of cloud went from before them and stood behind them.

20. So it came between the camp of the Egyptians and the camp of Israel. Thus it was a cloud and darkness to the one, and it gave light by night to the other, so that the one did not come near the other all that night.

21. Then Moses stretched out his hand over the sea; and the LORD caused the sea to go back by a strong east wind all that night, and made the sea into dry land, and the waters were divided.

22. So the children of Israel went into the midst of the sea on the dry ground, and the waters were a wall to them on their right hand and on their left.

23. And the Egyptians pursued and went after them into the midst of the sea, all Pharaoh's horses, his chariots, and his horsemen.

24. Now it came to pass, in the morning watch, that the LORD looked down upon the army of the Egyptians through the pillar of fire and cloud, and He troubled the army of the Egyptians.

25. And He took off their chariot wheels, so that they drove them with difficulty; and the Egyptians said, "Let us flee from the face of Israel, for the LORD fights for them against the Egyptians."

26. Then the LORD said to Moses, "Stretch out your hand over the sea, that the waters may come back upon the Egyptians, on their chariots, and on their horsemen."

27. And Moses stretched out his hand over the sea; and when the morning appeared, the sea returned to its full depth, while the Egyptians were fleeing into it. So the LORD overthrew the Egyptians in the midst of the sea.

28. Then the waters returned and covered the chariots, the horsemen, and all the army of Pharaoh that came into the sea after them. Not so much as one of them remained.

29. But the children of Israel had walked on dry land in the midst of the sea, and the waters were a wall to them on their right hand and on their left.

30. So the LORD saved Israel that day out of the hand of the Egyptians, and Israel saw the Egyptians dead on the seashore.

31. Thus Israel saw the great work which the LORD had done in Egypt; so the people feared the LORD, and believed the LORD and His servant Moses.

## Chapter 15

1. Then Moses and the children of Israel sang this song to the LORD, and spoke, saying: "I will sing to the LORD, For He has triumphed gloriously! The horse and its rider He has thrown into the sea!

2. The LORD is my strength and song, And He has become my salvation; He is my God, and I will praise Him; My father's God, and I will exalt Him.

3. The LORD is a man of war; The LORD is His name.

4. Pharaoh's chariots and his army He has cast into the sea; His chosen captains also are drowned in the Red Sea.

5. The depths have covered them; They sank to the bottom like a stone.

6. "Your right hand, O LORD, has become glorious in power; Your right hand, O LORD, has dashed the enemy in pieces.

7. And in the greatness of Your excellence You have overthrown those who rose against You; You sent forth Your wrath; It consumed them like stubble.

8. And with the blast of Your nostrils The waters were gathered together; The floods stood upright like a heap; The depths congealed in the heart of the sea.

9. The enemy said, "I will pursue, I will overtake, I will divide the spoil; My desire shall be satisfied on them. I will draw my sword, My hand shall destroy them.'

10. You blew with Your wind, The sea covered them; They sank like lead in the mighty waters.

11. "Who is like You, O LORD, among the gods? Who is like You, glorious in holiness, Fearful in praises, doing wonders?

12. You stretched out Your right hand; The earth swallowed them.

13. You in Your mercy have led forth The people whom You have redeemed; You have guided them in Your strength To Your holy habitation.

14. "The people will hear and be afraid; Sorrow will take hold of the inhabitants of Philistia.

15. Then the chiefs of Edom will be dismayed; 1 The mighty men of Moab, Trembling will take hold of them; All the inhabitants of Canaan will melt away.

16. Fear and dread will fall on them; By the greatness of Your arm They will be as still as a stone, Till Your people pass over, O LORD, Till the people pass over Whom You have purchased.

17. You will bring them in and plant them In the mountain of Your inheritance, In the place, O LORD, which You have made For Your own dwelling, The sanctuary, O LORD, which Your hands have established.

18. "The LORD shall reign forever and ever."

19. For the horses of Pharaoh went with his chariots and his horsemen into the sea, and the LORD brought back the waters of the sea upon them. But the children of Israel went on dry land in the midst of the sea.

20. Then Miriam the prophetess, the sister of Aaron, took the timbrel in her hand; and all the women went out after her with timbrels and with dances.

21. And Miriam answered them: "Sing to the LORD, For He has triumphed gloriously! The horse and its rider He has thrown into the sea!"

22. So Moses brought Israel from the Red Sea; then they went out into the Wilderness of Shur. And they went three days in the wilderness and found no water.

23. Now when they came to Marah, they could not drink the waters of Marah, for they were bitter. Therefore the name of it was called Marah.

24. And the people complained against Moses, saying, "What shall we drink?"

25. So he cried out to the LORD, and the LORD showed him a tree. When he cast it into the waters, the waters were made sweet. There He made a statute and an ordinance for them, and there He tested them,

26. and said, "If you diligently heed the voice of the LORD your God and do what is right in His sight, give ear to His commandments and keep all His statutes, I will put none of the diseases on you which I have brought on the Egyptians. For I am the LORD who heals you."

27. Then they came to Elim, where there were twelve wells of water and seventy palm trees; so they camped there by the waters.

## Chapter 16

1. And they journeyed from Elim, and all the congregation of the children of Israel came to the Wilderness of Sin, which is between Elim and Sinai, on the fifteenth day of the second month after they departed from the land of Egypt.

2. Then the whole congregation of the children of Israel complained against Moses and Aaron in the wilderness.

3. And the children of Israel said to them, "Oh, that we had died by the hand of the LORD in the land of Egypt, when we sat by the pots of meat and when we ate bread to the full! For you have brought us out into this wilderness to kill this whole assembly with hunger."

4. Then the LORD said to Moses, "Behold, I will rain bread from heaven for you. And the people shall go out and gather a certain quota every day, that I may test them, whether they will walk in My law or not.

5. And it shall be on the sixth day that they shall prepare what they bring in, and it shall be twice as much as they gather daily."

6. Then Moses and Aaron said to all the children of Israel, "At evening you shall know that the LORD has brought you out of the land of Egypt.

7. And in the morning you shall see the glory of the LORD; for He hears your complaints against the LORD. But what are we, that you complain against us?"

8. Also Moses said, "This shall be seen when the LORD gives you meat to eat in the evening, and in the morning bread to the full; for the LORD hears your complaints which you make against Him. And what are we? Your complaints are not against us but against the LORD."

9. Then Moses spoke to Aaron, "Say to all the congregation of the children of Israel, "Come near before the LORD, for He has heard your complaints."'

10. Now it came to pass, as Aaron spoke to the whole congregation of the children of Israel, that they looked toward the wilderness, and behold, the glory of the LORD appeared in the cloud.

11. And the LORD spoke to Moses, saying,

12. "I have heard the complaints of the children of Israel. Speak to them, saying, "At twilight you shall eat meat, and in the morning you shall be filled with bread. And you shall know that I am the LORD your God."'

13. So it was that quails came up at evening and covered the camp, and in the morning the dew lay all around the camp.

14. And when the layer of dew lifted, there, on the surface of the wilderness, was a small round substance, as fine as frost on the ground.

15. So when the children of Israel saw it, they said to one another, "What is it?" For they did not know what it was. And Moses said to them, "This is the bread which the LORD has given you to eat.

16. This is the thing which the LORD has commanded: "Let every man gather it according to each one's need, one omer for each person, according to the number of persons; let every man take for those who are in his tent."'

17. Then the children of Israel did so and gathered, some more, some less.

18. So when they measured it by omers, he who gathered much had nothing left over, and he who gathered little had no lack. Every man had gathered according to each one's need.

19. And Moses said, "Let no one leave any of it till morning."

20. Notwithstanding they did not heed Moses. But some of them left part of it until morning, and it bred worms and stank. And Moses was angry with them.

21. So they gathered it every morning, every man according to his need. And when the sun became hot, it melted.

22. And so it was, on the sixth day, that they gathered twice as much bread, two omers for each one. And all the rulers of the congregation came and told Moses.

23. Then he said to them, "This is what the LORD has said: "Tomorrow is a Sabbath rest, a holy Sabbath to the LORD. Bake what you will bake today, and boil what you will boil; and lay up for yourselves all that remains, to be kept until morning."'

24. So they laid it up till morning, as Moses commanded; and it did not stink, nor were there any worms in it.

25. Then Moses said, "Eat that today, for today is a Sabbath to the LORD; today you will not find it in the field.

26. Six days you shall gather it, but on the seventh day, the Sabbath, there will be none."

27. Now it happened that some of the people went out on the seventh day to gather, but they found none.

28. And the LORD said to Moses, "How long do you refuse to keep My commandments and My laws?

29. See! For the LORD has given you the Sabbath; therefore He gives you on the sixth day bread for two days. Let every man remain in his place; let no man go out of his place on the seventh day."

30. So the people rested on the seventh day.

31. And the house of Israel called its name Manna. And it was like white coriander seed, and the taste of it was like wafers made with honey.

32. Then Moses said, "This is the thing which the LORD has commanded: "Fill an omer with it, to be kept for your generations, that they may see the bread with which I fed you in the wilderness, when I brought you out of the land of Egypt."'

33. And Moses said to Aaron, "Take a pot and put an omer of manna in it, and lay it up before the LORD, to be kept for your generations."

34. As the LORD commanded Moses, so Aaron laid it up before the Testimony, to be kept.

35. And the children of Israel ate manna forty years, until they came to an inhabited land; they ate manna until they came to the border of the land of Canaan.

36. Now an omer is one-tenth of an ephah.

## Chapter 17

1. Then all the congregation of the children of Israel set out on their journey from the Wilderness of Sin, according to the commandment of the LORD, and camped in Rephidim; but there was no water for the people to drink.

2. Therefore the people contended with Moses, and said, "Give us water, that we may drink." So Moses said to them, "Why do you contend with me? Why do you tempt the LORD?"

3. And the people thirsted there for water, and the people complained against Moses, and said, "Why is it you have brought us up out of Egypt, to kill us and our children and our livestock with thirst?"

4. So Moses cried out to the LORD, saying, "What shall I do with this people? They are almost ready to stone me!"

5. And the LORD said to Moses, "Go on before the people, and take with you some of the elders of Israel. Also take in your hand your rod with which you struck the river, and go.

6. Behold, I will stand before you there on the rock in Horeb; and you shall strike the rock, and water will come out of it, that the people may drink." And Moses did so in the sight of the elders of Israel.

7. So he called the name of the place Massah and Meribah, because of the contention of the children of Israel, and because they tempted the LORD, saying, "Is the LORD among us or not?"

8. Now Amalek came and fought with Israel in Rephidim.

9. And Moses said to Joshua, "Choose us some men and go out, fight with Amalek. Tomorrow I will stand on the top of the hill with the rod of God in my hand."

10. So Joshua did as Moses said to him, and fought with Amalek. And Moses, Aaron, and Hur went up to the top of the hill.

11. And so it was, when Moses held up his hand, that Israel prevailed; and when he let down his hand, Amalek prevailed.

12. But Moses' hands became heavy; so they took a stone and put it under him, and he sat on it. And Aaron and Hur supported his hands, one on one side, and the other on the other side; and his hands were steady until the going down of the sun.

13. So Joshua defeated Amalek and his people with the edge of the sword.

14. Then the LORD said to Moses, "Write this for a memorial in the book and recount it in the hearing of Joshua, that I will utterly blot out the remembrance of Amalek from under heaven."

15. And Moses built an altar and called its name, The-LORD-Is-My-Banner;

16. for he said, "Because the LORD has sworn: the LORD will have war with Amalek from generation to generation."

## Chapter 18

1. And Jethro, the priest of Midian, Moses' father-in-law, heard of all that God had done for Moses and for Israel His people--that the LORD had brought Israel out of Egypt.

2. Then Jethro, Moses' father-in-law, took Zipporah, Moses' wife, after he had sent her back,

3. with her two sons, of whom the name of one was Gershom (for he said, "I have been a stranger in a foreign land")

4. and the name of the other was Eliezer (for he said, "The God of my father was my help, and delivered me from the sword of Pharaoh");

5. and Jethro, Moses' father-in-law, came with his sons and his wife to Moses in the wilderness, where he was encamped at the mountain of God.

6. Now he had said to Moses, "I, your father-in-law Jethro, am coming to you with your wife and her two sons with her."

7. So Moses went out to meet his father-in-law, bowed down, and kissed him. And they asked each other about their well-being, and they went into the tent.

8. And Moses told his father-in-law all that the LORD had done to Pharaoh and to the Egyptians for Israel's sake, all the hardship that had come upon them on the way, and how the LORD had delivered them.

9. Then Jethro rejoiced for all the good which the LORD had done for Israel, whom He had delivered out of the hand of the Egyptians.

10. And Jethro said, "Blessed be the LORD, who has delivered you out of the hand of the Egyptians and out of the hand of Pharaoh, and who has delivered the people from under the hand of the Egyptians.

11. Now I know that the LORD is greater than all the gods; for in the very thing in which they behaved proudly, He was above them."

12. Then Jethro, Moses' father-in-law, took a burnt offering and other sacrifices to offer to God. And Aaron came with all the elders of Israel to eat bread with Moses' father-in-law before God.

13. And so it was, on the next day, that Moses sat to judge the people; and the people stood before Moses from morning until evening.

14. So when Moses' father-in-law saw all that he did for the people, he said, "What is this thing that you are doing for the people? Why do you alone sit, and all the people stand before you from morning until evening?"

15. And Moses said to his father-in-law, "Because the people come to me to inquire of God.

16. When they have a difficulty, they come to me, and I judge between one and another; and I make known the statutes of God and His laws."

17. So Moses' father-in-law said to him, "The thing that you do is not good.

18. Both you and these people who are with you will surely wear yourselves out. For this thing is too much for you; you are not able to perform it by yourself.

19. Listen now to my voice; I will give you counsel, and God will be with you: Stand before God for the people, so that you may bring the difficulties to God.

20. And you shall teach them the statutes and the laws, and show them the way in which they must walk and the work they must do.

21. Moreover you shall select from all the people able men, such as fear God, men of truth, hating covetousness; and place such over them to be rulers of thousands, rulers of hundreds, rulers of fifties, and rulers of tens.

22. And let them judge the people at all times. Then it will be that every great matter they shall bring to you, but every small matter they themselves shall judge. So it will be easier for you, for they will bear the burden with you.

23. If you do this thing, and God so commands you, then you will be able to endure, and all this people will also go to their place in peace."

24. So Moses heeded the voice of his father-in-law and did all that he had said.

25. And Moses chose able men out of all Israel, and made them heads over the people: rulers of thousands, rulers of hundreds, rulers of fifties, and rulers of tens.

26. So they judged the people at all times; the hard cases they brought to Moses, but they judged every small case themselves.

27. Then Moses let his father-in-law depart, and he went his way to his own land.

## Chapter 19

1. In the third month after the children of Israel had gone out of the land of Egypt, on the same day, they came to the Wilderness of Sinai.

2. For they had departed from Rephidim, had come to the Wilderness of Sinai, and camped in the wilderness. So Israel camped there before the mountain.

3. And Moses went up to God, and the LORD called to him from the mountain, saying, "Thus you shall say to the house of Jacob, and tell the children of Israel:

4. "You have seen what I did to the Egyptians, and how I bore you on eagles' wings and brought you to Myself.

5. Now therefore, if you will indeed obey My voice and keep My covenant, then you shall be a special treasure to Me above all people; for all the earth is Mine.

6. And you shall be to Me a kingdom of priests and a holy nation.' These are the words which you shall speak to the children of Israel."

7. So Moses came and called for the elders of the people, and laid before them all these words which the LORD commanded him.

8. Then all the people answered together and said, "All that the LORD has spoken we will do." So Moses brought back the words of the people to the LORD.

9. And the LORD said to Moses, "Behold, I come to you in the thick cloud, that the people may hear when I speak with you, and believe you forever." So Moses told the words of the people to the LORD.

10. Then the LORD said to Moses, "Go to the people and consecrate them today and tomorrow, and let them wash their clothes.

11. And let them be ready for the third day. For on the third day the LORD will come down upon Mount Sinai in the sight of all the people.

12. You shall set bounds for the people all around, saying, "Take heed to yourselves that you do not go up to the mountain or touch its base. Whoever touches the mountain shall surely be put to death.

13. Not a hand shall touch him, but he shall surely be stoned or shot with an arrow; whether man or beast, he shall not live.' When the trumpet sounds long, they shall come near the mountain."

14. So Moses went down from the mountain to the people and sanctified the people, and they washed their clothes.

15. And he said to the people, "Be ready for the third day; do not come near your wives."

16. Then it came to pass on the third day, in the morning, that there were thunderings and lightnings, and a thick cloud on the mountain; and the sound of the trumpet was very loud, so that all the people who were in the camp trembled.

17. And Moses brought the people out of the camp to meet with God, and they stood at the foot of the mountain.

18. Now Mount Sinai was completely in smoke, because the LORD descended upon it in fire. Its smoke ascended like the smoke of a furnace, and the whole mountain quaked greatly.

19. And when the blast of the trumpet sounded long and became louder and louder, Moses spoke, and God answered him by voice.

20. Then the LORD came down upon Mount Sinai, on the top of the mountain. And the LORD called Moses to the top of the mountain, and Moses went up.

21. And the LORD said to Moses, "Go down and warn the people, lest they break through to gaze at the LORD, and many of them perish.

22. Also let the priests who come near the LORD consecrate themselves, lest the LORD break out against them."

23. But Moses said to the LORD, "The people cannot come up to Mount Sinai; for You warned us, saying, "Set bounds around the mountain and consecrate it."'

24. Then the LORD said to him, "Away! Get down and then come up, you and Aaron with you. But do not let the priests and the people break through to come up to the LORD, lest He break out against them."

25. So Moses went down to the people and spoke to them.

## Chapter 20

1. And God spoke all these words, saying:

2. "I am the LORD your God, who brought you out of the land of Egypt, out of the house of bondage.

3. "You shall have no other gods before Me.

4. "You shall not make for yourself a carved image--any likeness of anything that is in heaven above, or that is in the earth beneath, or that is in the water under the earth;

5. you shall not bow down to them nor serve them. For I, the LORD your God, am a jealous God, visiting the iniquity of the fathers upon the children to the third and fourth generations of those who hate Me,

6. but showing mercy to thousands, to those who love Me and keep My commandments.

7. "You shall not take the name of the LORD your God in vain, for the LORD will not hold him guiltless who takes His name in vain.

8. "Remember the Sabbath day, to keep it holy.

9. Six days you shall labor and do all your work,

10. but the seventh day is the Sabbath of the LORD your God. In it you shall do no work: you, nor your son, nor your daughter, nor your male servant, nor your female servant, nor your cattle, nor your stranger who is within your gates.

11. For in six days the LORD made the heavens and the earth, the sea, and all that is in them, and rested the seventh day. Therefore the LORD blessed the Sabbath day and hallowed it.

12. "Honor your father and your mother, that your days may be long upon the land which the LORD your God is giving you.

13. "You shall not murder.

14. "You shall not commit adultery.

15. "You shall not steal.

16. "You shall not bear false witness against your neighbor.

17. "You shall not covet your neighbor's house; you shall not covet your neighbor's wife, nor his male servant, nor his female servant, nor his ox, nor his donkey, nor anything that is your neighbor's."

18. Now all the people witnessed the thunderings, the lightning flashes, the sound of the trumpet, and the mountain smoking; and when the people saw it, they trembled and stood afar off.

19. Then they said to Moses, "You speak with us, and we will hear; but let not God speak with us, lest we die."

20. And Moses said to the people, "Do not fear; for God has come to test you, and that His fear may be before you, so that you may not sin."

21. So the people stood afar off, but Moses drew near the thick darkness where God was.

22. Then the LORD said to Moses, "Thus you shall say to the children of Israel: "You have seen that I have talked with you from heaven.

23. You shall not make anything to be with Me--gods of silver or gods of gold you shall not make for yourselves.

24. An altar of earth you shall make for Me, and you shall sacrifice on it your burnt offerings and your peace offerings, your sheep and your oxen. In every place where I record My name I will come to you, and I will bless you.

25. And if you make Me an altar of stone, you shall not build it of hewn stone; for if you use your tool on it, you have profaned it.

26. Nor shall you go up by steps to My altar, that your nakedness may not be exposed on it.'

## Chapter 21

1. "Now these are the judgments which you shall set before them:

2. If you buy a Hebrew servant, he shall serve six years; and in the seventh he shall go out free and pay nothing.

3. If he comes in by himself, he shall go out by himself; if he comes in married, then his wife shall go out with him.

4. If his master has given him a wife, and she has borne him sons or daughters, the wife and her children shall be her master's, and he shall go out by himself.

5. But if the servant plainly says, "I love my master, my wife, and my children; I will not go out free,'

6. then his master shall bring him to the judges. He shall also bring him to the door, or to the doorpost, and his master shall pierce his ear with an awl; and he shall serve him forever.

7. "And if a man sells his daughter to be a female slave, she shall not go out as the male slaves do.

8. If she does not please her master, who has betrothed her to himself, then he shall let her be redeemed. He shall have no right to sell her to a foreign people, since he has dealt deceitfully with her.

9. And if he has betrothed her to his son, he shall deal with her according to the custom of daughters.

10. If he takes another wife, he shall not diminish her food, her clothing, and her marriage rights.

11. And if he does not do these three for her, then she shall go out free, without paying money.

12. "He who strikes a man so that he dies shall surely be put to death.

13. However, if he did not lie in wait, but God delivered him into his hand, then I will appoint for you a place where he may flee.

14. "But if a man acts with premeditation against his neighbor, to kill him by treachery, you shall take him from My altar, that he may die.

15. "And he who strikes his father or his mother shall surely be put to death.

16. "He who kidnaps a man and sells him, or if he is found in his hand, shall surely be put to death.

17. "And he who curses his father or his mother shall surely be put to death.

18. "If men contend with each other, and one strikes the other with a stone or with his fist, and he does not die but is confined to his bed,

19. if he rises again and walks about outside with his staff, then he who struck him shall be acquitted. He shall only pay for the loss of his time, and shall provide for him to be thoroughly healed.

20. "And if a man beats his male or female servant with a rod, so that he dies under his hand, he shall surely be punished.

21. Notwithstanding, if he remains alive a day or two, he shall not be punished; for he is his property.

22. "If men fight, and hurt a woman with child, so that she gives birth prematurely, yet no harm follows, he shall surely be punished accordingly as the woman's husband imposes on him; and he shall pay as the judges determine.

23. But if any harm follows, then you shall give life for life,

24. eye for eye, tooth for tooth, hand for hand, foot for foot,

25. burn for burn, wound for wound, stripe for stripe.

26. "If a man strikes the eye of his male or female servant, and destroys it, he shall let him go free for the sake of his eye.

27. And if he knocks out the tooth of his male or female servant, he shall let him go free for the sake of his tooth.

28. "If an ox gores a man or a woman to death, then the ox shall surely be stoned, and its flesh shall not be eaten; but the owner of the ox shall be acquitted.

29. But if the ox tended to thrust with its horn in times past, and it has been made known to his owner, and he has not kept it confined, so that it has killed a man or a woman, the ox shall be stoned and its owner also shall be put to death.

30. If there is imposed on him a sum of money, then he shall pay to redeem his life, whatever is imposed on him.

31. Whether it has gored a son or gored a daughter, according to this judgment it shall be done to him.

32. If the ox gores a male or female servant, he shall give to their master thirty shekels of silver, and the ox shall be stoned.

33. "And if a man opens a pit, or if a man digs a pit and does not cover it, and an ox or a donkey falls in it,

34. the owner of the pit shall make it good; he shall give money to their owner, but the dead animal shall be his.

35. "If one man's ox hurts another's, so that it dies, then they shall sell the live ox and divide the money from it; and the dead ox they shall also divide.

36. Or if it was known that the ox tended to thrust in time past, and its owner has not kept it confined, he shall surely pay ox for ox, and the dead animal shall be his own.

## Chapter 22

1. "If a man steals an ox or a sheep, and slaughters it or sells it, he shall restore five oxen for an ox and four sheep for a sheep.

2. If the thief is found breaking in, and he is struck so that he dies, there shall be no guilt for his bloodshed.

3. If the sun has risen on him, there shall be guilt for his bloodshed. He should make full restitution; if he has nothing, then he shall be sold for his theft.

4. If the theft is certainly found alive in his hand, whether it is an ox or donkey or sheep, he shall restore double.

5. "If a man causes a field or vineyard to be grazed, and lets loose his animal, and it feeds in another man's field, he shall make restitution from the best of his own field and the best of his own vineyard.

6. "If fire breaks out and catches in thorns, so that stacked grain, standing grain, or the field is consumed, he who kindled the fire shall surely make restitution.

7. "If a man delivers to his neighbor money or articles to keep, and it is stolen out of the man's house, if the thief is found, he shall pay double.

8. If the thief is not found, then the master of the house shall be brought to the judges to see whether he has put his hand into his neighbor's goods.

9. "For any kind of trespass, whether it concerns an ox, a donkey, a sheep, or clothing, or for any kind of lost thing which another claims to be his, the cause of both parties shall come before the judges; and whomever the judges condemn shall pay double to his neighbor.

10. If a man delivers to his neighbor a donkey, an ox, a sheep, or any animal to keep, and it dies, is hurt, or driven away, no one seeing it,

11. then an oath of the LORD shall be between them both, that he has not put his hand into his neighbor's goods; and the owner of it shall accept that, and he shall not make it good.

12. But if, in fact, it is stolen from him, he shall make restitution to the owner of it.

13. If it is torn to pieces by a beast, then he shall bring it as evidence, and he shall not make good what was torn.

14. "And if a man borrows anything from his neighbor, and it becomes injured or dies, the owner of it not being with it, he shall surely make it good.

15. If its owner was with it, he shall not make it good; if it was hired, it came for its hire.

16. "If a man entices a virgin who is not betrothed, and lies with her, he shall surely pay the bride-price for her to be his wife.

17. If her father utterly refuses to give her to him, he shall pay money according to the bride-price of virgins.

18. "You shall not permit a sorceress to live.

19. "Whoever lies with an animal shall surely be put to death.

20. "He who sacrifices to any god, except to the LORD only, he shall be utterly destroyed.

21. "You shall neither mistreat a stranger nor oppress him, for you were strangers in the land of Egypt.

22. "You shall not afflict any widow or fatherless child.

23. If you afflict them in any way, and they cry at all to Me, I will surely hear their cry;

24. and My wrath will become hot, and I will kill you with the sword; your wives shall be widows, and your children fatherless.

25. "If you lend money to any of My people who are poor among you, you shall not be like a moneylender to him; you shall not charge him interest.

26. If you ever take your neighbor's garment as a pledge, you shall return it to him before the sun goes down.

27. For that is his only covering, it is his garment for his skin. What will he sleep in? And it will be that when he cries to Me, I will hear, for I am gracious.

28. "You shall not revile God, nor curse a ruler of your people.

29. "You shall not delay to offer the first of your ripe produce and your juices. The firstborn of your sons you shall give to Me.

30. Likewise you shall do with your oxen and your sheep. It shall be with its mother seven days; on the eighth day you shall give it to Me.

31. "And you shall be holy men to Me: you shall not eat meat torn by beasts in the field; you shall throw it to the dogs.

## Chapter 23

1. "You shall not circulate a false report. Do not put your hand with the wicked to be an unrighteous witness.

2. You shall not follow a crowd to do evil; nor shall you testify in a dispute so as to turn aside after many to pervert justice.

3. You shall not show partiality to a poor man in his dispute.

4. "If you meet your enemy's ox or his donkey going astray, you shall surely bring it back to him again.

5. If you see the donkey of one who hates you lying under its burden, and you would refrain from helping it, you shall surely help him with it.

6. "You shall not pervert the judgment of your poor in his dispute.

7. Keep yourself far from a false matter; do not kill the innocent and righteous. For I will not justify the wicked.

8. And you shall take no bribe, for a bribe blinds the discerning and perverts the words of the righteous.

9. "Also you shall not oppress a stranger, for you know the heart of a stranger, because you were strangers in the land of Egypt.

10. "Six years you shall sow your land and gather in its produce,

11. but the seventh year you shall let it rest and lie fallow, that the poor of your people may eat; and what they leave, the beasts of the field may eat. In like manner you shall do with your vineyard and your olive grove.

12. Six days you shall do your work, and on the seventh day you shall rest, that your ox and your donkey may rest, and the son of your female servant and the stranger may be refreshed.

13. "And in all that I have said to you, be circumspect and make no mention of the name of other gods, nor let it be heard from your mouth.

14. "Three times you shall keep a feast to Me in the year:

15. You shall keep the Feast of Unleavened Bread (you shall eat unleavened bread seven days, as I commanded you, at the time appointed in the month of Abib, for in it you came out of Egypt; none shall appear before Me empty);

16. and the Feast of Harvest, the firstfruits of your labors which you have sown in the field; and the Feast of Ingathering at the end of the year, when you have gathered in the fruit of your labors from the field.

17. "Three times in the year all your males shall appear before the Lord GOD.

18. "You shall not offer the blood of My sacrifice with leavened bread; nor shall the fat of My sacrifice remain until morning.

19. The first of the firstfruits of your land you shall bring into the house of the LORD your God. You shall not boil a young goat in its mother's milk.

20. "Behold, I send an Angel before you to keep you in the way and to bring you into the place which I have prepared.

21. Beware of Him and obey His voice; do not provoke Him, for He will not pardon your transgressions; for My name is in Him.

22. But if you indeed obey His voice and do all that I speak, then I will be an enemy to your enemies and an adversary to your adversaries.

23. For My Angel will go before you and bring you in to the Amorites and the Hittites and the Perizzites and the Canaanites and the Hivites and the Jebusites; and I will cut them off.

24. You shall not bow down to their gods, nor serve them, nor do according to their works; but you shall utterly overthrow them and completely break down their sacred pillars.

25. "So you shall serve the LORD your God, and He will bless your bread and your water. And I will take sickness away from the midst of you.

26. No one shall suffer miscarriage or be barren in your land; I will fulfill the number of your days.

27. "I will send My fear before you, I will cause confusion among all the people to whom you come, and will make all your enemies turn their backs to you.

28. And I will send hornets before you, which shall drive out the Hivite, the Canaanite, and the Hittite from before you.

29. I will not drive them out from before you in one year, lest the land become desolate and the beasts of the field become too numerous for you.

30. Little by little I will drive them out from before you, until you have increased, and you inherit the land.

31. And I will set your bounds from the Red Sea to the sea, Philistia, and from the desert to the River. For I will deliver the inhabitants of the land into your hand, and you shall drive them out before you.

32. You shall make no covenant with them, nor with their gods.

33. They shall not dwell in your land, lest they make you sin against Me. For if you serve their gods, it will surely be a snare to you."

## Chapter 24

1. Now He said to Moses, "Come up to the LORD, you and Aaron, Nadab and Abihu, and seventy of the elders of Israel, and worship from afar.

2. And Moses alone shall come near the LORD, but they shall not come near; nor shall the people go up with him."

3. So Moses came and told the people all the words of the LORD and all the judgments. And all the people answered with one voice and said, "All the words which the LORD has said we will do."

4. And Moses wrote all the words of the LORD. And he rose early in the morning, and built an altar at the foot of the mountain, and twelve pillars according to the twelve tribes of Israel.

5. Then he sent young men of the children of Israel, who offered burnt offerings and sacrificed peace offerings of oxen to the LORD.

6. And Moses took half the blood and put it in basins, and half the blood he sprinkled on the altar.

7. Then he took the Book of the Covenant and read in the hearing of the people. And they said, "All that the LORD has said we will do, and be obedient."

8. And Moses took the blood, sprinkled it on the people, and said, "This is the blood of the covenant which the LORD has made with you according to all these words."

9. Then Moses went up, also Aaron, Nadab, and Abihu, and seventy of the elders of Israel,

10. and they saw the God of Israel. And there was under His feet as it were a paved work of sapphire stone, and it was like the very heavens in its clarity.

11. But on the nobles of the children of Israel He did not lay His hand. So they saw God, and they ate and drank.

12. Then the LORD said to Moses, "Come up to Me on the mountain and be there; and I will give you tablets of stone, and the law and commandments which I have written, that you may teach them."

13. So Moses arose with his assistant Joshua, and Moses went up to the mountain of God.

14. And he said to the elders, "Wait here for us until we come back to you. Indeed, Aaron and Hur are with you. If any man has a difficulty, let him go to them."

15. Then Moses went up into the mountain, and a cloud covered the mountain.

16. Now the glory of the LORD rested on Mount Sinai, and the cloud covered it six days. And on the seventh day He called to Moses out of the midst of the cloud.

17. The sight of the glory of the LORD was like a consuming fire on the top of the mountain in the eyes of the children of Israel.

18. So Moses went into the midst of the cloud and went up into the mountain. And Moses was on the mountain forty days and forty nights.

## Chapter 25

1. Then the LORD spoke to Moses, saying:

2. "Speak to the children of Israel, that they bring Me an offering. From everyone who gives it willingly with his heart you shall take My offering.

3. And this is the offering which you shall take from them: gold, silver, and bronze;

4. blue, purple, and scarlet thread, fine linen, and goats' hair;

5. ram skins dyed red, badger skins, and acacia wood;

6. oil for the light, and spices for the anointing oil and for the sweet incense;

7. onyx stones, and stones to be set in the ephod and in the breastplate.

8. And let them make Me a sanctuary, that I may dwell among them.

9. According to all that I show you, that is, the pattern of the tabernacle and the pattern of all its furnishings, just so you shall make it.

10. "And they shall make an ark of acacia wood; two and a half cubits shall be its length, a cubit and a half its width, and a cubit and a half its height.

11. And you shall overlay it with pure gold, inside and out you shall overlay it, and shall make on it a molding of gold all around.

12. You shall cast four rings of gold for it, and put them in its four corners; two rings shall be on one side, and two rings on the other side.

13. And you shall make poles of acacia wood, and overlay them with gold.

14. You shall put the poles into the rings on the sides of the ark, that the ark may be carried by them.

15. The poles shall be in the rings of the ark; they shall not be taken from it.

16. And you shall put into the ark the Testimony which I will give you.

17. "You shall make a mercy seat of pure gold; two and a half cubits shall be its length and a cubit and a half its width.

18. And you shall make two cherubim of gold; of hammered work you shall make them at the two ends of the mercy seat.

19. Make one cherub at one end, and the other cherub at the other end; you shall make the cherubim at the two ends of it of one piece with the mercy seat.

20. And the cherubim shall stretch out their wings above, covering the mercy seat with their wings, and they shall face one another; the faces of the cherubim shall be toward the mercy seat.

21. You shall put the mercy seat on top of the ark, and in the ark you shall put the Testimony that I will give you.

22. And there I will meet with you, and I will speak with you from above the mercy seat, from between the two cherubim which are on the ark of the Testimony, about everything which I will give you in commandment to the children of Israel.

23. "You shall also make a table of acacia wood; two cubits shall be its length, a cubit its width, and a cubit and a half its height.

24. And you shall overlay it with pure gold, and make a molding of gold all around.

25. You shall make for it a frame of a handbreadth all around, and you shall make a gold molding for the frame all around.

26. And you shall make for it four rings of gold, and put the rings on the four corners that are at its four legs.

27. The rings shall be close to the frame, as holders for the poles to bear the table.

28. And you shall make the poles of acacia wood, and overlay them with gold, that the table may be carried with them.

29. You shall make its dishes, its pans, its pitchers, and its bowls for pouring. You shall make them of pure gold.

30. And you shall set the showbread on the table before Me always.

31. "You shall also make a lampstand of pure gold; the lampstand shall be of hammered work. Its shaft, its branches, its bowls, its ornamental knobs, and flowers shall be of one piece.

32. And six branches shall come out of its sides: three branches of the lampstand out of one side, and three branches of the lampstand out of the other side.

33. Three bowls shall be made like almond blossoms on one branch, with an ornamental knob and a flower, and three bowls made like almond blossoms on the other branch, with an ornamental knob and a flower--and so for the six branches that come out of the lampstand.

34. On the lampstand itself four bowls shall be made like almond blossoms, each with its ornamental knob and flower.

35. And there shall be a knob under the first two branches of the same, a knob under the second two branches of the same, and a knob under the third two branches of the same, according to the six branches that extend from the lampstand.

36. Their knobs and their branches shall be of one piece; all of it shall be one hammered piece of pure gold.

37. You shall make seven lamps for it, and they shall arrange its lamps so that they give light in front of it.

38. And its wick-trimmers and their trays shall be of pure gold.

39. It shall be made of a talent of pure gold, with all these utensils.

40. And see to it that you make them according to the pattern which was shown you on the mountain.

## Chapter 26

1. "Moreover you shall make the tabernacle with ten curtains of fine woven linen and blue, purple, and scarlet thread; with artistic designs of cherubim you shall weave them.

2. The length of each curtain shall be twenty-eight cubits, and the width of each curtain four cubits. And every one of the curtains shall have the same measurements.

3. Five curtains shall be coupled to one another, and the other five curtains shall be coupled to one another.

4. And you shall make loops of blue yarn on the edge of the curtain on the selvedge of one set, and likewise you shall do on the outer edge of the other curtain of the second set.

5. Fifty loops you shall make in the one curtain, and fifty loops you shall make on the edge of the curtain that is on the end of the second set, that the loops may be clasped to one another.

6. And you shall make fifty clasps of gold, and couple the curtains together with the clasps, so that it may be one tabernacle.

7. "You shall also make curtains of goats' hair, to be a tent over the tabernacle. You shall make eleven curtains.

8. The length of each curtain shall be thirty cubits, and the width of each curtain four cubits; and the eleven curtains shall all have the same measurements.

9. And you shall couple five curtains by themselves and six curtains by themselves, and you shall double over the sixth curtain at the forefront of the tent.

10. You shall make fifty loops on the edge of the curtain that is outermost in one set, and fifty loops on the edge of the curtain of the second set.

11. And you shall make fifty bronze clasps, put the clasps into the loops, and couple the tent together, that it may be one.

12. The remnant that remains of the curtains of the tent, the half curtain that remains, shall hang over the back of the tabernacle.

13. And a cubit on one side and a cubit on the other side, of what remains of the length of the curtains of the tent, shall hang over the sides of the tabernacle, on this side and on that side, to cover it.

14. "You shall also make a covering of ram skins dyed red for the tent, and a covering of badger skins above that.

15. "And for the tabernacle you shall make the boards of acacia wood, standing upright.

16. Ten cubits shall be the length of a board, and a cubit and a half shall be the width of each board.

17. Two tenons shall be in each board for binding one to another. Thus you shall make for all the boards of the tabernacle.

18. And you shall make the boards for the tabernacle, twenty boards for the south side.

19. You shall make forty sockets of silver under the twenty boards: two sockets under each of the boards for its two tenons.

20. And for the second side of the tabernacle, the north side, there shall be twenty boards

21. and their forty sockets of silver: two sockets under each of the boards.

22. For the far side of the tabernacle, westward, you shall make six boards.

23. And you shall also make two boards for the two back corners of the tabernacle.

24. They shall be coupled together at the bottom and they shall be coupled together at the top by one ring. Thus it shall be for both of them. They shall be for the two corners.

25. So there shall be eight boards with their sockets of silver--sixteen sockets--two sockets under each of the boards.

26. "And you shall make bars of acacia wood: five for the boards on one side of the tabernacle,

27. five bars for the boards on the other side of the tabernacle, and five bars for the boards of the side of the tabernacle, for the far side westward.

28. The middle bar shall pass through the midst of the boards from end to end.

29. You shall overlay the boards with gold, make their rings of gold as holders for the bars, and overlay the bars with gold.

30. And you shall raise up the tabernacle according to its pattern which you were shown on the mountain.

31. "You shall make a veil woven of blue, purple, and scarlet thread, and fine woven linen. It shall be woven with an artistic design of cherubim.

32. You shall hang it upon the four pillars of acacia wood overlaid with gold. Their hooks shall be gold, upon four sockets of silver.

33. And you shall hang the veil from the clasps. Then you shall bring the ark of the Testimony in there, behind the veil. The veil shall be a divider for you between the holy place and the Most Holy.

34. You shall put the mercy seat upon the ark of the Testimony in the Most Holy.

35. You shall set the table outside the veil, and the lampstand across from the table on the side of the tabernacle toward the south; and you shall put the table on the north side.

36. "You shall make a screen for the door of the tabernacle, woven of blue, purple, and scarlet thread, and fine woven linen, made by a weaver.

37. And you shall make for the screen five pillars of acacia wood, and overlay them with gold; their hooks shall be gold, and you shall cast five sockets of bronze for them.

## Chapter 27

1. "You shall make an altar of acacia wood, five cubits long and five cubits wide--the altar shall be square--and its height shall be three cubits.

2. You shall make its horns on its four corners; its horns shall be of one piece with it. And you shall overlay it with bronze.

3. Also you shall make its pans to receive its ashes, and its shovels and its basins and its forks and its firepans; you shall make all its utensils of bronze.

4. You shall make a grate for it, a network of bronze; and on the network you shall make four bronze rings at its four corners.

5. You shall put it under the rim of the altar beneath, that the network may be midway up the altar.

6. And you shall make poles for the altar, poles of acacia wood, and overlay them with bronze.

7. The poles shall be put in the rings, and the poles shall be on the two sides of the altar to bear it.

8. You shall make it hollow with boards; as it was shown you on the mountain, so shall they make it.

9. "You shall also make the court of the tabernacle. For the south side there shall be hangings for the court made of fine woven linen, one hundred cubits long for one side.

10. And its twenty pillars and their twenty sockets shall be bronze. The hooks of the pillars and their bands shall be silver.

11. Likewise along the length of the north side there shall be hangings one hundred cubits long, with its twenty pillars and their twenty sockets of bronze, and the hooks of the pillars and their bands of silver.

12. "And along the width of the court on the west side shall be hangings of fifty cubits, with their ten pillars and their ten sockets.

13. The width of the court on the east side shall be fifty cubits.

14. The hangings on one side of the gate shall be fifteen cubits, with their three pillars and their three sockets.

15. And on the other side shall be hangings of fifteen cubits, with their three pillars and their three sockets.

16. "For the gate of the court there shall be a screen twenty cubits long, woven of blue, purple, and scarlet thread, and fine woven linen, made by a weaver. It shall have four pillars and four sockets.

17. All the pillars around the court shall have bands of silver; their hooks shall be of silver and their sockets of bronze.

18. The length of the court shall be one hundred cubits, the width fifty throughout, and the height five cubits, made of fine woven linen, and its sockets of bronze.

19. All the utensils of the tabernacle for all its service, all its pegs, and all the pegs of the court, shall be of bronze.

20. "And you shall command the children of Israel that they bring you pure oil of pressed olives for the light, to cause the lamp to burn continually.

21. In the tabernacle of meeting, outside the veil which is before the Testimony, Aaron and his sons shall tend it from evening until morning before the LORD. It shall be a statute forever to their generations on behalf of the children of Israel.

## Chapter 28

1. "Now take Aaron your brother, and his sons with him, from among the children of Israel, that he may minister to Me as priest, Aaron and Aaron's sons: Nadab, Abihu, Eleazar, and Ithamar.

2. And you shall make holy garments for Aaron your brother, for glory and for beauty.

3. So you shall speak to all who are gifted artisans, whom I have filled with the spirit of wisdom, that they may make Aaron's garments, to consecrate him, that he may minister to Me as priest.

4. And these are the garments which they shall make: a breastplate, an ephod, a robe, a skillfully woven tunic, a turban, and a sash. So they shall make holy garments for Aaron your brother and his sons, that he may minister to Me as priest.

5. "They shall take the gold, blue, purple, and scarlet thread, and the fine linen,

6. and they shall make the ephod of gold, blue, purple, and scarlet thread, and fine woven linen, artistically worked.

7. It shall have two shoulder straps joined at its two edges, and so it shall be joined together.

8. And the intricately woven band of the ephod, which is on it, shall be of the same workmanship, made of gold, blue, purple, and scarlet thread, and fine woven linen.

9. "Then you shall take two onyx stones and engrave on them the names of the sons of Israel:

10. six of their names on one stone and six names on the other stone, in order of their birth.

11. With the work of an engraver in stone, like the engravings of a signet, you shall engrave the two stones with the names of the sons of Israel. You shall set them in settings of gold.

12. And you shall put the two stones on the shoulders of the ephod as memorial stones for the sons of Israel. So Aaron shall bear their names before the LORD on his two shoulders as a memorial.

13. You shall also make settings of gold,

14. and you shall make two chains of pure gold like braided cords, and fasten the braided chains to the settings.

15. "You shall make the breastplate of judgment. Artistically woven according to the workmanship of the ephod you shall make it: of gold, blue, purple, and scarlet thread, and fine woven linen, you shall make it.

16. It shall be doubled into a square: a span shall be its length, and a span shall be its width.

17. And you shall put settings of stones in it, four rows of stones: The first row shall be a sardius, a topaz, and an emerald; this shall be the first row;

18. the second row shall be a turquoise, a sapphire, and a diamond;

19. the third row, a jacinth, an agate, and an amethyst;

20. and the fourth row, a beryl, an onyx, and a jasper. They shall be set in gold settings.

21. And the stones shall have the names of the sons of Israel, twelve according to their names, like the engravings of a signet, each one with its own name; they shall be according to the twelve tribes.

22. "You shall make chains for the breastplate at the end, like braided cords of pure gold.

23. And you shall make two rings of gold for the breastplate, and put the two rings on the two ends of the breastplate.

24. Then you shall put the two braided chains of gold in the two rings which are on the ends of the breastplate;

25. and the other two ends of the two braided chains you shall fasten to the two settings, and put them on the shoulder straps of the ephod in the front.

26. "You shall make two rings of gold, and put them on the two ends of the breastplate, on the edge of it, which is on the inner side of the ephod.

27. And two other rings of gold you shall make, and put them on the two shoulder straps, underneath the ephod toward its front, right at the seam above the intricately woven band of the ephod.

28. They shall bind the breastplate by means of its rings to the rings of the ephod, using a blue cord, so that it is above the intricately woven band of the ephod, and so that the breastplate does not come loose from the ephod.

29. "So Aaron shall bear the names of the sons of Israel on the breastplate of judgment over his heart, when he goes into the holy place, as a memorial before the LORD continually.

30. And you shall put in the breastplate of judgment the Urim and the Thummim, and they shall be over Aaron's heart when he goes in before the LORD. So Aaron shall bear the judgment of the children of Israel over his heart before the LORD continually.

31. "You shall make the robe of the ephod all of blue.

32. There shall be an opening for his head in the middle of it; it shall have a woven binding all around its opening, like the opening in a coat of mail, so that it does not tear.

33. And upon its hem you shall make pomegranates of blue, purple, and scarlet, all around its hem, and bells of gold between them all around:

34. a golden bell and a pomegranate, a golden bell and a pomegranate, upon the hem of the robe all around.

35. And it shall be upon Aaron when he ministers, and its sound will be heard when he goes into the holy place before the LORD and when he comes out, that he may not die.

36. "You shall also make a plate of pure gold and engrave on it, like the engraving of a signet: HOLINESS TO THE LORD.

37. And you shall put it on a blue cord, that it may be on the turban; it shall be on the front of the turban.

38. So it shall be on Aaron's forehead, that Aaron may bear the iniquity of the holy things which the children of Israel hallow in all their holy gifts; and it shall always be on his forehead, that they may be accepted before the LORD.

39. "You shall skillfully weave the tunic of fine linen thread, you shall make the turban of fine linen, and you shall make the sash of woven work.

40. "For Aaron's sons you shall make tunics, and you shall make sashes for them. And you shall make hats for them, for glory and beauty.

41. So you shall put them on Aaron your brother and on his sons with him. You shall anoint them, consecrate them, and sanctify them, that they may minister to Me as priests.

42. And you shall make for them linen trousers to cover their nakedness; they shall reach from the waist to the thighs.

43. They shall be on Aaron and on his sons when they come into the tabernacle of meeting, or when they come near the altar to minister in the holy place, that they do not incur iniquity and die. It shall be a statute forever to him and his descendants after him.

## Chapter 29

1. "And this is what you shall do to them to hallow them for ministering to Me as priests: Take one young bull and two rams without blemish,

2. and unleavened bread, unleavened cakes mixed with oil, and unleavened wafers anointed with oil (you shall make them of wheat flour).

3. You shall put them in one basket and bring them in the basket, with the bull and the two rams.

4. "And Aaron and his sons you shall bring to the door of the tabernacle of meeting, and you shall wash them with water.

5. Then you shall take the garments, put the tunic on Aaron, and the robe of the ephod, the ephod, and the breastplate, and gird him with the intricately woven band of the ephod.

6. You shall put the turban on his head, and put the holy crown on the turban.

7. And you shall take the anointing oil, pour it on his head, and anoint him.

8. Then you shall bring his sons and put tunics on them.

9. And you shall gird them with sashes, Aaron and his sons, and put the hats on them. The priesthood shall be theirs for a perpetual statute. So you shall consecrate Aaron and his sons.

10. "You shall also have the bull brought before the tabernacle of meeting, and Aaron and his sons shall put their hands on the head of the bull.

11. Then you shall kill the bull before the LORD, by the door of the tabernacle of meeting.

12. You shall take some of the blood of the bull and put it on the horns of the altar with your finger, and pour all the blood beside the base of the altar.

13. And you shall take all the fat that covers the entrails, the fatty lobe attached to the liver, and the two kidneys and the fat that is on them, and burn them on the altar.

14. But the flesh of the bull, with its skin and its offal, you shall burn with fire outside the camp. It is a sin offering.

15. "You shall also take one ram, and Aaron and his sons shall put their hands on the head of the ram;

16. and you shall kill the ram, and you shall take its blood and sprinkle it all around on the altar.

17. Then you shall cut the ram in pieces, wash its entrails and its legs, and put them with its pieces and with its head.

18. And you shall burn the whole ram on the altar. It is a burnt offering to the LORD; it is a sweet aroma, an offering made by fire to the LORD.

19. "You shall also take the other ram, and Aaron and his sons shall put their hands on the head of the ram.

20. Then you shall kill the ram, and take some of its blood and put it on the tip of the right ear of Aaron and on the tip of the right ear of his sons, on the thumb of their right hand and on the big toe of their right foot, and sprinkle the blood all around on the altar.

21. And you shall take some of the blood that is on the altar, and some of the anointing oil, and sprinkle it on Aaron and on his garments, on his sons and on the garments of his sons with him; and he and his garments shall be hallowed, and his sons and his sons' garments with him.

22. "Also you shall take the fat of the ram, the fat tail, the fat that covers the entrails, the fatty lobe attached to the liver, the two kidneys and the fat on them, the right thigh (for it is a ram of consecration),

23. one loaf of bread, one cake made with oil, and one wafer from the basket of the unleavened bread that is before the LORD;

24. and you shall put all these in the hands of Aaron and in the hands of his sons, and you shall wave them as a wave offering before the LORD.

25. You shall receive them back from their hands and burn them on the altar as a burnt offering, as a sweet aroma before the LORD. It is an offering made by fire to the LORD.

26. "Then you shall take the breast of the ram of Aaron's consecration and wave it as a wave offering before the LORD; and it shall be your portion.

27. And from the ram of the consecration you shall consecrate the breast of the wave offering which is waved, and the thigh of the heave offering which is raised, of that which is for Aaron and of that which is for his sons.

28. It shall be from the children of Israel for Aaron and his sons by a statute forever. For it is a heave offering; it shall be a heave offering from the children of Israel from the sacrifices of their peace offerings, that is, their heave offering to the LORD.

29. "And the holy garments of Aaron shall be his sons' after him, to be anointed in them and to be consecrated in them.

30. That son who becomes priest in his place shall put them on for seven days, when he enters the tabernacle of meeting to minister in the holy place.

31. "And you shall take the ram of the consecration and boil its flesh in the holy place.

32. Then Aaron and his sons shall eat the flesh of the ram, and the bread that is in the basket, by the door of the tabernacle of meeting.

33. They shall eat those things with which the atonement was made, to consecrate and to sanctify them; but an outsider shall not eat them, because they are holy.

34. And if any of the flesh of the consecration offerings, or of the bread, remains until the morning, then you shall burn the remainder with fire. It shall not be eaten, because it is holy.

35. "Thus you shall do to Aaron and his sons, according to all that I have commanded you. Seven days you shall consecrate them.

36. And you shall offer a bull every day as a sin offering for atonement. You shall cleanse the altar when you make atonement for it, and you shall anoint it to sanctify it.

37. Seven days you shall make atonement for the altar and sanctify it. And the altar shall be most holy. Whatever touches the altar must be holy.

38. "Now this is what you shall offer on the altar: two lambs of the first year, day by day continually.

39. One lamb you shall offer in the morning, and the other lamb you shall offer at twilight.

40. With the one lamb shall be one-tenth of an ephah of flour mixed with one-fourth of a hin of pressed oil, and one-fourth of a hin of wine as a drink offering.

41. And the other lamb you shall offer at twilight; and you shall offer with it the grain offering and the drink offering, as in the morning, for a sweet aroma, an offering made by fire to the LORD.

42. This shall be a continual burnt offering throughout your generations at the door of the tabernacle of meeting before the LORD, where I will meet you to speak with you.

43. And there I will meet with the children of Israel, and the tabernacle shall be sanctified by My glory.

44. So I will consecrate the tabernacle of meeting and the altar. I will also consecrate both Aaron and his sons to minister to Me as priests.

45. I will dwell among the children of Israel and will be their God.

46. And they shall know that I am the LORD their God, who brought them up out of the land of Egypt, that I may dwell among them. I am the LORD their God.

## Chapter 30

1. "You shall make an altar to burn incense on; you shall make it of acacia wood.

2. A cubit shall be its length and a cubit its width--it shall be square--and two cubits shall be its height. Its horns shall be of one piece with it.

3. And you shall overlay its top, its sides all around, and its horns with pure gold; and you shall make for it a molding of gold all around.

4. Two gold rings you shall make for it, under the molding on both its sides. You shall place them on its two sides, and they will be holders for the poles with which to bear it.

5. You shall make the poles of acacia wood, and overlay them with gold.

6. And you shall put it before the veil that is before the ark of the Testimony, before the mercy seat that is over the Testimony, where I will meet with you.

7. "Aaron shall burn on it sweet incense every morning; when he tends the lamps, he shall burn incense on it.

8. And when Aaron lights the lamps at twilight, he shall burn incense on it, a perpetual incense before the LORD throughout your generations.

9. You shall not offer strange incense on it, or a burnt offering, or a grain offering; nor shall you pour a drink offering on it.

10. And Aaron shall make atonement upon its horns once a year with the blood of the sin offering of atonement; once a year he shall make atonement upon it throughout your generations. It is most holy to the LORD."

11. Then the LORD spoke to Moses, saying:

12. "When you take the census of the children of Israel for their number, then every man shall give a ransom for himself to the LORD, when you number them, that there may be no plague among them when you number them.

13. This is what everyone among those who are numbered shall give: half a shekel according to the shekel of the sanctuary (a shekel is twenty gerahs). The half-shekel shall be an offering to the LORD.

14. Everyone included among those who are numbered, from twenty years old and above, shall give an offering to the LORD.

15. The rich shall not give more and the poor shall not give less than half a shekel, when you give an offering to the LORD, to make atonement for yourselves.

16. And you shall take the atonement money of the children of Israel, and shall appoint it for the service of the tabernacle of meeting, that it may be a memorial for the children of Israel before the LORD, to make atonement for yourselves."

17. Then the LORD spoke to Moses, saying:

18. "You shall also make a laver of bronze, with its base also of bronze, for washing. You shall put it between the tabernacle of meeting and the altar. And you shall put water in it,

19. for Aaron and his sons shall wash their hands and their feet in water from it.

20. When they go into the tabernacle of meeting, or when they come near the altar to minister, to burn an offering made by fire to the LORD, they shall wash with water, lest they die.

21. So they shall wash their hands and their feet, lest they die. And it shall be a statute forever to them--to him and his descendants throughout their generations."

22. Moreover the LORD spoke to Moses, saying:

23. "Also take for yourself quality spices--five hundred shekels of liquid myrrh, half as much sweet-smelling cinnamon (two hundred and fifty shekels), two hundred and fifty shekels of sweet-smelling cane,

24. five hundred shekels of cassia, according to the shekel of the sanctuary, and a hin of olive oil.

25. And you shall make from these a holy anointing oil, an ointment compounded according to the art of the perfumer. It shall be a holy anointing oil.

26. With it you shall anoint the tabernacle of meeting and the ark of the Testimony;

27. the table and all its utensils, the lampstand and its utensils, and the altar of incense;

28. the altar of burnt offering with all its utensils, and the laver and its base.

29. You shall consecrate them, that they may be most holy; whatever touches them must be holy.

30. And you shall anoint Aaron and his sons, and consecrate them, that they may minister to Me as priests.

31. "And you shall speak to the children of Israel, saying: "This shall be a holy anointing oil to Me throughout your generations.

32. It shall not be poured on man's flesh; nor shall you make any other like it, according to its composition. It is holy, and it shall be holy to you.

33. Whoever compounds any like it, or whoever puts any of it on an outsider, shall be cut off from his people."'

34. And the LORD said to Moses: "Take sweet spices, stacte and onycha and galbanum, and pure frankincense with these sweet spices; there shall be equal amounts of each.

35. You shall make of these an incense, a compound according to the art of the perfumer, salted, pure, and holy.

36. And you shall beat some of it very fine, and put some of it before the Testimony in the tabernacle of meeting where I will meet with you. It shall be most holy to you.

37. But as for the incense which you shall make, you shall not make any for yourselves, according to its composition. It shall be to you holy for the LORD.

38. Whoever makes any like it, to smell it, he shall be cut off from his people."

## Chapter 31

1. Then the LORD spoke to Moses, saying:

2. "See, I have called by name Bezalel the son of Uri, the son of Hur, of the tribe of Judah.

3. And I have filled him with the Spirit of God, in wisdom, in understanding, in knowledge, and in all manner of workmanship,

4. to design artistic works, to work in gold, in silver, in bronze,

5. in cutting jewels for setting, in carving wood, and to work in all manner of workmanship.

6. "And I, indeed I, have appointed with him Aholiab the son of Ahisamach, of the tribe of Dan; and I have put wisdom in the hearts of all the gifted artisans, that they may make all that I have commanded you:

7. the tabernacle of meeting, the ark of the Testimony and the mercy seat that is on it, and all the furniture of the tabernacle--

8. the table and its utensils, the pure gold lampstand with all its utensils, the altar of incense,

9. the altar of burnt offering with all its utensils, and the laver and its base--

10. the garments of ministry, the holy garments for Aaron the priest and the garments of his sons, to minister as priests,

11. and the anointing oil and sweet incense for the holy place. According to all that I have commanded you they shall do."

12. And the LORD spoke to Moses, saying,

13. "Speak also to the children of Israel, saying: "Surely My Sabbaths you shall keep, for it is a sign between Me and you throughout your generations, that you may know that I am the LORD who sanctifies you.

14. You shall keep the Sabbath, therefore, for it is holy to you. Everyone who profanes it shall surely be put to death; for whoever does any work on it, that person shall be cut off from among his people.

15. Work shall be done for six days, but the seventh is the Sabbath of rest, holy to the LORD. Whoever does any work on the Sabbath day, he shall surely be put to death.

16. Therefore the children of Israel shall keep the Sabbath, to observe the Sabbath throughout their generations as a perpetual covenant.

17. It is a sign between Me and the children of Israel forever; for in six days the LORD made the heavens and the earth, and on the seventh day He rested and was refreshed."'

18. And when He had made an end of speaking with him on Mount Sinai, He gave Moses two tablets of the Testimony, tablets of stone, written with the finger of God.

## Chapter 32

1. Now when the people saw that Moses delayed coming down from the mountain, the people gathered together to Aaron, and said to him, "Come, make us gods that shall go before us; for as for this Moses, the man who brought us up out of the land of Egypt, we do not know what has become of him."

2. And Aaron said to them, "Break off the golden earrings which are in the ears of your wives, your sons, and your daughters, and bring them to me."

3. So all the people broke off the golden earrings which were in their ears, and brought them to Aaron.

4. And he received the gold from their hand, and he fashioned it with an engraving tool, and made a molded calf. Then they said, "This is your god, O Israel, that brought you out of the land of Egypt!"

5. So when Aaron saw it, he built an altar before it. And Aaron made a proclamation and said, "Tomorrow is a feast to the LORD."

6. Then they rose early on the next day, offered burnt offerings, and brought peace offerings; and the people sat down to eat and drink, and rose up to play.

7. And the LORD said to Moses, "Go, get down! For your people whom you brought out of the land of Egypt have corrupted themselves.

8. They have turned aside quickly out of the way which I commanded them. They have made themselves a molded calf, and worshiped it and sacrificed to it, and said, "This is your god, O Israel, that brought you out of the land of Egypt!"'

9. And the LORD said to Moses, "I have seen this people, and indeed it is a stiff-necked people!

10. Now therefore, let Me alone, that My wrath may burn hot against them and I may consume them. And I will make of you a great nation."

11. Then Moses pleaded with the LORD his God, and said: "LORD, why does Your wrath burn hot against Your people whom You have brought out of the land of Egypt with great power and with a mighty hand?

12. Why should the Egyptians speak, and say, "He brought them out to harm them, to kill them in the mountains, and to consume them from the face of the earth'? Turn from Your fierce wrath, and relent from this harm to Your people.

13. Remember Abraham, Isaac, and Israel, Your servants, to whom You swore by Your own self, and said to them, "I will multiply your descendants as the stars of heaven; and all this land that I have spoken of I give to your descendants, and they shall inherit it forever."'

14. So the LORD relented from the harm which He said He would do to His people.

15. And Moses turned and went down from the mountain, and the two tablets of the Testimony were in his hand. The tablets were written on both sides; on the one side and on the other they were written.

16. Now the tablets were the work of God, and the writing was the writing of God engraved on the tablets.

17. And when Joshua heard the noise of the people as they shouted, he said to Moses, "There is a noise of war in the camp."

18. But he said: "It is not the noise of the shout of victory, Nor the noise of the cry of defeat, But the sound of singing I hear."

19. So it was, as soon as he came near the camp, that he saw the calf and the dancing. So Moses' anger became hot, and he cast the tablets out of his hands and broke them at the foot of the mountain.

20. Then he took the calf which they had made, burned it in the fire, and ground it to powder; and he scattered it on the water and made the children of Israel drink it.

21. And Moses said to Aaron, "What did this people do to you that you have brought so great a sin upon them?"

22. So Aaron said, "Do not let the anger of my lord become hot. You know the people, that they are set on evil.

23. For they said to me, "Make us gods that shall go before us; as for this Moses, the man who brought us out of the land of Egypt, we do not know what has become of him.'

24. And I said to them, "Whoever has any gold, let them break it off.' So they gave it to me, and I cast it into the fire, and this calf came out."

25. Now when Moses saw that the people were unrestrained (for Aaron had not restrained them, to their shame among their enemies),

26. then Moses stood in the entrance of the camp, and said, "Whoever is on the LORD's side--come to me!" And all the sons of Levi gathered themselves together to him.

27. And he said to them, "Thus says the LORD God of Israel: "Let every man put his sword on his side, and go in and out from entrance to entrance throughout the camp, and let every man kill his brother, every man his companion, and every man his neighbor."'

28. So the sons of Levi did according to the word of Moses. And about three thousand men of the people fell that day.

29. Then Moses said, "Consecrate yourselves today to the LORD, that He may bestow on you a blessing this day, for every man has opposed his son and his brother."

30. Now it came to pass on the next day that Moses said to the people, "You have committed a great sin. So now I will go up to the LORD; perhaps I can make atonement for your sin."

31. Then Moses returned to the LORD and said, "Oh, these people have committed a great sin, and have made for themselves a god of gold!

32. Yet now, if You will forgive their sin--but if not, I pray, blot me out of Your book which You have written."

33. And the LORD said to Moses, "Whoever has sinned against Me, I will blot him out of My book.

34. Now therefore, go, lead the people to the place of which I have spoken to you. Behold, My Angel shall go before you. Nevertheless, in the day when I visit for punishment, I will visit punishment upon them for their sin."

35. So the LORD plagued the people because of what they did with the calf which Aaron made.

## Chapter 33

1. Then the LORD said to Moses, "Depart and go up from here, you and the people whom you have brought out of the land of Egypt, to the land of which I swore to Abraham, Isaac, and Jacob, saying, "To your descendants I will give it.'

2. And I will send My Angel before you, and I will drive out the Canaanite and the Amorite and the Hittite and the Perizzite and the Hivite and the Jebusite.

3. Go up to a land flowing with milk and honey; for I will not go up in your midst, lest I consume you on the way, for you are a stiff-necked people."

4. And when the people heard this bad news, they mourned, and no one put on his ornaments.

5. For the LORD had said to Moses, "Say to the children of Israel, "You are a stiff-necked people. I could come up into your midst in one moment and consume you. Now therefore, take off your ornaments, that I may know what to do to you."'

6. So the children of Israel stripped themselves of their ornaments by Mount Horeb.

7. Moses took his tent and pitched it outside the camp, far from the camp, and called it the tabernacle of meeting. And it came to pass that everyone who sought the LORD went out to the tabernacle of meeting which was outside the camp.

8. So it was, whenever Moses went out to the tabernacle, that all the people rose, and each man stood at his tent door and watched Moses until he had gone into the tabernacle.

9. And it came to pass, when Moses entered the tabernacle, that the pillar of cloud descended and stood at the door of the tabernacle, and the LORD talked with Moses.

10. All the people saw the pillar of cloud standing at the tabernacle door, and all the people rose and worshiped, each man in his tent door.

11. So the LORD spoke to Moses face to face, as a man speaks to his friend. And he would return to the camp, but his servant Joshua the son of Nun, a young man, did not depart from the tabernacle.

12. Then Moses said to the LORD, "See, You say to me, "Bring up this people.' But You have not let me know whom You will send with me. Yet You have said, "I know you by name, and you have also found grace in My sight.'

13. Now therefore, I pray, if I have found grace in Your sight, show me now Your way, that I may know You and that I may find grace in Your sight. And consider that this nation is Your people."

14. And He said, "My Presence will go with you, and I will give you rest."

15. Then he said to Him, "If Your Presence does not go with us, do not bring us up from here.

16. For how then will it be known that Your people and I have found grace in Your sight, except You go with us? So we shall be separate, Your people and I, from all the people who are upon the face of the earth."

17. So the LORD said to Moses, "I will also do this thing that you have spoken; for you have found grace in My sight, and I know you by name."

18. And he said, "Please, show me Your glory."

19. Then He said, "I will make all My goodness pass before you, and I will proclaim the name of the LORD before you. I will be gracious to whom I will be gracious, and I will have compassion on whom I will have compassion."

20. But He said, "You cannot see My face; for no man shall see Me, and live."

21. And the LORD said, "Here is a place by Me, and you shall stand on the rock.

22. So it shall be, while My glory passes by, that I will put you in the cleft of the rock, and will cover you with My hand while I pass by.

23. Then I will take away My hand, and you shall see My back; but My face shall not be seen."

## Chapter 34

1. And the LORD said to Moses, "Cut two tablets of stone like the first ones, and I will write on these tablets the words that were on the first tablets which you broke.

2. So be ready in the morning, and come up in the morning to Mount Sinai, and present yourself to Me there on the top of the mountain.

3. And no man shall come up with you, and let no man be seen throughout all the mountain; let neither flocks nor herds feed before that mountain."

4. So he cut two tablets of stone like the first ones. Then Moses rose early in the morning and went up Mount Sinai, as the LORD had commanded him; and he took in his hand the two tablets of stone.

5. Now the LORD descended in the cloud and stood with him there, and proclaimed the name of the LORD.

6. And the LORD passed before him and proclaimed, "The LORD, the LORD God, merciful and gracious, longsuffering, and abounding in goodness and truth,

7. keeping mercy for thousands, forgiving iniquity and transgression and sin, by no means clearing the guilty, visiting the iniquity of the fathers upon the children and the children's children to the third and the fourth generation."

8. So Moses made haste and bowed his head toward the earth, and worshiped.

9. Then he said, "If now I have found grace in Your sight, O Lord, let my Lord, I pray, go among us, even though we are a stiff-necked people; and pardon our iniquity and our sin, and take us as Your inheritance."

10. And He said: "Behold, I make a covenant. Before all your people I will do marvels such as have not been done in all the earth, nor in any nation; and all the people among whom you are shall see the work of the LORD. For it is an awesome thing that I will do with you.

11. Observe what I command you this day. Behold, I am driving out from before you the Amorite and the Canaanite and the Hittite and the Perizzite and the Hivite and the Jebusite.

12. Take heed to yourself, lest you make a covenant with the inhabitants of the land where you are going, lest it be a snare in your midst.

13. But you shall destroy their altars, break their sacred pillars, and cut down their wooden images

14. (for you shall worship no other god, for the LORD, whose name is Jealous, is a jealous God),

15. lest you make a covenant with the inhabitants of the land, and they play the harlot with their gods and make sacrifice to their gods, and one of them invites you and you eat of his sacrifice,

16. and you take of his daughters for your sons, and his daughters play the harlot with their gods and make your sons play the harlot with their gods.

17. "You shall make no molded gods for yourselves.

18. "The Feast of Unleavened Bread you shall keep. Seven days you shall eat unleavened bread, as I commanded you, in the appointed time of the month of Abib; for in the month of Abib you came out from Egypt.

19. "All that open the womb are Mine, and every male firstborn among your livestock, whether ox or sheep.

20. But the firstborn of a donkey you shall redeem with a lamb. And if you will not redeem him, then you shall break his neck. All the firstborn of your sons you shall redeem. "And none shall appear before Me empty-handed.

21. "Six days you shall work, but on the seventh day you shall rest; in plowing time and in harvest you shall rest.

22. "And you shall observe the Feast of Weeks, of the firstfruits of wheat harvest, and the Feast of Ingathering at the year's end.

23. "Three times in the year all your men shall appear before the Lord, the LORD God of Israel.

24. For I will cast out the nations before you and enlarge your borders; neither will any man covet your land when you go up to appear before the LORD your God three times in the year.

25. "You shall not offer the blood of My sacrifice with leaven, nor shall the sacrifice of the Feast of the Passover be left until morning.

26. "The first of the firstfruits of your land you shall bring to the house of the LORD your God. You shall not boil a young goat in its mother's milk."

27. Then the LORD said to Moses, "Write these words, for according to the tenor of these words I have made a covenant with you and with Israel."

28. So he was there with the LORD forty days and forty nights; he neither ate bread nor drank water. And He wrote on the tablets the words of the covenant, the Ten Commandments.

29. Now it was so, when Moses came down from Mount Sinai (and the two tablets of the Testimony were in Moses' hand when he came down from the mountain), that Moses did not know that the skin of his face shone while he talked with Him.

30. So when Aaron and all the children of Israel saw Moses, behold, the skin of his face shone, and they were afraid to come near him.

31. Then Moses called to them, and Aaron and all the rulers of the congregation returned to him; and Moses talked with them.

32. Afterward all the children of Israel came near, and he gave them as commandments all that the LORD had spoken with him on Mount Sinai.

33. And when Moses had finished speaking with them, he put a veil on his face.

34. But whenever Moses went in before the LORD to speak with Him, he would take the veil off until he came out; and he would come out and speak to the children of Israel whatever he had been commanded.

35. And whenever the children of Israel saw the face of Moses, that the skin of Moses' face shone, then Moses would put the veil on his face again, until he went in to speak with Him.

## Chapter 35

1. Then Moses gathered all the congregation of the children of Israel together, and said to them, "These are the words which the LORD has commanded you to do:

2. Work shall be done for six days, but the seventh day shall be a holy day for you, a Sabbath of rest to the LORD. Whoever does any work on it shall be put to death.

3. You shall kindle no fire throughout your dwellings on the Sabbath day."

4. And Moses spoke to all the congregation of the children of Israel, saying, "This is the thing which the LORD commanded, saying:

5. "Take from among you an offering to the LORD. Whoever is of a willing heart, let him bring it as an offering to the LORD: gold, silver, and bronze;

6. blue, purple, and scarlet thread, fine linen, and goats' hair;

7. ram skins dyed red, badger skins, and acacia wood;

8. oil for the light, and spices for the anointing oil and for the sweet incense;

9. onyx stones, and stones to be set in the ephod and in the breastplate.

10. "All who are gifted artisans among you shall come and make all that the LORD has commanded:

11. the tabernacle, its tent, its covering, its clasps, its boards, its bars, its pillars, and its sockets;

12. the ark and its poles, with the mercy seat, and the veil of the covering;

13. the table and its poles, all its utensils, and the showbread;

14. also the lampstand for the light, its utensils, its lamps, and the oil for the light;

15. the incense altar, its poles, the anointing oil, the sweet incense, and the screen for the door at the entrance of the tabernacle;

16. the altar of burnt offering with its bronze grating, its poles, all its utensils, and the laver and its base;

17. the hangings of the court, its pillars, their sockets, and the screen for the gate of the court;

18. the pegs of the tabernacle, the pegs of the court, and their cords;

19. the garments of ministry, for ministering in the holy place--the holy garments for Aaron the priest and the garments of his sons, to minister as priests."'

20. And all the congregation of the children of Israel departed from the presence of Moses.

21. Then everyone came whose heart was stirred, and everyone whose spirit was willing, and they brought the LORD's offering for the work of the tabernacle of meeting, for all its service, and for the holy garments.

22. They came, both men and women, as many as had a willing heart, and brought earrings and nose rings, rings and necklaces, all jewelry of gold, that is, every man who made an offering of gold to the LORD.

23. And every man, with whom was found blue, purple, and scarlet thread, fine linen, goats' hair, red skins of rams, and badger skins, brought them.

24. Everyone who offered an offering of silver or bronze brought the LORD's offering. And everyone with whom was found acacia wood for any work of the service, brought it.

25. All the women who were gifted artisans spun yarn with their hands, and brought what they had spun, of blue, purple, and scarlet, and fine linen.

26. And all the women whose hearts stirred with wisdom spun yarn of goats' hair.

27. The rulers brought onyx stones, and the stones to be set in the ephod and in the breastplate,

28. and spices and oil for the light, for the anointing oil, and for the sweet incense.

29. The children of Israel brought a freewill offering to the LORD, all the men and women whose hearts were willing to bring material for all kinds of work which the LORD, by the hand of Moses, had commanded to be done.

30. And Moses said to the children of Israel, "See, the LORD has called by name Bezalel the son of Uri, the son of Hur, of the tribe of Judah;

31. and He has filled him with the Spirit of God, in wisdom and understanding, in knowledge and all manner of workmanship,

32. to design artistic works, to work in gold and silver and bronze,

33. in cutting jewels for setting, in carving wood, and to work in all manner of artistic workmanship.

34. "And He has put in his heart the ability to teach, in him and Aholiab the son of Ahisamach, of the tribe of Dan.

35. He has filled them with skill to do all manner of work of the engraver and the designer and the tapestry maker, in blue, purple, and scarlet thread, and fine linen, and of the weaver--those who do every work and those who design artistic works.

## Chapter 36

1. "And Bezalel and Aholiab, and every gifted artisan in whom the LORD has put wisdom and understanding, to know how to do all manner of work for the service of the sanctuary, shall do according to all that the LORD has commanded."

2. Then Moses called Bezalel and Aholiab, and every gifted artisan in whose heart the LORD had put wisdom, everyone whose heart was stirred, to come and do the work.

3. And they received from Moses all the offering which the children of Israel had brought for the work of the service of making the sanctuary. So they continued bringing to him freewill offerings every morning.

4. Then all the craftsmen who were doing all the work of the sanctuary came, each from the work he was doing,

5. and they spoke to Moses, saying, "The people bring much more than enough for the service of the work which the LORD commanded us to do."

6. So Moses gave a commandment, and they caused it to be proclaimed throughout the camp, saying, "Let neither man nor woman do any more work for the offering of the sanctuary." And the people were restrained from bringing,

7. for the material they had was sufficient for all the work to be done--indeed too much.

8. Then all the gifted artisans among them who worked on the tabernacle made ten curtains woven of fine linen, and of blue, purple, and scarlet thread; with artistic designs of cherubim they made them.

9. The length of each curtain was twenty-eight cubits, and the width of each curtain four cubits; the curtains were all the same size.

10. And he coupled five curtains to one another, and the other five curtains he coupled to one another.

11. He made loops of blue yarn on the edge of the curtain on the selvedge of one set; likewise he did on the outer edge of the other curtain of the second set.

12. Fifty loops he made on one curtain, and fifty loops he made on the edge of the curtain on the end of the second set; the loops held one curtain to another.

13. And he made fifty clasps of gold, and coupled the curtains to one another with the clasps, that it might be one tabernacle.

14. He made curtains of goats' hair for the tent over the tabernacle; he made eleven curtains.

15. The length of each curtain was thirty cubits, and the width of each curtain four cubits; the eleven curtains were the same size.

16. He coupled five curtains by themselves and six curtains by themselves.

17. And he made fifty loops on the edge of the curtain that is outermost in one set, and fifty loops he made on the edge of the curtain of the second set.

18. He also made fifty bronze clasps to couple the tent together, that it might be one.

19. Then he made a covering for the tent of ram skins dyed red, and a covering of badger skins above that.

20. For the tabernacle he made boards of acacia wood, standing upright.

21. The length of each board was ten cubits, and the width of each board a cubit and a half.

22. Each board had two tenons for binding one to another. Thus he made for all the boards of the tabernacle.

23. And he made boards for the tabernacle, twenty boards for the south side.

24. Forty sockets of silver he made to go under the twenty boards: two sockets under each of the boards for its two tenons.

25. And for the other side of the tabernacle, the north side, he made twenty boards

26. and their forty sockets of silver: two sockets under each of the boards.

27. For the west side of the tabernacle he made six boards.

28. He also made two boards for the two back corners of the tabernacle.

29. And they were coupled at the bottom and coupled together at the top by one ring. Thus he made both of them for the two corners.

30. So there were eight boards and their sockets--sixteen sockets of silver--two sockets under each of the boards.

31. And he made bars of acacia wood: five for the boards on one side of the tabernacle,

32. five bars for the boards on the other side of the tabernacle, and five bars for the boards of the tabernacle on the far side westward.

33. And he made the middle bar to pass through the boards from one end to the other.

34. He overlaid the boards with gold, made their rings of gold to be holders for the bars, and overlaid the bars with gold.

35. And he made a veil of blue, purple, and scarlet thread, and fine woven linen; it was worked with an artistic design of cherubim.

36. He made for it four pillars of acacia wood, and overlaid them with gold, with their hooks of gold; and he cast four sockets of silver for them.

37. He also made a screen for the tabernacle door, of blue, purple, and scarlet thread, and fine woven linen, made by a weaver,

38. and its five pillars with their hooks. And he overlaid their capitals and their rings with gold, but their five sockets were bronze.

## Chapter 37

1. Then Bezalel made the ark of acacia wood; two and a half cubits was its length, a cubit and a half its width, and a cubit and a half its height.

2. He overlaid it with pure gold inside and outside, and made a molding of gold all around it.

3. And he cast for it four rings of gold to be set in its four corners: two rings on one side, and two rings on the other side of it.

4. He made poles of acacia wood, and overlaid them with gold.

5. And he put the poles into the rings at the sides of the ark, to bear the ark.

6. He also made the mercy seat of pure gold; two and a half cubits was its length and a cubit and a half its width.

7. He made two cherubim of beaten gold; he made them of one piece at the two ends of the mercy seat:

8. one cherub at one end on this side, and the other cherub at the other end on that side. He made the cherubim at the two ends of one piece with the mercy seat.

9. The cherubim spread out their wings above, and covered the mercy seat with their wings. They faced one another; the faces of the cherubim were toward the mercy seat.

10. He made the table of acacia wood; two cubits was its length, a cubit its width, and a cubit and a half its height.

11. And he overlaid it with pure gold, and made a molding of gold all around it.

12. Also he made a frame of a handbreadth all around it, and made a molding of gold for the frame all around it.

13. And he cast for it four rings of gold, and put the rings on the four corners that were at its four legs.

14. The rings were close to the frame, as holders for the poles to bear the table.

15. And he made the poles of acacia wood to bear the table, and overlaid them with gold.

16. He made of pure gold the utensils which were on the table: its dishes, its cups, its bowls, and its pitchers for pouring.

17. He also made the lampstand of pure gold; of hammered work he made the lampstand. Its shaft, its branches, its bowls, its ornamental knobs, and its flowers were of the same piece.

18. And six branches came out of its sides: three branches of the lampstand out of one side, and three branches of the lampstand out of the other side.

19. There were three bowls made like almond blossoms on one branch, with an ornamental knob and a flower, and three bowls made like almond blossoms on the other branch, with an ornamental knob and a flower--and so for the six branches coming out of the lampstand.

20. And on the lampstand itself were four bowls made like almond blossoms, each with its ornamental knob and flower.

21. There was a knob under the first two branches of the same, a knob under the second two branches of the same, and a knob under the third two branches of the same, according to the six branches extending from it.

22. Their knobs and their branches were of one piece; all of it was one hammered piece of pure gold.

23. And he made its seven lamps, its wick-trimmers, and its trays of pure gold.

24. Of a talent of pure gold he made it, with all its utensils.

25. He made the incense altar of acacia wood. Its length was a cubit and its width a cubit--it was square--and two cubits was its height. Its horns were of one piece with it.

26. And he overlaid it with pure gold: its top, its sides all around, and its horns. He also made for it a molding of gold all around it.

27. He made two rings of gold for it under its molding, by its two corners on both sides, as holders for the poles with which to bear it.

28. And he made the poles of acacia wood, and overlaid them with gold.

29. He also made the holy anointing oil and the pure incense of sweet spices, according to the work of the perfumer.

## Chapter 38

1. He made the altar of burnt offering of acacia wood; five cubits was its length and five cubits its width--it was square--and its height was three cubits.

2. He made its horns on its four corners; the horns were of one piece with it. And he overlaid it with bronze.

3. He made all the utensils for the altar: the pans, the shovels, the basins, the forks, and the firepans; all its utensils he made of bronze.

4. And he made a grate of bronze network for the altar, under its rim, midway from the bottom.

5. He cast four rings for the four corners of the bronze grating, as holders for the poles.

6. And he made the poles of acacia wood, and overlaid them with bronze.

7. Then he put the poles into the rings on the sides of the altar, with which to bear it. He made the altar hollow with boards.

8. He made the laver of bronze and its base of bronze, from the bronze mirrors of the serving women who assembled at the door of the tabernacle of meeting.

9. Then he made the court on the south side; the hangings of the court were of fine woven linen, one hundred cubits long.

10. There were twenty pillars for them, with twenty bronze sockets. The hooks of the pillars and their bands were silver.

11. On the north side the hangings were one hundred cubits long, with twenty pillars and their twenty bronze sockets. The hooks of the pillars and their bands were silver.

12. And on the west side there were hangings of fifty cubits, with ten pillars and their ten sockets. The hooks of the pillars and their bands were silver.

13. For the east side the hangings were fifty cubits.

14. The hangings of one side of the gate were fifteen cubits long, with their three pillars and their three sockets,

15. and the same for the other side of the court gate; on this side and that were hangings of fifteen cubits, with their three pillars and their three sockets.

16. All the hangings of the court all around were of fine woven linen.

17. The sockets for the pillars were bronze, the hooks of the pillars and their bands were silver, and the overlay of their capitals was silver; and all the pillars of the court had bands of silver.

18. The screen for the gate of the court was woven of blue, purple, and scarlet thread, and of fine woven linen. The length was twenty cubits, and the height along its width was five cubits, corresponding to the hangings of the court.

19. And there were four pillars with their four sockets of bronze; their hooks were silver, and the overlay of their capitals and their bands was silver.

20. All the pegs of the tabernacle, and of the court all around, were bronze.

21. This is the inventory of the tabernacle, the tabernacle of the Testimony, which was counted according to the commandment of Moses, for the service of the Levites, by the hand of Ithamar, son of Aaron the priest.

22. Bezalel the son of Uri, the son of Hur, of the tribe of Judah, made all that the LORD had commanded Moses.

23. And with him was Aholiab the son of Ahisamach, of the tribe of Dan, an engraver and designer, a weaver of blue, purple, and scarlet thread, and of fine linen.

24. All the gold that was used in all the work of the holy place, that is, the gold of the offering, was twenty-nine talents and seven hundred and thirty shekels, according to the shekel of the sanctuary.

25. And the silver from those who were numbered of the congregation was one hundred talents and one thousand seven hundred and seventy-five shekels, according to the shekel of the sanctuary:

26. a bekah for each man (that is, half a shekel, according to the shekel of the sanctuary), for everyone included in the numbering from twenty years old and above, for six hundred and three thousand, five hundred and fifty men.

27. And from the hundred talents of silver were cast the sockets of the sanctuary and the bases of the veil: one hundred sockets from the hundred talents, one talent for each socket.

28. Then from the one thousand seven hundred and seventy-five shekels he made hooks for the pillars, overlaid their capitals, and made bands for them.

29. The offering of bronze was seventy talents and two thousand four hundred shekels.

30. And with it he made the sockets for the door of the tabernacle of meeting, the bronze altar, the bronze grating for it, and all the utensils for the altar,

31. the sockets for the court all around, the bases for the court gate, all the pegs for the tabernacle, and all the pegs for the court all around.

## Chapter 39

1. Of the blue, purple, and scarlet thread they made garments of ministry, for ministering in the holy place, and made the holy garments for Aaron, as the LORD had commanded Moses.

2. He made the ephod of gold, blue, purple, and scarlet thread, and of fine woven linen.

3. And they beat the gold into thin sheets and cut it into threads, to work it in with the blue, purple, and scarlet thread, and the fine linen, into artistic designs.

4. They made shoulder straps for it to couple it together; it was coupled together at its two edges.

5. And the intricately woven band of his ephod that was on it was of the same workmanship, woven of gold, blue, purple, and scarlet thread, and of fine woven linen, as the LORD had commanded Moses.

6. And they set onyx stones, enclosed in settings of gold; they were engraved, as signets are engraved, with the names of the sons of Israel.

7. He put them on the shoulders of the ephod as memorial stones for the sons of Israel, as the LORD had commanded Moses.

8. And he made the breastplate, artistically woven like the workmanship of the ephod, of gold, blue, purple, and scarlet thread, and of fine woven linen.

9. They made the breastplate square by doubling it; a span was its length and a span its width when doubled.

10. And they set in it four rows of stones: a row with a sardius, a topaz, and an emerald was the first row;

11. the second row, a turquoise, a sapphire, and a diamond;

12. the third row, a jacinth, an agate, and an amethyst;

13. the fourth row, a beryl, an onyx, and a jasper. They were enclosed in settings of gold in their mountings.

14. There were twelve stones according to the names of the sons of Israel: according to their names, engraved like a signet, each one with its own name according to the twelve tribes.

15. And they made chains for the breastplate at the ends, like braided cords of pure gold.

16. They also made two settings of gold and two gold rings, and put the two rings on the two ends of the breastplate.

17. And they put the two braided chains of gold in the two rings on the ends of the breastplate.

18. The two ends of the two braided chains they fastened in the two settings, and put them on the shoulder straps of the ephod in the front.

19. And they made two rings of gold and put them on the two ends of the breastplate, on the edge of it, which was on the inward side of the ephod.

20. They made two other gold rings and put them on the two shoulder straps, underneath the ephod toward its front, right at the seam above the intricately woven band of the ephod.

21. And they bound the breastplate by means of its rings to the rings of the ephod with a blue cord, so that it would be above the intricately woven band of the ephod, and that the breastplate would not come loose from the ephod, as the LORD had commanded Moses.

22. He made the robe of the ephod of woven work, all of blue.

23. And there was an opening in the middle of the robe, like the opening in a coat of mail, with a woven binding all around the opening, so that it would not tear.

24. They made on the hem of the robe pomegranates of blue, purple, and scarlet, and of fine woven linen.

25. And they made bells of pure gold, and put the bells between the pomegranates on the hem of the robe all around between the pomegranates:

26. a bell and a pomegranate, a bell and a pomegranate, all around the hem of the robe to minister in, as the LORD had commanded Moses.

27. They made tunics, artistically woven of fine linen, for Aaron and his sons,

28. a turban of fine linen, exquisite hats of fine linen, short trousers of fine woven linen,

29. and a sash of fine woven linen with blue, purple, and scarlet thread, made by a weaver, as the LORD had commanded Moses.

30. Then they made the plate of the holy crown of pure gold, and wrote on it an inscription like the engraving of a signet: HOLINESS TO THE LORD.

31. And they tied to it a blue cord, to fasten it above on the turban, as the LORD had commanded Moses.

32. Thus all the work of the tabernacle of the tent of meeting was finished. And the children of Israel did according to all that the LORD had commanded Moses; so they did.

33. And they brought the tabernacle to Moses, the tent and all its furnishings: its clasps, its boards, its bars, its pillars, and its sockets;

34. the covering of ram skins dyed red, the covering of badger skins, and the veil of the covering;

35. the ark of the Testimony with its poles, and the mercy seat;

36. the table, all its utensils, and the showbread;

37. the pure gold lampstand with its lamps (the lamps set in order), all its utensils, and the oil for light;

38. the gold altar, the anointing oil, and the sweet incense; the screen for the tabernacle door;

39. the bronze altar, its grate of bronze, its poles, and all its utensils; the laver with its base;

40. the hangings of the court, its pillars and its sockets, the screen for the court gate, its cords, and its pegs; all the utensils for the service of the tabernacle, for the tent of meeting;

41. and the garments of ministry, to minister in the holy place: the holy garments for Aaron the priest, and his sons' garments, to minister as priests.

42. According to all that the LORD had commanded Moses, so the children of Israel did all the work.

43. Then Moses looked over all the work, and indeed they had done it; as the LORD had commanded, just so they had done it. And Moses blessed them.

## Chapter 40

1. Then the LORD spoke to Moses, saying:

2. "On the first day of the first month you shall set up the tabernacle of the tent of meeting.

3. You shall put in it the ark of the Testimony, and partition off the ark with the veil.

4. You shall bring in the table and arrange the things that are to be set in order on it; and you shall bring in the lampstand and light its lamps.

5. You shall also set the altar of gold for the incense before the ark of the Testimony, and put up the screen for the door of the tabernacle.

6. Then you shall set the altar of the burnt offering before the door of the tabernacle of the tent of meeting.

7. And you shall set the laver between the tabernacle of meeting and the altar, and put water in it.

8. You shall set up the court all around, and hang up the screen at the court gate.

9. "And you shall take the anointing oil, and anoint the tabernacle and all that is in it; and you shall hallow it and all its utensils, and it shall be holy.

10. You shall anoint the altar of the burnt offering and all its utensils, and consecrate the altar. The altar shall be most holy.

11. And you shall anoint the laver and its base, and consecrate it.

12. "Then you shall bring Aaron and his sons to the door of the tabernacle of meeting and wash them with water.

13. You shall put the holy garments on Aaron, and anoint him and consecrate him, that he may minister to Me as priest.

14. And you shall bring his sons and clothe them with tunics.

15. You shall anoint them, as you anointed their father, that they may minister to Me as priests; for their anointing shall surely be an everlasting priesthood throughout their generations."

16. Thus Moses did; according to all that the LORD had commanded him, so he did.

17. And it came to pass in the first month of the second year, on the first day of the month, that the tabernacle was raised up.

18. So Moses raised up the tabernacle, fastened its sockets, set up its boards, put in its bars, and raised up its pillars.

19. And he spread out the tent over the tabernacle and put the covering of the tent on top of it, as the LORD had commanded Moses.

20. He took the Testimony and put it into the ark, inserted the poles through the rings of the ark, and put the mercy seat on top of the ark.

21. And he brought the ark into the tabernacle, hung up the veil of the covering, and partitioned off the ark of the Testimony, as the LORD had commanded Moses.

22. He put the table in the tabernacle of meeting, on the north side of the tabernacle, outside the veil;

23. and he set the bread in order upon it before the LORD, as the LORD had commanded Moses.

24. He put the lampstand in the tabernacle of meeting, across from the table, on the south side of the tabernacle;

25. and he lit the lamps before the LORD, as the LORD had commanded Moses.

26. He put the gold altar in the tabernacle of meeting in front of the veil;

27. and he burned sweet incense on it, as the LORD had commanded Moses.

28. He hung up the screen at the door of the tabernacle.

29. And he put the altar of burnt offering before the door of the tabernacle of the tent of meeting, and offered upon it the burnt offering and the grain offering, as the LORD had commanded Moses.

30. He set the laver between the tabernacle of meeting and the altar, and put water there for washing;

31. and Moses, Aaron, and his sons would wash their hands and their feet with water from it.

32. Whenever they went into the tabernacle of meeting, and when they came near the altar, they washed, as the LORD had commanded Moses.

33. And he raised up the court all around the tabernacle and the altar, and hung up the screen of the court gate. So Moses finished the work.

34. Then the cloud covered the tabernacle of meeting, and the glory of the LORD filled the tabernacle.

35. And Moses was not able to enter the tabernacle of meeting, because the cloud rested above it, and the glory of the LORD filled the tabernacle.

36. Whenever the cloud was taken up from above the tabernacle, the children of Israel would go onward in all their journeys.

37. But if the cloud was not taken up, then they did not journey till the day that it was taken up.

38. For the cloud of the LORD was above the tabernacle by day, and fire was over it by night, in the sight of all the house of Israel, throughout all their journeys.


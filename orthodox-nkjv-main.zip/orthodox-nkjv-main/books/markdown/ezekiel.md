# ezekiel

## Chapter 1

1. Now it came to pass in the thirtieth year, in the fourth month, on the fifth day of the month, as I was among the captives by the River Chebar, that the heavens were opened and I saw visions of God.

2. On the fifth day of the month, which was in the fifth year of King Jehoiachin's captivity,

3. the word of the LORD came expressly to Ezekiel the priest, the son of Buzi, in the land of the Chaldeans by the River Chebar; and the hand of the LORD was upon him there.

4. Then I looked, and behold, a whirlwind was coming out of the north, a great cloud with raging fire engulfing itself; and brightness was all around it and radiating out of its midst like the color of amber, out of the midst of the fire.

5. Also from within it came the likeness of four living creatures. And this was their appearance: they had the likeness of a man.

6. Each one had four faces, and each one had four wings.

7. Their legs were straight, and the soles of their feet were like the soles of calves' feet. They sparkled like the color of burnished bronze.

8. The hands of a man were under their wings on their four sides; and each of the four had faces and wings.

9. Their wings touched one another. The creatures did not turn when they went, but each one went straight forward.

10. As for the likeness of their faces, each had the face of a man; each of the four had the face of a lion on the right side, each of the four had the face of an ox on the left side, and each of the four had the face of an eagle.

11. Thus were their faces. Their wings stretched upward; two wings of each one touched one another, and two covered their bodies.

12. And each one went straight forward; they went wherever the spirit wanted to go, and they did not turn when they went.

13. As for the likeness of the living creatures, their appearance was like burning coals of fire, like the appearance of torches going back and forth among the living creatures. The fire was bright, and out of the fire went lightning.

14. And the living creatures ran back and forth, in appearance like a flash of lightning.

15. Now as I looked at the living creatures, behold, a wheel was on the earth beside each living creature with its four faces.

16. The appearance of the wheels and their workings was like the color of beryl, and all four had the same likeness. The appearance of their workings was, as it were, a wheel in the middle of a wheel.

17. When they moved, they went toward any one of four directions; they did not turn aside when they went.

18. As for their rims, they were so high they were awesome; and their rims were full of eyes, all around the four of them.

19. When the living creatures went, the wheels went beside them; and when the living creatures were lifted up from the earth, the wheels were lifted up.

20. Wherever the spirit wanted to go, they went, because there the spirit went; and the wheels were lifted together with them, for the spirit of the living creatures was in the wheels.

21. When those went, these went; when those stood, these stood; and when those were lifted up from the earth, the wheels were lifted up together with them, for the spirit of the living creatures was in the wheels.

22. The likeness of the firmament above the heads of the living creatures was like the color of an awesome crystal, stretched out over their heads.

23. And under the firmament their wings spread out straight, one toward another. Each one had two which covered one side, and each one had two which covered the other side of the body.

24. When they went, I heard the noise of their wings, like the noise of many waters, like the voice of the Almighty, a tumult like the noise of an army; and when they stood still, they let down their wings.

25. A voice came from above the firmament that was over their heads; whenever they stood, they let down their wings.

26. And above the firmament over their heads was the likeness of a throne, in appearance like a sapphire stone; on the likeness of the throne was a likeness with the appearance of a man high above it.

27. Also from the appearance of His waist and upward I saw, as it were, the color of amber with the appearance of fire all around within it; and from the appearance of His waist and downward I saw, as it were, the appearance of fire with brightness all around.

28. Like the appearance of a rainbow in a cloud on a rainy day, so was the appearance of the brightness all around it. This was the appearance of the likeness of the glory of the LORD. So when I saw it, I fell on my face, and I heard a voice of One speaking.

## Chapter 2

1. And He said to me, "Son of man, stand on your feet, and I will speak to you."

2. Then the Spirit entered me when He spoke to me, and set me on my feet; and I heard Him who spoke to me.

3. And He said to me: "Son of man, I am sending you to the children of Israel, to a rebellious nation that has rebelled against Me; they and their fathers have transgressed against Me to this very day.

4. For they are impudent and stubborn children. I am sending you to them, and you shall say to them, "Thus says the Lord GOD.'

5. As for them, whether they hear or whether they refuse--for they are a rebellious house--yet they will know that a prophet has been among them.

6. "And you, son of man, do not be afraid of them nor be afraid of their words, though briers and thorns are with you and you dwell among scorpions; do not be afraid of their words or dismayed by their looks, though they are a rebellious house.

7. You shall speak My words to them, whether they hear or whether they refuse, for they are rebellious.

8. But you, son of man, hear what I say to you. Do not be rebellious like that rebellious house; open your mouth and eat what I give you."

9. Now when I looked, there was a hand stretched out to me; and behold, a scroll of a book was in it.

10. Then He spread it before me; and there was writing on the inside and on the outside, and written on it were lamentations and mourning and woe.

## Chapter 3

1. Moreover He said to me, "Son of man, eat what you find; eat this scroll, and go, speak to the house of Israel."

2. So I opened my mouth, and He caused me to eat that scroll.

3. And He said to me, "Son of man, feed your belly, and fill your stomach with this scroll that I give you." So I ate, and it was in my mouth like honey in sweetness.

4. Then He said to me: "Son of man, go to the house of Israel and speak with My words to them.

5. For you are not sent to a people of unfamiliar speech and of hard language, but to the house of Israel,

6. not to many people of unfamiliar speech and of hard language, whose words you cannot understand. Surely, had I sent you to them, they would have listened to you.

7. But the house of Israel will not listen to you, because they will not listen to Me; for all the house of Israel are impudent and hard-hearted.

8. Behold, I have made your face strong against their faces, and your forehead strong against their foreheads.

9. Like adamant stone, harder than flint, I have made your forehead; do not be afraid of them, nor be dismayed at their looks, though they are a rebellious house."

10. Moreover He said to me: "Son of man, receive into your heart all My words that I speak to you, and hear with your ears.

11. And go, get to the captives, to the children of your people, and speak to them and tell them, "Thus says the Lord GOD,' whether they hear, or whether they refuse."

12. Then the Spirit lifted me up, and I heard behind me a great thunderous voice: "Blessed is the glory of the LORD from His place!"

13. I also heard the noise of the wings of the living creatures that touched one another, and the noise of the wheels beside them, and a great thunderous noise.

14. So the Spirit lifted me up and took me away, and I went in bitterness, in the heat of my spirit; but the hand of the LORD was strong upon me.

15. Then I came to the captives at Tel Abib, who dwelt by the River Chebar; and I sat where they sat, and remained there astonished among them seven days.

16. Now it came to pass at the end of seven days that the word of the LORD came to me, saying,

17. "Son of man, I have made you a watchman for the house of Israel; therefore hear a word from My mouth, and give them warning from Me:

18. When I say to the wicked, "You shall surely die,' and you give him no warning, nor speak to warn the wicked from his wicked way, to save his life, that same wicked man shall die in his iniquity; but his blood I will require at your hand.

19. Yet, if you warn the wicked, and he does not turn from his wickedness, nor from his wicked way, he shall die in his iniquity; but you have delivered your soul.

20. "Again, when a righteous man turns from his righteousness and commits iniquity, and I lay a stumbling block before him, he shall die; because you did not give him warning, he shall die in his sin, and his righteousness which he has done shall not be remembered; but his blood I will require at your hand.

21. Nevertheless if you warn the righteous man that the righteous should not sin, and he does not sin, he shall surely live because he took warning; also you will have delivered your soul."

22. Then the hand of the LORD was upon me there, and He said to me, "Arise, go out into the plain, and there I shall talk with you."

23. So I arose and went out into the plain, and behold, the glory of the LORD stood there, like the glory which I saw by the River Chebar; and I fell on my face.

24. Then the Spirit entered me and set me on my feet, and spoke with me and said to me: "Go, shut yourself inside your house.

25. And you, O son of man, surely they will put ropes on you and bind you with them, so that you cannot go out among them.

26. I will make your tongue cling to the roof of your mouth, so that you shall be mute and not be one to rebuke them, for they are a rebellious house.

27. But when I speak with you, I will open your mouth, and you shall say to them, "Thus says the Lord GOD.' He who hears, let him hear; and he who refuses, let him refuse; for they are a rebellious house.

## Chapter 4

1. "You also, son of man, take a clay tablet and lay it before you, and portray on it a city, Jerusalem.

2. Lay siege against it, build a siege wall against it, and heap up a mound against it; set camps against it also, and place battering rams against it all around.

3. Moreover take for yourself an iron plate, and set it as an iron wall between you and the city. Set your face against it, and it shall be besieged, and you shall lay siege against it. This will be a sign to the house of Israel.

4. "Lie also on your left side, and lay the iniquity of the house of Israel upon it. According to the number of the days that you lie on it, you shall bear their iniquity.

5. For I have laid on you the years of their iniquity, according to the number of the days, three hundred and ninety days; so you shall bear the iniquity of the house of Israel.

6. And when you have completed them, lie again on your right side; then you shall bear the iniquity of the house of Judah forty days. I have laid on you a day for each year.

7. "Therefore you shall set your face toward the siege of Jerusalem; your arm shall be uncovered, and you shall prophesy against it.

8. And surely I will restrain you so that you cannot turn from one side to another till you have ended the days of your siege.

9. "Also take for yourself wheat, barley, beans, lentils, millet, and spelt; put them into one vessel, and make bread of them for yourself. During the number of days that you lie on your side, three hundred and ninety days, you shall eat it.

10. And your food which you eat shall be by weight, twenty shekels a day; from time to time you shall eat it.

11. You shall also drink water by measure, one-sixth of a hin; from time to time you shall drink.

12. And you shall eat it as barley cakes; and bake it using fuel of human waste in their sight."

13. Then the LORD said, "So shall the children of Israel eat their defiled bread among the Gentiles, where I will drive them."

14. So I said, "Ah, Lord GOD! Indeed I have never defiled myself from my youth till now; I have never eaten what died of itself or was torn by beasts, nor has abominable flesh ever come into my mouth."

15. Then He said to me, "See, I am giving you cow dung instead of human waste, and you shall prepare your bread over it."

16. Moreover He said to me, "Son of man, surely I will cut off the supply of bread in Jerusalem; they shall eat bread by weight and with anxiety, and shall drink water by measure and with dread,

17. that they may lack bread and water, and be dismayed with one another, and waste away because of their iniquity.

## Chapter 5

1. "And you, son of man, take a sharp sword, take it as a barber's razor, and pass it over your head and your beard; then take scales to weigh and divide the hair.

2. You shall burn with fire one-third in the midst of the city, when the days of the siege are finished; then you shall take one-third and strike around it with the sword, and one-third you shall scatter in the wind: I will draw out a sword after them.

3. You shall also take a small number of them and bind them in the edge of your garment.

4. Then take some of them again and throw them into the midst of the fire, and burn them in the fire. From there a fire will go out into all the house of Israel.

5. "Thus says the Lord GOD: "This is Jerusalem; I have set her in the midst of the nations and the countries all around her.

6. She has rebelled against My judgments by doing wickedness more than the nations, and against My statutes more than the countries that are all around her; for they have refused My judgments, and they have not walked in My statutes.'

7. Therefore thus says the Lord GOD: "Because you have multiplied disobedience more than the nations that are all around you, have not walked in My statutes nor kept My judgments, nor even done according to the judgments of the nations that are all around you'--

8. therefore thus says the Lord GOD: "Indeed I, even I, am against you and will execute judgments in your midst in the sight of the nations.

9. And I will do among you what I have never done, and the like of which I will never do again, because of all your abominations.

10. Therefore fathers shall eat their sons in your midst, and sons shall eat their fathers; and I will execute judgments among you, and all of you who remain I will scatter to all the winds.

11. "Therefore, as I live,' says the Lord GOD, "surely, because you have defiled My sanctuary with all your detestable things and with all your abominations, therefore I will also diminish you; My eye will not spare, nor will I have any pity.

12. One-third of you shall die of the pestilence, and be consumed with famine in your midst; and one-third shall fall by the sword all around you; and I will scatter another third to all the winds, and I will draw out a sword after them.

13. "Thus shall My anger be spent, and I will cause My fury to rest upon them, and I will be avenged; and they shall know that I, the LORD, have spoken it in My zeal, when I have spent My fury upon them.

14. Moreover I will make you a waste and a reproach among the nations that are all around you, in the sight of all who pass by.

15. "So it shall be a reproach, a taunt, a lesson, and an astonishment to the nations that are all around you, when I execute judgments among you in anger and in fury and in furious rebukes. I, the LORD, have spoken.

16. When I send against them the terrible arrows of famine which shall be for destruction, which I will send to destroy you, I will increase the famine upon you and cut off your supply of bread.

17. So I will send against you famine and wild beasts, and they will bereave you. Pestilence and blood shall pass through you, and I will bring the sword against you. I, the LORD, have spoken."'

## Chapter 6

1. Now the word of the LORD came to me, saying:

2. "Son of man, set your face toward the mountains of Israel, and prophesy against them,

3. and say, "O mountains of Israel, hear the word of the Lord GOD! Thus says the Lord GOD to the mountains, to the hills, to the ravines, and to the valleys: "Indeed I, even I, will bring a sword against you, and I will destroy your high places.

4. Then your altars shall be desolate, your incense altars shall be broken, and I will cast down your slain men before your idols.

5. And I will lay the corpses of the children of Israel before their idols, and I will scatter your bones all around your altars.

6. In all your dwelling places the cities shall be laid waste, and the high places shall be desolate, so that your altars may be laid waste and made desolate, your idols may be broken and made to cease, your incense altars may be cut down, and your works may be abolished.

7. The slain shall fall in your midst, and you shall know that I am the LORD.

8. "Yet I will leave a remnant, so that you may have some who escape the sword among the nations, when you are scattered through the countries.

9. Then those of you who escape will remember Me among the nations where they are carried captive, because I was crushed by their adulterous heart which has departed from Me, and by their eyes which play the harlot after their idols; they will loathe themselves for the evils which they committed in all their abominations.

10. And they shall know that I am the LORD; I have not said in vain that I would bring this calamity upon them."

11. "Thus says the Lord GOD: "Pound your fists and stamp your feet, and say, "Alas, for all the evil abominations of the house of Israel! For they shall fall by the sword, by famine, and by pestilence.

12. He who is far off shall die by the pestilence, he who is near shall fall by the sword, and he who remains and is besieged shall die by the famine. Thus will I spend My fury upon them.

13. Then you shall know that I am the LORD, when their slain are among their idols all around their altars, on every high hill, on all the mountaintops, under every green tree, and under every thick oak, wherever they offered sweet incense to all their idols.

14. So I will stretch out My hand against them and make the land desolate, yes, more desolate than the wilderness toward Diblah, in all their dwelling places. Then they shall know that I am the LORD."""

## Chapter 7

1. Moreover the word of the LORD came to me, saying,

2. "And you, son of man, thus says the Lord GOD to the land of Israel: "An end! The end has come upon the four corners of the land.

3. Now the end has come upon you, And I will send My anger against you; I will judge you according to your ways, And I will repay you for all your abominations.

4. My eye will not spare you, Nor will I have pity; But I will repay your ways, And your abominations will be in your midst; Then you shall know that I am the LORD!'

5. "Thus says the Lord GOD: "A disaster, a singular disaster; Behold, it has come!

6. An end has come, The end has come; It has dawned for you; Behold, it has come!

7. Doom has come to you, you who dwell in the land; The time has come, A day of trouble is near, And not of rejoicing in the mountains.

8. Now upon you I will soon pour out My fury, And spend My anger upon you; I will judge you according to your ways, And I will repay you for all your abominations.

9. "My eye will not spare, Nor will I have pity; I will repay you according to your ways, And your abominations will be in your midst. Then you shall know that I am the LORD who strikes.

10. "Behold, the day! Behold, it has come! Doom has gone out; The rod has blossomed, Pride has budded.

11. Violence has risen up into a rod of wickedness; None of them shall remain, None of their multitude, None of them; Nor shall there be wailing for them.

12. The time has come, The day draws near. "Let not the buyer rejoice, Nor the seller mourn, For wrath is on their whole multitude.

13. For the seller shall not return to what has been sold, Though he may still be alive; For the vision concerns the whole multitude, And it shall not turn back; No one will strengthen himself Who lives in iniquity.

14. "They have blown the trumpet and made everyone ready, But no one goes to battle; For My wrath is on all their multitude.

15. The sword is outside, And the pestilence and famine within. Whoever is in the field Will die by the sword; And whoever is in the city, Famine and pestilence will devour him.

16. "Those who survive will escape and be on the mountains Like doves of the valleys, All of them mourning, Each for his iniquity.

17. Every hand will be feeble, And every knee will be as weak as water.

18. They will also be girded with sackcloth; Horror will cover them; Shame will be on every face, Baldness on all their heads.

19. "They will throw their silver into the streets, And their gold will be like refuse; Their silver and their gold will not be able to deliver them In the day of the wrath of the LORD; They will not satisfy their souls, Nor fill their stomachs, Because it became their stumbling block of iniquity.

20. "As for the beauty of his ornaments, He set it in majesty; But they made from it The images of their abominations-- Their detestable things; Therefore I have made it Like refuse to them.

21. I will give it as plunder Into the hands of strangers, And to the wicked of the earth as spoil; And they shall defile it.

22. I will turn My face from them, And they will defile My secret place; For robbers shall enter it and defile it.

23. "Make a chain, For the land is filled with crimes of blood, And the city is full of violence.

24. Therefore I will bring the worst of the Gentiles, And they will possess their houses; I will cause the pomp of the strong to cease, And their holy places shall be defiled.

25. Destruction comes; They will seek peace, but there shall be none.

26. Disaster will come upon disaster, And rumor will be upon rumor. Then they will seek a vision from a prophet; But the law will perish from the priest, And counsel from the elders.

27. "The king will mourn, The prince will be clothed with desolation, And the hands of the common people will tremble. I will do to them according to their way, And according to what they deserve I will judge them; Then they shall know that I am the LORD!"'

## Chapter 8

1. And it came to pass in the sixth year, in the sixth month, on the fifth day of the month, as I sat in my house with the elders of Judah sitting before me, that the hand of the Lord GOD fell upon me there.

2. Then I looked, and there was a likeness, like the appearance of fire--from the appearance of His waist and downward, fire; and from His waist and upward, like the appearance of brightness, like the color of amber.

3. He stretched out the form of a hand, and took me by a lock of my hair; and the Spirit lifted me up between earth and heaven, and brought me in visions of God to Jerusalem, to the door of the north gate of the inner court, where the seat of the image of jealousy was, which provokes to jealousy.

4. And behold, the glory of the God of Israel was there, like the vision that I saw in the plain.

5. Then He said to me, "Son of man, lift your eyes now toward the north." So I lifted my eyes toward the north, and there, north of the altar gate, was this image of jealousy in the entrance.

6. Furthermore He said to me, "Son of man, do you see what they are doing, the great abominations that the house of Israel commits here, to make Me go far away from My sanctuary? Now turn again, you will see greater abominations."

7. So He brought me to the door of the court; and when I looked, there was a hole in the wall.

8. Then He said to me, "Son of man, dig into the wall"; and when I dug into the wall, there was a door.

9. And He said to me, "Go in, and see the wicked abominations which they are doing there."

10. So I went in and saw, and there--every sort of creeping thing, abominable beasts, and all the idols of the house of Israel, portrayed all around on the walls.

11. And there stood before them seventy men of the elders of the house of Israel, and in their midst stood Jaazaniah the son of Shaphan. Each man had a censer in his hand, and a thick cloud of incense went up.

12. Then He said to me, "Son of man, have you seen what the elders of the house of Israel do in the dark, every man in the room of his idols? For they say, "The LORD does not see us, the LORD has forsaken the land."'

13. And He said to me, "Turn again, and you will see greater abominations that they are doing."

14. So He brought me to the door of the north gate of the LORD's house; and to my dismay, women were sitting there weeping for Tammuz.

15. Then He said to me, "Have you seen this, O son of man? Turn again, you will see greater abominations than these."

16. So He brought me into the inner court of the LORD's house; and there, at the door of the temple of the LORD, between the porch and the altar, were about twenty-five men with their backs toward the temple of the LORD and their faces toward the east, and they were worshiping the sun toward the east.

17. And He said to me, "Have you seen this, O son of man? Is it a trivial thing to the house of Judah to commit the abominations which they commit here? For they have filled the land with violence; then they have returned to provoke Me to anger. Indeed they put the branch to their nose.

18. Therefore I also will act in fury. My eye will not spare nor will I have pity; and though they cry in My ears with a loud voice, I will not hear them."

## Chapter 9

1. Then He called out in my hearing with a loud voice, saying, "Let those who have charge over the city draw near, each with a deadly weapon in his hand."

2. And suddenly six men came from the direction of the upper gate, which faces north, each with his battle-ax in his hand. One man among them was clothed with linen and had a writer's inkhorn at his side. They went in and stood beside the bronze altar.

3. Now the glory of the God of Israel had gone up from the cherub, where it had been, to the threshold of the temple. And He called to the man clothed with linen, who had the writer's inkhorn at his side;

4. and the LORD said to him, "Go through the midst of the city, through the midst of Jerusalem, and put a mark on the foreheads of the men who sigh and cry over all the abominations that are done within it."

5. To the others He said in my hearing, "Go after him through the city and kill; do not let your eye spare, nor have any pity.

6. Utterly slay old and young men, maidens and little children and women; but do not come near anyone on whom is the mark; and begin at My sanctuary." So they began with the elders who were before the temple.

7. Then He said to them, "Defile the temple, and fill the courts with the slain. Go out!" And they went out and killed in the city.

8. So it was, that while they were killing them, I was left alone; and I fell on my face and cried out, and said, "Ah, Lord GOD! Will You destroy all the remnant of Israel in pouring out Your fury on Jerusalem?"

9. Then He said to me, "The iniquity of the house of Israel and Judah is exceedingly great, and the land is full of bloodshed, and the city full of perversity; for they say, "The LORD has forsaken the land, and the LORD does not see!'

10. And as for Me also, My eye will neither spare, nor will I have pity, but I will recompense their deeds on their own head."

11. Just then, the man clothed with linen, who had the inkhorn at his side, reported back and said, "I have done as You commanded me."

## Chapter 10

1. And I looked, and there in the firmament that was above the head of the cherubim, there appeared something like a sapphire stone, having the appearance of the likeness of a throne.

2. Then He spoke to the man clothed with linen, and said, "Go in among the wheels, under the cherub, fill your hands with coals of fire from among the cherubim, and scatter them over the city." And he went in as I watched.

3. Now the cherubim were standing on the south side of the temple when the man went in, and the cloud filled the inner court.

4. Then the glory of the LORD went up from the cherub, and paused over the threshold of the temple; and the house was filled with the cloud, and the court was full of the brightness of the LORD's glory.

5. And the sound of the wings of the cherubim was heard even in the outer court, like the voice of Almighty God when He speaks.

6. Then it happened, when He commanded the man clothed in linen, saying, "Take fire from among the wheels, from among the cherubim," that he went in and stood beside the wheels.

7. And the cherub stretched out his hand from among the cherubim to the fire that was among the cherubim, and took some of it and put it into the hands of the man clothed with linen, who took it and went out.

8. The cherubim appeared to have the form of a man's hand under their wings.

9. And when I looked, there were four wheels by the cherubim, one wheel by one cherub and another wheel by each other cherub; the wheels appeared to have the color of a beryl stone.

10. As for their appearance, all four looked alike--as it were, a wheel in the middle of a wheel.

11. When they went, they went toward any of their four directions; they did not turn aside when they went, but followed in the direction the head was facing. They did not turn aside when they went.

12. And their whole body, with their back, their hands, their wings, and the wheels that the four had, were full of eyes all around.

13. As for the wheels, they were called in my hearing, "Wheel."

14. Each one had four faces: the first face was the face of a cherub, the second face the face of a man, the third the face of a lion, and the fourth the face of an eagle.

15. And the cherubim were lifted up. This was the living creature I saw by the River Chebar.

16. When the cherubim went, the wheels went beside them; and when the cherubim lifted their wings to mount up from the earth, the same wheels also did not turn from beside them.

17. When the cherubim stood still, the wheels stood still, and when one was lifted up, the other lifted itself up, for the spirit of the living creature was in them.

18. Then the glory of the LORD departed from the threshold of the temple and stood over the cherubim.

19. And the cherubim lifted their wings and mounted up from the earth in my sight. When they went out, the wheels were beside them; and they stood at the door of the east gate of the LORD's house, and the glory of the God of Israel was above them.

20. This is the living creature I saw under the God of Israel by the River Chebar, and I knew they were cherubim.

21. Each one had four faces and each one four wings, and the likeness of the hands of a man was under their wings.

22. And the likeness of their faces was the same as the faces which I had seen by the River Chebar, their appearance and their persons. They each went straight forward.

## Chapter 11

1. Then the Spirit lifted me up and brought me to the East Gate of the LORD's house, which faces eastward; and there at the door of the gate were twenty-five men, among whom I saw Jaazaniah the son of Azzur, and Pelatiah the son of Benaiah, princes of the people.

2. And He said to me: "Son of man, these are the men who devise iniquity and give wicked counsel in this city,

3. who say, "The time is not near to build houses; this city is the caldron, and we are the meat.'

4. Therefore prophesy against them, prophesy, O son of man!"

5. Then the Spirit of the LORD fell upon me, and said to me, "Speak! "Thus says the LORD: "Thus you have said, O house of Israel; for I know the things that come into your mind.

6. You have multiplied your slain in this city, and you have filled its streets with the slain."

7. Therefore thus says the Lord GOD: "Your slain whom you have laid in its midst, they are the meat, and this city is the caldron; but I shall bring you out of the midst of it.

8. You have feared the sword; and I will bring a sword upon you," says the Lord GOD.

9. "And I will bring you out of its midst, and deliver you into the hands of strangers, and execute judgments on you.

10. You shall fall by the sword. I will judge you at the border of Israel. Then you shall know that I am the LORD.

11. This city shall not be your caldron, nor shall you be the meat in its midst. I will judge you at the border of Israel.

12. And you shall know that I am the LORD; for you have not walked in My statutes nor executed My judgments, but have done according to the customs of the Gentiles which are all around you.""'

13. Now it happened, while I was prophesying, that Pelatiah the son of Benaiah died. Then I fell on my face and cried with a loud voice, and said, "Ah, Lord GOD! Will You make a complete end of the remnant of Israel?"

14. Again the word of the LORD came to me, saying,

15. "Son of man, your brethren, your relatives, your countrymen, and all the house of Israel in its entirety, are those about whom the inhabitants of Jerusalem have said, "Get far away from the LORD; this land has been given to us as a possession.'

16. Therefore say, "Thus says the Lord GOD: "Although I have cast them far off among the Gentiles, and although I have scattered them among the countries, yet I shall be a little sanctuary for them in the countries where they have gone."'

17. Therefore say, "Thus says the Lord GOD: "I will gather you from the peoples, assemble you from the countries where you have been scattered, and I will give you the land of Israel."'

18. And they will go there, and they will take away all its detestable things and all its abominations from there.

19. Then I will give them one heart, and I will put a new spirit within them, and take the stony heart out of their flesh, and give them a heart of flesh,

20. that they may walk in My statutes and keep My judgments and do them; and they shall be My people, and I will be their God.

21. But as for those whose hearts follow the desire for their detestable things and their abominations, I will recompense their deeds on their own heads," says the Lord GOD.

22. So the cherubim lifted up their wings, with the wheels beside them, and the glory of the God of Israel was high above them.

23. And the glory of the LORD went up from the midst of the city and stood on the mountain, which is on the east side of the city.

24. Then the Spirit took me up and brought me in a vision by the Spirit of God into Chaldea, to those in captivity. And the vision that I had seen went up from me.

25. So I spoke to those in captivity of all the things the LORD had shown me.

## Chapter 12

1. Now the word of the LORD came to me, saying:

2. "Son of man, you dwell in the midst of a rebellious house, which has eyes to see but does not see, and ears to hear but does not hear; for they are a rebellious house.

3. "Therefore, son of man, prepare your belongings for captivity, and go into captivity by day in their sight. You shall go from your place into captivity to another place in their sight. It may be that they will consider, though they are a rebellious house.

4. By day you shall bring out your belongings in their sight, as though going into captivity; and at evening you shall go in their sight, like those who go into captivity.

5. Dig through the wall in their sight, and carry your belongings out through it.

6. In their sight you shall bear them on your shoulders and carry them out at twilight; you shall cover your face, so that you cannot see the ground, for I have made you a sign to the house of Israel."

7. So I did as I was commanded. I brought out my belongings by day, as though going into captivity, and at evening I dug through the wall with my hand. I brought them out at twilight, and I bore them on my shoulder in their sight.

8. And in the morning the word of the LORD came to me, saying,

9. "Son of man, has not the house of Israel, the rebellious house, said to you, "What are you doing?'

10. Say to them, "Thus says the Lord GOD: "This burden concerns the prince in Jerusalem and all the house of Israel who are among them."'

11. Say, "I am a sign to you. As I have done, so shall it be done to them; they shall be carried away into captivity.'

12. And the prince who is among them shall bear his belongings on his shoulder at twilight and go out. They shall dig through the wall to carry them out through it. He shall cover his face, so that he cannot see the ground with his eyes.

13. I will also spread My net over him, and he shall be caught in My snare. I will bring him to Babylon, to the land of the Chaldeans; yet he shall not see it, though he shall die there.

14. I will scatter to every wind all who are around him to help him, and all his troops; and I will draw out the sword after them.

15. "Then they shall know that I am the LORD, when I scatter them among the nations and disperse them throughout the countries.

16. But I will spare a few of their men from the sword, from famine, and from pestilence, that they may declare all their abominations among the Gentiles wherever they go. Then they shall know that I am the LORD."

17. Moreover the word of the LORD came to me, saying,

18. "Son of man, eat your bread with quaking, and drink your water with trembling and anxiety.

19. And say to the people of the land, "Thus says the Lord GOD to the inhabitants of Jerusalem and to the land of Israel: "They shall eat their bread with anxiety, and drink their water with dread, so that her land may be emptied of all who are in it, because of the violence of all those who dwell in it.

20. Then the cities that are inhabited shall be laid waste, and the land shall become desolate; and you shall know that I am the LORD.""'

21. And the word of the LORD came to me, saying,

22. "Son of man, what is this proverb that you people have about the land of Israel, which says, "The days are prolonged, and every vision fails'?

23. Tell them therefore, "Thus says the Lord GOD: "I will lay this proverb to rest, and they shall no more use it as a proverb in Israel." But say to them, "The days are at hand, and the fulfillment of every vision.

24. For no more shall there be any false vision or flattering divination within the house of Israel.

25. For I am the LORD. I speak, and the word which I speak will come to pass; it will no more be postponed; for in your days, O rebellious house, I will say the word and perform it," says the Lord GOD."'

26. Again the word of the LORD came to me, saying,

27. "Son of man, look, the house of Israel is saying, "The vision that he sees is for many days from now, and he prophesies of times far off.'

28. Therefore say to them, "Thus says the Lord GOD: "None of My words will be postponed any more, but the word which I speak will be done," says the Lord GOD."'

## Chapter 13

1. And the word of the LORD came to me, saying,

2. "Son of man, prophesy against the prophets of Israel who prophesy, and say to those who prophesy out of their own heart, "Hear the word of the LORD!"'

3. Thus says the Lord GOD: "Woe to the foolish prophets, who follow their own spirit and have seen nothing!

4. O Israel, your prophets are like foxes in the deserts.

5. You have not gone up into the gaps to build a wall for the house of Israel to stand in battle on the day of the LORD.

6. They have envisioned futility and false divination, saying, "Thus says the LORD!' But the LORD has not sent them; yet they hope that the word may be confirmed.

7. Have you not seen a futile vision, and have you not spoken false divination? You say, "The LORD says,' but I have not spoken."

8. Therefore thus says the Lord GOD: "Because you have spoken nonsense and envisioned lies, therefore I am indeed against you," says the Lord GOD.

9. "My hand will be against the prophets who envision futility and who divine lies; they shall not be in the assembly of My people, nor be written in the record of the house of Israel, nor shall they enter into the land of Israel. Then you shall know that I am the Lord GOD.

10. "Because, indeed, because they have seduced My people, saying, "Peace!' when there is no peace--and one builds a wall, and they plaster it with untempered mortar--

11. say to those who plaster it with untempered mortar, that it will fall. There will be flooding rain, and you, O great hailstones, shall fall; and a stormy wind shall tear it down.

12. Surely, when the wall has fallen, will it not be said to you, "Where is the mortar with which you plastered it?"'

13. Therefore thus says the Lord GOD: "I will cause a stormy wind to break forth in My fury; and there shall be a flooding rain in My anger, and great hailstones in fury to consume it.

14. So I will break down the wall you have plastered with untempered mortar, and bring it down to the ground, so that its foundation will be uncovered; it will fall, and you shall be consumed in the midst of it. Then you shall know that I am the LORD.

15. "Thus will I accomplish My wrath on the wall and on those who have plastered it with untempered mortar; and I will say to you, "The wall is no more, nor those who plastered it,

16. that is, the prophets of Israel who prophesy concerning Jerusalem, and who see visions of peace for her when there is no peace,"' says the Lord GOD.

17. "Likewise, son of man, set your face against the daughters of your people, who prophesy out of their own heart; prophesy against them,

18. and say, "Thus says the Lord GOD: "Woe to the women who sew magic charms on their sleeves and make veils for the heads of people of every height to hunt souls! Will you hunt the souls of My people, and keep yourselves alive?

19. And will you profane Me among My people for handfuls of barley and for pieces of bread, killing people who should not die, and keeping people alive who should not live, by your lying to My people who listen to lies?"

20. "Therefore thus says the Lord GOD: "Behold, I am against your magic charms by which you hunt souls there like birds. I will tear them from your arms, and let the souls go, the souls you hunt like birds.

21. I will also tear off your veils and deliver My people out of your hand, and they shall no longer be as prey in your hand. Then you shall know that I am the LORD.

22. "Because with lies you have made the heart of the righteous sad, whom I have not made sad; and you have strengthened the hands of the wicked, so that he does not turn from his wicked way to save his life.

23. Therefore you shall no longer envision futility nor practice divination; for I will deliver My people out of your hand, and you shall know that I am the LORD.""'

## Chapter 14

1. Now some of the elders of Israel came to me and sat before me.

2. And the word of the LORD came to me, saying,

3. "Son of man, these men have set up their idols in their hearts, and put before them that which causes them to stumble into iniquity. Should I let Myself be inquired of at all by them?

4. "Therefore speak to them, and say to them, "Thus says the Lord GOD: "Everyone of the house of Israel who sets up his idols in his heart, and puts before him what causes him to stumble into iniquity, and then comes to the prophet, I the LORD will answer him who comes, according to the multitude of his idols,

5. that I may seize the house of Israel by their heart, because they are all estranged from Me by their idols."'

6. "Therefore say to the house of Israel, "Thus says the Lord GOD: "Repent, turn away from your idols, and turn your faces away from all your abominations.

7. For anyone of the house of Israel, or of the strangers who dwell in Israel, who separates himself from Me and sets up his idols in his heart and puts before him what causes him to stumble into iniquity, then comes to a prophet to inquire of him concerning Me, I the LORD will answer him by Myself.

8. I will set My face against that man and make him a sign and a proverb, and I will cut him off from the midst of My people. Then you shall know that I am the LORD.

9. "And if the prophet is induced to speak anything, I the LORD have induced that prophet, and I will stretch out My hand against him and destroy him from among My people Israel.

10. And they shall bear their iniquity; the punishment of the prophet shall be the same as the punishment of the one who inquired,

11. that the house of Israel may no longer stray from Me, nor be profaned anymore with all their transgressions, but that they may be My people and I may be their God," says the Lord GOD."'

12. The word of the LORD came again to me, saying:

13. "Son of man, when a land sins against Me by persistent unfaithfulness, I will stretch out My hand against it; I will cut off its supply of bread, send famine on it, and cut off man and beast from it.

14. Even if these three men, Noah, Daniel, and Job, were in it, they would deliver only themselves by their righteousness," says the Lord GOD.

15. "If I cause wild beasts to pass through the land, and they empty it, and make it so desolate that no man may pass through because of the beasts,

16. even though these three men were in it, as I live," says the Lord GOD, "they would deliver neither sons nor daughters; only they would be delivered, and the land would be desolate.

17. "Or if I bring a sword on that land, and say, "Sword, go through the land,' and I cut off man and beast from it,

18. even though these three men were in it, as I live," says the Lord GOD, "they would deliver neither sons nor daughters, but only they themselves would be delivered.

19. "Or if I send a pestilence into that land and pour out My fury on it in blood, and cut off from it man and beast,

20. even though Noah, Daniel, and Job were in it, as I live," says the Lord GOD, "they would deliver neither son nor daughter; they would deliver only themselves by their righteousness."

21. For thus says the Lord GOD: "How much more it shall be when I send My four severe judgments on Jerusalem--the sword and famine and wild beasts and pestilence--to cut off man and beast from it?

22. Yet behold, there shall be left in it a remnant who will be brought out, both sons and daughters; surely they will come out to you, and you will see their ways and their doings. Then you will be comforted concerning the disaster that I have brought upon Jerusalem, all that I have brought upon it.

23. And they will comfort you, when you see their ways and their doings; and you shall know that I have done nothing without cause that I have done in it," says the Lord GOD.

## Chapter 15

1. Then the word of the LORD came to me, saying:

2. "Son of man, how is the wood of the vine better than any other wood, the vine branch which is among the trees of the forest?

3. Is wood taken from it to make any object? Or can men make a peg from it to hang any vessel on?

4. Instead, it is thrown into the fire for fuel; the fire devours both ends of it, and its middle is burned. Is it useful for any work?

5. Indeed, when it was whole, no object could be made from it. How much less will it be useful for any work when the fire has devoured it, and it is burned?

6. "Therefore thus says the Lord GOD: "Like the wood of the vine among the trees of the forest, which I have given to the fire for fuel, so I will give up the inhabitants of Jerusalem;

7. and I will set My face against them. They will go out from one fire, but another fire shall devour them. Then you shall know that I am the LORD, when I set My face against them.

8. Thus I will make the land desolate, because they have persisted in unfaithfulness,' says the Lord GOD."

## Chapter 16

1. Again the word of the LORD came to me, saying,

2. "Son of man, cause Jerusalem to know her abominations,

3. and say, "Thus says the Lord GOD to Jerusalem: "Your birth and your nativity are from the land of Canaan; your father was an Amorite and your mother a Hittite.

4. As for your nativity, on the day you were born your navel cord was not cut, nor were you washed in water to cleanse you; you were not rubbed with salt nor wrapped in swaddling cloths.

5. No eye pitied you, to do any of these things for you, to have compassion on you; but you were thrown out into the open field, when you yourself were loathed on the day you were born.

6. "And when I passed by you and saw you struggling in your own blood, I said to you in your blood, "Live!' Yes, I said to you in your blood, "Live!'

7. I made you thrive like a plant in the field; and you grew, matured, and became very beautiful. Your breasts were formed, your hair grew, but you were naked and bare.

8. "When I passed by you again and looked upon you, indeed your time was the time of love; so I spread My wing over you and covered your nakedness. Yes, I swore an oath to you and entered into a covenant with you, and you became Mine," says the Lord GOD.

9. "Then I washed you in water; yes, I thoroughly washed off your blood, and I anointed you with oil.

10. I clothed you in embroidered cloth and gave you sandals of badger skin; I clothed you with fine linen and covered you with silk.

11. I adorned you with ornaments, put bracelets on your wrists, and a chain on your neck.

12. And I put a jewel in your nose, earrings in your ears, and a beautiful crown on your head.

13. Thus you were adorned with gold and silver, and your clothing was of fine linen, silk, and embroidered cloth. You ate pastry of fine flour, honey, and oil. You were exceedingly beautiful, and succeeded to royalty.

14. Your fame went out among the nations because of your beauty, for it was perfect through My splendor which I had bestowed on you," says the Lord GOD.

15. "But you trusted in your own beauty, played the harlot because of your fame, and poured out your harlotry on everyone passing by who would have it.

16. You took some of your garments and adorned multicolored high places for yourself, and played the harlot on them. Such things should not happen, nor be.

17. You have also taken your beautiful jewelry from My gold and My silver, which I had given you, and made for yourself male images and played the harlot with them.

18. You took your embroidered garments and covered them, and you set My oil and My incense before them.

19. Also My food which I gave you--the pastry of fine flour, oil, and honey which I fed you--you set it before them as sweet incense; and so it was," says the Lord GOD.

20. "Moreover you took your sons and your daughters, whom you bore to Me, and these you sacrificed to them to be devoured. Were your acts of harlotry a small matter,

21. that you have slain My children and offered them up to them by causing them to pass through the fire?

22. And in all your abominations and acts of harlotry you did not remember the days of your youth, when you were naked and bare, struggling in your blood.

23. "Then it was so, after all your wickedness--"Woe, woe to you!' says the Lord GOD--

24. that you also built for yourself a shrine, and made a high place for yourself in every street.

25. You built your high places at the head of every road, and made your beauty to be abhorred. You offered yourself to everyone who passed by, and multiplied your acts of harlotry.

26. You also committed harlotry with the Egyptians, your very fleshly neighbors, and increased your acts of harlotry to provoke Me to anger.

27. "Behold, therefore, I stretched out My hand against you, diminished your allotment, and gave you up to the will of those who hate you, the daughters of the Philistines, who were ashamed of your lewd behavior.

28. You also played the harlot with the Assyrians, because you were insatiable; indeed you played the harlot with them and still were not satisfied.

29. Moreover you multiplied your acts of harlotry as far as the land of the trader, Chaldea; and even then you were not satisfied.

30. "How degenerate is your heart!" says the Lord GOD, "seeing you do all these things, the deeds of a brazen harlot.

31. "You erected your shrine at the head of every road, and built your high place in every street. Yet you were not like a harlot, because you scorned payment.

32. You are an adulterous wife, who takes strangers instead of her husband.

33. Men make payment to all harlots, but you made your payments to all your lovers, and hired them to come to you from all around for your harlotry.

34. You are the opposite of other women in your harlotry, because no one solicited you to be a harlot. In that you gave payment but no payment was given you, therefore you are the opposite."

35. "Now then, O harlot, hear the word of the LORD!

36. Thus says the Lord GOD: "Because your filthiness was poured out and your nakedness uncovered in your harlotry with your lovers, and with all your abominable idols, and because of the blood of your children which you gave to them,

37. surely, therefore, I will gather all your lovers with whom you took pleasure, all those you loved, and all those you hated; I will gather them from all around against you and will uncover your nakedness to them, that they may see all your nakedness.

38. And I will judge you as women who break wedlock or shed blood are judged; I will bring blood upon you in fury and jealousy.

39. I will also give you into their hand, and they shall throw down your shrines and break down your high places. They shall also strip you of your clothes, take your beautiful jewelry, and leave you naked and bare.

40. "They shall also bring up an assembly against you, and they shall stone you with stones and thrust you through with their swords.

41. They shall burn your houses with fire, and execute judgments on you in the sight of many women; and I will make you cease playing the harlot, and you shall no longer hire lovers.

42. So I will lay to rest My fury toward you, and My jealousy shall depart from you. I will be quiet, and be angry no more.

43. Because you did not remember the days of your youth, but agitated Me with all these things, surely I will also recompense your deeds on your own head," says the Lord GOD. "And you shall not commit lewdness in addition to all your abominations.

44. "Indeed everyone who quotes proverbs will use this proverb against you: "Like mother, like daughter!'

45. You are your mother's daughter, loathing husband and children; and you are the sister of your sisters, who loathed their husbands and children; your mother was a Hittite and your father an Amorite.

46. "Your elder sister is Samaria, who dwells with her daughters to the north of you; and your younger sister, who dwells to the south of you, is Sodom and her daughters.

47. You did not walk in their ways nor act according to their abominations; but, as if that were too little, you became more corrupt than they in all your ways.

48. "As I live," says the Lord GOD, "neither your sister Sodom nor her daughters have done as you and your daughters have done.

49. Look, this was the iniquity of your sister Sodom: She and her daughter had pride, fullness of food, and abundance of idleness; neither did she strengthen the hand of the poor and needy.

50. And they were haughty and committed abomination before Me; therefore I took them away as I saw fit.

51. "Samaria did not commit half of your sins; but you have multiplied your abominations more than they, and have justified your sisters by all the abominations which you have done.

52. You who judged your sisters, bear your own shame also, because the sins which you committed were more abominable than theirs; they are more righteous than you. Yes, be disgraced also, and bear your own shame, because you justified your sisters.

53. "When I bring back their captives, the captives of Sodom and her daughters, and the captives of Samaria and her daughters, then I will also bring back the captives of your captivity among them,

54. that you may bear your own shame and be disgraced by all that you did when you comforted them.

55. When your sisters, Sodom and her daughters, return to their former state, and Samaria and her daughters return to their former state, then you and your daughters will return to your former state.

56. For your sister Sodom was not a byword in your mouth in the days of your pride,

57. before your wickedness was uncovered. It was like the time of the reproach of the daughters of Syria and all those around her, and of the daughters of the Philistines, who despise you everywhere.

58. You have paid for your lewdness and your abominations," says the LORD.

59. For thus says the Lord GOD: "I will deal with you as you have done, who despised the oath by breaking the covenant.

60. "Nevertheless I will remember My covenant with you in the days of your youth, and I will establish an everlasting covenant with you.

61. Then you will remember your ways and be ashamed, when you receive your older and your younger sisters; for I will give them to you for daughters, but not because of My covenant with you.

62. And I will establish My covenant with you. Then you shall know that I am the LORD,

63. that you may remember and be ashamed, and never open your mouth anymore because of your shame, when I provide you an atonement for all you have done," says the Lord GOD."'

## Chapter 17

1. And the word of the LORD came to me, saying,

2. "Son of man, pose a riddle, and speak a parable to the house of Israel,

3. and say, "Thus says the Lord GOD: "A great eagle with large wings and long pinions, Full of feathers of various colors, Came to Lebanon And took from the cedar the highest branch.

4. He cropped off its topmost young twig And carried it to a land of trade; He set it in a city of merchants.

5. Then he took some of the seed of the land And planted it in a fertile field; He placed it by abundant waters And set it like a willow tree.

6. And it grew and became a spreading vine of low stature; Its branches turned toward him, But its roots were under it. So it became a vine, Brought forth branches, And put forth shoots.

7. "But there was another great eagle with large wings and many feathers; And behold, this vine bent its roots toward him, And stretched its branches toward him, From the garden terrace where it had been planted, That he might water it.

8. It was planted in good soil by many waters, To bring forth branches, bear fruit, And become a majestic vine."'

9. "Say, "Thus says the Lord GOD: "Will it thrive? Will he not pull up its roots, Cut off its fruit, And leave it to wither? All of its spring leaves will wither, And no great power or many people Will be needed to pluck it up by its roots.

10. Behold, it is planted, Will it thrive? Will it not utterly wither when the east wind touches it? It will wither in the garden terrace where it grew.""'

11. Moreover the word of the LORD came to me, saying,

12. "Say now to the rebellious house: "Do you not know what these things mean?' Tell them, "Indeed the king of Babylon went to Jerusalem and took its king and princes, and led them with him to Babylon.

13. And he took the king's offspring, made a covenant with him, and put him under oath. He also took away the mighty of the land,

14. that the kingdom might be brought low and not lift itself up, but that by keeping his covenant it might stand.

15. But he rebelled against him by sending his ambassadors to Egypt, that they might give him horses and many people. Will he prosper? Will he who does such things escape? Can he break a covenant and still be delivered?

16. "As I live,' says the Lord GOD, "surely in the place where the king dwells who made him king, whose oath he despised and whose covenant he broke--with him in the midst of Babylon he shall die.

17. Nor will Pharaoh with his mighty army and great company do anything in the war, when they heap up a siege mound and build a wall to cut off many persons.

18. Since he despised the oath by breaking the covenant, and in fact gave his hand and still did all these things, he shall not escape."'

19. Therefore thus says the Lord GOD: "As I live, surely My oath which he despised, and My covenant which he broke, I will recompense on his own head.

20. I will spread My net over him, and he shall be taken in My snare. I will bring him to Babylon and try him there for the treason which he committed against Me.

21. All his fugitives with all his troops shall fall by the sword, and those who remain shall be scattered to every wind; and you shall know that I, the LORD, have spoken."

22. Thus says the Lord GOD: "I will take also one of the highest branches of the high cedar and set it out. I will crop off from the topmost of its young twigs a tender one, and will plant it on a high and prominent mountain.

23. On the mountain height of Israel I will plant it; and it will bring forth boughs, and bear fruit, and be a majestic cedar. Under it will dwell birds of every sort; in the shadow of its branches they will dwell.

24. And all the trees of the field shall know that I, the LORD, have brought down the high tree and exalted the low tree, dried up the green tree and made the dry tree flourish; I, the LORD, have spoken and have done it."

## Chapter 18

1. The word of the LORD came to me again, saying,

2. "What do you mean when you use this proverb concerning the land of Israel, saying: "The fathers have eaten sour grapes, And the children's teeth are set on edge'?

3. "As I live," says the Lord GOD, "you shall no longer use this proverb in Israel.

4. "Behold, all souls are Mine; The soul of the father As well as the soul of the son is Mine; The soul who sins shall die.

5. But if a man is just And does what is lawful and right;

6. If he has not eaten on the mountains, Nor lifted up his eyes to the idols of the house of Israel, Nor defiled his neighbor's wife, Nor approached a woman during her impurity;

7. If he has not oppressed anyone, But has restored to the debtor his pledge; Has robbed no one by violence, But has given his bread to the hungry And covered the naked with clothing;

8. If he has not exacted usury Nor taken any increase, But has withdrawn his hand from iniquity And executed true judgment between man and man;

9. If he has walked in My statutes And kept My judgments faithfully-- He is just; He shall surely live!" Says the Lord GOD.

10. "If he begets a son who is a robber Or a shedder of blood, Who does any of these things

11. And does none of those duties, But has eaten on the mountains Or defiled his neighbor's wife;

12. If he has oppressed the poor and needy, Robbed by violence, Not restored the pledge, Lifted his eyes to the idols, Or committed abomination;

13. If he has exacted usury Or taken increase-- Shall he then live? He shall not live! If he has done any of these abominations, He shall surely die; His blood shall be upon him.

14. "If, however, he begets a son Who sees all the sins which his father has done, And considers but does not do likewise;

15. Who has not eaten on the mountains, Nor lifted his eyes to the idols of the house of Israel, Nor defiled his neighbor's wife;

16. Has not oppressed anyone, Nor withheld a pledge, Nor robbed by violence, But has given his bread to the hungry And covered the naked with clothing;

17. Who has withdrawn his hand from the poor And not received usury or increase, But has executed My judgments And walked in My statutes-- He shall not die for the iniquity of his father; He shall surely live!

18. "As for his father, Because he cruelly oppressed, Robbed his brother by violence, And did what is not good among his people, Behold, he shall die for his iniquity.

19. "Yet you say, "Why should the son not bear the guilt of the father?' Because the son has done what is lawful and right, and has kept all My statutes and observed them, he shall surely live.

20. The soul who sins shall die. The son shall not bear the guilt of the father, nor the father bear the guilt of the son. The righteousness of the righteous shall be upon himself, and the wickedness of the wicked shall be upon himself.

21. "But if a wicked man turns from all his sins which he has committed, keeps all My statutes, and does what is lawful and right, he shall surely live; he shall not die.

22. None of the transgressions which he has committed shall be remembered against him; because of the righteousness which he has done, he shall live.

23. Do I have any pleasure at all that the wicked should die?" says the Lord GOD, "and not that he should turn from his ways and live?

24. "But when a righteous man turns away from his righteousness and commits iniquity, and does according to all the abominations that the wicked man does, shall he live? All the righteousness which he has done shall not be remembered; because of the unfaithfulness of which he is guilty and the sin which he has committed, because of them he shall die.

25. "Yet you say, "The way of the Lord is not fair.' Hear now, O house of Israel, is it not My way which is fair, and your ways which are not fair?

26. When a righteous man turns away from his righteousness, commits iniquity, and dies in it, it is because of the iniquity which he has done that he dies.

27. Again, when a wicked man turns away from the wickedness which he committed, and does what is lawful and right, he preserves himself alive.

28. Because he considers and turns away from all the transgressions which he committed, he shall surely live; he shall not die.

29. Yet the house of Israel says, "The way of the Lord is not fair.' O house of Israel, is it not My ways which are fair, and your ways which are not fair?

30. "Therefore I will judge you, O house of Israel, every one according to his ways," says the Lord GOD. "Repent, and turn from all your transgressions, so that iniquity will not be your ruin.

31. Cast away from you all the transgressions which you have committed, and get yourselves a new heart and a new spirit. For why should you die, O house of Israel?

32. For I have no pleasure in the death of one who dies," says the Lord GOD. "Therefore turn and live!"

## Chapter 19

1. "Moreover take up a lamentation for the princes of Israel,

2. and say: "What is your mother? A lioness: She lay down among the lions; Among the young lions she nourished her cubs.

3. She brought up one of her cubs, And he became a young lion; He learned to catch prey, And he devoured men.

4. The nations also heard of him; He was trapped in their pit, And they brought him with chains to the land of Egypt.

5. "When she saw that she waited, that her hope was lost, She took another of her cubs and made him a young lion.

6. He roved among the lions, And became a young lion; He learned to catch prey; He devoured men.

7. He knew their desolate places, And laid waste their cities; The land with its fullness was desolated By the noise of his roaring.

8. Then the nations set against him from the provinces on every side, And spread their net over him; He was trapped in their pit.

9. They put him in a cage with chains, And brought him to the king of Babylon; They brought him in nets, That his voice should no longer be heard on the mountains of Israel.

10. "Your mother was like a vine in your bloodline, Planted by the waters, Fruitful and full of branches Because of many waters.

11. She had strong branches for scepters of rulers. She towered in stature above the thick branches, And was seen in her height amid the dense foliage.

12. But she was plucked up in fury, She was cast down to the ground, And the east wind dried her fruit. Her strong branches were broken and withered; The fire consumed them.

13. And now she is planted in the wilderness, In a dry and thirsty land.

14. Fire has come out from a rod of her branches And devoured her fruit, So that she has no strong branch-- a scepter for ruling."' This is a lamentation, and has become a lamentation.

## Chapter 20

1. It came to pass in the seventh year, in the fifth month, on the tenth day of the month, that certain of the elders of Israel came to inquire of the LORD, and sat before me.

2. Then the word of the LORD came to me, saying,

3. "Son of man, speak to the elders of Israel, and say to them, "Thus says the Lord GOD: "Have you come to inquire of Me? As I live," says the Lord GOD, "I will not be inquired of by you."'

4. Will you judge them, son of man, will you judge them? Then make known to them the abominations of their fathers.

5. "Say to them, "Thus says the Lord GOD: "On the day when I chose Israel and raised My hand in an oath to the descendants of the house of Jacob, and made Myself known to them in the land of Egypt, I raised My hand in an oath to them, saying, "I am the LORD your God.'

6. On that day I raised My hand in an oath to them, to bring them out of the land of Egypt into a land that I had searched out for them, "flowing with milk and honey,' the glory of all lands.

7. Then I said to them, "Each of you, throw away the abominations which are before his eyes, and do not defile yourselves with the idols of Egypt. I am the LORD your God.'

8. But they rebelled against Me and would not obey Me. They did not all cast away the abominations which were before their eyes, nor did they forsake the idols of Egypt. Then I said, "I will pour out My fury on them and fulfill My anger against them in the midst of the land of Egypt.'

9. But I acted for My name's sake, that it should not be profaned before the Gentiles among whom they were, in whose sight I had made Myself known to them, to bring them out of the land of Egypt.

10. "Therefore I made them go out of the land of Egypt and brought them into the wilderness.

11. And I gave them My statutes and showed them My judgments, "which, if a man does, he shall live by them.'

12. Moreover I also gave them My Sabbaths, to be a sign between them and Me, that they might know that I am the LORD who sanctifies them.

13. Yet the house of Israel rebelled against Me in the wilderness; they did not walk in My statutes; they despised My judgments, "which, if a man does, he shall live by them'; and they greatly defiled My Sabbaths. Then I said I would pour out My fury on them in the wilderness, to consume them.

14. But I acted for My name's sake, that it should not be profaned before the Gentiles, in whose sight I had brought them out.

15. So I also raised My hand in an oath to them in the wilderness, that I would not bring them into the land which I had given them, "flowing with milk and honey,' the glory of all lands,

16. because they despised My judgments and did not walk in My statutes, but profaned My Sabbaths; for their heart went after their idols.

17. Nevertheless My eye spared them from destruction. I did not make an end of them in the wilderness.

18. "But I said to their children in the wilderness, "Do not walk in the statutes of your fathers, nor observe their judgments, nor defile yourselves with their idols.

19. I am the LORD your God: Walk in My statutes, keep My judgments, and do them;

20. hallow My Sabbaths, and they will be a sign between Me and you, that you may know that I am the LORD your God.'

21. "Notwithstanding, the children rebelled against Me; they did not walk in My statutes, and were not careful to observe My judgments, "which, if a man does, he shall live by them'; but they profaned My Sabbaths. Then I said I would pour out My fury on them and fulfill My anger against them in the wilderness.

22. Nevertheless I withdrew My hand and acted for My name's sake, that it should not be profaned in the sight of the Gentiles, in whose sight I had brought them out.

23. Also I raised My hand in an oath to those in the wilderness, that I would scatter them among the Gentiles and disperse them throughout the countries,

24. because they had not executed My judgments, but had despised My statutes, profaned My Sabbaths, and their eyes were fixed on their fathers' idols.

25. "Therefore I also gave them up to statutes that were not good, and judgments by which they could not live;

26. and I pronounced them unclean because of their ritual gifts, in that they caused all their firstborn to pass through the fire, that I might make them desolate and that they might know that I am the LORD."'

27. "Therefore, son of man, speak to the house of Israel, and say to them, "Thus says the Lord GOD: "In this too your fathers have blasphemed Me, by being unfaithful to Me.

28. When I brought them into the land concerning which I had raised My hand in an oath to give them, and they saw all the high hills and all the thick trees, there they offered their sacrifices and provoked Me with their offerings. There they also sent up their sweet aroma and poured out their drink offerings.

29. Then I said to them, "What is this high place to which you go?' So its name is called Bamah to this day."'

30. Therefore say to the house of Israel, "Thus says the Lord GOD: "Are you defiling yourselves in the manner of your fathers, and committing harlotry according to their abominations?

31. For when you offer your gifts and make your sons pass through the fire, you defile yourselves with all your idols, even to this day. So shall I be inquired of by you, O house of Israel? As I live," says the Lord GOD, "I will not be inquired of by you.

32. What you have in your mind shall never be, when you say, "We will be like the Gentiles, like the families in other countries, serving wood and stone.'

33. "As I live," says the Lord GOD, "surely with a mighty hand, with an outstretched arm, and with fury poured out, I will rule over you.

34. I will bring you out from the peoples and gather you out of the countries where you are scattered, with a mighty hand, with an outstretched arm, and with fury poured out.

35. And I will bring you into the wilderness of the peoples, and there I will plead My case with you face to face.

36. Just as I pleaded My case with your fathers in the wilderness of the land of Egypt, so I will plead My case with you," says the Lord GOD.

37. "I will make you pass under the rod, and I will bring you into the bond of the covenant;

38. I will purge the rebels from among you, and those who transgress against Me; I will bring them out of the country where they dwell, but they shall not enter the land of Israel. Then you will know that I am the LORD.

39. "As for you, O house of Israel," thus says the Lord GOD: "Go, serve every one of you his idols--and hereafter--if you will not obey Me; but profane My holy name no more with your gifts and your idols.

40. For on My holy mountain, on the mountain height of Israel," says the Lord GOD, "there all the house of Israel, all of them in the land, shall serve Me; there I will accept them, and there I will require your offerings and the firstfruits of your sacrifices, together with all your holy things.

41. I will accept you as a sweet aroma when I bring you out from the peoples and gather you out of the countries where you have been scattered; and I will be hallowed in you before the Gentiles.

42. Then you shall know that I am the LORD, when I bring you into the land of Israel, into the country for which I raised My hand in an oath to give to your fathers.

43. And there you shall remember your ways and all your doings with which you were defiled; and you shall loathe yourselves in your own sight because of all the evils that you have committed.

44. Then you shall know that I am the LORD, when I have dealt with you for My name's sake, not according to your wicked ways nor according to your corrupt doings, O house of Israel," says the Lord GOD."'

45. Furthermore the word of the LORD came to me, saying,

46. "Son of man, set your face toward the south; preach against the south and prophesy against the forest land, the South,

47. and say to the forest of the South, "Hear the word of the LORD! Thus says the Lord GOD: "Behold, I will kindle a fire in you, and it shall devour every green tree and every dry tree in you; the blazing flame shall not be quenched, and all faces from the south to the north shall be scorched by it.

48. All flesh shall see that I, the LORD, have kindled it; it shall not be quenched.""'

49. Then I said, "Ah, Lord GOD! They say of me, "Does he not speak parables?"'

## Chapter 21

1. And the word of the LORD came to me, saying,

2. "Son of man, set your face toward Jerusalem, preach against the holy places, and prophesy against the land of Israel;

3. and say to the land of Israel, "Thus says the LORD: "Behold, I am against you, and I will draw My sword out of its sheath and cut off both righteous and wicked from you.

4. Because I will cut off both righteous and wicked from you, therefore My sword shall go out of its sheath against all flesh from south to north,

5. that all flesh may know that I, the LORD, have drawn My sword out of its sheath; it shall not return anymore."'

6. Sigh therefore, son of man, with a breaking heart, and sigh with bitterness before their eyes.

7. And it shall be when they say to you, "Why are you sighing?' that you shall answer, "Because of the news; when it comes, every heart will melt, all hands will be feeble, every spirit will faint, and all knees will be weak as water. Behold, it is coming and shall be brought to pass,' says the Lord GOD."

8. Again the word of the LORD came to me, saying,

9. "Son of man, prophesy and say, "Thus says the LORD!' Say: "A sword, a sword is sharpened And also polished!

10. Sharpened to make a dreadful slaughter, Polished to flash like lightning! Should we then make mirth? It despises the scepter of My son, As it does all wood.

11. And He has given it to be polished, That it may be handled; This sword is sharpened, and it is polished To be given into the hand of the slayer.'

12. "Cry and wail, son of man; For it will be against My people, Against all the princes of Israel. Terrors including the sword will be against My people; Therefore strike your thigh.

13. "Because it is a testing, And what if the sword despises even the scepter? The scepter shall be no more," says the Lord GOD.

14. "You therefore, son of man, prophesy, And strike your hands together. The third time let the sword do double damage. It is the sword that slays, The sword that slays the great men, That enters their private chambers.

15. I have set the point of the sword against all their gates, That the heart may melt and many may stumble. Ah! It is made bright; It is grasped for slaughter:

16. "Swords at the ready! Thrust right! Set your blade! Thrust left-- Wherever your edge is ordered!

17. "I also will beat My fists together, And I will cause My fury to rest; I, the LORD, have spoken."

18. The word of the LORD came to me again, saying:

19. "And son of man, appoint for yourself two ways for the sword of the king of Babylon to go; both of them shall go from the same land. Make a sign; put it at the head of the road to the city.

20. Appoint a road for the sword to go to Rabbah of the Ammonites, and to Judah, into fortified Jerusalem.

21. For the king of Babylon stands at the parting of the road, at the fork of the two roads, to use divination: he shakes the arrows, he consults the images, he looks at the liver.

22. In his right hand is the divination for Jerusalem: to set up battering rams, to call for a slaughter, to lift the voice with shouting, to set battering rams against the gates, to heap up a siege mound, and to build a wall.

23. And it will be to them like a false divination in the eyes of those who have sworn oaths with them; but he will bring their iniquity to remembrance, that they may be taken.

24. "Therefore thus says the Lord GOD: "Because you have made your iniquity to be remembered, in that your transgressions are uncovered, so that in all your doings your sins appear--because you have come to remembrance, you shall be taken in hand.

25. "Now to you, O profane, wicked prince of Israel, whose day has come, whose iniquity shall end,

26. thus says the Lord GOD: "Remove the turban, and take off the crown; Nothing shall remain the same. Exalt the humble, and humble the exalted.

27. Overthrown, overthrown, I will make it overthrown! It shall be no longer, Until He comes whose right it is, And I will give it to Him."'

28. "And you, son of man, prophesy and say, "Thus says the Lord GOD concerning the Ammonites and concerning their reproach,' and say: "A sword, a sword is drawn, Polished for slaughter, For consuming, for flashing--

29. While they see false visions for you, While they divine a lie to you, To bring you on the necks of the wicked, the slain Whose day has come, Whose iniquity shall end.

30. "Return it to its sheath. I will judge you In the place where you were created, In the land of your nativity.

31. I will pour out My indignation on you; I will blow against you with the fire of My wrath, And deliver you into the hands of brutal men who are skillful to destroy.

32. You shall be fuel for the fire; Your blood shall be in the midst of the land. You shall not be remembered, For I the LORD have spoken."'

## Chapter 22

1. Moreover the word of the LORD came to me, saying,

2. "Now, son of man, will you judge, will you judge the bloody city? Yes, show her all her abominations!

3. Then say, "Thus says the Lord GOD: "The city sheds blood in her own midst, that her time may come; and she makes idols within herself to defile herself.

4. You have become guilty by the blood which you have shed, and have defiled yourself with the idols which you have made. You have caused your days to draw near, and have come to the end of your years; therefore I have made you a reproach to the nations, and a mockery to all countries.

5. Those near and those far from you will mock you as infamous and full of tumult.

6. "Look, the princes of Israel: each one has used his power to shed blood in you.

7. In you they have made light of father and mother; in your midst they have oppressed the stranger; in you they have mistreated the fatherless and the widow.

8. You have despised My holy things and profaned My Sabbaths.

9. In you are men who slander to cause bloodshed; in you are those who eat on the mountains; in your midst they commit lewdness.

10. In you men uncover their fathers' nakedness; in you they violate women who are set apart during their impurity.

11. One commits abomination with his neighbor's wife; another lewdly defiles his daughter-in-law; and another in you violates his sister, his father's daughter.

12. In you they take bribes to shed blood; you take usury and increase; you have made profit from your neighbors by extortion, and have forgotten Me," says the Lord GOD.

13. "Behold, therefore, I beat My fists at the dishonest profit which you have made, and at the bloodshed which has been in your midst.

14. Can your heart endure, or can your hands remain strong, in the days when I shall deal with you? I, the LORD, have spoken, and will do it.

15. I will scatter you among the nations, disperse you throughout the countries, and remove your filthiness completely from you.

16. You shall defile yourself in the sight of the nations; then you shall know that I am the LORD.""'

17. The word of the LORD came to me, saying,

18. "Son of man, the house of Israel has become dross to Me; they are all bronze, tin, iron, and lead, in the midst of a furnace; they have become dross from silver.

19. Therefore thus says the Lord GOD: "Because you have all become dross, therefore behold, I will gather you into the midst of Jerusalem.

20. As men gather silver, bronze, iron, lead, and tin into the midst of a furnace, to blow fire on it, to melt it; so I will gather you in My anger and in My fury, and I will leave you there and melt you.

21. Yes, I will gather you and blow on you with the fire of My wrath, and you shall be melted in its midst.

22. As silver is melted in the midst of a furnace, so shall you be melted in its midst; then you shall know that I, the LORD, have poured out My fury on you."'

23. And the word of the LORD came to me, saying,

24. "Son of man, say to her: "You are a land that is not cleansed or rained on in the day of indignation.'

25. The conspiracy of her prophets in her midst is like a roaring lion tearing the prey; they have devoured people; they have taken treasure and precious things; they have made many widows in her midst.

26. Her priests have violated My law and profaned My holy things; they have not distinguished between the holy and unholy, nor have they made known the difference between the unclean and the clean; and they have hidden their eyes from My Sabbaths, so that I am profaned among them.

27. Her princes in her midst are like wolves tearing the prey, to shed blood, to destroy people, and to get dishonest gain.

28. Her prophets plastered them with untempered mortar, seeing false visions, and divining lies for them, saying, "Thus says the Lord GOD,' when the LORD had not spoken.

29. The people of the land have used oppressions, committed robbery, and mistreated the poor and needy; and they wrongfully oppress the stranger.

30. So I sought for a man among them who would make a wall, and stand in the gap before Me on behalf of the land, that I should not destroy it; but I found no one.

31. Therefore I have poured out My indignation on them; I have consumed them with the fire of My wrath; and I have recompensed their deeds on their own heads," says the Lord GOD.

## Chapter 23

1. The word of the LORD came again to me, saying:

2. "Son of man, there were two women, The daughters of one mother.

3. They committed harlotry in Egypt, They committed harlotry in their youth; Their breasts were there embraced, Their virgin bosom was there pressed.

4. Their names: Oholah the elder and Oholibah her sister; They were Mine, And they bore sons and daughters. As for their names, Samaria is Oholah, and Jerusalem is Oholibah.

5. "Oholah played the harlot even though she was Mine; And she lusted for her lovers, the neighboring Assyrians,

6. Who were clothed in purple, Captains and rulers, All of them desirable young men, Horsemen riding on horses.

7. Thus she committed her harlotry with them, All of them choice men of Assyria; And with all for whom she lusted, With all their idols, she defiled herself.

8. She has never given up her harlotry brought from Egypt, For in her youth they had lain with her, Pressed her virgin bosom, And poured out their immorality upon her.

9. "Therefore I have delivered her Into the hand of her lovers, Into the hand of the Assyrians, For whom she lusted.

10. They uncovered her nakedness, Took away her sons and daughters, And slew her with the sword; She became a byword among women, For they had executed judgment on her.

11. "Now although her sister Oholibah saw this, she became more corrupt in her lust than she, and in her harlotry more corrupt than her sister's harlotry.

12. "She lusted for the neighboring Assyrians, Captains and rulers, Clothed most gorgeously, Horsemen riding on horses, All of them desirable young men.

13. Then I saw that she was defiled; Both took the same way.

14. But she increased her harlotry; She looked at men portrayed on the wall, Images of Chaldeans portrayed in vermilion,

15. Girded with belts around their waists, Flowing turbans on their heads, All of them looking like captains, In the manner of the Babylonians of Chaldea, The land of their nativity.

16. As soon as her eyes saw them, She lusted for them And sent messengers to them in Chaldea.

17. "Then the Babylonians came to her, into the bed of love, And they defiled her with their immorality; So she was defiled by them, and alienated herself from them.

18. She revealed her harlotry and uncovered her nakedness. Then I alienated Myself from her, As I had alienated Myself from her sister.

19. "Yet she multiplied her harlotry In calling to remembrance the days of her youth, When she had played the harlot in the land of Egypt.

20. For she lusted for her paramours, Whose flesh is like the flesh of donkeys, And whose issue is like the issue of horses.

21. Thus you called to remembrance the lewdness of your youth, When the Egyptians pressed your bosom Because of your youthful breasts.

22. "Therefore, Oholibah, thus says the Lord GOD: "Behold, I will stir up your lovers against you, From whom you have alienated yourself, And I will bring them against you from every side:

23. The Babylonians, All the Chaldeans, Pekod, Shoa, Koa, All the Assyrians with them, All of them desirable young men, Governors and rulers, Captains and men of renown, All of them riding on horses.

24. And they shall come against you With chariots, wagons, and war-horses, With a horde of people. They shall array against you Buckler, shield, and helmet all around. "I will delegate judgment to them, And they shall judge you according to their judgments.

25. I will set My jealousy against you, And they shall deal furiously with you; They shall remove your nose and your ears, And your remnant shall fall by the sword; They shall take your sons and your daughters, And your remnant shall be devoured by fire.

26. They shall also strip you of your clothes And take away your beautiful jewelry.

27. "Thus I will make you cease your lewdness and your harlotry Brought from the land of Egypt, So that you will not lift your eyes to them, Nor remember Egypt anymore.'

28. "For thus says the Lord GOD: "Surely I will deliver you into the hand of those you hate, into the hand of those from whom you alienated yourself.

29. They will deal hatefully with you, take away all you have worked for, and leave you naked and bare. The nakedness of your harlotry shall be uncovered, both your lewdness and your harlotry.

30. I will do these things to you because you have gone as a harlot after the Gentiles, because you have become defiled by their idols.

31. You have walked in the way of your sister; therefore I will put her cup in your hand.'

32. "Thus says the Lord GOD: "You shall drink of your sister's cup, The deep and wide one; You shall be laughed to scorn And held in derision; It contains much.

33. You will be filled with drunkenness and sorrow, The cup of horror and desolation, The cup of your sister Samaria.

34. You shall drink and drain it, You shall break its shards, And tear at your own breasts; For I have spoken,' Says the Lord GOD.

35. "Therefore thus says the Lord GOD: "Because you have forgotten Me and cast Me behind your back, Therefore you shall bear the penalty Of your lewdness and your harlotry."'

36. The LORD also said to me: "Son of man, will you judge Oholah and Oholibah? Then declare to them their abominations.

37. For they have committed adultery, and blood is on their hands. They have committed adultery with their idols, and even sacrificed their sons whom they bore to Me, passing them through the fire, to devour them.

38. Moreover they have done this to Me: They have defiled My sanctuary on the same day and profaned My Sabbaths.

39. For after they had slain their children for their idols, on the same day they came into My sanctuary to profane it; and indeed thus they have done in the midst of My house.

40. "Furthermore you sent for men to come from afar, to whom a messenger was sent; and there they came. And you washed yourself for them, painted your eyes, and adorned yourself with ornaments.

41. You sat on a stately couch, with a table prepared before it, on which you had set My incense and My oil.

42. The sound of a carefree multitude was with her, and Sabeans were brought from the wilderness with men of the common sort, who put bracelets on their wrists and beautiful crowns on their heads.

43. Then I said concerning her who had grown old in adulteries, "Will they commit harlotry with her now, and she with them?'

44. Yet they went in to her, as men go in to a woman who plays the harlot; thus they went in to Oholah and Oholibah, the lewd women.

45. But righteous men will judge them after the manner of adulteresses, and after the manner of women who shed blood, because they are adulteresses, and blood is on their hands.

46. "For thus says the Lord GOD: "Bring up an assembly against them, give them up to trouble and plunder.

47. The assembly shall stone them with stones and execute them with their swords; they shall slay their sons and their daughters, and burn their houses with fire.

48. Thus I will cause lewdness to cease from the land, that all women may be taught not to practice your lewdness.

49. They shall repay you for your lewdness, and you shall pay for your idolatrous sins. Then you shall know that I am the Lord GOD."'

## Chapter 24

1. Again, in the ninth year, in the tenth month, on the tenth day of the month, the word of the LORD came to me, saying,

2. "Son of man, write down the name of the day, this very day--the king of Babylon started his siege against Jerusalem this very day.

3. And utter a parable to the rebellious house, and say to them, "Thus says the Lord GOD: "Put on a pot, set it on, And also pour water into it.

4. Gather pieces of meat in it, Every good piece, The thigh and the shoulder. Fill it with choice cuts;

5. Take the choice of the flock. Also pile fuel bones under it, Make it boil well, And let the cuts simmer in it."

6. "Therefore thus says the Lord GOD: "Woe to the bloody city, To the pot whose scum is in it, And whose scum is not gone from it! Bring it out piece by piece, On which no lot has fallen.

7. For her blood is in her midst; She set it on top of a rock; She did not pour it on the ground, To cover it with dust.

8. That it may raise up fury and take vengeance, I have set her blood on top of a rock, That it may not be covered."

9. "Therefore thus says the Lord GOD: "Woe to the bloody city! I too will make the pyre great.

10. Heap on the wood, Kindle the fire; Cook the meat well, Mix in the spices, And let the cuts be burned up.

11. "Then set the pot empty on the coals, That it may become hot and its bronze may burn, That its filthiness may be melted in it, That its scum may be consumed.

12. She has grown weary with lies, And her great scum has not gone from her. Let her scum be in the fire!

13. In your filthiness is lewdness. Because I have cleansed you, and you were not cleansed, You will not be cleansed of your filthiness anymore, Till I have caused My fury to rest upon you.

14. I, the LORD, have spoken it; It shall come to pass, and I will do it; I will not hold back, Nor will I spare, Nor will I relent; According to your ways And according to your deeds They will judge you," Says the Lord GOD."'

15. Also the word of the LORD came to me, saying,

16. "Son of man, behold, I take away from you the desire of your eyes with one stroke; yet you shall neither mourn nor weep, nor shall your tears run down.

17. Sigh in silence, make no mourning for the dead; bind your turban on your head, and put your sandals on your feet; do not cover your lips, and do not eat man's bread of sorrow."

18. So I spoke to the people in the morning, and at evening my wife died; and the next morning I did as I was commanded.

19. And the people said to me, "Will you not tell us what these things signify to us, that you behave so?"

20. Then I answered them, "The word of the LORD came to me, saying,

21. "Speak to the house of Israel, "Thus says the Lord GOD: "Behold, I will profane My sanctuary, your arrogant boast, the desire of your eyes, the delight of your soul; and your sons and daughters whom you left behind shall fall by the sword.

22. And you shall do as I have done; you shall not cover your lips nor eat man's bread of sorrow.

23. Your turbans shall be on your heads and your sandals on your feet; you shall neither mourn nor weep, but you shall pine away in your iniquities and mourn with one another.

24. Thus Ezekiel is a sign to you; according to all that he has done you shall do; and when this comes, you shall know that I am the Lord GOD."'

25. "And you, son of man--will it not be in the day when I take from them their stronghold, their joy and their glory, the desire of their eyes, and that on which they set their minds, their sons and their daughters:

26. on that day one who escapes will come to you to let you hear it with your ears;

27. on that day your mouth will be opened to him who has escaped; you shall speak and no longer be mute. Thus you will be a sign to them, and they shall know that I am the LORD."'

## Chapter 25

1. The word of the LORD came to me, saying,

2. "Son of man, set your face against the Ammonites, and prophesy against them.

3. Say to the Ammonites, "Hear the word of the Lord GOD! Thus says the Lord GOD: "Because you said, "Aha!' against My sanctuary when it was profaned, and against the land of Israel when it was desolate, and against the house of Judah when they went into captivity,

4. indeed, therefore, I will deliver you as a possession to the men of the East, and they shall set their encampments among you and make their dwellings among you; they shall eat your fruit, and they shall drink your milk.

5. And I will make Rabbah a stable for camels and Ammon a resting place for flocks. Then you shall know that I am the LORD."

6. "For thus says the Lord GOD: "Because you clapped your hands, stamped your feet, and rejoiced in heart with all your disdain for the land of Israel,

7. indeed, therefore, I will stretch out My hand against you, and give you as plunder to the nations; I will cut you off from the peoples, and I will cause you to perish from the countries; I will destroy you, and you shall know that I am the LORD."

8. "Thus says the Lord GOD: "Because Moab and Seir say, "Look! The house of Judah is like all the nations,'

9. therefore, behold, I will clear the territory of Moab of cities, of the cities on its frontier, the glory of the country, Beth Jeshimoth, Baal Meon, and Kirjathaim.

10. To the men of the East I will give it as a possession, together with the Ammonites, that the Ammonites may not be remembered among the nations.

11. And I will execute judgments upon Moab, and they shall know that I am the LORD."

12. "Thus says the Lord GOD: "Because of what Edom did against the house of Judah by taking vengeance, and has greatly offended by avenging itself on them,"

13. therefore thus says the Lord GOD: "I will also stretch out My hand against Edom, cut off man and beast from it, and make it desolate from Teman; Dedan shall fall by the sword.

14. I will lay My vengeance on Edom by the hand of My people Israel, that they may do in Edom according to My anger and according to My fury; and they shall know My vengeance," says the Lord GOD.

15. "Thus says the Lord GOD: "Because the Philistines dealt vengefully and took vengeance with a spiteful heart, to destroy because of the old hatred,"

16. therefore thus says the Lord GOD: "I will stretch out My hand against the Philistines, and I will cut off the Cherethites and destroy the remnant of the seacoast.

17. I will execute great vengeance on them with furious rebukes; and they shall know that I am the LORD, when I lay My vengeance upon them.""'

## Chapter 26

1. And it came to pass in the eleventh year, on the first day of the month, that the word of the LORD came to me, saying,

2. "Son of man, because Tyre has said against Jerusalem, "Aha! She is broken who was the gateway of the peoples; now she is turned over to me; I shall be filled; she is laid waste.'

3. "Therefore thus says the Lord GOD: "Behold, I am against you, O Tyre, and will cause many nations to come up against you, as the sea causes its waves to come up.

4. And they shall destroy the walls of Tyre and break down her towers; I will also scrape her dust from her, and make her like the top of a rock.

5. It shall be a place for spreading nets in the midst of the sea, for I have spoken,' says the Lord GOD; "it shall become plunder for the nations.

6. Also her daughter villages which are in the fields shall be slain by the sword. Then they shall know that I am the LORD.'

7. "For thus says the Lord GOD: "Behold, I will bring against Tyre from the north Nebuchadnezzar king of Babylon, king of kings, with horses, with chariots, and with horsemen, and an army with many people.

8. He will slay with the sword your daughter villages in the fields; he will heap up a siege mound against you, build a wall against you, and raise a defense against you.

9. He will direct his battering rams against your walls, and with his axes he will break down your towers.

10. Because of the abundance of his horses, their dust will cover you; your walls will shake at the noise of the horsemen, the wagons, and the chariots, when he enters your gates, as men enter a city that has been breached.

11. With the hooves of his horses he will trample all your streets; he will slay your people by the sword, and your strong pillars will fall to the ground.

12. They will plunder your riches and pillage your merchandise; they will break down your walls and destroy your pleasant houses; they will lay your stones, your timber, and your soil in the midst of the water.

13. I will put an end to the sound of your songs, and the sound of your harps shall be heard no more.

14. I will make you like the top of a rock; you shall be a place for spreading nets, and you shall never be rebuilt, for I the LORD have spoken,' says the Lord GOD.

15. "Thus says the Lord GOD to Tyre: "Will the coastlands not shake at the sound of your fall, when the wounded cry, when slaughter is made in the midst of you?

16. Then all the princes of the sea will come down from their thrones, lay aside their robes, and take off their embroidered garments; they will clothe themselves with trembling; they will sit on the ground, tremble every moment, and be astonished at you.

17. And they will take up a lamentation for you, and say to you: "How you have perished, O one inhabited by seafaring men, O renowned city, Who was strong at sea, She and her inhabitants, Who caused their terror to be on all her inhabitants!

18. Now the coastlands tremble on the day of your fall; Yes, the coastlands by the sea are troubled at your departure."'

19. "For thus says the Lord GOD: "When I make you a desolate city, like cities that are not inhabited, when I bring the deep upon you, and great waters cover you,

20. then I will bring you down with those who descend into the Pit, to the people of old, and I will make you dwell in the lowest part of the earth, in places desolate from antiquity, with those who go down to the Pit, so that you may never be inhabited; and I shall establish glory in the land of the living.

21. I will make you a terror, and you shall be no more; though you are sought for, you will never be found again,' says the Lord GOD."

## Chapter 27

1. The word of the LORD came again to me, saying,

2. "Now, son of man, take up a lamentation for Tyre,

3. and say to Tyre, "You who are situated at the entrance of the sea, merchant of the peoples on many coastlands, thus says the Lord GOD: "O Tyre, you have said, "I am perfect in beauty.'

4. Your borders are in the midst of the seas. Your builders have perfected your beauty.

5. They made all your planks of fir trees from Senir; They took a cedar from Lebanon to make you a mast.

6. Of oaks from Bashan they made your oars; The company of Ashurites have inlaid your planks With ivory from the coasts of Cyprus.

7. Fine embroidered linen from Egypt was what you spread for your sail; Blue and purple from the coasts of Elishah was what covered you.

8. "Inhabitants of Sidon and Arvad were your oarsmen; Your wise men, O Tyre, were in you; They became your pilots.

9. Elders of Gebal and its wise men Were in you to caulk your seams; All the ships of the sea And their oarsmen were in you To market your merchandise.

10. "Those from Persia, Lydia, and Libya Were in your army as men of war; They hung shield and helmet in you; They gave splendor to you.

11. Men of Arvad with your army were on your walls all around, And the men of Gammad were in your towers; They hung their shields on your walls all around; They made your beauty perfect.

12. "Tarshish was your merchant because of your many luxury goods. They gave you silver, iron, tin, and lead for your goods.

13. Javan, Tubal, and Meshech were your traders. They bartered human lives and vessels of bronze for your merchandise.

14. Those from the house of Togarmah traded for your wares with horses, steeds, and mules.

15. The men of Dedan were your traders; many isles were the market of your hand. They brought you ivory tusks and ebony as payment.

16. Syria was your merchant because of the abundance of goods you made. They gave you for your wares emeralds, purple, embroidery, fine linen, corals, and rubies.

17. Judah and the land of Israel were your traders. They traded for your merchandise wheat of Minnith, millet, honey, oil, and balm.

18. Damascus was your merchant because of the abundance of goods you made, because of your many luxury items, with the wine of Helbon and with white wool.

19. Dan and Javan paid for your wares, traversing back and forth. Wrought iron, cassia, and cane were among your merchandise.

20. Dedan was your merchant in saddlecloths for riding.

21. Arabia and all the princes of Kedar were your regular merchants. They traded with you in lambs, rams, and goats.

22. The merchants of Sheba and Raamah were your merchants. They traded for your wares the choicest spices, all kinds of precious stones, and gold.

23. Haran, Canneh, Eden, the merchants of Sheba, Assyria, and Chilmad were your merchants.

24. These were your merchants in choice items--in purple clothes, in embroidered garments, in chests of multicolored apparel, in sturdy woven cords, which were in your marketplace.

25. "The ships of Tarshish were carriers of your merchandise. You were filled and very glorious in the midst of the seas.

26. Your oarsmen brought you into many waters, But the east wind broke you in the midst of the seas.

27. "Your riches, wares, and merchandise, Your mariners and pilots, Your caulkers and merchandisers, All your men of war who are in you, And the entire company which is in your midst, Will fall into the midst of the seas on the day of your ruin.

28. The common-land will shake at the sound of the cry of your pilots.

29. "All who handle the oar, The mariners, All the pilots of the sea Will come down from their ships and stand on the shore.

30. They will make their voice heard because of you; They will cry bitterly and cast dust on their heads; They will roll about in ashes;

31. They will shave themselves completely bald because of you, Gird themselves with sackcloth, And weep for you With bitterness of heart and bitter wailing.

32. In their wailing for you They will take up a lamentation, And lament for you: "What city is like Tyre, Destroyed in the midst of the sea?

33. "When your wares went out by sea, You satisfied many people; You enriched the kings of the earth With your many luxury goods and your merchandise.

34. But you are broken by the seas in the depths of the waters; Your merchandise and the entire company will fall in your midst.

35. All the inhabitants of the isles will be astonished at you; Their kings will be greatly afraid, And their countenance will be troubled.

36. The merchants among the peoples will hiss at you; You will become a horror, and be no more forever."""

## Chapter 28

1. The word of the LORD came to me again, saying,

2. "Son of man, say to the prince of Tyre, "Thus says the Lord GOD: "Because your heart is lifted up, And you say, "I am a god, I sit in the seat of gods, In the midst of the seas,' Yet you are a man, and not a god, Though you set your heart as the heart of a god

3. (Behold, you are wiser than Daniel! There is no secret that can be hidden from you!

4. With your wisdom and your understanding You have gained riches for yourself, And gathered gold and silver into your treasuries;

5. By your great wisdom in trade you have increased your riches, And your heart is lifted up because of your riches),"

6. "Therefore thus says the Lord GOD: "Because you have set your heart as the heart of a god,

7. Behold, therefore, I will bring strangers against you, The most terrible of the nations; And they shall draw their swords against the beauty of your wisdom, And defile your splendor.

8. They shall throw you down into the Pit, And you shall die the death of the slain In the midst of the seas.

9. "Will you still say before him who slays you, "I am a god'? But you shall be a man, and not a god, In the hand of him who slays you.

10. You shall die the death of the uncircumcised By the hand of aliens; For I have spoken," says the Lord GOD."'

11. Moreover the word of the LORD came to me, saying,

12. "Son of man, take up a lamentation for the king of Tyre, and say to him, "Thus says the Lord GOD: "You were the seal of perfection, Full of wisdom and perfect in beauty.

13. You were in Eden, the garden of God; Every precious stone was your covering: The sardius, topaz, and diamond, Beryl, onyx, and jasper, Sapphire, turquoise, and emerald with gold. The workmanship of your timbrels and pipes Was prepared for you on the day you were created.

14. "You were the anointed cherub who covers; I established you; You were on the holy mountain of God; You walked back and forth in the midst of fiery stones.

15. You were perfect in your ways from the day you were created, Till iniquity was found in you.

16. "By the abundance of your trading You became filled with violence within, And you sinned; Therefore I cast you as a profane thing Out of the mountain of God; And I destroyed you, O covering cherub, From the midst of the fiery stones.

17. "Your heart was lifted up because of your beauty; You corrupted your wisdom for the sake of your splendor; I cast you to the ground, I laid you before kings, That they might gaze at you.

18. "You defiled your sanctuaries By the multitude of your iniquities, By the iniquity of your trading; Therefore I brought fire from your midst; It devoured you, And I turned you to ashes upon the earth In the sight of all who saw you.

19. All who knew you among the peoples are astonished at you; You have become a horror, And shall be no more forever.""'

20. Then the word of the LORD came to me, saying,

21. "Son of man, set your face toward Sidon, and prophesy against her,

22. and say, "Thus says the Lord GOD: "Behold, I am against you, O Sidon; I will be glorified in your midst; And they shall know that I am the LORD, When I execute judgments in her and am hallowed in her.

23. For I will send pestilence upon her, And blood in her streets; The wounded shall be judged in her midst By the sword against her on every side; Then they shall know that I am the LORD.

24. "And there shall no longer be a pricking brier or a painful thorn for the house of Israel from among all who are around them, who despise them. Then they shall know that I am the Lord GOD."

25. "Thus says the Lord GOD: "When I have gathered the house of Israel from the peoples among whom they are scattered, and am hallowed in them in the sight of the Gentiles, then they will dwell in their own land which I gave to My servant Jacob.

26. And they will dwell safely there, build houses, and plant vineyards; yes, they will dwell securely, when I execute judgments on all those around them who despise them. Then they shall know that I am the LORD their God.""'

## Chapter 29

1. In the tenth year, in the tenth month, on the twelfth day of the month, the word of the LORD came to me, saying,

2. "Son of man, set your face against Pharaoh king of Egypt, and prophesy against him, and against all Egypt.

3. Speak, and say, "Thus says the Lord GOD: "Behold, I am against you, O Pharaoh king of Egypt, O great monster who lies in the midst of his rivers, Who has said, "My River is my own; I have made it for myself.'

4. But I will put hooks in your jaws, And cause the fish of your rivers to stick to your scales; I will bring you up out of the midst of your rivers, And all the fish in your rivers will stick to your scales.

5. I will leave you in the wilderness, You and all the fish of your rivers; You shall fall on the open field; You shall not be picked up or gathered. I have given you as food To the beasts of the field And to the birds of the heavens.

6. "Then all the inhabitants of Egypt Shall know that I am the LORD, Because they have been a staff of reed to the house of Israel.

7. When they took hold of you with the hand, You broke and tore all their shoulders; When they leaned on you, You broke and made all their backs quiver."

8. "Therefore thus says the Lord GOD: "Surely I will bring a sword upon you and cut off from you man and beast.

9. And the land of Egypt shall become desolate and waste; then they will know that I am the LORD, because he said, "The River is mine, and I have made it.'

10. Indeed, therefore, I am against you and against your rivers, and I will make the land of Egypt utterly waste and desolate, from Migdol to Syene, as far as the border of Ethiopia.

11. Neither foot of man shall pass through it nor foot of beast pass through it, and it shall be uninhabited forty years.

12. I will make the land of Egypt desolate in the midst of the countries that are desolate; and among the cities that are laid waste, her cities shall be desolate forty years; and I will scatter the Egyptians among the nations and disperse them throughout the countries."

13. "Yet, thus says the Lord GOD: "At the end of forty years I will gather the Egyptians from the peoples among whom they were scattered.

14. I will bring back the captives of Egypt and cause them to return to the land of Pathros, to the land of their origin, and there they shall be a lowly kingdom.

15. It shall be the lowliest of kingdoms; it shall never again exalt itself above the nations, for I will diminish them so that they will not rule over the nations anymore.

16. No longer shall it be the confidence of the house of Israel, but will remind them of their iniquity when they turned to follow them. Then they shall know that I am the Lord GOD.""'

17. And it came to pass in the twenty-seventh year, in the first month, on the first day of the month, that the word of the LORD came to me, saying,

18. "Son of man, Nebuchadnezzar king of Babylon caused his army to labor strenuously against Tyre; every head was made bald, and every shoulder rubbed raw; yet neither he nor his army received wages from Tyre, for the labor which they expended on it.

19. Therefore thus says the Lord GOD: "Surely I will give the land of Egypt to Nebuchadnezzar king of Babylon; he shall take away her wealth, carry off her spoil, and remove her pillage; and that will be the wages for his army.

20. I have given him the land of Egypt for his labor, because they worked for Me,' says the Lord GOD.

21. "In that day I will cause the horn of the house of Israel to spring forth, and I will open your mouth to speak in their midst. Then they shall know that I am the LORD."'

## Chapter 30

1. The word of the LORD came to me again, saying,

2. "Son of man, prophesy and say, "Thus says the Lord GOD: "Wail, "Woe to the day!'

3. For the day is near, Even the day of the LORD is near; It will be a day of clouds, the time of the Gentiles.

4. The sword shall come upon Egypt, And great anguish shall be in Ethiopia, When the slain fall in Egypt, And they take away her wealth, And her foundations are broken down.

5. "Ethiopia, Libya, Lydia, all the mingled people, Chub, and the men of the lands who are allied, shall fall with them by the sword."

6. "Thus says the LORD: "Those who uphold Egypt shall fall, And the pride of her power shall come down. From Migdol to Syene Those within her shall fall by the sword," Says the Lord GOD.

7. "They shall be desolate in the midst of the desolate countries, And her cities shall be in the midst of the cities that are laid waste.

8. Then they will know that I am the LORD, When I have set a fire in Egypt And all her helpers are destroyed.

9. On that day messengers shall go forth from Me in ships To make the careless Ethiopians afraid, And great anguish shall come upon them, As on the day of Egypt; For indeed it is coming!"

10. "Thus says the Lord GOD: "I will also make a multitude of Egypt to cease By the hand of Nebuchadnezzar king of Babylon.

11. He and his people with him, the most terrible of the nations, Shall be brought to destroy the land; They shall draw their swords against Egypt, And fill the land with the slain.

12. I will make the rivers dry, And sell the land into the hand of the wicked; I will make the land waste, and all that is in it, By the hand of aliens. I, the LORD, have spoken."

13. "Thus says the Lord GOD: "I will also destroy the idols, And cause the images to cease from Noph; There shall no longer be princes from the land of Egypt; I will put fear in the land of Egypt.

14. I will make Pathros desolate, Set fire to Zoan, And execute judgments in No.

15. I will pour My fury on Sin, the strength of Egypt; I will cut off the multitude of No,

16. And set a fire in Egypt; Sin shall have great pain, No shall be split open, And Noph shall be in distress daily.

17. The young men of Aven and Pi Beseth shall fall by the sword, And these cities shall go into captivity.

18. At Tehaphnehes the day shall also be darkened, When I break the yokes of Egypt there. And her arrogant strength shall cease in her; As for her, a cloud shall cover her, And her daughters shall go into captivity.

19. Thus I will execute judgments on Egypt, Then they shall know that I am the LORD.""'

20. And it came to pass in the eleventh year, in the first month, on the seventh day of the month, that the word of the LORD came to me, saying,

21. "Son of man, I have broken the arm of Pharaoh king of Egypt; and see, it has not been bandaged for healing, nor a splint put on to bind it, to make it strong enough to hold a sword.

22. Therefore thus says the Lord GOD: "Surely I am against Pharaoh king of Egypt, and will break his arms, both the strong one and the one that was broken; and I will make the sword fall out of his hand.

23. I will scatter the Egyptians among the nations, and disperse them throughout the countries.

24. I will strengthen the arms of the king of Babylon and put My sword in his hand; but I will break Pharaoh's arms, and he will groan before him with the groanings of a mortally wounded man.

25. Thus I will strengthen the arms of the king of Babylon, but the arms of Pharaoh shall fall down; they shall know that I am the LORD, when I put My sword into the hand of the king of Babylon and he stretches it out against the land of Egypt.

26. I will scatter the Egyptians among the nations and disperse them throughout the countries. Then they shall know that I am the LORD."'

## Chapter 31

1. Now it came to pass in the eleventh year, in the third month, on the first day of the month, that the word of the LORD came to me, saying,

2. "Son of man, say to Pharaoh king of Egypt and to his multitude: "Whom are you like in your greatness?

3. Indeed Assyria was a cedar in Lebanon, With fine branches that shaded the forest, And of high stature; And its top was among the thick boughs.

4. The waters made it grow; Underground waters gave it height, With their rivers running around the place where it was planted, And sent out rivulets to all the trees of the field.

5. "Therefore its height was exalted above all the trees of the field; Its boughs were multiplied, And its branches became long because of the abundance of water, As it sent them out.

6. All the birds of the heavens made their nests in its boughs; Under its branches all the beasts of the field brought forth their young; And in its shadow all great nations made their home.

7. "Thus it was beautiful in greatness and in the length of its branches, Because its roots reached to abundant waters.

8. The cedars in the garden of God could not hide it; The fir trees were not like its boughs, And the chestnut trees were not like its branches; No tree in the garden of God was like it in beauty.

9. I made it beautiful with a multitude of branches, So that all the trees of Eden envied it, That were in the garden of God.'

10. "Therefore thus says the Lord GOD: "Because you have increased in height, and it set its top among the thick boughs, and its heart was lifted up in its height,

11. therefore I will deliver it into the hand of the mighty one of the nations, and he shall surely deal with it; I have driven it out for its wickedness.

12. And aliens, the most terrible of the nations, have cut it down and left it; its branches have fallen on the mountains and in all the valleys; its boughs lie broken by all the rivers of the land; and all the peoples of the earth have gone from under its shadow and left it.

13. "On its ruin will remain all the birds of the heavens, And all the beasts of the field will come to its branches--

14. "So that no trees by the waters may ever again exalt themselves for their height, nor set their tops among the thick boughs, that no tree which drinks water may ever be high enough to reach up to them. "For they have all been delivered to death, To the depths of the earth, Among the children of men who go down to the Pit.'

15. "Thus says the Lord GOD: "In the day when it went down to hell, I caused mourning. I covered the deep because of it. I restrained its rivers, and the great waters were held back. I caused Lebanon to mourn for it, and all the trees of the field wilted because of it.

16. I made the nations shake at the sound of its fall, when I cast it down to hell together with those who descend into the Pit; and all the trees of Eden, the choice and best of Lebanon, all that drink water, were comforted in the depths of the earth.

17. They also went down to hell with it, with those slain by the sword; and those who were its strong arm dwelt in its shadows among the nations.

18. "To which of the trees in Eden will you then be likened in glory and greatness? Yet you shall be brought down with the trees of Eden to the depths of the earth; you shall lie in the midst of the uncircumcised, with those slain by the sword. This is Pharaoh and all his multitude,' says the Lord GOD."

## Chapter 32

1. And it came to pass in the twelfth year, in the twelfth month, on the first day of the month, that the word of the LORD came to me, saying,

2. "Son of man, take up a lamentation for Pharaoh king of Egypt, and say to him: "You are like a young lion among the nations, And you are like a monster in the seas, Bursting forth in your rivers, Troubling the waters with your feet, And fouling their rivers.'

3. "Thus says the Lord GOD: "I will therefore spread My net over you with a company of many people, And they will draw you up in My net.

4. Then I will leave you on the land; I will cast you out on the open fields, And cause to settle on you all the birds of the heavens. And with you I will fill the beasts of the whole earth.

5. I will lay your flesh on the mountains, And fill the valleys with your carcass.

6. "I will also water the land with the flow of your blood, Even to the mountains; And the riverbeds will be full of you.

7. When I put out your light, I will cover the heavens, and make its stars dark; I will cover the sun with a cloud, And the moon shall not give her light.

8. All the bright lights of the heavens I will make dark over you, And bring darkness upon your land,' Says the Lord GOD.

9. "I will also trouble the hearts of many peoples, when I bring your destruction among the nations, into the countries which you have not known.

10. Yes, I will make many peoples astonished at you, and their kings shall be horribly afraid of you when I brandish My sword before them; and they shall tremble every moment, every man for his own life, in the day of your fall.'

11. "For thus says the Lord GOD: "The sword of the king of Babylon shall come upon you.

12. By the swords of the mighty warriors, all of them the most terrible of the nations, I will cause your multitude to fall. "They shall plunder the pomp of Egypt, And all its multitude shall be destroyed.

13. Also I will destroy all its animals From beside its great waters; The foot of man shall muddy them no more, Nor shall the hooves of animals muddy them.

14. Then I will make their waters clear, And make their rivers run like oil,' Says the Lord GOD.

15. "When I make the land of Egypt desolate, And the country is destitute of all that once filled it, When I strike all who dwell in it, Then they shall know that I am the LORD.

16. "This is the lamentation With which they shall lament her; The daughters of the nations shall lament her; They shall lament for her, for Egypt, And for all her multitude,' Says the Lord GOD."

17. It came to pass also in the twelfth year, on the fifteenth day of the month, that the word of the LORD came to me, saying:

18. "Son of man, wail over the multitude of Egypt, And cast them down to the depths of the earth, Her and the daughters of the famous nations, With those who go down to the Pit:

19. "Whom do you surpass in beauty? Go down, be placed with the uncircumcised.'

20. "They shall fall in the midst of those slain by the sword; She is delivered to the sword, Drawing her and all her multitudes.

21. The strong among the mighty Shall speak to him out of the midst of hell With those who help him: "They have gone down, They lie with the uncircumcised, slain by the sword.'

22. "Assyria is there, and all her company, With their graves all around her, All of them slain, fallen by the sword.

23. Her graves are set in the recesses of the Pit, And her company is all around her grave, All of them slain, fallen by the sword, Who caused terror in the land of the living.

24. "There is Elam and all her multitude, All around her grave, All of them slain, fallen by the sword, Who have gone down uncircumcised to the lower parts of the earth, Who caused their terror in the land of the living; Now they bear their shame with those who go down to the Pit.

25. They have set her bed in the midst of the slain, With all her multitude, With her graves all around it, All of them uncircumcised, slain by the sword; Though their terror was caused In the land of the living, Yet they bear their shame With those who go down to the Pit; It was put in the midst of the slain.

26. "There are Meshech and Tubal and all their multitudes, With all their graves around it, All of them uncircumcised, slain by the sword, Though they caused their terror in the land of the living.

27. They do not lie with the mighty Who are fallen of the uncircumcised, Who have gone down to hell with their weapons of war; They have laid their swords under their heads, But their iniquities will be on their bones, Because of the terror of the mighty in the land of the living.

28. Yes, you shall be broken in the midst of the uncircumcised, And lie with those slain by the sword.

29. "There is Edom, Her kings and all her princes, Who despite their might Are laid beside those slain by the sword; They shall lie with the uncircumcised, And with those who go down to the Pit.

30. There are the princes of the north, All of them, and all the Sidonians, Who have gone down with the slain In shame at the terror which they caused by their might; They lie uncircumcised with those slain by the sword, And bear their shame with those who go down to the Pit.

31. "Pharaoh will see them And be comforted over all his multitude, Pharaoh and all his army, Slain by the sword," Says the Lord GOD.

32. "For I have caused My terror in the land of the living; And he shall be placed in the midst of the uncircumcised With those slain by the sword, Pharaoh and all his multitude," Says the Lord GOD.

## Chapter 33

1. Again the word of the LORD came to me, saying,

2. "Son of man, speak to the children of your people, and say to them: "When I bring the sword upon a land, and the people of the land take a man from their territory and make him their watchman,

3. when he sees the sword coming upon the land, if he blows the trumpet and warns the people,

4. then whoever hears the sound of the trumpet and does not take warning, if the sword comes and takes him away, his blood shall be on his own head.

5. He heard the sound of the trumpet, but did not take warning; his blood shall be upon himself. But he who takes warning will save his life.

6. But if the watchman sees the sword coming and does not blow the trumpet, and the people are not warned, and the sword comes and takes any person from among them, he is taken away in his iniquity; but his blood I will require at the watchman's hand.'

7. "So you, son of man: I have made you a watchman for the house of Israel; therefore you shall hear a word from My mouth and warn them for Me.

8. When I say to the wicked, "O wicked man, you shall surely die!' and you do not speak to warn the wicked from his way, that wicked man shall die in his iniquity; but his blood I will require at your hand.

9. Nevertheless if you warn the wicked to turn from his way, and he does not turn from his way, he shall die in his iniquity; but you have delivered your soul.

10. "Therefore you, O son of man, say to the house of Israel: "Thus you say, "If our transgressions and our sins lie upon us, and we pine away in them, how can we then live?"'

11. Say to them: "As I live,' says the Lord GOD, "I have no pleasure in the death of the wicked, but that the wicked turn from his way and live. Turn, turn from your evil ways! For why should you die, O house of Israel?'

12. "Therefore you, O son of man, say to the children of your people: "The righteousness of the righteous man shall not deliver him in the day of his transgression; as for the wickedness of the wicked, he shall not fall because of it in the day that he turns from his wickedness; nor shall the righteous be able to live because of his righteousness in the day that he sins.'

13. When I say to the righteous that he shall surely live, but he trusts in his own righteousness and commits iniquity, none of his righteous works shall be remembered; but because of the iniquity that he has committed, he shall die.

14. Again, when I say to the wicked, "You shall surely die,' if he turns from his sin and does what is lawful and right,

15. if the wicked restores the pledge, gives back what he has stolen, and walks in the statutes of life without committing iniquity, he shall surely live; he shall not die.

16. None of his sins which he has committed shall be remembered against him; he has done what is lawful and right; he shall surely live.

17. "Yet the children of your people say, "The way of the LORD is not fair.' But it is their way which is not fair!

18. When the righteous turns from his righteousness and commits iniquity, he shall die because of it.

19. But when the wicked turns from his wickedness and does what is lawful and right, he shall live because of it.

20. Yet you say, "The way of the LORD is not fair.' O house of Israel, I will judge every one of you according to his own ways."

21. And it came to pass in the twelfth year of our captivity, in the tenth month, on the fifth day of the month, that one who had escaped from Jerusalem came to me and said, "The city has been captured!"

22. Now the hand of the LORD had been upon me the evening before the man came who had escaped. And He had opened my mouth; so when he came to me in the morning, my mouth was opened, and I was no longer mute.

23. Then the word of the LORD came to me, saying:

24. "Son of man, they who inhabit those ruins in the land of Israel are saying, "Abraham was only one, and he inherited the land. But we are many; the land has been given to us as a possession.'

25. "Therefore say to them, "Thus says the Lord GOD: "You eat meat with blood, you lift up your eyes toward your idols, and shed blood. Should you then possess the land?

26. You rely on your sword, you commit abominations, and you defile one another's wives. Should you then possess the land?"'

27. "Say thus to them, "Thus says the Lord GOD: "As I live, surely those who are in the ruins shall fall by the sword, and the one who is in the open field I will give to the beasts to be devoured, and those who are in the strongholds and caves shall die of the pestilence.

28. For I will make the land most desolate, her arrogant strength shall cease, and the mountains of Israel shall be so desolate that no one will pass through.

29. Then they shall know that I am the LORD, when I have made the land most desolate because of all their abominations which they have committed."'

30. "As for you, son of man, the children of your people are talking about you beside the walls and in the doors of the houses; and they speak to one another, everyone saying to his brother, "Please come and hear what the word is that comes from the LORD.'

31. So they come to you as people do, they sit before you as My people, and they hear your words, but they do not do them; for with their mouth they show much love, but their hearts pursue their own gain.

32. Indeed you are to them as a very lovely song of one who has a pleasant voice and can play well on an instrument; for they hear your words, but they do not do them.

33. And when this comes to pass--surely it will come--then they will know that a prophet has been among them."

## Chapter 34

1. And the word of the LORD came to me, saying,

2. "Son of man, prophesy against the shepherds of Israel, prophesy and say to them, "Thus says the Lord GOD to the shepherds: "Woe to the shepherds of Israel who feed themselves! Should not the shepherds feed the flocks?

3. You eat the fat and clothe yourselves with the wool; you slaughter the fatlings, but you do not feed the flock.

4. The weak you have not strengthened, nor have you healed those who were sick, nor bound up the broken, nor brought back what was driven away, nor sought what was lost; but with force and cruelty you have ruled them.

5. So they were scattered because there was no shepherd; and they became food for all the beasts of the field when they were scattered.

6. My sheep wandered through all the mountains, and on every high hill; yes, My flock was scattered over the whole face of the earth, and no one was seeking or searching for them."

7. "Therefore, you shepherds, hear the word of the LORD:

8. "As I live," says the Lord GOD, "surely because My flock became a prey, and My flock became food for every beast of the field, because there was no shepherd, nor did My shepherds search for My flock, but the shepherds fed themselves and did not feed My flock"--

9. therefore, O shepherds, hear the word of the LORD!

10. Thus says the Lord GOD: "Behold, I am against the shepherds, and I will require My flock at their hand; I will cause them to cease feeding the sheep, and the shepherds shall feed themselves no more; for I will deliver My flock from their mouths, that they may no longer be food for them."

11. "For thus says the Lord GOD: "Indeed I Myself will search for My sheep and seek them out.

12. As a shepherd seeks out his flock on the day he is among his scattered sheep, so will I seek out My sheep and deliver them from all the places where they were scattered on a cloudy and dark day.

13. And I will bring them out from the peoples and gather them from the countries, and will bring them to their own land; I will feed them on the mountains of Israel, in the valleys and in all the inhabited places of the country.

14. I will feed them in good pasture, and their fold shall be on the high mountains of Israel. There they shall lie down in a good fold and feed in rich pasture on the mountains of Israel.

15. I will feed My flock, and I will make them lie down," says the Lord GOD.

16. "I will seek what was lost and bring back what was driven away, bind up the broken and strengthen what was sick; but I will destroy the fat and the strong, and feed them in judgment."

17. "And as for you, O My flock, thus says the Lord GOD: "Behold, I shall judge between sheep and sheep, between rams and goats.

18. Is it too little for you to have eaten up the good pasture, that you must tread down with your feet the residue of your pasture--and to have drunk of the clear waters, that you must foul the residue with your feet?

19. And as for My flock, they eat what you have trampled with your feet, and they drink what you have fouled with your feet."

20. "Therefore thus says the Lord GOD to them: "Behold, I Myself will judge between the fat and the lean sheep.

21. Because you have pushed with side and shoulder, butted all the weak ones with your horns, and scattered them abroad,

22. therefore I will save My flock, and they shall no longer be a prey; and I will judge between sheep and sheep.

23. I will establish one shepherd over them, and he shall feed them--My servant David. He shall feed them and be their shepherd.

24. And I, the LORD, will be their God, and My servant David a prince among them; I, the LORD, have spoken.

25. "I will make a covenant of peace with them, and cause wild beasts to cease from the land; and they will dwell safely in the wilderness and sleep in the woods.

26. I will make them and the places all around My hill a blessing; and I will cause showers to come down in their season; there shall be showers of blessing.

27. Then the trees of the field shall yield their fruit, and the earth shall yield her increase. They shall be safe in their land; and they shall know that I am the LORD, when I have broken the bands of their yoke and delivered them from the hand of those who enslaved them.

28. And they shall no longer be a prey for the nations, nor shall beasts of the land devour them; but they shall dwell safely, and no one shall make them afraid.

29. I will raise up for them a garden of renown, and they shall no longer be consumed with hunger in the land, nor bear the shame of the Gentiles anymore.

30. Thus they shall know that I, the LORD their God, am with them, and they, the house of Israel, are My people," says the Lord GOD."'

31. "You are My flock, the flock of My pasture; you are men, and I am your God," says the Lord GOD.

## Chapter 35

1. Moreover the word of the LORD came to me, saying,

2. "Son of man, set your face against Mount Seir and prophesy against it,

3. and say to it, "Thus says the Lord GOD: "Behold, O Mount Seir, I am against you; I will stretch out My hand against you, And make you most desolate;

4. I shall lay your cities waste, And you shall be desolate. Then you shall know that I am the LORD.

5. "Because you have had an ancient hatred, and have shed the blood of the children of Israel by the power of the sword at the time of their calamity, when their iniquity came to an end,

6. therefore, as I live," says the Lord GOD, "I will prepare you for blood, and blood shall pursue you; since you have not hated blood, therefore blood shall pursue you.

7. Thus I will make Mount Seir most desolate, and cut off from it the one who leaves and the one who returns.

8. And I will fill its mountains with the slain; on your hills and in your valleys and in all your ravines those who are slain by the sword shall fall.

9. I will make you perpetually desolate, and your cities shall be uninhabited; then you shall know that I am the LORD.

10. "Because you have said, "These two nations and these two countries shall be mine, and we will possess them,' although the LORD was there,

11. therefore, as I live," says the Lord GOD, "I will do according to your anger and according to the envy which you showed in your hatred against them; and I will make Myself known among them when I judge you.

12. Then you shall know that I am the LORD. I have heard all your blasphemies which you have spoken against the mountains of Israel, saying, "They are desolate; they are given to us to consume.'

13. Thus with your mouth you have boasted against Me and multiplied your words against Me; I have heard them."

14. "Thus says the Lord GOD: "The whole earth will rejoice when I make you desolate.

15. As you rejoiced because the inheritance of the house of Israel was desolate, so I will do to you; you shall be desolate, O Mount Seir, as well as all of Edom--all of it! Then they shall know that I am the LORD."'

## Chapter 36

1. "And you, son of man, prophesy to the mountains of Israel, and say, "O mountains of Israel, hear the word of the LORD!

2. Thus says the Lord GOD: "Because the enemy has said of you, "Aha! The ancient heights have become our possession,""

3. therefore prophesy, and say, "Thus says the Lord GOD: "Because they made you desolate and swallowed you up on every side, so that you became the possession of the rest of the nations, and you are taken up by the lips of talkers and slandered by the people"--

4. therefore, O mountains of Israel, hear the word of the Lord GOD! Thus says the Lord GOD to the mountains, the hills, the rivers, the valleys, the desolate wastes, and the cities that have been forsaken, which became plunder and mockery to the rest of the nations all around--

5. therefore thus says the Lord GOD: "Surely I have spoken in My burning jealousy against the rest of the nations and against all Edom, who gave My land to themselves as a possession, with wholehearted joy and spiteful minds, in order to plunder its open country."'

6. "Therefore prophesy concerning the land of Israel, and say to the mountains, the hills, the rivers, and the valleys, "Thus says the Lord GOD: "Behold, I have spoken in My jealousy and My fury, because you have borne the shame of the nations."

7. Therefore thus says the Lord GOD: "I have raised My hand in an oath that surely the nations that are around you shall bear their own shame.

8. But you, O mountains of Israel, you shall shoot forth your branches and yield your fruit to My people Israel, for they are about to come.

9. For indeed I am for you, and I will turn to you, and you shall be tilled and sown.

10. I will multiply men upon you, all the house of Israel, all of it; and the cities shall be inhabited and the ruins rebuilt.

11. I will multiply upon you man and beast; and they shall increase and bear young; I will make you inhabited as in former times, and do better for you than at your beginnings. Then you shall know that I am the LORD.

12. Yes, I will cause men to walk on you, My people Israel; they shall take possession of you, and you shall be their inheritance; no more shall you bereave them of children."

13. "Thus says the Lord GOD: "Because they say to you, "You devour men and bereave your nation of children,'

14. therefore you shall devour men no more, nor bereave your nation anymore," says the Lord GOD.

15. Nor will I let you hear the taunts of the nations anymore, nor bear the reproach of the peoples anymore, nor shall you cause your nation to stumble anymore," says the Lord GOD."'

16. Moreover the word of the LORD came to me, saying:

17. "Son of man, when the house of Israel dwelt in their own land, they defiled it by their own ways and deeds; to Me their way was like the uncleanness of a woman in her customary impurity.

18. Therefore I poured out My fury on them for the blood they had shed on the land, and for their idols with which they had defiled it.

19. So I scattered them among the nations, and they were dispersed throughout the countries; I judged them according to their ways and their deeds.

20. When they came to the nations, wherever they went, they profaned My holy name--when they said of them, "These are the people of the LORD, and yet they have gone out of His land.'

21. But I had concern for My holy name, which the house of Israel had profaned among the nations wherever they went.

22. "Therefore say to the house of Israel, "Thus says the Lord GOD: "I do not do this for your sake, O house of Israel, but for My holy name's sake, which you have profaned among the nations wherever you went.

23. And I will sanctify My great name, which has been profaned among the nations, which you have profaned in their midst; and the nations shall know that I am the LORD," says the Lord GOD, "when I am hallowed in you before their eyes.

24. For I will take you from among the nations, gather you out of all countries, and bring you into your own land.

25. Then I will sprinkle clean water on you, and you shall be clean; I will cleanse you from all your filthiness and from all your idols.

26. I will give you a new heart and put a new spirit within you; I will take the heart of stone out of your flesh and give you a heart of flesh.

27. I will put My Spirit within you and cause you to walk in My statutes, and you will keep My judgments and do them.

28. Then you shall dwell in the land that I gave to your fathers; you shall be My people, and I will be your God.

29. I will deliver you from all your uncleannesses. I will call for the grain and multiply it, and bring no famine upon you.

30. And I will multiply the fruit of your trees and the increase of your fields, so that you need never again bear the reproach of famine among the nations.

31. Then you will remember your evil ways and your deeds that were not good; and you will loathe yourselves in your own sight, for your iniquities and your abominations.

32. Not for your sake do I do this," says the Lord GOD, "let it be known to you. Be ashamed and confounded for your own ways, O house of Israel!"

33. "Thus says the Lord GOD: "On the day that I cleanse you from all your iniquities, I will also enable you to dwell in the cities, and the ruins shall be rebuilt.

34. The desolate land shall be tilled instead of lying desolate in the sight of all who pass by.

35. So they will say, "This land that was desolate has become like the garden of Eden; and the wasted, desolate, and ruined cities are now fortified and inhabited.'

36. Then the nations which are left all around you shall know that I, the LORD, have rebuilt the ruined places and planted what was desolate. I, the LORD, have spoken it, and I will do it."

37. "Thus says the Lord GOD: "I will also let the house of Israel inquire of Me to do this for them: I will increase their men like a flock.

38. Like a flock offered as holy sacrifices, like the flock at Jerusalem on its feast days, so shall the ruined cities be filled with flocks of men. Then they shall know that I am the LORD.""'

## Chapter 37

1. The hand of the LORD came upon me and brought me out in the Spirit of the LORD, and set me down in the midst of the valley; and it was full of bones.

2. Then He caused me to pass by them all around, and behold, there were very many in the open valley; and indeed they were very dry.

3. And He said to me, "Son of man, can these bones live?" So I answered, "O Lord GOD, You know."

4. Again He said to me, "Prophesy to these bones, and say to them, "O dry bones, hear the word of the LORD!

5. Thus says the Lord GOD to these bones: "Surely I will cause breath to enter into you, and you shall live.

6. I will put sinews on you and bring flesh upon you, cover you with skin and put breath in you; and you shall live. Then you shall know that I am the LORD.""'

7. So I prophesied as I was commanded; and as I prophesied, there was a noise, and suddenly a rattling; and the bones came together, bone to bone.

8. Indeed, as I looked, the sinews and the flesh came upon them, and the skin covered them over; but there was no breath in them.

9. Also He said to me, "Prophesy to the breath, prophesy, son of man, and say to the breath, "Thus says the Lord GOD: "Come from the four winds, O breath, and breathe on these slain, that they may live.""'

10. So I prophesied as He commanded me, and breath came into them, and they lived, and stood upon their feet, an exceedingly great army.

11. Then He said to me, "Son of man, these bones are the whole house of Israel. They indeed say, "Our bones are dry, our hope is lost, and we ourselves are cut off!'

12. Therefore prophesy and say to them, "Thus says the Lord GOD: "Behold, O My people, I will open your graves and cause you to come up from your graves, and bring you into the land of Israel.

13. Then you shall know that I am the LORD, when I have opened your graves, O My people, and brought you up from your graves.

14. I will put My Spirit in you, and you shall live, and I will place you in your own land. Then you shall know that I, the LORD, have spoken it and performed it," says the LORD."'

15. Again the word of the LORD came to me, saying,

16. "As for you, son of man, take a stick for yourself and write on it: "For Judah and for the children of Israel, his companions.' Then take another stick and write on it, "For Joseph, the stick of Ephraim, and for all the house of Israel, his companions.'

17. Then join them one to another for yourself into one stick, and they will become one in your hand.

18. "And when the children of your people speak to you, saying, "Will you not show us what you mean by these?'--

19. say to them, "Thus says the Lord GOD: "Surely I will take the stick of Joseph, which is in the hand of Ephraim, and the tribes of Israel, his companions; and I will join them with it, with the stick of Judah, and make them one stick, and they will be one in My hand."'

20. And the sticks on which you write will be in your hand before their eyes.

21. "Then say to them, "Thus says the Lord GOD: "Surely I will take the children of Israel from among the nations, wherever they have gone, and will gather them from every side and bring them into their own land;

22. and I will make them one nation in the land, on the mountains of Israel; and one king shall be king over them all; they shall no longer be two nations, nor shall they ever be divided into two kingdoms again.

23. They shall not defile themselves anymore with their idols, nor with their detestable things, nor with any of their transgressions; but I will deliver them from all their dwelling places in which they have sinned, and will cleanse them. Then they shall be My people, and I will be their God.

24. "David My servant shall be king over them, and they shall all have one shepherd; they shall also walk in My judgments and observe My statutes, and do them.

25. Then they shall dwell in the land that I have given to Jacob My servant, where your fathers dwelt; and they shall dwell there, they, their children, and their children's children, forever; and My servant David shall be their prince forever.

26. Moreover I will make a covenant of peace with them, and it shall be an everlasting covenant with them; I will establish them and multiply them, and I will set My sanctuary in their midst forevermore.

27. My tabernacle also shall be with them; indeed I will be their God, and they shall be My people.

28. The nations also will know that I, the LORD, sanctify Israel, when My sanctuary is in their midst forevermore.""'

## Chapter 38

1. Now the word of the LORD came to me, saying,

2. "Son of man, set your face against Gog, of the land of Magog, the prince of Rosh, Meshech, and Tubal, and prophesy against him,

3. and say, "Thus says the Lord GOD: "Behold, I am against you, O Gog, the prince of Rosh, Meshech, and Tubal.

4. I will turn you around, put hooks into your jaws, and lead you out, with all your army, horses, and horsemen, all splendidly clothed, a great company with bucklers and shields, all of them handling swords.

5. Persia, Ethiopia, and Libya are with them, all of them with shield and helmet;

6. Gomer and all its troops; the house of Togarmah from the far north and all its troops--many people are with you.

7. "Prepare yourself and be ready, you and all your companies that are gathered about you; and be a guard for them.

8. After many days you will be visited. In the latter years you will come into the land of those brought back from the sword and gathered from many people on the mountains of Israel, which had long been desolate; they were brought out of the nations, and now all of them dwell safely.

9. You will ascend, coming like a storm, covering the land like a cloud, you and all your troops and many peoples with you."

10. "Thus says the Lord GOD: "On that day it shall come to pass that thoughts will arise in your mind, and you will make an evil plan:

11. You will say, "I will go up against a land of unwalled villages; I will go to a peaceful people, who dwell safely, all of them dwelling without walls, and having neither bars nor gates'--

12. to take plunder and to take booty, to stretch out your hand against the waste places that are again inhabited, and against a people gathered from the nations, who have acquired livestock and goods, who dwell in the midst of the land.

13. Sheba, Dedan, the merchants of Tarshish, and all their young lions will say to you, "Have you come to take plunder? Have you gathered your army to take booty, to carry away silver and gold, to take away livestock and goods, to take great plunder?""

14. "Therefore, son of man, prophesy and say to Gog, "Thus says the Lord GOD: "On that day when My people Israel dwell safely, will you not know it?

15. Then you will come from your place out of the far north, you and many peoples with you, all of them riding on horses, a great company and a mighty army.

16. You will come up against My people Israel like a cloud, to cover the land. It will be in the latter days that I will bring you against My land, so that the nations may know Me, when I am hallowed in you, O Gog, before their eyes."

17. Thus says the Lord GOD: "Are you he of whom I have spoken in former days by My servants the prophets of Israel, who prophesied for years in those days that I would bring you against them?

18. "And it will come to pass at the same time, when Gog comes against the land of Israel," says the Lord GOD, "that My fury will show in My face.

19. For in My jealousy and in the fire of My wrath I have spoken: "Surely in that day there shall be a great earthquake in the land of Israel,

20. so that the fish of the sea, the birds of the heavens, the beasts of the field, all creeping things that creep on the earth, and all men who are on the face of the earth shall shake at My presence. The mountains shall be thrown down, the steep places shall fall, and every wall shall fall to the ground.'

21. I will call for a sword against Gog throughout all My mountains," says the Lord GOD. "Every man's sword will be against his brother.

22. And I will bring him to judgment with pestilence and bloodshed; I will rain down on him, on his troops, and on the many peoples who are with him, flooding rain, great hailstones, fire, and brimstone.

23. Thus I will magnify Myself and sanctify Myself, and I will be known in the eyes of many nations. Then they shall know that I am the LORD."'

## Chapter 39

1. "And you, son of man, prophesy against Gog, and say, "Thus says the Lord GOD: "Behold, I am against you, O Gog, the prince of Rosh, Meshech, and Tubal;

2. and I will turn you around and lead you on, bringing you up from the far north, and bring you against the mountains of Israel.

3. Then I will knock the bow out of your left hand, and cause the arrows to fall out of your right hand.

4. You shall fall upon the mountains of Israel, you and all your troops and the peoples who are with you; I will give you to birds of prey of every sort and to the beasts of the field to be devoured.

5. You shall fall on the open field; for I have spoken," says the Lord GOD.

6. "And I will send fire on Magog and on those who live in security in the coastlands. Then they shall know that I am the LORD.

7. So I will make My holy name known in the midst of My people Israel, and I will not let them profane My holy name anymore. Then the nations shall know that I am the LORD, the Holy One in Israel.

8. Surely it is coming, and it shall be done," says the Lord GOD. "This is the day of which I have spoken.

9. "Then those who dwell in the cities of Israel will go out and set on fire and burn the weapons, both the shields and bucklers, the bows and arrows, the javelins and spears; and they will make fires with them for seven years.

10. They will not take wood from the field nor cut down any from the forests, because they will make fires with the weapons; and they will plunder those who plundered them, and pillage those who pillaged them," says the Lord GOD.

11. "It will come to pass in that day that I will give Gog a burial place there in Israel, the valley of those who pass by east of the sea; and it will obstruct travelers, because there they will bury Gog and all his multitude. Therefore they will call it the Valley of Hamon Gog.

12. For seven months the house of Israel will be burying them, in order to cleanse the land.

13. Indeed all the people of the land will be burying, and they will gain renown for it on the day that I am glorified," says the Lord GOD.

14. "They will set apart men regularly employed, with the help of a search party, to pass through the land and bury those bodies remaining on the ground, in order to cleanse it. At the end of seven months they will make a search.

15. The search party will pass through the land; and when anyone sees a man's bone, he shall set up a marker by it, till the buriers have buried it in the Valley of Hamon Gog.

16. The name of the city will also be Hamonah. Thus they shall cleanse the land."'

17. "And as for you, son of man, thus says the Lord GOD, "Speak to every sort of bird and to every beast of the field: "Assemble yourselves and come; Gather together from all sides to My sacrificial meal Which I am sacrificing for you, A great sacrificial meal on the mountains of Israel, That you may eat flesh and drink blood.

18. You shall eat the flesh of the mighty, Drink the blood of the princes of the earth, Of rams and lambs, Of goats and bulls, All of them fatlings of Bashan.

19. You shall eat fat till you are full, And drink blood till you are drunk, At My sacrificial meal Which I am sacrificing for you.

20. You shall be filled at My table With horses and riders, With mighty men And with all the men of war," says the Lord GOD.

21. "I will set My glory among the nations; all the nations shall see My judgment which I have executed, and My hand which I have laid on them.

22. So the house of Israel shall know that I am the LORD their God from that day forward.

23. The Gentiles shall know that the house of Israel went into captivity for their iniquity; because they were unfaithful to Me, therefore I hid My face from them. I gave them into the hand of their enemies, and they all fell by the sword.

24. According to their uncleanness and according to their transgressions I have dealt with them, and hidden My face from them."'

25. "Therefore thus says the Lord GOD: "Now I will bring back the captives of Jacob, and have mercy on the whole house of Israel; and I will be jealous for My holy name--

26. after they have borne their shame, and all their unfaithfulness in which they were unfaithful to Me, when they dwelt safely in their own land and no one made them afraid.

27. When I have brought them back from the peoples and gathered them out of their enemies' lands, and I am hallowed in them in the sight of many nations,

28. then they shall know that I am the LORD their God, who sent them into captivity among the nations, but also brought them back to their land, and left none of them captive any longer.

29. And I will not hide My face from them anymore; for I shall have poured out My Spirit on the house of Israel,' says the Lord GOD."

## Chapter 40

1. In the twenty-fifth year of our captivity, at the beginning of the year, on the tenth day of the month, in the fourteenth year after the city was captured, on the very same day the hand of the LORD was upon me; and He took me there.

2. In the visions of God He took me into the land of Israel and set me on a very high mountain; on it toward the south was something like the structure of a city.

3. He took me there, and behold, there was a man whose appearance was like the appearance of bronze. He had a line of flax and a measuring rod in his hand, and he stood in the gateway.

4. And the man said to me, "Son of man, look with your eyes and hear with your ears, and fix your mind on everything I show you; for you were brought here so that I might show them to you. Declare to the house of Israel everything you see."

5. Now there was a wall all around the outside of the temple. In the man's hand was a measuring rod six cubits long, each being a cubit and a handbreadth; and he measured the width of the wall structure, one rod; and the height, one rod.

6. Then he went to the gateway which faced east; and he went up its stairs and measured the threshold of the gateway, which was one rod wide, and the other threshold was one rod wide.

7. Each gate chamber was one rod long and one rod wide; between the gate chambers was a space of five cubits; and the threshold of the gateway by the vestibule of the inside gate was one rod.

8. He also measured the vestibule of the inside gate, one rod.

9. Then he measured the vestibule of the gateway, eight cubits; and the gateposts, two cubits. The vestibule of the gate was on the inside.

10. In the eastern gateway were three gate chambers on one side and three on the other; the three were all the same size; also the gateposts were of the same size on this side and that side.

11. He measured the width of the entrance to the gateway, ten cubits; and the length of the gate, thirteen cubits.

12. There was a space in front of the gate chambers, one cubit on this side and one cubit on that side; the gate chambers were six cubits on this side and six cubits on that side.

13. Then he measured the gateway from the roof of one gate chamber to the roof of the other; the width was twenty-five cubits, as door faces door.

14. He measured the gateposts, sixty cubits high, and the court all around the gateway extended to the gatepost.

15. From the front of the entrance gate to the front of the vestibule of the inner gate was fifty cubits.

16. There were beveled window frames in the gate chambers and in their intervening archways on the inside of the gateway all around, and likewise in the vestibules. There were windows all around on the inside. And on each gatepost were palm trees.

17. Then he brought me into the outer court; and there were chambers and a pavement made all around the court; thirty chambers faced the pavement.

18. The pavement was by the side of the gateways, corresponding to the length of the gateways; this was the lower pavement.

19. Then he measured the width from the front of the lower gateway to the front of the inner court exterior, one hundred cubits toward the east and the north.

20. On the outer court was also a gateway facing north, and he measured its length and its width.

21. Its gate chambers, three on this side and three on that side, its gateposts and its archways, had the same measurements as the first gate; its length was fifty cubits and its width twenty-five cubits.

22. Its windows and those of its archways, and also its palm trees, had the same measurements as the gateway facing east; it was ascended by seven steps, and its archway was in front of it.

23. A gate of the inner court was opposite the northern gateway, just as the eastern gateway; and he measured from gateway to gateway, one hundred cubits.

24. After that he brought me toward the south, and there a gateway was facing south; and he measured its gateposts and archways according to these same measurements.

25. There were windows in it and in its archways all around like those windows; its length was fifty cubits and its width twenty-five cubits.

26. Seven steps led up to it, and its archway was in front of them; and it had palm trees on its gateposts, one on this side and one on that side.

27. There was also a gateway on the inner court, facing south; and he measured from gateway to gateway toward the south, one hundred cubits.

28. Then he brought me to the inner court through the southern gateway; he measured the southern gateway according to these same measurements.

29. Also its gate chambers, its gateposts, and its archways were according to these same measurements; there were windows in it and in its archways all around; it was fifty cubits long and twenty-five cubits wide.

30. There were archways all around, twenty-five cubits long and five cubits wide.

31. Its archways faced the outer court, palm trees were on its gateposts, and going up to it were eight steps.

32. And he brought me into the inner court facing east; he measured the gateway according to these same measurements.

33. Also its gate chambers, its gateposts, and its archways were according to these same measurements; and there were windows in it and in its archways all around; it was fifty cubits long and twenty-five cubits wide.

34. Its archways faced the outer court, and palm trees were on its gateposts on this side and on that side; and going up to it were eight steps.

35. Then he brought me to the north gateway and measured it according to these same measurements--

36. also its gate chambers, its gateposts, and its archways. It had windows all around; its length was fifty cubits and its width twenty-five cubits.

37. Its gateposts faced the outer court, palm trees were on its gateposts on this side and on that side, and going up to it were eight steps.

38. There was a chamber and its entrance by the gateposts of the gateway, where they washed the burnt offering.

39. In the vestibule of the gateway were two tables on this side and two tables on that side, on which to slay the burnt offering, the sin offering, and the trespass offering.

40. At the outer side of the vestibule, as one goes up to the entrance of the northern gateway, were two tables; and on the other side of the vestibule of the gateway were two tables.

41. Four tables were on this side and four tables on that side, by the side of the gateway, eight tables on which they slaughtered the sacrifices.

42. There were also four tables of hewn stone for the burnt offering, one cubit and a half long, one cubit and a half wide, and one cubit high; on these they laid the instruments with which they slaughtered the burnt offering and the sacrifice.

43. Inside were hooks, a handbreadth wide, fastened all around; and the flesh of the sacrifices was on the tables.

44. Outside the inner gate were the chambers for the singers in the inner court, one facing south at the side of the northern gateway, and the other facing north at the side of the southern gateway.

45. Then he said to me, "This chamber which faces south is for the priests who have charge of the temple.

46. The chamber which faces north is for the priests who have charge of the altar; these are the sons of Zadok, from the sons of Levi, who come near the LORD to minister to Him."

47. And he measured the court, one hundred cubits long and one hundred cubits wide, foursquare. The altar was in front of the temple.

48. Then he brought me to the vestibule of the temple and measured the doorposts of the vestibule, five cubits on this side and five cubits on that side; and the width of the gateway was three cubits on this side and three cubits on that side.

49. The length of the vestibule was twenty cubits, and the width eleven cubits; and by the steps which led up to it there were pillars by the doorposts, one on this side and another on that side.

## Chapter 41

1. Then he brought me into the sanctuary and measured the doorposts, six cubits wide on one side and six cubits wide on the other side--the width of the tabernacle.

2. The width of the entryway was ten cubits, and the side walls of the entrance were five cubits on this side and five cubits on the other side; and he measured its length, forty cubits, and its width, twenty cubits.

3. Also he went inside and measured the doorposts, two cubits; and the entrance, six cubits high; and the width of the entrance, seven cubits.

4. He measured the length, twenty cubits; and the width, twenty cubits, beyond the sanctuary; and he said to me, "This is the Most Holy Place."

5. Next, he measured the wall of the temple, six cubits. The width of each side chamber all around the temple was four cubits on every side.

6. The side chambers were in three stories, one above the other, thirty chambers in each story; they rested on ledges which were for the side chambers all around, that they might be supported, but not fastened to the wall of the temple.

7. As one went up from story to story, the side chambers became wider all around, because their supporting ledges in the wall of the temple ascended like steps; therefore the width of the structure increased as one went up from the lowest story to the highest by way of the middle one.

8. I also saw an elevation all around the temple; it was the foundation of the side chambers, a full rod, that is, six cubits high.

9. The thickness of the outer wall of the side chambers was five cubits, and so also the remaining terrace by the place of the side chambers of the temple.

10. And between it and the wall chambers was a width of twenty cubits all around the temple on every side.

11. The doors of the side chambers opened on the terrace, one door toward the north and another toward the south; and the width of the terrace was five cubits all around.

12. The building that faced the separating courtyard at its western end was seventy cubits wide; the wall of the building was five cubits thick all around, and its length ninety cubits.

13. So he measured the temple, one hundred cubits long; and the separating courtyard with the building and its walls was one hundred cubits long;

14. also the width of the eastern face of the temple, including the separating courtyard, was one hundred cubits.

15. He measured the length of the building behind it, facing the separating courtyard, with its galleries on the one side and on the other side, one hundred cubits, as well as the inner temple and the porches of the court,

16. their doorposts and the beveled window frames. And the galleries all around their three stories opposite the threshold were paneled with wood from the ground to the windows--the windows were covered--

17. from the space above the door, even to the inner room, as well as outside, and on every wall all around, inside and outside, by measure.

18. And it was made with cherubim and palm trees, a palm tree between cherub and cherub. Each cherub had two faces,

19. so that the face of a man was toward a palm tree on one side, and the face of a young lion toward a palm tree on the other side; thus it was made throughout the temple all around.

20. From the floor to the space above the door, and on the wall of the sanctuary, cherubim and palm trees were carved.

21. The doorposts of the temple were square, as was the front of the sanctuary; their appearance was similar.

22. The altar was of wood, three cubits high, and its length two cubits. Its corners, its length, and its sides were of wood; and he said to me, "This is the table that is before the LORD."

23. The temple and the sanctuary had two doors.

24. The doors had two panels apiece, two folding panels: two panels for one door and two panels for the other door.

25. Cherubim and palm trees were carved on the doors of the temple just as they were carved on the walls. A wooden canopy was on the front of the vestibule outside.

26. There were beveled window frames and palm trees on one side and on the other, on the sides of the vestibule--also on the side chambers of the temple and on the canopies.

## Chapter 42

1. Then he brought me out into the outer court, by the way toward the north; and he brought me into the chamber which was opposite the separating courtyard, and which was opposite the building toward the north.

2. Facing the length, which was one hundred cubits (the width was fifty cubits), was the north door.

3. Opposite the inner court of twenty cubits, and opposite the pavement of the outer court, was gallery against gallery in three stories.

4. In front of the chambers, toward the inside, was a walk ten cubits wide, at a distance of one cubit; and their doors faced north.

5. Now the upper chambers were shorter, because the galleries took away space from them more than from the lower and middle stories of the building.

6. For they were in three stories and did not have pillars like the pillars of the courts; therefore the upper level was shortened more than the lower and middle levels from the ground up.

7. And a wall which was outside ran parallel to the chambers, at the front of the chambers, toward the outer court; its length was fifty cubits.

8. The length of the chambers toward the outer court was fifty cubits, whereas that facing the temple was one hundred cubits.

9. At the lower chambers was the entrance on the east side, as one goes into them from the outer court.

10. Also there were chambers in the thickness of the wall of the court toward the east, opposite the separating courtyard and opposite the building.

11. There was a walk in front of them also, and their appearance was like the chambers which were toward the north; they were as long and as wide as the others, and all their exits and entrances were according to plan.

12. And corresponding to the doors of the chambers that were facing south, as one enters them, there was a door in front of the walk, the way directly in front of the wall toward the east.

13. Then he said to me, "The north chambers and the south chambers, which are opposite the separating courtyard, are the holy chambers where the priests who approach the LORD shall eat the most holy offerings. There they shall lay the most holy offerings--the grain offering, the sin offering, and the trespass offering--for the place is holy.

14. When the priests enter them, they shall not go out of the holy chamber into the outer court; but there they shall leave their garments in which they minister, for they are holy. They shall put on other garments; then they may approach that which is for the people."

15. Now when he had finished measuring the inner temple, he brought me out through the gateway that faces toward the east, and measured it all around.

16. He measured the east side with the measuring rod, five hundred rods by the measuring rod all around.

17. He measured the north side, five hundred rods by the measuring rod all around.

18. He measured the south side, five hundred rods by the measuring rod.

19. He came around to the west side and measured five hundred rods by the measuring rod.

20. He measured it on the four sides; it had a wall all around, five hundred cubits long and five hundred wide, to separate the holy areas from the common.

## Chapter 43

1. Afterward he brought me to the gate, the gate that faces toward the east.

2. And behold, the glory of the God of Israel came from the way of the east. His voice was like the sound of many waters; and the earth shone with His glory.

3. It was like the appearance of the vision which I saw--like the vision which I saw when I came to destroy the city. The visions were like the vision which I saw by the River Chebar; and I fell on my face.

4. And the glory of the LORD came into the temple by way of the gate which faces toward the east.

5. The Spirit lifted me up and brought me into the inner court; and behold, the glory of the LORD filled the temple.

6. Then I heard Him speaking to me from the temple, while a man stood beside me.

7. And He said to me, "Son of man, this is the place of My throne and the place of the soles of My feet, where I will dwell in the midst of the children of Israel forever. No more shall the house of Israel defile My holy name, they nor their kings, by their harlotry or with the carcasses of their kings on their high places.

8. When they set their threshold by My threshold, and their doorpost by My doorpost, with a wall between them and Me, they defiled My holy name by the abominations which they committed; therefore I have consumed them in My anger.

9. Now let them put their harlotry and the carcasses of their kings far away from Me, and I will dwell in their midst forever.

10. "Son of man, describe the temple to the house of Israel, that they may be ashamed of their iniquities; and let them measure the pattern.

11. And if they are ashamed of all that they have done, make known to them the design of the temple and its arrangement, its exits and its entrances, its entire design and all its ordinances, all its forms and all its laws. Write it down in their sight, so that they may keep its whole design and all its ordinances, and perform them.

12. This is the law of the temple: The whole area surrounding the mountaintop is most holy. Behold, this is the law of the temple.

13. "These are the measurements of the altar in cubits (the cubit is one cubit and a handbreadth): the base one cubit high and one cubit wide, with a rim all around its edge of one span. This is the height of the altar:

14. from the base on the ground to the lower ledge, two cubits; the width of the ledge, one cubit; from the smaller ledge to the larger ledge, four cubits; and the width of the ledge, one cubit.

15. The altar hearth is four cubits high, with four horns extending upward from the hearth.

16. The altar hearth is twelve cubits long, twelve wide, square at its four corners;

17. the ledge, fourteen cubits long and fourteen wide on its four sides, with a rim of half a cubit around it; its base, one cubit all around; and its steps face toward the east."

18. And He said to me, "Son of man, thus says the Lord GOD: "These are the ordinances for the altar on the day when it is made, for sacrificing burnt offerings on it, and for sprinkling blood on it.

19. You shall give a young bull for a sin offering to the priests, the Levites, who are of the seed of Zadok, who approach Me to minister to Me,' says the Lord GOD.

20. You shall take some of its blood and put it on the four horns of the altar, on the four corners of the ledge, and on the rim around it; thus you shall cleanse it and make atonement for it.

21. Then you shall also take the bull of the sin offering, and burn it in the appointed place of the temple, outside the sanctuary.

22. On the second day you shall offer a kid of the goats without blemish for a sin offering; and they shall cleanse the altar, as they cleansed it with the bull.

23. When you have finished cleansing it, you shall offer a young bull without blemish, and a ram from the flock without blemish.

24. When you offer them before the LORD, the priests shall throw salt on them, and they will offer them up as a burnt offering to the LORD.

25. Every day for seven days you shall prepare a goat for a sin offering; they shall also prepare a young bull and a ram from the flock, both without blemish.

26. Seven days they shall make atonement for the altar and purify it, and so consecrate it.

27. When these days are over it shall be, on the eighth day and thereafter, that the priests shall offer your burnt offerings and your peace offerings on the altar; and I will accept you,' says the Lord GOD."

## Chapter 44

1. Then He brought me back to the outer gate of the sanctuary which faces toward the east, but it was shut.

2. And the LORD said to me, "This gate shall be shut; it shall not be opened, and no man shall enter by it, because the LORD God of Israel has entered by it; therefore it shall be shut.

3. As for the prince, because he is the prince, he may sit in it to eat bread before the LORD; he shall enter by way of the vestibule of the gateway, and go out the same way."

4. Also He brought me by way of the north gate to the front of the temple; so I looked, and behold, the glory of the LORD filled the house of the LORD; and I fell on my face.

5. And the LORD said to me, "Son of man, mark well, see with your eyes and hear with your ears, all that I say to you concerning all the ordinances of the house of the LORD and all its laws. Mark well who may enter the house and all who go out from the sanctuary.

6. "Now say to the rebellious, to the house of Israel, "Thus says the Lord GOD: "O house of Israel, let Us have no more of all your abominations.

7. When you brought in foreigners, uncircumcised in heart and uncircumcised in flesh, to be in My sanctuary to defile it--My house--and when you offered My food, the fat and the blood, then they broke My covenant because of all your abominations.

8. And you have not kept charge of My holy things, but you have set others to keep charge of My sanctuary for you."

9. Thus says the Lord GOD: "No foreigner, uncircumcised in heart or uncircumcised in flesh, shall enter My sanctuary, including any foreigner who is among the children of Israel.

10. "And the Levites who went far from Me, when Israel went astray, who strayed away from Me after their idols, they shall bear their iniquity.

11. Yet they shall be ministers in My sanctuary, as gatekeepers of the house and ministers of the house; they shall slay the burnt offering and the sacrifice for the people, and they shall stand before them to minister to them.

12. Because they ministered to them before their idols and caused the house of Israel to fall into iniquity, therefore I have raised My hand in an oath against them," says the Lord GOD, "that they shall bear their iniquity.

13. And they shall not come near Me to minister to Me as priest, nor come near any of My holy things, nor into the Most Holy Place; but they shall bear their shame and their abominations which they have committed.

14. Nevertheless I will make them keep charge of the temple, for all its work, and for all that has to be done in it.

15. "But the priests, the Levites, the sons of Zadok, who kept charge of My sanctuary when the children of Israel went astray from Me, they shall come near Me to minister to Me; and they shall stand before Me to offer to Me the fat and the blood," says the Lord GOD.

16. "They shall enter My sanctuary, and they shall come near My table to minister to Me, and they shall keep My charge.

17. And it shall be, whenever they enter the gates of the inner court, that they shall put on linen garments; no wool shall come upon them while they minister within the gates of the inner court or within the house.

18. They shall have linen turbans on their heads and linen trousers on their bodies; they shall not clothe themselves with anything that causes sweat.

19. When they go out to the outer court, to the outer court to the people, they shall take off their garments in which they have ministered, leave them in the holy chambers, and put on other garments; and in their holy garments they shall not sanctify the people.

20. "They shall neither shave their heads, nor let their hair grow long, but they shall keep their hair well trimmed.

21. No priest shall drink wine when he enters the inner court.

22. They shall not take as wife a widow or a divorced woman, but take virgins of the descendants of the house of Israel, or widows of priests.

23. "And they shall teach My people the difference between the holy and the unholy, and cause them to discern between the unclean and the clean.

24. In controversy they shall stand as judges, and judge it according to My judgments. They shall keep My laws and My statutes in all My appointed meetings, and they shall hallow My Sabbaths.

25. "They shall not defile themselves by coming near a dead person. Only for father or mother, for son or daughter, for brother or unmarried sister may they defile themselves.

26. After he is cleansed, they shall count seven days for him.

27. And on the day that he goes to the sanctuary to minister in the sanctuary, he must offer his sin offering in the inner court," says the Lord GOD.

28. "It shall be, in regard to their inheritance, that I am their inheritance. You shall give them no possession in Israel, for I am their possession.

29. They shall eat the grain offering, the sin offering, and the trespass offering; every dedicated thing in Israel shall be theirs.

30. The best of all firstfruits of any kind, and every sacrifice of any kind from all your sacrifices, shall be the priest's; also you shall give to the priest the first of your ground meal, to cause a blessing to rest on your house.

31. The priests shall not eat anything, bird or beast, that died naturally or was torn by wild beasts.

## Chapter 45

1. "Moreover, when you divide the land by lot into inheritance, you shall set apart a district for the LORD, a holy section of the land; its length shall be twenty-five thousand cubits, and the width ten thousand. It shall be holy throughout its territory all around.

2. Of this there shall be a square plot for the sanctuary, five hundred by five hundred rods, with fifty cubits around it for an open space.

3. So this is the district you shall measure: twenty-five thousand cubits long and ten thousand wide; in it shall be the sanctuary, the Most Holy Place.

4. It shall be a holy section of the land, belonging to the priests, the ministers of the sanctuary, who come near to minister to the LORD; it shall be a place for their houses and a holy place for the sanctuary.

5. An area twenty-five thousand cubits long and ten thousand wide shall belong to the Levites, the ministers of the temple; they shall have twenty chambers as a possession.

6. "You shall appoint as the property of the city an area five thousand cubits wide and twenty-five thousand long, adjacent to the district of the holy section; it shall belong to the whole house of Israel.

7. "The prince shall have a section on one side and the other of the holy district and the city's property; and bordering on the holy district and the city's property, extending westward on the west side and eastward on the east side, the length shall be side by side with one of the tribal portions, from the west border to the east border.

8. The land shall be his possession in Israel; and My princes shall no more oppress My people, but they shall give the rest of the land to the house of Israel, according to their tribes."

9. "Thus says the Lord GOD: "Enough, O princes of Israel! Remove violence and plundering, execute justice and righteousness, and stop dispossessing My people," says the Lord GOD.

10. "You shall have honest scales, an honest ephah, and an honest bath.

11. The ephah and the bath shall be of the same measure, so that the bath contains one-tenth of a homer, and the ephah one-tenth of a homer; their measure shall be according to the homer.

12. The shekel shall be twenty gerahs; twenty shekels, twenty-five shekels, and fifteen shekels shall be your mina.

13. "This is the offering which you shall offer: you shall give one-sixth of an ephah from a homer of wheat, and one-sixth of an ephah from a homer of barley.

14. The ordinance concerning oil, the bath of oil, is one-tenth of a bath from a kor. A kor is a homer or ten baths, for ten baths are a homer.

15. And one lamb shall be given from a flock of two hundred, from the rich pastures of Israel. These shall be for grain offerings, burnt offerings, and peace offerings, to make atonement for them," says the Lord GOD.

16. "All the people of the land shall give this offering for the prince in Israel.

17. Then it shall be the prince's part to give burnt offerings, grain offerings, and drink offerings, at the feasts, the New Moons, the Sabbaths, and at all the appointed seasons of the house of Israel. He shall prepare the sin offering, the grain offering, the burnt offering, and the peace offerings to make atonement for the house of Israel."

18. "Thus says the Lord GOD: "In the first month, on the first day of the month, you shall take a young bull without blemish and cleanse the sanctuary.

19. The priest shall take some of the blood of the sin offering and put it on the doorposts of the temple, on the four corners of the ledge of the altar, and on the gateposts of the gate of the inner court.

20. And so you shall do on the seventh day of the month for everyone who has sinned unintentionally or in ignorance. Thus you shall make atonement for the temple.

21. "In the first month, on the fourteenth day of the month, you shall observe the Passover, a feast of seven days; unleavened bread shall be eaten.

22. And on that day the prince shall prepare for himself and for all the people of the land a bull for a sin offering.

23. On the seven days of the feast he shall prepare a burnt offering to the LORD, seven bulls and seven rams without blemish, daily for seven days, and a kid of the goats daily for a sin offering.

24. And he shall prepare a grain offering of one ephah for each bull and one ephah for each ram, together with a hin of oil for each ephah.

25. "In the seventh month, on the fifteenth day of the month, at the feast, he shall do likewise for seven days, according to the sin offering, the burnt offering, the grain offering, and the oil."

## Chapter 46

1. "Thus says the Lord GOD: "The gateway of the inner court that faces toward the east shall be shut the six working days; but on the Sabbath it shall be opened, and on the day of the New Moon it shall be opened.

2. The prince shall enter by way of the vestibule of the gateway from the outside, and stand by the gatepost. The priests shall prepare his burnt offering and his peace offerings. He shall worship at the threshold of the gate. Then he shall go out, but the gate shall not be shut until evening.

3. Likewise the people of the land shall worship at the entrance to this gateway before the LORD on the Sabbaths and the New Moons.

4. The burnt offering that the prince offers to the LORD on the Sabbath day shall be six lambs without blemish, and a ram without blemish;

5. and the grain offering shall be one ephah for a ram, and the grain offering for the lambs, as much as he wants to give, as well as a hin of oil with every ephah.

6. On the day of the New Moon it shall be a young bull without blemish, six lambs, and a ram; they shall be without blemish.

7. He shall prepare a grain offering of an ephah for a bull, an ephah for a ram, as much as he wants to give for the lambs, and a hin of oil with every ephah.

8. When the prince enters, he shall go in by way of the vestibule of the gateway, and go out the same way.

9. "But when the people of the land come before the LORD on the appointed feast days, whoever enters by way of the north gate to worship shall go out by way of the south gate; and whoever enters by way of the south gate shall go out by way of the north gate. He shall not return by way of the gate through which he came, but shall go out through the opposite gate.

10. The prince shall then be in their midst. When they go in, he shall go in; and when they go out, he shall go out.

11. At the festivals and the appointed feast days the grain offering shall be an ephah for a bull, an ephah for a ram, as much as he wants to give for the lambs, and a hin of oil with every ephah.

12. "Now when the prince makes a voluntary burnt offering or voluntary peace offering to the LORD, the gate that faces toward the east shall then be opened for him; and he shall prepare his burnt offering and his peace offerings as he did on the Sabbath day. Then he shall go out, and after he goes out the gate shall be shut.

13. "You shall daily make a burnt offering to the LORD of a lamb of the first year without blemish; you shall prepare it every morning.

14. And you shall prepare a grain offering with it every morning, a sixth of an ephah, and a third of a hin of oil to moisten the fine flour. This grain offering is a perpetual ordinance, to be made regularly to the LORD.

15. Thus they shall prepare the lamb, the grain offering, and the oil, as a regular burnt offering every morning."

16. "Thus says the Lord GOD: "If the prince gives a gift of some of his inheritance to any of his sons, it shall belong to his sons; it is their possession by inheritance.

17. But if he gives a gift of some of his inheritance to one of his servants, it shall be his until the year of liberty, after which it shall return to the prince. But his inheritance shall belong to his sons; it shall become theirs.

18. Moreover the prince shall not take any of the people's inheritance by evicting them from their property; he shall provide an inheritance for his sons from his own property, so that none of My people may be scattered from his property.""'

19. Now he brought me through the entrance, which was at the side of the gate, into the holy chambers of the priests which face toward the north; and there a place was situated at their extreme western end.

20. And he said to me, "This is the place where the priests shall boil the trespass offering and the sin offering, and where they shall bake the grain offering, so that they do not bring them out into the outer court to sanctify the people."

21. Then he brought me out into the outer court and caused me to pass by the four corners of the court; and in fact, in every corner of the court there was another court.

22. In the four corners of the court were enclosed courts, forty cubits long and thirty wide; all four corners were the same size.

23. There was a row of building stones all around in them, all around the four of them; and cooking hearths were made under the rows of stones all around.

24. And he said to me, "These are the kitchens where the ministers of the temple shall boil the sacrifices of the people."

## Chapter 47

1. Then he brought me back to the door of the temple; and there was water, flowing from under the threshold of the temple toward the east, for the front of the temple faced east; the water was flowing from under the right side of the temple, south of the altar.

2. He brought me out by way of the north gate, and led me around on the outside to the outer gateway that faces east; and there was water, running out on the right side.

3. And when the man went out to the east with the line in his hand, he measured one thousand cubits, and he brought me through the waters; the water came up to my ankles.

4. Again he measured one thousand and brought me through the waters; the water came up to my knees. Again he measured one thousand and brought me through; the water came up to my waist.

5. Again he measured one thousand, and it was a river that I could not cross; for the water was too deep, water in which one must swim, a river that could not be crossed.

6. He said to me, "Son of man, have you seen this?" Then he brought me and returned me to the bank of the river.

7. When I returned, there, along the bank of the river, were very many trees on one side and the other.

8. Then he said to me: "This water flows toward the eastern region, goes down into the valley, and enters the sea. When it reaches the sea, its waters are healed.

9. And it shall be that every living thing that moves, wherever the rivers go, will live. There will be a very great multitude of fish, because these waters go there; for they will be healed, and everything will live wherever the river goes.

10. It shall be that fishermen will stand by it from En Gedi to En Eglaim; they will be places for spreading their nets. Their fish will be of the same kinds as the fish of the Great Sea, exceedingly many.

11. But its swamps and marshes will not be healed; they will be given over to salt.

12. Along the bank of the river, on this side and that, will grow all kinds of trees used for food; their leaves will not wither, and their fruit will not fail. They will bear fruit every month, because their water flows from the sanctuary. Their fruit will be for food, and their leaves for medicine."

13. Thus says the Lord GOD: "These are the borders by which you shall divide the land as an inheritance among the twelve tribes of Israel. Joseph shall have two portions.

14. You shall inherit it equally with one another; for I raised My hand in an oath to give it to your fathers, and this land shall fall to you as your inheritance.

15. "This shall be the border of the land on the north: from the Great Sea, by the road to Hethlon, as one goes to Zedad,

16. Hamath, Berothah, Sibraim (which is between the border of Damascus and the border of Hamath), to Hazar Hatticon (which is on the border of Hauran).

17. Thus the boundary shall be from the Sea to Hazar Enan, the border of Damascus; and as for the north, northward, it is the border of Hamath. This is the north side.

18. "On the east side you shall mark out the border from between Hauran and Damascus, and between Gilead and the land of Israel, along the Jordan, and along the eastern side of the sea. This is the east side.

19. "The south side, toward the South, shall be from Tamar to the waters of Meribah by Kadesh, along the brook to the Great Sea. This is the south side, toward the South.

20. "The west side shall be the Great Sea, from the southern boundary until one comes to a point opposite Hamath. This is the west side.

21. "Thus you shall divide this land among yourselves according to the tribes of Israel.

22. It shall be that you will divide it by lot as an inheritance for yourselves, and for the strangers who dwell among you and who bear children among you. They shall be to you as native-born among the children of Israel; they shall have an inheritance with you among the tribes of Israel.

23. And it shall be that in whatever tribe the stranger dwells, there you shall give him his inheritance," says the Lord GOD.

## Chapter 48

1. "Now these are the names of the tribes: From the northern border along the road to Hethlon at the entrance of Hamath, to Hazar Enan, the border of Damascus northward, in the direction of Hamath, there shall be one section for Dan from its east to its west side;

2. by the border of Dan, from the east side to the west, one section for Asher;

3. by the border of Asher, from the east side to the west, one section for Naphtali;

4. by the border of Naphtali, from the east side to the west, one section for Manasseh;

5. by the border of Manasseh, from the east side to the west, one section for Ephraim;

6. by the border of Ephraim, from the east side to the west, one section for Reuben;

7. by the border of Reuben, from the east side to the west, one section for Judah;

8. by the border of Judah, from the east side to the west, shall be the district which you shall set apart, twenty-five thousand cubits in width, and in length the same as one of the other portions, from the east side to the west, with the sanctuary in the center.

9. "The district that you shall set apart for the LORD shall be twenty-five thousand cubits in length and ten thousand in width.

10. To these--to the priests--the holy district shall belong: on the north twenty-five thousand cubits in length, on the west ten thousand in width, on the east ten thousand in width, and on the south twenty-five thousand in length. The sanctuary of the LORD shall be in the center.

11. It shall be for the priests of the sons of Zadok, who are sanctified, who have kept My charge, who did not go astray when the children of Israel went astray, as the Levites went astray.

12. And this district of land that is set apart shall be to them a thing most holy by the border of the Levites.

13. "Opposite the border of the priests, the Levites shall have an area twenty-five thousand cubits in length and ten thousand in width; its entire length shall be twenty-five thousand and its width ten thousand.

14. And they shall not sell or exchange any of it; they may not alienate this best part of the land, for it is holy to the LORD.

15. "The five thousand cubits in width that remain, along the edge of the twenty-five thousand, shall be for general use by the city, for dwellings and common-land; and the city shall be in the center.

16. These shall be its measurements: the north side four thousand five hundred cubits, the south side four thousand five hundred, the east side four thousand five hundred, and the west side four thousand five hundred.

17. The common-land of the city shall be: to the north two hundred and fifty cubits, to the south two hundred and fifty, to the east two hundred and fifty, and to the west two hundred and fifty.

18. The rest of the length, alongside the district of the holy section, shall be ten thousand cubits to the east and ten thousand to the west. It shall be adjacent to the district of the holy section, and its produce shall be food for the workers of the city.

19. The workers of the city, from all the tribes of Israel, shall cultivate it.

20. The entire district shall be twenty-five thousand cubits by twenty-five thousand cubits, foursquare. You shall set apart the holy district with the property of the city.

21. "The rest shall belong to the prince, on one side and on the other of the holy district and of the city's property, next to the twenty-five thousand cubits of the holy district as far as the eastern border, and westward next to the twenty-five thousand as far as the western border, adjacent to the tribal portions; it shall belong to the prince. It shall be the holy district, and the sanctuary of the temple shall be in the center.

22. Moreover, apart from the possession of the Levites and the possession of the city which are in the midst of what belongs to the prince, the area between the border of Judah and the border of Benjamin shall belong to the prince.

23. "As for the rest of the tribes, from the east side to the west, Benjamin shall have one section;

24. by the border of Benjamin, from the east side to the west, Simeon shall have one section;

25. by the border of Simeon, from the east side to the west, Issachar shall have one section;

26. by the border of Issachar, from the east side to the west, Zebulun shall have one section;

27. by the border of Zebulun, from the east side to the west, Gad shall have one section;

28. by the border of Gad, on the south side, toward the South, the border shall be from Tamar to the waters of Meribah by Kadesh, along the brook to the Great Sea.

29. This is the land which you shall divide by lot as an inheritance among the tribes of Israel, and these are their portions," says the Lord GOD.

30. "These are the exits of the city. On the north side, measuring four thousand five hundred cubits

31. (the gates of the city shall be named after the tribes of Israel), the three gates northward: one gate for Reuben, one gate for Judah, and one gate for Levi;

32. on the east side, four thousand five hundred cubits, three gates: one gate for Joseph, one gate for Benjamin, and one gate for Dan;

33. on the south side, measuring four thousand five hundred cubits, three gates: one gate for Simeon, one gate for Issachar, and one gate for Zebulun;

34. on the west side, four thousand five hundred cubits with their three gates: one gate for Gad, one gate for Asher, and one gate for Naphtali.

35. All the way around shall be eighteen thousand cubits; and the name of the city from that day shall be: THE LORD IS THERE."


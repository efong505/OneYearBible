# ezra

## Chapter 1

1. Now in the first year of Cyrus king of Persia, that the word of the LORD by the mouth of Jeremiah might be fulfilled, the LORD stirred up the spirit of Cyrus king of Persia, so that he made a proclamation throughout all his kingdom, and also put it in writing, saying,

2. Thus says Cyrus king of Persia: All the kingdoms of the earth the LORD God of heaven has given me. And He has commanded me to build Him a house at Jerusalem which is in Judah.

3. Who is among you of all His people? May his God be with him, and let him go up to Jerusalem which is in Judah, and build the house of the LORD God of Israel (He is God), which is in Jerusalem.

4. And whoever is left in any place where he dwells, let the men of his place help him with silver and gold, with goods and livestock, besides the freewill offerings for the house of God which is in Jerusalem.

5. Then the heads of the fathers' houses of Judah and Benjamin, and the priests and the Levites, with all whose spirits God had moved, arose to go up and build the house of the LORD which is in Jerusalem.

6. And all those who were around them encouraged them with articles of silver and gold, with goods and livestock, and with precious things, besides all that was willingly offered.

7. King Cyrus also brought out the articles of the house of the LORD, which Nebuchadnezzar had taken from Jerusalem and put in the temple of his gods;

8. and Cyrus king of Persia brought them out by the hand of Mithredath the treasurer, and counted them out to Sheshbazzar the prince of Judah.

9. This is the number of them: thirty gold platters, one thousand silver platters, twenty-nine knives,

10. thirty gold basins, four hundred and ten silver basins of a similar kind, and one thousand other articles.

11. All the articles of gold and silver were five thousand four hundred. All these Sheshbazzar took with the captives who were brought from Babylon to Jerusalem.

## Chapter 2

1. Now these are the people of the province who came back from the captivity, of those who had been carried away, whom Nebuchadnezzar the king of Babylon had carried away to Babylon, and who returned to Jerusalem and Judah, everyone to his own city.

2. Those who came with Zerubbabel were Jeshua, Nehemiah, Seraiah, Reelaiah, Mordecai, Bilshan, Mispar, Bigvai, Rehum, and Baanah. The number of the men of the people of Israel:

3. the people of Parosh, two thousand one hundred and seventy-two;

4. the people of Shephatiah, three hundred and seventy-two;

5. the people of Arah, seven hundred and seventy-five;

6. the people of Pahath-Moab, of the people of Jeshua and Joab, two thousand eight hundred and twelve;

7. the people of Elam, one thousand two hundred and fifty-four;

8. the people of Zattu, nine hundred and forty-five;

9. the people of Zaccai, seven hundred and sixty;

10. the people of Bani, six hundred and forty-two;

11. the people of Bebai, six hundred and twenty-three;

12. the people of Azgad, one thousand two hundred and twenty-two;

13. the people of Adonikam, six hundred and sixty-six;

14. the people of Bigvai, two thousand and fifty-six;

15. the people of Adin, four hundred and fifty-four;

16. the people of Ater of Hezekiah, ninety-eight;

17. the people of Bezai, three hundred and twenty-three;

18. the people of Jorah, one hundred and twelve;

19. the people of Hashum, two hundred and twenty-three;

20. the people of Gibbar, ninety-five;

21. the people of Bethlehem, one hundred and twenty-three;

22. the men of Netophah, fifty-six;

23. the men of Anathoth, one hundred and twenty-eight;

24. the people of Azmaveth, forty-two;

25. the people of Kirjath Arim, Chephirah, and Beeroth, seven hundred and forty-three;

26. the people of Ramah and Geba, six hundred and twenty-one;

27. the men of Michmas, one hundred and twenty-two;

28. the men of Bethel and Ai, two hundred and twenty-three;

29. the people of Nebo, fifty-two;

30. the people of Magbish, one hundred and fifty-six;

31. the people of the other Elam, one thousand two hundred and fifty-four;

32. the people of Harim, three hundred and twenty;

33. the people of Lod, Hadid, and Ono, seven hundred and twenty-five;

34. the people of Jericho, three hundred and forty-five;

35. the people of Senaah, three thousand six hundred and thirty.

36. The priests: the sons of Jedaiah, of the house of Jeshua, nine hundred and seventy-three;

37. the sons of Immer, one thousand and fifty-two;

38. the sons of Pashhur, one thousand two hundred and forty-seven;

39. the sons of Harim, one thousand and seventeen.

40. The Levites: the sons of Jeshua and Kadmiel, of the sons of Hodaviah, seventy-four.

41. The singers: the sons of Asaph, one hundred and twenty-eight.

42. The sons of the gatekeepers: the sons of Shallum, the sons of Ater, the sons of Talmon, the sons of Akkub, the sons of Hatita, and the sons of Shobai, one hundred and thirty-nine in all.

43. The Nethinim: the sons of Ziha, the sons of Hasupha, the sons of Tabbaoth,

44. the sons of Keros, the sons of Siaha, the sons of Padon,

45. the sons of Lebanah, the sons of Hagabah, the sons of Akkub,

46. the sons of Hagab, the sons of Shalmai, the sons of Hanan,

47. the sons of Giddel, the sons of Gahar, the sons of Reaiah,

48. the sons of Rezin, the sons of Nekoda, the sons of Gazzam,

49. the sons of Uzza, the sons of Paseah, the sons of Besai,

50. the sons of Asnah, the sons of Meunim, the sons of Nephusim,

51. the sons of Bakbuk, the sons of Hakupha, the sons of Harhur,

52. the sons of Bazluth, the sons of Mehida, the sons of Harsha,

53. the sons of Barkos, the sons of Sisera, the sons of Tamah,

54. the sons of Neziah, and the sons of Hatipha.

55. The sons of Solomon's servants: the sons of Sotai, the sons of Sophereth, the sons of Peruda,

56. the sons of Jaala, the sons of Darkon, the sons of Giddel,

57. the sons of Shephatiah, the sons of Hattil, the sons of Pochereth of Zebaim, and the sons of Ami.

58. All the Nethinim and the children of Solomon's servants were three hundred and ninety-two.

59. And these were the ones who came up from Tel Melah, Tel Harsha, Cherub, Addan, and Immer; but they could not identify their father's house or their genealogy, whether they were of Israel:

60. the sons of Delaiah, the sons of Tobiah, and the sons of Nekoda, six hundred and fifty-two;

61. and of the sons of the priests: the sons of Habaiah, the sons of Koz, and the sons of Barzillai, who took a wife of the daughters of Barzillai the Gileadite, and was called by their name.

62. These sought their listing among those who were registered by genealogy, but they were not found; therefore they were excluded from the priesthood as defiled.

63. And the governor said to them that they should not eat of the most holy things till a priest could consult with the Urim and Thummim.

64. The whole assembly together was forty-two thousand three hundred and sixty,

65. besides their male and female servants, of whom there were seven thousand three hundred and thirty-seven; and they had two hundred men and women singers.

66. Their horses were seven hundred and thirty-six, their mules two hundred and forty-five,

67. their camels four hundred and thirty-five, and their donkeys six thousand seven hundred and twenty.

68. Some of the heads of the fathers' houses, when they came to the house of the LORD which is in Jerusalem, offered freely for the house of God, to erect it in its place:

69. According to their ability, they gave to the treasury for the work sixty-one thousand gold drachmas, five thousand minas of silver, and one hundred priestly garments.

70. So the priests and the Levites, some of the people, the singers, the gatekeepers, and the Nethinim, dwelt in their cities, and all Israel in their cities.

## Chapter 3

1. And when the seventh month had come, and the children of Israel were in the cities, the people gathered together as one man to Jerusalem.

2. Then Jeshua the son of Jozadak and his brethren the priests, and Zerubbabel the son of Shealtiel and his brethren, arose and built the altar of the God of Israel, to offer burnt offerings on it, as it is written in the Law of Moses the man of God.

3. Though fear had come upon them because of the people of those countries, they set the altar on its bases; and they offered burnt offerings on it to the LORD, both the morning and evening burnt offerings.

4. They also kept the Feast of Tabernacles, as it is written, and offered the daily burnt offerings in the number required by ordinance for each day.

5. Afterwards they offered the regular burnt offering, and those for New Moons and for all the appointed feasts of the LORD that were consecrated, and those of everyone who willingly offered a freewill offering to the LORD.

6. From the first day of the seventh month they began to offer burnt offerings to the LORD, although the foundation of the temple of the LORD had not been laid.

7. They also gave money to the masons and the carpenters, and food, drink, and oil to the people of Sidon and Tyre to bring cedar logs from Lebanon to the sea, to Joppa, according to the permission which they had from Cyrus king of Persia.

8. Now in the second month of the second year of their coming to the house of God at Jerusalem, Zerubbabel the son of Shealtiel, Jeshua the son of Jozadak, and the rest of their brethren the priests and the Levites, and all those who had come out of the captivity to Jerusalem, began work and appointed the Levites from twenty years old and above to oversee the work of the house of the LORD.

9. Then Jeshua with his sons and brothers, Kadmiel with his sons, and the sons of Judah, arose as one to oversee those working on the house of God: the sons of Henadad with their sons and their brethren the Levites.

10. When the builders laid the foundation of the temple of the LORD, the priests stood in their apparel with trumpets, and the Levites, the sons of Asaph, with cymbals, to praise the LORD, according to the ordinance of David king of Israel.

11. And they sang responsively, praising and giving thanks to the LORD: "For He is good, For His mercy endures forever toward Israel." Then all the people shouted with a great shout, when they praised the LORD, because the foundation of the house of the LORD was laid.

12. But many of the priests and Levites and heads of the fathers' houses, old men who had seen the first temple, wept with a loud voice when the foundation of this temple was laid before their eyes. Yet many shouted aloud for joy,

13. so that the people could not discern the noise of the shout of joy from the noise of the weeping of the people, for the people shouted with a loud shout, and the sound was heard afar off.

## Chapter 4

1. Now when the adversaries of Judah and Benjamin heard that the descendants of the captivity were building the temple of the LORD God of Israel,

2. they came to Zerubbabel and the heads of the fathers' houses, and said to them, "Let us build with you, for we seek your God as you do; and we have sacrificed to Him since the days of Esarhaddon king of Assyria, who brought us here."

3. But Zerubbabel and Jeshua and the rest of the heads of the fathers' houses of Israel said to them, "You may do nothing with us to build a house for our God; but we alone will build to the LORD God of Israel, as King Cyrus the king of Persia has commanded us."

4. Then the people of the land tried to discourage the people of Judah. They troubled them in building,

5. and hired counselors against them to frustrate their purpose all the days of Cyrus king of Persia, even until the reign of Darius king of Persia.

6. In the reign of Ahasuerus, in the beginning of his reign, they wrote an accusation against the inhabitants of Judah and Jerusalem.

7. In the days of Artaxerxes also, Bishlam, Mithredath, Tabel, and the rest of their companions wrote to Artaxerxes king of Persia; and the letter was written in Aramaic script, and translated into the Aramaic language.

8. Rehum the commander and Shimshai the scribe wrote a letter against Jerusalem to King Artaxerxes in this fashion:

9. From Rehum the commander, Shimshai the scribe, and the rest of their companions--representatives of the Dinaites, the Apharsathchites, the Tarpelites, the people of Persia and Erech and Babylon and Shushan, the Dehavites, the Elamites,

10. and the rest of the nations whom the great and noble Osnapper took captive and settled in the cities of Samaria and the remainder beyond the River--and so forth.

11. (This is a copy of the letter that they sent him) To King Artaxerxes from your servants, the men of the region beyond the River, and so forth:

12. Let it be known to the king that the Jews who came up from you have come to us at Jerusalem, and are building the rebellious and evil city, and are finishing its walls and repairing the foundations.

13. Let it now be known to the king that, if this city is built and the walls completed, they will not pay tax, tribute, or custom, and the king's treasury will be diminished.

14. Now because we receive support from the palace, it was not proper for us to see the king's dishonor; therefore we have sent and informed the king,

15. that search may be made in the book of the records of your fathers. And you will find in the book of the records and know that this city is a rebellious city, harmful to kings and provinces, and that they have incited sedition within the city in former times, for which cause this city was destroyed.

16. We inform the king that if this city is rebuilt and its walls are completed, the result will be that you will have no dominion beyond the River.

17. The king sent an answer: To Rehum the commander, to Shimshai the scribe, to the rest of their companions who dwell in Samaria, and to the remainder beyond the River: Peace, and so forth.

18. The letter which you sent to us has been clearly read before me.

19. And I gave the command, and a search has been made, and it was found that this city in former times has revolted against kings, and rebellion and sedition have been fostered in it.

20. There have also been mighty kings over Jerusalem, who have ruled over all the region beyond the River; and tax, tribute, and custom were paid to them.

21. Now give the command to make these men cease, that this city may not be built until the command is given by me.

22. Take heed now that you do not fail to do this. Why should damage increase to the hurt of the kings?

23. Now when the copy of King Artaxerxes' letter was read before Rehum, Shimshai the scribe, and their companions, they went up in haste to Jerusalem against the Jews, and by force of arms made them cease.

24. Thus the work of the house of God which is at Jerusalem ceased, and it was discontinued until the second year of the reign of Darius king of Persia.

## Chapter 5

1. Then the prophet Haggai and Zechariah the son of Iddo, prophets, prophesied to the Jews who were in Judah and Jerusalem, in the name of the God of Israel, who was over them.

2. So Zerubbabel the son of Shealtiel and Jeshua the son of Jozadak rose up and began to build the house of God which is in Jerusalem; and the prophets of God were with them, helping them.

3. At the same time Tattenai the governor of the region beyond the River and Shethar-Boznai and their companions came to them and spoke thus to them: "Who has commanded you to build this temple and finish this wall?"

4. Then, accordingly, we told them the names of the men who were constructing this building.

5. But the eye of their God was upon the elders of the Jews, so that they could not make them cease till a report could go to Darius. Then a written answer was returned concerning this matter.

6. This is a copy of the letter that Tattenai sent: The governor of the region beyond the River, and Shethar-Boznai, and his companions, the Persians who were in the region beyond the River, to Darius the king.

7. (They sent a letter to him, in which was written thus) To Darius the king: All peace.

8. Let it be known to the king that we went into the province of Judea, to the temple of the great God, which is being built with heavy stones, and timber is being laid in the walls; and this work goes on diligently and prospers in their hands.

9. Then we asked those elders, and spoke thus to them: "Who commanded you to build this temple and to finish these walls?"

10. We also asked them their names to inform you, that we might write the names of the men who were chief among them.

11. And thus they returned us an answer, saying: "We are the servants of the God of heaven and earth, and we are rebuilding the temple that was built many years ago, which a great king of Israel built and completed.

12. But because our fathers provoked the God of heaven to wrath, He gave them into the hand of Nebuchadnezzar king of Babylon, the Chaldean, who destroyed this temple and carried the people away to Babylon.

13. However, in the first year of Cyrus king of Babylon, King Cyrus issued a decree to build this house of God.

14. Also, the gold and silver articles of the house of God, which Nebuchadnezzar had taken from the temple that was in Jerusalem and carried into the temple of Babylon--those King Cyrus took from the temple of Babylon, and they were given to one named Sheshbazzar, whom he had made governor.

15. And he said to him, "Take these articles; go, carry them to the temple site that is in Jerusalem, and let the house of God be rebuilt on its former site.'

16. Then the same Sheshbazzar came and laid the foundation of the house of God which is in Jerusalem; but from that time even until now it has been under construction, and it is not finished."

17. Now therefore, if it seems good to the king, let a search be made in the king's treasure house, which is there in Babylon, whether it is so that a decree was issued by King Cyrus to build this house of God at Jerusalem, and let the king send us his pleasure concerning this matter.

## Chapter 6

1. Then King Darius issued a decree, and a search was made in the archives, where the treasures were stored in Babylon.

2. And at Achmetha, in the palace that is in the province of Media, a scroll was found, and in it a record was written thus:

3. In the first year of King Cyrus, King Cyrus issued a decree concerning the house of God at Jerusalem: "Let the house be rebuilt, the place where they offered sacrifices; and let the foundations of it be firmly laid, its height sixty cubits and its width sixty cubits,

4. with three rows of heavy stones and one row of new timber. Let the expenses be paid from the king's treasury.

5. Also let the gold and silver articles of the house of God, which Nebuchadnezzar took from the temple which is in Jerusalem and brought to Babylon, be restored and taken back to the temple which is in Jerusalem, each to its place; and deposit them in the house of God"--

6. Now therefore, Tattenai, governor of the region beyond the River, and Shethar-Boznai, and your companions the Persians who are beyond the River, keep yourselves far from there.

7. Let the work of this house of God alone; let the governor of the Jews and the elders of the Jews build this house of God on its site.

8. Moreover I issue a decree as to what you shall do for the elders of these Jews, for the building of this house of God: Let the cost be paid at the king's expense from taxes on the region beyond the River; this is to be given immediately to these men, so that they are not hindered.

9. And whatever they need--young bulls, rams, and lambs for the burnt offerings of the God of heaven, wheat, salt, wine, and oil, according to the request of the priests who are in Jerusalem--let it be given them day by day without fail,

10. that they may offer sacrifices of sweet aroma to the God of heaven, and pray for the life of the king and his sons.

11. Also I issue a decree that whoever alters this edict, let a timber be pulled from his house and erected, and let him be hanged on it; and let his house be made a refuse heap because of this.

12. And may the God who causes His name to dwell there destroy any king or people who put their hand to alter it, or to destroy this house of God which is in Jerusalem. I Darius issue a decree; let it be done diligently.

13. Then Tattenai, governor of the region beyond the River, Shethar-Boznai, and their companions diligently did according to what King Darius had sent.

14. So the elders of the Jews built, and they prospered through the prophesying of Haggai the prophet and Zechariah the son of Iddo. And they built and finished it, according to the commandment of the God of Israel, and according to the command of Cyrus, Darius, and Artaxerxes king of Persia.

15. Now the temple was finished on the third day of the month of Adar, which was in the sixth year of the reign of King Darius.

16. Then the children of Israel, the priests and the Levites and the rest of the descendants of the captivity, celebrated the dedication of this house of God with joy.

17. And they offered sacrifices at the dedication of this house of God, one hundred bulls, two hundred rams, four hundred lambs, and as a sin offering for all Israel twelve male goats, according to the number of the tribes of Israel.

18. They assigned the priests to their divisions and the Levites to their divisions, over the service of God in Jerusalem, as it is written in the Book of Moses.

19. And the descendants of the captivity kept the Passover on the fourteenth day of the first month.

20. For the priests and the Levites had purified themselves; all of them were ritually clean. And they slaughtered the Passover lambs for all the descendants of the captivity, for their brethren the priests, and for themselves.

21. Then the children of Israel who had returned from the captivity ate together with all who had separated themselves from the filth of the nations of the land in order to seek the LORD God of Israel.

22. And they kept the Feast of Unleavened Bread seven days with joy; for the LORD made them joyful, and turned the heart of the king of Assyria toward them, to strengthen their hands in the work of the house of God, the God of Israel.

## Chapter 7

1. Now after these things, in the reign of Artaxerxes king of Persia, Ezra the son of Seraiah, the son of Azariah, the son of Hilkiah,

2. the son of Shallum, the son of Zadok, the son of Ahitub,

3. the son of Amariah, the son of Azariah, the son of Meraioth,

4. the son of Zerahiah, the son of Uzzi, the son of Bukki,

5. the son of Abishua, the son of Phinehas, the son of Eleazar, the son of Aaron the chief priest--

6. this Ezra came up from Babylon; and he was a skilled scribe in the Law of Moses, which the LORD God of Israel had given. The king granted him all his request, according to the hand of the LORD his God upon him.

7. Some of the children of Israel, the priests, the Levites, the singers, the gatekeepers, and the Nethinim came up to Jerusalem in the seventh year of King Artaxerxes.

8. And Ezra came to Jerusalem in the fifth month, which was in the seventh year of the king.

9. On the first day of the first month he began his journey from Babylon, and on the first day of the fifth month he came to Jerusalem, according to the good hand of his God upon him.

10. For Ezra had prepared his heart to seek the Law of the LORD, and to do it, and to teach statutes and ordinances in Israel.

11. This is a copy of the letter that King Artaxerxes gave Ezra the priest, the scribe, expert in the words of the commandments of the LORD, and of His statutes to Israel:

12. Artaxerxes, king of kings, To Ezra the priest, a scribe of the Law of the God of heaven: Perfect peace, and so forth.

13. I issue a decree that all those of the people of Israel and the priests and Levites in my realm, who volunteer to go up to Jerusalem, may go with you.

14. And whereas you are being sent by the king and his seven counselors to inquire concerning Judah and Jerusalem, with regard to the Law of your God which is in your hand;

15. and whereas you are to carry the silver and gold which the king and his counselors have freely offered to the God of Israel, whose dwelling is in Jerusalem;

16. and whereas all the silver and gold that you may find in all the province of Babylon, along with the freewill offering of the people and the priests, are to be freely offered for the house of their God in Jerusalem--

17. now therefore, be careful to buy with this money bulls, rams, and lambs, with their grain offerings and their drink offerings, and offer them on the altar of the house of your God in Jerusalem.

18. And whatever seems good to you and your brethren to do with the rest of the silver and the gold, do it according to the will of your God.

19. Also the articles that are given to you for the service of the house of your God, deliver in full before the God of Jerusalem.

20. And whatever more may be needed for the house of your God, which you may have occasion to provide, pay for it from the king's treasury.

21. And I, even I, Artaxerxes the king, issue a decree to all the treasurers who are in the region beyond the River, that whatever Ezra the priest, the scribe of the Law of the God of heaven, may require of you, let it be done diligently,

22. up to one hundred talents of silver, one hundred kors of wheat, one hundred baths of wine, one hundred baths of oil, and salt without prescribed limit.

23. Whatever is commanded by the God of heaven, let it diligently be done for the house of the God of heaven. For why should there be wrath against the realm of the king and his sons?

24. Also we inform you that it shall not be lawful to impose tax, tribute, or custom on any of the priests, Levites, singers, gatekeepers, Nethinim, or servants of this house of God.

25. And you, Ezra, according to your God-given wisdom, set magistrates and judges who may judge all the people who are in the region beyond the River, all such as know the laws of your God; and teach those who do not know them.

26. Whoever will not observe the law of your God and the law of the king, let judgment be executed speedily on him, whether it be death, or banishment, or confiscation of goods, or imprisonment.

27. Blessed be the LORD God of our fathers, who has put such a thing as this in the king's heart, to beautify the house of the LORD which is in Jerusalem,

28. and has extended mercy to me before the king and his counselors, and before all the king's mighty princes. So I was encouraged, as the hand of the LORD my God was upon me; and I gathered leading men of Israel to go up with me.

## Chapter 8

1. These are the heads of their fathers' houses, and this is the genealogy of those who went up with me from Babylon, in the reign of King Artaxerxes:

2. of the sons of Phinehas, Gershom; of the sons of Ithamar, Daniel; of the sons of David, Hattush;

3. of the sons of Shecaniah, of the sons of Parosh, Zechariah; and registered with him were one hundred and fifty males;

4. of the sons of Pahath-Moab, Eliehoenai the son of Zerahiah, and with him two hundred males;

5. of the sons of Shechaniah, Ben-Jahaziel, and with him three hundred males;

6. of the sons of Adin, Ebed the son of Jonathan, and with him fifty males;

7. of the sons of Elam, Jeshaiah the son of Athaliah, and with him seventy males;

8. of the sons of Shephatiah, Zebadiah the son of Michael, and with him eighty males;

9. of the sons of Joab, Obadiah the son of Jehiel, and with him two hundred and eighteen males;

10. of the sons of Shelomith, Ben-Josiphiah, and with him one hundred and sixty males;

11. of the sons of Bebai, Zechariah the son of Bebai, and with him twenty-eight males;

12. of the sons of Azgad, Johanan the son of Hakkatan, and with him one hundred and ten males;

13. of the last sons of Adonikam, whose names are these--Eliphelet, Jeiel, and Shemaiah--and with them sixty males;

14. also of the sons of Bigvai, Uthai and Zabbud, and with them seventy males.

15. Now I gathered them by the river that flows to Ahava, and we camped there three days. And I looked among the people and the priests, and found none of the sons of Levi there.

16. Then I sent for Eliezer, Ariel, Shemaiah, Elnathan, Jarib, Elnathan, Nathan, Zechariah, and Meshullam, leaders; also for Joiarib and Elnathan, men of understanding.

17. And I gave them a command for Iddo the chief man at the place Casiphia, and I told them what they should say to Iddo and his brethren the Nethinim at the place Casiphia--that they should bring us servants for the house of our God.

18. Then, by the good hand of our God upon us, they brought us a man of understanding, of the sons of Mahli the son of Levi, the son of Israel, namely Sherebiah, with his sons and brothers, eighteen men;

19. and Hashabiah, and with him Jeshaiah of the sons of Merari, his brothers and their sons, twenty men;

20. also of the Nethinim, whom David and the leaders had appointed for the service of the Levites, two hundred and twenty Nethinim. All of them were designated by name.

21. Then I proclaimed a fast there at the river of Ahava, that we might humble ourselves before our God, to seek from Him the right way for us and our little ones and all our possessions.

22. For I was ashamed to request of the king an escort of soldiers and horsemen to help us against the enemy on the road, because we had spoken to the king, saying, "The hand of our God is upon all those for good who seek Him, but His power and His wrath are against all those who forsake Him."

23. So we fasted and entreated our God for this, and He answered our prayer.

24. And I separated twelve of the leaders of the priests--Sherebiah, Hashabiah, and ten of their brethren with them--

25. and weighed out to them the silver, the gold, and the articles, the offering for the house of our God which the king and his counselors and his princes, and all Israel who were present, had offered.

26. I weighed into their hand six hundred and fifty talents of silver, silver articles weighing one hundred talents, one hundred talents of gold,

27. twenty gold basins worth a thousand drachmas, and two vessels of fine polished bronze, precious as gold.

28. And I said to them, "You are holy to the LORD; the articles are holy also; and the silver and the gold are a freewill offering to the LORD God of your fathers.

29. Watch and keep them until you weigh them before the leaders of the priests and the Levites and heads of the fathers' houses of Israel in Jerusalem, in the chambers of the house of the LORD."

30. So the priests and the Levites received the silver and the gold and the articles by weight, to bring them to Jerusalem to the house of our God.

31. Then we departed from the river of Ahava on the twelfth day of the first month, to go to Jerusalem. And the hand of our God was upon us, and He delivered us from the hand of the enemy and from ambush along the road.

32. So we came to Jerusalem, and stayed there three days.

33. Now on the fourth day the silver and the gold and the articles were weighed in the house of our God by the hand of Meremoth the son of Uriah the priest, and with him was Eleazar the son of Phinehas; with them were the Levites, Jozabad the son of Jeshua and Noadiah the son of Binnui,

34. with the number and weight of everything. All the weight was written down at that time.

35. The children of those who had been carried away captive, who had come from the captivity, offered burnt offerings to the God of Israel: twelve bulls for all Israel, ninety-six rams, seventy-seven lambs, and twelve male goats as a sin offering. All this was a burnt offering to the LORD.

36. And they delivered the king's orders to the king's satraps and the governors in the region beyond the River. So they gave support to the people and the house of God.

## Chapter 9

1. When these things were done, the leaders came to me, saying, "The people of Israel and the priests and the Levites have not separated themselves from the peoples of the lands, with respect to the abominations of the Canaanites, the Hittites, the Perizzites, the Jebusites, the Ammonites, the Moabites, the Egyptians, and the Amorites.

2. For they have taken some of their daughters as wives for themselves and their sons, so that the holy seed is mixed with the peoples of those lands. Indeed, the hand of the leaders and rulers has been foremost in this trespass."

3. So when I heard this thing, I tore my garment and my robe, and plucked out some of the hair of my head and beard, and sat down astonished.

4. Then everyone who trembled at the words of the God of Israel assembled to me, because of the transgression of those who had been carried away captive, and I sat astonished until the evening sacrifice.

5. At the evening sacrifice I arose from my fasting; and having torn my garment and my robe, I fell on my knees and spread out my hands to the LORD my God.

6. And I said: "O my God, I am too ashamed and humiliated to lift up my face to You, my God; for our iniquities have risen higher than our heads, and our guilt has grown up to the heavens.

7. Since the days of our fathers to this day we have been very guilty, and for our iniquities we, our kings, and our priests have been delivered into the hand of the kings of the lands, to the sword, to captivity, to plunder, and to humiliation, as it is this day.

8. And now for a little while grace has been shown from the LORD our God, to leave us a remnant to escape, and to give us a peg in His holy place, that our God may enlighten our eyes and give us a measure of revival in our bondage.

9. For we were slaves. Yet our God did not forsake us in our bondage; but He extended mercy to us in the sight of the kings of Persia, to revive us, to repair the house of our God, to rebuild its ruins, and to give us a wall in Judah and Jerusalem.

10. And now, O our God, what shall we say after this? For we have forsaken Your commandments,

11. which You commanded by Your servants the prophets, saying, "The land which you are entering to possess is an unclean land, with the uncleanness of the peoples of the lands, with their abominations which have filled it from one end to another with their impurity.

12. Now therefore, do not give your daughters as wives for their sons, nor take their daughters to your sons; and never seek their peace or prosperity, that you may be strong and eat the good of the land, and leave it as an inheritance to your children forever.'

13. And after all that has come upon us for our evil deeds and for our great guilt, since You our God have punished us less than our iniquities deserve, and have given us such deliverance as this,

14. should we again break Your commandments, and join in marriage with the people committing these abominations? Would You not be angry with us until You had consumed us, so that there would be no remnant or survivor?

15. O LORD God of Israel, You are righteous, for we are left as a remnant, as it is this day. Here we are before You, in our guilt, though no one can stand before You because of this!"

## Chapter 10

1. Now while Ezra was praying, and while he was confessing, weeping, and bowing down before the house of God, a very large assembly of men, women, and children gathered to him from Israel; for the people wept very bitterly.

2. And Shechaniah the son of Jehiel, one of the sons of Elam, spoke up and said to Ezra, "We have trespassed against our God, and have taken pagan wives from the peoples of the land; yet now there is hope in Israel in spite of this.

3. Now therefore, let us make a covenant with our God to put away all these wives and those who have been born to them, according to the advice of my master and of those who tremble at the commandment of our God; and let it be done according to the law.

4. Arise, for this matter is your responsibility. We also are with you. Be of good courage, and do it."

5. Then Ezra arose, and made the leaders of the priests, the Levites, and all Israel swear an oath that they would do according to this word. So they swore an oath.

6. Then Ezra rose up from before the house of God, and went into the chamber of Jehohanan the son of Eliashib; and when he came there, he ate no bread and drank no water, for he mourned because of the guilt of those from the captivity.

7. And they issued a proclamation throughout Judah and Jerusalem to all the descendants of the captivity, that they must gather at Jerusalem,

8. and that whoever would not come within three days, according to the instructions of the leaders and elders, all his property would be confiscated, and he himself would be separated from the assembly of those from the captivity.

9. So all the men of Judah and Benjamin gathered at Jerusalem within three days. It was the ninth month, on the twentieth of the month; and all the people sat in the open square of the house of God, trembling because of this matter and because of heavy rain.

10. Then Ezra the priest stood up and said to them, "You have transgressed and have taken pagan wives, adding to the guilt of Israel.

11. Now therefore, make confession to the LORD God of your fathers, and do His will; separate yourselves from the peoples of the land, and from the pagan wives."

12. Then all the assembly answered and said with a loud voice, "Yes! As you have said, so we must do.

13. But there are many people; it is the season for heavy rain, and we are not able to stand outside. Nor is this the work of one or two days, for there are many of us who have transgressed in this matter.

14. Please, let the leaders of our entire assembly stand; and let all those in our cities who have taken pagan wives come at appointed times, together with the elders and judges of their cities, until the fierce wrath of our God is turned away from us in this matter."

15. Only Jonathan the son of Asahel and Jahaziah the son of Tikvah opposed this, and Meshullam and Shabbethai the Levite gave them support.

16. Then the descendants of the captivity did so. And Ezra the priest, with certain heads of the fathers' households, were set apart by the fathers' households, each of them by name; and they sat down on the first day of the tenth month to examine the matter.

17. By the first day of the first month they finished questioning all the men who had taken pagan wives.

18. And among the sons of the priests who had taken pagan wives the following were found of the sons of Jeshua the son of Jozadak, and his brothers: Maaseiah, Eliezer, Jarib, and Gedaliah.

19. And they gave their promise that they would put away their wives; and being guilty, they presented a ram of the flock as their trespass offering.

20. Also of the sons of Immer: Hanani and Zebadiah;

21. of the sons of Harim: Maaseiah, Elijah, Shemaiah, Jehiel, and Uzziah;

22. of the sons of Pashhur: Elioenai, Maaseiah, Ishmael, Nethanel, Jozabad, and Elasah.

23. Also of the Levites: Jozabad, Shimei, Kelaiah (the same is Kelita), Pethahiah, Judah, and Eliezer.

24. Also of the singers: Eliashib; and of the gatekeepers: Shallum, Telem, and Uri.

25. And others of Israel: of the sons of Parosh: Ramiah, Jeziah, Malchiah, Mijamin, Eleazar, Malchijah, and Benaiah;

26. of the sons of Elam: Mattaniah, Zechariah, Jehiel, Abdi, Jeremoth, and Eliah;

27. of the sons of Zattu: Elioenai, Eliashib, Mattaniah, Jeremoth, Zabad, and Aziza;

28. of the sons of Bebai: Jehohanan, Hananiah, Zabbai, and Athlai;

29. of the sons of Bani: Meshullam, Malluch, Adaiah, Jashub, Sheal, and Ramoth;

30. of the sons of Pahath-Moab: Adna, Chelal, Benaiah, Maaseiah, Mattaniah, Bezalel, Binnui, and Manasseh;

31. of the sons of Harim: Eliezer, Ishijah, Malchijah, Shemaiah, Shimeon,

32. Benjamin, Malluch, and Shemariah;

33. of the sons of Hashum: Mattenai, Mattattah, Zabad, Eliphelet, Jeremai, Manasseh, and Shimei;

34. of the sons of Bani: Maadai, Amram, Uel,

35. Benaiah, Bedeiah, Cheluh,

36. Vaniah, Meremoth, Eliashib,

37. Mattaniah, Mattenai, Jaasai,

38. Bani, Binnui, Shimei,

39. Shelemiah, Nathan, Adaiah,

40. Machnadebai, Shashai, Sharai,

41. Azarel, Shelemiah, Shemariah,

42. Shallum, Amariah, and Joseph;

43. of the sons of Nebo: Jeiel, Mattithiah, Zabad, Zebina, Jaddai, Joel, and Benaiah.

44. All these had taken pagan wives, and some of them had wives by whom they had children.


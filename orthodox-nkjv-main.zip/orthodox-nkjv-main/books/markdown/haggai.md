# haggai

## Chapter 1

1. In the second year of King Darius, in the sixth month, on the first day of the month, the word of the LORD came by Haggai the prophet to Zerubbabel the son of Shealtiel, governor of Judah, and to Joshua the son of Jehozadak, the high priest, saying,

2. "Thus speaks the LORD of hosts, saying: "This people says, "The time has not come, the time that the LORD's house should be built.""'

3. Then the word of the LORD came by Haggai the prophet, saying,

4. "Is it time for you yourselves to dwell in your paneled houses, and this temple to lie in ruins?"

5. Now therefore, thus says the LORD of hosts: "Consider your ways!

6. "You have sown much, and bring in little; You eat, but do not have enough; You drink, but you are not filled with drink; You clothe yourselves, but no one is warm; And he who earns wages, Earns wages to put into a bag with holes."

7. Thus says the LORD of hosts: "Consider your ways!

8. Go up to the mountains and bring wood and build the temple, that I may take pleasure in it and be glorified," says the LORD.

9. "You looked for much, but indeed it came to little; and when you brought it home, I blew it away. Why?" says the LORD of hosts. "Because of My house that is in ruins, while every one of you runs to his own house.

10. Therefore the heavens above you withhold the dew, and the earth withholds its fruit.

11. For I called for a drought on the land and the mountains, on the grain and the new wine and the oil, on whatever the ground brings forth, on men and livestock, and on all the labor of your hands."

12. Then Zerubbabel the son of Shealtiel, and Joshua the son of Jehozadak, the high priest, with all the remnant of the people, obeyed the voice of the LORD their God, and the words of Haggai the prophet, as the LORD their God had sent him; and the people feared the presence of the LORD.

13. Then Haggai, the LORD's messenger, spoke the LORD's message to the people, saying, "I am with you, says the LORD."

14. So the LORD stirred up the spirit of Zerubbabel the son of Shealtiel, governor of Judah, and the spirit of Joshua the son of Jehozadak, the high priest, and the spirit of all the remnant of the people; and they came and worked on the house of the LORD of hosts, their God,

15. on the twenty-fourth day of the sixth month, in the second year of King Darius.

## Chapter 2

1. In the seventh month, on the twenty-first of the month, the word of the LORD came by Haggai the prophet, saying:

2. "Speak now to Zerubbabel the son of Shealtiel, governor of Judah, and to Joshua the son of Jehozadak, the high priest, and to the remnant of the people, saying:

3. "Who is left among you who saw this temple in its former glory? And how do you see it now? In comparison with it, is this not in your eyes as nothing?

4. Yet now be strong, Zerubbabel,' says the LORD; "and be strong, Joshua, son of Jehozadak, the high priest; and be strong, all you people of the land,' says the LORD, "and work; for I am with you,' says the LORD of hosts.

5. "According to the word that I covenanted with you when you came out of Egypt, so My Spirit remains among you; do not fear!'

6. "For thus says the LORD of hosts: "Once more (it is a little while) I will shake heaven and earth, the sea and dry land;

7. and I will shake all nations, and they shall come to the Desire of All Nations, and I will fill this temple with glory,' says the LORD of hosts.

8. "The silver is Mine, and the gold is Mine,' says the LORD of hosts.

9. "The glory of this latter temple shall be greater than the former,' says the LORD of hosts. "And in this place I will give peace,' says the LORD of hosts."

10. On the twenty-fourth day of the ninth month, in the second year of Darius, the word of the LORD came by Haggai the prophet, saying,

11. "Thus says the LORD of hosts: "Now, ask the priests concerning the law, saying,

12. "If one carries holy meat in the fold of his garment, and with the edge he touches bread or stew, wine or oil, or any food, will it become holy?""' Then the priests answered and said, "No."

13. And Haggai said, "If one who is unclean because of a dead body touches any of these, will it be unclean?" So the priests answered and said, "It shall be unclean."

14. Then Haggai answered and said, ""So is this people, and so is this nation before Me,' says the LORD, "and so is every work of their hands; and what they offer there is unclean.

15. "And now, carefully consider from this day forward: from before stone was laid upon stone in the temple of the LORD--

16. since those days, when one came to a heap of twenty ephahs, there were but ten; when one came to the wine vat to draw out fifty baths from the press, there were but twenty.

17. I struck you with blight and mildew and hail in all the labors of your hands; yet you did not turn to Me,' says the LORD.

18. "Consider now from this day forward, from the twenty-fourth day of the ninth month, from the day that the foundation of the LORD's temple was laid--consider it:

19. Is the seed still in the barn? As yet the vine, the fig tree, the pomegranate, and the olive tree have not yielded fruit. But from this day I will bless you."'

20. And again the word of the LORD came to Haggai on the twenty-fourth day of the month, saying,

21. "Speak to Zerubbabel, governor of Judah, saying: "I will shake heaven and earth.

22. I will overthrow the throne of kingdoms; I will destroy the strength of the Gentile kingdoms. I will overthrow the chariots And those who ride in them; The horses and their riders shall come down, Every one by the sword of his brother.

23. "In that day,' says the LORD of hosts, "I will take you, Zerubbabel My servant, the son of Shealtiel,' says the LORD, "and will make you like a signet ring; for I have chosen you,' says the LORD of hosts."


# hebrews

## Chapter 1

1. God, who at various times and in various ways spoke in time past to the fathers by the prophets,

2. has in these last days spoken to us by His Son, whom He has appointed heir of all things, through whom also He made the worlds;

3. who being the brightness of His glory and the express image of His person, and upholding all things by the word of His power, when He had by Himself purged our sins, sat down at the right hand of the Majesty on high,

4. having become so much better than the angels, as He has by inheritance obtained a more excellent name than they.

5. For to which of the angels did He ever say: "You are My Son, Today I have begotten You"? And again: "I will be to Him a Father, And He shall be to Me a Son"?

6. But when He again brings the firstborn into the world, He says: "Let all the angels of God worship Him."

7. And of the angels He says: "Who makes His angels spirits And His ministers a flame of fire."

8. But to the Son He says: "Your throne, O God, is forever and ever; A scepter of righteousness is the scepter of Your kingdom.

9. You have loved righteousness and hated lawlessness; Therefore God, Your God, has anointed You With the oil of gladness more than Your companions."

10. And: "You, LORD, in the beginning laid the foundation of the earth, And the heavens are the work of Your hands.

11. They will perish, but You remain; And they will all grow old like a garment;

12. Like a cloak You will fold them up, And they will be changed. But You are the same, And Your years will not fail."

13. But to which of the angels has He ever said: "Sit at My right hand, Till I make Your enemies Your footstool"?

14. Are they not all ministering spirits sent forth to minister for those who will inherit salvation?

## Chapter 2

1. Therefore we must give the more earnest heed to the things we have heard, lest we drift away.

2. For if the word spoken through angels proved steadfast, and every transgression and disobedience received a just reward,

3. how shall we escape if we neglect so great a salvation, which at the first began to be spoken by the Lord, and was confirmed to us by those who heard Him,

4. God also bearing witness both with signs and wonders, with various miracles, and gifts of the Holy Spirit, according to His own will?

5. For He has not put the world to come, of which we speak, in subjection to angels.

6. But one testified in a certain place, saying: "What is man that You are mindful of him, Or the son of man that You take care of him?

7. You have made him a little lower than the angels; You have crowned him with glory and honor, And set him over the works of Your hands.

8. You have put all things in subjection under his feet." For in that He put all in subjection under him, He left nothing that is not put under him. But now we do not yet see all things put under him.

9. But we see Jesus, who was made a little lower than the angels, for the suffering of death crowned with glory and honor, that He, by the grace of God, might taste death for everyone.

10. For it was fitting for Him, for whom are all things and by whom are all things, in bringing many sons to glory, to make the captain of their salvation perfect through sufferings.

11. For both He who sanctifies and those who are being sanctified are all of one, for which reason He is not ashamed to call them brethren,

12. saying: "I will declare Your name to My brethren; In the midst of the assembly I will sing praise to You."

13. And again: "I will put My trust in Him." And again: "Here am I and the children whom God has given Me."

14. Inasmuch then as the children have partaken of flesh and blood, He Himself likewise shared in the same, that through death He might destroy him who had the power of death, that is, the devil,

15. and release those who through fear of death were all their lifetime subject to bondage.

16. For indeed He does not give aid to angels, but He does give aid to the seed of Abraham.

17. Therefore, in all things He had to be made like His brethren, that He might be a merciful and faithful High Priest in things pertaining to God, to make propitiation for the sins of the people.

18. For in that He Himself has suffered, being tempted, He is able to aid those who are tempted.

## Chapter 3

1. Therefore, holy brethren, partakers of the heavenly calling, consider the Apostle and High Priest of our confession, Christ Jesus,

2. who was faithful to Him who appointed Him, as Moses also was faithful in all His house.

3. For this One has been counted worthy of more glory than Moses, inasmuch as He who built the house has more honor than the house.

4. For every house is built by someone, but He who built all things is God.

5. And Moses indeed was faithful in all His house as a servant, for a testimony of those things which would be spoken afterward,

6. but Christ as a Son over His own house, whose house we are if we hold fast the confidence and the rejoicing of the hope firm to the end.

7. Therefore, as the Holy Spirit says: "Today, if you will hear His voice,

8. Do not harden your hearts as in the rebellion, In the day of trial in the wilderness,

9. Where your fathers tested Me, tried Me, And saw My works forty years.

10. Therefore I was angry with that generation, And said, "They always go astray in their heart, And they have not known My ways.'

11. So I swore in My wrath, "They shall not enter My rest."'

12. Beware, brethren, lest there be in any of you an evil heart of unbelief in departing from the living God;

13. but exhort one another daily, while it is called "Today," lest any of you be hardened through the deceitfulness of sin.

14. For we have become partakers of Christ if we hold the beginning of our confidence steadfast to the end,

15. while it is said: "Today, if you will hear His voice, Do not harden your hearts as in the rebellion."

16. For who, having heard, rebelled? Indeed, was it not all who came out of Egypt, led by Moses?

17. Now with whom was He angry forty years? Was it not with those who sinned, whose corpses fell in the wilderness?

18. And to whom did He swear that they would not enter His rest, but to those who did not obey?

19. So we see that they could not enter in because of unbelief.

## Chapter 4

1. Therefore, since a promise remains of entering His rest, let us fear lest any of you seem to have come short of it.

2. For indeed the gospel was preached to us as well as to them; but the word which they heard did not profit them, not being mixed with faith in those who heard it.

3. For we who have believed do enter that rest, as He has said: "So I swore in My wrath, "They shall not enter My rest,"' although the works were finished from the foundation of the world.

4. For He has spoken in a certain place of the seventh day in this way: "And God rested on the seventh day from all His works";

5. and again in this place: "They shall not enter My rest."

6. Since therefore it remains that some must enter it, and those to whom it was first preached did not enter because of disobedience,

7. again He designates a certain day, saying in David, "Today," after such a long time, as it has been said: "Today, if you will hear His voice, Do not harden your hearts."

8. For if Joshua had given them rest, then He would not afterward have spoken of another day.

9. There remains therefore a rest for the people of God.

10. For he who has entered His rest has himself also ceased from his works as God did from His.

11. Let us therefore be diligent to enter that rest, lest anyone fall according to the same example of disobedience.

12. For the word of God is living and powerful, and sharper than any two-edged sword, piercing even to the division of soul and spirit, and of joints and marrow, and is a discerner of the thoughts and intents of the heart.

13. And there is no creature hidden from His sight, but all things are naked and open to the eyes of Him to whom we must give account.

14. Seeing then that we have a great High Priest who has passed through the heavens, Jesus the Son of God, let us hold fast our confession.

15. For we do not have a High Priest who cannot sympathize with our weaknesses, but was in all points tempted as we are, yet without sin.

16. Let us therefore come boldly to the throne of grace, that we may obtain mercy and find grace to help in time of need.

## Chapter 5

1. For every high priest taken from among men is appointed for men in things pertaining to God, that he may offer both gifts and sacrifices for sins.

2. He can have compassion on those who are ignorant and going astray, since he himself is also subject to weakness.

3. Because of this he is required as for the people, so also for himself, to offer sacrifices for sins.

4. And no man takes this honor to himself, but he who is called by God, just as Aaron was.

5. So also Christ did not glorify Himself to become High Priest, but it was He who said to Him: "You are My Son, Today I have begotten You."

6. As He also says in another place: "You are a priest forever According to the order of Melchizedek";

7. who, in the days of His flesh, when He had offered up prayers and supplications, with vehement cries and tears to Him who was able to save Him from death, and was heard because of His godly fear,

8. though He was a Son, yet He learned obedience by the things which He suffered.

9. And having been perfected, He became the author of eternal salvation to all who obey Him,

10. called by God as High Priest "according to the order of Melchizedek,"

11. of whom we have much to say, and hard to explain, since you have become dull of hearing.

12. For though by this time you ought to be teachers, you need someone to teach you again the first principles of the oracles of God; and you have come to need milk and not solid food.

13. For everyone who partakes only of milk is unskilled in the word of righteousness, for he is a babe.

14. But solid food belongs to those who are of full age, that is, those who by reason of use have their senses exercised to discern both good and evil.

## Chapter 6

1. Therefore, leaving the discussion of the elementary principles of Christ, let us go on to perfection, not laying again the foundation of repentance from dead works and of faith toward God,

2. of the doctrine of baptisms, of laying on of hands, of resurrection of the dead, and of eternal judgment.

3. And this we will do if God permits.

4. For it is impossible for those who were once enlightened, and have tasted the heavenly gift, and have become partakers of the Holy Spirit,

5. and have tasted the good word of God and the powers of the age to come,

6. if they fall away, to renew them again to repentance, since they crucify again for themselves the Son of God, and put Him to an open shame.

7. For the earth which drinks in the rain that often comes upon it, and bears herbs useful for those by whom it is cultivated, receives blessing from God;

8. but if it bears thorns and briers, it is rejected and near to being cursed, whose end is to be burned.

9. But, beloved, we are confident of better things concerning you, yes, things that accompany salvation, though we speak in this manner.

10. For God is not unjust to forget your work and labor of love which you have shown toward His name, in that you have ministered to the saints, and do minister.

11. And we desire that each one of you show the same diligence to the full assurance of hope until the end,

12. that you do not become sluggish, but imitate those who through faith and patience inherit the promises.

13. For when God made a promise to Abraham, because He could swear by no one greater, He swore by Himself,

14. saying, "Surely blessing I will bless you, and multiplying I will multiply you."

15. And so, after he had patiently endured, he obtained the promise.

16. For men indeed swear by the greater, and an oath for confirmation is for them an end of all dispute.

17. Thus God, determining to show more abundantly to the heirs of promise the immutability of His counsel, confirmed it by an oath,

18. that by two immutable things, in which it is impossible for God to lie, we might have strong consolation, who have fled for refuge to lay hold of the hope set before us.

19. This hope we have as an anchor of the soul, both sure and steadfast, and which enters the Presence behind the veil,

20. where the forerunner has entered for us, even Jesus, having become High Priest forever according to the order of Melchizedek.

## Chapter 7

1. For this Melchizedek, king of Salem, priest of the Most High God, who met Abraham returning from the slaughter of the kings and blessed him,

2. to whom also Abraham gave a tenth part of all, first being translated "king of righteousness," and then also king of Salem, meaning "king of peace,"

3. without father, without mother, without genealogy, having neither beginning of days nor end of life, but made like the Son of God, remains a priest continually.

4. Now consider how great this man was, to whom even the patriarch Abraham gave a tenth of the spoils.

5. And indeed those who are of the sons of Levi, who receive the priesthood, have a commandment to receive tithes from the people according to the law, that is, from their brethren, though they have come from the loins of Abraham;

6. but he whose genealogy is not derived from them received tithes from Abraham and blessed him who had the promises.

7. Now beyond all contradiction the lesser is blessed by the better.

8. Here mortal men receive tithes, but there he receives them, of whom it is witnessed that he lives.

9. Even Levi, who receives tithes, paid tithes through Abraham, so to speak,

10. for he was still in the loins of his father when Melchizedek met him.

11. Therefore, if perfection were through the Levitical priesthood (for under it the people received the law), what further need was there that another priest should rise according to the order of Melchizedek, and not be called according to the order of Aaron?

12. For the priesthood being changed, of necessity there is also a change of the law.

13. For He of whom these things are spoken belongs to another tribe, from which no man has officiated at the altar.

14. For it is evident that our Lord arose from Judah, of which tribe Moses spoke nothing concerning priesthood.

15. And it is yet far more evident if, in the likeness of Melchizedek, there arises another priest

16. who has come, not according to the law of a fleshly commandment, but according to the power of an endless life.

17. For He testifies: "You are a priest forever According to the order of Melchizedek."

18. For on the one hand there is an annulling of the former commandment because of its weakness and unprofitableness,

19. for the law made nothing perfect; on the other hand, there is the bringing in of a better hope, through which we draw near to God.

20. And inasmuch as He was not made priest without an oath

21. (for they have become priests without an oath, but He with an oath by Him who said to Him: "The LORD has sworn And will not relent, "You are a priest forever According to the order of Melchizedek"'),

22. by so much more Jesus has become a surety of a better covenant.

23. Also there were many priests, because they were prevented by death from continuing.

24. But He, because He continues forever, has an unchangeable priesthood.

25. Therefore He is also able to save to the uttermost those who come to God through Him, since He always lives to make intercession for them.

26. For such a High Priest was fitting for us, who is holy, harmless, undefiled, separate from sinners, and has become higher than the heavens;

27. who does not need daily, as those high priests, to offer up sacrifices, first for His own sins and then for the people's, for this He did once for all when He offered up Himself.

28. For the law appoints as high priests men who have weakness, but the word of the oath, which came after the law, appoints the Son who has been perfected forever.

## Chapter 8

1. Now this is the main point of the things we are saying: We have such a High Priest, who is seated at the right hand of the throne of the Majesty in the heavens,

2. a Minister of the sanctuary and of the true tabernacle which the Lord erected, and not man.

3. For every high priest is appointed to offer both gifts and sacrifices. Therefore it is necessary that this One also have something to offer.

4. For if He were on earth, He would not be a priest, since there are priests who offer the gifts according to the law;

5. who serve the copy and shadow of the heavenly things, as Moses was divinely instructed when he was about to make the tabernacle. For He said, "See that you make all things according to the pattern shown you on the mountain."

6. But now He has obtained a more excellent ministry, inasmuch as He is also Mediator of a better covenant, which was established on better promises.

7. For if that first covenant had been faultless, then no place would have been sought for a second.

8. Because finding fault with them, He says: "Behold, the days are coming, says the LORD, when I will make a new covenant with the house of Israel and with the house of Judah--

9. not according to the covenant that I made with their fathers in the day when I took them by the hand to lead them out of the land of Egypt; because they did not continue in My covenant, and I disregarded them, says the LORD.

10. For this is the covenant that I will make with the house of Israel after those days, says the LORD: I will put My laws in their mind and write them on their hearts; and I will be their God, and they shall be My people.

11. None of them shall teach his neighbor, and none his brother, saying, "Know the LORD,' for all shall know Me, from the least of them to the greatest of them.

12. For I will be merciful to their unrighteousness, and their sins and their lawless deeds I will remember no more."

13. In that He says, "A new covenant," He has made the first obsolete. Now what is becoming obsolete and growing old is ready to vanish away.

## Chapter 9

1. Then indeed, even the first covenant had ordinances of divine service and the earthly sanctuary.

2. For a tabernacle was prepared: the first part, in which was the lampstand, the table, and the showbread, which is called the sanctuary;

3. and behind the second veil, the part of the tabernacle which is called the Holiest of All,

4. which had the golden censer and the ark of the covenant overlaid on all sides with gold, in which were the golden pot that had the manna, Aaron's rod that budded, and the tablets of the covenant;

5. and above it were the cherubim of glory overshadowing the mercy seat. Of these things we cannot now speak in detail.

6. Now when these things had been thus prepared, the priests always went into the first part of the tabernacle, performing the services.

7. But into the second part the high priest went alone once a year, not without blood, which he offered for himself and for the people's sins committed in ignorance;

8. the Holy Spirit indicating this, that the way into the Holiest of All was not yet made manifest while the first tabernacle was still standing.

9. It was symbolic for the present time in which both gifts and sacrifices are offered which cannot make him who performed the service perfect in regard to the conscience--

10. concerned only with foods and drinks, various washings, and fleshly ordinances imposed until the time of reformation.

11. But Christ came as High Priest of the good things to come, with the greater and more perfect tabernacle not made with hands, that is, not of this creation.

12. Not with the blood of goats and calves, but with His own blood He entered the Most Holy Place once for all, having obtained eternal redemption.

13. For if the blood of bulls and goats and the ashes of a heifer, sprinkling the unclean, sanctifies for the purifying of the flesh,

14. how much more shall the blood of Christ, who through the eternal Spirit offered Himself without spot to God, cleanse your conscience from dead works to serve the living God?

15. And for this reason He is the Mediator of the new covenant, by means of death, for the redemption of the transgressions under the first covenant, that those who are called may receive the promise of the eternal inheritance.

16. For where there is a testament, there must also of necessity be the death of the testator.

17. For a testament is in force after men are dead, since it has no power at all while the testator lives.

18. Therefore not even the first covenant was dedicated without blood.

19. For when Moses had spoken every precept to all the people according to the law, he took the blood of calves and goats, with water, scarlet wool, and hyssop, and sprinkled both the book itself and all the people,

20. saying, "This is the blood of the covenant which God has commanded you."

21. Then likewise he sprinkled with blood both the tabernacle and all the vessels of the ministry.

22. And according to the law almost all things are purified with blood, and without shedding of blood there is no remission.

23. Therefore it was necessary that the copies of the things in the heavens should be purified with these, but the heavenly things themselves with better sacrifices than these.

24. For Christ has not entered the holy places made with hands, which are copies of the true, but into heaven itself, now to appear in the presence of God for us;

25. not that He should offer Himself often, as the high priest enters the Most Holy Place every year with blood of another--

26. He then would have had to suffer often since the foundation of the world; but now, once at the end of the ages, He has appeared to put away sin by the sacrifice of Himself.

27. And as it is appointed for men to die once, but after this the judgment,

28. so Christ was offered once to bear the sins of many. To those who eagerly wait for Him He will appear a second time, apart from sin, for salvation.

## Chapter 10

1. For the law, having a shadow of the good things to come, and not the very image of the things, can never with these same sacrifices, which they offer continually year by year, make those who approach perfect.

2. For then would they not have ceased to be offered? For the worshipers, once purified, would have had no more consciousness of sins.

3. But in those sacrifices there is a reminder of sins every year.

4. For it is not possible that the blood of bulls and goats could take away sins.

5. Therefore, when He came into the world, He said: "Sacrifice and offering You did not desire, But a body You have prepared for Me.

6. In burnt offerings and sacrifices for sin You had no pleasure.

7. Then I said, "Behold, I have come-- In the volume of the book it is written of Me-- To do Your will, O God."'

8. Previously saying, "Sacrifice and offering, burnt offerings, and offerings for sin You did not desire, nor had pleasure in them" (which are offered according to the law),

9. then He said, "Behold, I have come to do Your will, O God." He takes away the first that He may establish the second.

10. By that will we have been sanctified through the offering of the body of Jesus Christ once for all.

11. And every priest stands ministering daily and offering repeatedly the same sacrifices, which can never take away sins.

12. But this Man, after He had offered one sacrifice for sins forever, sat down at the right hand of God,

13. from that time waiting till His enemies are made His footstool.

14. For by one offering He has perfected forever those who are being sanctified.

15. But the Holy Spirit also witnesses to us; for after He had said before,

16. "This is the covenant that I will make with them after those days, says the LORD: I will put My laws into their hearts, and in their minds I will write them,"

17. then He adds, "Their sins and their lawless deeds I will remember no more."

18. Now where there is remission of these, there is no longer an offering for sin.

19. Therefore, brethren, having boldness to enter the Holiest by the blood of Jesus,

20. by a new and living way which He consecrated for us, through the veil, that is, His flesh,

21. and having a High Priest over the house of God,

22. let us draw near with a true heart in full assurance of faith, having our hearts sprinkled from an evil conscience and our bodies washed with pure water.

23. Let us hold fast the confession of our hope without wavering, for He who promised is faithful.

24. And let us consider one another in order to stir up love and good works,

25. not forsaking the assembling of ourselves together, as is the manner of some, but exhorting one another, and so much the more as you see the Day approaching.

26. For if we sin willfully after we have received the knowledge of the truth, there no longer remains a sacrifice for sins,

27. but a certain fearful expectation of judgment, and fiery indignation which will devour the adversaries.

28. Anyone who has rejected Moses' law dies without mercy on the testimony of two or three witnesses.

29. Of how much worse punishment, do you suppose, will he be thought worthy who has trampled the Son of God underfoot, counted the blood of the covenant by which he was sanctified a common thing, and insulted the Spirit of grace?

30. For we know Him who said, "Vengeance is Mine, I will repay," says the Lord. And again, "The LORD will judge His people."

31. It is a fearful thing to fall into the hands of the living God.

32. But recall the former days in which, after you were illuminated, you endured a great struggle with sufferings:

33. partly while you were made a spectacle both by reproaches and tribulations, and partly while you became companions of those who were so treated;

34. for you had compassion on me in my chains, and joyfully accepted the plundering of your goods, knowing that you have a better and an enduring possession for yourselves in heaven.

35. Therefore do not cast away your confidence, which has great reward.

36. For you have need of endurance, so that after you have done the will of God, you may receive the promise:

37. "For yet a little while, And He who is coming will come and will not tarry.

38. Now the just shall live by faith; But if anyone draws back, My soul has no pleasure in him."

39. But we are not of those who draw back to perdition, but of those who believe to the saving of the soul.

## Chapter 11

1. Now faith is the substance of things hoped for, the evidence of things not seen.

2. For by it the elders obtained a good testimony.

3. By faith we understand that the worlds were framed by the word of God, so that the things which are seen were not made of things which are visible.

4. By faith Abel offered to God a more excellent sacrifice than Cain, through which he obtained witness that he was righteous, God testifying of his gifts; and through it he being dead still speaks.

5. By faith Enoch was taken away so that he did not see death, "and was not found, because God had taken him"; for before he was taken he had this testimony, that he pleased God.

6. But without faith it is impossible to please Him, for he who comes to God must believe that He is, and that He is a rewarder of those who diligently seek Him.

7. By faith Noah, being divinely warned of things not yet seen, moved with godly fear, prepared an ark for the saving of his household, by which he condemned the world and became heir of the righteousness which is according to faith.

8. By faith Abraham obeyed when he was called to go out to the place which he would receive as an inheritance. And he went out, not knowing where he was going.

9. By faith he dwelt in the land of promise as in a foreign country, dwelling in tents with Isaac and Jacob, the heirs with him of the same promise;

10. for he waited for the city which has foundations, whose builder and maker is God.

11. By faith Sarah herself also received strength to conceive seed, and she bore a child when she was past the age, because she judged Him faithful who had promised.

12. Therefore from one man, and him as good as dead, were born as many as the stars of the sky in multitude--innumerable as the sand which is by the seashore.

13. These all died in faith, not having received the promises, but having seen them afar off were assured of them, embraced them and confessed that they were strangers and pilgrims on the earth.

14. For those who say such things declare plainly that they seek a homeland.

15. And truly if they had called to mind that country from which they had come out, they would have had opportunity to return.

16. But now they desire a better, that is, a heavenly country. Therefore God is not ashamed to be called their God, for He has prepared a city for them.

17. By faith Abraham, when he was tested, offered up Isaac, and he who had received the promises offered up his only begotten son,

18. of whom it was said, "In Isaac your seed shall be called,"

19. concluding that God was able to raise him up, even from the dead, from which he also received him in a figurative sense.

20. By faith Isaac blessed Jacob and Esau concerning things to come.

21. By faith Jacob, when he was dying, blessed each of the sons of Joseph, and worshiped, leaning on the top of his staff.

22. By faith Joseph, when he was dying, made mention of the departure of the children of Israel, and gave instructions concerning his bones.

23. By faith Moses, when he was born, was hidden three months by his parents, because they saw he was a beautiful child; and they were not afraid of the king's command.

24. By faith Moses, when he became of age, refused to be called the son of Pharaoh's daughter,

25. choosing rather to suffer affliction with the people of God than to enjoy the passing pleasures of sin,

26. esteeming the reproach of Christ greater riches than the treasures in Egypt; for he looked to the reward.

27. By faith he forsook Egypt, not fearing the wrath of the king; for he endured as seeing Him who is invisible.

28. By faith he kept the Passover and the sprinkling of blood, lest he who destroyed the firstborn should touch them.

29. By faith they passed through the Red Sea as by dry land, whereas the Egyptians, attempting to do so, were drowned.

30. By faith the walls of Jericho fell down after they were encircled for seven days.

31. By faith the harlot Rahab did not perish with those who did not believe, when she had received the spies with peace.

32. And what more shall I say? For the time would fail me to tell of Gideon and Barak and Samson and Jephthah, also of David and Samuel and the prophets:

33. who through faith subdued kingdoms, worked righteousness, obtained promises, stopped the mouths of lions,

34. quenched the violence of fire, escaped the edge of the sword, out of weakness were made strong, became valiant in battle, turned to flight the armies of the aliens.

35. Women received their dead raised to life again. Others were tortured, not accepting deliverance, that they might obtain a better resurrection.

36. Still others had trial of mockings and scourgings, yes, and of chains and imprisonment.

37. They were stoned, they were sawn in two, were tempted, were slain with the sword. They wandered about in sheepskins and goatskins, being destitute, afflicted, tormented--

38. of whom the world was not worthy. They wandered in deserts and mountains, in dens and caves of the earth.

39. And all these, having obtained a good testimony through faith, did not receive the promise,

40. God having provided something better for us, that they should not be made perfect apart from us.

## Chapter 12

1. Therefore we also, since we are surrounded by so great a cloud of witnesses, let us lay aside every weight, and the sin which so easily ensnares us, and let us run with endurance the race that is set before us,

2. looking unto Jesus, the author and finisher of our faith, who for the joy that was set before Him endured the cross, despising the shame, and has sat down at the right hand of the throne of God.

3. For consider Him who endured such hostility from sinners against Himself, lest you become weary and discouraged in your souls.

4. You have not yet resisted to bloodshed, striving against sin.

5. And you have forgotten the exhortation which speaks to you as to sons: "My son, do not despise the chastening of the LORD, Nor be discouraged when you are rebuked by Him;

6. For whom the LORD loves He chastens, And scourges every son whom He receives."

7. If you endure chastening, God deals with you as with sons; for what son is there whom a father does not chasten?

8. But if you are without chastening, of which all have become partakers, then you are illegitimate and not sons.

9. Furthermore, we have had human fathers who corrected us, and we paid them respect. Shall we not much more readily be in subjection to the Father of spirits and live?

10. For they indeed for a few days chastened us as seemed best to them, but He for our profit, that we may be partakers of His holiness.

11. Now no chastening seems to be joyful for the present, but painful; nevertheless, afterward it yields the peaceable fruit of righteousness to those who have been trained by it.

12. Therefore strengthen the hands which hang down, and the feeble knees,

13. and make straight paths for your feet, so that what is lame may not be dislocated, but rather be healed.

14. Pursue peace with all people, and holiness, without which no one will see the Lord:

15. looking carefully lest anyone fall short of the grace of God; lest any root of bitterness springing up cause trouble, and by this many become defiled;

16. lest there be any fornicator or profane person like Esau, who for one morsel of food sold his birthright.

17. For you know that afterward, when he wanted to inherit the blessing, he was rejected, for he found no place for repentance, though he sought it diligently with tears.

18. For you have not come to the mountain that may be touched and that burned with fire, and to blackness and darkness and tempest,

19. and the sound of a trumpet and the voice of words, so that those who heard it begged that the word should not be spoken to them anymore.

20. (For they could not endure what was commanded: "And if so much as a beast touches the mountain, it shall be stoned or shot with an arrow."

21. And so terrifying was the sight that Moses said, "I am exceedingly afraid and trembling.")

22. But you have come to Mount Zion and to the city of the living God, the heavenly Jerusalem, to an innumerable company of angels,

23. to the general assembly and church of the firstborn who are registered in heaven, to God the Judge of all, to the spirits of just men made perfect,

24. to Jesus the Mediator of the new covenant, and to the blood of sprinkling that speaks better things than that of Abel.

25. See that you do not refuse Him who speaks. For if they did not escape who refused Him who spoke on earth, much more shall we not escape if we turn away from Him who speaks from heaven,

26. whose voice then shook the earth; but now He has promised, saying, "Yet once more I shake not only the earth, but also heaven."

27. Now this, "Yet once more," indicates the removal of those things that are being shaken, as of things that are made, that the things which cannot be shaken may remain.

28. Therefore, since we are receiving a kingdom which cannot be shaken, let us have grace, by which we may serve God acceptably with reverence and godly fear.

29. For our God is a consuming fire.

## Chapter 13

1. Let brotherly love continue.

2. Do not forget to entertain strangers, for by so doing some have unwittingly entertained angels.

3. Remember the prisoners as if chained with them--those who are mistreated--since you yourselves are in the body also.

4. Marriage is honorable among all, and the bed undefiled; but fornicators and adulterers God will judge.

5. Let your conduct be without covetousness; be content with such things as you have. For He Himself has said, "I will never leave you nor forsake you."

6. So we may boldly say: "The LORD is my helper; I will not fear. What can man do to me?"

7. Remember those who rule over you, who have spoken the word of God to you, whose faith follow, considering the outcome of their conduct.

8. Jesus Christ is the same yesterday, today, and forever.

9. Do not be carried about with various and strange doctrines. For it is good that the heart be established by grace, not with foods which have not profited those who have been occupied with them.

10. We have an altar from which those who serve the tabernacle have no right to eat.

11. For the bodies of those animals, whose blood is brought into the sanctuary by the high priest for sin, are burned outside the camp.

12. Therefore Jesus also, that He might sanctify the people with His own blood, suffered outside the gate.

13. Therefore let us go forth to Him, outside the camp, bearing His reproach.

14. For here we have no continuing city, but we seek the one to come.

15. Therefore by Him let us continually offer the sacrifice of praise to God, that is, the fruit of our lips, giving thanks to His name.

16. But do not forget to do good and to share, for with such sacrifices God is well pleased.

17. Obey those who rule over you, and be submissive, for they watch out for your souls, as those who must give account. Let them do so with joy and not with grief, for that would be unprofitable for you.

18. Pray for us; for we are confident that we have a good conscience, in all things desiring to live honorably.

19. But I especially urge you to do this, that I may be restored to you the sooner.

20. Now may the God of peace who brought up our Lord Jesus from the dead, that great Shepherd of the sheep, through the blood of the everlasting covenant,

21. make you complete in every good work to do His will, working in you what is well pleasing in His sight, through Jesus Christ, to whom be glory forever and ever. Amen.

22. And I appeal to you, brethren, bear with the word of exhortation, for I have written to you in few words.

23. Know that our brother Timothy has been set free, with whom I shall see you if he comes shortly.

24. Greet all those who rule over you, and all the saints. Those from Italy greet you.

25. Grace be with you all. Amen.


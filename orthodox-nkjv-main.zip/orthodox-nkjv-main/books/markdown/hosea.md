# hosea

## Chapter 1

1. The word of the LORD that came to Hosea the son of Beeri, in the days of Uzziah, Jotham, Ahaz, and Hezekiah, kings of Judah, and in the days of Jeroboam the son of Joash, king of Israel.

2. When the LORD began to speak by Hosea, the LORD said to Hosea: "Go, take yourself a wife of harlotry And children of harlotry, For the land has committed great harlotry By departing from the LORD."

3. So he went and took Gomer the daughter of Diblaim, and she conceived and bore him a son.

4. Then the LORD said to him: "Call his name Jezreel, For in a little while I will avenge the bloodshed of Jezreel on the house of Jehu, And bring an end to the kingdom of the house of Israel.

5. It shall come to pass in that day That I will break the bow of Israel in the Valley of Jezreel."

6. And she conceived again and bore a daughter. Then God said to him: "Call her name Lo-Ruhamah, For I will no longer have mercy on the house of Israel, But I will utterly take them away.

7. Yet I will have mercy on the house of Judah, Will save them by the LORD their God, And will not save them by bow, Nor by sword or battle, By horses or horsemen."

8. Now when she had weaned Lo-Ruhamah, she conceived and bore a son.

9. Then God said: "Call his name Lo-Ammi, For you are not My people, And I will not be your God.

10. "Yet the number of the children of Israel Shall be as the sand of the sea, Which cannot be measured or numbered. And it shall come to pass In the place where it was said to them, "You are not My people,' There it shall be said to them, "You are sons of the living God.'

11. Then the children of Judah and the children of Israel Shall be gathered together, And appoint for themselves one head; And they shall come up out of the land, For great will be the day of Jezreel!

## Chapter 2

1. Say to your brethren, "My people,' And to your sisters, "Mercy is shown.'

2. "Bring charges against your mother, bring charges; For she is not My wife, nor am I her Husband! Let her put away her harlotries from her sight, And her adulteries from between her breasts;

3. Lest I strip her naked And expose her, as in the day she was born, And make her like a wilderness, And set her like a dry land, And slay her with thirst.

4. "I will not have mercy on her children, For they are the children of harlotry.

5. For their mother has played the harlot; She who conceived them has behaved shamefully. For she said, "I will go after my lovers, Who give me my bread and my water, My wool and my linen, My oil and my drink.'

6. "Therefore, behold, I will hedge up your way with thorns, And wall her in, So that she cannot find her paths.

7. She will chase her lovers, But not overtake them; Yes, she will seek them, but not find them. Then she will say, "I will go and return to my first husband, For then it was better for me than now.'

8. For she did not know That I gave her grain, new wine, and oil, And multiplied her silver and gold-- Which they prepared for Baal.

9. "Therefore I will return and take away My grain in its time And My new wine in its season, And will take back My wool and My linen, Given to cover her nakedness.

10. Now I will uncover her lewdness in the sight of her lovers, And no one shall deliver her from My hand.

11. I will also cause all her mirth to cease, Her feast days, Her New Moons, Her Sabbaths-- All her appointed feasts.

12. "And I will destroy her vines and her fig trees, Of which she has said, "These are my wages that my lovers have given me.' So I will make them a forest, And the beasts of the field shall eat them.

13. I will punish her For the days of the Baals to which she burned incense. She decked herself with her earrings and jewelry, And went after her lovers; But Me she forgot," says the LORD.

14. "Therefore, behold, I will allure her, Will bring her into the wilderness, And speak comfort to her.

15. I will give her her vineyards from there, And the Valley of Achor as a door of hope; She shall sing there, As in the days of her youth, As in the day when she came up from the land of Egypt.

16. "And it shall be, in that day," Says the LORD, "That you will call Me "My Husband,' And no longer call Me "My Master,'

17. For I will take from her mouth the names of the Baals, And they shall be remembered by their name no more.

18. In that day I will make a covenant for them With the beasts of the field, With the birds of the air, And with the creeping things of the ground. Bow and sword of battle I will shatter from the earth, To make them lie down safely.

19. "I will betroth you to Me forever; Yes, I will betroth you to Me In righteousness and justice, In lovingkindness and mercy;

20. I will betroth you to Me in faithfulness, And you shall know the LORD.

21. "It shall come to pass in that day That I will answer," says the LORD; "I will answer the heavens, And they shall answer the earth.

22. The earth shall answer With grain, With new wine, And with oil; They shall answer Jezreel.

23. Then I will sow her for Myself in the earth, And I will have mercy on her who had not obtained mercy; Then I will say to those who were not My people, "You are My people!' And they shall say, "You are my God!"'

## Chapter 3

1. Then the LORD said to me, "Go again, love a woman who is loved by a lover and is committing adultery, just like the love of the LORD for the children of Israel, who look to other gods and love the raisin cakes of the pagans."

2. So I bought her for myself for fifteen shekels of silver, and one and one-half homers of barley.

3. And I said to her, "You shall stay with me many days; you shall not play the harlot, nor shall you have a man--so, too, will I be toward you."

4. For the children of Israel shall abide many days without king or prince, without sacrifice or sacred pillar, without ephod or teraphim.

5. Afterward the children of Israel shall return and seek the LORD their God and David their king. They shall fear the LORD and His goodness in the latter days.

## Chapter 4

1. Hear the word of the LORD, You children of Israel, For the LORD brings a charge against the inhabitants of the land: "There is no truth or mercy Or knowledge of God in the land.

2. By swearing and lying, Killing and stealing and committing adultery, They break all restraint, With bloodshed upon bloodshed.

3. Therefore the land will mourn; And everyone who dwells there will waste away With the beasts of the field And the birds of the air; Even the fish of the sea will be taken away.

4. "Now let no man contend, or rebuke another; For your people are like those who contend with the priest.

5. Therefore you shall stumble in the day; The prophet also shall stumble with you in the night; And I will destroy your mother.

6. My people are destroyed for lack of knowledge. Because you have rejected knowledge, I also will reject you from being priest for Me; Because you have forgotten the law of your God, I also will forget your children.

7. "The more they increased, The more they sinned against Me; I will change their glory into shame.

8. They eat up the sin of My people; They set their heart on their iniquity.

9. And it shall be: like people, like priest. So I will punish them for their ways, And reward them for their deeds.

10. For they shall eat, but not have enough; They shall commit harlotry, but not increase; Because they have ceased obeying the LORD.

11. "Harlotry, wine, and new wine enslave the heart.

12. My people ask counsel from their wooden idols, And their staff informs them. For the spirit of harlotry has caused them to stray, And they have played the harlot against their God.

13. They offer sacrifices on the mountaintops, And burn incense on the hills, Under oaks, poplars, and terebinths, Because their shade is good. Therefore your daughters commit harlotry, And your brides commit adultery.

14. "I will not punish your daughters when they commit harlotry, Nor your brides when they commit adultery; For the men themselves go apart with harlots, And offer sacrifices with a ritual harlot. Therefore people who do not understand will be trampled.

15. "Though you, Israel, play the harlot, Let not Judah offend. Do not come up to Gilgal, Nor go up to Beth Aven, Nor swear an oath, saying, "As the LORD lives'--

16. "For Israel is stubborn Like a stubborn calf; Now the LORD will let them forage Like a lamb in open country.

17. "Ephraim is joined to idols, Let him alone.

18. Their drink is rebellion, They commit harlotry continually. Her rulers dearly love dishonor.

19. The wind has wrapped her up in its wings, And they shall be ashamed because of their sacrifices.

## Chapter 5

1. "Hear this, O priests! Take heed, O house of Israel! Give ear, O house of the king! For yours is the judgment, Because you have been a snare to Mizpah And a net spread on Tabor.

2. The revolters are deeply involved in slaughter, Though I rebuke them all.

3. I know Ephraim, And Israel is not hidden from Me; For now, O Ephraim, you commit harlotry; Israel is defiled.

4. "They do not direct their deeds Toward turning to their God, For the spirit of harlotry is in their midst, And they do not know the LORD.

5. The pride of Israel testifies to his face; Therefore Israel and Ephraim stumble in their iniquity; Judah also stumbles with them.

6. "With their flocks and herds They shall go to seek the LORD, But they will not find Him; He has withdrawn Himself from them.

7. They have dealt treacherously with the LORD, For they have begotten pagan children. Now a New Moon shall devour them and their heritage.

8. "Blow the ram's horn in Gibeah, The trumpet in Ramah! Cry aloud at Beth Aven, "Look behind you, O Benjamin!'

9. Ephraim shall be desolate in the day of rebuke; Among the tribes of Israel I make known what is sure.

10. "The princes of Judah are like those who remove a landmark; I will pour out My wrath on them like water.

11. Ephraim is oppressed and broken in judgment, Because he willingly walked by human precept.

12. Therefore I will be to Ephraim like a moth, And to the house of Judah like rottenness.

13. "When Ephraim saw his sickness, And Judah saw his wound, Then Ephraim went to Assyria And sent to King Jareb; Yet he cannot cure you, Nor heal you of your wound.

14. For I will be like a lion to Ephraim, And like a young lion to the house of Judah. I, even I, will tear them and go away; I will take them away, and no one shall rescue.

15. I will return again to My place Till they acknowledge their offense. Then they will seek My face; In their affliction they will earnestly seek Me."

## Chapter 6

1. Come, and let us return to the LORD; For He has torn, but He will heal us; He has stricken, but He will bind us up.

2. After two days He will revive us; On the third day He will raise us up, That we may live in His sight.

3. Let us know, Let us pursue the knowledge of the LORD. His going forth is established as the morning; He will come to us like the rain, Like the latter and former rain to the earth.

4. "O Ephraim, what shall I do to you? O Judah, what shall I do to you? For your faithfulness is like a morning cloud, And like the early dew it goes away.

5. Therefore I have hewn them by the prophets, I have slain them by the words of My mouth; And your judgments are like light that goes forth.

6. For I desire mercy and not sacrifice, And the knowledge of God more than burnt offerings.

7. "But like men they transgressed the covenant; There they dealt treacherously with Me.

8. Gilead is a city of evildoers And defiled with blood.

9. As bands of robbers lie in wait for a man, So the company of priests murder on the way to Shechem; Surely they commit lewdness.

10. I have seen a horrible thing in the house of Israel: There is the harlotry of Ephraim; Israel is defiled.

11. Also, O Judah, a harvest is appointed for you, When I return the captives of My people.

## Chapter 7

1. "When I would have healed Israel, Then the iniquity of Ephraim was uncovered, And the wickedness of Samaria. For they have committed fraud; A thief comes in; A band of robbers takes spoil outside.

2. They do not consider in their hearts That I remember all their wickedness; Now their own deeds have surrounded them; They are before My face.

3. They make a king glad with their wickedness, And princes with their lies.

4. "They are all adulterers. Like an oven heated by a baker-- He ceases stirring the fire after kneading the dough, Until it is leavened.

5. In the day of our king Princes have made him sick, inflamed with wine; He stretched out his hand with scoffers.

6. They prepare their heart like an oven, While they lie in wait; Their baker sleeps all night; In the morning it burns like a flaming fire.

7. They are all hot, like an oven, And have devoured their judges; All their kings have fallen. None among them calls upon Me.

8. "Ephraim has mixed himself among the peoples; Ephraim is a cake unturned.

9. Aliens have devoured his strength, But he does not know it; Yes, gray hairs are here and there on him, Yet he does not know it.

10. And the pride of Israel testifies to his face, But they do not return to the LORD their God, Nor seek Him for all this.

11. "Ephraim also is like a silly dove, without sense-- They call to Egypt, They go to Assyria.

12. Wherever they go, I will spread My net on them; I will bring them down like birds of the air; I will chastise them According to what their congregation has heard.

13. "Woe to them, for they have fled from Me! Destruction to them, Because they have transgressed against Me! Though I redeemed them, Yet they have spoken lies against Me.

14. They did not cry out to Me with their heart When they wailed upon their beds. "They assemble together for grain and new wine, They rebel against Me;

15. Though I disciplined and strengthened their arms, Yet they devise evil against Me;

16. They return, but not to the Most High; They are like a treacherous bow. Their princes shall fall by the sword For the cursings of their tongue. This shall be their derision in the land of Egypt.

## Chapter 8

1. "Set the trumpet to your mouth! He shall come like an eagle against the house of the LORD, Because they have transgressed My covenant And rebelled against My law.

2. Israel will cry to Me, "My God, we know You!'

3. Israel has rejected the good; The enemy will pursue him.

4. "They set up kings, but not by Me; They made princes, but I did not acknowledge them. From their silver and gold They made idols for themselves-- That they might be cut off.

5. Your calf is rejected, O Samaria! My anger is aroused against them-- How long until they attain to innocence?

6. For from Israel is even this: A workman made it, and it is not God; But the calf of Samaria shall be broken to pieces.

7. "They sow the wind, And reap the whirlwind. The stalk has no bud; It shall never produce meal. If it should produce, Aliens would swallow it up.

8. Israel is swallowed up; Now they are among the Gentiles Like a vessel in which is no pleasure.

9. For they have gone up to Assyria, Like a wild donkey alone by itself; Ephraim has hired lovers.

10. Yes, though they have hired among the nations, Now I will gather them; And they shall sorrow a little, Because of the burden of the king of princes.

11. "Because Ephraim has made many altars for sin, They have become for him altars for sinning.

12. I have written for him the great things of My law, But they were considered a strange thing.

13. For the sacrifices of My offerings they sacrifice flesh and eat it, But the LORD does not accept them. Now He will remember their iniquity and punish their sins. They shall return to Egypt.

14. "For Israel has forgotten his Maker, And has built temples; Judah also has multiplied fortified cities; But I will send fire upon his cities, And it shall devour his palaces."

## Chapter 9

1. Do not rejoice, O Israel, with joy like other peoples, For you have played the harlot against your God. You have made love for hire on every threshing floor.

2. The threshing floor and the winepress Shall not feed them, And the new wine shall fail in her.

3. They shall not dwell in the LORD's land, But Ephraim shall return to Egypt, And shall eat unclean things in Assyria.

4. They shall not offer wine offerings to the LORD, Nor shall their sacrifices be pleasing to Him. It shall be like bread of mourners to them; All who eat it shall be defiled. For their bread shall be for their own life; It shall not come into the house of the LORD.

5. What will you do in the appointed day, And in the day of the feast of the LORD?

6. For indeed they are gone because of destruction. Egypt shall gather them up; Memphis shall bury them. Nettles shall possess their valuables of silver; Thorns shall be in their tents.

7. The days of punishment have come; The days of recompense have come. Israel knows! The prophet is a fool, The spiritual man is insane, Because of the greatness of your iniquity and great enmity.

8. The watchman of Ephraim is with my God; But the prophet is a fowler's snare in all his ways-- Enmity in the house of his God.

9. They are deeply corrupted, As in the days of Gibeah. He will remember their iniquity; He will punish their sins.

10. "I found Israel Like grapes in the wilderness; I saw your fathers As the firstfruits on the fig tree in its first season. But they went to Baal Peor, And separated themselves to that shame; They became an abomination like the thing they loved.

11. As for Ephraim, their glory shall fly away like a bird-- No birth, no pregnancy, and no conception!

12. Though they bring up their children, Yet I will bereave them to the last man. Yes, woe to them when I depart from them!

13. Just as I saw Ephraim like Tyre, planted in a pleasant place, So Ephraim will bring out his children to the murderer."

14. Give them, O LORD-- What will You give? Give them a miscarrying womb And dry breasts!

15. "All their wickedness is in Gilgal, For there I hated them. Because of the evil of their deeds I will drive them from My house; I will love them no more. All their princes are rebellious.

16. Ephraim is stricken, Their root is dried up; They shall bear no fruit. Yes, were they to bear children, I would kill the darlings of their womb."

17. My God will cast them away, Because they did not obey Him; And they shall be wanderers among the nations.

## Chapter 10

1. Israel empties his vine; He brings forth fruit for himself. According to the multitude of his fruit He has increased the altars; According to the bounty of his land They have embellished his sacred pillars.

2. Their heart is divided; Now they are held guilty. He will break down their altars; He will ruin their sacred pillars.

3. For now they say, "We have no king, Because we did not fear the LORD. And as for a king, what would he do for us?"

4. They have spoken words, Swearing falsely in making a covenant. Thus judgment springs up like hemlock in the furrows of the field.

5. The inhabitants of Samaria fear Because of the calf of Beth Aven. For its people mourn for it, And its priests shriek for it-- Because its glory has departed from it.

6. The idol also shall be carried to Assyria As a present for King Jareb. Ephraim shall receive shame, And Israel shall be ashamed of his own counsel.

7. As for Samaria, her king is cut off Like a twig on the water.

8. Also the high places of Aven, the sin of Israel, Shall be destroyed. The thorn and thistle shall grow on their altars; They shall say to the mountains, "Cover us!" And to the hills, "Fall on us!"

9. "O Israel, you have sinned from the days of Gibeah; There they stood. The battle in Gibeah against the children of iniquity Did not overtake them.

10. When it is My desire, I will chasten them. Peoples shall be gathered against them When I bind them for their two transgressions.

11. Ephraim is a trained heifer That loves to thresh grain; But I harnessed her fair neck, I will make Ephraim pull a plow. Judah shall plow; Jacob shall break his clods."

12. Sow for yourselves righteousness; Reap in mercy; Break up your fallow ground, For it is time to seek the LORD, Till He comes and rains righteousness on you.

13. You have plowed wickedness; You have reaped iniquity. You have eaten the fruit of lies, Because you trusted in your own way, In the multitude of your mighty men.

14. Therefore tumult shall arise among your people, And all your fortresses shall be plundered As Shalman plundered Beth Arbel in the day of battle-- A mother dashed in pieces upon her children.

15. Thus it shall be done to you, O Bethel, Because of your great wickedness. At dawn the king of Israel Shall be cut off utterly.

## Chapter 11

1. "When Israel was a child, I loved him, And out of Egypt I called My son.

2. As they called them, So they went from them; They sacrificed to the Baals, And burned incense to carved images.

3. "I taught Ephraim to walk, Taking them by their arms; But they did not know that I healed them.

4. I drew them with gentle cords, With bands of love, And I was to them as those who take the yoke from their neck. I stooped and fed them.

5. "He shall not return to the land of Egypt; But the Assyrian shall be his king, Because they refused to repent.

6. And the sword shall slash in his cities, Devour his districts, And consume them, Because of their own counsels.

7. My people are bent on backsliding from Me. Though they call to the Most High, None at all exalt Him.

8. "How can I give you up, Ephraim? How can I hand you over, Israel? How can I make you like Admah? How can I set you like Zeboiim? My heart churns within Me; My sympathy is stirred.

9. I will not execute the fierceness of My anger; I will not again destroy Ephraim. For I am God, and not man, The Holy One in your midst; And I will not come with terror.

10. "They shall walk after the LORD. He will roar like a lion. When He roars, Then His sons shall come trembling from the west;

11. They shall come trembling like a bird from Egypt, Like a dove from the land of Assyria. And I will let them dwell in their houses," Says the LORD.

12. "Ephraim has encircled Me with lies, And the house of Israel with deceit; But Judah still walks with God, Even with the Holy One who is faithful.

## Chapter 12

1. "Ephraim feeds on the wind, And pursues the east wind; He daily increases lies and desolation. Also they make a covenant with the Assyrians, And oil is carried to Egypt.

2. "The LORD also brings a charge against Judah, And will punish Jacob according to his ways; According to his deeds He will recompense him.

3. He took his brother by the heel in the womb, And in his strength he struggled with God.

4. Yes, he struggled with the Angel and prevailed; He wept, and sought favor from Him. He found Him in Bethel, And there He spoke to us--

5. That is, the LORD God of hosts. The LORD is His memorable name.

6. So you, by the help of your God, return; Observe mercy and justice, And wait on your God continually.

7. "A cunning Canaanite! Deceitful scales are in his hand; He loves to oppress.

8. And Ephraim said, "Surely I have become rich, I have found wealth for myself; In all my labors They shall find in me no iniquity that is sin.'

9. "But I am the LORD your God, Ever since the land of Egypt; I will again make you dwell in tents, As in the days of the appointed feast.

10. I have also spoken by the prophets, And have multiplied visions; I have given symbols through the witness of the prophets."

11. Though Gilead has idols-- Surely they are vanity-- Though they sacrifice bulls in Gilgal, Indeed their altars shall be heaps in the furrows of the field.

12. Jacob fled to the country of Syria; Israel served for a spouse, And for a wife he tended sheep.

13. By a prophet the LORD brought Israel out of Egypt, And by a prophet he was preserved.

14. Ephraim provoked Him to anger most bitterly; Therefore his Lord will leave the guilt of his bloodshed upon him, And return his reproach upon him.

## Chapter 13

1. When Ephraim spoke, trembling, He exalted himself in Israel; But when he offended through Baal worship, he died.

2. Now they sin more and more, And have made for themselves molded images, Idols of their silver, according to their skill; All of it is the work of craftsmen. They say of them, "Let the men who sacrifice kiss the calves!"

3. Therefore they shall be like the morning cloud And like the early dew that passes away, Like chaff blown off from a threshing floor And like smoke from a chimney.

4. "Yet I am the LORD your God Ever since the land of Egypt, And you shall know no God but Me; For there is no savior besides Me.

5. I knew you in the wilderness, In the land of great drought.

6. When they had pasture, they were filled; They were filled and their heart was exalted; Therefore they forgot Me.

7. "So I will be to them like a lion; Like a leopard by the road I will lurk;

8. I will meet them like a bear deprived of her cubs; I will tear open their rib cage, And there I will devour them like a lion. The wild beast shall tear them.

9. "O Israel, you are destroyed, But your help is from Me.

10. I will be your King; Where is any other, That he may save you in all your cities? And your judges to whom you said, "Give me a king and princes'?

11. I gave you a king in My anger, And took him away in My wrath.

12. "The iniquity of Ephraim is bound up; His sin is stored up.

13. The sorrows of a woman in childbirth shall come upon him. He is an unwise son, For he should not stay long where children are born.

14. "I will ransom them from the power of the grave; I will redeem them from death. O Death, I will be your plagues! O Grave, I will be your destruction! Pity is hidden from My eyes."

15. Though he is fruitful among his brethren, An east wind shall come; The wind of the LORD shall come up from the wilderness. Then his spring shall become dry, And his fountain shall be dried up. He shall plunder the treasury of every desirable prize.

16. Samaria is held guilty, For she has rebelled against her God. They shall fall by the sword, Their infants shall be dashed in pieces, And their women with child ripped open.

## Chapter 14

1. O Israel, return to the LORD your God, For you have stumbled because of your iniquity;

2. Take words with you, And return to the LORD. Say to Him, "Take away all iniquity; Receive us graciously, For we will offer the sacrifices of our lips.

3. Assyria shall not save us, We will not ride on horses, Nor will we say anymore to the work of our hands, "You are our gods.' For in You the fatherless finds mercy."

4. "I will heal their backsliding, I will love them freely, For My anger has turned away from him.

5. I will be like the dew to Israel; He shall grow like the lily, And lengthen his roots like Lebanon.

6. His branches shall spread; His beauty shall be like an olive tree, And his fragrance like Lebanon.

7. Those who dwell under his shadow shall return; They shall be revived like grain, And grow like a vine. Their scent shall be like the wine of Lebanon.

8. "Ephraim shall say, "What have I to do anymore with idols?' I have heard and observed him. I am like a green cypress tree; Your fruit is found in Me."

9. Who is wise? Let him understand these things. Who is prudent? Let him know them. For the ways of the LORD are right; The righteous walk in them, But transgressors stumble in them.


# isaiah

## Chapter 1

1. The vision of Isaiah the son of Amoz, which he saw concerning Judah and Jerusalem in the days of Uzziah, Jotham, Ahaz, and Hezekiah, kings of Judah.

2. Hear, O heavens, and give ear, O earth! For the LORD has spoken: "I have nourished and brought up children, And they have rebelled against Me;

3. The ox knows its owner And the donkey its master's crib; But Israel does not know, My people do not consider."

4. Alas, sinful nation, A people laden with iniquity, A brood of evildoers, Children who are corrupters! They have forsaken the LORD, They have provoked to anger The Holy One of Israel, They have turned away backward.

5. Why should you be stricken again? You will revolt more and more. The whole head is sick, And the whole heart faints.

6. From the sole of the foot even to the head, There is no soundness in it, But wounds and bruises and putrefying sores; They have not been closed or bound up, Or soothed with ointment.

7. Your country is desolate, Your cities are burned with fire; Strangers devour your land in your presence; And it is desolate, as overthrown by strangers.

8. So the daughter of Zion is left as a booth in a vineyard, As a hut in a garden of cucumbers, As a besieged city.

9. Unless the LORD of hosts Had left to us a very small remnant, We would have become like Sodom, We would have been made like Gomorrah.

10. Hear the word of the LORD, You rulers of Sodom; Give ear to the law of our God, You people of Gomorrah:

11. "To what purpose is the multitude of your sacrifices to Me?" Says the LORD. "I have had enough of burnt offerings of rams And the fat of fed cattle. I do not delight in the blood of bulls, Or of lambs or goats.

12. "When you come to appear before Me, Who has required this from your hand, To trample My courts?

13. Bring no more futile sacrifices; Incense is an abomination to Me. The New Moons, the Sabbaths, and the calling of assemblies-- I cannot endure iniquity and the sacred meeting.

14. Your New Moons and your appointed feasts My soul hates; They are a trouble to Me, I am weary of bearing them.

15. When you spread out your hands, I will hide My eyes from you; Even though you make many prayers, I will not hear. Your hands are full of blood.

16. "Wash yourselves, make yourselves clean; Put away the evil of your doings from before My eyes. Cease to do evil,

17. Learn to do good; Seek justice, Rebuke the oppressor; Defend the fatherless, Plead for the widow.

18. "Come now, and let us reason together," Says the LORD, "Though your sins are like scarlet, They shall be as white as snow; Though they are red like crimson, They shall be as wool.

19. If you are willing and obedient, You shall eat the good of the land;

20. But if you refuse and rebel, You shall be devoured by the sword"; For the mouth of the LORD has spoken.

21. How the faithful city has become a harlot! It was full of justice; Righteousness lodged in it, But now murderers.

22. Your silver has become dross, Your wine mixed with water.

23. Your princes are rebellious, And companions of thieves; Everyone loves bribes, And follows after rewards. They do not defend the fatherless, Nor does the cause of the widow come before them.

24. Therefore the Lord says, The LORD of hosts, the Mighty One of Israel, "Ah, I will rid Myself of My adversaries, And take vengeance on My enemies.

25. I will turn My hand against you, And thoroughly purge away your dross, And take away all your alloy.

26. I will restore your judges as at the first, And your counselors as at the beginning. Afterward you shall be called the city of righteousness, the faithful city."

27. Zion shall be redeemed with justice, And her penitents with righteousness.

28. The destruction of transgressors and of sinners shall be together, And those who forsake the LORD shall be consumed.

29. For they shall be ashamed of the terebinth trees Which you have desired; And you shall be embarrassed because of the gardens Which you have chosen.

30. For you shall be as a terebinth whose leaf fades, And as a garden that has no water.

31. The strong shall be as tinder, And the work of it as a spark; Both will burn together, And no one shall quench them.

## Chapter 2

1. The word that Isaiah the son of Amoz saw concerning Judah and Jerusalem.

2. Now it shall come to pass in the latter days That the mountain of the LORD's house Shall be established on the top of the mountains, And shall be exalted above the hills; And all nations shall flow to it.

3. Many people shall come and say, "Come, and let us go up to the mountain of the LORD, To the house of the God of Jacob; He will teach us His ways, And we shall walk in His paths." For out of Zion shall go forth the law, And the word of the LORD from Jerusalem.

4. He shall judge between the nations, And rebuke many people; They shall beat their swords into plowshares, And their spears into pruning hooks; Nation shall not lift up sword against nation, Neither shall they learn war anymore.

5. O house of Jacob, come and let us walk In the light of the LORD.

6. For You have forsaken Your people, the house of Jacob, Because they are filled with eastern ways; They are soothsayers like the Philistines, And they are pleased with the children of foreigners.

7. Their land is also full of silver and gold, And there is no end to their treasures; Their land is also full of horses, And there is no end to their chariots.

8. Their land is also full of idols; They worship the work of their own hands, That which their own fingers have made.

9. People bow down, And each man humbles himself; Therefore do not forgive them.

10. Enter into the rock, and hide in the dust, From the terror of the LORD And the glory of His majesty.

11. The lofty looks of man shall be humbled, The haughtiness of men shall be bowed down, And the LORD alone shall be exalted in that day.

12. For the day of the LORD of hosts Shall come upon everything proud and lofty, Upon everything lifted up-- And it shall be brought low--

13. Upon all the cedars of Lebanon that are high and lifted up, And upon all the oaks of Bashan;

14. Upon all the high mountains, And upon all the hills that are lifted up;

15. Upon every high tower, And upon every fortified wall;

16. Upon all the ships of Tarshish, And upon all the beautiful sloops.

17. The loftiness of man shall be bowed down, And the haughtiness of men shall be brought low; The LORD alone will be exalted in that day,

18. But the idols He shall utterly abolish.

19. They shall go into the holes of the rocks, And into the caves of the earth, From the terror of the LORD And the glory of His majesty, When He arises to shake the earth mightily.

20. In that day a man will cast away his idols of silver And his idols of gold, Which they made, each for himself to worship, To the moles and bats,

21. To go into the clefts of the rocks, And into the crags of the rugged rocks, From the terror of the LORD And the glory of His majesty, When He arises to shake the earth mightily.

22. Sever yourselves from such a man, Whose breath is in his nostrils; For of what account is he?

## Chapter 3

1. For behold, the Lord, the LORD of hosts, Takes away from Jerusalem and from Judah The stock and the store, The whole supply of bread and the whole supply of water;

2. The mighty man and the man of war, The judge and the prophet, And the diviner and the elder;

3. The captain of fifty and the honorable man, The counselor and the skillful artisan, And the expert enchanter.

4. "I will give children to be their princes, And babes shall rule over them.

5. The people will be oppressed, Every one by another and every one by his neighbor; The child will be insolent toward the elder, And the base toward the honorable."

6. When a man takes hold of his brother In the house of his father, saying, "You have clothing; You be our ruler, And let these ruins be under your power,"

7. In that day he will protest, saying, "I cannot cure your ills, For in my house is neither food nor clothing; Do not make me a ruler of the people."

8. For Jerusalem stumbled, And Judah is fallen, Because their tongue and their doings Are against the LORD, To provoke the eyes of His glory.

9. The look on their countenance witnesses against them, And they declare their sin as Sodom; They do not hide it. Woe to their soul! For they have brought evil upon themselves.

10. "Say to the righteous that it shall be well with them, For they shall eat the fruit of their doings.

11. Woe to the wicked! It shall be ill with him, For the reward of his hands shall be given him.

12. As for My people, children are their oppressors, And women rule over them. O My people! Those who lead you cause you to err, And destroy the way of your paths."

13. The LORD stands up to plead, And stands to judge the people.

14. The LORD will enter into judgment With the elders of His people And His princes: "For you have eaten up the vineyard; The plunder of the poor is in your houses.

15. What do you mean by crushing My people And grinding the faces of the poor?" Says the Lord GOD of hosts.

16. Moreover the LORD says: "Because the daughters of Zion are haughty, And walk with outstretched necks And wanton eyes, Walking and mincing as they go, Making a jingling with their feet,

17. Therefore the Lord will strike with a scab The crown of the head of the daughters of Zion, And the LORD will uncover their secret parts."

18. In that day the Lord will take away the finery: The jingling anklets, the scarves, and the crescents;

19. The pendants, the bracelets, and the veils;

20. The headdresses, the leg ornaments, and the headbands; The perfume boxes, the charms, The nose jewels, The outer garments, the purses, The fine linen, the turbans, and the robes.

24. And so it shall be: Instead of a sweet smell there will be a stench; Instead of a sash, a rope; Instead of well-set hair, baldness; Instead of a rich robe, a girding of sackcloth; And branding instead of beauty.

25. Your men shall fall by the sword, And your mighty in the war.

26. Her gates shall lament and mourn, And she being desolate shall sit on the ground.

## Chapter 4

1. And in that day seven women shall take hold of one man, saying, "We will eat our own food and wear our own apparel; Only let us be called by your name, To take away our reproach."

2. In that day the Branch of the LORD shall be beautiful and glorious; And the fruit of the earth shall be excellent and appealing For those of Israel who have escaped.

3. And it shall come to pass that he who is left in Zion and remains in Jerusalem will be called holy--everyone who is recorded among the living in Jerusalem.

4. When the Lord has washed away the filth of the daughters of Zion, and purged the blood of Jerusalem from her midst, by the spirit of judgment and by the spirit of burning,

5. then the LORD will create above every dwelling place of Mount Zion, and above her assemblies, a cloud and smoke by day and the shining of a flaming fire by night. For over all the glory there will be a covering.

6. And there will be a tabernacle for shade in the daytime from the heat, for a place of refuge, and for a shelter from storm and rain.

## Chapter 5

1. Now let me sing to my Well-beloved A song of my Beloved regarding His vineyard: My Well-beloved has a vineyard On a very fruitful hill.

2. He dug it up and cleared out its stones, And planted it with the choicest vine. He built a tower in its midst, And also made a winepress in it; So He expected it to bring forth good grapes, But it brought forth wild grapes.

3. "And now, O inhabitants of Jerusalem and men of Judah, Judge, please, between Me and My vineyard.

4. What more could have been done to My vineyard That I have not done in it? Why then, when I expected it to bring forth good grapes, Did it bring forth wild grapes?

5. And now, please let Me tell you what I will do to My vineyard: I will take away its hedge, and it shall be burned; And break down its wall, and it shall be trampled down.

6. I will lay it waste; It shall not be pruned or dug, But there shall come up briers and thorns. I will also command the clouds That they rain no rain on it."

7. For the vineyard of the LORD of hosts is the house of Israel, And the men of Judah are His pleasant plant. He looked for justice, but behold, oppression; For righteousness, but behold, a cry for help.

8. Woe to those who join house to house; They add field to field, Till there is no place Where they may dwell alone in the midst of the land!

9. In my hearing the LORD of hosts said, "Truly, many houses shall be desolate, Great and beautiful ones, without inhabitant.

10. For ten acres of vineyard shall yield one bath, And a homer of seed shall yield one ephah."

11. Woe to those who rise early in the morning, That they may follow intoxicating drink; Who continue until night, till wine inflames them!

12. The harp and the strings, The tambourine and flute, And wine are in their feasts; But they do not regard the work of the LORD, Nor consider the operation of His hands.

13. Therefore my people have gone into captivity, Because they have no knowledge; Their honorable men are famished, And their multitude dried up with thirst.

14. Therefore Sheol has enlarged itself And opened its mouth beyond measure; Their glory and their multitude and their pomp, And he who is jubilant, shall descend into it.

15. People shall be brought down, Each man shall be humbled, And the eyes of the lofty shall be humbled.

16. But the LORD of hosts shall be exalted in judgment, And God who is holy shall be hallowed in righteousness.

17. Then the lambs shall feed in their pasture, And in the waste places of the fat ones strangers shall eat.

18. Woe to those who draw iniquity with cords of vanity, And sin as if with a cart rope;

19. That say, "Let Him make speed and hasten His work, That we may see it; And let the counsel of the Holy One of Israel draw near and come, That we may know it."

20. Woe to those who call evil good, and good evil; Who put darkness for light, and light for darkness; Who put bitter for sweet, and sweet for bitter!

21. Woe to those who are wise in their own eyes, And prudent in their own sight!

22. Woe to men mighty at drinking wine, Woe to men valiant for mixing intoxicating drink,

23. Who justify the wicked for a bribe, And take away justice from the righteous man!

24. Therefore, as the fire devours the stubble, And the flame consumes the chaff, So their root will be as rottenness, And their blossom will ascend like dust; Because they have rejected the law of the LORD of hosts, And despised the word of the Holy One of Israel.

25. Therefore the anger of the LORD is aroused against His people; He has stretched out His hand against them And stricken them, And the hills trembled. Their carcasses were as refuse in the midst of the streets. For all this His anger is not turned away, But His hand is stretched out still.

26. He will lift up a banner to the nations from afar, And will whistle to them from the end of the earth; Surely they shall come with speed, swiftly.

27. No one will be weary or stumble among them, No one will slumber or sleep; Nor will the belt on their loins be loosed, Nor the strap of their sandals be broken;

28. Whose arrows are sharp, And all their bows bent; Their horses' hooves will seem like flint, And their wheels like a whirlwind.

29. Their roaring will be like a lion, They will roar like young lions; Yes, they will roar And lay hold of the prey; They will carry it away safely, And no one will deliver.

30. In that day they will roar against them Like the roaring of the sea. And if one looks to the land, Behold, darkness and sorrow; And the light is darkened by the clouds.

## Chapter 6

1. In the year that King Uzziah died, I saw the Lord sitting on a throne, high and lifted up, and the train of His robe filled the temple.

2. Above it stood seraphim; each one had six wings: with two he covered his face, with two he covered his feet, and with two he flew.

3. And one cried to another and said: "Holy, holy, holy is the LORD of hosts; The whole earth is full of His glory!"

4. And the posts of the door were shaken by the voice of him who cried out, and the house was filled with smoke.

5. So I said: "Woe is me, for I am undone! Because I am a man of unclean lips, And I dwell in the midst of a people of unclean lips; For my eyes have seen the King, The LORD of hosts."

6. Then one of the seraphim flew to me, having in his hand a live coal which he had taken with the tongs from the altar.

7. And he touched my mouth with it, and said: "Behold, this has touched your lips; Your iniquity is taken away, And your sin purged."

8. Also I heard the voice of the Lord, saying: "Whom shall I send, And who will go for Us?" Then I said, "Here am I! Send me."

9. And He said, "Go, and tell this people: "Keep on hearing, but do not understand; Keep on seeing, but do not perceive.'

10. "Make the heart of this people dull, And their ears heavy, And shut their eyes; Lest they see with their eyes, And hear with their ears, And understand with their heart, And return and be healed."

11. Then I said, "Lord, how long?" And He answered: "Until the cities are laid waste and without inhabitant, The houses are without a man, The land is utterly desolate,

12. The LORD has removed men far away, And the forsaken places are many in the midst of the land.

13. But yet a tenth will be in it, And will return and be for consuming, As a terebinth tree or as an oak, Whose stump remains when it is cut down. So the holy seed shall be its stump."

## Chapter 7

1. Now it came to pass in the days of Ahaz the son of Jotham, the son of Uzziah, king of Judah, that Rezin king of Syria and Pekah the son of Remaliah, king of Israel, went up to Jerusalem to make war against it, but could not prevail against it.

2. And it was told to the house of David, saying, "Syria's forces are deployed in Ephraim." So his heart and the heart of his people were moved as the trees of the woods are moved with the wind.

3. Then the LORD said to Isaiah, "Go out now to meet Ahaz, you and Shear-Jashub your son, at the end of the aqueduct from the upper pool, on the highway to the Fuller's Field,

4. and say to him: "Take heed, and be quiet; do not fear or be fainthearted for these two stubs of smoking firebrands, for the fierce anger of Rezin and Syria, and the son of Remaliah.

5. Because Syria, Ephraim, and the son of Remaliah have plotted evil against you, saying,

6. "Let us go up against Judah and trouble it, and let us make a gap in its wall for ourselves, and set a king over them, the son of Tabel"--

7. thus says the Lord GOD: "It shall not stand, Nor shall it come to pass.

8. For the head of Syria is Damascus, And the head of Damascus is Rezin. Within sixty-five years Ephraim will be broken, So that it will not be a people.

9. The head of Ephraim is Samaria, And the head of Samaria is Remaliah's son. If you will not believe, Surely you shall not be established.""'

10. Moreover the LORD spoke again to Ahaz, saying,

11. "Ask a sign for yourself from the LORD your God; ask it either in the depth or in the height above."

12. But Ahaz said, "I will not ask, nor will I test the LORD!"

13. Then he said, "Hear now, O house of David! Is it a small thing for you to weary men, but will you weary my God also?

14. Therefore the Lord Himself will give you a sign: Behold, the virgin shall conceive and bear a Son, and shall call His name Immanuel.

15. Curds and honey He shall eat, that He may know to refuse the evil and choose the good.

16. For before the Child shall know to refuse the evil and choose the good, the land that you dread will be forsaken by both her kings.

17. The LORD will bring the king of Assyria upon you and your people and your father's house--days that have not come since the day that Ephraim departed from Judah."

18. And it shall come to pass in that day That the LORD will whistle for the fly That is in the farthest part of the rivers of Egypt, And for the bee that is in the land of Assyria.

19. They will come, and all of them will rest In the desolate valleys and in the clefts of the rocks, And on all thorns and in all pastures.

20. In the same day the Lord will shave with a hired razor, With those from beyond the River, with the king of Assyria, The head and the hair of the legs, And will also remove the beard.

21. It shall be in that day That a man will keep alive a young cow and two sheep;

22. So it shall be, from the abundance of milk they give, That he will eat curds; For curds and honey everyone will eat who is left in the land.

23. It shall happen in that day, That wherever there could be a thousand vines Worth a thousand shekels of silver, It will be for briers and thorns.

24. With arrows and bows men will come there, Because all the land will become briers and thorns.

25. And to any hill which could be dug with the hoe, You will not go there for fear of briers and thorns; But it will become a range for oxen And a place for sheep to roam.

## Chapter 8

1. Moreover the LORD said to me, "Take a large scroll, and write on it with a man's pen concerning Maher-Shalal-Hash-Baz.

2. And I will take for Myself faithful witnesses to record, Uriah the priest and Zechariah the son of Jeberechiah."

3. Then I went to the prophetess, and she conceived and bore a son. Then the LORD said to me, "Call his name Maher-Shalal-Hash-Baz;

4. for before the child shall have knowledge to cry "My father' and "My mother,' the riches of Damascus and the spoil of Samaria will be taken away before the king of Assyria."

5. The LORD also spoke to me again, saying:

6. "Inasmuch as these people refused The waters of Shiloah that flow softly, And rejoice in Rezin and in Remaliah's son;

7. Now therefore, behold, the Lord brings up over them The waters of the River, strong and mighty-- The king of Assyria and all his glory; He will go up over all his channels And go over all his banks.

8. He will pass through Judah, He will overflow and pass over, He will reach up to the neck; And the stretching out of his wings Will fill the breadth of Your land, O Immanuel.

9. "Be shattered, O you peoples, and be broken in pieces! Give ear, all you from far countries. Gird yourselves, but be broken in pieces; Gird yourselves, but be broken in pieces.

10. Take counsel together, but it will come to nothing; Speak the word, but it will not stand, For God is with us."

11. For the LORD spoke thus to me with a strong hand, and instructed me that I should not walk in the way of this people, saying:

12. "Do not say, "A conspiracy,' Concerning all that this people call a conspiracy, Nor be afraid of their threats, nor be troubled.

13. The LORD of hosts, Him you shall hallow; Let Him be your fear, And let Him be your dread.

14. He will be as a sanctuary, But a stone of stumbling and a rock of offense To both the houses of Israel, As a trap and a snare to the inhabitants of Jerusalem.

15. And many among them shall stumble; They shall fall and be broken, Be snared and taken."

16. Bind up the testimony, Seal the law among my disciples.

17. And I will wait on the LORD, Who hides His face from the house of Jacob; And I will hope in Him.

18. Here am I and the children whom the LORD has given me! We are for signs and wonders in Israel From the LORD of hosts, Who dwells in Mount Zion.

19. And when they say to you, "Seek those who are mediums and wizards, who whisper and mutter," should not a people seek their God? Should they seek the dead on behalf of the living?

20. To the law and to the testimony! If they do not speak according to this word, it is because there is no light in them.

21. They will pass through it hard-pressed and hungry; and it shall happen, when they are hungry, that they will be enraged and curse their king and their God, and look upward.

22. Then they will look to the earth, and see trouble and darkness, gloom of anguish; and they will be driven into darkness.

## Chapter 9

1. Nevertheless the gloom will not be upon her who is distressed, As when at first He lightly esteemed The land of Zebulun and the land of Naphtali, And afterward more heavily oppressed her, By the way of the sea, beyond the Jordan, In Galilee of the Gentiles.

2. The people who walked in darkness Have seen a great light; Those who dwelt in the land of the shadow of death, Upon them a light has shined.

3. You have multiplied the nation And increased its joy; They rejoice before You According to the joy of harvest, As men rejoice when they divide the spoil.

4. For You have broken the yoke of his burden And the staff of his shoulder, The rod of his oppressor, As in the day of Midian.

5. For every warrior's sandal from the noisy battle, And garments rolled in blood, Will be used for burning and fuel of fire.

6. For unto us a Child is born, Unto us a Son is given; And the government will be upon His shoulder. And His name will be called Wonderful, Counselor, Mighty God, Everlasting Father, Prince of Peace.

7. Of the increase of His government and peace There will be no end, Upon the throne of David and over His kingdom, To order it and establish it with judgment and justice From that time forward, even forever. The zeal of the Lord of hosts will perform this.

8. The LORD sent a word against Jacob, And it has fallen on Israel.

9. All the people will know-- Ephraim and the inhabitant of Samaria-- Who say in pride and arrogance of heart:

10. "The bricks have fallen down, But we will rebuild with hewn stones; The sycamores are cut down, But we will replace them with cedars."

11. Therefore the LORD shall set up The adversaries of Rezin against him, And spur his enemies on,

12. The Syrians before and the Philistines behind; And they shall devour Israel with an open mouth. For all this His anger is not turned away, But His hand is stretched out still.

13. For the people do not turn to Him who strikes them, Nor do they seek the LORD of hosts.

14. Therefore the LORD will cut off head and tail from Israel, Palm branch and bulrush in one day.

15. The elder and honorable, he is the head; The prophet who teaches lies, he is the tail.

16. For the leaders of this people cause them to err, And those who are led by them are destroyed.

17. Therefore the Lord will have no joy in their young men, Nor have mercy on their fatherless and widows; For everyone is a hypocrite and an evildoer, And every mouth speaks folly. For all this His anger is not turned away, But His hand is stretched out still.

18. For wickedness burns as the fire; It shall devour the briers and thorns, And kindle in the thickets of the forest; They shall mount up like rising smoke.

19. Through the wrath of the LORD of hosts The land is burned up, And the people shall be as fuel for the fire; No man shall spare his brother.

20. And he shall snatch on the right hand And be hungry; He shall devour on the left hand And not be satisfied; Every man shall eat the flesh of his own arm.

21. Manasseh shall devour Ephraim, and Ephraim Manasseh; Together they shall be against Judah. For all this His anger is not turned away, But His hand is stretched out still.

## Chapter 10

1. "Woe to those who decree unrighteous decrees, Who write misfortune, Which they have prescribed

2. To rob the needy of justice, And to take what is right from the poor of My people, That widows may be their prey, And that they may rob the fatherless.

3. What will you do in the day of punishment, And in the desolation which will come from afar? To whom will you flee for help? And where will you leave your glory?

4. Without Me they shall bow down among the prisoners, And they shall fall among the slain." For all this His anger is not turned away, But His hand is stretched out still.

5. "Woe to Assyria, the rod of My anger And the staff in whose hand is My indignation.

6. I will send him against an ungodly nation, And against the people of My wrath I will give him charge, To seize the spoil, to take the prey, And to tread them down like the mire of the streets.

7. Yet he does not mean so, Nor does his heart think so; But it is in his heart to destroy, And cut off not a few nations.

8. For he says, "Are not my princes altogether kings?

9. Is not Calno like Carchemish? Is not Hamath like Arpad? Is not Samaria like Damascus?

10. As my hand has found the kingdoms of the idols, Whose carved images excelled those of Jerusalem and Samaria,

11. As I have done to Samaria and her idols, Shall I not do also to Jerusalem and her idols?"'

12. Therefore it shall come to pass, when the Lord has performed all His work on Mount Zion and on Jerusalem, that He will say, "I will punish the fruit of the arrogant heart of the king of Assyria, and the glory of his haughty looks."

13. For he says: "By the strength of my hand I have done it, And by my wisdom, for I am prudent; Also I have removed the boundaries of the people, And have robbed their treasuries; So I have put down the inhabitants like a valiant man.

14. My hand has found like a nest the riches of the people, And as one gathers eggs that are left, I have gathered all the earth; And there was no one who moved his wing, Nor opened his mouth with even a peep."

15. Shall the ax boast itself against him who chops with it? Or shall the saw exalt itself against him who saws with it? As if a rod could wield itself against those who lift it up, Or as if a staff could lift up, as if it were not wood!

16. Therefore the Lord, the Lord of hosts, Will send leanness among his fat ones; And under his glory He will kindle a burning Like the burning of a fire.

17. So the Light of Israel will be for a fire, And his Holy One for a flame; It will burn and devour His thorns and his briers in one day.

18. And it will consume the glory of his forest and of his fruitful field, Both soul and body; And they will be as when a sick man wastes away.

19. Then the rest of the trees of his forest Will be so few in number That a child may write them.

20. And it shall come to pass in that day That the remnant of Israel, And such as have escaped of the house of Jacob, Will never again depend on him who defeated them, But will depend on the LORD, the Holy One of Israel, in truth.

21. The remnant will return, the remnant of Jacob, To the Mighty God.

22. For though your people, O Israel, be as the sand of the sea, A remnant of them will return; The destruction decreed shall overflow with righteousness.

23. For the Lord GOD of hosts Will make a determined end In the midst of all the land.

24. Therefore thus says the Lord GOD of hosts: "O My people, who dwell in Zion, do not be afraid of the Assyrian. He shall strike you with a rod and lift up his staff against you, in the manner of Egypt.

25. For yet a very little while and the indignation will cease, as will My anger in their destruction."

26. And the LORD of hosts will stir up a scourge for him like the slaughter of Midian at the rock of Oreb; as His rod was on the sea, so will He lift it up in the manner of Egypt.

27. It shall come to pass in that day That his burden will be taken away from your shoulder, And his yoke from your neck, And the yoke will be destroyed because of the anointing oil.

28. He has come to Aiath, He has passed Migron; At Michmash he has attended to his equipment.

29. They have gone along the ridge, They have taken up lodging at Geba. Ramah is afraid, Gibeah of Saul has fled.

30. Lift up your voice, O daughter of Gallim! Cause it to be heard as far as Laish-- O poor Anathoth!

31. Madmenah has fled, The inhabitants of Gebim seek refuge.

32. As yet he will remain at Nob that day; He will shake his fist at the mount of the daughter of Zion, The hill of Jerusalem.

33. Behold, the Lord, The LORD of hosts, Will lop off the bough with terror; Those of high stature will be hewn down, And the haughty will be humbled.

34. He will cut down the thickets of the forest with iron, And Lebanon will fall by the Mighty One.

## Chapter 11

1. There shall come forth a Rod from the stem of Jesse, And a Branch shall grow out of his roots.

2. The Spirit of the LORD shall rest upon Him, The Spirit of wisdom and understanding, The Spirit of counsel and might, The Spirit of knowledge and of the fear of the LORD.

3. His delight is in the fear of the LORD, And He shall not judge by the sight of His eyes, Nor decide by the hearing of His ears;

4. But with righteousness He shall judge the poor, And decide with equity for the meek of the earth; He shall strike the earth with the rod of His mouth, And with the breath of His lips He shall slay the wicked.

5. Righteousness shall be the belt of His loins, And faithfulness the belt of His waist.

6. "The wolf also shall dwell with the lamb, The leopard shall lie down with the young goat, The calf and the young lion and the fatling together; And a little child shall lead them.

7. The cow and the bear shall graze; Their young ones shall lie down together; And the lion shall eat straw like the ox.

8. The nursing child shall play by the cobra's hole, And the weaned child shall put his hand in the viper's den.

9. They shall not hurt nor destroy in all My holy mountain, For the earth shall be full of the knowledge of the LORD As the waters cover the sea.

10. "And in that day there shall be a Root of Jesse, Who shall stand as a banner to the people; For the Gentiles shall seek Him, And His resting place shall be glorious."

11. It shall come to pass in that day That the Lord shall set His hand again the second time To recover the remnant of His people who are left, From Assyria and Egypt, From Pathros and Cush, From Elam and Shinar, From Hamath and the islands of the sea.

12. He will set up a banner for the nations, And will assemble the outcasts of Israel, And gather together the dispersed of Judah From the four corners of the earth.

13. Also the envy of Ephraim shall depart, And the adversaries of Judah shall be cut off; Ephraim shall not envy Judah, And Judah shall not harass Ephraim.

14. But they shall fly down upon the shoulder of the Philistines toward the west; Together they shall plunder the people of the East; They shall lay their hand on Edom and Moab; And the people of Ammon shall obey them.

15. The LORD will utterly destroy the tongue of the Sea of Egypt; With His mighty wind He will shake His fist over the River, And strike it in the seven streams, And make men cross over dryshod.

16. There will be a highway for the remnant of His people Who will be left from Assyria, As it was for Israel In the day that he came up from the land of Egypt.

## Chapter 12

1. And in that day you will say: "O LORD, I will praise You; Though You were angry with me, Your anger is turned away, and You comfort me.

2. Behold, God is my salvation, I will trust and not be afraid; "For YAH, the LORD, is my strength and song; He also has become my salvation."'

3. Therefore with joy you will draw water From the wells of salvation.

4. And in that day you will say: "Praise the LORD, call upon His name; Declare His deeds among the peoples, Make mention that His name is exalted.

5. Sing to the LORD, For He has done excellent things; This is known in all the earth.

6. Cry out and shout, O inhabitant of Zion, For great is the Holy One of Israel in your midst!"

## Chapter 13

1. The burden against Babylon which Isaiah the son of Amoz saw.

2. "Lift up a banner on the high mountain, Raise your voice to them; Wave your hand, that they may enter the gates of the nobles.

3. I have commanded My sanctified ones; I have also called My mighty ones for My anger-- Those who rejoice in My exaltation."

4. The noise of a multitude in the mountains, Like that of many people! A tumultuous noise of the kingdoms of nations gathered together! The LORD of hosts musters The army for battle.

5. They come from a far country, From the end of heaven-- The LORD and His weapons of indignation, To destroy the whole land.

6. Wail, for the day of the LORD is at hand! It will come as destruction from the Almighty.

7. Therefore all hands will be limp, Every man's heart will melt,

8. And they will be afraid. Pangs and sorrows will take hold of them; They will be in pain as a woman in childbirth; They will be amazed at one another; Their faces will be like flames.

9. Behold, the day of the LORD comes, Cruel, with both wrath and fierce anger, To lay the land desolate; And He will destroy its sinners from it.

10. For the stars of heaven and their constellations Will not give their light; The sun will be darkened in its going forth, And the moon will not cause its light to shine.

11. "I will punish the world for its evil, And the wicked for their iniquity; I will halt the arrogance of the proud, And will lay low the haughtiness of the terrible.

12. I will make a mortal more rare than fine gold, A man more than the golden wedge of Ophir.

13. Therefore I will shake the heavens, And the earth will move out of her place, In the wrath of the LORD of hosts And in the day of His fierce anger.

14. It shall be as the hunted gazelle, And as a sheep that no man takes up; Every man will turn to his own people, And everyone will flee to his own land.

15. Everyone who is found will be thrust through, And everyone who is captured will fall by the sword.

16. Their children also will be dashed to pieces before their eyes; Their houses will be plundered And their wives ravished.

17. "Behold, I will stir up the Medes against them, Who will not regard silver; And as for gold, they will not delight in it.

18. Also their bows will dash the young men to pieces, And they will have no pity on the fruit of the womb; Their eye will not spare children.

19. And Babylon, the glory of kingdoms, The beauty of the Chaldeans' pride, Will be as when God overthrew Sodom and Gomorrah.

20. It will never be inhabited, Nor will it be settled from generation to generation; Nor will the Arabian pitch tents there, Nor will the shepherds make their sheepfolds there.

21. But wild beasts of the desert will lie there, And their houses will be full of owls; Ostriches will dwell there, And wild goats will caper there.

22. The hyenas will howl in their citadels, And jackals in their pleasant palaces. Her time is near to come, And her days will not be prolonged."

## Chapter 14

1. For the LORD will have mercy on Jacob, and will still choose Israel, and settle them in their own land. The strangers will be joined with them, and they will cling to the house of Jacob.

2. Then people will take them and bring them to their place, and the house of Israel will possess them for servants and maids in the land of the LORD; they will take them captive whose captives they were, and rule over their oppressors.

3. It shall come to pass in the day the LORD gives you rest from your sorrow, and from your fear and the hard bondage in which you were made to serve,

4. that you will take up this proverb against the king of Babylon, and say: "How the oppressor has ceased, The golden city ceased!

5. The LORD has broken the staff of the wicked, The scepter of the rulers;

6. He who struck the people in wrath with a continual stroke, He who ruled the nations in anger, Is persecuted and no one hinders.

7. The whole earth is at rest and quiet; They break forth into singing.

8. Indeed the cypress trees rejoice over you, And the cedars of Lebanon, Saying, "Since you were cut down, No woodsman has come up against us.'

9. "Hell from beneath is excited about you, To meet you at your coming; It stirs up the dead for you, All the chief ones of the earth; It has raised up from their thrones All the kings of the nations.

10. They all shall speak and say to you: "Have you also become as weak as we? Have you become like us?

11. Your pomp is brought down to Sheol, And the sound of your stringed instruments; The maggot is spread under you, And worms cover you.'

12. "How you are fallen from heaven, O Lucifer, son of the morning! How you are cut down to the ground, You who weakened the nations!

13. For you have said in your heart: "I will ascend into heaven, I will exalt my throne above the stars of God; I will also sit on the mount of the congregation On the farthest sides of the north;

14. I will ascend above the heights of the clouds, I will be like the Most High.'

15. Yet you shall be brought down to Sheol, To the lowest depths of the Pit.

16. "Those who see you will gaze at you, And consider you, saying: "Is this the man who made the earth tremble, Who shook kingdoms,

17. Who made the world as a wilderness And destroyed its cities, Who did not open the house of his prisoners?'

18. "All the kings of the nations, All of them, sleep in glory, Everyone in his own house;

19. But you are cast out of your grave Like an abominable branch, Like the garment of those who are slain, Thrust through with a sword, Who go down to the stones of the pit, Like a corpse trodden underfoot.

20. You will not be joined with them in burial, Because you have destroyed your land And slain your people. The brood of evildoers shall never be named.

21. Prepare slaughter for his children Because of the iniquity of their fathers, Lest they rise up and possess the land, And fill the face of the world with cities."

22. "For I will rise up against them," says the LORD of hosts, "And cut off from Babylon the name and remnant, And offspring and posterity," says the LORD.

23. "I will also make it a possession for the porcupine, And marshes of muddy water; I will sweep it with the broom of destruction," says the LORD of hosts.

24. The LORD of hosts has sworn, saying, "Surely, as I have thought, so it shall come to pass, And as I have purposed, so it shall stand:

25. That I will break the Assyrian in My land, And on My mountains tread him underfoot. Then his yoke shall be removed from them, And his burden removed from their shoulders.

26. This is the purpose that is purposed against the whole earth, And this is the hand that is stretched out over all the nations.

27. For the LORD of hosts has purposed, And who will annul it? His hand is stretched out, And who will turn it back?"

28. This is the burden which came in the year that King Ahaz died.

29. "Do not rejoice, all you of Philistia, Because the rod that struck you is broken; For out of the serpent's roots will come forth a viper, And its offspring will be a fiery flying serpent.

30. The firstborn of the poor will feed, And the needy will lie down in safety; I will kill your roots with famine, And it will slay your remnant.

31. Wail, O gate! Cry, O city! All you of Philistia are dissolved; For smoke will come from the north, And no one will be alone in his appointed times."

32. What will they answer the messengers of the nation? That the LORD has founded Zion, And the poor of His people shall take refuge in it.

## Chapter 15

1. The burden against Moab. Because in the night Ar of Moab is laid waste And destroyed, Because in the night Kir of Moab is laid waste And destroyed,

2. He has gone up to the temple and Dibon, To the high places to weep. Moab will wail over Nebo and over Medeba; On all their heads will be baldness, And every beard cut off.

3. In their streets they will clothe themselves with sackcloth; On the tops of their houses And in their streets Everyone will wail, weeping bitterly.

4. Heshbon and Elealeh will cry out, Their voice shall be heard as far as Jahaz; Therefore the armed soldiers of Moab will cry out; His life will be burdensome to him.

5. "My heart will cry out for Moab; His fugitives shall flee to Zoar, Like a three-year-old heifer. For by the Ascent of Luhith They will go up with weeping; For in the way of Horonaim They will raise up a cry of destruction,

6. For the waters of Nimrim will be desolate, For the green grass has withered away; The grass fails, there is nothing green.

7. Therefore the abundance they have gained, And what they have laid up, They will carry away to the Brook of the Willows.

8. For the cry has gone all around the borders of Moab, Its wailing to Eglaim And its wailing to Beer Elim.

9. For the waters of Dimon will be full of blood; Because I will bring more upon Dimon, Lions upon him who escapes from Moab, And on the remnant of the land."

## Chapter 16

1. Send the lamb to the ruler of the land, From Sela to the wilderness, To the mount of the daughter of Zion.

2. For it shall be as a wandering bird thrown out of the nest; So shall be the daughters of Moab at the fords of the Arnon.

3. "Take counsel, execute judgment; Make your shadow like the night in the middle of the day; Hide the outcasts, Do not betray him who escapes.

4. Let My outcasts dwell with you, O Moab; Be a shelter to them from the face of the spoiler. For the extortioner is at an end, Devastation ceases, The oppressors are consumed out of the land.

5. In mercy the throne will be established; And One will sit on it in truth, in the tabernacle of David, Judging and seeking justice and hastening righteousness."

6. We have heard of the pride of Moab-- He is very proud-- Of his haughtiness and his pride and his wrath; But his lies shall not be so.

7. Therefore Moab shall wail for Moab; Everyone shall wail. For the foundations of Kir Hareseth you shall mourn; Surely they are stricken.

8. For the fields of Heshbon languish, And the vine of Sibmah; The lords of the nations have broken down its choice plants, Which have reached to Jazer And wandered through the wilderness. Her branches are stretched out, They are gone over the sea.

9. Therefore I will bewail the vine of Sibmah, With the weeping of Jazer; I will drench you with my tears, O Heshbon and Elealeh; For battle cries have fallen Over your summer fruits and your harvest.

10. Gladness is taken away, And joy from the plentiful field; In the vineyards there will be no singing, Nor will there be shouting; No treaders will tread out wine in the presses; I have made their shouting cease.

11. Therefore my heart shall resound like a harp for Moab, And my inner being for Kir Heres.

12. And it shall come to pass, When it is seen that Moab is weary on the high place, That he will come to his sanctuary to pray; But he will not prevail.

13. This is the word which the LORD has spoken concerning Moab since that time.

14. But now the LORD has spoken, saying, "Within three years, as the years of a hired man, the glory of Moab will be despised with all that great multitude, and the remnant will be very small and feeble."

## Chapter 17

1. The burden against Damascus. "Behold, Damascus will cease from being a city, And it will be a ruinous heap.

2. The cities of Aroer are forsaken; They will be for flocks Which lie down, and no one will make them afraid.

3. The fortress also will cease from Ephraim, The kingdom from Damascus, And the remnant of Syria; They will be as the glory of the children of Israel," Says the LORD of hosts.

4. "In that day it shall come to pass That the glory of Jacob will wane, And the fatness of his flesh grow lean.

5. It shall be as when the harvester gathers the grain, And reaps the heads with his arm; It shall be as he who gathers heads of grain In the Valley of Rephaim.

6. Yet gleaning grapes will be left in it, Like the shaking of an olive tree, Two or three olives at the top of the uppermost bough, Four or five in its most fruitful branches," Says the LORD God of Israel.

7. In that day a man will look to his Maker, And his eyes will have respect for the Holy One of Israel.

8. He will not look to the altars, The work of his hands; He will not respect what his fingers have made, Nor the wooden images nor the incense altars.

9. In that day his strong cities will be as a forsaken bough And an uppermost branch, Which they left because of the children of Israel; And there will be desolation.

10. Because you have forgotten the God of your salvation, And have not been mindful of the Rock of your stronghold, Therefore you will plant pleasant plants And set out foreign seedlings;

11. In the day you will make your plant to grow, And in the morning you will make your seed to flourish; But the harvest will be a heap of ruins In the day of grief and desperate sorrow.

12. Woe to the multitude of many people Who make a noise like the roar of the seas, And to the rushing of nations That make a rushing like the rushing of mighty waters!

13. The nations will rush like the rushing of many waters; But God will rebuke them and they will flee far away, And be chased like the chaff of the mountains before the wind, Like a rolling thing before the whirlwind.

14. Then behold, at eventide, trouble! And before the morning, he is no more. This is the portion of those who plunder us, And the lot of those who rob us.

## Chapter 18

1. Woe to the land shadowed with buzzing wings, Which is beyond the rivers of Ethiopia,

2. Which sends ambassadors by sea, Even in vessels of reed on the waters, saying, "Go, swift messengers, to a nation tall and smooth of skin, To a people terrible from their beginning onward, A nation powerful and treading down, Whose land the rivers divide."

3. All inhabitants of the world and dwellers on the earth: When he lifts up a banner on the mountains, you see it; And when he blows a trumpet, you hear it.

4. For so the LORD said to me, "I will take My rest, And I will look from My dwelling place Like clear heat in sunshine, Like a cloud of dew in the heat of harvest."

5. For before the harvest, when the bud is perfect And the sour grape is ripening in the flower, He will both cut off the sprigs with pruning hooks And take away and cut down the branches.

6. They will be left together for the mountain birds of prey And for the beasts of the earth; The birds of prey will summer on them, And all the beasts of the earth will winter on them.

7. In that time a present will be brought to the LORD of hosts From a people tall and smooth of skin, And from a people terrible from their beginning onward, A nation powerful and treading down, Whose land the rivers divide-- To the place of the name of the LORD of hosts, To Mount Zion.

## Chapter 19

1. The burden against Egypt. Behold, the LORD rides on a swift cloud, And will come into Egypt; The idols of Egypt will totter at His presence, And the heart of Egypt will melt in its midst.

2. "I will set Egyptians against Egyptians; Everyone will fight against his brother, And everyone against his neighbor, City against city, kingdom against kingdom.

3. The spirit of Egypt will fail in its midst; I will destroy their counsel, And they will consult the idols and the charmers, The mediums and the sorcerers.

4. And the Egyptians I will give Into the hand of a cruel master, And a fierce king will rule over them," Says the Lord, the LORD of hosts.

5. The waters will fail from the sea, And the river will be wasted and dried up.

6. The rivers will turn foul; The brooks of defense will be emptied and dried up; The reeds and rushes will wither.

7. The papyrus reeds by the River, by the mouth of the River, And everything sown by the River, Will wither, be driven away, and be no more.

8. The fishermen also will mourn; All those will lament who cast hooks into the River, And they will languish who spread nets on the waters.

9. Moreover those who work in fine flax And those who weave fine fabric will be ashamed;

10. And its foundations will be broken. All who make wages will be troubled of soul.

11. Surely the princes of Zoan are fools; Pharaoh's wise counselors give foolish counsel. How do you say to Pharaoh, "I am the son of the wise, The son of ancient kings?"

12. Where are they? Where are your wise men? Let them tell you now, And let them know what the LORD of hosts has purposed against Egypt.

13. The princes of Zoan have become fools; The princes of Noph are deceived; They have also deluded Egypt, Those who are the mainstay of its tribes.

14. The LORD has mingled a perverse spirit in her midst; And they have caused Egypt to err in all her work, As a drunken man staggers in his vomit.

15. Neither will there be any work for Egypt, Which the head or tail, Palm branch or bulrush, may do.

16. In that day Egypt will be like women, and will be afraid and fear because of the waving of the hand of the LORD of hosts, which He waves over it.

17. And the land of Judah will be a terror to Egypt; everyone who makes mention of it will be afraid in himself, because of the counsel of the LORD of hosts which He has determined against it.

18. In that day five cities in the land of Egypt will speak the language of Canaan and swear by the LORD of hosts; one will be called the City of Destruction.

19. In that day there will be an altar to the LORD in the midst of the land of Egypt, and a pillar to the LORD at its border.

20. And it will be for a sign and for a witness to the LORD of hosts in the land of Egypt; for they will cry to the LORD because of the oppressors, and He will send them a Savior and a Mighty One, and He will deliver them.

21. Then the LORD will be known to Egypt, and the Egyptians will know the LORD in that day, and will make sacrifice and offering; yes, they will make a vow to the LORD and perform it.

22. And the LORD will strike Egypt, He will strike and heal it; they will return to the LORD, and He will be entreated by them and heal them.

23. In that day there will be a highway from Egypt to Assyria, and the Assyrian will come into Egypt and the Egyptian into Assyria, and the Egyptians will serve with the Assyrians.

24. In that day Israel will be one of three with Egypt and Assyria--a blessing in the midst of the land,

25. whom the LORD of hosts shall bless, saying, "Blessed is Egypt My people, and Assyria the work of My hands, and Israel My inheritance."

## Chapter 20

1. In the year that Tartan came to Ashdod, when Sargon the king of Assyria sent him, and he fought against Ashdod and took it,

2. at the same time the LORD spoke by Isaiah the son of Amoz, saying, "Go, and remove the sackcloth from your body, and take your sandals off your feet." And he did so, walking naked and barefoot.

3. Then the LORD said, "Just as My servant Isaiah has walked naked and barefoot three years for a sign and a wonder against Egypt and Ethiopia,

4. so shall the king of Assyria lead away the Egyptians as prisoners and the Ethiopians as captives, young and old, naked and barefoot, with their buttocks uncovered, to the shame of Egypt.

5. Then they shall be afraid and ashamed of Ethiopia their expectation and Egypt their glory.

6. And the inhabitant of this territory will say in that day, "Surely such is our expectation, wherever we flee for help to be delivered from the king of Assyria; and how shall we escape?"'

## Chapter 21

1. The burden against the Wilderness of the Sea. As whirlwinds in the South pass through, So it comes from the desert, from a terrible land.

2. A distressing vision is declared to me; The treacherous dealer deals treacherously, And the plunderer plunders. Go up, O Elam! Besiege, O Media! All its sighing I have made to cease.

3. Therefore my loins are filled with pain; Pangs have taken hold of me, like the pangs of a woman in labor. I was distressed when I heard it; I was dismayed when I saw it.

4. My heart wavered, fearfulness frightened me; The night for which I longed He turned into fear for me.

5. Prepare the table, Set a watchman in the tower, Eat and drink. Arise, you princes, Anoint the shield!

6. For thus has the Lord said to me: "Go, set a watchman, Let him declare what he sees."

7. And he saw a chariot with a pair of horsemen, A chariot of donkeys, and a chariot of camels, And he listened earnestly with great care.

8. Then he cried, "A lion, my Lord! I stand continually on the watchtower in the daytime; I have sat at my post every night.

9. And look, here comes a chariot of men with a pair of horsemen!" Then he answered and said, "Babylon is fallen, is fallen! And all the carved images of her gods He has broken to the ground."

10. Oh, my threshing and the grain of my floor! That which I have heard from the LORD of hosts, The God of Israel, I have declared to you.

11. The burden against Dumah. He calls to me out of Seir, "Watchman, what of the night? Watchman, what of the night?"

12. The watchman said, "The morning comes, and also the night. If you will inquire, inquire; Return! Come back!"

13. The burden against Arabia. In the forest in Arabia you will lodge, O you traveling companies of Dedanites.

14. O inhabitants of the land of Tema, Bring water to him who is thirsty; With their bread they met him who fled.

15. For they fled from the swords, from the drawn sword, From the bent bow, and from the distress of war.

16. For thus the LORD has said to me: "Within a year, according to the year of a hired man, all the glory of Kedar will fail;

17. and the remainder of the number of archers, the mighty men of the people of Kedar, will be diminished; for the LORD God of Israel has spoken it."

## Chapter 22

1. The burden against the Valley of Vision. What ails you now, that you have all gone up to the housetops,

2. You who are full of noise, A tumultuous city, a joyous city? Your slain men are not slain with the sword, Nor dead in battle.

3. All your rulers have fled together; They are captured by the archers. All who are found in you are bound together; They have fled from afar.

4. Therefore I said, "Look away from me, I will weep bitterly; Do not labor to comfort me Because of the plundering of the daughter of my people."

5. For it is a day of trouble and treading down and perplexity By the Lord GOD of hosts In the Valley of Vision-- Breaking down the walls And of crying to the mountain.

6. Elam bore the quiver With chariots of men and horsemen, And Kir uncovered the shield.

7. It shall come to pass that your choicest valleys Shall be full of chariots, And the horsemen shall set themselves in array at the gate.

8. He removed the protection of Judah. You looked in that day to the armor of the House of the Forest;

9. You also saw the damage to the city of David, That it was great; And you gathered together the waters of the lower pool.

10. You numbered the houses of Jerusalem, And the houses you broke down To fortify the wall.

11. You also made a reservoir between the two walls For the water of the old pool. But you did not look to its Maker, Nor did you have respect for Him who fashioned it long ago.

12. And in that day the Lord GOD of hosts Called for weeping and for mourning, For baldness and for girding with sackcloth.

13. But instead, joy and gladness, Slaying oxen and killing sheep, Eating meat and drinking wine: "Let us eat and drink, for tomorrow we die!"

14. Then it was revealed in my hearing by the LORD of hosts, "Surely for this iniquity there will be no atonement for you, Even to your death," says the Lord GOD of hosts.

15. Thus says the Lord GOD of hosts: "Go, proceed to this steward, To Shebna, who is over the house, and say:

16. "What have you here, and whom have you here, That you have hewn a sepulcher here, As he who hews himself a sepulcher on high, Who carves a tomb for himself in a rock?

17. Indeed, the LORD will throw you away violently, O mighty man, And will surely seize you.

18. He will surely turn violently and toss you like a ball Into a large country; There you shall die, and there your glorious chariots Shall be the shame of your master's house.

19. So I will drive you out of your office, And from your position he will pull you down.

20. "Then it shall be in that day, That I will call My servant Eliakim the son of Hilkiah;

21. I will clothe him with your robe And strengthen him with your belt; I will commit your responsibility into his hand. He shall be a father to the inhabitants of Jerusalem And to the house of Judah.

22. The key of the house of David I will lay on his shoulder; So he shall open, and no one shall shut; And he shall shut, and no one shall open.

23. I will fasten him as a peg in a secure place, And he will become a glorious throne to his father's house.

24. "They will hang on him all the glory of his father's house, the offspring and the posterity, all vessels of small quantity, from the cups to all the pitchers.

25. In that day,' says the LORD of hosts, "the peg that is fastened in the secure place will be removed and be cut down and fall, and the burden that was on it will be cut off; for the LORD has spoken."'

## Chapter 23

1. The burden against Tyre. Wail, you ships of Tarshish! For it is laid waste, So that there is no house, no harbor; From the land of Cyprus it is revealed to them.

2. Be still, you inhabitants of the coastland, You merchants of Sidon, Whom those who cross the sea have filled.

3. And on great waters the grain of Shihor, The harvest of the River, is her revenue; And she is a marketplace for the nations.

4. Be ashamed, O Sidon; For the sea has spoken, The strength of the sea, saying, "I do not labor, nor bring forth children; Neither do I rear young men, Nor bring up virgins."

5. When the report reaches Egypt, They also will be in agony at the report of Tyre.

6. Cross over to Tarshish; Wail, you inhabitants of the coastland!

7. Is this your joyous city, Whose antiquity is from ancient days, Whose feet carried her far off to dwell?

8. Who has taken this counsel against Tyre, the crowning city, Whose merchants are princes, Whose traders are the honorable of the earth?

9. The LORD of hosts has purposed it, To bring to dishonor the pride of all glory, To bring into contempt all the honorable of the earth.

10. Overflow through your land like the River, O daughter of Tarshish; There is no more strength.

11. He stretched out His hand over the sea, He shook the kingdoms; The LORD has given a commandment against Canaan To destroy its strongholds.

12. And He said, "You will rejoice no more, O you oppressed virgin daughter of Sidon. Arise, cross over to Cyprus; There also you will have no rest."

13. Behold, the land of the Chaldeans, This people which was not; Assyria founded it for wild beasts of the desert. They set up its towers, They raised up its palaces, And brought it to ruin.

14. Wail, you ships of Tarshish! For your strength is laid waste.

15. Now it shall come to pass in that day that Tyre will be forgotten seventy years, according to the days of one king. At the end of seventy years it will happen to Tyre as in the song of the harlot:

16. "Take a harp, go about the city, You forgotten harlot; Make sweet melody, sing many songs, That you may be remembered."

17. And it shall be, at the end of seventy years, that the LORD will deal with Tyre. She will return to her hire, and commit fornication with all the kingdoms of the world on the face of the earth.

18. Her gain and her pay will be set apart for the LORD; it will not be treasured nor laid up, for her gain will be for those who dwell before the LORD, to eat sufficiently, and for fine clothing.

## Chapter 24

1. Behold, the LORD makes the earth empty and makes it waste, Distorts its surface And scatters abroad its inhabitants.

2. And it shall be: As with the people, so with the priest; As with the servant, so with his master; As with the maid, so with her mistress; As with the buyer, so with the seller; As with the lender, so with the borrower; As with the creditor, so with the debtor.

3. The land shall be entirely emptied and utterly plundered, For the LORD has spoken this word.

4. The earth mourns and fades away, The world languishes and fades away; The haughty people of the earth languish.

5. The earth is also defiled under its inhabitants, Because they have transgressed the laws, Changed the ordinance, Broken the everlasting covenant.

6. Therefore the curse has devoured the earth, And those who dwell in it are desolate. Therefore the inhabitants of the earth are burned, And few men are left.

7. The new wine fails, the vine languishes, All the merry-hearted sigh.

8. The mirth of the tambourine ceases, The noise of the jubilant ends, The joy of the harp ceases.

9. They shall not drink wine with a song; Strong drink is bitter to those who drink it.

10. The city of confusion is broken down; Every house is shut up, so that none may go in.

11. There is a cry for wine in the streets, All joy is darkened, The mirth of the land is gone.

12. In the city desolation is left, And the gate is stricken with destruction.

13. When it shall be thus in the midst of the land among the people, It shall be like the shaking of an olive tree, Like the gleaning of grapes when the vintage is done.

14. They shall lift up their voice, they shall sing; For the majesty of the LORD They shall cry aloud from the sea.

15. Therefore glorify the LORD in the dawning light, The name of the LORD God of Israel in the coastlands of the sea.

16. From the ends of the earth we have heard songs: "Glory to the righteous!" But I said, "I am ruined, ruined! Woe to me! The treacherous dealers have dealt treacherously, Indeed, the treacherous dealers have dealt very treacherously."

17. Fear and the pit and the snare Are upon you, O inhabitant of the earth.

18. And it shall be That he who flees from the noise of the fear Shall fall into the pit, And he who comes up from the midst of the pit Shall be caught in the snare; For the windows from on high are open, And the foundations of the earth are shaken.

19. The earth is violently broken, The earth is split open, The earth is shaken exceedingly.

20. The earth shall reel to and fro like a drunkard, And shall totter like a hut; Its transgression shall be heavy upon it, And it will fall, and not rise again.

21. It shall come to pass in that day That the LORD will punish on high the host of exalted ones, And on the earth the kings of the earth.

22. They will be gathered together, As prisoners are gathered in the pit, And will be shut up in the prison; After many days they will be punished.

23. Then the moon will be disgraced And the sun ashamed; For the LORD of hosts will reign On Mount Zion and in Jerusalem And before His elders, gloriously.

## Chapter 25

1. O LORD, You are my God. I will exalt You, I will praise Your name, For You have done wonderful things; Your counsels of old are faithfulness and truth.

2. For You have made a city a ruin, A fortified city a ruin, A palace of foreigners to be a city no more; It will never be rebuilt.

3. Therefore the strong people will glorify You; The city of the terrible nations will fear You.

4. For You have been a strength to the poor, A strength to the needy in his distress, A refuge from the storm, A shade from the heat; For the blast of the terrible ones is as a storm against the wall.

5. You will reduce the noise of aliens, As heat in a dry place; As heat in the shadow of a cloud, The song of the terrible ones will be diminished.

6. And in this mountain The LORD of hosts will make for all people A feast of choice pieces, A feast of wines on the lees, Of fat things full of marrow, Of well-refined wines on the lees.

7. And He will destroy on this mountain The surface of the covering cast over all people, And the veil that is spread over all nations.

8. He will swallow up death forever, And the Lord GOD will wipe away tears from all faces; The rebuke of His people He will take away from all the earth; For the LORD has spoken.

9. And it will be said in that day: "Behold, this is our God; We have waited for Him, and He will save us. This is the LORD; We have waited for Him; We will be glad and rejoice in His salvation."

10. For on this mountain the hand of the LORD will rest, And Moab shall be trampled down under Him, As straw is trampled down for the refuse heap.

11. And He will spread out His hands in their midst As a swimmer reaches out to swim, And He will bring down their pride Together with the trickery of their hands.

12. The fortress of the high fort of your walls He will bring down, lay low, And bring to the ground, down to the dust.

## Chapter 26

1. In that day this song will be sung in the land of Judah: "We have a strong city; God will appoint salvation for walls and bulwarks.

2. Open the gates, That the righteous nation which keeps the truth may enter in.

3. You will keep him in perfect peace, Whose mind is stayed on You, Because he trusts in You.

4. Trust in the LORD forever, For in Yah, the LORD, is everlasting strength.

5. For He brings down those who dwell on high, The lofty city; He lays it low, He lays it low to the ground, He brings it down to the dust.

6. The foot shall tread it down-- The feet of the poor And the steps of the needy."

7. The way of the just is uprightness; O Most Upright, You weigh the path of the just.

8. Yes, in the way of Your judgments, O LORD, we have waited for You; The desire of our soul is for Your name And for the remembrance of You.

9. With my soul I have desired You in the night, Yes, by my spirit within me I will seek You early; For when Your judgments are in the earth, The inhabitants of the world will learn righteousness.

10. Let grace be shown to the wicked, Yet he will not learn righteousness; In the land of uprightness he will deal unjustly, And will not behold the majesty of the LORD.

11. LORD, when Your hand is lifted up, they will not see. But they will see and be ashamed For their envy of people; Yes, the fire of Your enemies shall devour them.

12. LORD, You will establish peace for us, For You have also done all our works in us.

13. O LORD our God, masters besides You Have had dominion over us; But by You only we make mention of Your name.

14. They are dead, they will not live; They are deceased, they will not rise. Therefore You have punished and destroyed them, And made all their memory to perish.

15. You have increased the nation, O LORD, You have increased the nation; You are glorified; You have expanded all the borders of the land.

16. LORD, in trouble they have visited You, They poured out a prayer when Your chastening was upon them.

17. As a woman with child Is in pain and cries out in her pangs, When she draws near the time of her delivery, So have we been in Your sight, O LORD.

18. We have been with child, we have been in pain; We have, as it were, brought forth wind; We have not accomplished any deliverance in the earth, Nor have the inhabitants of the world fallen.

19. Your dead shall live; Together with my dead body they shall arise. Awake and sing, you who dwell in dust; For your dew is like the dew of herbs, And the earth shall cast out the dead.

20. Come, my people, enter your chambers, And shut your doors behind you; Hide yourself, as it were, for a little moment, Until the indignation is past.

21. For behold, the LORD comes out of His place To punish the inhabitants of the earth for their iniquity; The earth will also disclose her blood, And will no more cover her slain.

## Chapter 27

1. In that day the LORD with His severe sword, great and strong, Will punish Leviathan the fleeing serpent, Leviathan that twisted serpent; And He will slay the reptile that is in the sea.

2. In that day sing to her, "A vineyard of red wine!

3. I, the LORD, keep it, I water it every moment; Lest any hurt it, I keep it night and day.

4. Fury is not in Me. Who would set briers and thorns Against Me in battle? I would go through them, I would burn them together.

5. Or let him take hold of My strength, That he may make peace with Me; And he shall make peace with Me."

6. Those who come He shall cause to take root in Jacob; Israel shall blossom and bud, And fill the face of the world with fruit.

7. Has He struck Israel as He struck those who struck him? Or has He been slain according to the slaughter of those who were slain by Him?

8. In measure, by sending it away, You contended with it. He removes it by His rough wind In the day of the east wind.

9. Therefore by this the iniquity of Jacob will be covered; And this is all the fruit of taking away his sin: When he makes all the stones of the altar Like chalkstones that are beaten to dust, Wooden images and incense altars shall not stand.

10. Yet the fortified city will be desolate, The habitation forsaken and left like a wilderness; There the calf will feed, and there it will lie down And consume its branches.

11. When its boughs are withered, they will be broken off; The women come and set them on fire. For it is a people of no understanding; Therefore He who made them will not have mercy on them, And He who formed them will show them no favor.

12. And it shall come to pass in that day That the LORD will thresh, From the channel of the River to the Brook of Egypt; And you will be gathered one by one, O you children of Israel.

13. So it shall be in that day: The great trumpet will be blown; They will come, who are about to perish in the land of Assyria, And they who are outcasts in the land of Egypt, And shall worship the LORD in the holy mount at Jerusalem.

## Chapter 28

1. Woe to the crown of pride, to the drunkards of Ephraim, Whose glorious beauty is a fading flower Which is at the head of the verdant valleys, To those who are overcome with wine!

2. Behold, the Lord has a mighty and strong one, Like a tempest of hail and a destroying storm, Like a flood of mighty waters overflowing, Who will bring them down to the earth with His hand.

3. The crown of pride, the drunkards of Ephraim, Will be trampled underfoot;

4. And the glorious beauty is a fading flower Which is at the head of the verdant valley, Like the first fruit before the summer, Which an observer sees; He eats it up while it is still in his hand.

5. In that day the LORD of hosts will be For a crown of glory and a diadem of beauty To the remnant of His people,

6. For a spirit of justice to him who sits in judgment, And for strength to those who turn back the battle at the gate.

7. But they also have erred through wine, And through intoxicating drink are out of the way; The priest and the prophet have erred through intoxicating drink, They are swallowed up by wine, They are out of the way through intoxicating drink; They err in vision, they stumble in judgment.

8. For all tables are full of vomit and filth; No place is clean.

9. "Whom will he teach knowledge? And whom will he make to understand the message? Those just weaned from milk? Those just drawn from the breasts?

10. For precept must be upon precept, precept upon precept, Line upon line, line upon line, Here a little, there a little."

11. For with stammering lips and another tongue He will speak to this people,

12. To whom He said, "This is the rest with which You may cause the weary to rest," And, "This is the refreshing"; Yet they would not hear.

13. But the word of the LORD was to them, "Precept upon precept, precept upon precept, Line upon line, line upon line, Here a little, there a little," That they might go and fall backward, and be broken And snared and caught.

14. Therefore hear the word of the LORD, you scornful men, Who rule this people who are in Jerusalem,

15. Because you have said, "We have made a covenant with death, And with Sheol we are in agreement. When the overflowing scourge passes through, It will not come to us, For we have made lies our refuge, And under falsehood we have hidden ourselves."

16. Therefore thus says the Lord GOD: "Behold, I lay in Zion a stone for a foundation, A tried stone, a precious cornerstone, a sure foundation; Whoever believes will not act hastily.

17. Also I will make justice the measuring line, And righteousness the plummet; The hail will sweep away the refuge of lies, And the waters will overflow the hiding place.

18. Your covenant with death will be annulled, And your agreement with Sheol will not stand; When the overflowing scourge passes through, Then you will be trampled down by it.

19. As often as it goes out it will take you; For morning by morning it will pass over, And by day and by night; It will be a terror just to understand the report."

20. For the bed is too short to stretch out on, And the covering so narrow that one cannot wrap himself in it.

21. For the LORD will rise up as at Mount Perazim, He will be angry as in the Valley of Gibeon-- That He may do His work, His awesome work, And bring to pass His act, His unusual act.

22. Now therefore, do not be mockers, Lest your bonds be made strong; For I have heard from the Lord GOD of hosts, A destruction determined even upon the whole earth.

23. Give ear and hear my voice, Listen and hear my speech.

24. Does the plowman keep plowing all day to sow? Does he keep turning his soil and breaking the clods?

25. When he has leveled its surface, Does he not sow the black cummin And scatter the cummin, Plant the wheat in rows, The barley in the appointed place, And the spelt in its place?

26. For He instructs him in right judgment, His God teaches him.

27. For the black cummin is not threshed with a threshing sledge, Nor is a cartwheel rolled over the cummin; But the black cummin is beaten out with a stick, And the cummin with a rod.

28. Bread flour must be ground; Therefore he does not thresh it forever, Break it with his cartwheel, Or crush it with his horsemen.

29. This also comes from the LORD of hosts, Who is wonderful in counsel and excellent in guidance.

## Chapter 29

1. "Woe to Ariel, to Ariel, the city where David dwelt! Add year to year; Let feasts come around.

2. Yet I will distress Ariel; There shall be heaviness and sorrow, And it shall be to Me as Ariel.

3. I will encamp against you all around, I will lay siege against you with a mound, And I will raise siegeworks against you.

4. You shall be brought down, You shall speak out of the ground; Your speech shall be low, out of the dust; Your voice shall be like a medium's, out of the ground; And your speech shall whisper out of the dust.

5. "Moreover the multitude of your foes Shall be like fine dust, And the multitude of the terrible ones Like chaff that passes away; Yes, it shall be in an instant, suddenly.

6. You will be punished by the LORD of hosts With thunder and earthquake and great noise, With storm and tempest And the flame of devouring fire.

7. The multitude of all the nations who fight against Ariel, Even all who fight against her and her fortress, And distress her, Shall be as a dream of a night vision.

8. It shall even be as when a hungry man dreams, And look--he eats; But he awakes, and his soul is still empty; Or as when a thirsty man dreams, And look--he drinks; But he awakes, and indeed he is faint, And his soul still craves: So the multitude of all the nations shall be, Who fight against Mount Zion."

9. Pause and wonder! Blind yourselves and be blind! They are drunk, but not with wine; They stagger, but not with intoxicating drink.

10. For the LORD has poured out on you The spirit of deep sleep, And has closed your eyes, namely, the prophets; And He has covered your heads, namely, the seers.

11. The whole vision has become to you like the words of a book that is sealed, which men deliver to one who is literate, saying, "Read this, please." And he says, "I cannot, for it is sealed."

12. Then the book is delivered to one who is illiterate, saying, "Read this, please." And he says, "I am not literate."

13. Therefore the Lord said: "Inasmuch as these people draw near with their mouths And honor Me with their lips, But have removed their hearts far from Me, And their fear toward Me is taught by the commandment of men,

14. Therefore, behold, I will again do a marvelous work Among this people, A marvelous work and a wonder; For the wisdom of their wise men shall perish, And the understanding of their prudent men shall be hidden."

15. Woe to those who seek deep to hide their counsel far from the LORD, And their works are in the dark; They say, "Who sees us?" and, "Who knows us?"

16. Surely you have things turned around! Shall the potter be esteemed as the clay; For shall the thing made say of him who made it, "He did not make me"? Or shall the thing formed say of him who formed it, "He has no understanding"?

17. Is it not yet a very little while Till Lebanon shall be turned into a fruitful field, And the fruitful field be esteemed as a forest?

18. In that day the deaf shall hear the words of the book, And the eyes of the blind shall see out of obscurity and out of darkness.

19. The humble also shall increase their joy in the LORD, And the poor among men shall rejoice In the Holy One of Israel.

20. For the terrible one is brought to nothing, The scornful one is consumed, And all who watch for iniquity are cut off--

21. Who make a man an offender by a word, And lay a snare for him who reproves in the gate, And turn aside the just by empty words.

22. Therefore thus says the LORD, who redeemed Abraham, concerning the house of Jacob: "Jacob shall not now be ashamed, Nor shall his face now grow pale;

23. But when he sees his children, The work of My hands, in his midst, They will hallow My name, And hallow the Holy One of Jacob, And fear the God of Israel.

24. These also who erred in spirit will come to understanding, And those who complained will learn doctrine."

## Chapter 30

1. "Woe to the rebellious children," says the LORD, "Who take counsel, but not of Me, And who devise plans, but not of My Spirit, That they may add sin to sin;

2. Who walk to go down to Egypt, And have not asked My advice, To strengthen themselves in the strength of Pharaoh, And to trust in the shadow of Egypt!

3. Therefore the strength of Pharaoh Shall be your shame, And trust in the shadow of Egypt Shall be your humiliation.

4. For his princes were at Zoan, And his ambassadors came to Hanes.

5. They were all ashamed of a people who could not benefit them, Or be help or benefit, But a shame and also a reproach."

6. The burden against the beasts of the South. Through a land of trouble and anguish, From which came the lioness and lion, The viper and fiery flying serpent, They will carry their riches on the backs of young donkeys, And their treasures on the humps of camels, To a people who shall not profit;

7. For the Egyptians shall help in vain and to no purpose. Therefore I have called her Rahab-Hem-Shebeth.

8. Now go, write it before them on a tablet, And note it on a scroll, That it may be for time to come, Forever and ever:

9. That this is a rebellious people, Lying children, Children who will not hear the law of the LORD;

10. Who say to the seers, "Do not see," And to the prophets, "Do not prophesy to us right things; Speak to us smooth things, prophesy deceits.

11. Get out of the way, Turn aside from the path, Cause the Holy One of Israel To cease from before us."

12. Therefore thus says the Holy One of Israel: "Because you despise this word, And trust in oppression and perversity, And rely on them,

13. Therefore this iniquity shall be to you Like a breach ready to fall, A bulge in a high wall, Whose breaking comes suddenly, in an instant.

14. And He shall break it like the breaking of the potter's vessel, Which is broken in pieces; He shall not spare. So there shall not be found among its fragments A shard to take fire from the hearth, Or to take water from the cistern."

15. For thus says the Lord GOD, the Holy One of Israel: "In returning and rest you shall be saved; In quietness and confidence shall be your strength." But you would not,

16. And you said, "No, for we will flee on horses"-- Therefore you shall flee! And, "We will ride on swift horses"-- Therefore those who pursue you shall be swift!

17. One thousand shall flee at the threat of one, At the threat of five you shall flee, Till you are left as a pole on top of a mountain And as a banner on a hill.

18. Therefore the LORD will wait, that He may be gracious to you; And therefore He will be exalted, that He may have mercy on you. For the LORD is a God of justice; Blessed are all those who wait for Him.

19. For the people shall dwell in Zion at Jerusalem; You shall weep no more. He will be very gracious to you at the sound of your cry; When He hears it, He will answer you.

20. And though the Lord gives you The bread of adversity and the water of affliction, Yet your teachers will not be moved into a corner anymore, But your eyes shall see your teachers.

21. Your ears shall hear a word behind you, saying, "This is the way, walk in it," Whenever you turn to the right hand Or whenever you turn to the left.

22. You will also defile the covering of your images of silver, And the ornament of your molded images of gold. You will throw them away as an unclean thing; You will say to them, "Get away!"

23. Then He will give the rain for your seed With which you sow the ground, And bread of the increase of the earth; It will be fat and plentiful. In that day your cattle will feed In large pastures.

24. Likewise the oxen and the young donkeys that work the ground Will eat cured fodder, Which has been winnowed with the shovel and fan.

25. There will be on every high mountain And on every high hill Rivers and streams of waters, In the day of the great slaughter, When the towers fall.

26. Moreover the light of the moon will be as the light of the sun, And the light of the sun will be sevenfold, As the light of seven days, In the day that the LORD binds up the bruise of His people And heals the stroke of their wound.

27. Behold, the name of the LORD comes from afar, Burning with His anger, And His burden is heavy; His lips are full of indignation, And His tongue like a devouring fire.

28. His breath is like an overflowing stream, Which reaches up to the neck, To sift the nations with the sieve of futility; And there shall be a bridle in the jaws of the people, Causing them to err.

29. You shall have a song As in the night when a holy festival is kept, And gladness of heart as when one goes with a flute, To come into the mountain of the LORD, To the Mighty One of Israel.

30. The LORD will cause His glorious voice to be heard, And show the descent of His arm, With the indignation of His anger And the flame of a devouring fire, With scattering, tempest, and hailstones.

31. For through the voice of the LORD Assyria will be beaten down, As He strikes with the rod.

32. And in every place where the staff of punishment passes, Which the LORD lays on him, It will be with tambourines and harps; And in battles of brandishing He will fight with it.

33. For Tophet was established of old, Yes, for the king it is prepared. He has made it deep and large; Its pyre is fire with much wood; The breath of the LORD, like a stream of brimstone, Kindles it.

## Chapter 31

1. Woe to those who go down to Egypt for help, And rely on horses, Who trust in chariots because they are many, And in horsemen because they are very strong, But who do not look to the Holy One of Israel, Nor seek the LORD!

2. Yet He also is wise and will bring disaster, And will not call back His words, But will arise against the house of evildoers, And against the help of those who work iniquity.

3. Now the Egyptians are men, and not God; And their horses are flesh, and not spirit. When the LORD stretches out His hand, Both he who helps will fall, And he who is helped will fall down; They all will perish together.

4. For thus the LORD has spoken to me: "As a lion roars, And a young lion over his prey (When a multitude of shepherds is summoned against him, He will not be afraid of their voice Nor be disturbed by their noise), So the LORD of hosts will come down To fight for Mount Zion and for its hill.

5. Like birds flying about, So will the LORD of hosts defend Jerusalem. Defending, He will also deliver it; Passing over, He will preserve it."

6. Return to Him against whom the children of Israel have deeply revolted.

7. For in that day every man shall throw away his idols of silver and his idols of gold--sin, which your own hands have made for yourselves.

8. "Then Assyria shall fall by a sword not of man, And a sword not of mankind shall devour him. But he shall flee from the sword, And his young men shall become forced labor.

9. He shall cross over to his stronghold for fear, And his princes shall be afraid of the banner," Says the LORD, Whose fire is in Zion And whose furnace is in Jerusalem.

## Chapter 32

1. Behold, a king will reign in righteousness, And princes will rule with justice.

2. A man will be as a hiding place from the wind, And a cover from the tempest, As rivers of water in a dry place, As the shadow of a great rock in a weary land.

3. The eyes of those who see will not be dim, And the ears of those who hear will listen.

4. Also the heart of the rash will understand knowledge, And the tongue of the stammerers will be ready to speak plainly.

5. The foolish person will no longer be called generous, Nor the miser said to be bountiful;

6. For the foolish person will speak foolishness, And his heart will work iniquity: To practice ungodliness, To utter error against the LORD, To keep the hungry unsatisfied, And he will cause the drink of the thirsty to fail.

7. Also the schemes of the schemer are evil; He devises wicked plans To destroy the poor with lying words, Even when the needy speaks justice.

8. But a generous man devises generous things, And by generosity he shall stand.

9. Rise up, you women who are at ease, Hear my voice; You complacent daughters, Give ear to my speech.

10. In a year and some days You will be troubled, you complacent women; For the vintage will fail, The gathering will not come.

11. Tremble, you women who are at ease; Be troubled, you complacent ones; Strip yourselves, make yourselves bare, And gird sackcloth on your waists.

12. People shall mourn upon their breasts For the pleasant fields, for the fruitful vine.

13. On the land of my people will come up thorns and briers, Yes, on all the happy homes in the joyous city;

14. Because the palaces will be forsaken, The bustling city will be deserted. The forts and towers will become lairs forever, A joy of wild donkeys, a pasture of flocks--

15. Until the Spirit is poured upon us from on high, And the wilderness becomes a fruitful field, And the fruitful field is counted as a forest.

16. Then justice will dwell in the wilderness, And righteousness remain in the fruitful field.

17. The work of righteousness will be peace, And the effect of righteousness, quietness and assurance forever.

18. My people will dwell in a peaceful habitation, In secure dwellings, and in quiet resting places,

19. Though hail comes down on the forest, And the city is brought low in humiliation.

20. Blessed are you who sow beside all waters, Who send out freely the feet of the ox and the donkey.

## Chapter 33

1. Woe to you who plunder, though you have not been plundered; And you who deal treacherously, though they have not dealt treacherously with you! When you cease plundering, You will be plundered; When you make an end of dealing treacherously, They will deal treacherously with you.

2. O LORD, be gracious to us; We have waited for You. Be their arm every morning, Our salvation also in the time of trouble.

3. At the noise of the tumult the people shall flee; When You lift Yourself up, the nations shall be scattered;

4. And Your plunder shall be gathered Like the gathering of the caterpillar; As the running to and fro of locusts, He shall run upon them.

5. The LORD is exalted, for He dwells on high; He has filled Zion with justice and righteousness.

6. Wisdom and knowledge will be the stability of your times, And the strength of salvation; The fear of the LORD is His treasure.

7. Surely their valiant ones shall cry outside, The ambassadors of peace shall weep bitterly.

8. The highways lie waste, The traveling man ceases. He has broken the covenant, He has despised the cities, He regards no man.

9. The earth mourns and languishes, Lebanon is shamed and shriveled; Sharon is like a wilderness, And Bashan and Carmel shake off their fruits.

10. "Now I will rise," says the LORD; "Now I will be exalted, Now I will lift Myself up.

11. You shall conceive chaff, You shall bring forth stubble; Your breath, as fire, shall devour you.

12. And the people shall be like the burnings of lime; Like thorns cut up they shall be burned in the fire.

13. Hear, you who are afar off, what I have done; And you who are near, acknowledge My might."

14. The sinners in Zion are afraid; Fearfulness has seized the hypocrites: "Who among us shall dwell with the devouring fire? Who among us shall dwell with everlasting burnings?"

15. He who walks righteously and speaks uprightly, He who despises the gain of oppressions, Who gestures with his hands, refusing bribes, Who stops his ears from hearing of bloodshed, And shuts his eyes from seeing evil:

16. He will dwell on high; His place of defense will be the fortress of rocks; Bread will be given him, His water will be sure.

17. Your eyes will see the King in His beauty; They will see the land that is very far off.

18. Your heart will meditate on terror: "Where is the scribe? Where is he who weighs? Where is he who counts the towers?"

19. You will not see a fierce people, A people of obscure speech, beyond perception, Of a stammering tongue that you cannot understand.

20. Look upon Zion, the city of our appointed feasts; Your eyes will see Jerusalem, a quiet home, A tabernacle that will not be taken down; Not one of its stakes will ever be removed, Nor will any of its cords be broken.

21. But there the majestic LORD will be for us A place of broad rivers and streams, In which no galley with oars will sail, Nor majestic ships pass by

22. (For the LORD is our Judge, The LORD is our Lawgiver, The LORD is our King; He will save us);

23. Your tackle is loosed, They could not strengthen their mast, They could not spread the sail. Then the prey of great plunder is divided; The lame take the prey.

24. And the inhabitant will not say, "I am sick"; The people who dwell in it will be forgiven their iniquity.

## Chapter 34

1. Come near, you nations, to hear; And heed, you people! Let the earth hear, and all that is in it, The world and all things that come forth from it.

2. For the indignation of the LORD is against all nations, And His fury against all their armies; He has utterly destroyed them, He has given them over to the slaughter.

3. Also their slain shall be thrown out; Their stench shall rise from their corpses, And the mountains shall be melted with their blood.

4. All the host of heaven shall be dissolved, And the heavens shall be rolled up like a scroll; All their host shall fall down As the leaf falls from the vine, And as fruit falling from a fig tree.

5. "For My sword shall be bathed in heaven; Indeed it shall come down on Edom, And on the people of My curse, for judgment.

6. The sword of the LORD is filled with blood, It is made overflowing with fatness, With the blood of lambs and goats, With the fat of the kidneys of rams. For the LORD has a sacrifice in Bozrah, And a great slaughter in the land of Edom.

7. The wild oxen shall come down with them, And the young bulls with the mighty bulls; Their land shall be soaked with blood, And their dust saturated with fatness."

8. For it is the day of the LORD's vengeance, The year of recompense for the cause of Zion.

9. Its streams shall be turned into pitch, And its dust into brimstone; Its land shall become burning pitch.

10. It shall not be quenched night or day; Its smoke shall ascend forever. From generation to generation it shall lie waste; No one shall pass through it forever and ever.

11. But the pelican and the porcupine shall possess it, Also the owl and the raven shall dwell in it. And He shall stretch out over it The line of confusion and the stones of emptiness.

12. They shall call its nobles to the kingdom, But none shall be there, and all its princes shall be nothing.

13. And thorns shall come up in its palaces, Nettles and brambles in its fortresses; It shall be a habitation of jackals, A courtyard for ostriches.

14. The wild beasts of the desert shall also meet with the jackals, And the wild goat shall bleat to its companion; Also the night creature shall rest there, And find for herself a place of rest.

15. There the arrow snake shall make her nest and lay eggs And hatch, and gather them under her shadow; There also shall the hawks be gathered, Every one with her mate.

16. "Search from the book of the LORD, and read: Not one of these shall fail; Not one shall lack her mate. For My mouth has commanded it, and His Spirit has gathered them.

17. He has cast the lot for them, And His hand has divided it among them with a measuring line. They shall possess it forever; From generation to generation they shall dwell in it."

## Chapter 35

1. The wilderness and the wasteland shall be glad for them, And the desert shall rejoice and blossom as the rose;

2. It shall blossom abundantly and rejoice, Even with joy and singing. The glory of Lebanon shall be given to it, The excellence of Carmel and Sharon. They shall see the glory of the LORD, The excellency of our God.

3. Strengthen the weak hands, And make firm the feeble knees.

4. Say to those who are fearful-hearted, "Be strong, do not fear! Behold, your God will come with vengeance, With the recompense of God; He will come and save you."

5. Then the eyes of the blind shall be opened, And the ears of the deaf shall be unstopped.

6. Then the lame shall leap like a deer, And the tongue of the dumb sing. For waters shall burst forth in the wilderness, And streams in the desert.

7. The parched ground shall become a pool, And the thirsty land springs of water; In the habitation of jackals, where each lay, There shall be grass with reeds and rushes.

8. A highway shall be there, and a road, And it shall be called the Highway of Holiness. The unclean shall not pass over it, But it shall be for others. Whoever walks the road, although a fool, Shall not go astray.

9. No lion shall be there, Nor shall any ravenous beast go up on it; It shall not be found there. But the redeemed shall walk there,

10. And the ransomed of the LORD shall return, And come to Zion with singing, With everlasting joy on their heads. They shall obtain joy and gladness, And sorrow and sighing shall flee away.

## Chapter 36

1. Now it came to pass in the fourteenth year of King Hezekiah that Sennacherib king of Assyria came up against all the fortified cities of Judah and took them.

2. Then the king of Assyria sent the Rabshakeh with a great army from Lachish to King Hezekiah at Jerusalem. And he stood by the aqueduct from the upper pool, on the highway to the Fuller's Field.

3. And Eliakim the son of Hilkiah, who was over the household, Shebna the scribe, and Joah the son of Asaph, the recorder, came out to him.

4. Then the Rabshakeh said to them, "Say now to Hezekiah, "Thus says the great king, the king of Assyria: "What confidence is this in which you trust?

5. I say you speak of having plans and power for war; but they are mere words. Now in whom do you trust, that you rebel against me?

6. Look! You are trusting in the staff of this broken reed, Egypt, on which if a man leans, it will go into his hand and pierce it. So is Pharaoh king of Egypt to all who trust in him.

7. "But if you say to me, "We trust in the LORD our God,' is it not He whose high places and whose altars Hezekiah has taken away, and said to Judah and Jerusalem, "You shall worship before this altar'?"'

8. Now therefore, I urge you, give a pledge to my master the king of Assyria, and I will give you two thousand horses--if you are able on your part to put riders on them!

9. How then will you repel one captain of the least of my master's servants, and put your trust in Egypt for chariots and horsemen?

10. Have I now come up without the LORD against this land to destroy it? The LORD said to me, "Go up against this land, and destroy it."'

11. Then Eliakim, Shebna, and Joah said to the Rabshakeh, "Please speak to your servants in Aramaic, for we understand it; and do not speak to us in Hebrew in the hearing of the people who are on the wall."

12. But the Rabshakeh said, "Has my master sent me to your master and to you to speak these words, and not to the men who sit on the wall, who will eat and drink their own waste with you?"

13. Then the Rabshakeh stood and called out with a loud voice in Hebrew, and said, "Hear the words of the great king, the king of Assyria!

14. Thus says the king: "Do not let Hezekiah deceive you, for he will not be able to deliver you;

15. nor let Hezekiah make you trust in the LORD, saying, "The LORD will surely deliver us; this city will not be given into the hand of the king of Assyria."'

16. Do not listen to Hezekiah; for thus says the king of Assyria: "Make peace with me by a present and come out to me; and every one of you eat from his own vine and every one from his own fig tree, and every one of you drink the waters of his own cistern;

17. until I come and take you away to a land like your own land, a land of grain and new wine, a land of bread and vineyards.

18. Beware lest Hezekiah persuade you, saying, "The LORD will deliver us." Has any one of the gods of the nations delivered its land from the hand of the king of Assyria?

19. Where are the gods of Hamath and Arpad? Where are the gods of Sepharvaim? Indeed, have they delivered Samaria from my hand?

20. Who among all the gods of these lands have delivered their countries from my hand, that the LORD should deliver Jerusalem from my hand?"'

21. But they held their peace and answered him not a word; for the king's commandment was, "Do not answer him."

22. Then Eliakim the son of Hilkiah, who was over the household, Shebna the scribe, and Joah the son of Asaph, the recorder, came to Hezekiah with their clothes torn, and told him the words of the Rabshakeh.

## Chapter 37

1. And so it was, when King Hezekiah heard it, that he tore his clothes, covered himself with sackcloth, and went into the house of the LORD.

2. Then he sent Eliakim, who was over the household, Shebna the scribe, and the elders of the priests, covered with sackcloth, to Isaiah the prophet, the son of Amoz.

3. And they said to him, "Thus says Hezekiah: "This day is a day of trouble and rebuke and blasphemy; for the children have come to birth, but there is no strength to bring them forth.

4. It may be that the LORD your God will hear the words of the Rabshakeh, whom his master the king of Assyria has sent to reproach the living God, and will rebuke the words which the LORD your God has heard. Therefore lift up your prayer for the remnant that is left."'

5. So the servants of King Hezekiah came to Isaiah.

6. And Isaiah said to them, "Thus you shall say to your master, "Thus says the LORD: "Do not be afraid of the words which you have heard, with which the servants of the king of Assyria have blasphemed Me.

7. Surely I will send a spirit upon him, and he shall hear a rumor and return to his own land; and I will cause him to fall by the sword in his own land.""'

8. Then the Rabshakeh returned, and found the king of Assyria warring against Libnah, for he heard that he had departed from Lachish.

9. And the king heard concerning Tirhakah king of Ethiopia, "He has come out to make war with you." So when he heard it, he sent messengers to Hezekiah, saying,

10. "Thus you shall speak to Hezekiah king of Judah, saying: "Do not let your God in whom you trust deceive you, saying, "Jerusalem shall not be given into the hand of the king of Assyria."

11. Look! You have heard what the kings of Assyria have done to all lands by utterly destroying them; and shall you be delivered?

12. Have the gods of the nations delivered those whom my fathers have destroyed, Gozan and Haran and Rezeph, and the people of Eden who were in Telassar?

13. Where is the king of Hamath, the king of Arpad, and the king of the city of Sepharvaim, Hena, and Ivah?"'

14. And Hezekiah received the letter from the hand of the messengers, and read it; and Hezekiah went up to the house of the LORD, and spread it before the LORD.

15. Then Hezekiah prayed to the LORD, saying:

16. "O LORD of hosts, God of Israel, the One who dwells between the cherubim, You are God, You alone, of all the kingdoms of the earth. You have made heaven and earth.

17. Incline Your ear, O LORD, and hear; open Your eyes, O LORD, and see; and hear all the words of Sennacherib, which he has sent to reproach the living God.

18. Truly, LORD, the kings of Assyria have laid waste all the nations and their lands,

19. and have cast their gods into the fire; for they were not gods, but the work of men's hands--wood and stone. Therefore they destroyed them.

20. Now therefore, O LORD our God, save us from his hand, that all the kingdoms of the earth may know that You are the LORD, You alone."

21. Then Isaiah the son of Amoz sent to Hezekiah, saying, "Thus says the LORD God of Israel, "Because you have prayed to Me against Sennacherib king of Assyria,

22. this is the word which the LORD has spoken concerning him: "The virgin, the daughter of Zion, Has despised you, laughed you to scorn; The daughter of Jerusalem Has shaken her head behind your back!

23. "Whom have you reproached and blasphemed? Against whom have you raised your voice, And lifted up your eyes on high? Against the Holy One of Israel.

24. By your servants you have reproached the Lord, And said, "By the multitude of my chariots I have come up to the height of the mountains, To the limits of Lebanon; I will cut down its tall cedars And its choice cypress trees; I will enter its farthest height, To its fruitful forest.

25. I have dug and drunk water, And with the soles of my feet I have dried up All the brooks of defense.'

26. "Did you not hear long ago How I made it, From ancient times that I formed it? Now I have brought it to pass, That you should be For crushing fortified cities into heaps of ruins.

27. Therefore their inhabitants had little power; They were dismayed and confounded; They were as the grass of the field And the green herb, As the grass on the housetops And grain blighted before it is grown.

28. "But I know your dwelling place, Your going out and your coming in, And your rage against Me.

29. Because your rage against Me and your tumult Have come up to My ears, Therefore I will put My hook in your nose And My bridle in your lips, And I will turn you back By the way which you came."'

30. "This shall be a sign to you: You shall eat this year such as grows of itself, And the second year what springs from the same; Also in the third year sow and reap, Plant vineyards and eat the fruit of them.

31. And the remnant who have escaped of the house of Judah Shall again take root downward, And bear fruit upward.

32. For out of Jerusalem shall go a remnant, And those who escape from Mount Zion. The zeal of the LORD of hosts will do this.

33. "Therefore thus says the LORD concerning the king of Assyria: "He shall not come into this city, Nor shoot an arrow there, Nor come before it with shield, Nor build a siege mound against it.

34. By the way that he came, By the same shall he return; And he shall not come into this city,' Says the LORD.

35. "For I will defend this city, to save it For My own sake and for My servant David's sake."'

36. Then the angel of the LORD went out, and killed in the camp of the Assyrians one hundred and eighty-five thousand; and when people arose early in the morning, there were the corpses--all dead.

37. So Sennacherib king of Assyria departed and went away, returned home, and remained at Nineveh.

38. Now it came to pass, as he was worshiping in the house of Nisroch his god, that his sons Adrammelech and Sharezer struck him down with the sword; and they escaped into the land of Ararat. Then Esarhaddon his son reigned in his place.

## Chapter 38

1. In those days Hezekiah was sick and near death. And Isaiah the prophet, the son of Amoz, went to him and said to him, "Thus says the LORD: "Set your house in order, for you shall die and not live."'

2. Then Hezekiah turned his face toward the wall, and prayed to the LORD,

3. and said, "Remember now, O LORD, I pray, how I have walked before You in truth and with a loyal heart, and have done what is good in Your sight." And Hezekiah wept bitterly.

4. And the word of the LORD came to Isaiah, saying,

5. "Go and tell Hezekiah, "Thus says the LORD, the God of David your father: "I have heard your prayer, I have seen your tears; surely I will add to your days fifteen years.

6. I will deliver you and this city from the hand of the king of Assyria, and I will defend this city."'

7. And this is the sign to you from the LORD, that the LORD will do this thing which He has spoken:

8. Behold, I will bring the shadow on the sundial, which has gone down with the sun on the sundial of Ahaz, ten degrees backward." So the sun returned ten degrees on the dial by which it had gone down.

9. This is the writing of Hezekiah king of Judah, when he had been sick and had recovered from his sickness:

10. I said, "In the prime of my life I shall go to the gates of Sheol; I am deprived of the remainder of my years."

11. I said, "I shall not see Yah, The LORD in the land of the living; I shall observe man no more among the inhabitants of the world.

12. My life span is gone, Taken from me like a shepherd's tent; I have cut off my life like a weaver. He cuts me off from the loom; From day until night You make an end of me.

13. I have considered until morning-- Like a lion, So He breaks all my bones; From day until night You make an end of me.

14. Like a crane or a swallow, so I chattered; I mourned like a dove; My eyes fail from looking upward. O LORD, I am oppressed; Undertake for me!

15. "What shall I say? He has both spoken to me, And He Himself has done it. I shall walk carefully all my years In the bitterness of my soul.

16. O Lord, by these things men live; And in all these things is the life of my spirit; So You will restore me and make me live.

17. Indeed it was for my own peace That I had great bitterness; But You have lovingly delivered my soul from the pit of corruption, For You have cast all my sins behind Your back.

18. For Sheol cannot thank You, Death cannot praise You; Those who go down to the pit cannot hope for Your truth.

19. The living, the living man, he shall praise You, As I do this day; The father shall make known Your truth to the children.

20. "The LORD was ready to save me; Therefore we will sing my songs with stringed instruments All the days of our life, in the house of the LORD."

21. Now Isaiah had said, "Let them take a lump of figs, and apply it as a poultice on the boil, and he shall recover."

22. And Hezekiah had said, "What is the sign that I shall go up to the house of the LORD?"

## Chapter 39

1. At that time Merodach-Baladan the son of Baladan, king of Babylon, sent letters and a present to Hezekiah, for he heard that he had been sick and had recovered.

2. And Hezekiah was pleased with them, and showed them the house of his treasures--the silver and gold, the spices and precious ointment, and all his armory--all that was found among his treasures. There was nothing in his house or in all his dominion that Hezekiah did not show them.

3. Then Isaiah the prophet went to King Hezekiah, and said to him, "What did these men say, and from where did they come to you?" So Hezekiah said, "They came to me from a far country, from Babylon."

4. And he said, "What have they seen in your house?" So Hezekiah answered, "They have seen all that is in my house; there is nothing among my treasures that I have not shown them."

5. Then Isaiah said to Hezekiah, "Hear the word of the LORD of hosts:

6. "Behold, the days are coming when all that is in your house, and what your fathers have accumulated until this day, shall be carried to Babylon; nothing shall be left,' says the LORD.

7. "And they shall take away some of your sons who will descend from you, whom you will beget; and they shall be eunuchs in the palace of the king of Babylon."'

8. So Hezekiah said to Isaiah, "The word of the LORD which you have spoken is good!" For he said, "At least there will be peace and truth in my days."

## Chapter 40

1. "Comfort, yes, comfort My people!" Says your God.

2. "Speak comfort to Jerusalem, and cry out to her, That her warfare is ended, That her iniquity is pardoned; For she has received from the LORD's hand Double for all her sins."

3. The voice of one crying in the wilderness: "Prepare the way of the LORD; Make straight in the desert A highway for our God.

4. Every valley shall be exalted And every mountain and hill brought low; The crooked places shall be made straight And the rough places smooth;

5. The glory of the LORD shall be revealed, And all flesh shall see it together; For the mouth of the LORD has spoken."

6. The voice said, "Cry out!" And he said, "What shall I cry?" "All flesh is grass, And all its loveliness is like the flower of the field.

7. The grass withers, the flower fades, Because the breath of the LORD blows upon it; Surely the people are grass.

8. The grass withers, the flower fades, But the word of our God stands forever."

9. O Zion, You who bring good tidings, Get up into the high mountain; O Jerusalem, You who bring good tidings, Lift up your voice with strength, Lift it up, be not afraid; Say to the cities of Judah, "Behold your God!"

10. Behold, the Lord GOD shall come with a strong hand, And His arm shall rule for Him; Behold, His reward is with Him, And His work before Him.

11. He will feed His flock like a shepherd; He will gather the lambs with His arm, And carry them in His bosom, And gently lead those who are with young.

12. Who has measured the waters in the hollow of His hand, Measured heaven with a span And calculated the dust of the earth in a measure? Weighed the mountains in scales And the hills in a balance?

13. Who has directed the Spirit of the LORD, Or as His counselor has taught Him?

14. With whom did He take counsel, and who instructed Him, And taught Him in the path of justice? Who taught Him knowledge, And showed Him the way of understanding?

15. Behold, the nations are as a drop in a bucket, And are counted as the small dust on the scales; Look, He lifts up the isles as a very little thing.

16. And Lebanon is not sufficient to burn, Nor its beasts sufficient for a burnt offering.

17. All nations before Him are as nothing, And they are counted by Him less than nothing and worthless.

18. To whom then will you liken God? Or what likeness will you compare to Him?

19. The workman molds an image, The goldsmith overspreads it with gold, And the silversmith casts silver chains.

20. Whoever is too impoverished for such a contribution Chooses a tree that will not rot; He seeks for himself a skillful workman To prepare a carved image that will not totter.

21. Have you not known? Have you not heard? Has it not been told you from the beginning? Have you not understood from the foundations of the earth?

22. It is He who sits above the circle of the earth, And its inhabitants are like grasshoppers, Who stretches out the heavens like a curtain, And spreads them out like a tent to dwell in.

23. He brings the princes to nothing; He makes the judges of the earth useless.

24. Scarcely shall they be planted, Scarcely shall they be sown, Scarcely shall their stock take root in the earth, When He will also blow on them, And they will wither, And the whirlwind will take them away like stubble.

25. "To whom then will you liken Me, Or to whom shall I be equal?" says the Holy One.

26. Lift up your eyes on high, And see who has created these things, Who brings out their host by number; He calls them all by name, By the greatness of His might And the strength of His power; Not one is missing.

27. Why do you say, O Jacob, And speak, O Israel: "My way is hidden from the LORD, And my just claim is passed over by my God"?

28. Have you not known? Have you not heard? The everlasting God, the LORD, The Creator of the ends of the earth, Neither faints nor is weary. His understanding is unsearchable.

29. He gives power to the weak, And to those who have no might He increases strength.

30. Even the youths shall faint and be weary, And the young men shall utterly fall,

31. But those who wait on the LORD Shall renew their strength; They shall mount up with wings like eagles, They shall run and not be weary, They shall walk and not faint.

## Chapter 41

1. "Keep silence before Me, O coastlands, And let the people renew their strength! Let them come near, then let them speak; Let us come near together for judgment.

2. "Who raised up one from the east? Who in righteousness called him to His feet? Who gave the nations before him, And made him rule over kings? Who gave them as the dust to his sword, As driven stubble to his bow?

3. Who pursued them, and passed safely By the way that he had not gone with his feet?

4. Who has performed and done it, Calling the generations from the beginning? "I, the LORD, am the first; And with the last I am He."'

5. The coastlands saw it and feared, The ends of the earth were afraid; They drew near and came.

6. Everyone helped his neighbor, And said to his brother, "Be of good courage!"

7. So the craftsman encouraged the goldsmith; He who smooths with the hammer inspired him who strikes the anvil, Saying, "It is ready for the soldering"; Then he fastened it with pegs, That it might not totter.

8. "But you, Israel, are My servant, Jacob whom I have chosen, The descendants of Abraham My friend.

9. You whom I have taken from the ends of the earth, And called from its farthest regions, And said to you, "You are My servant, I have chosen you and have not cast you away:

10. Fear not, for I am with you; Be not dismayed, for I am your God. I will strengthen you, Yes, I will help you, I will uphold you with My righteous right hand.'

11. "Behold, all those who were incensed against you Shall be ashamed and disgraced; They shall be as nothing, And those who strive with you shall perish.

12. You shall seek them and not find them-- Those who contended with you. Those who war against you Shall be as nothing, As a nonexistent thing.

13. For I, the LORD your God, will hold your right hand, Saying to you, "Fear not, I will help you.'

14. "Fear not, you worm Jacob, You men of Israel! I will help you," says the LORD And your Redeemer, the Holy One of Israel.

15. "Behold, I will make you into a new threshing sledge with sharp teeth; You shall thresh the mountains and beat them small, And make the hills like chaff.

16. You shall winnow them, the wind shall carry them away, And the whirlwind shall scatter them; You shall rejoice in the LORD, And glory in the Holy One of Israel.

17. "The poor and needy seek water, but there is none, Their tongues fail for thirst. I, the LORD, will hear them; I, the God of Israel, will not forsake them.

18. I will open rivers in desolate heights, And fountains in the midst of the valleys; I will make the wilderness a pool of water, And the dry land springs of water.

19. I will plant in the wilderness the cedar and the acacia tree, The myrtle and the oil tree; I will set in the desert the cypress tree and the pine And the box tree together,

20. That they may see and know, And consider and understand together, That the hand of the LORD has done this, And the Holy One of Israel has created it.

21. "Present your case," says the LORD. "Bring forth your strong reasons," says the King of Jacob.

22. "Let them bring forth and show us what will happen; Let them show the former things, what they were, That we may consider them, And know the latter end of them; Or declare to us things to come.

23. Show the things that are to come hereafter, That we may know that you are gods; Yes, do good or do evil, That we may be dismayed and see it together.

24. Indeed you are nothing, And your work is nothing; He who chooses you is an abomination.

25. "I have raised up one from the north, And he shall come; From the rising of the sun he shall call on My name; And he shall come against princes as though mortar, As the potter treads clay.

26. Who has declared from the beginning, that we may know? And former times, that we may say, "He is righteous'? Surely there is no one who shows, Surely there is no one who declares, Surely there is no one who hears your words.

27. The first time I said to Zion, "Look, there they are!' And I will give to Jerusalem one who brings good tidings.

28. For I looked, and there was no man; I looked among them, but there was no counselor, Who, when I asked of them, could answer a word.

29. Indeed they are all worthless; Their works are nothing; Their molded images are wind and confusion.

## Chapter 42

1. "Behold! My Servant whom I uphold, My Elect One in whom My soul delights! I have put My Spirit upon Him; He will bring forth justice to the Gentiles.

2. He will not cry out, nor raise His voice, Nor cause His voice to be heard in the street.

3. A bruised reed He will not break, And smoking flax He will not quench; He will bring forth justice for truth.

4. He will not fail nor be discouraged, Till He has established justice in the earth; And the coastlands shall wait for His law."

5. Thus says God the LORD, Who created the heavens and stretched them out, Who spread forth the earth and that which comes from it, Who gives breath to the people on it, And spirit to those who walk on it:

6. "I, the LORD, have called You in righteousness, And will hold Your hand; I will keep You and give You as a covenant to the people, As a light to the Gentiles,

7. To open blind eyes, To bring out prisoners from the prison, Those who sit in darkness from the prison house.

8. I am the LORD, that is My name; And My glory I will not give to another, Nor My praise to carved images.

9. Behold, the former things have come to pass, And new things I declare; Before they spring forth I tell you of them."

10. Sing to the LORD a new song, And His praise from the ends of the earth, You who go down to the sea, and all that is in it, You coastlands and you inhabitants of them!

11. Let the wilderness and its cities lift up their voice, The villages that Kedar inhabits. Let the inhabitants of Sela sing, Let them shout from the top of the mountains.

12. Let them give glory to the LORD, And declare His praise in the coastlands.

13. The LORD shall go forth like a mighty man; He shall stir up His zeal like a man of war. He shall cry out, yes, shout aloud; He shall prevail against His enemies.

14. "I have held My peace a long time, I have been still and restrained Myself. Now I will cry like a woman in labor, I will pant and gasp at once.

15. I will lay waste the mountains and hills, And dry up all their vegetation; I will make the rivers coastlands, And I will dry up the pools.

16. I will bring the blind by a way they did not know; I will lead them in paths they have not known. I will make darkness light before them, And crooked places straight. These things I will do for them, And not forsake them.

17. They shall be turned back, They shall be greatly ashamed, Who trust in carved images, Who say to the molded images, "You are our gods.'

18. "Hear, you deaf; And look, you blind, that you may see.

19. Who is blind but My servant, Or deaf as My messenger whom I send? Who is blind as he who is perfect, And blind as the LORD's servant?

20. Seeing many things, but you do not observe; Opening the ears, but he does not hear."

21. The LORD is well pleased for His righteousness' sake; He will exalt the law and make it honorable.

22. But this is a people robbed and plundered; All of them are snared in holes, And they are hidden in prison houses; They are for prey, and no one delivers; For plunder, and no one says, "Restore!"

23. Who among you will give ear to this? Who will listen and hear for the time to come?

24. Who gave Jacob for plunder, and Israel to the robbers? Was it not the LORD, He against whom we have sinned? For they would not walk in His ways, Nor were they obedient to His law.

25. Therefore He has poured on him the fury of His anger And the strength of battle; It has set him on fire all around, Yet he did not know; And it burned him, Yet he did not take it to heart.

## Chapter 43

1. But now, thus says the LORD, who created you, O Jacob, And He who formed you, O Israel: "Fear not, for I have redeemed you; I have called you by your name; You are Mine.

2. When you pass through the waters, I will be with you; And through the rivers, they shall not overflow you. When you walk through the fire, you shall not be burned, Nor shall the flame scorch you.

3. For I am the LORD your God, The Holy One of Israel, your Savior; I gave Egypt for your ransom, Ethiopia and Seba in your place.

4. Since you were precious in My sight, You have been honored, And I have loved you; Therefore I will give men for you, And people for your life.

5. Fear not, for I am with you; I will bring your descendants from the east, And gather you from the west;

6. I will say to the north, "Give them up!' And to the south, "Do not keep them back!' Bring My sons from afar, And My daughters from the ends of the earth--

7. Everyone who is called by My name, Whom I have created for My glory; I have formed him, yes, I have made him."

8. Bring out the blind people who have eyes, And the deaf who have ears.

9. Let all the nations be gathered together, And let the people be assembled. Who among them can declare this, And show us former things? Let them bring out their witnesses, that they may be justified; Or let them hear and say, "It is truth."

10. "You are My witnesses," says the LORD, "And My servant whom I have chosen, That you may know and believe Me, And understand that I am He. Before Me there was no God formed, Nor shall there be after Me.

11. I, even I, am the LORD, And besides Me there is no savior.

12. I have declared and saved, I have proclaimed, And there was no foreign god among you; Therefore you are My witnesses," Says the LORD, "that I am God.

13. Indeed before the day was, I am He; And there is no one who can deliver out of My hand; I work, and who will reverse it?"

14. Thus says the LORD, your Redeemer, The Holy One of Israel: "For your sake I will send to Babylon, And bring them all down as fugitives-- The Chaldeans, who rejoice in their ships.

15. I am the LORD, your Holy One, The Creator of Israel, your King."

16. Thus says the LORD, who makes a way in the sea And a path through the mighty waters,

17. Who brings forth the chariot and horse, The army and the power (They shall lie down together, they shall not rise; They are extinguished, they are quenched like a wick):

18. "Do not remember the former things, Nor consider the things of old.

19. Behold, I will do a new thing, Now it shall spring forth; Shall you not know it? I will even make a road in the wilderness And rivers in the desert.

20. The beast of the field will honor Me, The jackals and the ostriches, Because I give waters in the wilderness And rivers in the desert, To give drink to My people, My chosen.

21. This people I have formed for Myself; They shall declare My praise.

22. "But you have not called upon Me, O Jacob; And you have been weary of Me, O Israel.

23. You have not brought Me the sheep for your burnt offerings, Nor have you honored Me with your sacrifices. I have not caused you to serve with grain offerings, Nor wearied you with incense.

24. You have bought Me no sweet cane with money, Nor have you satisfied Me with the fat of your sacrifices; But you have burdened Me with your sins, You have wearied Me with your iniquities.

25. "I, even I, am He who blots out your transgressions for My own sake; And I will not remember your sins.

26. Put Me in remembrance; Let us contend together; State your case, that you may be acquitted.

27. Your first father sinned, And your mediators have transgressed against Me.

28. Therefore I will profane the princes of the sanctuary; I will give Jacob to the curse, And Israel to reproaches.

## Chapter 44

1. "Yet hear me now, O Jacob My servant, And Israel whom I have chosen.

2. Thus says the LORD who made you And formed you from the womb, who will help you: "Fear not, O Jacob My servant; And you, Jeshurun, whom I have chosen.

3. For I will pour water on him who is thirsty, And floods on the dry ground; I will pour My Spirit on your descendants, And My blessing on your offspring;

4. They will spring up among the grass Like willows by the watercourses.'

5. One will say, "I am the LORD's'; Another will call himself by the name of Jacob; Another will write with his hand, "The LORD's,' And name himself by the name of Israel.

6. "Thus says the LORD, the King of Israel, And his Redeemer, the LORD of hosts: "I am the First and I am the Last; Besides Me there is no God.

7. And who can proclaim as I do? Then let him declare it and set it in order for Me, Since I appointed the ancient people. And the things that are coming and shall come, Let them show these to them.

8. Do not fear, nor be afraid; Have I not told you from that time, and declared it? You are My witnesses. Is there a God besides Me? Indeed there is no other Rock; I know not one."'

9. Those who make an image, all of them are useless, And their precious things shall not profit; They are their own witnesses; They neither see nor know, that they may be ashamed.

10. Who would form a god or mold an image That profits him nothing?

11. Surely all his companions would be ashamed; And the workmen, they are mere men. Let them all be gathered together, Let them stand up; Yet they shall fear, They shall be ashamed together.

12. The blacksmith with the tongs works one in the coals, Fashions it with hammers, And works it with the strength of his arms. Even so, he is hungry, and his strength fails; He drinks no water and is faint.

13. The craftsman stretches out his rule, He marks one out with chalk; He fashions it with a plane, He marks it out with the compass, And makes it like the figure of a man, According to the beauty of a man, that it may remain in the house.

14. He cuts down cedars for himself, And takes the cypress and the oak; He secures it for himself among the trees of the forest. He plants a pine, and the rain nourishes it.

15. Then it shall be for a man to burn, For he will take some of it and warm himself; Yes, he kindles it and bakes bread; Indeed he makes a god and worships it; He makes it a carved image, and falls down to it.

16. He burns half of it in the fire; With this half he eats meat; He roasts a roast, and is satisfied. He even warms himself and says, "Ah! I am warm, I have seen the fire."

17. And the rest of it he makes into a god, His carved image. He falls down before it and worships it, Prays to it and says, "Deliver me, for you are my god!"

18. They do not know nor understand; For He has shut their eyes, so that they cannot see, And their hearts, so that they cannot understand.

19. And no one considers in his heart, Nor is there knowledge nor understanding to say, "I have burned half of it in the fire, Yes, I have also baked bread on its coals; I have roasted meat and eaten it; And shall I make the rest of it an abomination? Shall I fall down before a block of wood?"

20. He feeds on ashes; A deceived heart has turned him aside; And he cannot deliver his soul, Nor say, "Is there not a lie in my right hand?"

21. "Remember these, O Jacob, And Israel, for you are My servant; I have formed you, you are My servant; O Israel, you will not be forgotten by Me!

22. I have blotted out, like a thick cloud, your transgressions, And like a cloud, your sins. Return to Me, for I have redeemed you."

23. Sing, O heavens, for the LORD has done it! Shout, you lower parts of the earth; Break forth into singing, you mountains, O forest, and every tree in it! For the LORD has redeemed Jacob, And glorified Himself in Israel.

24. Thus says the LORD, your Redeemer, And He who formed you from the womb: "I am the LORD, who makes all things, Who stretches out the heavens all alone, Who spreads abroad the earth by Myself;

25. Who frustrates the signs of the babblers, And drives diviners mad; Who turns wise men backward, And makes their knowledge foolishness;

26. Who confirms the word of His servant, And performs the counsel of His messengers; Who says to Jerusalem, "You shall be inhabited,' To the cities of Judah, "You shall be built,' And I will raise up her waste places;

27. Who says to the deep, "Be dry! And I will dry up your rivers';

28. Who says of Cyrus, "He is My shepherd, And he shall perform all My pleasure, Saying to Jerusalem, "You shall be built," And to the temple, "Your foundation shall be laid."'

## Chapter 45

1. "Thus says the LORD to His anointed, To Cyrus, whose right hand I have held-- To subdue nations before him And loose the armor of kings, To open before him the double doors, So that the gates will not be shut:

2. "I will go before you And make the crooked places straight; I will break in pieces the gates of bronze And cut the bars of iron.

3. I will give you the treasures of darkness And hidden riches of secret places, That you may know that I, the LORD, Who call you by your name, Am the God of Israel.

4. For Jacob My servant's sake, And Israel My elect, I have even called you by your name; I have named you, though you have not known Me.

5. I am the LORD, and there is no other; There is no God besides Me. I will gird you, though you have not known Me,

6. That they may know from the rising of the sun to its setting That there is none besides Me. I am the LORD, and there is no other;

7. I form the light and create darkness, I make peace and create calamity; I, the LORD, do all these things.'

8. "Rain down, you heavens, from above, And let the skies pour down righteousness; Let the earth open, let them bring forth salvation, And let righteousness spring up together. I, the LORD, have created it.

9. "Woe to him who strives with his Maker! Let the potsherd strive with the potsherds of the earth! Shall the clay say to him who forms it, "What are you making?' Or shall your handiwork say, "He has no hands'?

10. Woe to him who says to his father, "What are you begetting?' Or to the woman, "What have you brought forth?"'

11. Thus says the LORD, The Holy One of Israel, and his Maker: "Ask Me of things to come concerning My sons; And concerning the work of My hands, you command Me.

12. I have made the earth, And created man on it. I--My hands--stretched out the heavens, And all their host I have commanded.

13. I have raised him up in righteousness, And I will direct all his ways; He shall build My city And let My exiles go free, Not for price nor reward," Says the LORD of hosts.

14. Thus says the LORD: "The labor of Egypt and merchandise of Cush And of the Sabeans, men of stature, Shall come over to you, and they shall be yours; They shall walk behind you, They shall come over in chains; And they shall bow down to you. They will make supplication to you, saying, "Surely God is in you, And there is no other; There is no other God."'

15. Truly You are God, who hide Yourself, O God of Israel, the Savior!

16. They shall be ashamed And also disgraced, all of them; They shall go in confusion together, Who are makers of idols.

17. But Israel shall be saved by the LORD With an everlasting salvation; You shall not be ashamed or disgraced Forever and ever.

18. For thus says the LORD, Who created the heavens, Who is God, Who formed the earth and made it, Who has established it, Who did not create it in vain, Who formed it to be inhabited: "I am the LORD, and there is no other.

19. I have not spoken in secret, In a dark place of the earth; I did not say to the seed of Jacob, "Seek Me in vain'; I, the LORD, speak righteousness, I declare things that are right.

20. "Assemble yourselves and come; Draw near together, You who have escaped from the nations. They have no knowledge, Who carry the wood of their carved image, And pray to a god that cannot save.

21. Tell and bring forth your case; Yes, let them take counsel together. Who has declared this from ancient time? Who has told it from that time? Have not I, the LORD? And there is no other God besides Me, A just God and a Savior; There is none besides Me.

22. "Look to Me, and be saved, All you ends of the earth! For I am God, and there is no other.

23. I have sworn by Myself; The word has gone out of My mouth in righteousness, And shall not return, That to Me every knee shall bow, Every tongue shall take an oath.

24. He shall say, "Surely in the LORD I have righteousness and strength. To Him men shall come, And all shall be ashamed Who are incensed against Him.

25. In the LORD all the descendants of Israel Shall be justified, and shall glory."'

## Chapter 46

1. Bel bows down, Nebo stoops; Their idols were on the beasts and on the cattle. Your carriages were heavily loaded, A burden to the weary beast.

2. They stoop, they bow down together; They could not deliver the burden, But have themselves gone into captivity.

3. "Listen to Me, O house of Jacob, And all the remnant of the house of Israel, Who have been upheld by Me from birth, Who have been carried from the womb:

4. Even to your old age, I am He, And even to gray hairs I will carry you! I have made, and I will bear; Even I will carry, and will deliver you.

5. "To whom will you liken Me, and make Me equal And compare Me, that we should be alike?

6. They lavish gold out of the bag, And weigh silver on the scales; They hire a goldsmith, and he makes it a god; They prostrate themselves, yes, they worship.

7. They bear it on the shoulder, they carry it And set it in its place, and it stands; From its place it shall not move. Though one cries out to it, yet it cannot answer Nor save him out of his trouble.

8. "Remember this, and show yourselves men; Recall to mind, O you transgressors.

9. Remember the former things of old, For I am God, and there is no other; I am God, and there is none like Me,

10. Declaring the end from the beginning, And from ancient times things that are not yet done, Saying, "My counsel shall stand, And I will do all My pleasure,'

11. Calling a bird of prey from the east, The man who executes My counsel, from a far country. Indeed I have spoken it; I will also bring it to pass. I have purposed it; I will also do it.

12. "Listen to Me, you stubborn-hearted, Who are far from righteousness:

13. I bring My righteousness near, it shall not be far off; My salvation shall not linger. And I will place salvation in Zion, For Israel My glory.

## Chapter 47

1. "Come down and sit in the dust, O virgin daughter of Babylon; Sit on the ground without a throne, O daughter of the Chaldeans! For you shall no more be called Tender and delicate.

2. Take the millstones and grind meal. Remove your veil, Take off the skirt, Uncover the thigh, Pass through the rivers.

3. Your nakedness shall be uncovered, Yes, your shame will be seen; I will take vengeance, And I will not arbitrate with a man."

4. As for our Redeemer, the LORD of hosts is His name, The Holy One of Israel.

5. "Sit in silence, and go into darkness, O daughter of the Chaldeans; For you shall no longer be called The Lady of Kingdoms.

6. I was angry with My people; I have profaned My inheritance, And given them into your hand. You showed them no mercy; On the elderly you laid your yoke very heavily.

7. And you said, "I shall be a lady forever,' So that you did not take these things to heart, Nor remember the latter end of them.

8. "Therefore hear this now, you who are given to pleasures, Who dwell securely, Who say in your heart, "I am, and there is no one else besides me; I shall not sit as a widow, Nor shall I know the loss of children';

9. But these two things shall come to you In a moment, in one day: The loss of children, and widowhood. They shall come upon you in their fullness Because of the multitude of your sorceries, For the great abundance of your enchantments.

10. "For you have trusted in your wickedness; You have said, "No one sees me'; Your wisdom and your knowledge have warped you; And you have said in your heart, "I am, and there is no one else besides me.'

11. Therefore evil shall come upon you; You shall not know from where it arises. And trouble shall fall upon you; You will not be able to put it off. And desolation shall come upon you suddenly, Which you shall not know.

12. "Stand now with your enchantments And the multitude of your sorceries, In which you have labored from your youth-- Perhaps you will be able to profit, Perhaps you will prevail.

13. You are wearied in the multitude of your counsels; Let now the astrologers, the stargazers, And the monthly prognosticators Stand up and save you From what shall come upon you.

14. Behold, they shall be as stubble, The fire shall burn them; They shall not deliver themselves From the power of the flame; It shall not be a coal to be warmed by, Nor a fire to sit before!

15. Thus shall they be to you With whom you have labored, Your merchants from your youth; They shall wander each one to his quarter. No one shall save you.

## Chapter 48

1. "Hear this, O house of Jacob, Who are called by the name of Israel, And have come forth from the wellsprings of Judah; Who swear by the name of the LORD, And make mention of the God of Israel, But not in truth or in righteousness;

2. For they call themselves after the holy city, And lean on the God of Israel; The LORD of hosts is His name:

3. "I have declared the former things from the beginning; They went forth from My mouth, and I caused them to hear it. Suddenly I did them, and they came to pass.

4. Because I knew that you were obstinate, And your neck was an iron sinew, And your brow bronze,

5. Even from the beginning I have declared it to you; Before it came to pass I proclaimed it to you, Lest you should say, "My idol has done them, And my carved image and my molded image Have commanded them.'

6. "You have heard; See all this. And will you not declare it? I have made you hear new things from this time, Even hidden things, and you did not know them.

7. They are created now and not from the beginning; And before this day you have not heard them, Lest you should say, "Of course I knew them.'

8. Surely you did not hear, Surely you did not know; Surely from long ago your ear was not opened. For I knew that you would deal very treacherously, And were called a transgressor from the womb.

9. "For My name's sake I will defer My anger, And for My praise I will restrain it from you, So that I do not cut you off.

10. Behold, I have refined you, but not as silver; I have tested you in the furnace of affliction.

11. For My own sake, for My own sake, I will do it; For how should My name be profaned? And I will not give My glory to another.

12. "Listen to Me, O Jacob, And Israel, My called: I am He, I am the First, I am also the Last.

13. Indeed My hand has laid the foundation of the earth, And My right hand has stretched out the heavens; When I call to them, They stand up together.

14. "All of you, assemble yourselves, and hear! Who among them has declared these things? The LORD loves him; He shall do His pleasure on Babylon, And His arm shall be against the Chaldeans.

15. I, even I, have spoken; Yes, I have called him, I have brought him, and his way will prosper.

16. "Come near to Me, hear this: I have not spoken in secret from the beginning; From the time that it was, I was there. And now the Lord GOD and His Spirit Have sent Me."

17. Thus says the LORD, your Redeemer, The Holy One of Israel: "I am the LORD your God, Who teaches you to profit, Who leads you by the way you should go.

18. Oh, that you had heeded My commandments! Then your peace would have been like a river, And your righteousness like the waves of the sea.

19. Your descendants also would have been like the sand, And the offspring of your body like the grains of sand; His name would not have been cut off Nor destroyed from before Me."

20. Go forth from Babylon! Flee from the Chaldeans! With a voice of singing, Declare, proclaim this, Utter it to the end of the earth; Say, "The LORD has redeemed His servant Jacob!"

21. And they did not thirst When He led them through the deserts; He caused the waters to flow from the rock for them; He also split the rock, and the waters gushed out.

22. "There is no peace," says the LORD, "for the wicked."

## Chapter 49

1. "Listen, O coastlands, to Me, And take heed, you peoples from afar! The LORD has called Me from the womb; From the matrix of My mother He has made mention of My name.

2. And He has made My mouth like a sharp sword; In the shadow of His hand He has hidden Me, And made Me a polished shaft; In His quiver He has hidden Me."

3. "And He said to me, "You are My servant, O Israel, In whom I will be glorified.'

4. Then I said, "I have labored in vain, I have spent my strength for nothing and in vain; Yet surely my just reward is with the LORD, And my work with my God."'

5. "And now the LORD says, Who formed Me from the womb to be His Servant, To bring Jacob back to Him, So that Israel is gathered to Him (For I shall be glorious in the eyes of the LORD, And My God shall be My strength),

6. Indeed He says, "It is too small a thing that You should be My Servant To raise up the tribes of Jacob, And to restore the preserved ones of Israel; I will also give You as a light to the Gentiles, That You should be My salvation to the ends of the earth."'

7. Thus says the LORD, The Redeemer of Israel, their Holy One, To Him whom man despises, To Him whom the nation abhors, To the Servant of rulers: "Kings shall see and arise, Princes also shall worship, Because of the LORD who is faithful, The Holy One of Israel; And He has chosen You."

8. Thus says the LORD: "In an acceptable time I have heard You, And in the day of salvation I have helped You; I will preserve You and give You As a covenant to the people, To restore the earth, To cause them to inherit the desolate heritages;

9. That You may say to the prisoners, "Go forth,' To those who are in darkness, "Show yourselves.' "They shall feed along the roads, And their pastures shall be on all desolate heights.

10. They shall neither hunger nor thirst, Neither heat nor sun shall strike them; For He who has mercy on them will lead them, Even by the springs of water He will guide them.

11. I will make each of My mountains a road, And My highways shall be elevated.

12. Surely these shall come from afar; Look! Those from the north and the west, And these from the land of Sinim."

13. Sing, O heavens! Be joyful, O earth! And break out in singing, O mountains! For the LORD has comforted His people, And will have mercy on His afflicted.

14. But Zion said, "The LORD has forsaken me, And my Lord has forgotten me."

15. "Can a woman forget her nursing child, And not have compassion on the son of her womb? Surely they may forget, Yet I will not forget you.

16. See, I have inscribed you on the palms of My hands; Your walls are continually before Me.

17. Your sons shall make haste; Your destroyers and those who laid you waste Shall go away from you.

18. Lift up your eyes, look around and see; All these gather together and come to you. As I live," says the LORD, "You shall surely clothe yourselves with them all as an ornament, And bind them on you as a bride does.

19. "For your waste and desolate places, And the land of your destruction, Will even now be too small for the inhabitants; And those who swallowed you up will be far away.

20. The children you will have, After you have lost the others, Will say again in your ears, "The place is too small for me; Give me a place where I may dwell.'

21. Then you will say in your heart, "Who has begotten these for me, Since I have lost my children and am desolate, A captive, and wandering to and fro? And who has brought these up? There I was, left alone; But these, where were they?"'

22. Thus says the Lord GOD: "Behold, I will lift My hand in an oath to the nations, And set up My standard for the peoples; They shall bring your sons in their arms, And your daughters shall be carried on their shoulders;

23. Kings shall be your foster fathers, And their queens your nursing mothers; They shall bow down to you with their faces to the earth, And lick up the dust of your feet. Then you will know that I am the LORD, For they shall not be ashamed who wait for Me."

24. Shall the prey be taken from the mighty, Or the captives of the righteous be delivered?

25. But thus says the LORD: "Even the captives of the mighty shall be taken away, And the prey of the terrible be delivered; For I will contend with him who contends with you, And I will save your children.

26. I will feed those who oppress you with their own flesh, And they shall be drunk with their own blood as with sweet wine. All flesh shall know That I, the LORD, am your Savior, And your Redeemer, the Mighty One of Jacob."

## Chapter 50

1. Thus says the LORD: "Where is the certificate of your mother's divorce, Whom I have put away? Or which of My creditors is it to whom I have sold you? For your iniquities you have sold yourselves, And for your transgressions your mother has been put away.

2. Why, when I came, was there no man? Why, when I called, was there none to answer? Is My hand shortened at all that it cannot redeem? Or have I no power to deliver? Indeed with My rebuke I dry up the sea, I make the rivers a wilderness; Their fish stink because there is no water, And die of thirst.

3. I clothe the heavens with blackness, And I make sackcloth their covering."

4. "The Lord GOD has given Me The tongue of the learned, That I should know how to speak A word in season to him who is weary. He awakens Me morning by morning, He awakens My ear To hear as the learned.

5. The Lord GOD has opened My ear; And I was not rebellious, Nor did I turn away.

6. I gave My back to those who struck Me, And My cheeks to those who plucked out the beard; I did not hide My face from shame and spitting.

7. "For the Lord GOD will help Me; Therefore I will not be disgraced; Therefore I have set My face like a flint, And I know that I will not be ashamed.

8. He is near who justifies Me; Who will contend with Me? Let us stand together. Who is My adversary? Let him come near Me.

9. Surely the Lord GOD will help Me; Who is he who will condemn Me? Indeed they will all grow old like a garment; The moth will eat them up.

10. "Who among you fears the LORD? Who obeys the voice of His Servant? Who walks in darkness And has no light? Let him trust in the name of the LORD And rely upon his God.

11. Look, all you who kindle a fire, Who encircle yourselves with sparks: Walk in the light of your fire and in the sparks you have kindled-- This you shall have from My hand: You shall lie down in torment.

## Chapter 51

1. "Listen to Me, you who follow after righteousness, You who seek the LORD: Look to the rock from which you were hewn, And to the hole of the pit from which you were dug.

2. Look to Abraham your father, And to Sarah who bore you; For I called him alone, And blessed him and increased him."

3. For the LORD will comfort Zion, He will comfort all her waste places; He will make her wilderness like Eden, And her desert like the garden of the LORD; Joy and gladness will be found in it, Thanksgiving and the voice of melody.

4. "Listen to Me, My people; And give ear to Me, O My nation: For law will proceed from Me, And I will make My justice rest As a light of the peoples.

5. My righteousness is near, My salvation has gone forth, And My arms will judge the peoples; The coastlands will wait upon Me, And on My arm they will trust.

6. Lift up your eyes to the heavens, And look on the earth beneath. For the heavens will vanish away like smoke, The earth will grow old like a garment, And those who dwell in it will die in like manner; But My salvation will be forever, And My righteousness will not be abolished.

7. "Listen to Me, you who know righteousness, You people in whose heart is My law: Do not fear the reproach of men, Nor be afraid of their insults.

8. For the moth will eat them up like a garment, And the worm will eat them like wool; But My righteousness will be forever, And My salvation from generation to generation."

9. Awake, awake, put on strength, O arm of the LORD! Awake as in the ancient days, In the generations of old. Are You not the arm that cut Rahab apart, And wounded the serpent?

10. Are You not the One who dried up the sea, The waters of the great deep; That made the depths of the sea a road For the redeemed to cross over?

11. So the ransomed of the LORD shall return, And come to Zion with singing, With everlasting joy on their heads. They shall obtain joy and gladness; Sorrow and sighing shall flee away.

12. "I, even I, am He who comforts you. Who are you that you should be afraid Of a man who will die, And of the son of a man who will be made like grass?

13. And you forget the LORD your Maker, Who stretched out the heavens And laid the foundations of the earth; You have feared continually every day Because of the fury of the oppressor, When he has prepared to destroy. And where is the fury of the oppressor?

14. The captive exile hastens, that he may be loosed, That he should not die in the pit, And that his bread should not fail.

15. But I am the LORD your God, Who divided the sea whose waves roared-- The LORD of hosts is His name.

16. And I have put My words in your mouth; I have covered you with the shadow of My hand, That I may plant the heavens, Lay the foundations of the earth, And say to Zion, "You are My people."'

17. Awake, awake! Stand up, O Jerusalem, You who have drunk at the hand of the LORD The cup of His fury; You have drunk the dregs of the cup of trembling, And drained it out.

18. There is no one to guide her Among all the sons she has brought forth; Nor is there any who takes her by the hand Among all the sons she has brought up.

19. These two things have come to you; Who will be sorry for you?-- Desolation and destruction, famine and sword-- By whom will I comfort you?

20. Your sons have fainted, They lie at the head of all the streets, Like an antelope in a net; They are full of the fury of the LORD, The rebuke of your God.

21. Therefore please hear this, you afflicted, And drunk but not with wine.

22. Thus says your Lord, The LORD and your God, Who pleads the cause of His people: "See, I have taken out of your hand The cup of trembling, The dregs of the cup of My fury; You shall no longer drink it.

23. But I will put it into the hand of those who afflict you, Who have said to you, "Lie down, that we may walk over you.' And you have laid your body like the ground, And as the street, for those who walk over."

## Chapter 52

1. Awake, awake! Put on your strength, O Zion; Put on your beautiful garments, O Jerusalem, the holy city! For the uncircumcised and the unclean Shall no longer come to you.

2. Shake yourself from the dust, arise; Sit down, O Jerusalem! Loose yourself from the bonds of your neck, O captive daughter of Zion!

3. For thus says the LORD: "You have sold yourselves for nothing, And you shall be redeemed without money."

4. For thus says the Lord GOD: "My people went down at first Into Egypt to dwell there; Then the Assyrian oppressed them without cause.

5. Now therefore, what have I here," says the LORD, "That My people are taken away for nothing? Those who rule over them Make them wail," says the LORD, "And My name is blasphemed continually every day.

6. Therefore My people shall know My name; Therefore they shall know in that day That I am He who speaks: "Behold, it is I."'

7. How beautiful upon the mountains Are the feet of him who brings good news, Who proclaims peace, Who brings glad tidings of good things, Who proclaims salvation, Who says to Zion, "Your God reigns!"

8. Your watchmen shall lift up their voices, With their voices they shall sing together; For they shall see eye to eye When the LORD brings back Zion.

9. Break forth into joy, sing together, You waste places of Jerusalem! For the LORD has comforted His people, He has redeemed Jerusalem.

10. The LORD has made bare His holy arm In the eyes of all the nations; And all the ends of the earth shall see The salvation of our God.

11. Depart! Depart! Go out from there, Touch no unclean thing; Go out from the midst of her, Be clean, You who bear the vessels of the LORD.

12. For you shall not go out with haste, Nor go by flight; For the LORD will go before you, And the God of Israel will be your rear guard.

13. Behold, My Servant shall deal prudently; He shall be exalted and extolled and be very high.

14. Just as many were astonished at you, So His visage was marred more than any man, And His form more than the sons of men;

15. So shall He sprinkle many nations. Kings shall shut their mouths at Him; For what had not been told them they shall see, And what they had not heard they shall consider.

## Chapter 53

1. Who has believed our report? And to whom has the arm of the LORD been revealed?

2. For He shall grow up before Him as a tender plant, And as a root out of dry ground. He has no form or comeliness; And when we see Him, There is no beauty that we should desire Him.

3. He is despised and rejected by men, A Man of sorrows and acquainted with grief. And we hid, as it were, our faces from Him; He was despised, and we did not esteem Him.

4. Surely He has borne our griefs And carried our sorrows; Yet we esteemed Him stricken, Smitten by God, and afflicted.

5. But He was wounded for our transgressions, He was bruised for our iniquities; The chastisement for our peace was upon Him, And by His stripes we are healed.

6. All we like sheep have gone astray; We have turned, every one, to his own way; And the LORD has laid on Him the iniquity of us all.

7. He was oppressed and He was afflicted, Yet He opened not His mouth; He was led as a lamb to the slaughter, And as a sheep before its shearers is silent, So He opened not His mouth.

8. He was taken from prison and from judgment, And who will declare His generation? For He was cut off from the land of the living; For the transgressions of My people He was stricken.

9. And they made His grave with the wicked-- But with the rich at His death, Because He had done no violence, Nor was any deceit in His mouth.

10. Yet it pleased the LORD to bruise Him; He has put Him to grief. When You make His soul an offering for sin, He shall see His seed, He shall prolong His days, And the pleasure of the LORD shall prosper in His hand.

11. He shall see the labor of His soul, and be satisfied. By His knowledge My righteous Servant shall justify many, For He shall bear their iniquities.

12. Therefore I will divide Him a portion with the great, And He shall divide the spoil with the strong, Because He poured out His soul unto death, And He was numbered with the transgressors, And He bore the sin of many, And made intercession for the transgressors.

## Chapter 54

1. "Sing, O barren, You who have not borne! Break forth into singing, and cry aloud, You who have not labored with child! For more are the children of the desolate Than the children of the married woman," says the LORD.

2. "Enlarge the place of your tent, And let them stretch out the curtains of your dwellings; Do not spare; Lengthen your cords, And strengthen your stakes.

3. For you shall expand to the right and to the left, And your descendants will inherit the nations, And make the desolate cities inhabited.

4. "Do not fear, for you will not be ashamed; Neither be disgraced, for you will not be put to shame; For you will forget the shame of your youth, And will not remember the reproach of your widowhood anymore.

5. For your Maker is your husband, The LORD of hosts is His name; And your Redeemer is the Holy One of Israel; He is called the God of the whole earth.

6. For the LORD has called you Like a woman forsaken and grieved in spirit, Like a youthful wife when you were refused," Says your God.

7. "For a mere moment I have forsaken you, But with great mercies I will gather you.

8. With a little wrath I hid My face from you for a moment; But with everlasting kindness I will have mercy on you," Says the LORD, your Redeemer.

9. "For this is like the waters of Noah to Me; For as I have sworn That the waters of Noah would no longer cover the earth, So have I sworn That I would not be angry with you, nor rebuke you.

10. For the mountains shall depart And the hills be removed, But My kindness shall not depart from you, Nor shall My covenant of peace be removed," Says the LORD, who has mercy on you.

11. "O you afflicted one, Tossed with tempest, and not comforted, Behold, I will lay your stones with colorful gems, And lay your foundations with sapphires.

12. I will make your pinnacles of rubies, Your gates of crystal, And all your walls of precious stones.

13. All your children shall be taught by the LORD, And great shall be the peace of your children.

14. In righteousness you shall be established; You shall be far from oppression, for you shall not fear; And from terror, for it shall not come near you.

15. Indeed they shall surely assemble, but not because of Me. Whoever assembles against you shall fall for your sake.

16. "Behold, I have created the blacksmith Who blows the coals in the fire, Who brings forth an instrument for his work; And I have created the spoiler to destroy.

17. No weapon formed against you shall prosper, And every tongue which rises against you in judgment You shall condemn. This is the heritage of the servants of the LORD, And their righteousness is from Me," Says the LORD.

## Chapter 55

1. "Ho! Everyone who thirsts, Come to the waters; And you who have no money, Come, buy and eat. Yes, come, buy wine and milk Without money and without price.

2. Why do you spend money for what is not bread, And your wages for what does not satisfy? Listen carefully to Me, and eat what is good, And let your soul delight itself in abundance.

3. Incline your ear, and come to Me. Hear, and your soul shall live; And I will make an everlasting covenant with you-- The sure mercies of David.

4. Indeed I have given him as a witness to the people, A leader and commander for the people.

5. Surely you shall call a nation you do not know, And nations who do not know you shall run to you, Because of the LORD your God, And the Holy One of Israel; For He has glorified you."

6. Seek the LORD while He may be found, Call upon Him while He is near.

7. Let the wicked forsake his way, And the unrighteous man his thoughts; Let him return to the LORD, And He will have mercy on him; And to our God, For He will abundantly pardon.

8. "For My thoughts are not your thoughts, Nor are your ways My ways," says the LORD.

9. "For as the heavens are higher than the earth, So are My ways higher than your ways, And My thoughts than your thoughts.

10. "For as the rain comes down, and the snow from heaven, And do not return there, But water the earth, And make it bring forth and bud, That it may give seed to the sower And bread to the eater,

11. So shall My word be that goes forth from My mouth; It shall not return to Me void, But it shall accomplish what I please, And it shall prosper in the thing for which I sent it.

12. "For you shall go out with joy, And be led out with peace; The mountains and the hills Shall break forth into singing before you, And all the trees of the field shall clap their hands.

13. Instead of the thorn shall come up the cypress tree, And instead of the brier shall come up the myrtle tree; And it shall be to the LORD for a name, For an everlasting sign that shall not be cut off."

## Chapter 56

1. Thus says the LORD: "Keep justice, and do righteousness, For My salvation is about to come, And My righteousness to be revealed.

2. Blessed is the man who does this, And the son of man who lays hold on it; Who keeps from defiling the Sabbath, And keeps his hand from doing any evil."

3. Do not let the son of the foreigner Who has joined himself to the LORD Speak, saying, "The LORD has utterly separated me from His people"; Nor let the eunuch say, "Here I am, a dry tree."

4. For thus says the LORD: "To the eunuchs who keep My Sabbaths, And choose what pleases Me, And hold fast My covenant,

5. Even to them I will give in My house And within My walls a place and a name Better than that of sons and daughters; I will give them an everlasting name That shall not be cut off.

6. "Also the sons of the foreigner Who join themselves to the LORD, to serve Him, And to love the name of the LORD, to be His servants-- Everyone who keeps from defiling the Sabbath, And holds fast My covenant--

7. Even them I will bring to My holy mountain, And make them joyful in My house of prayer. Their burnt offerings and their sacrifices Will be accepted on My altar; For My house shall be called a house of prayer for all nations."

8. The Lord GOD, who gathers the outcasts of Israel, says, "Yet I will gather to him Others besides those who are gathered to him."

9. All you beasts of the field, come to devour, All you beasts in the forest.

10. His watchmen are blind, They are all ignorant; They are all dumb dogs, They cannot bark; Sleeping, lying down, loving to slumber.

11. Yes, they are greedy dogs Which never have enough. And they are shepherds Who cannot understand; They all look to their own way, Every one for his own gain, From his own territory.

12. "Come," one says, "I will bring wine, And we will fill ourselves with intoxicating drink; Tomorrow will be as today, And much more abundant."

## Chapter 57

1. The righteous perishes, And no man takes it to heart; Merciful men are taken away, While no one considers That the righteous is taken away from evil.

2. He shall enter into peace; They shall rest in their beds, Each one walking in his uprightness.

3. "But come here, You sons of the sorceress, You offspring of the adulterer and the harlot!

4. Whom do you ridicule? Against whom do you make a wide mouth And stick out the tongue? Are you not children of transgression, Offspring of falsehood,

5. Inflaming yourselves with gods under every green tree, Slaying the children in the valleys, Under the clefts of the rocks?

6. Among the smooth stones of the stream Is your portion; They, they, are your lot! Even to them you have poured a drink offering, You have offered a grain offering. Should I receive comfort in these?

7. "On a lofty and high mountain You have set your bed; Even there you went up To offer sacrifice.

8. Also behind the doors and their posts You have set up your remembrance; For you have uncovered yourself to those other than Me, And have gone up to them; You have enlarged your bed And made a covenant with them; You have loved their bed, Where you saw their nudity.

9. You went to the king with ointment, And increased your perfumes; You sent your messengers far off, And even descended to Sheol.

10. You are wearied in the length of your way; Yet you did not say, "There is no hope.' You have found the life of your hand; Therefore you were not grieved.

11. "And of whom have you been afraid, or feared, That you have lied And not remembered Me, Nor taken it to your heart? Is it not because I have held My peace from of old That you do not fear Me?

12. I will declare your righteousness And your works, For they will not profit you.

13. When you cry out, Let your collection of idols deliver you. But the wind will carry them all away, A breath will take them. But he who puts his trust in Me shall possess the land, And shall inherit My holy mountain."

14. And one shall say, "Heap it up! Heap it up! Prepare the way, Take the stumbling block out of the way of My people."

15. For thus says the High and Lofty One Who inhabits eternity, whose name is Holy: "I dwell in the high and holy place, With him who has a contrite and humble spirit, To revive the spirit of the humble, And to revive the heart of the contrite ones.

16. For I will not contend forever, Nor will I always be angry; For the spirit would fail before Me, And the souls which I have made.

17. For the iniquity of his covetousness I was angry and struck him; I hid and was angry, And he went on backsliding in the way of his heart.

18. I have seen his ways, and will heal him; I will also lead him, And restore comforts to him And to his mourners.

19. "I create the fruit of the lips: Peace, peace to him who is far off and to him who is near," Says the LORD, "And I will heal him."

20. But the wicked are like the troubled sea, When it cannot rest, Whose waters cast up mire and dirt.

21. "There is no peace," Says my God, "for the wicked."

## Chapter 58

1. "Cry aloud, spare not; Lift up your voice like a trumpet; Tell My people their transgression, And the house of Jacob their sins.

2. Yet they seek Me daily, And delight to know My ways, As a nation that did righteousness, And did not forsake the ordinance of their God. They ask of Me the ordinances of justice; They take delight in approaching God.

3. "Why have we fasted,' they say, "and You have not seen? Why have we afflicted our souls, and You take no notice?' "In fact, in the day of your fast you find pleasure, And exploit all your laborers.

4. Indeed you fast for strife and debate, And to strike with the fist of wickedness. You will not fast as you do this day, To make your voice heard on high.

5. Is it a fast that I have chosen, A day for a man to afflict his soul? Is it to bow down his head like a bulrush, And to spread out sackcloth and ashes? Would you call this a fast, And an acceptable day to the LORD?

6. "Is this not the fast that I have chosen: To loose the bonds of wickedness, To undo the heavy burdens, To let the oppressed go free, And that you break every yoke?

7. Is it not to share your bread with the hungry, And that you bring to your house the poor who are cast out; When you see the naked, that you cover him, And not hide yourself from your own flesh?

8. Then your light shall break forth like the morning, Your healing shall spring forth speedily, And your righteousness shall go before you; The glory of the LORD shall be your rear guard.

9. Then you shall call, and the LORD will answer; You shall cry, and He will say, "Here I am.' "If you take away the yoke from your midst, The pointing of the finger, and speaking wickedness,

10. If you extend your soul to the hungry And satisfy the afflicted soul, Then your light shall dawn in the darkness, And your darkness shall be as the noonday.

11. The LORD will guide you continually, And satisfy your soul in drought, And strengthen your bones; You shall be like a watered garden, And like a spring of water, whose waters do not fail.

12. Those from among you Shall build the old waste places; You shall raise up the foundations of many generations; And you shall be called the Repairer of the Breach, The Restorer of Streets to Dwell In.

13. "If you turn away your foot from the Sabbath, From doing your pleasure on My holy day, And call the Sabbath a delight, The holy day of the LORD honorable, And shall honor Him, not doing your own ways, Nor finding your own pleasure, Nor speaking your own words,

14. Then you shall delight yourself in the LORD; And I will cause you to ride on the high hills of the earth, And feed you with the heritage of Jacob your father. The mouth of the LORD has spoken."

## Chapter 59

1. Behold, the LORD's hand is not shortened, That it cannot save; Nor His ear heavy, That it cannot hear.

2. But your iniquities have separated you from your God; And your sins have hidden His face from you, So that He will not hear.

3. For your hands are defiled with blood, And your fingers with iniquity; Your lips have spoken lies, Your tongue has muttered perversity.

4. No one calls for justice, Nor does any plead for truth. They trust in empty words and speak lies; They conceive evil and bring forth iniquity.

5. They hatch vipers' eggs and weave the spider's web; He who eats of their eggs dies, And from that which is crushed a viper breaks out.

6. Their webs will not become garments, Nor will they cover themselves with their works; Their works are works of iniquity, And the act of violence is in their hands.

7. Their feet run to evil, And they make haste to shed innocent blood; Their thoughts are thoughts of iniquity; Wasting and destruction are in their paths.

8. The way of peace they have not known, And there is no justice in their ways; They have made themselves crooked paths; Whoever takes that way shall not know peace.

9. Therefore justice is far from us, Nor does righteousness overtake us; We look for light, but there is darkness! For brightness, but we walk in blackness!

10. We grope for the wall like the blind, And we grope as if we had no eyes; We stumble at noonday as at twilight; We are as dead men in desolate places.

11. We all growl like bears, And moan sadly like doves; We look for justice, but there is none; For salvation, but it is far from us.

12. For our transgressions are multiplied before You, And our sins testify against us; For our transgressions are with us, And as for our iniquities, we know them:

13. In transgressing and lying against the LORD, And departing from our God, Speaking oppression and revolt, Conceiving and uttering from the heart words of falsehood.

14. Justice is turned back, And righteousness stands afar off; For truth is fallen in the street, And equity cannot enter.

15. So truth fails, And he who departs from evil makes himself a prey. Then the LORD saw it, and it displeased Him That there was no justice.

16. He saw that there was no man, And wondered that there was no intercessor; Therefore His own arm brought salvation for Him; And His own righteousness, it sustained Him.

17. For He put on righteousness as a breastplate, And a helmet of salvation on His head; He put on the garments of vengeance for clothing, And was clad with zeal as a cloak.

18. According to their deeds, accordingly He will repay, Fury to His adversaries, Recompense to His enemies; The coastlands He will fully repay.

19. So shall they fear The name of the LORD from the west, And His glory from the rising of the sun; When the enemy comes in like a flood, The Spirit of the LORD will lift up a standard against him.

20. "The Redeemer will come to Zion, And to those who turn from transgression in Jacob," Says the LORD.

21. "As for Me," says the LORD, "this is My covenant with them: My Spirit who is upon you, and My words which I have put in your mouth, shall not depart from your mouth, nor from the mouth of your descendants, nor from the mouth of your descendants' descendants," says the LORD, "from this time and forevermore."

## Chapter 60

1. Arise, shine; For your light has come! And the glory of the LORD is risen upon you.

2. For behold, the darkness shall cover the earth, And deep darkness the people; But the LORD will arise over you, And His glory will be seen upon you.

3. The Gentiles shall come to your light, And kings to the brightness of your rising.

4. "Lift up your eyes all around, and see: They all gather together, they come to you; Your sons shall come from afar, And your daughters shall be nursed at your side.

5. Then you shall see and become radiant, And your heart shall swell with joy; Because the abundance of the sea shall be turned to you, The wealth of the Gentiles shall come to you.

6. The multitude of camels shall cover your land, The dromedaries of Midian and Ephah; All those from Sheba shall come; They shall bring gold and incense, And they shall proclaim the praises of the LORD.

7. All the flocks of Kedar shall be gathered together to you, The rams of Nebaioth shall minister to you; They shall ascend with acceptance on My altar, And I will glorify the house of My glory.

8. "Who are these who fly like a cloud, And like doves to their roosts?

9. Surely the coastlands shall wait for Me; And the ships of Tarshish will come first, To bring your sons from afar, Their silver and their gold with them, To the name of the LORD your God, And to the Holy One of Israel, Because He has glorified you.

10. "The sons of foreigners shall build up your walls, And their kings shall minister to you; For in My wrath I struck you, But in My favor I have had mercy on you.

11. Therefore your gates shall be open continually; They shall not be shut day or night, That men may bring to you the wealth of the Gentiles, And their kings in procession.

12. For the nation and kingdom which will not serve you shall perish, And those nations shall be utterly ruined.

13. "The glory of Lebanon shall come to you, The cypress, the pine, and the box tree together, To beautify the place of My sanctuary; And I will make the place of My feet glorious.

14. Also the sons of those who afflicted you Shall come bowing to you, And all those who despised you shall fall prostrate at the soles of your feet; And they shall call you The City of the LORD, Zion of the Holy One of Israel.

15. "Whereas you have been forsaken and hated, So that no one went through you, I will make you an eternal excellence, A joy of many generations.

16. You shall drink the milk of the Gentiles, And milk the breast of kings; You shall know that I, the LORD, am your Savior And your Redeemer, the Mighty One of Jacob.

17. "Instead of bronze I will bring gold, Instead of iron I will bring silver, Instead of wood, bronze, And instead of stones, iron. I will also make your officers peace, And your magistrates righteousness.

18. Violence shall no longer be heard in your land, Neither wasting nor destruction within your borders; But you shall call your walls Salvation, And your gates Praise.

19. "The sun shall no longer be your light by day, Nor for brightness shall the moon give light to you; But the LORD will be to you an everlasting light, And your God your glory.

20. Your sun shall no longer go down, Nor shall your moon withdraw itself; For the LORD will be your everlasting light, And the days of your mourning shall be ended.

21. Also your people shall all be righteous; They shall inherit the land forever, The branch of My planting, The work of My hands, That I may be glorified.

22. A little one shall become a thousand, And a small one a strong nation. I, the LORD, will hasten it in its time."

## Chapter 61

1. "The Spirit of the Lord GOD is upon Me, Because the LORD has anointed Me To preach good tidings to the poor; He has sent Me to heal the brokenhearted, To proclaim liberty to the captives, And the opening of the prison to those who are bound;

2. To proclaim the acceptable year of the LORD, And the day of vengeance of our God; To comfort all who mourn,

3. To console those who mourn in Zion, To give them beauty for ashes, The oil of joy for mourning, The garment of praise for the spirit of heaviness; That they may be called trees of righteousness, The planting of the LORD, that He may be glorified."

4. And they shall rebuild the old ruins, They shall raise up the former desolations, And they shall repair the ruined cities, The desolations of many generations.

5. Strangers shall stand and feed your flocks, And the sons of the foreigner Shall be your plowmen and your vinedressers.

6. But you shall be named the priests of the LORD, They shall call you the servants of our God. You shall eat the riches of the Gentiles, And in their glory you shall boast.

7. Instead of your shame you shall have double honor, And instead of confusion they shall rejoice in their portion. Therefore in their land they shall possess double; Everlasting joy shall be theirs.

8. "For I, the LORD, love justice; I hate robbery for burnt offering; I will direct their work in truth, And will make with them an everlasting covenant.

9. Their descendants shall be known among the Gentiles, And their offspring among the people. All who see them shall acknowledge them, That they are the posterity whom the LORD has blessed."

10. I will greatly rejoice in the LORD, My soul shall be joyful in my God; For He has clothed me with the garments of salvation, He has covered me with the robe of righteousness, As a bridegroom decks himself with ornaments, And as a bride adorns herself with her jewels.

11. For as the earth brings forth its bud, As the garden causes the things that are sown in it to spring forth, So the Lord GOD will cause righteousness and praise to spring forth before all the nations.

## Chapter 62

1. For Zion's sake I will not hold My peace, And for Jerusalem's sake I will not rest, Until her righteousness goes forth as brightness, And her salvation as a lamp that burns.

2. The Gentiles shall see your righteousness, And all kings your glory. You shall be called by a new name, Which the mouth of the LORD will name.

3. You shall also be a crown of glory In the hand of the LORD, And a royal diadem In the hand of your God.

4. You shall no longer be termed Forsaken, Nor shall your land any more be termed Desolate; But you shall be called Hephzibah, and your land Beulah; For the LORD delights in you, And your land shall be married.

5. For as a young man marries a virgin, So shall your sons marry you; And as the bridegroom rejoices over the bride, So shall your God rejoice over you.

6. I have set watchmen on your walls, O Jerusalem; They shall never hold their peace day or night. You who make mention of the LORD, do not keep silent,

7. And give Him no rest till He establishes And till He makes Jerusalem a praise in the earth.

8. The LORD has sworn by His right hand And by the arm of His strength: "Surely I will no longer give your grain As food for your enemies; And the sons of the foreigner shall not drink your new wine, For which you have labored.

9. But those who have gathered it shall eat it, And praise the LORD; Those who have brought it together shall drink it in My holy courts."

10. Go through, Go through the gates! Prepare the way for the people; Build up, Build up the highway! Take out the stones, Lift up a banner for the peoples!

11. Indeed the LORD has proclaimed To the end of the world: "Say to the daughter of Zion, "Surely your salvation is coming; Behold, His reward is with Him, And His work before Him."'

12. And they shall call them The Holy People, The Redeemed of the LORD; And you shall be called Sought Out, A City Not Forsaken.

## Chapter 63

1. Who is this who comes from Edom, With dyed garments from Bozrah, This One who is glorious in His apparel, Traveling in the greatness of His strength?-- "I who speak in righteousness, mighty to save."

2. Why is Your apparel red, And Your garments like one who treads in the winepress?

3. "I have trodden the winepress alone, And from the peoples no one was with Me. For I have trodden them in My anger, And trampled them in My fury; Their blood is sprinkled upon My garments, And I have stained all My robes.

4. For the day of vengeance is in My heart, And the year of My redeemed has come.

5. I looked, but there was no one to help, And I wondered That there was no one to uphold; Therefore My own arm brought salvation for Me; And My own fury, it sustained Me.

6. I have trodden down the peoples in My anger, Made them drunk in My fury, And brought down their strength to the earth."

7. I will mention the lovingkindnesses of the LORD And the praises of the LORD, According to all that the LORD has bestowed on us, And the great goodness toward the house of Israel, Which He has bestowed on them according to His mercies, According to the multitude of His lovingkindnesses.

8. For He said, "Surely they are My people, Children who will not lie." So He became their Savior.

9. In all their affliction He was afflicted, And the Angel of His Presence saved them; In His love and in His pity He redeemed them; And He bore them and carried them All the days of old.

10. But they rebelled and grieved His Holy Spirit; So He turned Himself against them as an enemy, And He fought against them.

11. Then he remembered the days of old, Moses and his people, saying: "Where is He who brought them up out of the sea With the shepherd of His flock? Where is He who put His Holy Spirit within them,

12. Who led them by the right hand of Moses, With His glorious arm, Dividing the water before them To make for Himself an everlasting name,

13. Who led them through the deep, As a horse in the wilderness, That they might not stumble?"

14. As a beast goes down into the valley, And the Spirit of the LORD causes him to rest, So You lead Your people, To make Yourself a glorious name.

15. Look down from heaven, And see from Your habitation, holy and glorious. Where are Your zeal and Your strength, The yearning of Your heart and Your mercies toward me? Are they restrained?

16. Doubtless You are our Father, Though Abraham was ignorant of us, And Israel does not acknowledge us. You, O LORD, are our Father; Our Redeemer from Everlasting is Your name.

17. O LORD, why have You made us stray from Your ways, And hardened our heart from Your fear? Return for Your servants' sake, The tribes of Your inheritance.

18. Your holy people have possessed it but a little while; Our adversaries have trodden down Your sanctuary.

19. We have become like those of old, over whom You never ruled, Those who were never called by Your name.

## Chapter 64

1. Oh, that You would rend the heavens! That You would come down! That the mountains might shake at Your presence--

2. As fire burns brushwood, As fire causes water to boil-- To make Your name known to Your adversaries, That the nations may tremble at Your presence!

3. When You did awesome things for which we did not look, You came down, The mountains shook at Your presence.

4. For since the beginning of the world Men have not heard nor perceived by the ear, Nor has the eye seen any God besides You, Who acts for the one who waits for Him.

5. You meet him who rejoices and does righteousness, Who remembers You in Your ways. You are indeed angry, for we have sinned-- In these ways we continue; And we need to be saved.

6. But we are all like an unclean thing, And all our righteousnesses are like filthy rags; We all fade as a leaf, And our iniquities, like the wind, Have taken us away.

7. And there is no one who calls on Your name, Who stirs himself up to take hold of You; For You have hidden Your face from us, And have consumed us because of our iniquities.

8. But now, O LORD, You are our Father; We are the clay, and You our potter; And all we are the work of Your hand.

9. Do not be furious, O LORD, Nor remember iniquity forever; Indeed, please look--we all are Your people!

10. Your holy cities are a wilderness, Zion is a wilderness, Jerusalem a desolation.

11. Our holy and beautiful temple, Where our fathers praised You, Is burned up with fire; And all our pleasant things are laid waste.

12. Will You restrain Yourself because of these things, O LORD? Will You hold Your peace, and afflict us very severely?

## Chapter 65

1. "I was sought by those who did not ask for Me; I was found by those who did not seek Me. I said, "Here I am, here I am,' To a nation that was not called by My name.

2. I have stretched out My hands all day long to a rebellious people, Who walk in a way that is not good, According to their own thoughts;

3. A people who provoke Me to anger continually to My face; Who sacrifice in gardens, And burn incense on altars of brick;

4. Who sit among the graves, And spend the night in the tombs; Who eat swine's flesh, And the broth of abominable things is in their vessels;

5. Who say, "Keep to yourself, Do not come near me, For I am holier than you!' These are smoke in My nostrils, A fire that burns all the day.

6. "Behold, it is written before Me: I will not keep silence, but will repay-- Even repay into their bosom--

7. Your iniquities and the iniquities of your fathers together," Says the LORD, "Who have burned incense on the mountains And blasphemed Me on the hills; Therefore I will measure their former work into their bosom."

8. Thus says the LORD: "As the new wine is found in the cluster, And one says, "Do not destroy it, For a blessing is in it,' So will I do for My servants' sake, That I may not destroy them all.

9. I will bring forth descendants from Jacob, And from Judah an heir of My mountains; My elect shall inherit it, And My servants shall dwell there.

10. Sharon shall be a fold of flocks, And the Valley of Achor a place for herds to lie down, For My people who have sought Me.

11. "But you are those who forsake the LORD, Who forget My holy mountain, Who prepare a table for Gad, And who furnish a drink offering for Meni.

12. Therefore I will number you for the sword, And you shall all bow down to the slaughter; Because, when I called, you did not answer; When I spoke, you did not hear, But did evil before My eyes, And chose that in which I do not delight."

13. Therefore thus says the Lord GOD: "Behold, My servants shall eat, But you shall be hungry; Behold, My servants shall drink, But you shall be thirsty; Behold, My servants shall rejoice, But you shall be ashamed;

14. Behold, My servants shall sing for joy of heart, But you shall cry for sorrow of heart, And wail for grief of spirit.

15. You shall leave your name as a curse to My chosen; For the Lord GOD will slay you, And call His servants by another name;

16. So that he who blesses himself in the earth Shall bless himself in the God of truth; And he who swears in the earth Shall swear by the God of truth; Because the former troubles are forgotten, And because they are hidden from My eyes.

17. "For behold, I create new heavens and a new earth; And the former shall not be remembered or come to mind.

18. But be glad and rejoice forever in what I create; For behold, I create Jerusalem as a rejoicing, And her people a joy.

19. I will rejoice in Jerusalem, And joy in My people; The voice of weeping shall no longer be heard in her, Nor the voice of crying.

20. "No more shall an infant from there live but a few days, Nor an old man who has not fulfilled his days; For the child shall die one hundred years old, But the sinner being one hundred years old shall be accursed.

21. They shall build houses and inhabit them; They shall plant vineyards and eat their fruit.

22. They shall not build and another inhabit; They shall not plant and another eat; For as the days of a tree, so shall be the days of My people, And My elect shall long enjoy the work of their hands.

23. They shall not labor in vain, Nor bring forth children for trouble; For they shall be the descendants of the blessed of the LORD, And their offspring with them.

24. "It shall come to pass That before they call, I will answer; And while they are still speaking, I will hear.

25. The wolf and the lamb shall feed together, The lion shall eat straw like the ox, And dust shall be the serpent's food. They shall not hurt nor destroy in all My holy mountain," Says the LORD.

## Chapter 66

1. Thus says the LORD: "Heaven is My throne, And earth is My footstool. Where is the house that you will build Me? And where is the place of My rest?

2. For all those things My hand has made, And all those things exist," Says the LORD. "But on this one will I look: On him who is poor and of a contrite spirit, And who trembles at My word.

3. "He who kills a bull is as if he slays a man; He who sacrifices a lamb, as if he breaks a dog's neck; He who offers a grain offering, as if he offers swine's blood; He who burns incense, as if he blesses an idol. Just as they have chosen their own ways, And their soul delights in their abominations,

4. So will I choose their delusions, And bring their fears on them; Because, when I called, no one answered, When I spoke they did not hear; But they did evil before My eyes, And chose that in which I do not delight."

5. Hear the word of the LORD, You who tremble at His word: "Your brethren who hated you, Who cast you out for My name's sake, said, "Let the LORD be glorified, That we may see your joy.' But they shall be ashamed."

6. The sound of noise from the city! A voice from the temple! The voice of the LORD, Who fully repays His enemies!

7. "Before she was in labor, she gave birth; Before her pain came, She delivered a male child.

8. Who has heard such a thing? Who has seen such things? Shall the earth be made to give birth in one day? Or shall a nation be born at once? For as soon as Zion was in labor, She gave birth to her children.

9. Shall I bring to the time of birth, and not cause delivery?" says the LORD. "Shall I who cause delivery shut up the womb?" says your God.

10. "Rejoice with Jerusalem, And be glad with her, all you who love her; Rejoice for joy with her, all you who mourn for her;

11. That you may feed and be satisfied With the consolation of her bosom, That you may drink deeply and be delighted With the abundance of her glory."

12. For thus says the LORD: "Behold, I will extend peace to her like a river, And the glory of the Gentiles like a flowing stream. Then you shall feed; On her sides shall you be carried, And be dandled on her knees.

13. As one whom his mother comforts, So I will comfort you; And you shall be comforted in Jerusalem."

14. When you see this, your heart shall rejoice, And your bones shall flourish like grass; The hand of the LORD shall be known to His servants, And His indignation to His enemies.

15. For behold, the LORD will come with fire And with His chariots, like a whirlwind, To render His anger with fury, And His rebuke with flames of fire.

16. For by fire and by His sword The LORD will judge all flesh; And the slain of the LORD shall be many.

17. "Those who sanctify themselves and purify themselves, To go to the gardens After an idol in the midst, Eating swine's flesh and the abomination and the mouse, Shall be consumed together," says the LORD.

18. "For I know their works and their thoughts. It shall be that I will gather all nations and tongues; and they shall come and see My glory.

19. I will set a sign among them; and those among them who escape I will send to the nations: to Tarshish and Pul and Lud, who draw the bow, and Tubal and Javan, to the coastlands afar off who have not heard My fame nor seen My glory. And they shall declare My glory among the Gentiles.

20. Then they shall bring all your brethren for an offering to the LORD out of all nations, on horses and in chariots and in litters, on mules and on camels, to My holy mountain Jerusalem," says the LORD, "as the children of Israel bring an offering in a clean vessel into the house of the LORD.

21. And I will also take some of them for priests and Levites," says the LORD.

22. "For as the new heavens and the new earth Which I will make shall remain before Me," says the LORD, "So shall your descendants and your name remain.

23. And it shall come to pass That from one New Moon to another, And from one Sabbath to another, All flesh shall come to worship before Me," says the LORD.

24. "And they shall go forth and look Upon the corpses of the men Who have transgressed against Me. For their worm does not die, And their fire is not quenched. They shall be an abhorrence to all flesh."


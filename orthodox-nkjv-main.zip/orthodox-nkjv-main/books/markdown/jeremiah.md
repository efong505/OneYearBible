# jeremiah

## Chapter 1

1. The words of Jeremiah the son of Hilkiah, of the priests who were in Anathoth in the land of Benjamin,

2. to whom the word of the LORD came in the days of Josiah the son of Amon, king of Judah, in the thirteenth year of his reign.

3. It came also in the days of Jehoiakim the son of Josiah, king of Judah, until the end of the eleventh year of Zedekiah the son of Josiah, king of Judah, until the carrying away of Jerusalem captive in the fifth month.

4. Then the word of the LORD came to me, saying:

5. "Before I formed you in the womb I knew you; Before you were born I sanctified you; I ordained you a prophet to the nations."

6. Then said I: "Ah, Lord GOD! Behold, I cannot speak, for I am a youth."

7. But the LORD said to me: "Do not say, "I am a youth,' For you shall go to all to whom I send you, And whatever I command you, you shall speak.

8. Do not be afraid of their faces, For I am with you to deliver you," says the LORD.

9. Then the LORD put forth His hand and touched my mouth, and the LORD said to me: "Behold, I have put My words in your mouth.

10. See, I have this day set you over the nations and over the kingdoms, To root out and to pull down, To destroy and to throw down, To build and to plant."

11. Moreover the word of the LORD came to me, saying, "Jeremiah, what do you see?" And I said, "I see a branch of an almond tree."

12. Then the LORD said to me, "You have seen well, for I am ready to perform My word."

13. And the word of the LORD came to me the second time, saying, "What do you see?" And I said, "I see a boiling pot, and it is facing away from the north."

14. Then the LORD said to me: "Out of the north calamity shall break forth On all the inhabitants of the land.

15. For behold, I am calling All the families of the kingdoms of the north," says the LORD; "They shall come and each one set his throne At the entrance of the gates of Jerusalem, Against all its walls all around, And against all the cities of Judah.

16. I will utter My judgments Against them concerning all their wickedness, Because they have forsaken Me, Burned incense to other gods, And worshiped the works of their own hands.

17. "Therefore prepare yourself and arise, And speak to them all that I command you. Do not be dismayed before their faces, Lest I dismay you before them.

18. For behold, I have made you this day A fortified city and an iron pillar, And bronze walls against the whole land-- Against the kings of Judah, Against its princes, Against its priests, And against the people of the land.

19. They will fight against you, But they shall not prevail against you. For I am with you," says the LORD, "to deliver you."

## Chapter 2

1. Moreover the word of the LORD came to me, saying,

2. "Go and cry in the hearing of Jerusalem, saying, "Thus says the LORD: "I remember you, The kindness of your youth, The love of your betrothal, When you went after Me in the wilderness, In a land not sown.

3. Israel was holiness to the LORD, The firstfruits of His increase. All that devour him will offend; Disaster will come upon them," says the LORD."'

4. Hear the word of the LORD, O house of Jacob and all the families of the house of Israel.

5. Thus says the LORD: "What injustice have your fathers found in Me, That they have gone far from Me, Have followed idols, And have become idolaters?

6. Neither did they say, "Where is the LORD, Who brought us up out of the land of Egypt, Who led us through the wilderness, Through a land of deserts and pits, Through a land of drought and the shadow of death, Through a land that no one crossed And where no one dwelt?'

7. I brought you into a bountiful country, To eat its fruit and its goodness. But when you entered, you defiled My land And made My heritage an abomination.

8. The priests did not say, "Where is the LORD?' And those who handle the law did not know Me; The rulers also transgressed against Me; The prophets prophesied by Baal, And walked after things that do not profit.

9. "Therefore I will yet bring charges against you," says the LORD, "And against your children's children I will bring charges.

10. For pass beyond the coasts of Cyprus and see, Send to Kedar and consider diligently, And see if there has been such a thing.

11. Has a nation changed its gods, Which are not gods? But My people have changed their Glory For what does not profit.

12. Be astonished, O heavens, at this, And be horribly afraid; Be very desolate," says the LORD.

13. "For My people have committed two evils: They have forsaken Me, the fountain of living waters, And hewn themselves cisterns--broken cisterns that can hold no water.

14. "Is Israel a servant? Is he a homeborn slave? Why is he plundered?

15. The young lions roared at him, and growled; They made his land waste; His cities are burned, without inhabitant.

16. Also the people of Noph and Tahpanhes Have broken the crown of your head.

17. Have you not brought this on yourself, In that you have forsaken the LORD your God When He led you in the way?

18. And now why take the road to Egypt, To drink the waters of Sihor? Or why take the road to Assyria, To drink the waters of the River?

19. Your own wickedness will correct you, And your backslidings will rebuke you. Know therefore and see that it is an evil and bitter thing That you have forsaken the LORD your God, And the fear of Me is not in you," Says the Lord GOD of hosts.

20. "For of old I have broken your yoke and burst your bonds; And you said, "I will not transgress,' When on every high hill and under every green tree You lay down, playing the harlot.

21. Yet I had planted you a noble vine, a seed of highest quality. How then have you turned before Me Into the degenerate plant of an alien vine?

22. For though you wash yourself with lye, and use much soap, Yet your iniquity is marked before Me," says the Lord GOD.

23. "How can you say, "I am not polluted, I have not gone after the Baals'? See your way in the valley; Know what you have done: You are a swift dromedary breaking loose in her ways,

24. A wild donkey used to the wilderness, That sniffs at the wind in her desire; In her time of mating, who can turn her away? All those who seek her will not weary themselves; In her month they will find her.

25. Withhold your foot from being unshod, and your throat from thirst. But you said, "There is no hope. No! For I have loved aliens, and after them I will go.'

26. "As the thief is ashamed when he is found out, So is the house of Israel ashamed; They and their kings and their princes, and their priests and their prophets,

27. Saying to a tree, "You are my father,' And to a stone, "You gave birth to me.' For they have turned their back to Me, and not their face. But in the time of their trouble They will say, "Arise and save us.'

28. But where are your gods that you have made for yourselves? Let them arise, If they can save you in the time of your trouble; For according to the number of your cities Are your gods, O Judah.

29. "Why will you plead with Me? You all have transgressed against Me," says the LORD.

30. "In vain I have chastened your children; They received no correction. Your sword has devoured your prophets Like a destroying lion.

31. "O generation, see the word of the LORD! Have I been a wilderness to Israel, Or a land of darkness? Why do My people say, "We are lords; We will come no more to You'?

32. Can a virgin forget her ornaments, Or a bride her attire? Yet My people have forgotten Me days without number.

33. "Why do you beautify your way to seek love? Therefore you have also taught The wicked women your ways.

34. Also on your skirts is found The blood of the lives of the poor innocents. I have not found it by secret search, But plainly on all these things.

35. Yet you say, "Because I am innocent, Surely His anger shall turn from me.' Behold, I will plead My case against you, Because you say, "I have not sinned.'

36. Why do you gad about so much to change your way? Also you shall be ashamed of Egypt as you were ashamed of Assyria.

37. Indeed you will go forth from him With your hands on your head; For the LORD has rejected your trusted allies, And you will not prosper by them.

## Chapter 3

1. "They say, "If a man divorces his wife, And she goes from him And becomes another man's, May he return to her again?' Would not that land be greatly polluted? But you have played the harlot with many lovers; Yet return to Me," says the LORD.

2. "Lift up your eyes to the desolate heights and see: Where have you not lain with men? By the road you have sat for them Like an Arabian in the wilderness; And you have polluted the land With your harlotries and your wickedness.

3. Therefore the showers have been withheld, And there has been no latter rain. You have had a harlot's forehead; You refuse to be ashamed.

4. Will you not from this time cry to Me, "My Father, You are the guide of my youth?

5. Will He remain angry forever? Will He keep it to the end?' Behold, you have spoken and done evil things, As you were able."

6. The LORD said also to me in the days of Josiah the king: "Have you seen what backsliding Israel has done? She has gone up on every high mountain and under every green tree, and there played the harlot.

7. And I said, after she had done all these things, "Return to Me.' But she did not return. And her treacherous sister Judah saw it.

8. Then I saw that for all the causes for which backsliding Israel had committed adultery, I had put her away and given her a certificate of divorce; yet her treacherous sister Judah did not fear, but went and played the harlot also.

9. So it came to pass, through her casual harlotry, that she defiled the land and committed adultery with stones and trees.

10. And yet for all this her treacherous sister Judah has not turned to Me with her whole heart, but in pretense," says the LORD.

11. Then the LORD said to me, "Backsliding Israel has shown herself more righteous than treacherous Judah.

12. Go and proclaim these words toward the north, and say: "Return, backsliding Israel,' says the LORD; "I will not cause My anger to fall on you. For I am merciful,' says the LORD; "I will not remain angry forever.

13. Only acknowledge your iniquity, That you have transgressed against the LORD your God, And have scattered your charms To alien deities under every green tree, And you have not obeyed My voice,' says the LORD.

14. "Return, O backsliding children," says the LORD; "for I am married to you. I will take you, one from a city and two from a family, and I will bring you to Zion.

15. And I will give you shepherds according to My heart, who will feed you with knowledge and understanding.

16. "Then it shall come to pass, when you are multiplied and increased in the land in those days," says the LORD, "that they will say no more, "The ark of the covenant of the LORD.' It shall not come to mind, nor shall they remember it, nor shall they visit it, nor shall it be made anymore.

17. "At that time Jerusalem shall be called The Throne of the LORD, and all the nations shall be gathered to it, to the name of the LORD, to Jerusalem. No more shall they follow the dictates of their evil hearts.

18. "In those days the house of Judah shall walk with the house of Israel, and they shall come together out of the land of the north to the land that I have given as an inheritance to your fathers.

19. "But I said: "How can I put you among the children And give you a pleasant land, A beautiful heritage of the hosts of nations?' "And I said: "You shall call Me, "My Father," And not turn away from Me.'

20. Surely, as a wife treacherously departs from her husband, So have you dealt treacherously with Me, O house of Israel," says the LORD.

21. A voice was heard on the desolate heights, Weeping and supplications of the children of Israel. For they have perverted their way; They have forgotten the LORD their God.

22. "Return, you backsliding children, And I will heal your backslidings." "Indeed we do come to You, For You are the LORD our God.

23. Truly, in vain is salvation hoped for from the hills, And from the multitude of mountains; Truly, in the LORD our God Is the salvation of Israel.

24. For shame has devoured The labor of our fathers from our youth-- Their flocks and their herds, Their sons and their daughters.

25. We lie down in our shame, And our reproach covers us. For we have sinned against the LORD our God, We and our fathers, From our youth even to this day, And have not obeyed the voice of the LORD our God."

## Chapter 4

1. "If you will return, O Israel," says the LORD, "Return to Me; And if you will put away your abominations out of My sight, Then you shall not be moved.

2. And you shall swear, "The LORD lives,' In truth, in judgment, and in righteousness; The nations shall bless themselves in Him, And in Him they shall glory."

3. For thus says the LORD to the men of Judah and Jerusalem: "Break up your fallow ground, And do not sow among thorns.

4. Circumcise yourselves to the LORD, And take away the foreskins of your hearts, You men of Judah and inhabitants of Jerusalem, Lest My fury come forth like fire, And burn so that no one can quench it, Because of the evil of your doings."

5. Declare in Judah and proclaim in Jerusalem, and say: "Blow the trumpet in the land; Cry, "Gather together,' And say, "Assemble yourselves, And let us go into the fortified cities.'

6. Set up the standard toward Zion. Take refuge! Do not delay! For I will bring disaster from the north, And great destruction."

7. The lion has come up from his thicket, And the destroyer of nations is on his way. He has gone forth from his place To make your land desolate. Your cities will be laid waste, Without inhabitant.

8. For this, clothe yourself with sackcloth, Lament and wail. For the fierce anger of the LORD Has not turned back from us.

9. "And it shall come to pass in that day," says the LORD, "That the heart of the king shall perish, And the heart of the princes; The priests shall be astonished, And the prophets shall wonder."

10. Then I said, "Ah, Lord GOD! Surely You have greatly deceived this people and Jerusalem, Saying, "You shall have peace,' Whereas the sword reaches to the heart."

11. At that time it will be said To this people and to Jerusalem, "A dry wind of the desolate heights blows in the wilderness Toward the daughter of My people-- Not to fan or to cleanse--

12. A wind too strong for these will come for Me; Now I will also speak judgment against them."

13. "Behold, he shall come up like clouds, And his chariots like a whirlwind. His horses are swifter than eagles. Woe to us, for we are plundered!"

14. O Jerusalem, wash your heart from wickedness, That you may be saved. How long shall your evil thoughts lodge within you?

15. For a voice declares from Dan And proclaims affliction from Mount Ephraim:

16. "Make mention to the nations, Yes, proclaim against Jerusalem, That watchers come from a far country And raise their voice against the cities of Judah.

17. Like keepers of a field they are against her all around, Because she has been rebellious against Me," says the LORD.

18. "Your ways and your doings Have procured these things for you. This is your wickedness, Because it is bitter, Because it reaches to your heart."

19. O my soul, my soul! I am pained in my very heart! My heart makes a noise in me; I cannot hold my peace, Because you have heard, O my soul, The sound of the trumpet, The alarm of war.

20. Destruction upon destruction is cried, For the whole land is plundered. Suddenly my tents are plundered, And my curtains in a moment.

21. How long will I see the standard, And hear the sound of the trumpet?

22. "For My people are foolish, They have not known Me. They are silly children, And they have no understanding. They are wise to do evil, But to do good they have no knowledge."

23. I beheld the earth, and indeed it was without form, and void; And the heavens, they had no light.

24. I beheld the mountains, and indeed they trembled, And all the hills moved back and forth.

25. I beheld, and indeed there was no man, And all the birds of the heavens had fled.

26. I beheld, and indeed the fruitful land was a wilderness, And all its cities were broken down At the presence of the LORD, By His fierce anger.

27. For thus says the LORD: "The whole land shall be desolate; Yet I will not make a full end.

28. For this shall the earth mourn, And the heavens above be black, Because I have spoken. I have purposed and will not relent, Nor will I turn back from it.

29. The whole city shall flee from the noise of the horsemen and bowmen. They shall go into thickets and climb up on the rocks. Every city shall be forsaken, And not a man shall dwell in it.

30. "And when you are plundered, What will you do? Though you clothe yourself with crimson, Though you adorn yourself with ornaments of gold, Though you enlarge your eyes with paint, In vain you will make yourself fair; Your lovers will despise you; They will seek your life.

31. "For I have heard a voice as of a woman in labor, The anguish as of her who brings forth her first child, The voice of the daughter of Zion bewailing herself; She spreads her hands, saying, "Woe is me now, for my soul is weary Because of murderers!'

## Chapter 5

1. "Run to and fro through the streets of Jerusalem; See now and know; And seek in her open places If you can find a man, If there is anyone who executes judgment, Who seeks the truth, And I will pardon her.

2. Though they say, "As the LORD lives,' Surely they swear falsely."

3. O LORD, are not Your eyes on the truth? You have stricken them, But they have not grieved; You have consumed them, But they have refused to receive correction. They have made their faces harder than rock; They have refused to return.

4. Therefore I said, "Surely these are poor. They are foolish; For they do not know the way of the LORD, The judgment of their God.

5. I will go to the great men and speak to them, For they have known the way of the LORD, The judgment of their God." But these have altogether broken the yoke And burst the bonds.

6. Therefore a lion from the forest shall slay them, A wolf of the deserts shall destroy them; A leopard will watch over their cities. Everyone who goes out from there shall be torn in pieces, Because their transgressions are many; Their backslidings have increased.

7. "How shall I pardon you for this? Your children have forsaken Me And sworn by those that are not gods. When I had fed them to the full, Then they committed adultery And assembled themselves by troops in the harlots' houses.

8. They were like well-fed lusty stallions; Every one neighed after his neighbor's wife.

9. Shall I not punish them for these things?" says the LORD. "And shall I not avenge Myself on such a nation as this?

10. "Go up on her walls and destroy, But do not make a complete end. Take away her branches, For they are not the LORD's.

11. For the house of Israel and the house of Judah Have dealt very treacherously with Me," says the LORD.

12. They have lied about the LORD, And said, "It is not He. Neither will evil come upon us, Nor shall we see sword or famine.

13. And the prophets become wind, For the word is not in them. Thus shall it be done to them."

14. Therefore thus says the LORD God of hosts: "Because you speak this word, Behold, I will make My words in your mouth fire, And this people wood, And it shall devour them.

15. Behold, I will bring a nation against you from afar, O house of Israel," says the LORD. "It is a mighty nation, It is an ancient nation, A nation whose language you do not know, Nor can you understand what they say.

16. Their quiver is like an open tomb; They are all mighty men.

17. And they shall eat up your harvest and your bread, Which your sons and daughters should eat. They shall eat up your flocks and your herds; They shall eat up your vines and your fig trees; They shall destroy your fortified cities, In which you trust, with the sword.

18. "Nevertheless in those days," says the LORD, "I will not make a complete end of you.

19. And it will be when you say, "Why does the LORD our God do all these things to us?' then you shall answer them, "Just as you have forsaken Me and served foreign gods in your land, so you shall serve aliens in a land that is not yours.'

20. "Declare this in the house of Jacob And proclaim it in Judah, saying,

21. "Hear this now, O foolish people, Without understanding, Who have eyes and see not, And who have ears and hear not:

22. Do you not fear Me?' says the LORD. "Will you not tremble at My presence, Who have placed the sand as the bound of the sea, By a perpetual decree, that it cannot pass beyond it? And though its waves toss to and fro, Yet they cannot prevail; Though they roar, yet they cannot pass over it.

23. But this people has a defiant and rebellious heart; They have revolted and departed.

24. They do not say in their heart, "Let us now fear the LORD our God, Who gives rain, both the former and the latter, in its season. He reserves for us the appointed weeks of the harvest."

25. Your iniquities have turned these things away, And your sins have withheld good from you.

26. "For among My people are found wicked men; They lie in wait as one who sets snares; They set a trap; They catch men.

27. As a cage is full of birds, So their houses are full of deceit. Therefore they have become great and grown rich.

28. They have grown fat, they are sleek; Yes, they surpass the deeds of the wicked; They do not plead the cause, The cause of the fatherless; Yet they prosper, And the right of the needy they do not defend.

29. Shall I not punish them for these things?' says the LORD. "Shall I not avenge Myself on such a nation as this?'

30. "An astonishing and horrible thing Has been committed in the land:

31. The prophets prophesy falsely, And the priests rule by their own power; And My people love to have it so. But what will you do in the end?

## Chapter 6

1. "O you children of Benjamin, Gather yourselves to flee from the midst of Jerusalem! Blow the trumpet in Tekoa, And set up a signal-fire in Beth Haccerem; For disaster appears out of the north, And great destruction.

2. I have likened the daughter of Zion To a lovely and delicate woman.

3. The shepherds with their flocks shall come to her. They shall pitch their tents against her all around. Each one shall pasture in his own place."

4. "Prepare war against her; Arise, and let us go up at noon. Woe to us, for the day goes away, For the shadows of the evening are lengthening.

5. Arise, and let us go by night, And let us destroy her palaces."

6. For thus has the LORD of hosts said: "Cut down trees, And build a mound against Jerusalem. This is the city to be punished. She is full of oppression in her midst.

7. As a fountain wells up with water, So she wells up with her wickedness. Violence and plundering are heard in her. Before Me continually are grief and wounds.

8. Be instructed, O Jerusalem, Lest My soul depart from you; Lest I make you desolate, A land not inhabited."

9. Thus says the LORD of hosts: "They shall thoroughly glean as a vine the remnant of Israel; As a grape-gatherer, put your hand back into the branches."

10. To whom shall I speak and give warning, That they may hear? Indeed their ear is uncircumcised, And they cannot give heed. Behold, the word of the LORD is a reproach to them; They have no delight in it.

11. Therefore I am full of the fury of the LORD. I am weary of holding it in. "I will pour it out on the children outside, And on the assembly of young men together; For even the husband shall be taken with the wife, The aged with him who is full of days.

12. And their houses shall be turned over to others, Fields and wives together; For I will stretch out My hand Against the inhabitants of the land," says the LORD.

13. "Because from the least of them even to the greatest of them, Everyone is given to covetousness; And from the prophet even to the priest, Everyone deals falsely.

14. They have also healed the hurt of My people slightly, Saying, "Peace, peace!' When there is no peace.

15. Were they ashamed when they had committed abomination? No! They were not at all ashamed; Nor did they know how to blush. Therefore they shall fall among those who fall; At the time I punish them, They shall be cast down," says the LORD.

16. Thus says the LORD: "Stand in the ways and see, And ask for the old paths, where the good way is, And walk in it; Then you will find rest for your souls. But they said, "We will not walk in it.'

17. Also, I set watchmen over you, saying, "Listen to the sound of the trumpet!' But they said, "We will not listen.'

18. Therefore hear, you nations, And know, O congregation, what is among them.

19. Hear, O earth! Behold, I will certainly bring calamity on this people-- The fruit of their thoughts, Because they have not heeded My words Nor My law, but rejected it.

20. For what purpose to Me Comes frankincense from Sheba, And sweet cane from a far country? Your burnt offerings are not acceptable, Nor your sacrifices sweet to Me."

21. Therefore thus says the LORD: "Behold, I will lay stumbling blocks before this people, And the fathers and the sons together shall fall on them. The neighbor and his friend shall perish."

22. Thus says the LORD: "Behold, a people comes from the north country, And a great nation will be raised from the farthest parts of the earth.

23. They will lay hold on bow and spear; They are cruel and have no mercy; Their voice roars like the sea; And they ride on horses, As men of war set in array against you, O daughter of Zion."

24. We have heard the report of it; Our hands grow feeble. Anguish has taken hold of us, Pain as of a woman in labor.

25. Do not go out into the field, Nor walk by the way. Because of the sword of the enemy, Fear is on every side.

26. O daughter of my people, Dress in sackcloth And roll about in ashes! Make mourning as for an only son, most bitter lamentation; For the plunderer will suddenly come upon us.

27. "I have set you as an assayer and a fortress among My people, That you may know and test their way.

28. They are all stubborn rebels, walking as slanderers. They are bronze and iron, They are all corrupters;

29. The bellows blow fiercely, The lead is consumed by the fire; The smelter refines in vain, For the wicked are not drawn off.

30. People will call them rejected silver, Because the LORD has rejected them."

## Chapter 7

1. The word that came to Jeremiah from the LORD, saying,

2. "Stand in the gate of the LORD's house, and proclaim there this word, and say, "Hear the word of the LORD, all you of Judah who enter in at these gates to worship the LORD!"'

3. Thus says the LORD of hosts, the God of Israel: "Amend your ways and your doings, and I will cause you to dwell in this place.

4. Do not trust in these lying words, saying, "The temple of the LORD, the temple of the LORD, the temple of the LORD are these.'

5. "For if you thoroughly amend your ways and your doings, if you thoroughly execute judgment between a man and his neighbor,

6. if you do not oppress the stranger, the fatherless, and the widow, and do not shed innocent blood in this place, or walk after other gods to your hurt,

7. then I will cause you to dwell in this place, in the land that I gave to your fathers forever and ever.

8. "Behold, you trust in lying words that cannot profit.

9. Will you steal, murder, commit adultery, swear falsely, burn incense to Baal, and walk after other gods whom you do not know,

10. and then come and stand before Me in this house which is called by My name, and say, "We are delivered to do all these abominations'?

11. Has this house, which is called by My name, become a den of thieves in your eyes? Behold, I, even I, have seen it," says the LORD.

12. "But go now to My place which was in Shiloh, where I set My name at the first, and see what I did to it because of the wickedness of My people Israel.

13. And now, because you have done all these works," says the LORD, "and I spoke to you, rising up early and speaking, but you did not hear, and I called you, but you did not answer,

14. therefore I will do to the house which is called by My name, in which you trust, and to this place which I gave to you and your fathers, as I have done to Shiloh.

15. And I will cast you out of My sight, as I have cast out all your brethren--the whole posterity of Ephraim.

16. "Therefore do not pray for this people, nor lift up a cry or prayer for them, nor make intercession to Me; for I will not hear you.

17. Do you not see what they do in the cities of Judah and in the streets of Jerusalem?

18. The children gather wood, the fathers kindle the fire, and the women knead dough, to make cakes for the queen of heaven; and they pour out drink offerings to other gods, that they may provoke Me to anger.

19. Do they provoke Me to anger?" says the LORD. "Do they not provoke themselves, to the shame of their own faces?"

20. Therefore thus says the Lord GOD: "Behold, My anger and My fury will be poured out on this place--on man and on beast, on the trees of the field and on the fruit of the ground. And it will burn and not be quenched."

21. Thus says the LORD of hosts, the God of Israel: "Add your burnt offerings to your sacrifices and eat meat.

22. For I did not speak to your fathers, or command them in the day that I brought them out of the land of Egypt, concerning burnt offerings or sacrifices.

23. But this is what I commanded them, saying, "Obey My voice, and I will be your God, and you shall be My people. And walk in all the ways that I have commanded you, that it may be well with you.'

24. Yet they did not obey or incline their ear, but followed the counsels and the dictates of their evil hearts, and went backward and not forward.

25. Since the day that your fathers came out of the land of Egypt until this day, I have even sent to you all My servants the prophets, daily rising up early and sending them.

26. Yet they did not obey Me or incline their ear, but stiffened their neck. They did worse than their fathers.

27. "Therefore you shall speak all these words to them, but they will not obey you. You shall also call to them, but they will not answer you.

28. "So you shall say to them, "This is a nation that does not obey the voice of the LORD their God nor receive correction. Truth has perished and has been cut off from their mouth.

29. Cut off your hair and cast it away, and take up a lamentation on the desolate heights; for the LORD has rejected and forsaken the generation of His wrath.'

30. For the children of Judah have done evil in My sight," says the LORD. "They have set their abominations in the house which is called by My name, to pollute it.

31. And they have built the high places of Tophet, which is in the Valley of the Son of Hinnom, to burn their sons and their daughters in the fire, which I did not command, nor did it come into My heart.

32. "Therefore behold, the days are coming," says the LORD, "when it will no more be called Tophet, or the Valley of the Son of Hinnom, but the Valley of Slaughter; for they will bury in Tophet until there is no room.

33. The corpses of this people will be food for the birds of the heaven and for the beasts of the earth. And no one will frighten them away.

34. Then I will cause to cease from the cities of Judah and from the streets of Jerusalem the voice of mirth and the voice of gladness, the voice of the bridegroom and the voice of the bride. For the land shall be desolate.

## Chapter 8

1. "At that time," says the LORD, "they shall bring out the bones of the kings of Judah, and the bones of its princes, and the bones of the priests, and the bones of the prophets, and the bones of the inhabitants of Jerusalem, out of their graves.

2. They shall spread them before the sun and the moon and all the host of heaven, which they have loved and which they have served and after which they have walked, which they have sought and which they have worshiped. They shall not be gathered nor buried; they shall be like refuse on the face of the earth.

3. Then death shall be chosen rather than life by all the residue of those who remain of this evil family, who remain in all the places where I have driven them," says the LORD of hosts.

4. "Moreover you shall say to them, "Thus says the LORD: "Will they fall and not rise? Will one turn away and not return?

5. Why has this people slidden back, Jerusalem, in a perpetual backsliding? They hold fast to deceit, They refuse to return.

6. I listened and heard, But they do not speak aright. No man repented of his wickedness, Saying, "What have I done?' Everyone turned to his own course, As the horse rushes into the battle.

7. "Even the stork in the heavens Knows her appointed times; And the turtledove, the swift, and the swallow Observe the time of their coming. But My people do not know the judgment of the LORD.

8. "How can you say, "We are wise, And the law of the LORD is with us'? Look, the false pen of the scribe certainly works falsehood.

9. The wise men are ashamed, They are dismayed and taken. Behold, they have rejected the word of the LORD; So what wisdom do they have?

10. Therefore I will give their wives to others, And their fields to those who will inherit them; Because from the least even to the greatest Everyone is given to covetousness; From the prophet even to the priest Everyone deals falsely.

11. For they have healed the hurt of the daughter of My people slightly, Saying, "Peace, peace!' When there is no peace.

12. Were they ashamed when they had committed abomination? No! They were not at all ashamed, Nor did they know how to blush. Therefore they shall fall among those who fall; In the time of their punishment They shall be cast down," says the LORD.

13. "I will surely consume them," says the LORD. "No grapes shall be on the vine, Nor figs on the fig tree, And the leaf shall fade; And the things I have given them shall pass away from them.""'

14. "Why do we sit still? Assemble yourselves, And let us enter the fortified cities, And let us be silent there. For the LORD our God has put us to silence And given us water of gall to drink, Because we have sinned against the LORD.

15. "We looked for peace, but no good came; And for a time of health, and there was trouble!

16. The snorting of His horses was heard from Dan. The whole land trembled at the sound of the neighing of His strong ones; For they have come and devoured the land and all that is in it, The city and those who dwell in it."

17. "For behold, I will send serpents among you, Vipers which cannot be charmed, And they shall bite you," says the LORD.

18. I would comfort myself in sorrow; My heart is faint in me.

19. Listen! The voice, The cry of the daughter of my people From a far country: "Is not the LORD in Zion? Is not her King in her?" "Why have they provoked Me to anger With their carved images-- With foreign idols?"

20. "The harvest is past, The summer is ended, And we are not saved!"

21. For the hurt of the daughter of my people I am hurt. I am mourning; Astonishment has taken hold of me.

22. Is there no balm in Gilead, Is there no physician there? Why then is there no recovery For the health of the daughter of my people?

## Chapter 9

1. Oh, that my head were waters, And my eyes a fountain of tears, That I might weep day and night For the slain of the daughter of my people!

2. Oh, that I had in the wilderness A lodging place for travelers; That I might leave my people, And go from them! For they are all adulterers, An assembly of treacherous men.

3. "And like their bow they have bent their tongues for lies. They are not valiant for the truth on the earth. For they proceed from evil to evil, And they do not know Me," says the LORD.

4. "Everyone take heed to his neighbor, And do not trust any brother; For every brother will utterly supplant, And every neighbor will walk with slanderers.

5. Everyone will deceive his neighbor, And will not speak the truth; They have taught their tongue to speak lies; They weary themselves to commit iniquity.

6. Your dwelling place is in the midst of deceit; Through deceit they refuse to know Me," says the LORD.

7. Therefore thus says the LORD of hosts: "Behold, I will refine them and try them; For how shall I deal with the daughter of My people?

8. Their tongue is an arrow shot out; It speaks deceit; One speaks peaceably to his neighbor with his mouth, But in his heart he lies in wait.

9. Shall I not punish them for these things?" says the LORD. "Shall I not avenge Myself on such a nation as this?"

10. I will take up a weeping and wailing for the mountains, And for the dwelling places of the wilderness a lamentation, Because they are burned up, So that no one can pass through; Nor can men hear the voice of the cattle. Both the birds of the heavens and the beasts have fled; They are gone.

11. "I will make Jerusalem a heap of ruins, a den of jackals. I will make the cities of Judah desolate, without an inhabitant."

12. Who is the wise man who may understand this? And who is he to whom the mouth of the LORD has spoken, that he may declare it? Why does the land perish and burn up like a wilderness, so that no one can pass through?

13. And the LORD said, "Because they have forsaken My law which I set before them, and have not obeyed My voice, nor walked according to it,

14. but they have walked according to the dictates of their own hearts and after the Baals, which their fathers taught them,"

15. therefore thus says the LORD of hosts, the God of Israel: "Behold, I will feed them, this people, with wormwood, and give them water of gall to drink.

16. I will scatter them also among the Gentiles, whom neither they nor their fathers have known. And I will send a sword after them until I have consumed them."

17. Thus says the LORD of hosts: "Consider and call for the mourning women, That they may come; And send for skillful wailing women, That they may come.

18. Let them make haste And take up a wailing for us, That our eyes may run with tears, And our eyelids gush with water.

19. For a voice of wailing is heard from Zion: "How we are plundered! We are greatly ashamed, Because we have forsaken the land, Because we have been cast out of our dwellings."'

20. Yet hear the word of the LORD, O women, And let your ear receive the word of His mouth; Teach your daughters wailing, And everyone her neighbor a lamentation.

21. For death has come through our windows, Has entered our palaces, To kill off the children--no longer to be outside! And the young men--no longer on the streets!

22. Speak, "Thus says the LORD: "Even the carcasses of men shall fall as refuse on the open field, Like cuttings after the harvester, And no one shall gather them."'

23. Thus says the LORD: "Let not the wise man glory in his wisdom, Let not the mighty man glory in his might, Nor let the rich man glory in his riches;

24. But let him who glories glory in this, That he understands and knows Me, That I am the LORD, exercising lovingkindness, judgment, and righteousness in the earth. For in these I delight," says the LORD.

25. "Behold, the days are coming," says the LORD, "that I will punish all who are circumcised with the uncircumcised--

26. Egypt, Judah, Edom, the people of Ammon, Moab, and all who are in the farthest corners, who dwell in the wilderness. For all these nations are uncircumcised, and all the house of Israel are uncircumcised in the heart."

## Chapter 10

1. Hear the word which the LORD speaks to you, O house of Israel.

2. Thus says the LORD: "Do not learn the way of the Gentiles; Do not be dismayed at the signs of heaven, For the Gentiles are dismayed at them.

3. For the customs of the peoples are futile; For one cuts a tree from the forest, The work of the hands of the workman, with the ax.

4. They decorate it with silver and gold; They fasten it with nails and hammers So that it will not topple.

5. They are upright, like a palm tree, And they cannot speak; They must be carried, Because they cannot go by themselves. Do not be afraid of them, For they cannot do evil, Nor can they do any good."

6. Inasmuch as there is none like You, O LORD (You are great, and Your name is great in might),

7. Who would not fear You, O King of the nations? For this is Your rightful due. For among all the wise men of the nations, And in all their kingdoms, There is none like You.

8. But they are altogether dull-hearted and foolish; A wooden idol is a worthless doctrine.

9. Silver is beaten into plates; It is brought from Tarshish, And gold from Uphaz, The work of the craftsman And of the hands of the metalsmith; Blue and purple are their clothing; They are all the work of skillful men.

10. But the LORD is the true God; He is the living God and the everlasting King. At His wrath the earth will tremble, And the nations will not be able to endure His indignation.

11. Thus you shall say to them: "The gods that have not made the heavens and the earth shall perish from the earth and from under these heavens."

12. He has made the earth by His power, He has established the world by His wisdom, And has stretched out the heavens at His discretion.

13. When He utters His voice, There is a multitude of waters in the heavens: "And He causes the vapors to ascend from the ends of the earth. He makes lightning for the rain, He brings the wind out of His treasuries."

14. Everyone is dull-hearted, without knowledge; Every metalsmith is put to shame by an image; For his molded image is falsehood, And there is no breath in them.

15. They are futile, a work of errors; In the time of their punishment they shall perish.

16. The Portion of Jacob is not like them, For He is the Maker of all things, And Israel is the tribe of His inheritance; The LORD of hosts is His name.

17. Gather up your wares from the land, O inhabitant of the fortress!

18. For thus says the LORD: "Behold, I will throw out at this time The inhabitants of the land, And will distress them, That they may find it so."

19. Woe is me for my hurt! My wound is severe. But I say, "Truly this is an infirmity, And I must bear it."

20. My tent is plundered, And all my cords are broken; My children have gone from me, And they are no more. There is no one to pitch my tent anymore, Or set up my curtains.

21. For the shepherds have become dull-hearted, And have not sought the LORD; Therefore they shall not prosper, And all their flocks shall be scattered.

22. Behold, the noise of the report has come, And a great commotion out of the north country, To make the cities of Judah desolate, a den of jackals.

23. O LORD, I know the way of man is not in himself; It is not in man who walks to direct his own steps.

24. O LORD, correct me, but with justice; Not in Your anger, lest You bring me to nothing.

25. Pour out Your fury on the Gentiles, who do not know You, And on the families who do not call on Your name; For they have eaten up Jacob, Devoured him and consumed him, And made his dwelling place desolate.

## Chapter 11

1. The word that came to Jeremiah from the LORD, saying,

2. "Hear the words of this covenant, and speak to the men of Judah and to the inhabitants of Jerusalem;

3. and say to them, "Thus says the LORD God of Israel: "Cursed is the man who does not obey the words of this covenant

4. which I commanded your fathers in the day I brought them out of the land of Egypt, from the iron furnace, saying, "Obey My voice, and do according to all that I command you; so shall you be My people, and I will be your God,'

5. that I may establish the oath which I have sworn to your fathers, to give them "a land flowing with milk and honey,' as it is this day.""' And I answered and said, "So be it, LORD."

6. Then the LORD said to me, "Proclaim all these words in the cities of Judah and in the streets of Jerusalem, saying: "Hear the words of this covenant and do them.

7. For I earnestly exhorted your fathers in the day I brought them up out of the land of Egypt, until this day, rising early and exhorting, saying, "Obey My voice."

8. Yet they did not obey or incline their ear, but everyone followed the dictates of his evil heart; therefore I will bring upon them all the words of this covenant, which I commanded them to do, but which they have not done."'

9. And the LORD said to me, "A conspiracy has been found among the men of Judah and among the inhabitants of Jerusalem.

10. They have turned back to the iniquities of their forefathers who refused to hear My words, and they have gone after other gods to serve them; the house of Israel and the house of Judah have broken My covenant which I made with their fathers."

11. Therefore thus says the LORD: "Behold, I will surely bring calamity on them which they will not be able to escape; and though they cry out to Me, I will not listen to them.

12. Then the cities of Judah and the inhabitants of Jerusalem will go and cry out to the gods to whom they offer incense, but they will not save them at all in the time of their trouble.

13. For according to the number of your cities were your gods, O Judah; and according to the number of the streets of Jerusalem you have set up altars to that shameful thing, altars to burn incense to Baal.

14. "So do not pray for this people, or lift up a cry or prayer for them; for I will not hear them in the time that they cry out to Me because of their trouble.

15. "What has My beloved to do in My house, Having done lewd deeds with many? And the holy flesh has passed from you. When you do evil, then you rejoice.

16. The LORD called your name, Green Olive Tree, Lovely and of Good Fruit. With the noise of a great tumult He has kindled fire on it, And its branches are broken.

17. "For the LORD of hosts, who planted you, has pronounced doom against you for the evil of the house of Israel and of the house of Judah, which they have done against themselves to provoke Me to anger in offering incense to Baal."

18. Now the LORD gave me knowledge of it, and I know it; for You showed me their doings.

19. But I was like a docile lamb brought to the slaughter; and I did not know that they had devised schemes against me, saying, "Let us destroy the tree with its fruit, and let us cut him off from the land of the living, that his name may be remembered no more."

20. But, O LORD of hosts, You who judge righteously, Testing the mind and the heart, Let me see Your vengeance on them, For to You I have revealed my cause.

21. "Therefore thus says the LORD concerning the men of Anathoth who seek your life, saying, "Do not prophesy in the name of the LORD, lest you die by our hand'--

22. therefore thus says the LORD of hosts: "Behold, I will punish them. The young men shall die by the sword, their sons and their daughters shall die by famine;

23. and there shall be no remnant of them, for I will bring catastrophe on the men of Anathoth, even the year of their punishment."'

## Chapter 12

1. Righteous are You, O LORD, when I plead with You; Yet let me talk with You about Your judgments. Why does the way of the wicked prosper? Why are those happy who deal so treacherously?

2. You have planted them, yes, they have taken root; They grow, yes, they bear fruit. You are near in their mouth But far from their mind.

3. But You, O LORD, know me; You have seen me, And You have tested my heart toward You. Pull them out like sheep for the slaughter, And prepare them for the day of slaughter.

4. How long will the land mourn, And the herbs of every field wither? The beasts and birds are consumed, For the wickedness of those who dwell there, Because they said, "He will not see our final end."

5. "If you have run with the footmen, and they have wearied you, Then how can you contend with horses? And if in the land of peace, In which you trusted, they wearied you, Then how will you do in the floodplain of the Jordan?

6. For even your brothers, the house of your father, Even they have dealt treacherously with you; Yes, they have called a multitude after you. Do not believe them, Even though they speak smooth words to you.

7. "I have forsaken My house, I have left My heritage; I have given the dearly beloved of My soul into the hand of her enemies.

8. My heritage is to Me like a lion in the forest; It cries out against Me; Therefore I have hated it.

9. My heritage is to Me like a speckled vulture; The vultures all around are against her. Come, assemble all the beasts of the field, Bring them to devour!

10. "Many rulers have destroyed My vineyard, They have trodden My portion underfoot; They have made My pleasant portion a desolate wilderness.

11. They have made it desolate; Desolate, it mourns to Me; The whole land is made desolate, Because no one takes it to heart.

12. The plunderers have come On all the desolate heights in the wilderness, For the sword of the LORD shall devour From one end of the land to the other end of the land; No flesh shall have peace.

13. They have sown wheat but reaped thorns; They have put themselves to pain but do not profit. But be ashamed of your harvest Because of the fierce anger of the LORD."

14. Thus says the LORD: "Against all My evil neighbors who touch the inheritance which I have caused My people Israel to inherit--behold, I will pluck them out of their land and pluck out the house of Judah from among them.

15. Then it shall be, after I have plucked them out, that I will return and have compassion on them and bring them back, everyone to his heritage and everyone to his land.

16. And it shall be, if they will learn carefully the ways of My people, to swear by My name, "As the LORD lives,' as they taught My people to swear by Baal, then they shall be established in the midst of My people.

17. But if they do not obey, I will utterly pluck up and destroy that nation," says the LORD.

## Chapter 13

1. Thus the LORD said to me: "Go and get yourself a linen sash, and put it around your waist, but do not put it in water."

2. So I got a sash according to the word of the LORD, and put it around my waist.

3. And the word of the LORD came to me the second time, saying,

4. "Take the sash that you acquired, which is around your waist, and arise, go to the Euphrates, and hide it there in a hole in the rock."

5. So I went and hid it by the Euphrates, as the LORD commanded me.

6. Now it came to pass after many days that the LORD said to me, "Arise, go to the Euphrates, and take from there the sash which I commanded you to hide there."

7. Then I went to the Euphrates and dug, and I took the sash from the place where I had hidden it; and there was the sash, ruined. It was profitable for nothing.

8. Then the word of the LORD came to me, saying,

9. "Thus says the LORD: "In this manner I will ruin the pride of Judah and the great pride of Jerusalem.

10. This evil people, who refuse to hear My words, who follow the dictates of their hearts, and walk after other gods to serve them and worship them, shall be just like this sash which is profitable for nothing.

11. For as the sash clings to the waist of a man, so I have caused the whole house of Israel and the whole house of Judah to cling to Me,' says the LORD, "that they may become My people, for renown, for praise, and for glory; but they would not hear.'

12. "Therefore you shall speak to them this word: "Thus says the LORD God of Israel: "Every bottle shall be filled with wine."' "And they will say to you, "Do we not certainly know that every bottle will be filled with wine?'

13. "Then you shall say to them, "Thus says the LORD: "Behold, I will fill all the inhabitants of this land--even the kings who sit on David's throne, the priests, the prophets, and all the inhabitants of Jerusalem--with drunkenness!

14. And I will dash them one against another, even the fathers and the sons together," says the LORD. "I will not pity nor spare nor have mercy, but will destroy them.""'

15. Hear and give ear: Do not be proud, For the LORD has spoken.

16. Give glory to the LORD your God Before He causes darkness, And before your feet stumble On the dark mountains, And while you are looking for light, He turns it into the shadow of death And makes it dense darkness.

17. But if you will not hear it, My soul will weep in secret for your pride; My eyes will weep bitterly And run down with tears, Because the LORD's flock has been taken captive.

18. Say to the king and to the queen mother, "Humble yourselves; Sit down, For your rule shall collapse, the crown of your glory."

19. The cities of the South shall be shut up, And no one shall open them; Judah shall be carried away captive, all of it; It shall be wholly carried away captive.

20. Lift up your eyes and see Those who come from the north. Where is the flock that was given to you, Your beautiful sheep?

21. What will you say when He punishes you? For you have taught them To be chieftains, to be head over you. Will not pangs seize you, Like a woman in labor?

22. And if you say in your heart, "Why have these things come upon me?" For the greatness of your iniquity Your skirts have been uncovered, Your heels made bare.

23. Can the Ethiopian change his skin or the leopard its spots? Then may you also do good who are accustomed to do evil.

24. "Therefore I will scatter them like stubble That passes away by the wind of the wilderness.

25. This is your lot, The portion of your measures from Me," says the LORD, "Because you have forgotten Me And trusted in falsehood.

26. Therefore I will uncover your skirts over your face, That your shame may appear.

27. I have seen your adulteries And your lustful neighings, The lewdness of your harlotry, Your abominations on the hills in the fields. Woe to you, O Jerusalem! Will you still not be made clean?"

## Chapter 14

1. The word of the LORD that came to Jeremiah concerning the droughts.

2. "Judah mourns, And her gates languish; They mourn for the land, And the cry of Jerusalem has gone up.

3. Their nobles have sent their lads for water; They went to the cisterns and found no water. They returned with their vessels empty; They were ashamed and confounded And covered their heads.

4. Because the ground is parched, For there was no rain in the land, The plowmen were ashamed; They covered their heads.

5. Yes, the deer also gave birth in the field, But left because there was no grass.

6. And the wild donkeys stood in the desolate heights; They sniffed at the wind like jackals; Their eyes failed because there was no grass."

7. O LORD, though our iniquities testify against us, Do it for Your name's sake; For our backslidings are many, We have sinned against You.

8. O the Hope of Israel, his Savior in time of trouble, Why should You be like a stranger in the land, And like a traveler who turns aside to tarry for a night?

9. Why should You be like a man astonished, Like a mighty one who cannot save? Yet You, O LORD, are in our midst, And we are called by Your name; Do not leave us!

10. Thus says the LORD to this people: "Thus they have loved to wander; They have not restrained their feet. Therefore the LORD does not accept them; He will remember their iniquity now, And punish their sins."

11. Then the LORD said to me, "Do not pray for this people, for their good.

12. When they fast, I will not hear their cry; and when they offer burnt offering and grain offering, I will not accept them. But I will consume them by the sword, by the famine, and by the pestilence."

13. Then I said, "Ah, Lord GOD! Behold, the prophets say to them, "You shall not see the sword, nor shall you have famine, but I will give you assured peace in this place."'

14. And the LORD said to me, "The prophets prophesy lies in My name. I have not sent them, commanded them, nor spoken to them; they prophesy to you a false vision, divination, a worthless thing, and the deceit of their heart.

15. Therefore thus says the LORD concerning the prophets who prophesy in My name, whom I did not send, and who say, "Sword and famine shall not be in this land'--"By sword and famine those prophets shall be consumed!

16. And the people to whom they prophesy shall be cast out in the streets of Jerusalem because of the famine and the sword; they will have no one to bury them--them nor their wives, their sons nor their daughters--for I will pour their wickedness on them.'

17. "Therefore you shall say this word to them: "Let my eyes flow with tears night and day, And let them not cease; For the virgin daughter of my people Has been broken with a mighty stroke, with a very severe blow.

18. If I go out to the field, Then behold, those slain with the sword! And if I enter the city, Then behold, those sick from famine! Yes, both prophet and priest go about in a land they do not know."'

19. Have You utterly rejected Judah? Has Your soul loathed Zion? Why have You stricken us so that there is no healing for us? We looked for peace, but there was no good; And for the time of healing, and there was trouble.

20. We acknowledge, O LORD, our wickedness And the iniquity of our fathers, For we have sinned against You.

21. Do not abhor us, for Your name's sake; Do not disgrace the throne of Your glory. Remember, do not break Your covenant with us.

22. Are there any among the idols of the nations that can cause rain? Or can the heavens give showers? Are You not He, O LORD our God? Therefore we will wait for You, Since You have made all these.

## Chapter 15

1. Then the LORD said to me, "Even if Moses and Samuel stood before Me, My mind would not be favorable toward this people. Cast them out of My sight, and let them go forth.

2. And it shall be, if they say to you, "Where should we go?' then you shall tell them, "Thus says the LORD: "Such as are for death, to death; And such as are for the sword, to the sword; And such as are for the famine, to the famine; And such as are for the captivity, to the captivity."'

3. "And I will appoint over them four forms of destruction," says the LORD: "the sword to slay, the dogs to drag, the birds of the heavens and the beasts of the earth to devour and destroy.

4. I will hand them over to trouble, to all kingdoms of the earth, because of Manasseh the son of Hezekiah, king of Judah, for what he did in Jerusalem.

5. "For who will have pity on you, O Jerusalem? Or who will bemoan you? Or who will turn aside to ask how you are doing?

6. You have forsaken Me," says the LORD, "You have gone backward. Therefore I will stretch out My hand against you and destroy you; I am weary of relenting!

7. And I will winnow them with a winnowing fan in the gates of the land; I will bereave them of children; I will destroy My people, Since they do not return from their ways.

8. Their widows will be increased to Me more than the sand of the seas; I will bring against them, Against the mother of the young men, A plunderer at noonday; I will cause anguish and terror to fall on them suddenly.

9. "She languishes who has borne seven; She has breathed her last; Her sun has gone down While it was yet day; She has been ashamed and confounded. And the remnant of them I will deliver to the sword Before their enemies," says the LORD.

10. Woe is me, my mother, That you have borne me, A man of strife and a man of contention to the whole earth! I have neither lent for interest, Nor have men lent to me for interest. Every one of them curses me.

11. The LORD said: "Surely it will be well with your remnant; Surely I will cause the enemy to intercede with you In the time of adversity and in the time of affliction.

12. Can anyone break iron, The northern iron and the bronze?

13. Your wealth and your treasures I will give as plunder without price, Because of all your sins, Throughout your territories.

14. And I will make you cross over with your enemies Into a land which you do not know; For a fire is kindled in My anger, Which shall burn upon you."

15. O LORD, You know; Remember me and visit me, And take vengeance for me on my persecutors. In Your enduring patience, do not take me away. Know that for Your sake I have suffered rebuke.

16. Your words were found, and I ate them, And Your word was to me the joy and rejoicing of my heart; For I am called by Your name, O LORD God of hosts.

17. I did not sit in the assembly of the mockers, Nor did I rejoice; I sat alone because of Your hand, For You have filled me with indignation.

18. Why is my pain perpetual And my wound incurable, Which refuses to be healed? Will You surely be to me like an unreliable stream, As waters that fail?

19. Therefore thus says the LORD: "If you return, Then I will bring you back; You shall stand before Me; If you take out the precious from the vile, You shall be as My mouth. Let them return to you, But you must not return to them.

20. And I will make you to this people a fortified bronze wall; And they will fight against you, But they shall not prevail against you; For I am with you to save you And deliver you," says the LORD.

21. "I will deliver you from the hand of the wicked, And I will redeem you from the grip of the terrible."

## Chapter 16

1. The word of the LORD also came to me, saying,

2. "You shall not take a wife, nor shall you have sons or daughters in this place."

3. For thus says the LORD concerning the sons and daughters who are born in this place, and concerning their mothers who bore them and their fathers who begot them in this land:

4. "They shall die gruesome deaths; they shall not be lamented nor shall they be buried, but they shall be like refuse on the face of the earth. They shall be consumed by the sword and by famine, and their corpses shall be meat for the birds of heaven and for the beasts of the earth."

5. For thus says the LORD: "Do not enter the house of mourning, nor go to lament or bemoan them; for I have taken away My peace from this people," says the LORD, "lovingkindness and mercies.

6. Both the great and the small shall die in this land. They shall not be buried; neither shall men lament for them, cut themselves, nor make themselves bald for them.

7. Nor shall men break bread in mourning for them, to comfort them for the dead; nor shall men give them the cup of consolation to drink for their father or their mother.

8. Also you shall not go into the house of feasting to sit with them, to eat and drink."

9. For thus says the LORD of hosts, the God of Israel: "Behold, I will cause to cease from this place, before your eyes and in your days, the voice of mirth and the voice of gladness, the voice of the bridegroom and the voice of the bride.

10. "And it shall be, when you show this people all these words, and they say to you, "Why has the LORD pronounced all this great disaster against us? Or what is our iniquity? Or what is our sin that we have committed against the LORD our God?'

11. then you shall say to them, "Because your fathers have forsaken Me,' says the LORD; "they have walked after other gods and have served them and worshiped them, and have forsaken Me and not kept My law.

12. And you have done worse than your fathers, for behold, each one follows the dictates of his own evil heart, so that no one listens to Me.

13. Therefore I will cast you out of this land into a land that you do not know, neither you nor your fathers; and there you shall serve other gods day and night, where I will not show you favor.'

14. "Therefore behold, the days are coming," says the LORD, "that it shall no more be said, "The LORD lives who brought up the children of Israel from the land of Egypt,'

15. but, "The LORD lives who brought up the children of Israel from the land of the north and from all the lands where He had driven them.' For I will bring them back into their land which I gave to their fathers.

16. "Behold, I will send for many fishermen," says the LORD, "and they shall fish them; and afterward I will send for many hunters, and they shall hunt them from every mountain and every hill, and out of the holes of the rocks.

17. For My eyes are on all their ways; they are not hidden from My face, nor is their iniquity hidden from My eyes.

18. And first I will repay double for their iniquity and their sin, because they have defiled My land; they have filled My inheritance with the carcasses of their detestable and abominable idols."

19. O LORD, my strength and my fortress, My refuge in the day of affliction, The Gentiles shall come to You From the ends of the earth and say, "Surely our fathers have inherited lies, Worthlessness and unprofitable things."

20. Will a man make gods for himself, Which are not gods?

21. "Therefore behold, I will this once cause them to know, I will cause them to know My hand and My might; And they shall know that My name is the LORD.

## Chapter 17

1. "The sin of Judah is written with a pen of iron; With the point of a diamond it is engraved On the tablet of their heart, And on the horns of your altars,

2. While their children remember Their altars and their wooden images By the green trees on the high hills.

3. O My mountain in the field, I will give as plunder your wealth, all your treasures, And your high places of sin within all your borders.

4. And you, even yourself, Shall let go of your heritage which I gave you; And I will cause you to serve your enemies In the land which you do not know; For you have kindled a fire in My anger which shall burn forever."

5. Thus says the LORD: "Cursed is the man who trusts in man And makes flesh his strength, Whose heart departs from the LORD.

6. For he shall be like a shrub in the desert, And shall not see when good comes, But shall inhabit the parched places in the wilderness, In a salt land which is not inhabited.

7. "Blessed is the man who trusts in the LORD, And whose hope is the LORD.

8. For he shall be like a tree planted by the waters, Which spreads out its roots by the river, And will not fear when heat comes; But its leaf will be green, And will not be anxious in the year of drought, Nor will cease from yielding fruit.

9. "The heart is deceitful above all things, And desperately wicked; Who can know it?

10. I, the LORD, search the heart, I test the mind, Even to give every man according to his ways, According to the fruit of his doings.

11. "As a partridge that broods but does not hatch, So is he who gets riches, but not by right; It will leave him in the midst of his days, And at his end he will be a fool."

12. A glorious high throne from the beginning Is the place of our sanctuary.

13. O LORD, the hope of Israel, All who forsake You shall be ashamed. "Those who depart from Me Shall be written in the earth, Because they have forsaken the LORD, The fountain of living waters."

14. Heal me, O LORD, and I shall be healed; Save me, and I shall be saved, For You are my praise.

15. Indeed they say to me, "Where is the word of the LORD? Let it come now!"

16. As for me, I have not hurried away from being a shepherd who follows You, Nor have I desired the woeful day; You know what came out of my lips; It was right there before You.

17. Do not be a terror to me; You are my hope in the day of doom.

18. Let them be ashamed who persecute me, But do not let me be put to shame; Let them be dismayed, But do not let me be dismayed. Bring on them the day of doom, And destroy them with double destruction!

19. Thus the LORD said to me: "Go and stand in the gate of the children of the people, by which the kings of Judah come in and by which they go out, and in all the gates of Jerusalem;

20. and say to them, "Hear the word of the LORD, you kings of Judah, and all Judah, and all the inhabitants of Jerusalem, who enter by these gates.

21. Thus says the LORD: "Take heed to yourselves, and bear no burden on the Sabbath day, nor bring it in by the gates of Jerusalem;

22. nor carry a burden out of your houses on the Sabbath day, nor do any work, but hallow the Sabbath day, as I commanded your fathers.

23. But they did not obey nor incline their ear, but made their neck stiff, that they might not hear nor receive instruction.

24. "And it shall be, if you heed Me carefully," says the LORD, "to bring no burden through the gates of this city on the Sabbath day, but hallow the Sabbath day, to do no work in it,

25. then shall enter the gates of this city kings and princes sitting on the throne of David, riding in chariots and on horses, they and their princes, accompanied by the men of Judah and the inhabitants of Jerusalem; and this city shall remain forever.

26. And they shall come from the cities of Judah and from the places around Jerusalem, from the land of Benjamin and from the lowland, from the mountains and from the South, bringing burnt offerings and sacrifices, grain offerings and incense, bringing sacrifices of praise to the house of the LORD.

27. "But if you will not heed Me to hallow the Sabbath day, such as not carrying a burden when entering the gates of Jerusalem on the Sabbath day, then I will kindle a fire in its gates, and it shall devour the palaces of Jerusalem, and it shall not be quenched.""'

## Chapter 18

1. The word which came to Jeremiah from the LORD, saying:

2. "Arise and go down to the potter's house, and there I will cause you to hear My words."

3. Then I went down to the potter's house, and there he was, making something at the wheel.

4. And the vessel that he made of clay was marred in the hand of the potter; so he made it again into another vessel, as it seemed good to the potter to make.

5. Then the word of the LORD came to me, saying:

6. "O house of Israel, can I not do with you as this potter?" says the LORD. "Look, as the clay is in the potter's hand, so are you in My hand, O house of Israel!

7. The instant I speak concerning a nation and concerning a kingdom, to pluck up, to pull down, and to destroy it,

8. if that nation against whom I have spoken turns from its evil, I will relent of the disaster that I thought to bring upon it.

9. And the instant I speak concerning a nation and concerning a kingdom, to build and to plant it,

10. if it does evil in My sight so that it does not obey My voice, then I will relent concerning the good with which I said I would benefit it.

11. "Now therefore, speak to the men of Judah and to the inhabitants of Jerusalem, saying, "Thus says the LORD: "Behold, I am fashioning a disaster and devising a plan against you. Return now every one from his evil way, and make your ways and your doings good.""'

12. And they said, "That is hopeless! So we will walk according to our own plans, and we will every one obey the dictates of his evil heart."

13. Therefore thus says the LORD: "Ask now among the Gentiles, Who has heard such things? The virgin of Israel has done a very horrible thing.

14. Will a man leave the snow water of Lebanon, Which comes from the rock of the field? Will the cold flowing waters be forsaken for strange waters?

15. "Because My people have forgotten Me, They have burned incense to worthless idols. And they have caused themselves to stumble in their ways, From the ancient paths, To walk in pathways and not on a highway,

16. To make their land desolate and a perpetual hissing; Everyone who passes by it will be astonished And shake his head.

17. I will scatter them as with an east wind before the enemy; I will show them the back and not the face In the day of their calamity."

18. Then they said, "Come and let us devise plans against Jeremiah; for the law shall not perish from the priest, nor counsel from the wise, nor the word from the prophet. Come and let us attack him with the tongue, and let us not give heed to any of his words."

19. Give heed to me, O LORD, And listen to the voice of those who contend with me!

20. Shall evil be repaid for good? For they have dug a pit for my life. Remember that I stood before You To speak good for them, To turn away Your wrath from them.

21. Therefore deliver up their children to the famine, And pour out their blood By the force of the sword; Let their wives become widows And bereaved of their children. Let their men be put to death, Their young men be slain By the sword in battle.

22. Let a cry be heard from their houses, When You bring a troop suddenly upon them; For they have dug a pit to take me, And hidden snares for my feet.

23. Yet, LORD, You know all their counsel Which is against me, to slay me. Provide no atonement for their iniquity, Nor blot out their sin from Your sight; But let them be overthrown before You. Deal thus with them In the time of Your anger.

## Chapter 19

1. Thus says the LORD: "Go and get a potter's earthen flask, and take some of the elders of the people and some of the elders of the priests.

2. And go out to the Valley of the Son of Hinnom, which is by the entry of the Potsherd Gate; and proclaim there the words that I will tell you,

3. and say, "Hear the word of the LORD, O kings of Judah and inhabitants of Jerusalem. Thus says the LORD of hosts, the God of Israel: "Behold, I will bring such a catastrophe on this place, that whoever hears of it, his ears will tingle.

4. "Because they have forsaken Me and made this an alien place, because they have burned incense in it to other gods whom neither they, their fathers, nor the kings of Judah have known, and have filled this place with the blood of the innocents

5. (they have also built the high places of Baal, to burn their sons with fire for burnt offerings to Baal, which I did not command or speak, nor did it come into My mind),

6. therefore behold, the days are coming," says the LORD, "that this place shall no more be called Tophet or the Valley of the Son of Hinnom, but the Valley of Slaughter.

7. And I will make void the counsel of Judah and Jerusalem in this place, and I will cause them to fall by the sword before their enemies and by the hands of those who seek their lives; their corpses I will give as meat for the birds of the heaven and for the beasts of the earth.

8. I will make this city desolate and a hissing; everyone who passes by it will be astonished and hiss because of all its plagues.

9. And I will cause them to eat the flesh of their sons and the flesh of their daughters, and everyone shall eat the flesh of his friend in the siege and in the desperation with which their enemies and those who seek their lives shall drive them to despair."'

10. "Then you shall break the flask in the sight of the men who go with you,

11. and say to them, "Thus says the LORD of hosts: "Even so I will break this people and this city, as one breaks a potter's vessel, which cannot be made whole again; and they shall bury them in Tophet till there is no place to bury.

12. Thus I will do to this place," says the LORD, "and to its inhabitants, and make this city like Tophet.

13. And the houses of Jerusalem and the houses of the kings of Judah shall be defiled like the place of Tophet, because of all the houses on whose roofs they have burned incense to all the host of heaven, and poured out drink offerings to other gods.""'

14. Then Jeremiah came from Tophet, where the LORD had sent him to prophesy; and he stood in the court of the Lord's house and said to all the people,

15. "Thus says the LORD of hosts, the God of Israel: "Behold, I will bring on this city and on all her towns all the doom that I have pronounced against it, because they have stiffened their necks that they might not hear My words."'

## Chapter 20

1. Now Pashhur the son of Immer, the priest who was also chief governor in the house of the LORD, heard that Jeremiah prophesied these things.

2. Then Pashhur struck Jeremiah the prophet, and put him in the stocks that were in the high gate of Benjamin, which was by the house of the LORD.

3. And it happened on the next day that Pashhur brought Jeremiah out of the stocks. Then Jeremiah said to him, "The LORD has not called your name Pashhur, but Magor-Missabib.

4. For thus says the LORD: "Behold, I will make you a terror to yourself and to all your friends; and they shall fall by the sword of their enemies, and your eyes shall see it. I will give all Judah into the hand of the king of Babylon, and he shall carry them captive to Babylon and slay them with the sword.

5. Moreover I will deliver all the wealth of this city, all its produce, and all its precious things; all the treasures of the kings of Judah I will give into the hand of their enemies, who will plunder them, seize them, and carry them to Babylon.

6. And you, Pashhur, and all who dwell in your house, shall go into captivity. You shall go to Babylon, and there you shall die, and be buried there, you and all your friends, to whom you have prophesied lies."'

7. O LORD, You induced me, and I was persuaded; You are stronger than I, and have prevailed. I am in derision daily; Everyone mocks me.

8. For when I spoke, I cried out; I shouted, "Violence and plunder!" Because the word of the LORD was made to me A reproach and a derision daily.

9. Then I said, "I will not make mention of Him, Nor speak anymore in His name." But His word was in my heart like a burning fire Shut up in my bones; I was weary of holding it back, And I could not.

10. For I heard many mocking: "Fear on every side!" "Report," they say, "and we will report it!" All my acquaintances watched for my stumbling, saying, "Perhaps he can be induced; Then we will prevail against him, And we will take our revenge on him."

11. But the LORD is with me as a mighty, awesome One. Therefore my persecutors will stumble, and will not prevail. They will be greatly ashamed, for they will not prosper. Their everlasting confusion will never be forgotten.

12. But, O LORD of hosts, You who test the righteous, And see the mind and heart, Let me see Your vengeance on them; For I have pleaded my cause before You.

13. Sing to the LORD! Praise the LORD! For He has delivered the life of the poor From the hand of evildoers.

14. Cursed be the day in which I was born! Let the day not be blessed in which my mother bore me!

15. Let the man be cursed Who brought news to my father, saying, "A male child has been born to you!" Making him very glad.

16. And let that man be like the cities Which the LORD overthrew, and did not relent; Let him hear the cry in the morning And the shouting at noon,

17. Because he did not kill me from the womb, That my mother might have been my grave, And her womb always enlarged with me.

18. Why did I come forth from the womb to see labor and sorrow, That my days should be consumed with shame?

## Chapter 21

1. The word which came to Jeremiah from the LORD when King Zedekiah sent to him Pashhur the son of Melchiah, and Zephaniah the son of Maaseiah, the priest, saying,

2. "Please inquire of the LORD for us, for Nebuchadnezzar king of Babylon makes war against us. Perhaps the LORD will deal with us according to all His wonderful works, that the king may go away from us."

3. Then Jeremiah said to them, "Thus you shall say to Zedekiah,

4. "Thus says the LORD God of Israel: "Behold, I will turn back the weapons of war that are in your hands, with which you fight against the king of Babylon and the Chaldeans who besiege you outside the walls; and I will assemble them in the midst of this city.

5. I Myself will fight against you with an outstretched hand and with a strong arm, even in anger and fury and great wrath.

6. I will strike the inhabitants of this city, both man and beast; they shall die of a great pestilence.

7. And afterward," says the LORD, "I will deliver Zedekiah king of Judah, his servants and the people, and such as are left in this city from the pestilence and the sword and the famine, into the hand of Nebuchadnezzar king of Babylon, into the hand of their enemies, and into the hand of those who seek their life; and he shall strike them with the edge of the sword. He shall not spare them, or have pity or mercy."'

8. "Now you shall say to this people, "Thus says the LORD: "Behold, I set before you the way of life and the way of death.

9. He who remains in this city shall die by the sword, by famine, and by pestilence; but he who goes out and defects to the Chaldeans who besiege you, he shall live, and his life shall be as a prize to him.

10. For I have set My face against this city for adversity and not for good," says the LORD. "It shall be given into the hand of the king of Babylon, and he shall burn it with fire."'

11. "And concerning the house of the king of Judah, say, "Hear the word of the LORD,

12. O house of David! Thus says the LORD: "Execute judgment in the morning; And deliver him who is plundered Out of the hand of the oppressor, Lest My fury go forth like fire And burn so that no one can quench it, Because of the evil of your doings.

13. "Behold, I am against you, O inhabitant of the valley, And rock of the plain," says the LORD, "Who say, "Who shall come down against us? Or who shall enter our dwellings?'

14. But I will punish you according to the fruit of your doings," says the LORD; "I will kindle a fire in its forest, And it shall devour all things around it.""'

## Chapter 22

1. Thus says the LORD: "Go down to the house of the king of Judah, and there speak this word,

2. and say, "Hear the word of the LORD, O king of Judah, you who sit on the throne of David, you and your servants and your people who enter these gates!

3. Thus says the LORD: "Execute judgment and righteousness, and deliver the plundered out of the hand of the oppressor. Do no wrong and do no violence to the stranger, the fatherless, or the widow, nor shed innocent blood in this place.

4. For if you indeed do this thing, then shall enter the gates of this house, riding on horses and in chariots, accompanied by servants and people, kings who sit on the throne of David.

5. But if you will not hear these words, I swear by Myself," says the LORD, "that this house shall become a desolation.""'

6. For thus says the LORD to the house of the king of Judah: "You are Gilead to Me, The head of Lebanon; Yet I surely will make you a wilderness, Cities which are not inhabited.

7. I will prepare destroyers against you, Everyone with his weapons; They shall cut down your choice cedars And cast them into the fire.

8. And many nations will pass by this city; and everyone will say to his neighbor, "Why has the LORD done so to this great city?'

9. Then they will answer, "Because they have forsaken the covenant of the LORD their God, and worshiped other gods and served them."'

10. Weep not for the dead, nor bemoan him; Weep bitterly for him who goes away, For he shall return no more, Nor see his native country.

11. For thus says the LORD concerning Shallum the son of Josiah, king of Judah, who reigned instead of Josiah his father, who went from this place: "He shall not return here anymore,

12. but he shall die in the place where they have led him captive, and shall see this land no more.

13. "Woe to him who builds his house by unrighteousness And his chambers by injustice, Who uses his neighbor's service without wages And gives him nothing for his work,

14. Who says, "I will build myself a wide house with spacious chambers, And cut out windows for it, Paneling it with cedar And painting it with vermilion.'

15. "Shall you reign because you enclose yourself in cedar? Did not your father eat and drink, And do justice and righteousness? Then it was well with him.

16. He judged the cause of the poor and needy; Then it was well. Was not this knowing Me?" says the LORD.

17. "Yet your eyes and your heart are for nothing but your covetousness, For shedding innocent blood, And practicing oppression and violence."

18. Therefore thus says the LORD concerning Jehoiakim the son of Josiah, king of Judah: "They shall not lament for him, Saying, "Alas, my brother!' or "Alas, my sister!' They shall not lament for him, Saying, "Alas, master!' or "Alas, his glory!'

19. He shall be buried with the burial of a donkey, Dragged and cast out beyond the gates of Jerusalem.

20. "Go up to Lebanon, and cry out, And lift up your voice in Bashan; Cry from Abarim, For all your lovers are destroyed.

21. I spoke to you in your prosperity, But you said, "I will not hear.' This has been your manner from your youth, That you did not obey My voice.

22. The wind shall eat up all your rulers, And your lovers shall go into captivity; Surely then you will be ashamed and humiliated For all your wickedness.

23. O inhabitant of Lebanon, Making your nest in the cedars, How gracious will you be when pangs come upon you, Like the pain of a woman in labor?

24. "As I live," says the LORD, "though Coniah the son of Jehoiakim, king of Judah, were the signet on My right hand, yet I would pluck you off;

25. and I will give you into the hand of those who seek your life, and into the hand of those whose face you fear--the hand of Nebuchadnezzar king of Babylon and the hand of the Chaldeans.

26. So I will cast you out, and your mother who bore you, into another country where you were not born; and there you shall die.

27. But to the land to which they desire to return, there they shall not return.

28. "Is this man Coniah a despised, broken idol-- A vessel in which is no pleasure? Why are they cast out, he and his descendants, And cast into a land which they do not know?

29. O earth, earth, earth, Hear the word of the LORD!

30. Thus says the LORD: "Write this man down as childless, A man who shall not prosper in his days; For none of his descendants shall prosper, Sitting on the throne of David, And ruling anymore in Judah."'

## Chapter 23

1. "Woe to the shepherds who destroy and scatter the sheep of My pasture!" says the LORD.

2. Therefore thus says the LORD God of Israel against the shepherds who feed My people: "You have scattered My flock, driven them away, and not attended to them. Behold, I will attend to you for the evil of your doings," says the LORD.

3. "But I will gather the remnant of My flock out of all countries where I have driven them, and bring them back to their folds; and they shall be fruitful and increase.

4. I will set up shepherds over them who will feed them; and they shall fear no more, nor be dismayed, nor shall they be lacking," says the LORD.

5. "Behold, the days are coming," says the LORD, "That I will raise to David a Branch of righteousness; A King shall reign and prosper, And execute judgment and righteousness in the earth.

6. In His days Judah will be saved, And Israel will dwell safely; Now this is His name by which He will be called: THE LORD OUR RIGHTEOUSNESS.

7. "Therefore, behold, the days are coming," says the LORD, "that they shall no longer say, "As the LORD lives who brought up the children of Israel from the land of Egypt,'

8. but, "As the LORD lives who brought up and led the descendants of the house of Israel from the north country and from all the countries where I had driven them.' And they shall dwell in their own land."

9. My heart within me is broken Because of the prophets; All my bones shake. I am like a drunken man, And like a man whom wine has overcome, Because of the LORD, And because of His holy words.

10. For the land is full of adulterers; For because of a curse the land mourns. The pleasant places of the wilderness are dried up. Their course of life is evil, And their might is not right.

11. "For both prophet and priest are profane; Yes, in My house I have found their wickedness," says the LORD.

12. "Therefore their way shall be to them Like slippery ways; In the darkness they shall be driven on And fall in them; For I will bring disaster on them, The year of their punishment," says the LORD.

13. "And I have seen folly in the prophets of Samaria: They prophesied by Baal And caused My people Israel to err.

14. Also I have seen a horrible thing in the prophets of Jerusalem: They commit adultery and walk in lies; They also strengthen the hands of evildoers, So that no one turns back from his wickedness. All of them are like Sodom to Me, And her inhabitants like Gomorrah.

15. "Therefore thus says the LORD of hosts concerning the prophets: "Behold, I will feed them with wormwood, And make them drink the water of gall; For from the prophets of Jerusalem Profaneness has gone out into all the land."'

16. Thus says the LORD of hosts: "Do not listen to the words of the prophets who prophesy to you. They make you worthless; They speak a vision of their own heart, Not from the mouth of the LORD.

17. They continually say to those who despise Me, "The LORD has said, "You shall have peace"'; And to everyone who walks according to the dictates of his own heart, they say, "No evil shall come upon you."'

18. For who has stood in the counsel of the LORD, And has perceived and heard His word? Who has marked His word and heard it?

19. Behold, a whirlwind of the LORD has gone forth in fury-- A violent whirlwind! It will fall violently on the head of the wicked.

20. The anger of the LORD will not turn back Until He has executed and performed the thoughts of His heart. In the latter days you will understand it perfectly.

21. "I have not sent these prophets, yet they ran. I have not spoken to them, yet they prophesied.

22. But if they had stood in My counsel, And had caused My people to hear My words, Then they would have turned them from their evil way And from the evil of their doings.

23. "Am I a God near at hand," says the LORD, "And not a God afar off?

24. Can anyone hide himself in secret places, So I shall not see him?" says the LORD; "Do I not fill heaven and earth?" says the LORD.

25. "I have heard what the prophets have said who prophesy lies in My name, saying, "I have dreamed, I have dreamed!'

26. How long will this be in the heart of the prophets who prophesy lies? Indeed they are prophets of the deceit of their own heart,

27. who try to make My people forget My name by their dreams which everyone tells his neighbor, as their fathers forgot My name for Baal.

28. "The prophet who has a dream, let him tell a dream; And he who has My word, let him speak My word faithfully. What is the chaff to the wheat?" says the LORD.

29. "Is not My word like a fire?" says the LORD, "And like a hammer that breaks the rock in pieces?

30. "Therefore behold, I am against the prophets," says the LORD, "who steal My words every one from his neighbor.

31. Behold, I am against the prophets," says the LORD, "who use their tongues and say, "He says.'

32. Behold, I am against those who prophesy false dreams," says the LORD, "and tell them, and cause My people to err by their lies and by their recklessness. Yet I did not send them or command them; therefore they shall not profit this people at all," says the LORD.

33. "So when these people or the prophet or the priest ask you, saying, "What is the oracle of the LORD?' you shall then say to them, "What oracle?' I will even forsake you," says the LORD.

34. "And as for the prophet and the priest and the people who say, "The oracle of the LORD!' I will even punish that man and his house.

35. Thus every one of you shall say to his neighbor, and every one to his brother, "What has the LORD answered?' and, "What has the LORD spoken?'

36. And the oracle of the LORD you shall mention no more. For every man's word will be his oracle, for you have perverted the words of the living God, the LORD of hosts, our God.

37. Thus you shall say to the prophet, "What has the LORD answered you?' and, "What has the LORD spoken?'

38. But since you say, "The oracle of the LORD!' therefore thus says the LORD: "Because you say this word, "The oracle of the LORD!" and I have sent to you, saying, "Do not say, "The oracle of the LORD!"'

39. therefore behold, I, even I, will utterly forget you and forsake you, and the city that I gave you and your fathers, and will cast you out of My presence.

40. And I will bring an everlasting reproach upon you, and a perpetual shame, which shall not be forgotten."'

## Chapter 24

1. The LORD showed me, and there were two baskets of figs set before the temple of the LORD, after Nebuchadnezzar king of Babylon had carried away captive Jeconiah the son of Jehoiakim, king of Judah, and the princes of Judah with the craftsmen and smiths, from Jerusalem, and had brought them to Babylon.

2. One basket had very good figs, like the figs that are first ripe; and the other basket had very bad figs which could not be eaten, they were so bad.

3. Then the LORD said to me, "What do you see, Jeremiah?" And I said, "Figs, the good figs, very good; and the bad, very bad, which cannot be eaten, they are so bad."

4. Again the word of the LORD came to me, saying,

5. "Thus says the LORD, the God of Israel: "Like these good figs, so will I acknowledge those who are carried away captive from Judah, whom I have sent out of this place for their own good, into the land of the Chaldeans.

6. For I will set My eyes on them for good, and I will bring them back to this land; I will build them and not pull them down, and I will plant them and not pluck them up.

7. Then I will give them a heart to know Me, that I am the LORD; and they shall be My people, and I will be their God, for they shall return to Me with their whole heart.

8. "And as the bad figs which cannot be eaten, they are so bad'--surely thus says the LORD--"so will I give up Zedekiah the king of Judah, his princes, the residue of Jerusalem who remain in this land, and those who dwell in the land of Egypt.

9. I will deliver them to trouble into all the kingdoms of the earth, for their harm, to be a reproach and a byword, a taunt and a curse, in all places where I shall drive them.

10. And I will send the sword, the famine, and the pestilence among them, till they are consumed from the land that I gave to them and their fathers."'

## Chapter 25

1. The word that came to Jeremiah concerning all the people of Judah, in the fourth year of Jehoiakim the son of Josiah, king of Judah (which was the first year of Nebuchadnezzar king of Babylon),

2. which Jeremiah the prophet spoke to all the people of Judah and to all the inhabitants of Jerusalem, saying:

3. "From the thirteenth year of Josiah the son of Amon, king of Judah, even to this day, this is the twenty-third year in which the word of the LORD has come to me; and I have spoken to you, rising early and speaking, but you have not listened.

4. And the LORD has sent to you all His servants the prophets, rising early and sending them, but you have not listened nor inclined your ear to hear.

5. They said, "Repent now everyone of his evil way and his evil doings, and dwell in the land that the LORD has given to you and your fathers forever and ever.

6. Do not go after other gods to serve them and worship them, and do not provoke Me to anger with the works of your hands; and I will not harm you.'

7. Yet you have not listened to Me," says the LORD, "that you might provoke Me to anger with the works of your hands to your own hurt.

8. "Therefore thus says the LORD of hosts: "Because you have not heard My words,

9. behold, I will send and take all the families of the north,' says the LORD, "and Nebuchadnezzar the king of Babylon, My servant, and will bring them against this land, against its inhabitants, and against these nations all around, and will utterly destroy them, and make them an astonishment, a hissing, and perpetual desolations.

10. Moreover I will take from them the voice of mirth and the voice of gladness, the voice of the bridegroom and the voice of the bride, the sound of the millstones and the light of the lamp.

11. And this whole land shall be a desolation and an astonishment, and these nations shall serve the king of Babylon seventy years.

12. "Then it will come to pass, when seventy years are completed, that I will punish the king of Babylon and that nation, the land of the Chaldeans, for their iniquity,' says the LORD; "and I will make it a perpetual desolation.

13. So I will bring on that land all My words which I have pronounced against it, all that is written in this book, which Jeremiah has prophesied concerning all the nations.

14. (For many nations and great kings shall be served by them also; and I will repay them according to their deeds and according to the works of their own hands.)"'

15. For thus says the LORD God of Israel to me: "Take this wine cup of fury from My hand, and cause all the nations, to whom I send you, to drink it.

16. And they will drink and stagger and go mad because of the sword that I will send among them."

17. Then I took the cup from the LORD's hand, and made all the nations drink, to whom the LORD had sent me:

18. Jerusalem and the cities of Judah, its kings and its princes, to make them a desolation, an astonishment, a hissing, and a curse, as it is this day;

19. Pharaoh king of Egypt, his servants, his princes, and all his people;

20. all the mixed multitude, all the kings of the land of Uz, all the kings of the land of the Philistines (namely, Ashkelon, Gaza, Ekron, and the remnant of Ashdod);

21. Edom, Moab, and the people of Ammon;

22. all the kings of Tyre, all the kings of Sidon, and the kings of the coastlands which are across the sea;

23. Dedan, Tema, Buz, and all who are in the farthest corners;

24. all the kings of Arabia and all the kings of the mixed multitude who dwell in the desert;

25. all the kings of Zimri, all the kings of Elam, and all the kings of the Medes;

26. all the kings of the north, far and near, one with another; and all the kingdoms of the world which are on the face of the earth. Also the king of Sheshach shall drink after them.

27. "Therefore you shall say to them, "Thus says the LORD of hosts, the God of Israel: "Drink, be drunk, and vomit! Fall and rise no more, because of the sword which I will send among you."'

28. And it shall be, if they refuse to take the cup from your hand to drink, then you shall say to them, "Thus says the LORD of hosts: "You shall certainly drink!

29. For behold, I begin to bring calamity on the city which is called by My name, and should you be utterly unpunished? You shall not be unpunished, for I will call for a sword on all the inhabitants of the earth," says the LORD of hosts.'

30. "Therefore prophesy against them all these words, and say to them: "The LORD will roar from on high, And utter His voice from His holy habitation; He will roar mightily against His fold. He will give a shout, as those who tread the grapes, Against all the inhabitants of the earth.

31. A noise will come to the ends of the earth-- For the LORD has a controversy with the nations; He will plead His case with all flesh. He will give those who are wicked to the sword,' says the LORD."

32. Thus says the LORD of hosts: "Behold, disaster shall go forth From nation to nation, And a great whirlwind shall be raised up From the farthest parts of the earth.

33. "And at that day the slain of the LORD shall be from one end of the earth even to the other end of the earth. They shall not be lamented, or gathered, or buried; they shall become refuse on the ground.

34. "Wail, shepherds, and cry! Roll about in the ashes, You leaders of the flock! For the days of your slaughter and your dispersions are fulfilled; You shall fall like a precious vessel.

35. And the shepherds will have no way to flee, Nor the leaders of the flock to escape.

36. A voice of the cry of the shepherds, And a wailing of the leaders to the flock will be heard. For the LORD has plundered their pasture,

37. And the peaceful dwellings are cut down Because of the fierce anger of the LORD.

38. He has left His lair like the lion; For their land is desolate Because of the fierceness of the Oppressor, And because of His fierce anger."

## Chapter 26

1. In the beginning of the reign of Jehoiakim the son of Josiah, king of Judah, this word came from the LORD, saying,

2. "Thus says the LORD: "Stand in the court of the LORD's house, and speak to all the cities of Judah, which come to worship in the LORD's house, all the words that I command you to speak to them. Do not diminish a word.

3. Perhaps everyone will listen and turn from his evil way, that I may relent concerning the calamity which I purpose to bring on them because of the evil of their doings.'

4. And you shall say to them, "Thus says the LORD: "If you will not listen to Me, to walk in My law which I have set before you,

5. to heed the words of My servants the prophets whom I sent to you, both rising up early and sending them (but you have not heeded),

6. then I will make this house like Shiloh, and will make this city a curse to all the nations of the earth.""'

7. So the priests and the prophets and all the people heard Jeremiah speaking these words in the house of the LORD.

8. Now it happened, when Jeremiah had made an end of speaking all that the LORD had commanded him to speak to all the people, that the priests and the prophets and all the people seized him, saying, "You will surely die!

9. Why have you prophesied in the name of the LORD, saying, "This house shall be like Shiloh, and this city shall be desolate, without an inhabitant'?" And all the people were gathered against Jeremiah in the house of the LORD.

10. When the princes of Judah heard these things, they came up from the king's house to the house of the LORD and sat down in the entry of the New Gate of the LORD's house.

11. And the priests and the prophets spoke to the princes and all the people, saying, "This man deserves to die! For he has prophesied against this city, as you have heard with your ears."

12. Then Jeremiah spoke to all the princes and all the people, saying: "The LORD sent me to prophesy against this house and against this city with all the words that you have heard.

13. Now therefore, amend your ways and your doings, and obey the voice of the LORD your God; then the LORD will relent concerning the doom that He has pronounced against you.

14. As for me, here I am, in your hand; do with me as seems good and proper to you.

15. But know for certain that if you put me to death, you will surely bring innocent blood on yourselves, on this city, and on its inhabitants; for truly the LORD has sent me to you to speak all these words in your hearing."

16. So the princes and all the people said to the priests and the prophets, "This man does not deserve to die. For he has spoken to us in the name of the LORD our God."

17. Then certain of the elders of the land rose up and spoke to all the assembly of the people, saying:

18. "Micah of Moresheth prophesied in the days of Hezekiah king of Judah, and spoke to all the people of Judah, saying, "Thus says the LORD of hosts: "Zion shall be plowed like a field, Jerusalem shall become heaps of ruins, And the mountain of the temple Like the bare hills of the forest."'

19. Did Hezekiah king of Judah and all Judah ever put him to death? Did he not fear the LORD and seek the LORD's favor? And the LORD relented concerning the doom which He had pronounced against them. But we are doing great evil against ourselves."

20. Now there was also a man who prophesied in the name of the LORD, Urijah the son of Shemaiah of Kirjath Jearim, who prophesied against this city and against this land according to all the words of Jeremiah.

21. And when Jehoiakim the king, with all his mighty men and all the princes, heard his words, the king sought to put him to death; but when Urijah heard it, he was afraid and fled, and went to Egypt.

22. Then Jehoiakim the king sent men to Egypt: Elnathan the son of Achbor, and other men who went with him to Egypt.

23. And they brought Urijah from Egypt and brought him to Jehoiakim the king, who killed him with the sword and cast his dead body into the graves of the common people.

24. Nevertheless the hand of Ahikam the son of Shaphan was with Jeremiah, so that they should not give him into the hand of the people to put him to death.

## Chapter 27

1. In the beginning of the reign of Jehoiakim the son of Josiah, king of Judah, this word came to Jeremiah from the LORD, saying,

2. "Thus says the LORD to me: "Make for yourselves bonds and yokes, and put them on your neck,

3. and send them to the king of Edom, the king of Moab, the king of the Ammonites, the king of Tyre, and the king of Sidon, by the hand of the messengers who come to Jerusalem to Zedekiah king of Judah.

4. And command them to say to their masters, "Thus says the LORD of hosts, the God of Israel--thus you shall say to your masters:

5. "I have made the earth, the man and the beast that are on the ground, by My great power and by My outstretched arm, and have given it to whom it seemed proper to Me.

6. And now I have given all these lands into the hand of Nebuchadnezzar the king of Babylon, My servant; and the beasts of the field I have also given him to serve him.

7. So all nations shall serve him and his son and his son's son, until the time of his land comes; and then many nations and great kings shall make him serve them.

8. And it shall be, that the nation and kingdom which will not serve Nebuchadnezzar the king of Babylon, and which will not put its neck under the yoke of the king of Babylon, that nation I will punish,' says the LORD, "with the sword, the famine, and the pestilence, until I have consumed them by his hand.

9. Therefore do not listen to your prophets, your diviners, your dreamers, your soothsayers, or your sorcerers, who speak to you, saying, "You shall not serve the king of Babylon."

10. For they prophesy a lie to you, to remove you far from your land; and I will drive you out, and you will perish.

11. But the nations that bring their necks under the yoke of the king of Babylon and serve him, I will let them remain in their own land,' says the LORD, "and they shall till it and dwell in it."""

12. I also spoke to Zedekiah king of Judah according to all these words, saying, "Bring your necks under the yoke of the king of Babylon, and serve him and his people, and live!

13. Why will you die, you and your people, by the sword, by the famine, and by the pestilence, as the LORD has spoken against the nation that will not serve the king of Babylon?

14. Therefore do not listen to the words of the prophets who speak to you, saying, "You shall not serve the king of Babylon,' for they prophesy a lie to you;

15. for I have not sent them," says the LORD, "yet they prophesy a lie in My name, that I may drive you out, and that you may perish, you and the prophets who prophesy to you."

16. Also I spoke to the priests and to all this people, saying, "Thus says the LORD: "Do not listen to the words of your prophets who prophesy to you, saying, "Behold, the vessels of the LORD's house will now shortly be brought back from Babylon"; for they prophesy a lie to you.

17. Do not listen to them; serve the king of Babylon, and live! Why should this city be laid waste?

18. But if they are prophets, and if the word of the LORD is with them, let them now make intercession to the LORD of hosts, that the vessels which are left in the house of the LORD, in the house of the king of Judah, and at Jerusalem, do not go to Babylon.'

19. "For thus says the LORD of hosts concerning the pillars, concerning the Sea, concerning the carts, and concerning the remainder of the vessels that remain in this city,

20. which Nebuchadnezzar king of Babylon did not take, when he carried away captive Jeconiah the son of Jehoiakim, king of Judah, from Jerusalem to Babylon, and all the nobles of Judah and Jerusalem--

21. yes, thus says the LORD of hosts, the God of Israel, concerning the vessels that remain in the house of the LORD, and in the house of the king of Judah and of Jerusalem:

22. "They shall be carried to Babylon, and there they shall be until the day that I visit them,' says the LORD. "Then I will bring them up and restore them to this place."'

## Chapter 28

1. And it happened in the same year, at the beginning of the reign of Zedekiah king of Judah, in the fourth year and in the fifth month, that Hananiah the son of Azur the prophet, who was from Gibeon, spoke to me in the house of the LORD in the presence of the priests and of all the people, saying,

2. "Thus speaks the LORD of hosts, the God of Israel, saying: "I have broken the yoke of the king of Babylon.

3. Within two full years I will bring back to this place all the vessels of the LORD's house, that Nebuchadnezzar king of Babylon took away from this place and carried to Babylon.

4. And I will bring back to this place Jeconiah the son of Jehoiakim, king of Judah, with all the captives of Judah who went to Babylon,' says the LORD, "for I will break the yoke of the king of Babylon."'

5. Then the prophet Jeremiah spoke to the prophet Hananiah in the presence of the priests and in the presence of all the people who stood in the house of the LORD,

6. and the prophet Jeremiah said, "Amen! The LORD do so; the LORD perform your words which you have prophesied, to bring back the vessels of the LORD's house and all who were carried away captive, from Babylon to this place.

7. Nevertheless hear now this word that I speak in your hearing and in the hearing of all the people:

8. The prophets who have been before me and before you of old prophesied against many countries and great kingdoms--of war and disaster and pestilence.

9. As for the prophet who prophesies of peace, when the word of the prophet comes to pass, the prophet will be known as one whom the LORD has truly sent."

10. Then Hananiah the prophet took the yoke off the prophet Jeremiah's neck and broke it.

11. And Hananiah spoke in the presence of all the people, saying, "Thus says the LORD: "Even so I will break the yoke of Nebuchadnezzar king of Babylon from the neck of all nations within the space of two full years."' And the prophet Jeremiah went his way.

12. Now the word of the LORD came to Jeremiah, after Hananiah the prophet had broken the yoke from the neck of the prophet Jeremiah, saying,

13. "Go and tell Hananiah, saying, "Thus says the LORD: "You have broken the yokes of wood, but you have made in their place yokes of iron."

14. For thus says the LORD of hosts, the God of Israel: "I have put a yoke of iron on the neck of all these nations, that they may serve Nebuchadnezzar king of Babylon; and they shall serve him. I have given him the beasts of the field also.""'

15. Then the prophet Jeremiah said to Hananiah the prophet, "Hear now, Hananiah, the LORD has not sent you, but you make this people trust in a lie.

16. Therefore thus says the LORD: "Behold, I will cast you from the face of the earth. This year you shall die, because you have taught rebellion against the LORD."'

17. So Hananiah the prophet died the same year in the seventh month.

## Chapter 29

1. Now these are the words of the letter that Jeremiah the prophet sent from Jerusalem to the remainder of the elders who were carried away captive--to the priests, the prophets, and all the people whom Nebuchadnezzar had carried away captive from Jerusalem to Babylon.

2. (This happened after Jeconiah the king, the queen mother, the eunuchs, the princes of Judah and Jerusalem, the craftsmen, and the smiths had departed from Jerusalem.)

3. The letter was sent by the hand of Elasah the son of Shaphan, and Gemariah the son of Hilkiah, whom Zedekiah king of Judah sent to Babylon, to Nebuchadnezzar king of Babylon, saying,

4. Thus says the LORD of hosts, the God of Israel, to all who were carried away captive, whom I have caused to be carried away from Jerusalem to Babylon:

5. Build houses and dwell in them; plant gardens and eat their fruit.

6. Take wives and beget sons and daughters; and take wives for your sons and give your daughters to husbands, so that they may bear sons and daughters--that you may be increased there, and not diminished.

7. And seek the peace of the city where I have caused you to be carried away captive, and pray to the LORD for it; for in its peace you will have peace.

8. For thus says the LORD of hosts, the God of Israel: Do not let your prophets and your diviners who are in your midst deceive you, nor listen to your dreams which you cause to be dreamed.

9. For they prophesy falsely to you in My name; I have not sent them, says the LORD.

10. For thus says the LORD: After seventy years are completed at Babylon, I will visit you and perform My good word toward you, and cause you to return to this place.

11. For I know the thoughts that I think toward you, says the LORD, thoughts of peace and not of evil, to give you a future and a hope.

12. Then you will call upon Me and go and pray to Me, and I will listen to you.

13. And you will seek Me and find Me, when you search for Me with all your heart.

14. I will be found by you, says the LORD, and I will bring you back from your captivity; I will gather you from all the nations and from all the places where I have driven you, says the LORD, and I will bring you to the place from which I cause you to be carried away captive.

15. Because you have said, "The LORD has raised up prophets for us in Babylon"--

16. therefore thus says the LORD concerning the king who sits on the throne of David, concerning all the people who dwell in this city, and concerning your brethren who have not gone out with you into captivity--

17. thus says the LORD of hosts: Behold, I will send on them the sword, the famine, and the pestilence, and will make them like rotten figs that cannot be eaten, they are so bad.

18. And I will pursue them with the sword, with famine, and with pestilence; and I will deliver them to trouble among all the kingdoms of the earth--to be a curse, an astonishment, a hissing, and a reproach among all the nations where I have driven them,

19. because they have not heeded My words, says the LORD, which I sent to them by My servants the prophets, rising up early and sending them; neither would you heed, says the LORD.

20. Therefore hear the word of the LORD, all you of the captivity, whom I have sent from Jerusalem to Babylon.

21. Thus says the LORD of hosts, the God of Israel, concerning Ahab the son of Kolaiah, and Zedekiah the son of Maaseiah, who prophesy a lie to you in My name: Behold, I will deliver them into the hand of Nebuchadnezzar king of Babylon, and he shall slay them before your eyes.

22. And because of them a curse shall be taken up by all the captivity of Judah who are in Babylon, saying, "The LORD make you like Zedekiah and Ahab, whom the king of Babylon roasted in the fire";

23. because they have done disgraceful things in Israel, have committed adultery with their neighbors' wives, and have spoken lying words in My name, which I have not commanded them. Indeed I know, and am a witness, says the LORD.

24. You shall also speak to Shemaiah the Nehelamite, saying,

25. Thus speaks the LORD of hosts, the God of Israel, saying: You have sent letters in your name to all the people who are at Jerusalem, to Zephaniah the son of Maaseiah the priest, and to all the priests, saying,

26. "The LORD has made you priest instead of Jehoiada the priest, so that there should be officers in the house of the LORD over every man who is demented and considers himself a prophet, that you should put him in prison and in the stocks.

27. Now therefore, why have you not rebuked Jeremiah of Anathoth who makes himself a prophet to you?

28. For he has sent to us in Babylon, saying, "This captivity is long; build houses and dwell in them, and plant gardens and eat their fruit."'

29. Now Zephaniah the priest read this letter in the hearing of Jeremiah the prophet.

30. Then the word of the LORD came to Jeremiah, saying:

31. Send to all those in captivity, saying, Thus says the LORD concerning Shemaiah the Nehelamite: Because Shemaiah has prophesied to you, and I have not sent him, and he has caused you to trust in a lie--

32. therefore thus says the LORD: Behold, I will punish Shemaiah the Nehelamite and his family: he shall not have anyone to dwell among this people, nor shall he see the good that I will do for My people, says the LORD, because he has taught rebellion against the LORD.

## Chapter 30

1. The word that came to Jeremiah from the LORD, saying,

2. "Thus speaks the LORD God of Israel, saying: "Write in a book for yourself all the words that I have spoken to you.

3. For behold, the days are coming,' says the LORD, "that I will bring back from captivity My people Israel and Judah,' says the LORD. "And I will cause them to return to the land that I gave to their fathers, and they shall possess it."'

4. Now these are the words that the LORD spoke concerning Israel and Judah.

5. "For thus says the LORD: "We have heard a voice of trembling, Of fear, and not of peace.

6. Ask now, and see, Whether a man is ever in labor with child? So why do I see every man with his hands on his loins Like a woman in labor, And all faces turned pale?

7. Alas! For that day is great, So that none is like it; And it is the time of Jacob's trouble, But he shall be saved out of it.

8. "For it shall come to pass in that day,' Says the LORD of hosts, "That I will break his yoke from your neck, And will burst your bonds; Foreigners shall no more enslave them.

9. But they shall serve the LORD their God, And David their king, Whom I will raise up for them.

10. "Therefore do not fear, O My servant Jacob,' says the LORD, "Nor be dismayed, O Israel; For behold, I will save you from afar, And your seed from the land of their captivity. Jacob shall return, have rest and be quiet, And no one shall make him afraid.

11. For I am with you,' says the LORD, "to save you; Though I make a full end of all nations where I have scattered you, Yet I will not make a complete end of you. But I will correct you in justice, And will not let you go altogether unpunished.'

12. "For thus says the LORD: "Your affliction is incurable, Your wound is severe.

13. There is no one to plead your cause, That you may be bound up; You have no healing medicines.

14. All your lovers have forgotten you; They do not seek you; For I have wounded you with the wound of an enemy, With the chastisement of a cruel one, For the multitude of your iniquities, Because your sins have increased.

15. Why do you cry about your affliction? Your sorrow is incurable. Because of the multitude of your iniquities, Because your sins have increased, I have done these things to you.

16. "Therefore all those who devour you shall be devoured; And all your adversaries, every one of them, shall go into captivity; Those who plunder you shall become plunder, And all who prey upon you I will make a prey.

17. For I will restore health to you And heal you of your wounds,' says the LORD, "Because they called you an outcast saying: "This is Zion; No one seeks her."'

18. "Thus says the LORD: "Behold, I will bring back the captivity of Jacob's tents, And have mercy on his dwelling places; The city shall be built upon its own mound, And the palace shall remain according to its own plan.

19. Then out of them shall proceed thanksgiving And the voice of those who make merry; I will multiply them, and they shall not diminish; I will also glorify them, and they shall not be small.

20. Their children also shall be as before, And their congregation shall be established before Me; And I will punish all who oppress them.

21. Their nobles shall be from among them, And their governor shall come from their midst; Then I will cause him to draw near, And he shall approach Me; For who is this who pledged his heart to approach Me?' says the LORD.

22. "You shall be My people, And I will be your God."'

23. Behold, the whirlwind of the LORD Goes forth with fury, A continuing whirlwind; It will fall violently on the head of the wicked.

24. The fierce anger of the LORD will not return until He has done it, And until He has performed the intents of His heart. In the latter days you will consider it.

## Chapter 31

1. "At the same time," says the LORD, "I will be the God of all the families of Israel, and they shall be My people."

2. Thus says the LORD: "The people who survived the sword Found grace in the wilderness-- Israel, when I went to give him rest."

3. The LORD has appeared of old to me, saying: "Yes, I have loved you with an everlasting love; Therefore with lovingkindness I have drawn you.

4. Again I will build you, and you shall be rebuilt, O virgin of Israel! You shall again be adorned with your tambourines, And shall go forth in the dances of those who rejoice.

5. You shall yet plant vines on the mountains of Samaria; The planters shall plant and eat them as ordinary food.

6. For there shall be a day When the watchmen will cry on Mount Ephraim, "Arise, and let us go up to Zion, To the LORD our God."'

7. For thus says the LORD: "Sing with gladness for Jacob, And shout among the chief of the nations; Proclaim, give praise, and say, "O LORD, save Your people, The remnant of Israel!'

8. Behold, I will bring them from the north country, And gather them from the ends of the earth, Among them the blind and the lame, The woman with child And the one who labors with child, together; A great throng shall return there.

9. They shall come with weeping, And with supplications I will lead them. I will cause them to walk by the rivers of waters, In a straight way in which they shall not stumble; For I am a Father to Israel, And Ephraim is My firstborn.

10. "Hear the word of the LORD, O nations, And declare it in the isles afar off, and say, "He who scattered Israel will gather him, And keep him as a shepherd does his flock.'

11. For the LORD has redeemed Jacob, And ransomed him from the hand of one stronger than he.

12. Therefore they shall come and sing in the height of Zion, Streaming to the goodness of the LORD-- For wheat and new wine and oil, For the young of the flock and the herd; Their souls shall be like a well-watered garden, And they shall sorrow no more at all.

13. "Then shall the virgin rejoice in the dance, And the young men and the old, together; For I will turn their mourning to joy, Will comfort them, And make them rejoice rather than sorrow.

14. I will satiate the soul of the priests with abundance, And My people shall be satisfied with My goodness, says the LORD."

15. Thus says the LORD: "A voice was heard in Ramah, Lamentation and bitter weeping, Rachel weeping for her children, Refusing to be comforted for her children, Because they are no more."

16. Thus says the LORD: "Refrain your voice from weeping, And your eyes from tears; For your work shall be rewarded, says the LORD, And they shall come back from the land of the enemy.

17. There is hope in your future, says the LORD, That your children shall come back to their own border.

18. "I have surely heard Ephraim bemoaning himself: "You have chastised me, and I was chastised, Like an untrained bull; Restore me, and I will return, For You are the LORD my God.

19. Surely, after my turning, I repented; And after I was instructed, I struck myself on the thigh; I was ashamed, yes, even humiliated, Because I bore the reproach of my youth.'

20. Is Ephraim My dear son? Is he a pleasant child? For though I spoke against him, I earnestly remember him still; Therefore My heart yearns for him; I will surely have mercy on him, says the LORD.

21. "Set up signposts, Make landmarks; Set your heart toward the highway, The way in which you went. Turn back, O virgin of Israel, Turn back to these your cities.

22. How long will you gad about, O you backsliding daughter? For the LORD has created a new thing in the earth-- A woman shall encompass a man."

23. Thus says the LORD of hosts, the God of Israel: "They shall again use this speech in the land of Judah and in its cities, when I bring back their captivity: "The LORD bless you, O home of justice, and mountain of holiness!'

24. And there shall dwell in Judah itself, and in all its cities together, farmers and those going out with flocks.

25. For I have satiated the weary soul, and I have replenished every sorrowful soul."

26. After this I awoke and looked around, and my sleep was sweet to me.

27. "Behold, the days are coming, says the LORD, that I will sow the house of Israel and the house of Judah with the seed of man and the seed of beast.

28. And it shall come to pass, that as I have watched over them to pluck up, to break down, to throw down, to destroy, and to afflict, so I will watch over them to build and to plant, says the LORD.

29. In those days they shall say no more: "The fathers have eaten sour grapes, And the children's teeth are set on edge.'

30. But every one shall die for his own iniquity; every man who eats the sour grapes, his teeth shall be set on edge.

31. "Behold, the days are coming, says the LORD, when I will make a new covenant with the house of Israel and with the house of Judah--

32. not according to the covenant that I made with their fathers in the day that I took them by the hand to lead them out of the land of Egypt, My covenant which they broke, though I was a husband to them, says the LORD.

33. But this is the covenant that I will make with the house of Israel after those days, says the LORD: I will put My law in their minds, and write it on their hearts; and I will be their God, and they shall be My people.

34. No more shall every man teach his neighbor, and every man his brother, saying, "Know the LORD,' for they all shall know Me, from the least of them to the greatest of them, says the LORD. For I will forgive their iniquity, and their sin I will remember no more."

35. Thus says the LORD, Who gives the sun for a light by day, The ordinances of the moon and the stars for a light by night, Who disturbs the sea, And its waves roar (The LORD of hosts is His name):

36. "If those ordinances depart From before Me, says the LORD, Then the seed of Israel shall also cease From being a nation before Me forever."

37. Thus says the LORD: "If heaven above can be measured, And the foundations of the earth searched out beneath, I will also cast off all the seed of Israel For all that they have done, says the LORD.

38. "Behold, the days are coming, says the LORD, that the city shall be built for the LORD from the Tower of Hananel to the Corner Gate.

39. The surveyor's line shall again extend straight forward over the hill Gareb; then it shall turn toward Goath.

40. And the whole valley of the dead bodies and of the ashes, and all the fields as far as the Brook Kidron, to the corner of the Horse Gate toward the east, shall be holy to the LORD. It shall not be plucked up or thrown down anymore forever."

## Chapter 32

1. The word that came to Jeremiah from the LORD in the tenth year of Zedekiah king of Judah, which was the eighteenth year of Nebuchadnezzar.

2. For then the king of Babylon's army besieged Jerusalem, and Jeremiah the prophet was shut up in the court of the prison, which was in the king of Judah's house.

3. For Zedekiah king of Judah had shut him up, saying, "Why do you prophesy and say, "Thus says the LORD: "Behold, I will give this city into the hand of the king of Babylon, and he shall take it;

4. and Zedekiah king of Judah shall not escape from the hand of the Chaldeans, but shall surely be delivered into the hand of the king of Babylon, and shall speak with him face to face, and see him eye to eye;

5. then he shall lead Zedekiah to Babylon, and there he shall be until I visit him," says the LORD; "though you fight with the Chaldeans, you shall not succeed"'?"

6. And Jeremiah said, "The word of the LORD came to me, saying,

7. "Behold, Hanamel the son of Shallum your uncle will come to you, saying, "Buy my field which is in Anathoth, for the right of redemption is yours to buy it."'

8. Then Hanamel my uncle's son came to me in the court of the prison according to the word of the LORD, and said to me, "Please buy my field that is in Anathoth, which is in the country of Benjamin; for the right of inheritance is yours, and the redemption yours; buy it for yourself.' Then I knew that this was the word of the LORD.

9. So I bought the field from Hanamel, the son of my uncle who was in Anathoth, and weighed out to him the money--seventeen shekels of silver.

10. And I signed the deed and sealed it, took witnesses, and weighed the money on the scales.

11. So I took the purchase deed, both that which was sealed according to the law and custom, and that which was open;

12. and I gave the purchase deed to Baruch the son of Neriah, son of Mahseiah, in the presence of Hanamel my uncle's son, and in the presence of the witnesses who signed the purchase deed, before all the Jews who sat in the court of the prison.

13. "Then I charged Baruch before them, saying,

14. "Thus says the LORD of hosts, the God of Israel: "Take these deeds, both this purchase deed which is sealed and this deed which is open, and put them in an earthen vessel, that they may last many days."

15. For thus says the LORD of hosts, the God of Israel: "Houses and fields and vineyards shall be possessed again in this land."'

16. "Now when I had delivered the purchase deed to Baruch the son of Neriah, I prayed to the LORD, saying:

17. "Ah, Lord GOD! Behold, You have made the heavens and the earth by Your great power and outstretched arm. There is nothing too hard for You.

18. You show lovingkindness to thousands, and repay the iniquity of the fathers into the bosom of their children after them--the Great, the Mighty God, whose name is the LORD of hosts.

19. You are great in counsel and mighty in work, for your eyes are open to all the ways of the sons of men, to give everyone according to his ways and according to the fruit of his doings.

20. You have set signs and wonders in the land of Egypt, to this day, and in Israel and among other men; and You have made Yourself a name, as it is this day.

21. You have brought Your people Israel out of the land of Egypt with signs and wonders, with a strong hand and an outstretched arm, and with great terror;

22. You have given them this land, of which You swore to their fathers to give them--"a land flowing with milk and honey."

23. And they came in and took possession of it, but they have not obeyed Your voice or walked in Your law. They have done nothing of all that You commanded them to do; therefore You have caused all this calamity to come upon them.

24. "Look, the siege mounds! They have come to the city to take it; and the city has been given into the hand of the Chaldeans who fight against it, because of the sword and famine and pestilence. What You have spoken has happened; there You see it!

25. And You have said to me, O Lord GOD, "Buy the field for money, and take witnesses"!--yet the city has been given into the hand of the Chaldeans."'

26. Then the word of the LORD came to Jeremiah, saying,

27. "Behold, I am the LORD, the God of all flesh. Is there anything too hard for Me?

28. Therefore thus says the LORD: "Behold, I will give this city into the hand of the Chaldeans, into the hand of Nebuchadnezzar king of Babylon, and he shall take it.

29. And the Chaldeans who fight against this city shall come and set fire to this city and burn it, with the houses on whose roofs they have offered incense to Baal and poured out drink offerings to other gods, to provoke Me to anger;

30. because the children of Israel and the children of Judah have done only evil before Me from their youth. For the children of Israel have provoked Me only to anger with the work of their hands,' says the LORD.

31. "For this city has been to Me a provocation of My anger and My fury from the day that they built it, even to this day; so I will remove it from before My face

32. because of all the evil of the children of Israel and the children of Judah, which they have done to provoke Me to anger--they, their kings, their princes, their priests, their prophets, the men of Judah, and the inhabitants of Jerusalem.

33. And they have turned to Me the back, and not the face; though I taught them, rising up early and teaching them, yet they have not listened to receive instruction.

34. But they set their abominations in the house which is called by My name, to defile it.

35. And they built the high places of Baal which are in the Valley of the Son of Hinnom, to cause their sons and their daughters to pass through the fire to Molech, which I did not command them, nor did it come into My mind that they should do this abomination, to cause Judah to sin.'

36. "Now therefore, thus says the LORD, the God of Israel, concerning this city of which you say, "It shall be delivered into the hand of the king of Babylon by the sword, by the famine, and by the pestilence:

37. Behold, I will gather them out of all countries where I have driven them in My anger, in My fury, and in great wrath; I will bring them back to this place, and I will cause them to dwell safely.

38. They shall be My people, and I will be their God;

39. then I will give them one heart and one way, that they may fear Me forever, for the good of them and their children after them.

40. And I will make an everlasting covenant with them, that I will not turn away from doing them good; but I will put My fear in their hearts so that they will not depart from Me.

41. Yes, I will rejoice over them to do them good, and I will assuredly plant them in this land, with all My heart and with all My soul.'

42. "For thus says the LORD: "Just as I have brought all this great calamity on this people, so I will bring on them all the good that I have promised them.

43. And fields will be bought in this land of which you say, "It is desolate, without man or beast; it has been given into the hand of the Chaldeans."

44. Men will buy fields for money, sign deeds and seal them, and take witnesses, in the land of Benjamin, in the places around Jerusalem, in the cities of Judah, in the cities of the mountains, in the cities of the lowland, and in the cities of the South; for I will cause their captives to return,' says the LORD."

## Chapter 33

1. Moreover the word of the LORD came to Jeremiah a second time, while he was still shut up in the court of the prison, saying,

2. "Thus says the LORD who made it, the LORD who formed it to establish it (the LORD is His name):

3. "Call to Me, and I will answer you, and show you great and mighty things, which you do not know.'

4. "For thus says the LORD, the God of Israel, concerning the houses of this city and the houses of the kings of Judah, which have been pulled down to fortify against the siege mounds and the sword:

5. "They come to fight with the Chaldeans, but only to fill their places with the dead bodies of men whom I will slay in My anger and My fury, all for whose wickedness I have hidden My face from this city.

6. Behold, I will bring it health and healing; I will heal them and reveal to them the abundance of peace and truth.

7. And I will cause the captives of Judah and the captives of Israel to return, and will rebuild those places as at the first.

8. I will cleanse them from all their iniquity by which they have sinned against Me, and I will pardon all their iniquities by which they have sinned and by which they have transgressed against Me.

9. Then it shall be to Me a name of joy, a praise, and an honor before all nations of the earth, who shall hear all the good that I do to them; they shall fear and tremble for all the goodness and all the prosperity that I provide for it.'

10. "Thus says the LORD: "Again there shall be heard in this place--of which you say, "It is desolate, without man and without beast"--in the cities of Judah, in the streets of Jerusalem that are desolate, without man and without inhabitant and without beast,

11. the voice of joy and the voice of gladness, the voice of the bridegroom and the voice of the bride, the voice of those who will say: "Praise the LORD of hosts, For the LORD is good, For His mercy endures forever"-- and of those who will bring the sacrifice of praise into the house of the LORD. For I will cause the captives of the land to return as at the first,' says the LORD.

12. "Thus says the LORD of hosts: "In this place which is desolate, without man and without beast, and in all its cities, there shall again be a dwelling place of shepherds causing their flocks to lie down.

13. In the cities of the mountains, in the cities of the lowland, in the cities of the South, in the land of Benjamin, in the places around Jerusalem, and in the cities of Judah, the flocks shall again pass under the hands of him who counts them,' says the LORD.

14. "Behold, the days are coming,' says the LORD, "that I will perform that good thing which I have promised to the house of Israel and to the house of Judah:

15. "In those days and at that time I will cause to grow up to David A Branch of righteousness; He shall execute judgment and righteousness in the earth.

16. In those days Judah will be saved, And Jerusalem will dwell safely. And this is the name by which she will be called: THE LORD OUR RIGHTEOUSNESS.'

17. "For thus says the LORD: "David shall never lack a man to sit on the throne of the house of Israel;

18. nor shall the priests, the Levites, lack a man to offer burnt offerings before Me, to kindle grain offerings, and to sacrifice continually."'

19. And the word of the LORD came to Jeremiah, saying,

20. "Thus says the LORD: "If you can break My covenant with the day and My covenant with the night, so that there will not be day and night in their season,

21. then My covenant may also be broken with David My servant, so that he shall not have a son to reign on his throne, and with the Levites, the priests, My ministers.

22. As the host of heaven cannot be numbered, nor the sand of the sea measured, so will I multiply the descendants of David My servant and the Levites who minister to Me."'

23. Moreover the word of the LORD came to Jeremiah, saying,

24. "Have you not considered what these people have spoken, saying, "The two families which the LORD has chosen, He has also cast them off|'? Thus they have despised My people, as if they should no more be a nation before them.

25. "Thus says the LORD: "If My covenant is not with day and night, and if I have not appointed the ordinances of heaven and earth,

26. then I will cast away the descendants of Jacob and David My servant, so that I will not take any of his descendants to be rulers over the descendants of Abraham, Isaac, and Jacob. For I will cause their captives to return, and will have mercy on them."'

## Chapter 34

1. The word which came to Jeremiah from the LORD, when Nebuchadnezzar king of Babylon and all his army, all the kingdoms of the earth under his dominion, and all the people, fought against Jerusalem and all its cities, saying,

2. "Thus says the LORD, the God of Israel: "Go and speak to Zedekiah king of Judah and tell him, "Thus says the LORD: "Behold, I will give this city into the hand of the king of Babylon, and he shall burn it with fire.

3. And you shall not escape from his hand, but shall surely be taken and delivered into his hand; your eyes shall see the eyes of the king of Babylon, he shall speak with you face to face, and you shall go to Babylon.""

4. Yet hear the word of the LORD, O Zedekiah king of Judah! Thus says the LORD concerning you: "You shall not die by the sword.

5. You shall die in peace; as in the ceremonies of your fathers, the former kings who were before you, so they shall burn incense for you and lament for you, saying, "Alas, lord!" For I have pronounced the word, says the LORD."'

6. Then Jeremiah the prophet spoke all these words to Zedekiah king of Judah in Jerusalem,

7. when the king of Babylon's army fought against Jerusalem and all the cities of Judah that were left, against Lachish and Azekah; for only these fortified cities remained of the cities of Judah.

8. This is the word that came to Jeremiah from the LORD, after King Zedekiah had made a covenant with all the people who were at Jerusalem to proclaim liberty to them:

9. that every man should set free his male and female slave--a Hebrew man or woman--that no one should keep a Jewish brother in bondage.

10. Now when all the princes and all the people, who had entered into the covenant, heard that everyone should set free his male and female slaves, that no one should keep them in bondage anymore, they obeyed and let them go.

11. But afterward they changed their minds and made the male and female slaves return, whom they had set free, and brought them into subjection as male and female slaves.

12. Therefore the word of the LORD came to Jeremiah from the LORD, saying,

13. "Thus says the LORD, the God of Israel: "I made a covenant with your fathers in the day that I brought them out of the land of Egypt, out of the house of bondage, saying,

14. "At the end of seven years let every man set free his Hebrew brother, who has been sold to him; and when he has served you six years, you shall let him go free from you." But your fathers did not obey Me nor incline their ear.

15. Then you recently turned and did what was right in My sight--every man proclaiming liberty to his neighbor; and you made a covenant before Me in the house which is called by My name.

16. Then you turned around and profaned My name, and every one of you brought back his male and female slaves, whom he had set at liberty, at their pleasure, and brought them back into subjection, to be your male and female slaves.'

17. "Therefore thus says the LORD: "You have not obeyed Me in proclaiming liberty, every one to his brother and every one to his neighbor. Behold, I proclaim liberty to you,' says the LORD--"to the sword, to pestilence, and to famine! And I will deliver you to trouble among all the kingdoms of the earth.

18. And I will give the men who have transgressed My covenant, who have not performed the words of the covenant which they made before Me, when they cut the calf in two and passed between the parts of it--

19. the princes of Judah, the princes of Jerusalem, the eunuchs, the priests, and all the people of the land who passed between the parts of the calf--

20. I will give them into the hand of their enemies and into the hand of those who seek their life. Their dead bodies shall be for meat for the birds of the heaven and the beasts of the earth.

21. And I will give Zedekiah king of Judah and his princes into the hand of their enemies, into the hand of those who seek their life, and into the hand of the king of Babylon's army which has gone back from you.

22. Behold, I will command,' says the LORD, "and cause them to return to this city. They will fight against it and take it and burn it with fire; and I will make the cities of Judah a desolation without inhabitant."'

## Chapter 35

1. The word which came to Jeremiah from the LORD in the days of Jehoiakim the son of Josiah, king of Judah, saying,

2. "Go to the house of the Rechabites, speak to them, and bring them into the house of the LORD, into one of the chambers, and give them wine to drink."

3. Then I took Jaazaniah the son of Jeremiah, the son of Habazziniah, his brothers and all his sons, and the whole house of the Rechabites,

4. and I brought them into the house of the LORD, into the chamber of the sons of Hanan the son of Igdaliah, a man of God, which was by the chamber of the princes, above the chamber of Maaseiah the son of Shallum, the keeper of the door.

5. Then I set before the sons of the house of the Rechabites bowls full of wine, and cups; and I said to them, "Drink wine."

6. But they said, "We will drink no wine, for Jonadab the son of Rechab, our father, commanded us, saying, "You shall drink no wine, you nor your sons, forever.

7. You shall not build a house, sow seed, plant a vineyard, nor have any of these; but all your days you shall dwell in tents, that you may live many days in the land where you are sojourners.'

8. Thus we have obeyed the voice of Jonadab the son of Rechab, our father, in all that he charged us, to drink no wine all our days, we, our wives, our sons, or our daughters,

9. nor to build ourselves houses to dwell in; nor do we have vineyard, field, or seed.

10. But we have dwelt in tents, and have obeyed and done according to all that Jonadab our father commanded us.

11. But it came to pass, when Nebuchadnezzar king of Babylon came up into the land, that we said, "Come, let us go to Jerusalem for fear of the army of the Chaldeans and for fear of the army of the Syrians.' So we dwell at Jerusalem."

12. Then came the word of the LORD to Jeremiah, saying,

13. "Thus says the LORD of hosts, the God of Israel: "Go and tell the men of Judah and the inhabitants of Jerusalem, "Will you not receive instruction to obey My words?" says the LORD.

14. "The words of Jonadab the son of Rechab, which he commanded his sons, not to drink wine, are performed; for to this day they drink none, and obey their father's commandment. But although I have spoken to you, rising early and speaking, you did not obey Me.

15. I have also sent to you all My servants the prophets, rising up early and sending them, saying, "Turn now everyone from his evil way, amend your doings, and do not go after other gods to serve them; then you will dwell in the land which I have given you and your fathers.' But you have not inclined your ear, nor obeyed Me.

16. Surely the sons of Jonadab the son of Rechab have performed the commandment of their father, which he commanded them, but this people has not obeyed Me."'

17. "Therefore thus says the LORD God of hosts, the God of Israel: "Behold, I will bring on Judah and on all the inhabitants of Jerusalem all the doom that I have pronounced against them; because I have spoken to them but they have not heard, and I have called to them but they have not answered."'

18. And Jeremiah said to the house of the Rechabites, "Thus says the LORD of hosts, the God of Israel: "Because you have obeyed the commandment of Jonadab your father, and kept all his precepts and done according to all that he commanded you,

19. therefore thus says the LORD of hosts, the God of Israel: "Jonadab the son of Rechab shall not lack a man to stand before Me forever.""'

## Chapter 36

1. Now it came to pass in the fourth year of Jehoiakim the son of Josiah, king of Judah, that this word came to Jeremiah from the LORD, saying:

2. "Take a scroll of a book and write on it all the words that I have spoken to you against Israel, against Judah, and against all the nations, from the day I spoke to you, from the days of Josiah even to this day.

3. It may be that the house of Judah will hear all the adversities which I purpose to bring upon them, that everyone may turn from his evil way, that I may forgive their iniquity and their sin."

4. Then Jeremiah called Baruch the son of Neriah; and Baruch wrote on a scroll of a book, at the instruction of Jeremiah, all the words of the LORD which He had spoken to him.

5. And Jeremiah commanded Baruch, saying, "I am confined, I cannot go into the house of the LORD.

6. You go, therefore, and read from the scroll which you have written at my instruction, the words of the LORD, in the hearing of the people in the LORD's house on the day of fasting. And you shall also read them in the hearing of all Judah who come from their cities.

7. It may be that they will present their supplication before the LORD, and everyone will turn from his evil way. For great is the anger and the fury that the LORD has pronounced against this people."

8. And Baruch the son of Neriah did according to all that Jeremiah the prophet commanded him, reading from the book the words of the LORD in the LORD's house.

9. Now it came to pass in the fifth year of Jehoiakim the son of Josiah, king of Judah, in the ninth month, that they proclaimed a fast before the LORD to all the people in Jerusalem, and to all the people who came from the cities of Judah to Jerusalem.

10. Then Baruch read from the book the words of Jeremiah in the house of the LORD, in the chamber of Gemariah the son of Shaphan the scribe, in the upper court at the entry of the New Gate of the LORD's house, in the hearing of all the people.

11. When Michaiah the son of Gemariah, the son of Shaphan, heard all the words of the LORD from the book,

12. he then went down to the king's house, into the scribe's chamber; and there all the princes were sitting--Elishama the scribe, Delaiah the son of Shemaiah, Elnathan the son of Achbor, Gemariah the son of Shaphan, Zedekiah the son of Hananiah, and all the princes.

13. Then Michaiah declared to them all the words that he had heard when Baruch read the book in the hearing of the people.

14. Therefore all the princes sent Jehudi the son of Nethaniah, the son of Shelemiah, the son of Cushi, to Baruch, saying, "Take in your hand the scroll from which you have read in the hearing of the people, and come." So Baruch the son of Neriah took the scroll in his hand and came to them.

15. And they said to him, "Sit down now, and read it in our hearing." So Baruch read it in their hearing.

16. Now it happened, when they had heard all the words, that they looked in fear from one to another, and said to Baruch, "We will surely tell the king of all these words."

17. And they asked Baruch, saying, "Tell us now, how did you write all these words--at his instruction?"

18. So Baruch answered them, "He proclaimed with his mouth all these words to me, and I wrote them with ink in the book."

19. Then the princes said to Baruch, "Go and hide, you and Jeremiah; and let no one know where you are."

20. And they went to the king, into the court; but they stored the scroll in the chamber of Elishama the scribe, and told all the words in the hearing of the king.

21. So the king sent Jehudi to bring the scroll, and he took it from Elishama the scribe's chamber. And Jehudi read it in the hearing of the king and in the hearing of all the princes who stood beside the king.

22. Now the king was sitting in the winter house in the ninth month, with a fire burning on the hearth before him.

23. And it happened, when Jehudi had read three or four columns, that the king cut it with the scribe's knife and cast it into the fire that was on the hearth, until all the scroll was consumed in the fire that was on the hearth.

24. Yet they were not afraid, nor did they tear their garments, the king nor any of his servants who heard all these words.

25. Nevertheless Elnathan, Delaiah, and Gemariah implored the king not to burn the scroll; but he would not listen to them.

26. And the king commanded Jerahmeel the king's son, Seraiah the son of Azriel, and Shelemiah the son of Abdeel, to seize Baruch the scribe and Jeremiah the prophet, but the LORD hid them.

27. Now after the king had burned the scroll with the words which Baruch had written at the instruction of Jeremiah, the word of the LORD came to Jeremiah, saying:

28. "Take yet another scroll, and write on it all the former words that were in the first scroll which Jehoiakim the king of Judah has burned.

29. And you shall say to Jehoiakim king of Judah, "Thus says the LORD: "You have burned this scroll, saying, "Why have you written in it that the king of Babylon will certainly come and destroy this land, and cause man and beast to cease from here?"'

30. Therefore thus says the LORD concerning Jehoiakim king of Judah: "He shall have no one to sit on the throne of David, and his dead body shall be cast out to the heat of the day and the frost of the night.

31. I will punish him, his family, and his servants for their iniquity; and I will bring on them, on the inhabitants of Jerusalem, and on the men of Judah all the doom that I have pronounced against them; but they did not heed.""'

32. Then Jeremiah took another scroll and gave it to Baruch the scribe, the son of Neriah, who wrote on it at the instruction of Jeremiah all the words of the book which Jehoiakim king of Judah had burned in the fire. And besides, there were added to them many similar words.

## Chapter 37

1. Now King Zedekiah the son of Josiah reigned instead of Coniah the son of Jehoiakim, whom Nebuchadnezzar king of Babylon made king in the land of Judah.

2. But neither he nor his servants nor the people of the land gave heed to the words of the LORD which He spoke by the prophet Jeremiah.

3. And Zedekiah the king sent Jehucal the son of Shelemiah, and Zephaniah the son of Maaseiah, the priest, to the prophet Jeremiah, saying, "Pray now to the LORD our God for us."

4. Now Jeremiah was coming and going among the people, for they had not yet put him in prison.

5. Then Pharaoh's army came up from Egypt; and when the Chaldeans who were besieging Jerusalem heard news of them, they departed from Jerusalem.

6. Then the word of the LORD came to the prophet Jeremiah, saying,

7. "Thus says the LORD, the God of Israel, "Thus you shall say to the king of Judah, who sent you to Me to inquire of Me: "Behold, Pharaoh's army which has come up to help you will return to Egypt, to their own land.

8. And the Chaldeans shall come back and fight against this city, and take it and burn it with fire."'

9. Thus says the LORD: "Do not deceive yourselves, saying, "The Chaldeans will surely depart from us," for they will not depart.

10. For though you had defeated the whole army of the Chaldeans who fight against you, and there remained only wounded men among them, they would rise up, every man in his tent, and burn the city with fire."'

11. And it happened, when the army of the Chaldeans left the siege of Jerusalem for fear of Pharaoh's army,

12. that Jeremiah went out of Jerusalem to go into the land of Benjamin to claim his property there among the people.

13. And when he was in the Gate of Benjamin, a captain of the guard was there whose name was Irijah the son of Shelemiah, the son of Hananiah; and he seized Jeremiah the prophet, saying, "You are defecting to the Chaldeans!"

14. Then Jeremiah said, "False! I am not defecting to the Chaldeans." But he did not listen to him. So Irijah seized Jeremiah and brought him to the princes.

15. Therefore the princes were angry with Jeremiah, and they struck him and put him in prison in the house of Jonathan the scribe. For they had made that the prison.

16. When Jeremiah entered the dungeon and the cells, and Jeremiah had remained there many days,

17. then Zedekiah the king sent and took him out. The king asked him secretly in his house, and said, "Is there any word from the LORD?" And Jeremiah said, "There is." Then he said, "You shall be delivered into the hand of the king of Babylon!"

18. Moreover Jeremiah said to King Zedekiah, "What offense have I committed against you, against your servants, or against this people, that you have put me in prison?

19. Where now are your prophets who prophesied to you, saying, "The king of Babylon will not come against you or against this land'?

20. Therefore please hear now, O my lord the king. Please, let my petition be accepted before you, and do not make me return to the house of Jonathan the scribe, lest I die there."

21. Then Zedekiah the king commanded that they should commit Jeremiah to the court of the prison, and that they should give him daily a piece of bread from the bakers' street, until all the bread in the city was gone. Thus Jeremiah remained in the court of the prison.

## Chapter 38

1. Now Shephatiah the son of Mattan, Gedaliah the son of Pashhur, Jucal the son of Shelemiah, and Pashhur the son of Malchiah heard the words that Jeremiah had spoken to all the people, saying,

2. "Thus says the LORD: "He who remains in this city shall die by the sword, by famine, and by pestilence; but he who goes over to the Chaldeans shall live; his life shall be as a prize to him, and he shall live.'

3. Thus says the LORD: "This city shall surely be given into the hand of the king of Babylon's army, which shall take it."'

4. Therefore the princes said to the king, "Please, let this man be put to death, for thus he weakens the hands of the men of war who remain in this city, and the hands of all the people, by speaking such words to them. For this man does not seek the welfare of this people, but their harm."

5. Then Zedekiah the king said, "Look, he is in your hand. For the king can do nothing against you."

6. So they took Jeremiah and cast him into the dungeon of Malchiah the king's son, which was in the court of the prison, and they let Jeremiah down with ropes. And in the dungeon there was no water, but mire. So Jeremiah sank in the mire.

7. Now Ebed-Melech the Ethiopian, one of the eunuchs, who was in the king's house, heard that they had put Jeremiah in the dungeon. When the king was sitting at the Gate of Benjamin,

8. Ebed-Melech went out of the king's house and spoke to the king, saying:

9. "My lord the king, these men have done evil in all that they have done to Jeremiah the prophet, whom they have cast into the dungeon, and he is likely to die from hunger in the place where he is. For there is no more bread in the city."

10. Then the king commanded Ebed-Melech the Ethiopian, saying, "Take from here thirty men with you, and lift Jeremiah the prophet out of the dungeon before he dies."

11. So Ebed-Melech took the men with him and went into the house of the king under the treasury, and took from there old clothes and old rags, and let them down by ropes into the dungeon to Jeremiah.

12. Then Ebed-Melech the Ethiopian said to Jeremiah, "Please put these old clothes and rags under your armpits, under the ropes." And Jeremiah did so.

13. So they pulled Jeremiah up with ropes and lifted him out of the dungeon. And Jeremiah remained in the court of the prison.

14. Then Zedekiah the king sent and had Jeremiah the prophet brought to him at the third entrance of the house of the LORD. And the king said to Jeremiah, "I will ask you something. Hide nothing from me."

15. Jeremiah said to Zedekiah, "If I declare it to you, will you not surely put me to death? And if I give you advice, you will not listen to me."

16. So Zedekiah the king swore secretly to Jeremiah, saying, "As the LORD lives, who made our very souls, I will not put you to death, nor will I give you into the hand of these men who seek your life."

17. Then Jeremiah said to Zedekiah, "Thus says the LORD, the God of hosts, the God of Israel: "If you surely surrender to the king of Babylon's princes, then your soul shall live; this city shall not be burned with fire, and you and your house shall live.

18. But if you do not surrender to the king of Babylon's princes, then this city shall be given into the hand of the Chaldeans; they shall burn it with fire, and you shall not escape from their hand."'

19. And Zedekiah the king said to Jeremiah, "I am afraid of the Jews who have defected to the Chaldeans, lest they deliver me into their hand, and they abuse me."

20. But Jeremiah said, "They shall not deliver you. Please, obey the voice of the LORD which I speak to you. So it shall be well with you, and your soul shall live.

21. But if you refuse to surrender, this is the word that the LORD has shown me:

22. "Now behold, all the women who are left in the king of Judah's house shall be surrendered to the king of Babylon's princes, and those women shall say: "Your close friends have set upon you And prevailed against you; Your feet have sunk in the mire, And they have turned away again."

23. "So they shall surrender all your wives and children to the Chaldeans. You shall not escape from their hand, but shall be taken by the hand of the king of Babylon. And you shall cause this city to be burned with fire."'

24. Then Zedekiah said to Jeremiah, "Let no one know of these words, and you shall not die.

25. But if the princes hear that I have talked with you, and they come to you and say to you, "Declare to us now what you have said to the king, and also what the king said to you; do not hide it from us, and we will not put you to death,'

26. then you shall say to them, "I presented my request before the king, that he would not make me return to Jonathan's house to die there."'

27. Then all the princes came to Jeremiah and asked him. And he told them according to all these words that the king had commanded. So they stopped speaking with him, for the conversation had not been heard.

28. Now Jeremiah remained in the court of the prison until the day that Jerusalem was taken. And he was there when Jerusalem was taken.

## Chapter 39

1. In the ninth year of Zedekiah king of Judah, in the tenth month, Nebuchadnezzar king of Babylon and all his army came against Jerusalem, and besieged it.

2. In the eleventh year of Zedekiah, in the fourth month, on the ninth day of the month, the city was penetrated.

3. Then all the princes of the king of Babylon came in and sat in the Middle Gate: Nergal-Sharezer, Samgar-Nebo, Sarsechim, Rabsaris, Nergal-Sarezer, Rabmag, with the rest of the princes of the king of Babylon.

4. So it was, when Zedekiah the king of Judah and all the men of war saw them, that they fled and went out of the city by night, by way of the king's garden, by the gate between the two walls. And he went out by way of the plain.

5. But the Chaldean army pursued them and overtook Zedekiah in the plains of Jericho. And when they had captured him, they brought him up to Nebuchadnezzar king of Babylon, to Riblah in the land of Hamath, where he pronounced judgment on him.

6. Then the king of Babylon killed the sons of Zedekiah before his eyes in Riblah; the king of Babylon also killed all the nobles of Judah.

7. Moreover he put out Zedekiah's eyes, and bound him with bronze fetters to carry him off to Babylon.

8. And the Chaldeans burned the king's house and the houses of the people with fire, and broke down the walls of Jerusalem.

9. Then Nebuzaradan the captain of the guard carried away captive to Babylon the remnant of the people who remained in the city and those who defected to him, with the rest of the people who remained.

10. But Nebuzaradan the captain of the guard left in the land of Judah the poor people, who had nothing, and gave them vineyards and fields at the same time.

11. Now Nebuchadnezzar king of Babylon gave charge concerning Jeremiah to Nebuzaradan the captain of the guard, saying,

12. "Take him and look after him, and do him no harm; but do to him just as he says to you."

13. So Nebuzaradan the captain of the guard sent Nebushasban, Rabsaris, Nergal-Sharezer, Rabmag, and all the king of Babylon's chief officers;

14. then they sent someone to take Jeremiah from the court of the prison, and committed him to Gedaliah the son of Ahikam, the son of Shaphan, that he should take him home. So he dwelt among the people.

15. Meanwhile the word of the LORD had come to Jeremiah while he was shut up in the court of the prison, saying,

16. "Go and speak to Ebed-Melech the Ethiopian, saying, "Thus says the LORD of hosts, the God of Israel: "Behold, I will bring My words upon this city for adversity and not for good, and they shall be performed in that day before you.

17. But I will deliver you in that day," says the LORD, "and you shall not be given into the hand of the men of whom you are afraid.

18. For I will surely deliver you, and you shall not fall by the sword; but your life shall be as a prize to you, because you have put your trust in Me," says the LORD."'

## Chapter 40

1. The word that came to Jeremiah from the LORD after Nebuzaradan the captain of the guard had let him go from Ramah, when he had taken him bound in chains among all who were carried away captive from Jerusalem and Judah, who were carried away captive to Babylon.

2. And the captain of the guard took Jeremiah and said to him: "The LORD your God has pronounced this doom on this place.

3. Now the LORD has brought it, and has done just as He said. Because you people have sinned against the LORD, and not obeyed His voice, therefore this thing has come upon you.

4. And now look, I free you this day from the chains that were on your hand. If it seems good to you to come with me to Babylon, come, and I will look after you. But if it seems wrong for you to come with me to Babylon, remain here. See, all the land is before you; wherever it seems good and convenient for you to go, go there."

5. Now while Jeremiah had not yet gone back, Nebuzaradan said, "Go back to Gedaliah the son of Ahikam, the son of Shaphan, whom the king of Babylon has made governor over the cities of Judah, and dwell with him among the people. Or go wherever it seems convenient for you to go." So the captain of the guard gave him rations and a gift and let him go.

6. Then Jeremiah went to Gedaliah the son of Ahikam, to Mizpah, and dwelt with him among the people who were left in the land.

7. And when all the captains of the armies who were in the fields, they and their men, heard that the king of Babylon had made Gedaliah the son of Ahikam governor in the land, and had committed to him men, women, children, and the poorest of the land who had not been carried away captive to Babylon,

8. then they came to Gedaliah at Mizpah--Ishmael the son of Nethaniah, Johanan and Jonathan the sons of Kareah, Seraiah the son of Tanhumeth, the sons of Ephai the Netophathite, and Jezaniah the son of a Maachathite, they and their men.

9. And Gedaliah the son of Ahikam, the son of Shaphan, took an oath before them and their men, saying, "Do not be afraid to serve the Chaldeans. Dwell in the land and serve the king of Babylon, and it shall be well with you.

10. As for me, I will indeed dwell at Mizpah and serve the Chaldeans who come to us. But you, gather wine and summer fruit and oil, put them in your vessels, and dwell in your cities that you have taken."

11. Likewise, when all the Jews who were in Moab, among the Ammonites, in Edom, and who were in all the countries, heard that the king of Babylon had left a remnant of Judah, and that he had set over them Gedaliah the son of Ahikam, the son of Shaphan,

12. then all the Jews returned out of all places where they had been driven, and came to the land of Judah, to Gedaliah at Mizpah, and gathered wine and summer fruit in abundance.

13. Moreover Johanan the son of Kareah and all the captains of the forces that were in the fields came to Gedaliah at Mizpah,

14. and said to him, "Do you certainly know that Baalis the king of the Ammonites has sent Ishmael the son of Nethaniah to murder you?" But Gedaliah the son of Ahikam did not believe them.

15. Then Johanan the son of Kareah spoke secretly to Gedaliah in Mizpah, saying, "Let me go, please, and I will kill Ishmael the son of Nethaniah, and no one will know it. Why should he murder you, so that all the Jews who are gathered to you would be scattered, and the remnant in Judah perish?"

16. But Gedaliah the son of Ahikam said to Johanan the son of Kareah, "You shall not do this thing, for you speak falsely concerning Ishmael."

## Chapter 41

1. Now it came to pass in the seventh month that Ishmael the son of Nethaniah, the son of Elishama, of the royal family and of the officers of the king, came with ten men to Gedaliah the son of Ahikam, at Mizpah. And there they ate bread together in Mizpah.

2. Then Ishmael the son of Nethaniah, and the ten men who were with him, arose and struck Gedaliah the son of Ahikam, the son of Shaphan, with the sword, and killed him whom the king of Babylon had made governor over the land.

3. Ishmael also struck down all the Jews who were with him, that is, with Gedaliah at Mizpah, and the Chaldeans who were found there, the men of war.

4. And it happened, on the second day after he had killed Gedaliah, when as yet no one knew it,

5. that certain men came from Shechem, from Shiloh, and from Samaria, eighty men with their beards shaved and their clothes torn, having cut themselves, with offerings and incense in their hand, to bring them to the house of the LORD.

6. Now Ishmael the son of Nethaniah went out from Mizpah to meet them, weeping as he went along; and it happened as he met them that he said to them, "Come to Gedaliah the son of Ahikam!"

7. So it was, when they came into the midst of the city, that Ishmael the son of Nethaniah killed them and cast them into the midst of a pit, he and the men who were with him.

8. But ten men were found among them who said to Ishmael, "Do not kill us, for we have treasures of wheat, barley, oil, and honey in the field." So he desisted and did not kill them among their brethren.

9. Now the pit into which Ishmael had cast all the dead bodies of the men whom he had slain, because of Gedaliah, was the same one Asa the king had made for fear of Baasha king of Israel. Ishmael the son of Nethaniah filled it with the slain.

10. Then Ishmael carried away captive all the rest of the people who were in Mizpah, the king's daughters and all the people who remained in Mizpah, whom Nebuzaradan the captain of the guard had committed to Gedaliah the son of Ahikam. And Ishmael the son of Nethaniah carried them away captive and departed to go over to the Ammonites.

11. But when Johanan the son of Kareah and all the captains of the forces that were with him heard of all the evil that Ishmael the son of Nethaniah had done,

12. they took all the men and went to fight with Ishmael the son of Nethaniah; and they found him by the great pool that is in Gibeon.

13. So it was, when all the people who were with Ishmael saw Johanan the son of Kareah, and all the captains of the forces who were with him, that they were glad.

14. Then all the people whom Ishmael had carried away captive from Mizpah turned around and came back, and went to Johanan the son of Kareah.

15. But Ishmael the son of Nethaniah escaped from Johanan with eight men and went to the Ammonites.

16. Then Johanan the son of Kareah, and all the captains of the forces that were with him, took from Mizpah all the rest of the people whom he had recovered from Ishmael the son of Nethaniah after he had murdered Gedaliah the son of Ahikam--the mighty men of war and the women and the children and the eunuchs, whom he had brought back from Gibeon.

17. And they departed and dwelt in the habitation of Chimham, which is near Bethlehem, as they went on their way to Egypt,

18. because of the Chaldeans; for they were afraid of them, because Ishmael the son of Nethaniah had murdered Gedaliah the son of Ahikam, whom the king of Babylon had made governor in the land.

## Chapter 42

1. Now all the captains of the forces, Johanan the son of Kareah, Jezaniah the son of Hoshaiah, and all the people, from the least to the greatest, came near

2. and said to Jeremiah the prophet, "Please, let our petition be acceptable to you, and pray for us to the LORD your God, for all this remnant (since we are left but a few of many, as you can see),

3. that the LORD your God may show us the way in which we should walk and the thing we should do."

4. Then Jeremiah the prophet said to them, "I have heard. Indeed, I will pray to the LORD your God according to your words, and it shall be, that whatever the LORD answers you, I will declare it to you. I will keep nothing back from you."

5. So they said to Jeremiah, "Let the LORD be a true and faithful witness between us, if we do not do according to everything which the LORD your God sends us by you.

6. Whether it is pleasing or displeasing, we will obey the voice of the LORD our God to whom we send you, that it may be well with us when we obey the voice of the LORD our God."

7. And it happened after ten days that the word of the LORD came to Jeremiah.

8. Then he called Johanan the son of Kareah, all the captains of the forces which were with him, and all the people from the least even to the greatest,

9. and said to them, "Thus says the LORD, the God of Israel, to whom you sent me to present your petition before Him:

10. "If you will still remain in this land, then I will build you and not pull you down, and I will plant you and not pluck you up. For I relent concerning the disaster that I have brought upon you.

11. Do not be afraid of the king of Babylon, of whom you are afraid; do not be afraid of him,' says the LORD, "for I am with you, to save you and deliver you from his hand.

12. And I will show you mercy, that he may have mercy on you and cause you to return to your own land.'

13. "But if you say, "We will not dwell in this land,' disobeying the voice of the LORD your God,

14. saying, "No, but we will go to the land of Egypt where we shall see no war, nor hear the sound of the trumpet, nor be hungry for bread, and there we will dwell'--

15. Then hear now the word of the LORD, O remnant of Judah! Thus says the LORD of hosts, the God of Israel: "If you wholly set your faces to enter Egypt, and go to dwell there,

16. then it shall be that the sword which you feared shall overtake you there in the land of Egypt; the famine of which you were afraid shall follow close after you there in Egypt; and there you shall die.

17. So shall it be with all the men who set their faces to go to Egypt to dwell there. They shall die by the sword, by famine, and by pestilence. And none of them shall remain or escape from the disaster that I will bring upon them.'

18. "For thus says the LORD of hosts, the God of Israel: "As My anger and My fury have been poured out on the inhabitants of Jerusalem, so will My fury be poured out on you when you enter Egypt. And you shall be an oath, an astonishment, a curse, and a reproach; and you shall see this place no more.'

19. "The LORD has said concerning you, O remnant of Judah, "Do not go to Egypt!' Know certainly that I have admonished you this day.

20. For you were hypocrites in your hearts when you sent me to the LORD your God, saying, "Pray for us to the LORD our God, and according to all that the LORD your God says, so declare to us and we will do it.'

21. And I have this day declared it to you, but you have not obeyed the voice of the LORD your God, or anything which He has sent you by me.

22. Now therefore, know certainly that you shall die by the sword, by famine, and by pestilence in the place where you desire to go to dwell."

## Chapter 43

1. Now it happened, when Jeremiah had stopped speaking to all the people all the words of the LORD their God, for which the LORD their God had sent him to them, all these words,

2. that Azariah the son of Hoshaiah, Johanan the son of Kareah, and all the proud men spoke, saying to Jeremiah, "You speak falsely! The LORD our God has not sent you to say, "Do not go to Egypt to dwell there.'

3. But Baruch the son of Neriah has set you against us, to deliver us into the hand of the Chaldeans, that they may put us to death or carry us away captive to Babylon."

4. So Johanan the son of Kareah, all the captains of the forces, and all the people would not obey the voice of the LORD, to remain in the land of Judah.

5. But Johanan the son of Kareah and all the captains of the forces took all the remnant of Judah who had returned to dwell in the land of Judah, from all nations where they had been driven--

6. men, women, children, the king's daughters, and every person whom Nebuzaradan the captain of the guard had left with Gedaliah the son of Ahikam, the son of Shaphan, and Jeremiah the prophet and Baruch the son of Neriah.

7. So they went to the land of Egypt, for they did not obey the voice of the LORD. And they went as far as Tahpanhes.

8. Then the word of the LORD came to Jeremiah in Tahpanhes, saying,

9. "Take large stones in your hand, and hide them in the sight of the men of Judah, in the clay in the brick courtyard which is at the entrance to Pharaoh's house in Tahpanhes;

10. and say to them, "Thus says the LORD of hosts, the God of Israel: "Behold, I will send and bring Nebuchadnezzar the king of Babylon, My servant, and will set his throne above these stones that I have hidden. And he will spread his royal pavilion over them.

11. When he comes, he shall strike the land of Egypt and deliver to death those appointed for death, and to captivity those appointed for captivity, and to the sword those appointed for the sword.

12. I will kindle a fire in the houses of the gods of Egypt, and he shall burn them and carry them away captive. And he shall array himself with the land of Egypt, as a shepherd puts on his garment, and he shall go out from there in peace.

13. He shall also break the sacred pillars of Beth Shemesh that are in the land of Egypt; and the houses of the gods of the Egyptians he shall burn with fire.""'

## Chapter 44

1. The word that came to Jeremiah concerning all the Jews who dwell in the land of Egypt, who dwell at Migdol, at Tahpanhes, at Noph, and in the country of Pathros, saying,

2. "Thus says the LORD of hosts, the God of Israel: "You have seen all the calamity that I have brought on Jerusalem and on all the cities of Judah; and behold, this day they are a desolation, and no one dwells in them,

3. because of their wickedness which they have committed to provoke Me to anger, in that they went to burn incense and to serve other gods whom they did not know, they nor you nor your fathers.

4. However I have sent to you all My servants the prophets, rising early and sending them, saying, "Oh, do not do this abominable thing that I hate!"

5. But they did not listen or incline their ear to turn from their wickedness, to burn no incense to other gods.

6. So My fury and My anger were poured out and kindled in the cities of Judah and in the streets of Jerusalem; and they are wasted and desolate, as it is this day.'

7. "Now therefore, thus says the LORD, the God of hosts, the God of Israel: "Why do you commit this great evil against yourselves, to cut off from you man and woman, child and infant, out of Judah, leaving none to remain,

8. in that you provoke Me to wrath with the works of your hands, burning incense to other gods in the land of Egypt where you have gone to dwell, that you may cut yourselves off and be a curse and a reproach among all the nations of the earth?

9. Have you forgotten the wickedness of your fathers, the wickedness of the kings of Judah, the wickedness of their wives, your own wickedness, and the wickedness of your wives, which they committed in the land of Judah and in the streets of Jerusalem?

10. They have not been humbled, to this day, nor have they feared; they have not walked in My law or in My statutes that I set before you and your fathers.'

11. "Therefore thus says the LORD of hosts, the God of Israel: "Behold, I will set My face against you for catastrophe and for cutting off all Judah.

12. And I will take the remnant of Judah who have set their faces to go into the land of Egypt to dwell there, and they shall all be consumed and fall in the land of Egypt. They shall be consumed by the sword and by famine. They shall die, from the least to the greatest, by the sword and by famine; and they shall be an oath, an astonishment, a curse and a reproach!

13. For I will punish those who dwell in the land of Egypt, as I have punished Jerusalem, by the sword, by famine, and by pestilence,

14. so that none of the remnant of Judah who have gone into the land of Egypt to dwell there shall escape or survive, lest they return to the land of Judah, to which they desire to return and dwell. For none shall return except those who escape."'

15. Then all the men who knew that their wives had burned incense to other gods, with all the women who stood by, a great multitude, and all the people who dwelt in the land of Egypt, in Pathros, answered Jeremiah, saying:

16. "As for the word that you have spoken to us in the name of the LORD, we will not listen to you!

17. But we will certainly do whatever has gone out of our own mouth, to burn incense to the queen of heaven and pour out drink offerings to her, as we have done, we and our fathers, our kings and our princes, in the cities of Judah and in the streets of Jerusalem. For then we had plenty of food, were well-off, and saw no trouble.

18. But since we stopped burning incense to the queen of heaven and pouring out drink offerings to her, we have lacked everything and have been consumed by the sword and by famine."

19. The women also said, "And when we burned incense to the queen of heaven and poured out drink offerings to her, did we make cakes for her, to worship her, and pour out drink offerings to her without our husbands' permission?"

20. Then Jeremiah spoke to all the people--the men, the women, and all the people who had given him that answer--saying:

21. "The incense that you burned in the cities of Judah and in the streets of Jerusalem, you and your fathers, your kings and your princes, and the people of the land, did not the LORD remember them, and did it not come into His mind?

22. So the LORD could no longer bear it, because of the evil of your doings and because of the abominations which you committed. Therefore your land is a desolation, an astonishment, a curse, and without an inhabitant, as it is this day.

23. Because you have burned incense and because you have sinned against the LORD, and have not obeyed the voice of the LORD or walked in His law, in His statutes or in His testimonies, therefore this calamity has happened to you, as at this day."

24. Moreover Jeremiah said to all the people and to all the women, "Hear the word of the LORD, all Judah who are in the land of Egypt!

25. Thus says the LORD of hosts, the God of Israel, saying: "You and your wives have spoken with your mouths and fulfilled with your hands, saying, "We will surely keep our vows that we have made, to burn incense to the queen of heaven and pour out drink offerings to her." You will surely keep your vows and perform your vows!'

26. Therefore hear the word of the LORD, all Judah who dwell in the land of Egypt: "Behold, I have sworn by My great name,' says the LORD, "that My name shall no more be named in the mouth of any man of Judah in all the land of Egypt, saying, "The Lord GOD lives."

27. Behold, I will watch over them for adversity and not for good. And all the men of Judah who are in the land of Egypt shall be consumed by the sword and by famine, until there is an end to them.

28. Yet a small number who escape the sword shall return from the land of Egypt to the land of Judah; and all the remnant of Judah, who have gone to the land of Egypt to dwell there, shall know whose words will stand, Mine or theirs.

29. And this shall be a sign to you,' says the LORD, "that I will punish you in this place, that you may know that My words will surely stand against you for adversity.'

30. "Thus says the LORD: "Behold, I will give Pharaoh Hophra king of Egypt into the hand of his enemies and into the hand of those who seek his life, as I gave Zedekiah king of Judah into the hand of Nebuchadnezzar king of Babylon, his enemy who sought his life."'

## Chapter 45

1. The word that Jeremiah the prophet spoke to Baruch the son of Neriah, when he had written these words in a book at the instruction of Jeremiah, in the fourth year of Jehoiakim the son of Josiah, king of Judah, saying,

2. "Thus says the LORD, the God of Israel, to you, O Baruch:

3. "You said, "Woe is me now! For the LORD has added grief to my sorrow. I fainted in my sighing, and I find no rest."'

4. "Thus you shall say to him, "Thus says the LORD: "Behold, what I have built I will break down, and what I have planted I will pluck up, that is, this whole land.

5. And do you seek great things for yourself? Do not seek them; for behold, I will bring adversity on all flesh," says the LORD. "But I will give your life to you as a prize in all places, wherever you go.""'

## Chapter 46

1. The word of the LORD which came to Jeremiah the prophet against the nations.

2. Against Egypt. Concerning the army of Pharaoh Necho, king of Egypt, which was by the River Euphrates in Carchemish, and which Nebuchadnezzar king of Babylon defeated in the fourth year of Jehoiakim the son of Josiah, king of Judah:

3. "Order the buckler and shield, And draw near to battle!

4. Harness the horses, And mount up, you horsemen! Stand forth with your helmets, Polish the spears, Put on the armor!

5. Why have I seen them dismayed and turned back? Their mighty ones are beaten down; They have speedily fled, And did not look back, For fear was all around," says the LORD.

6. "Do not let the swift flee away, Nor the mighty man escape; They will stumble and fall Toward the north, by the River Euphrates.

7. "Who is this coming up like a flood, Whose waters move like the rivers?

8. Egypt rises up like a flood, And its waters move like the rivers; And he says, "I will go up and cover the earth, I will destroy the city and its inhabitants.'

9. Come up, O horses, and rage, O chariots! And let the mighty men come forth: The Ethiopians and the Libyans who handle the shield, And the Lydians who handle and bend the bow.

10. For this is the day of the Lord GOD of hosts, A day of vengeance, That He may avenge Himself on His adversaries. The sword shall devour; It shall be satiated and made drunk with their blood; For the Lord GOD of hosts has a sacrifice In the north country by the River Euphrates.

11. "Go up to Gilead and take balm, O virgin, the daughter of Egypt; In vain you will use many medicines; You shall not be cured.

12. The nations have heard of your shame, And your cry has filled the land; For the mighty man has stumbled against the mighty; They both have fallen together."

13. The word that the LORD spoke to Jeremiah the prophet, how Nebuchadnezzar king of Babylon would come and strike the land of Egypt.

14. "Declare in Egypt, and proclaim in Migdol; Proclaim in Noph and in Tahpanhes; Say, "Stand fast and prepare yourselves, For the sword devours all around you.'

15. Why are your valiant men swept away? They did not stand Because the LORD drove them away.

16. He made many fall; Yes, one fell upon another. And they said, "Arise! Let us go back to our own people And to the land of our nativity From the oppressing sword.'

17. They cried there, "Pharaoh, king of Egypt, is but a noise. He has passed by the appointed time!'

18. "As I live," says the King, Whose name is the LORD of hosts, "Surely as Tabor is among the mountains And as Carmel by the sea, so he shall come.

19. O you daughter dwelling in Egypt, Prepare yourself to go into captivity! For Noph shall be waste and desolate, without inhabitant.

20. "Egypt is a very pretty heifer, But destruction comes, it comes from the north.

21. Also her mercenaries are in her midst like fat bulls, For they also are turned back, They have fled away together. They did not stand, For the day of their calamity had come upon them, The time of their punishment.

22. Her noise shall go like a serpent, For they shall march with an army And come against her with axes, Like those who chop wood.

23. "They shall cut down her forest," says the LORD, "Though it cannot be searched, Because they are innumerable, And more numerous than grasshoppers.

24. The daughter of Egypt shall be ashamed; She shall be delivered into the hand Of the people of the north."

25. The LORD of hosts, the God of Israel, says: "Behold, I will bring punishment on Amon of No, and Pharaoh and Egypt, with their gods and their kings--Pharaoh and those who trust in him.

26. And I will deliver them into the hand of those who seek their lives, into the hand of Nebuchadnezzar king of Babylon and the hand of his servants. Afterward it shall be inhabited as in the days of old," says the LORD.

27. "But do not fear, O My servant Jacob, And do not be dismayed, O Israel! For behold, I will save you from afar, And your offspring from the land of their captivity; Jacob shall return, have rest and be at ease; No one shall make him afraid.

28. Do not fear, O Jacob My servant," says the LORD, "For I am with you; For I will make a complete end of all the nations To which I have driven you, But I will not make a complete end of you. I will rightly correct you, For I will not leave you wholly unpunished."

## Chapter 47

1. The word of the LORD that came to Jeremiah the prophet against the Philistines, before Pharaoh attacked Gaza.

2. Thus says the LORD: "Behold, waters rise out of the north, And shall be an overflowing flood; They shall overflow the land and all that is in it, The city and those who dwell within; Then the men shall cry, And all the inhabitants of the land shall wail.

3. At the noise of the stamping hooves of his strong horses, At the rushing of his chariots, At the rumbling of his wheels, The fathers will not look back for their children, Lacking courage,

4. Because of the day that comes to plunder all the Philistines, To cut off from Tyre and Sidon every helper who remains; For the LORD shall plunder the Philistines, The remnant of the country of Caphtor.

5. Baldness has come upon Gaza, Ashkelon is cut off With the remnant of their valley. How long will you cut yourself?

6. "O you sword of the LORD, How long until you are quiet? Put yourself up into your scabbard, Rest and be still!

7. How can it be quiet, Seeing the LORD has given it a charge Against Ashkelon and against the seashore? There He has appointed it."

## Chapter 48

1. Against Moab. Thus says the LORD of hosts, the God of Israel: "Woe to Nebo! For it is plundered, Kirjathaim is shamed and taken; The high stronghold is shamed and dismayed--

2. No more praise of Moab. In Heshbon they have devised evil against her: "Come, and let us cut her off as a nation.' You also shall be cut down, O Madmen! The sword shall pursue you;

3. A voice of crying shall be from Horonaim: "Plundering and great destruction!'

4. "Moab is destroyed; Her little ones have caused a cry to be heard;

5. For in the Ascent of Luhith they ascend with continual weeping; For in the descent of Horonaim the enemies have heard a cry of destruction.

6. "Flee, save your lives! And be like the juniper in the wilderness.

7. For because you have trusted in your works and your treasures, You also shall be taken. And Chemosh shall go forth into captivity, His priests and his princes together.

8. And the plunderer shall come against every city; No one shall escape. The valley also shall perish, And the plain shall be destroyed, As the LORD has spoken.

9. "Give wings to Moab, That she may flee and get away; For her cities shall be desolate, Without any to dwell in them.

10. Cursed is he who does the work of the LORD deceitfully, And cursed is he who keeps back his sword from blood.

11. "Moab has been at ease from his youth; He has settled on his dregs, And has not been emptied from vessel to vessel, Nor has he gone into captivity. Therefore his taste remained in him, And his scent has not changed.

12. "Therefore behold, the days are coming," says the LORD, "That I shall send him wine-workers Who will tip him over And empty his vessels And break the bottles.

13. Moab shall be ashamed of Chemosh, As the house of Israel was ashamed of Bethel, their confidence.

14. "How can you say, "We are mighty And strong men for the war'?

15. Moab is plundered and gone up from her cities; Her chosen young men have gone down to the slaughter," says the King, Whose name is the LORD of hosts.

16. "The calamity of Moab is near at hand, And his affliction comes quickly.

17. Bemoan him, all you who are around him; And all you who know his name, Say, "How the strong staff is broken, The beautiful rod!'

18. "O daughter inhabiting Dibon, Come down from your glory, And sit in thirst; For the plunderer of Moab has come against you, He has destroyed your strongholds.

19. O inhabitant of Aroer, Stand by the way and watch; Ask him who flees And her who escapes; Say, "What has happened?'

20. Moab is shamed, for he is broken down. Wail and cry! Tell it in Arnon, that Moab is plundered.

21. "And judgment has come on the plain country: On Holon and Jahzah and Mephaath,

22. On Dibon and Nebo and Beth Diblathaim,

23. On Kirjathaim and Beth Gamul and Beth Meon,

24. On Kerioth and Bozrah, On all the cities of the land of Moab, Far or near.

25. The horn of Moab is cut off, And his arm is broken," says the LORD.

26. "Make him drunk, Because he exalted himself against the LORD. Moab shall wallow in his vomit, And he shall also be in derision.

27. For was not Israel a derision to you? Was he found among thieves? For whenever you speak of him, You shake your head in scorn.

28. You who dwell in Moab, Leave the cities and dwell in the rock, And be like the dove which makes her nest In the sides of the cave's mouth.

29. "We have heard the pride of Moab (He is exceedingly proud), Of his loftiness and arrogance and pride, And of the haughtiness of his heart."

30. "I know his wrath," says the LORD, "But it is not right; His lies have made nothing right.

31. Therefore I will wail for Moab, And I will cry out for all Moab; I will mourn for the men of Kir Heres.

32. O vine of Sibmah! I will weep for you with the weeping of Jazer. Your plants have gone over the sea, They reach to the sea of Jazer. The plunderer has fallen on your summer fruit and your vintage.

33. Joy and gladness are taken From the plentiful field And from the land of Moab; I have caused wine to fail from the winepresses; No one will tread with joyous shouting-- Not joyous shouting!

34. "From the cry of Heshbon to Elealeh and to Jahaz They have uttered their voice, From Zoar to Horonaim, Like a three-year-old heifer; For the waters of Nimrim also shall be desolate.

35. "Moreover," says the LORD, "I will cause to cease in Moab The one who offers sacrifices in the high places And burns incense to his gods.

36. Therefore My heart shall wail like flutes for Moab, And like flutes My heart shall wail For the men of Kir Heres. Therefore the riches they have acquired have perished.

37. "For every head shall be bald, and every beard clipped; On all the hands shall be cuts, and on the loins sackcloth--

38. A general lamentation On all the housetops of Moab, And in its streets; For I have broken Moab like a vessel in which is no pleasure," says the LORD.

39. "They shall wail: "How she is broken down! How Moab has turned her back with shame!' So Moab shall be a derision And a dismay to all those about her."

40. For thus says the LORD: "Behold, one shall fly like an eagle, And spread his wings over Moab.

41. Kerioth is taken, And the strongholds are surprised; The mighty men's hearts in Moab on that day shall be Like the heart of a woman in birth pangs.

42. And Moab shall be destroyed as a people, Because he exalted himself against the LORD.

43. Fear and the pit and the snare shall be upon you, O inhabitant of Moab," says the LORD.

44. "He who flees from the fear shall fall into the pit, And he who gets out of the pit shall be caught in the snare. For upon Moab, upon it I will bring The year of their punishment," says the LORD.

45. "Those who fled stood under the shadow of Heshbon Because of exhaustion. But a fire shall come out of Heshbon, A flame from the midst of Sihon, And shall devour the brow of Moab, The crown of the head of the sons of tumult.

46. Woe to you, O Moab! The people of Chemosh perish; For your sons have been taken captive, And your daughters captive.

47. "Yet I will bring back the captives of Moab In the latter days," says the LORD. Thus far is the judgment of Moab.

## Chapter 49

1. Against the Ammonites. Thus says the LORD: "Has Israel no sons? Has he no heir? Why then does Milcom inherit Gad, And his people dwell in its cities?

2. Therefore behold, the days are coming," says the LORD, "That I will cause to be heard an alarm of war In Rabbah of the Ammonites; It shall be a desolate mound, And her villages shall be burned with fire. Then Israel shall take possession of his inheritance," says the LORD.

3. "Wail, O Heshbon, for Ai is plundered! Cry, you daughters of Rabbah, Gird yourselves with sackcloth! Lament and run to and fro by the walls; For Milcom shall go into captivity With his priests and his princes together.

4. Why do you boast in the valleys, Your flowing valley, O backsliding daughter? Who trusted in her treasures, saying, "Who will come against me?'

5. Behold, I will bring fear upon you," Says the Lord GOD of hosts, "From all those who are around you; You shall be driven out, everyone headlong, And no one will gather those who wander off.

6. But afterward I will bring back The captives of the people of Ammon," says the LORD.

7. Against Edom. Thus says the LORD of hosts: "Is wisdom no more in Teman? Has counsel perished from the prudent? Has their wisdom vanished?

8. Flee, turn back, dwell in the depths, O inhabitants of Dedan! For I will bring the calamity of Esau upon him, The time that I will punish him.

9. If grape-gatherers came to you, Would they not leave some gleaning grapes? If thieves by night, Would they not destroy until they have enough?

10. But I have made Esau bare; I have uncovered his secret places, And he shall not be able to hide himself. His descendants are plundered, His brethren and his neighbors, And he is no more.

11. Leave your fatherless children, I will preserve them alive; And let your widows trust in Me."

12. For thus says the LORD: "Behold, those whose judgment was not to drink of the cup have assuredly drunk. And are you the one who will altogether go unpunished? You shall not go unpunished, but you shall surely drink of it.

13. For I have sworn by Myself," says the LORD, "that Bozrah shall become a desolation, a reproach, a waste, and a curse. And all its cities shall be perpetual wastes."

14. I have heard a message from the LORD, And an ambassador has been sent to the nations: "Gather together, come against her, And rise up to battle!

15. "For indeed, I will make you small among nations, Despised among men.

16. Your fierceness has deceived you, The pride of your heart, O you who dwell in the clefts of the rock, Who hold the height of the hill! Though you make your nest as high as the eagle, I will bring you down from there," says the LORD.

17. "Edom also shall be an astonishment; Everyone who goes by it will be astonished And will hiss at all its plagues.

18. As in the overthrow of Sodom and Gomorrah And their neighbors," says the LORD, "No one shall remain there, Nor shall a son of man dwell in it.

19. "Behold, he shall come up like a lion from the floodplain of the Jordan Against the dwelling place of the strong; But I will suddenly make him run away from her. And who is a chosen man that I may appoint over her? For who is like Me? Who will arraign Me? And who is that shepherd Who will withstand Me?"

20. Therefore hear the counsel of the LORD that He has taken against Edom, And His purposes that He has proposed against the inhabitants of Teman: Surely the least of the flock shall draw them out; Surely He shall make their dwelling places desolate with them.

21. The earth shakes at the noise of their fall; At the cry its noise is heard at the Red Sea.

22. Behold, He shall come up and fly like the eagle, And spread His wings over Bozrah; The heart of the mighty men of Edom in that day shall be Like the heart of a woman in birth pangs.

23. Against Damascus. "Hamath and Arpad are shamed, For they have heard bad news. They are fainthearted; There is trouble on the sea; It cannot be quiet.

24. Damascus has grown feeble; She turns to flee, And fear has seized her. Anguish and sorrows have taken her like a woman in labor.

25. Why is the city of praise not deserted, the city of My joy?

26. Therefore her young men shall fall in her streets, And all the men of war shall be cut off in that day," says the LORD of hosts.

27. "I will kindle a fire in the wall of Damascus, And it shall consume the palaces of Ben-Hadad."

28. Against Kedar and against the kingdoms of Hazor, which Nebuchadnezzar king of Babylon shall strike. Thus says the LORD: "Arise, go up to Kedar, And devastate the men of the East!

29. Their tents and their flocks they shall take away. They shall take for themselves their curtains, All their vessels and their camels; And they shall cry out to them, "Fear is on every side!'

30. "Flee, get far away! Dwell in the depths, O inhabitants of Hazor!" says the LORD. "For Nebuchadnezzar king of Babylon has taken counsel against you, And has conceived a plan against you.

31. "Arise, go up to the wealthy nation that dwells securely," says the LORD, "Which has neither gates nor bars, Dwelling alone.

32. Their camels shall be for booty, And the multitude of their cattle for plunder. I will scatter to all winds those in the farthest corners, And I will bring their calamity from all its sides," says the LORD.

33. "Hazor shall be a dwelling for jackals, a desolation forever; No one shall reside there, Nor son of man dwell in it."

34. The word of the LORD that came to Jeremiah the prophet against Elam, in the beginning of the reign of Zedekiah king of Judah, saying,

35. "Thus says the LORD of hosts: "Behold, I will break the bow of Elam, The foremost of their might.

36. Against Elam I will bring the four winds From the four quarters of heaven, And scatter them toward all those winds; There shall be no nations where the outcasts of Elam will not go.

37. For I will cause Elam to be dismayed before their enemies And before those who seek their life. I will bring disaster upon them, My fierce anger,' says the LORD; "And I will send the sword after them Until I have consumed them.

38. I will set My throne in Elam, And will destroy from there the king and the princes,' says the LORD.

39. "But it shall come to pass in the latter days: I will bring back the captives of Elam,' says the LORD."

## Chapter 50

1. The word that the LORD spoke against Babylon and against the land of the Chaldeans by Jeremiah the prophet.

2. "Declare among the nations, Proclaim, and set up a standard; Proclaim--do not conceal it-- Say, "Babylon is taken, Bel is shamed. Merodach is broken in pieces; Her idols are humiliated, Her images are broken in pieces.'

3. For out of the north a nation comes up against her, Which shall make her land desolate, And no one shall dwell therein. They shall move, they shall depart, Both man and beast.

4. "In those days and in that time," says the LORD, "The children of Israel shall come, They and the children of Judah together; With continual weeping they shall come, And seek the LORD their God.

5. They shall ask the way to Zion, With their faces toward it, saying, "Come and let us join ourselves to the LORD In a perpetual covenant That will not be forgotten.'

6. "My people have been lost sheep. Their shepherds have led them astray; They have turned them away on the mountains. They have gone from mountain to hill; They have forgotten their resting place.

7. All who found them have devoured them; And their adversaries said, "We have not offended, Because they have sinned against the LORD, the habitation of justice, The LORD, the hope of their fathers.'

8. "Move from the midst of Babylon, Go out of the land of the Chaldeans; And be like the rams before the flocks.

9. For behold, I will raise and cause to come up against Babylon An assembly of great nations from the north country, And they shall array themselves against her; From there she shall be captured. Their arrows shall be like those of an expert warrior; None shall return in vain.

10. And Chaldea shall become plunder; All who plunder her shall be satisfied," says the LORD.

11. "Because you were glad, because you rejoiced, You destroyers of My heritage, Because you have grown fat like a heifer threshing grain, And you bellow like bulls,

12. Your mother shall be deeply ashamed; She who bore you shall be ashamed. Behold, the least of the nations shall be a wilderness, A dry land and a desert.

13. Because of the wrath of the LORD She shall not be inhabited, But she shall be wholly desolate. Everyone who goes by Babylon shall be horrified And hiss at all her plagues.

14. "Put yourselves in array against Babylon all around, All you who bend the bow; Shoot at her, spare no arrows, For she has sinned against the LORD.

15. Shout against her all around; She has given her hand, Her foundations have fallen, Her walls are thrown down; For it is the vengeance of the LORD. Take vengeance on her. As she has done, so do to her.

16. Cut off the sower from Babylon, And him who handles the sickle at harvest time. For fear of the oppressing sword Everyone shall turn to his own people, And everyone shall flee to his own land.

17. "Israel is like scattered sheep; The lions have driven him away. First the king of Assyria devoured him; Now at last this Nebuchadnezzar king of Babylon has broken his bones."

18. Therefore thus says the LORD of hosts, the God of Israel: "Behold, I will punish the king of Babylon and his land, As I have punished the king of Assyria.

19. But I will bring back Israel to his home, And he shall feed on Carmel and Bashan; His soul shall be satisfied on Mount Ephraim and Gilead.

20. In those days and in that time," says the LORD, "The iniquity of Israel shall be sought, but there shall be none; And the sins of Judah, but they shall not be found; For I will pardon those whom I preserve.

21. "Go up against the land of Merathaim, against it, And against the inhabitants of Pekod. Waste and utterly destroy them," says the LORD, "And do according to all that I have commanded you.

22. A sound of battle is in the land, And of great destruction.

23. How the hammer of the whole earth has been cut apart and broken! How Babylon has become a desolation among the nations! I have laid a snare for you;

24. You have indeed been trapped, O Babylon, And you were not aware; You have been found and also caught, Because you have contended against the LORD.

25. The LORD has opened His armory, And has brought out the weapons of His indignation; For this is the work of the Lord GOD of hosts In the land of the Chaldeans.

26. Come against her from the farthest border; Open her storehouses; Cast her up as heaps of ruins, And destroy her utterly; Let nothing of her be left.

27. Slay all her bulls, Let them go down to the slaughter. Woe to them! For their day has come, the time of their punishment.

28. The voice of those who flee and escape from the land of Babylon Declares in Zion the vengeance of the LORD our God, The vengeance of His temple.

29. "Call together the archers against Babylon. All you who bend the bow, encamp against it all around; Let none of them escape. Repay her according to her work; According to all she has done, do to her; For she has been proud against the LORD, Against the Holy One of Israel.

30. Therefore her young men shall fall in the streets, And all her men of war shall be cut off in that day," says the LORD.

31. "Behold, I am against you, O most haughty one!" says the Lord GOD of hosts; "For your day has come, The time that I will punish you.

32. The most proud shall stumble and fall, And no one will raise him up; I will kindle a fire in his cities, And it will devour all around him."

33. Thus says the LORD of hosts: "The children of Israel were oppressed, Along with the children of Judah; All who took them captive have held them fast; They have refused to let them go.

34. Their Redeemer is strong; The LORD of hosts is His name. He will thoroughly plead their case, That He may give rest to the land, And disquiet the inhabitants of Babylon.

35. "A sword is against the Chaldeans," says the LORD, "Against the inhabitants of Babylon, And against her princes and her wise men.

36. A sword is against the soothsayers, and they will be fools. A sword is against her mighty men, and they will be dismayed.

37. A sword is against their horses, Against their chariots, And against all the mixed peoples who are in her midst; And they will become like women. A sword is against her treasures, and they will be robbed.

38. A drought is against her waters, and they will be dried up. For it is the land of carved images, And they are insane with their idols.

39. "Therefore the wild desert beasts shall dwell there with the jackals, And the ostriches shall dwell in it. It shall be inhabited no more forever, Nor shall it be dwelt in from generation to generation.

40. As God overthrew Sodom and Gomorrah And their neighbors," says the LORD, "So no one shall reside there, Nor son of man dwell in it.

41. "Behold, a people shall come from the north, And a great nation and many kings Shall be raised up from the ends of the earth.

42. They shall hold the bow and the lance; They are cruel and shall not show mercy. Their voice shall roar like the sea; They shall ride on horses, Set in array, like a man for the battle, Against you, O daughter of Babylon.

43. "The king of Babylon has heard the report about them, And his hands grow feeble; Anguish has taken hold of him, Pangs as of a woman in childbirth.

44. "Behold, he shall come up like a lion from the floodplain of the Jordan Against the dwelling place of the strong; But I will make them suddenly run away from her. And who is a chosen man that I may appoint over her? For who is like Me? Who will arraign Me? And who is that shepherd Who will withstand Me?"

45. Therefore hear the counsel of the LORD that He has taken against Babylon, And His purposes that He has proposed against the land of the Chaldeans: Surely the least of the flock shall draw them out; Surely He will make their dwelling place desolate with them.

46. At the noise of the taking of Babylon The earth trembles, And the cry is heard among the nations.

## Chapter 51

1. Thus says the LORD: "Behold, I will raise up against Babylon, Against those who dwell in Leb Kamai, A destroying wind.

2. And I will send winnowers to Babylon, Who shall winnow her and empty her land. For in the day of doom They shall be against her all around.

3. Against her let the archer bend his bow, And lift himself up against her in his armor. Do not spare her young men; Utterly destroy all her army.

4. Thus the slain shall fall in the land of the Chaldeans, And those thrust through in her streets.

5. For Israel is not forsaken, nor Judah, By his God, the LORD of hosts, Though their land was filled with sin against the Holy One of Israel."

6. Flee from the midst of Babylon, And every one save his life! Do not be cut off in her iniquity, For this is the time of the LORD's vengeance; He shall recompense her.

7. Babylon was a golden cup in the LORD's hand, That made all the earth drunk. The nations drank her wine; Therefore the nations are deranged.

8. Babylon has suddenly fallen and been destroyed. Wail for her! Take balm for her pain; Perhaps she may be healed.

9. We would have healed Babylon, But she is not healed. Forsake her, and let us go everyone to his own country; For her judgment reaches to heaven and is lifted up to the skies.

10. The LORD has revealed our righteousness. Come and let us declare in Zion the work of the LORD our God.

11. Make the arrows bright! Gather the shields! The LORD has raised up the spirit of the kings of the Medes. For His plan is against Babylon to destroy it, Because it is the vengeance of the LORD, The vengeance for His temple.

12. Set up the standard on the walls of Babylon; Make the guard strong, Set up the watchmen, Prepare the ambushes. For the LORD has both devised and done What He spoke against the inhabitants of Babylon.

13. O you who dwell by many waters, Abundant in treasures, Your end has come, The measure of your covetousness.

14. The LORD of hosts has sworn by Himself: "Surely I will fill you with men, as with locusts, And they shall lift up a shout against you."

15. He has made the earth by His power; He has established the world by His wisdom, And stretched out the heaven by His understanding.

16. When He utters His voice-- There is a multitude of waters in the heavens: "He causes the vapors to ascend from the ends of the earth; He makes lightnings for the rain; He brings the wind out of His treasuries."

17. Everyone is dull-hearted, without knowledge; Every metalsmith is put to shame by the carved image; For his molded image is falsehood, And there is no breath in them.

18. They are futile, a work of errors; In the time of their punishment they shall perish.

19. The Portion of Jacob is not like them, For He is the Maker of all things; And Israel is the tribe of His inheritance. The LORD of hosts is His name.

20. "You are My battle-ax and weapons of war: For with you I will break the nation in pieces; With you I will destroy kingdoms;

21. With you I will break in pieces the horse and its rider; With you I will break in pieces the chariot and its rider;

22. With you also I will break in pieces man and woman; With you I will break in pieces old and young; With you I will break in pieces the young man and the maiden;

23. With you also I will break in pieces the shepherd and his flock; With you I will break in pieces the farmer and his yoke of oxen; And with you I will break in pieces governors and rulers.

24. "And I will repay Babylon And all the inhabitants of Chaldea For all the evil they have done In Zion in your sight," says the LORD.

25. "Behold, I am against you, O destroying mountain, Who destroys all the earth," says the LORD. "And I will stretch out My hand against you, Roll you down from the rocks, And make you a burnt mountain.

26. They shall not take from you a stone for a corner Nor a stone for a foundation, But you shall be desolate forever," says the LORD.

27. Set up a banner in the land, Blow the trumpet among the nations! Prepare the nations against her, Call the kingdoms together against her: Ararat, Minni, and Ashkenaz. Appoint a general against her; Cause the horses to come up like the bristling locusts.

28. Prepare against her the nations, With the kings of the Medes, Its governors and all its rulers, All the land of his dominion.

29. And the land will tremble and sorrow; For every purpose of the LORD shall be performed against Babylon, To make the land of Babylon a desolation without inhabitant.

30. The mighty men of Babylon have ceased fighting, They have remained in their strongholds; Their might has failed, They became like women; They have burned her dwelling places, The bars of her gate are broken.

31. One runner will run to meet another, And one messenger to meet another, To show the king of Babylon that his city is taken on all sides;

32. The passages are blocked, The reeds they have burned with fire, And the men of war are terrified.

33. For thus says the LORD of hosts, the God of Israel: "The daughter of Babylon is like a threshing floor When it is time to thresh her; Yet a little while And the time of her harvest will come."

34. "Nebuchadnezzar the king of Babylon Has devoured me, he has crushed me; He has made me an empty vessel, He has swallowed me up like a monster; He has filled his stomach with my delicacies, He has spit me out.

35. Let the violence done to me and my flesh be upon Babylon," The inhabitant of Zion will say; "And my blood be upon the inhabitants of Chaldea!" Jerusalem will say.

36. Therefore thus says the LORD: "Behold, I will plead your case and take vengeance for you. I will dry up her sea and make her springs dry.

37. Babylon shall become a heap, A dwelling place for jackals, An astonishment and a hissing, Without an inhabitant.

38. They shall roar together like lions, They shall growl like lions' whelps.

39. In their excitement I will prepare their feasts; I will make them drunk, That they may rejoice, And sleep a perpetual sleep And not awake," says the LORD.

40. "I will bring them down Like lambs to the slaughter, Like rams with male goats.

41. "Oh, how Sheshach is taken! Oh, how the praise of the whole earth is seized! How Babylon has become desolate among the nations!

42. The sea has come up over Babylon; She is covered with the multitude of its waves.

43. Her cities are a desolation, A dry land and a wilderness, A land where no one dwells, Through which no son of man passes.

44. I will punish Bel in Babylon, And I will bring out of his mouth what he has swallowed; And the nations shall not stream to him anymore. Yes, the wall of Babylon shall fall.

45. "My people, go out of the midst of her! And let everyone deliver himself from the fierce anger of the LORD.

46. And lest your heart faint, And you fear for the rumor that will be heard in the land (A rumor will come one year, And after that, in another year A rumor will come, And violence in the land, Ruler against ruler),

47. Therefore behold, the days are coming That I will bring judgment on the carved images of Babylon; Her whole land shall be ashamed, And all her slain shall fall in her midst.

48. Then the heavens and the earth and all that is in them Shall sing joyously over Babylon; For the plunderers shall come to her from the north," says the LORD.

49. As Babylon has caused the slain of Israel to fall, So at Babylon the slain of all the earth shall fall.

50. You who have escaped the sword, Get away! Do not stand still! Remember the LORD afar off, And let Jerusalem come to your mind.

51. We are ashamed because we have heard reproach. Shame has covered our faces, For strangers have come into the sanctuaries of the LORD's house.

52. "Therefore behold, the days are coming," says the LORD, "That I will bring judgment on her carved images, And throughout all her land the wounded shall groan.

53. Though Babylon were to mount up to heaven, And though she were to fortify the height of her strength, Yet from Me plunderers would come to her," says the LORD.

54. The sound of a cry comes from Babylon, And great destruction from the land of the Chaldeans,

55. Because the LORD is plundering Babylon And silencing her loud voice, Though her waves roar like great waters, And the noise of their voice is uttered,

56. Because the plunderer comes against her, against Babylon, And her mighty men are taken. Every one of their bows is broken; For the LORD is the God of recompense, He will surely repay.

57. "And I will make drunk Her princes and wise men, Her governors, her deputies, and her mighty men. And they shall sleep a perpetual sleep And not awake," says the King, Whose name is the LORD of hosts.

58. Thus says the LORD of hosts: "The broad walls of Babylon shall be utterly broken, And her high gates shall be burned with fire; The people will labor in vain, And the nations, because of the fire; And they shall be weary."

59. The word which Jeremiah the prophet commanded Seraiah the son of Neriah, the son of Mahseiah, when he went with Zedekiah the king of Judah to Babylon in the fourth year of his reign. And Seraiah was the quartermaster.

60. So Jeremiah wrote in a book all the evil that would come upon Babylon, all these words that are written against Babylon.

61. And Jeremiah said to Seraiah, "When you arrive in Babylon and see it, and read all these words,

62. then you shall say, "O LORD, You have spoken against this place to cut it off, so that none shall remain in it, neither man nor beast, but it shall be desolate forever.'

63. Now it shall be, when you have finished reading this book, that you shall tie a stone to it and throw it out into the Euphrates.

64. Then you shall say, "Thus Babylon shall sink and not rise from the catastrophe that I will bring upon her. And they shall be weary."' Thus far are the words of Jeremiah.

## Chapter 52

1. Zedekiah was twenty-one years old when he became king, and he reigned eleven years in Jerusalem. His mother's name was Hamutal the daughter of Jeremiah of Libnah.

2. He also did evil in the sight of the LORD, according to all that Jehoiakim had done.

3. For because of the anger of the LORD this happened in Jerusalem and Judah, till He finally cast them out from His presence. Then Zedekiah rebelled against the king of Babylon.

4. Now it came to pass in the ninth year of his reign, in the tenth month, on the tenth day of the month, that Nebuchadnezzar king of Babylon and all his army came against Jerusalem and encamped against it; and they built a siege wall against it all around.

5. So the city was besieged until the eleventh year of King Zedekiah.

6. By the fourth month, on the ninth day of the month, the famine had become so severe in the city that there was no food for the people of the land.

7. Then the city wall was broken through, and all the men of war fled and went out of the city at night by way of the gate between the two walls, which was by the king's garden, even though the Chaldeans were near the city all around. And they went by way of the plain.

8. But the army of the Chaldeans pursued the king, and they overtook Zedekiah in the plains of Jericho. All his army was scattered from him.

9. So they took the king and brought him up to the king of Babylon at Riblah in the land of Hamath, and he pronounced judgment on him.

10. Then the king of Babylon killed the sons of Zedekiah before his eyes. And he killed all the princes of Judah in Riblah.

11. He also put out the eyes of Zedekiah; and the king of Babylon bound him in bronze fetters, took him to Babylon, and put him in prison till the day of his death.

12. Now in the fifth month, on the tenth day of the month (which was the nineteenth year of King Nebuchadnezzar king of Babylon), Nebuzaradan, the captain of the guard, who served the king of Babylon, came to Jerusalem.

13. He burned the house of the LORD and the king's house; all the houses of Jerusalem, that is, all the houses of the great, he burned with fire.

14. And all the army of the Chaldeans who were with the captain of the guard broke down all the walls of Jerusalem all around.

15. Then Nebuzaradan the captain of the guard carried away captive some of the poor people, the rest of the people who remained in the city, the defectors who had deserted to the king of Babylon, and the rest of the craftsmen.

16. But Nebuzaradan the captain of the guard left some of the poor of the land as vinedressers and farmers.

17. The bronze pillars that were in the house of the LORD, and the carts and the bronze Sea that were in the house of the LORD, the Chaldeans broke in pieces, and carried all their bronze to Babylon.

18. They also took away the pots, the shovels, the trimmers, the bowls, the spoons, and all the bronze utensils with which the priests ministered.

19. The basins, the firepans, the bowls, the pots, the lampstands, the spoons, and the cups, whatever was solid gold and whatever was solid silver, the captain of the guard took away.

20. The two pillars, one Sea, the twelve bronze bulls which were under it, and the carts, which King Solomon had made for the house of the LORD--the bronze of all these articles was beyond measure.

21. Now concerning the pillars: the height of one pillar was eighteen cubits, a measuring line of twelve cubits could measure its circumference, and its thickness was four fingers; it was hollow.

22. A capital of bronze was on it; and the height of one capital was five cubits, with a network and pomegranates all around the capital, all of bronze. The second pillar, with pomegranates was the same.

23. There were ninety-six pomegranates on the sides; all the pomegranates, all around on the network, were one hundred.

24. The captain of the guard took Seraiah the chief priest, Zephaniah the second priest, and the three doorkeepers.

25. He also took out of the city an officer who had charge of the men of war, seven men of the king's close associates who were found in the city, the principal scribe of the army who mustered the people of the land, and sixty men of the people of the land who were found in the midst of the city.

26. And Nebuzaradan the captain of the guard took these and brought them to the king of Babylon at Riblah.

27. Then the king of Babylon struck them and put them to death at Riblah in the land of Hamath. Thus Judah was carried away captive from its own land.

28. These are the people whom Nebuchadnezzar carried away captive: in the seventh year, three thousand and twenty-three Jews;

29. in the eighteenth year of Nebuchadnezzar he carried away captive from Jerusalem eight hundred and thirty-two persons;

30. in the twenty-third year of Nebuchadnezzar, Nebuzaradan the captain of the guard carried away captive of the Jews seven hundred and forty-five persons. All the persons were four thousand six hundred.

31. Now it came to pass in the thirty-seventh year of the captivity of Jehoiachin king of Judah, in the twelfth month, on the twenty-fifth day of the month, that Evil-Merodach king of Babylon, in the first year of his reign, lifted up the head of Jehoiachin king of Judah and brought him out of prison.

32. And he spoke kindly to him and gave him a more prominent seat than those of the kings who were with him in Babylon.

33. So Jehoiachin changed from his prison garments, and he ate bread regularly before the king all the days of his life.

34. And as for his provisions, there was a regular ration given him by the king of Babylon, a portion for each day until the day of his death, all the days of his life.


# joel

## Chapter 1

1. The word of the LORD that came to Joel the son of Pethuel.

2. Hear this, you elders, And give ear, all you inhabitants of the land! Has anything like this happened in your days, Or even in the days of your fathers?

3. Tell your children about it, Let your children tell their children, And their children another generation.

4. What the chewing locust left, the swarming locust has eaten; What the swarming locust left, the crawling locust has eaten; And what the crawling locust left, the consuming locust has eaten.

5. Awake, you drunkards, and weep; And wail, all you drinkers of wine, Because of the new wine, For it has been cut off from your mouth.

6. For a nation has come up against My land, Strong, and without number; His teeth are the teeth of a lion, And he has the fangs of a fierce lion.

7. He has laid waste My vine, And ruined My fig tree; He has stripped it bare and thrown it away; Its branches are made white.

8. Lament like a virgin girded with sackcloth For the husband of her youth.

9. The grain offering and the drink offering Have been cut off from the house of the LORD; The priests mourn, who minister to the LORD.

10. The field is wasted, The land mourns; For the grain is ruined, The new wine is dried up, The oil fails.

11. Be ashamed, you farmers, Wail, you vinedressers, For the wheat and the barley; Because the harvest of the field has perished.

12. The vine has dried up, And the fig tree has withered; The pomegranate tree, The palm tree also, And the apple tree-- All the trees of the field are withered; Surely joy has withered away from the sons of men.

13. Gird yourselves and lament, you priests; Wail, you who minister before the altar; Come, lie all night in sackcloth, You who minister to my God; For the grain offering and the drink offering Are withheld from the house of your God.

14. Consecrate a fast, Call a sacred assembly; Gather the elders And all the inhabitants of the land Into the house of the LORD your God, And cry out to the LORD.

15. Alas for the day! For the day of the LORD is at hand; It shall come as destruction from the Almighty.

16. Is not the food cut off before our eyes, Joy and gladness from the house of our God?

17. The seed shrivels under the clods, Storehouses are in shambles; Barns are broken down, For the grain has withered.

18. How the animals groan! The herds of cattle are restless, Because they have no pasture; Even the flocks of sheep suffer punishment.

19. O LORD, to You I cry out; For fire has devoured the open pastures, And a flame has burned all the trees of the field.

20. The beasts of the field also cry out to You, For the water brooks are dried up, And fire has devoured the open pastures.

## Chapter 2

1. Blow the trumpet in Zion, And sound an alarm in My holy mountain! Let all the inhabitants of the land tremble; For the day of the LORD is coming, For it is at hand:

2. A day of darkness and gloominess, A day of clouds and thick darkness, Like the morning clouds spread over the mountains. A people come, great and strong, The like of whom has never been; Nor will there ever be any such after them, Even for many successive generations.

3. A fire devours before them, And behind them a flame burns; The land is like the Garden of Eden before them, And behind them a desolate wilderness; Surely nothing shall escape them.

4. Their appearance is like the appearance of horses; And like swift steeds, so they run.

5. With a noise like chariots Over mountaintops they leap, Like the noise of a flaming fire that devours the stubble, Like a strong people set in battle array.

6. Before them the people writhe in pain; All faces are drained of color.

7. They run like mighty men, They climb the wall like men of war; Every one marches in formation, And they do not break ranks.

8. They do not push one another; Every one marches in his own column. Though they lunge between the weapons, They are not cut down.

9. They run to and fro in the city, They run on the wall; They climb into the houses, They enter at the windows like a thief.

10. The earth quakes before them, The heavens tremble; The sun and moon grow dark, And the stars diminish their brightness.

11. The LORD gives voice before His army, For His camp is very great; For strong is the One who executes His word. For the day of the LORD is great and very terrible; Who can endure it?

12. "Now, therefore," says the LORD, "Turn to Me with all your heart, With fasting, with weeping, and with mourning."

13. So rend your heart, and not your garments; Return to the LORD your God, For He is gracious and merciful, Slow to anger, and of great kindness; And He relents from doing harm.

14. Who knows if He will turn and relent, And leave a blessing behind Him-- A grain offering and a drink offering For the LORD your God?

15. Blow the trumpet in Zion, Consecrate a fast, Call a sacred assembly;

16. Gather the people, Sanctify the congregation, Assemble the elders, Gather the children and nursing babes; Let the bridegroom go out from his chamber, And the bride from her dressing room.

17. Let the priests, who minister to the LORD, Weep between the porch and the altar; Let them say, "Spare Your people, O LORD, And do not give Your heritage to reproach, That the nations should rule over them. Why should they say among the peoples, "Where is their God?"'

18. Then the LORD will be zealous for His land, And pity His people.

19. The LORD will answer and say to His people, "Behold, I will send you grain and new wine and oil, And you will be satisfied by them; I will no longer make you a reproach among the nations.

20. "But I will remove far from you the northern army, And will drive him away into a barren and desolate land, With his face toward the eastern sea And his back toward the western sea; His stench will come up, And his foul odor will rise, Because he has done monstrous things."

21. Fear not, O land; Be glad and rejoice, For the LORD has done marvelous things!

22. Do not be afraid, you beasts of the field; For the open pastures are springing up, And the tree bears its fruit; The fig tree and the vine yield their strength.

23. Be glad then, you children of Zion, And rejoice in the LORD your God; For He has given you the former rain faithfully, And He will cause the rain to come down for you-- The former rain, And the latter rain in the first month.

24. The threshing floors shall be full of wheat, And the vats shall overflow with new wine and oil.

25. "So I will restore to you the years that the swarming locust has eaten, The crawling locust, The consuming locust, And the chewing locust, My great army which I sent among you.

26. You shall eat in plenty and be satisfied, And praise the name of the LORD your God, Who has dealt wondrously with you; And My people shall never be put to shame.

27. Then you shall know that I am in the midst of Israel: I am the LORD your God And there is no other. My people shall never be put to shame.

28. "And it shall come to pass afterward That I will pour out My Spirit on all flesh; Your sons and your daughters shall prophesy, Your old men shall dream dreams, Your young men shall see visions.

29. And also on My menservants and on My maidservants I will pour out My Spirit in those days.

30. "And I will show wonders in the heavens and in the earth: Blood and fire and pillars of smoke.

31. The sun shall be turned into darkness, And the moon into blood, Before the coming of the great and awesome day of the LORD.

32. And it shall come to pass That whoever calls on the name of the LORD Shall be saved. For in Mount Zion and in Jerusalem there shall be deliverance, As the LORD has said, Among the remnant whom the LORD calls.

## Chapter 3

1. "For behold, in those days and at that time, When I bring back the captives of Judah and Jerusalem,

2. I will also gather all nations, And bring them down to the Valley of Jehoshaphat; And I will enter into judgment with them there On account of My people, My heritage Israel, Whom they have scattered among the nations; They have also divided up My land.

3. They have cast lots for My people, Have given a boy as payment for a harlot, And sold a girl for wine, that they may drink.

4. "Indeed, what have you to do with Me, O Tyre and Sidon, and all the coasts of Philistia? Will you retaliate against Me? But if you retaliate against Me, Swiftly and speedily I will return your retaliation upon your own head;

5. Because you have taken My silver and My gold, And have carried into your temples My prized possessions.

6. Also the people of Judah and the people of Jerusalem You have sold to the Greeks, That you may remove them far from their borders.

7. "Behold, I will raise them Out of the place to which you have sold them, And will return your retaliation upon your own head.

8. I will sell your sons and your daughters Into the hand of the people of Judah, And they will sell them to the Sabeans, To a people far off; For the LORD has spoken."

9. Proclaim this among the nations: "Prepare for war! Wake up the mighty men, Let all the men of war draw near, Let them come up.

10. Beat your plowshares into swords And your pruning hooks into spears; Let the weak say, "I am strong."'

11. Assemble and come, all you nations, And gather together all around. Cause Your mighty ones to go down there, O LORD.

12. "Let the nations be wakened, and come up to the Valley of Jehoshaphat; For there I will sit to judge all the surrounding nations.

13. Put in the sickle, for the harvest is ripe. Come, go down; For the winepress is full, The vats overflow-- For their wickedness is great."

14. Multitudes, multitudes in the valley of decision! For the day of the LORD is near in the valley of decision.

15. The sun and moon will grow dark, And the stars will diminish their brightness.

16. The LORD also will roar from Zion, And utter His voice from Jerusalem; The heavens and earth will shake; But the LORD will be a shelter for His people, And the strength of the children of Israel.

17. "So you shall know that I am the LORD your God, Dwelling in Zion My holy mountain. Then Jerusalem shall be holy, And no aliens shall ever pass through her again."

18. And it will come to pass in that day That the mountains shall drip with new wine, The hills shall flow with milk, And all the brooks of Judah shall be flooded with water; A fountain shall flow from the house of the LORD And water the Valley of Acacias.

19. "Egypt shall be a desolation, And Edom a desolate wilderness, Because of violence against the people of Judah, For they have shed innocent blood in their land.

20. But Judah shall abide forever, And Jerusalem from generation to generation.

21. For I will acquit them of the guilt of bloodshed, whom I had not acquitted; For the LORD dwells in Zion."


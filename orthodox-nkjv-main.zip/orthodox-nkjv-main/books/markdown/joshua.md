# joshua

## Chapter 1

1. After the death of Moses the servant of the LORD, it came to pass that the LORD spoke to Joshua the son of Nun, Moses' assistant, saying:

2. "Moses My servant is dead. Now therefore, arise, go over this Jordan, you and all this people, to the land which I am giving to them--the children of Israel.

3. Every place that the sole of your foot will tread upon I have given you, as I said to Moses.

4. From the wilderness and this Lebanon as far as the great river, the River Euphrates, all the land of the Hittites, and to the Great Sea toward the going down of the sun, shall be your territory.

5. No man shall be able to stand before you all the days of your life; as I was with Moses, so I will be with you. I will not leave you nor forsake you.

6. Be strong and of good courage, for to this people you shall divide as an inheritance the land which I swore to their fathers to give them.

7. Only be strong and very courageous, that you may observe to do according to all the law which Moses My servant commanded you; do not turn from it to the right hand or to the left, that you may prosper wherever you go.

8. This Book of the Law shall not depart from your mouth, but you shall meditate in it day and night, that you may observe to do according to all that is written in it. For then you will make your way prosperous, and then you will have good success.

9. Have I not commanded you? Be strong and of good courage; do not be afraid, nor be dismayed, for the LORD your God is with you wherever you go."

10. Then Joshua commanded the officers of the people, saying,

11. "Pass through the camp and command the people, saying, "Prepare provisions for yourselves, for within three days you will cross over this Jordan, to go in to possess the land which the LORD your God is giving you to possess."'

12. And to the Reubenites, the Gadites, and half the tribe of Manasseh Joshua spoke, saying,

13. "Remember the word which Moses the servant of the LORD commanded you, saying, "The LORD your God is giving you rest and is giving you this land.'

14. Your wives, your little ones, and your livestock shall remain in the land which Moses gave you on this side of the Jordan. But you shall pass before your brethren armed, all your mighty men of valor, and help them,

15. until the LORD has given your brethren rest, as He gave you, and they also have taken possession of the land which the LORD your God is giving them. Then you shall return to the land of your possession and enjoy it, which Moses the LORD's servant gave you on this side of the Jordan toward the sunrise."

16. So they answered Joshua, saying, "All that you command us we will do, and wherever you send us we will go.

17. Just as we heeded Moses in all things, so we will heed you. Only the LORD your God be with you, as He was with Moses.

18. Whoever rebels against your command and does not heed your words, in all that you command him, shall be put to death. Only be strong and of good courage."

## Chapter 2

1. Now Joshua the son of Nun sent out two men from Acacia Grove to spy secretly, saying, "Go, view the land, especially Jericho." So they went, and came to the house of a harlot named Rahab, and lodged there.

2. And it was told the king of Jericho, saying, "Behold, men have come here tonight from the children of Israel to search out the country."

3. So the king of Jericho sent to Rahab, saying, "Bring out the men who have come to you, who have entered your house, for they have come to search out all the country."

4. Then the woman took the two men and hid them. So she said, "Yes, the men came to me, but I did not know where they were from.

5. And it happened as the gate was being shut, when it was dark, that the men went out. Where the men went I do not know; pursue them quickly, for you may overtake them."

6. (But she had brought them up to the roof and hidden them with the stalks of flax, which she had laid in order on the roof.)

7. Then the men pursued them by the road to the Jordan, to the fords. And as soon as those who pursued them had gone out, they shut the gate.

8. Now before they lay down, she came up to them on the roof,

9. and said to the men: "I know that the LORD has given you the land, that the terror of you has fallen on us, and that all the inhabitants of the land are fainthearted because of you.

10. For we have heard how the LORD dried up the water of the Red Sea for you when you came out of Egypt, and what you did to the two kings of the Amorites who were on the other side of the Jordan, Sihon and Og, whom you utterly destroyed.

11. And as soon as we heard these things, our hearts melted; neither did there remain any more courage in anyone because of you, for the LORD your God, He is God in heaven above and on earth beneath.

12. Now therefore, I beg you, swear to me by the LORD, since I have shown you kindness, that you also will show kindness to my father's house, and give me a true token,

13. and spare my father, my mother, my brothers, my sisters, and all that they have, and deliver our lives from death."

14. So the men answered her, "Our lives for yours, if none of you tell this business of ours. And it shall be, when the LORD has given us the land, that we will deal kindly and truly with you."

15. Then she let them down by a rope through the window, for her house was on the city wall; she dwelt on the wall.

16. And she said to them, "Get to the mountain, lest the pursuers meet you. Hide there three days, until the pursuers have returned. Afterward you may go your way."

17. So the men said to her: "We will be blameless of this oath of yours which you have made us swear,

18. unless, when we come into the land, you bind this line of scarlet cord in the window through which you let us down, and unless you bring your father, your mother, your brothers, and all your father's household to your own home.

19. So it shall be that whoever goes outside the doors of your house into the street, his blood shall be on his own head, and we will be guiltless. And whoever is with you in the house, his blood shall be on our head if a hand is laid on him.

20. And if you tell this business of ours, then we will be free from your oath which you made us swear."

21. Then she said, "According to your words, so be it." And she sent them away, and they departed. And she bound the scarlet cord in the window.

22. They departed and went to the mountain, and stayed there three days until the pursuers returned. The pursuers sought them all along the way, but did not find them.

23. So the two men returned, descended from the mountain, and crossed over; and they came to Joshua the son of Nun, and told him all that had befallen them.

24. And they said to Joshua, "Truly the LORD has delivered all the land into our hands, for indeed all the inhabitants of the country are fainthearted because of us."

## Chapter 3

1. Then Joshua rose early in the morning; and they set out from Acacia Grove and came to the Jordan, he and all the children of Israel, and lodged there before they crossed over.

2. So it was, after three days, that the officers went through the camp;

3. and they commanded the people, saying, "When you see the ark of the covenant of the LORD your God, and the priests, the Levites, bearing it, then you shall set out from your place and go after it.

4. Yet there shall be a space between you and it, about two thousand cubits by measure. Do not come near it, that you may know the way by which you must go, for you have not passed this way before."

5. And Joshua said to the people, "Sanctify yourselves, for tomorrow the LORD will do wonders among you."

6. Then Joshua spoke to the priests, saying, "Take up the ark of the covenant and cross over before the people." So they took up the ark of the covenant and went before the people.

7. And the LORD said to Joshua, "This day I will begin to exalt you in the sight of all Israel, that they may know that, as I was with Moses, so I will be with you.

8. You shall command the priests who bear the ark of the covenant, saying, "When you have come to the edge of the water of the Jordan, you shall stand in the Jordan."'

9. So Joshua said to the children of Israel, "Come here, and hear the words of the LORD your God."

10. And Joshua said, "By this you shall know that the living God is among you, and that He will without fail drive out from before you the Canaanites and the Hittites and the Hivites and the Perizzites and the Girgashites and the Amorites and the Jebusites:

11. Behold, the ark of the covenant of the Lord of all the earth is crossing over before you into the Jordan.

12. Now therefore, take for yourselves twelve men from the tribes of Israel, one man from every tribe.

13. And it shall come to pass, as soon as the soles of the feet of the priests who bear the ark of the LORD, the Lord of all the earth, shall rest in the waters of the Jordan, that the waters of the Jordan shall be cut off, the waters that come down from upstream, and they shall stand as a heap."

14. So it was, when the people set out from their camp to cross over the Jordan, with the priests bearing the ark of the covenant before the people,

15. and as those who bore the ark came to the Jordan, and the feet of the priests who bore the ark dipped in the edge of the water (for the Jordan overflows all its banks during the whole time of harvest),

16. that the waters which came down from upstream stood still, and rose in a heap very far away at Adam, the city that is beside Zaretan. So the waters that went down into the Sea of the Arabah, the Salt Sea, failed, and were cut off; and the people crossed over opposite Jericho.

17. Then the priests who bore the ark of the covenant of the LORD stood firm on dry ground in the midst of the Jordan; and all Israel crossed over on dry ground, until all the people had crossed completely over the Jordan.

## Chapter 4

1. And it came to pass, when all the people had completely crossed over the Jordan, that the LORD spoke to Joshua, saying:

2. "Take for yourselves twelve men from the people, one man from every tribe,

3. and command them, saying, "Take for yourselves twelve stones from here, out of the midst of the Jordan, from the place where the priests' feet stood firm. You shall carry them over with you and leave them in the lodging place where you lodge tonight."'

4. Then Joshua called the twelve men whom he had appointed from the children of Israel, one man from every tribe;

5. and Joshua said to them: "Cross over before the ark of the LORD your God into the midst of the Jordan, and each one of you take up a stone on his shoulder, according to the number of the tribes of the children of Israel,

6. that this may be a sign among you when your children ask in time to come, saying, "What do these stones mean to you?'

7. Then you shall answer them that the waters of the Jordan were cut off before the ark of the covenant of the LORD; when it crossed over the Jordan, the waters of the Jordan were cut off. And these stones shall be for a memorial to the children of Israel forever."

8. And the children of Israel did so, just as Joshua commanded, and took up twelve stones from the midst of the Jordan, as the LORD had spoken to Joshua, according to the number of the tribes of the children of Israel, and carried them over with them to the place where they lodged, and laid them down there.

9. Then Joshua set up twelve stones in the midst of the Jordan, in the place where the feet of the priests who bore the ark of the covenant stood; and they are there to this day.

10. So the priests who bore the ark stood in the midst of the Jordan until everything was finished that the LORD had commanded Joshua to speak to the people, according to all that Moses had commanded Joshua; and the people hurried and crossed over.

11. Then it came to pass, when all the people had completely crossed over, that the ark of the LORD and the priests crossed over in the presence of the people.

12. And the men of Reuben, the men of Gad, and half the tribe of Manasseh crossed over armed before the children of Israel, as Moses had spoken to them.

13. About forty thousand prepared for war crossed over before the LORD for battle, to the plains of Jericho.

14. On that day the LORD exalted Joshua in the sight of all Israel; and they feared him, as they had feared Moses, all the days of his life.

15. Then the LORD spoke to Joshua, saying,

16. "Command the priests who bear the ark of the Testimony to come up from the Jordan."

17. Joshua therefore commanded the priests, saying, "Come up from the Jordan."

18. And it came to pass, when the priests who bore the ark of the covenant of the LORD had come from the midst of the Jordan, and the soles of the priests' feet touched the dry land, that the waters of the Jordan returned to their place and overflowed all its banks as before.

19. Now the people came up from the Jordan on the tenth day of the first month, and they camped in Gilgal on the east border of Jericho.

20. And those twelve stones which they took out of the Jordan, Joshua set up in Gilgal.

21. Then he spoke to the children of Israel, saying: "When your children ask their fathers in time to come, saying, "What are these stones?'

22. then you shall let your children know, saying, "Israel crossed over this Jordan on dry land';

23. for the LORD your God dried up the waters of the Jordan before you until you had crossed over, as the LORD your God did to the Red Sea, which He dried up before us until we had crossed over,

24. that all the peoples of the earth may know the hand of the LORD, that it is mighty, that you may fear the LORD your God forever."

## Chapter 5

1. So it was, when all the kings of the Amorites who were on the west side of the Jordan, and all the kings of the Canaanites who were by the sea, heard that the LORD had dried up the waters of the Jordan from before the children of Israel until we had crossed over, that their heart melted; and there was no spirit in them any longer because of the children of Israel.

2. At that time the LORD said to Joshua, "Make flint knives for yourself, and circumcise the sons of Israel again the second time."

3. So Joshua made flint knives for himself, and circumcised the sons of Israel at the hill of the foreskins.

4. And this is the reason why Joshua circumcised them: All the people who came out of Egypt who were males, all the men of war, had died in the wilderness on the way, after they had come out of Egypt.

5. For all the people who came out had been circumcised, but all the people born in the wilderness, on the way as they came out of Egypt, had not been circumcised.

6. For the children of Israel walked forty years in the wilderness, till all the people who were men of war, who came out of Egypt, were consumed, because they did not obey the voice of the LORD--to whom the LORD swore that He would not show them the land which the LORD had sworn to their fathers that He would give us, "a land flowing with milk and honey."

7. Then Joshua circumcised their sons whom He raised up in their place; for they were uncircumcised, because they had not been circumcised on the way.

8. So it was, when they had finished circumcising all the people, that they stayed in their places in the camp till they were healed.

9. Then the LORD said to Joshua, "This day I have rolled away the reproach of Egypt from you." Therefore the name of the place is called Gilgal to this day.

10. Now the children of Israel camped in Gilgal, and kept the Passover on the fourteenth day of the month at twilight on the plains of Jericho.

11. And they ate of the produce of the land on the day after the Passover, unleavened bread and parched grain, on the very same day.

12. Then the manna ceased on the day after they had eaten the produce of the land; and the children of Israel no longer had manna, but they ate the food of the land of Canaan that year.

13. And it came to pass, when Joshua was by Jericho, that he lifted his eyes and looked, and behold, a Man stood opposite him with His sword drawn in His hand. And Joshua went to Him and said to Him, "Are You for us or for our adversaries?"

14. So He said, "No, but as Commander of the army of the LORD I have now come." And Joshua fell on his face to the earth and worshiped, and said to Him, "What does my Lord say to His servant?"

15. Then the Commander of the LORD's army said to Joshua, "Take your sandal off your foot, for the place where you stand is holy." And Joshua did so.

## Chapter 6

1. Now Jericho was securely shut up because of the children of Israel; none went out, and none came in.

2. And the LORD said to Joshua: "See! I have given Jericho into your hand, its king, and the mighty men of valor.

3. You shall march around the city, all you men of war; you shall go all around the city once. This you shall do six days.

4. And seven priests shall bear seven trumpets of rams' horns before the ark. But the seventh day you shall march around the city seven times, and the priests shall blow the trumpets.

5. It shall come to pass, when they make a long blast with the ram's horn, and when you hear the sound of the trumpet, that all the people shall shout with a great shout; then the wall of the city will fall down flat. And the people shall go up every man straight before him."

6. Then Joshua the son of Nun called the priests and said to them, "Take up the ark of the covenant, and let seven priests bear seven trumpets of rams' horns before the ark of the LORD."

7. And he said to the people, "Proceed, and march around the city, and let him who is armed advance before the ark of the LORD."

8. So it was, when Joshua had spoken to the people, that the seven priests bearing the seven trumpets of rams' horns before the LORD advanced and blew the trumpets, and the ark of the covenant of the LORD followed them.

9. The armed men went before the priests who blew the trumpets, and the rear guard came after the ark, while the priests continued blowing the trumpets.

10. Now Joshua had commanded the people, saying, "You shall not shout or make any noise with your voice, nor shall a word proceed out of your mouth, until the day I say to you, "Shout!' Then you shall shout."

11. So he had the ark of the LORD circle the city, going around it once. Then they came into the camp and lodged in the camp.

12. And Joshua rose early in the morning, and the priests took up the ark of the LORD.

13. Then seven priests bearing seven trumpets of rams' horns before the ark of the LORD went on continually and blew with the trumpets. And the armed men went before them. But the rear guard came after the ark of the LORD, while the priests continued blowing the trumpets.

14. And the second day they marched around the city once and returned to the camp. So they did six days.

15. But it came to pass on the seventh day that they rose early, about the dawning of the day, and marched around the city seven times in the same manner. On that day only they marched around the city seven times.

16. And the seventh time it happened, when the priests blew the trumpets, that Joshua said to the people: "Shout, for the LORD has given you the city!

17. Now the city shall be doomed by the LORD to destruction, it and all who are in it. Only Rahab the harlot shall live, she and all who are with her in the house, because she hid the messengers that we sent.

18. And you, by all means abstain from the accursed things, lest you become accursed when you take of the accursed things, and make the camp of Israel a curse, and trouble it.

19. But all the silver and gold, and vessels of bronze and iron, are consecrated to the LORD; they shall come into the treasury of the LORD."

20. So the people shouted when the priests blew the trumpets. And it happened when the people heard the sound of the trumpet, and the people shouted with a great shout, that the wall fell down flat. Then the people went up into the city, every man straight before him, and they took the city.

21. And they utterly destroyed all that was in the city, both man and woman, young and old, ox and sheep and donkey, with the edge of the sword.

22. But Joshua had said to the two men who had spied out the country, "Go into the harlot's house, and from there bring out the woman and all that she has, as you swore to her."

23. And the young men who had been spies went in and brought out Rahab, her father, her mother, her brothers, and all that she had. So they brought out all her relatives and left them outside the camp of Israel.

24. But they burned the city and all that was in it with fire. Only the silver and gold, and the vessels of bronze and iron, they put into the treasury of the house of the LORD.

25. And Joshua spared Rahab the harlot, her father's household, and all that she had. So she dwells in Israel to this day, because she hid the messengers whom Joshua sent to spy out Jericho.

26. Then Joshua charged them at that time, saying, "Cursed be the man before the LORD who rises up and builds this city Jericho; he shall lay its foundation with his firstborn, and with his youngest he shall set up its gates."

27. So the LORD was with Joshua, and his fame spread throughout all the country.

## Chapter 7

1. But the children of Israel committed a trespass regarding the accursed things, for Achan the son of Carmi, the son of Zabdi, the son of Zerah, of the tribe of Judah, took of the accursed things; so the anger of the LORD burned against the children of Israel.

2. Now Joshua sent men from Jericho to Ai, which is beside Beth Aven, on the east side of Bethel, and spoke to them, saying, "Go up and spy out the country." So the men went up and spied out Ai.

3. And they returned to Joshua and said to him, "Do not let all the people go up, but let about two or three thousand men go up and attack Ai. Do not weary all the people there, for the people of Ai are few."

4. So about three thousand men went up there from the people, but they fled before the men of Ai.

5. And the men of Ai struck down about thirty-six men, for they chased them from before the gate as far as Shebarim, and struck them down on the descent; therefore the hearts of the people melted and became like water.

6. Then Joshua tore his clothes, and fell to the earth on his face before the ark of the LORD until evening, he and the elders of Israel; and they put dust on their heads.

7. And Joshua said, "Alas, Lord GOD, why have You brought this people over the Jordan at all--to deliver us into the hand of the Amorites, to destroy us? Oh, that we had been content, and dwelt on the other side of the Jordan!

8. O Lord, what shall I say when Israel turns its back before its enemies?

9. For the Canaanites and all the inhabitants of the land will hear it, and surround us, and cut off our name from the earth. Then what will You do for Your great name?"

10. So the LORD said to Joshua: "Get up! Why do you lie thus on your face?

11. Israel has sinned, and they have also transgressed My covenant which I commanded them. For they have even taken some of the accursed things, and have both stolen and deceived; and they have also put it among their own stuff.

12. Therefore the children of Israel could not stand before their enemies, but turned their backs before their enemies, because they have become doomed to destruction. Neither will I be with you anymore, unless you destroy the accursed from among you.

13. Get up, sanctify the people, and say, "Sanctify yourselves for tomorrow, because thus says the LORD God of Israel: "There is an accursed thing in your midst, O Israel; you cannot stand before your enemies until you take away the accursed thing from among you."

14. In the morning therefore you shall be brought according to your tribes. And it shall be that the tribe which the LORD takes shall come according to families; and the family which the LORD takes shall come by households; and the household which the LORD takes shall come man by man.

15. Then it shall be that he who is taken with the accursed thing shall be burned with fire, he and all that he has, because he has transgressed the covenant of the LORD, and because he has done a disgraceful thing in Israel."'

16. So Joshua rose early in the morning and brought Israel by their tribes, and the tribe of Judah was taken.

17. He brought the clan of Judah, and he took the family of the Zarhites; and he brought the family of the Zarhites man by man, and Zabdi was taken.

18. Then he brought his household man by man, and Achan the son of Carmi, the son of Zabdi, the son of Zerah, of the tribe of Judah, was taken.

19. Now Joshua said to Achan, "My son, I beg you, give glory to the LORD God of Israel, and make confession to Him, and tell me now what you have done; do not hide it from me."

20. And Achan answered Joshua and said, "Indeed I have sinned against the LORD God of Israel, and this is what I have done:

21. When I saw among the spoils a beautiful Babylonian garment, two hundred shekels of silver, and a wedge of gold weighing fifty shekels, I coveted them and took them. And there they are, hidden in the earth in the midst of my tent, with the silver under it."

22. So Joshua sent messengers, and they ran to the tent; and there it was, hidden in his tent, with the silver under it.

23. And they took them from the midst of the tent, brought them to Joshua and to all the children of Israel, and laid them out before the LORD.

24. Then Joshua, and all Israel with him, took Achan the son of Zerah, the silver, the garment, the wedge of gold, his sons, his daughters, his oxen, his donkeys, his sheep, his tent, and all that he had, and they brought them to the Valley of Achor.

25. And Joshua said, "Why have you troubled us? The LORD will trouble you this day." So all Israel stoned him with stones; and they burned them with fire after they had stoned them with stones.

26. Then they raised over him a great heap of stones, still there to this day. So the LORD turned from the fierceness of His anger. Therefore the name of that place has been called the Valley of Achor to this day.

## Chapter 8

1. Now the LORD said to Joshua: "Do not be afraid, nor be dismayed; take all the people of war with you, and arise, go up to Ai. See, I have given into your hand the king of Ai, his people, his city, and his land.

2. And you shall do to Ai and its king as you did to Jericho and its king. Only its spoil and its cattle you shall take as booty for yourselves. Lay an ambush for the city behind it."

3. So Joshua arose, and all the people of war, to go up against Ai; and Joshua chose thirty thousand mighty men of valor and sent them away by night.

4. And he commanded them, saying: "Behold, you shall lie in ambush against the city, behind the city. Do not go very far from the city, but all of you be ready.

5. Then I and all the people who are with me will approach the city; and it will come about, when they come out against us as at the first, that we shall flee before them.

6. For they will come out after us till we have drawn them from the city, for they will say, "They are fleeing before us as at the first.' Therefore we will flee before them.

7. Then you shall rise from the ambush and seize the city, for the LORD your God will deliver it into your hand.

8. And it will be, when you have taken the city, that you shall set the city on fire. According to the commandment of the LORD you shall do. See, I have commanded you."

9. Joshua therefore sent them out; and they went to lie in ambush, and stayed between Bethel and Ai, on the west side of Ai; but Joshua lodged that night among the people.

10. Then Joshua rose up early in the morning and mustered the people, and went up, he and the elders of Israel, before the people to Ai.

11. And all the people of war who were with him went up and drew near; and they came before the city and camped on the north side of Ai. Now a valley lay between them and Ai.

12. So he took about five thousand men and set them in ambush between Bethel and Ai, on the west side of the city.

13. And when they had set the people, all the army that was on the north of the city, and its rear guard on the west of the city, Joshua went that night into the midst of the valley.

14. Now it happened, when the king of Ai saw it, that the men of the city hurried and rose early and went out against Israel to battle, he and all his people, at an appointed place before the plain. But he did not know that there was an ambush against him behind the city.

15. And Joshua and all Israel made as if they were beaten before them, and fled by the way of the wilderness.

16. So all the people who were in Ai were called together to pursue them. And they pursued Joshua and were drawn away from the city.

17. There was not a man left in Ai or Bethel who did not go out after Israel. So they left the city open and pursued Israel.

18. Then the LORD said to Joshua, "Stretch out the spear that is in your hand toward Ai, for I will give it into your hand." And Joshua stretched out the spear that was in his hand toward the city.

19. So those in ambush arose quickly out of their place; they ran as soon as he had stretched out his hand, and they entered the city and took it, and hurried to set the city on fire.

20. And when the men of Ai looked behind them, they saw, and behold, the smoke of the city ascended to heaven. So they had no power to flee this way or that way, and the people who had fled to the wilderness turned back on the pursuers.

21. Now when Joshua and all Israel saw that the ambush had taken the city and that the smoke of the city ascended, they turned back and struck down the men of Ai.

22. Then the others came out of the city against them; so they were caught in the midst of Israel, some on this side and some on that side. And they struck them down, so that they let none of them remain or escape.

23. But the king of Ai they took alive, and brought him to Joshua.

24. And it came to pass when Israel had made an end of slaying all the inhabitants of Ai in the field, in the wilderness where they pursued them, and when they all had fallen by the edge of the sword until they were consumed, that all the Israelites returned to Ai and struck it with the edge of the sword.

25. So it was that all who fell that day, both men and women, were twelve thousand--all the people of Ai.

26. For Joshua did not draw back his hand, with which he stretched out the spear, until he had utterly destroyed all the inhabitants of Ai.

27. Only the livestock and the spoil of that city Israel took as booty for themselves, according to the word of the LORD which He had commanded Joshua.

28. So Joshua burned Ai and made it a heap forever, a desolation to this day.

29. And the king of Ai he hanged on a tree until evening. And as soon as the sun was down, Joshua commanded that they should take his corpse down from the tree, cast it at the entrance of the gate of the city, and raise over it a great heap of stones that remains to this day.

30. Now Joshua built an altar to the LORD God of Israel in Mount Ebal,

31. as Moses the servant of the LORD had commanded the children of Israel, as it is written in the Book of the Law of Moses: "an altar of whole stones over which no man has wielded an iron tool." And they offered on it burnt offerings to the LORD, and sacrificed peace offerings.

32. And there, in the presence of the children of Israel, he wrote on the stones a copy of the law of Moses, which he had written.

33. Then all Israel, with their elders and officers and judges, stood on either side of the ark before the priests, the Levites, who bore the ark of the covenant of the LORD, the stranger as well as he who was born among them. Half of them were in front of Mount Gerizim and half of them in front of Mount Ebal, as Moses the servant of the LORD had commanded before, that they should bless the people of Israel.

34. And afterward he read all the words of the law, the blessings and the cursings, according to all that is written in the Book of the Law.

35. There was not a word of all that Moses had commanded which Joshua did not read before all the assembly of Israel, with the women, the little ones, and the strangers who were living among them.

## Chapter 9

1. And it came to pass when all the kings who were on this side of the Jordan, in the hills and in the lowland and in all the coasts of the Great Sea toward Lebanon--the Hittite, the Amorite, the Canaanite, the Perizzite, the Hivite, and the Jebusite--heard about it,

2. that they gathered together to fight with Joshua and Israel with one accord.

3. But when the inhabitants of Gibeon heard what Joshua had done to Jericho and Ai,

4. they worked craftily, and went and pretended to be ambassadors. And they took old sacks on their donkeys, old wineskins torn and mended,

5. old and patched sandals on their feet, and old garments on themselves; and all the bread of their provision was dry and moldy.

6. And they went to Joshua, to the camp at Gilgal, and said to him and to the men of Israel, "We have come from a far country; now therefore, make a covenant with us."

7. Then the men of Israel said to the Hivites, "Perhaps you dwell among us; so how can we make a covenant with you?"

8. But they said to Joshua, "We are your servants." And Joshua said to them, "Who are you, and where do you come from?"

9. So they said to him: "From a very far country your servants have come, because of the name of the LORD your God; for we have heard of His fame, and all that He did in Egypt,

10. and all that He did to the two kings of the Amorites who were beyond the Jordan--to Sihon king of Heshbon, and Og king of Bashan, who was at Ashtaroth.

11. Therefore our elders and all the inhabitants of our country spoke to us, saying, "Take provisions with you for the journey, and go to meet them, and say to them, "We are your servants; now therefore, make a covenant with us."'

12. This bread of ours we took hot for our provision from our houses on the day we departed to come to you. But now look, it is dry and moldy.

13. And these wineskins which we filled were new, and see, they are torn; and these our garments and our sandals have become old because of the very long journey."

14. Then the men of Israel took some of their provisions; but they did not ask counsel of the LORD.

15. So Joshua made peace with them, and made a covenant with them to let them live; and the rulers of the congregation swore to them.

16. And it happened at the end of three days, after they had made a covenant with them, that they heard that they were their neighbors who dwelt near them.

17. Then the children of Israel journeyed and came to their cities on the third day. Now their cities were Gibeon, Chephirah, Beeroth, and Kirjath Jearim.

18. But the children of Israel did not attack them, because the rulers of the congregation had sworn to them by the LORD God of Israel. And all the congregation complained against the rulers.

19. Then all the rulers said to all the congregation, "We have sworn to them by the LORD God of Israel; now therefore, we may not touch them.

20. This we will do to them: We will let them live, lest wrath be upon us because of the oath which we swore to them."

21. And the rulers said to them, "Let them live, but let them be woodcutters and water carriers for all the congregation, as the rulers had promised them."

22. Then Joshua called for them, and he spoke to them, saying, "Why have you deceived us, saying, "We are very far from you,' when you dwell near us?

23. Now therefore, you are cursed, and none of you shall be freed from being slaves--woodcutters and water carriers for the house of my God."

24. So they answered Joshua and said, "Because your servants were clearly told that the LORD your God commanded His servant Moses to give you all the land, and to destroy all the inhabitants of the land from before you; therefore we were very much afraid for our lives because of you, and have done this thing.

25. And now, here we are, in your hands; do with us as it seems good and right to do to us."

26. So he did to them, and delivered them out of the hand of the children of Israel, so that they did not kill them.

27. And that day Joshua made them woodcutters and water carriers for the congregation and for the altar of the LORD, in the place which He would choose, even to this day.

## Chapter 10

1. Now it came to pass when Adoni-Zedek king of Jerusalem heard how Joshua had taken Ai and had utterly destroyed it--as he had done to Jericho and its king, so he had done to Ai and its king--and how the inhabitants of Gibeon had made peace with Israel and were among them,

2. that they feared greatly, because Gibeon was a great city, like one of the royal cities, and because it was greater than Ai, and all its men were mighty.

3. Therefore Adoni-Zedek king of Jerusalem sent to Hoham king of Hebron, Piram king of Jarmuth, Japhia king of Lachish, and Debir king of Eglon, saying,

4. "Come up to me and help me, that we may attack Gibeon, for it has made peace with Joshua and with the children of Israel."

5. Therefore the five kings of the Amorites, the king of Jerusalem, the king of Hebron, the king of Jarmuth, the king of Lachish, and the king of Eglon, gathered together and went up, they and all their armies, and camped before Gibeon and made war against it.

6. And the men of Gibeon sent to Joshua at the camp at Gilgal, saying, "Do not forsake your servants; come up to us quickly, save us and help us, for all the kings of the Amorites who dwell in the mountains have gathered together against us."

7. So Joshua ascended from Gilgal, he and all the people of war with him, and all the mighty men of valor.

8. And the LORD said to Joshua, "Do not fear them, for I have delivered them into your hand; not a man of them shall stand before you."

9. Joshua therefore came upon them suddenly, having marched all night from Gilgal.

10. So the LORD routed them before Israel, killed them with a great slaughter at Gibeon, chased them along the road that goes to Beth Horon, and struck them down as far as Azekah and Makkedah.

11. And it happened, as they fled before Israel and were on the descent of Beth Horon, that the LORD cast down large hailstones from heaven on them as far as Azekah, and they died. There were more who died from the hailstones than the children of Israel killed with the sword.

12. Then Joshua spoke to the LORD in the day when the LORD delivered up the Amorites before the children of Israel, and he said in the sight of Israel: "Sun, stand still over Gibeon; And Moon, in the Valley of Aijalon."

13. So the sun stood still, And the moon stopped, Till the people had revenge Upon their enemies. Is this not written in the Book of Jasher? So the sun stood still in the midst of heaven, and did not hasten to go down for about a whole day.

14. And there has been no day like that, before it or after it, that the LORD heeded the voice of a man; for the LORD fought for Israel.

15. Then Joshua returned, and all Israel with him, to the camp at Gilgal.

16. But these five kings had fled and hidden themselves in a cave at Makkedah.

17. And it was told Joshua, saying, "The five kings have been found hidden in the cave at Makkedah."

18. So Joshua said, "Roll large stones against the mouth of the cave, and set men by it to guard them.

19. And do not stay there yourselves, but pursue your enemies, and attack their rear guard. Do not allow them to enter their cities, for the LORD your God has delivered them into your hand."

20. Then it happened, while Joshua and the children of Israel made an end of slaying them with a very great slaughter, till they had finished, that those who escaped entered fortified cities.

21. And all the people returned to the camp, to Joshua at Makkedah, in peace. No one moved his tongue against any of the children of Israel.

22. Then Joshua said, "Open the mouth of the cave, and bring out those five kings to me from the cave."

23. And they did so, and brought out those five kings to him from the cave: the king of Jerusalem, the king of Hebron, the king of Jarmuth, the king of Lachish, and the king of Eglon.

24. So it was, when they brought out those kings to Joshua, that Joshua called for all the men of Israel, and said to the captains of the men of war who went with him, "Come near, put your feet on the necks of these kings." And they drew near and put their feet on their necks.

25. Then Joshua said to them, "Do not be afraid, nor be dismayed; be strong and of good courage, for thus the LORD will do to all your enemies against whom you fight."

26. And afterward Joshua struck them and killed them, and hanged them on five trees; and they were hanging on the trees until evening.

27. So it was at the time of the going down of the sun that Joshua commanded, and they took them down from the trees, cast them into the cave where they had been hidden, and laid large stones against the cave's mouth, which remain until this very day.

28. On that day Joshua took Makkedah, and struck it and its king with the edge of the sword. He utterly destroyed them--all the people who were in it. He let none remain. He also did to the king of Makkedah as he had done to the king of Jericho.

29. Then Joshua passed from Makkedah, and all Israel with him, to Libnah; and they fought against Libnah.

30. And the LORD also delivered it and its king into the hand of Israel; he struck it and all the people who were in it with the edge of the sword. He let none remain in it, but did to its king as he had done to the king of Jericho.

31. Then Joshua passed from Libnah, and all Israel with him, to Lachish; and they encamped against it and fought against it.

32. And the LORD delivered Lachish into the hand of Israel, who took it on the second day, and struck it and all the people who were in it with the edge of the sword, according to all that he had done to Libnah.

33. Then Horam king of Gezer came up to help Lachish; and Joshua struck him and his people, until he left him none remaining.

34. From Lachish Joshua passed to Eglon, and all Israel with him; and they encamped against it and fought against it.

35. They took it on that day and struck it with the edge of the sword; all the people who were in it he utterly destroyed that day, according to all that he had done to Lachish.

36. So Joshua went up from Eglon, and all Israel with him, to Hebron; and they fought against it.

37. And they took it and struck it with the edge of the sword--its king, all its cities, and all the people who were in it; he left none remaining, according to all that he had done to Eglon, but utterly destroyed it and all the people who were in it.

38. Then Joshua returned, and all Israel with him, to Debir; and they fought against it.

39. And he took it and its king and all its cities; they struck them with the edge of the sword and utterly destroyed all the people who were in it. He left none remaining; as he had done to Hebron, so he did to Debir and its king, as he had done also to Libnah and its king.

40. So Joshua conquered all the land: the mountain country and the South and the lowland and the wilderness slopes, and all their kings; he left none remaining, but utterly destroyed all that breathed, as the LORD God of Israel had commanded.

41. And Joshua conquered them from Kadesh Barnea as far as Gaza, and all the country of Goshen, even as far as Gibeon.

42. All these kings and their land Joshua took at one time, because the LORD God of Israel fought for Israel.

43. Then Joshua returned, and all Israel with him, to the camp at Gilgal.

## Chapter 11

1. And it came to pass, when Jabin king of Hazor heard these things, that he sent to Jobab king of Madon, to the king of Shimron, to the king of Achshaph,

2. and to the kings who were from the north, in the mountains, in the plain south of Chinneroth, in the lowland, and in the heights of Dor on the west,

3. to the Canaanites in the east and in the west, the Amorite, the Hittite, the Perizzite, the Jebusite in the mountains, and the Hivite below Hermon in the land of Mizpah.

4. So they went out, they and all their armies with them, as many people as the sand that is on the seashore in multitude, with very many horses and chariots.

5. And when all these kings had met together, they came and camped together at the waters of Merom to fight against Israel.

6. But the LORD said to Joshua, "Do not be afraid because of them, for tomorrow about this time I will deliver all of them slain before Israel. You shall hamstring their horses and burn their chariots with fire."

7. So Joshua and all the people of war with him came against them suddenly by the waters of Merom, and they attacked them.

8. And the LORD delivered them into the hand of Israel, who defeated them and chased them to Greater Sidon, to the Brook Misrephoth, and to the Valley of Mizpah eastward; they attacked them until they left none of them remaining.

9. So Joshua did to them as the LORD had told him: he hamstrung their horses and burned their chariots with fire.

10. Joshua turned back at that time and took Hazor, and struck its king with the sword; for Hazor was formerly the head of all those kingdoms.

11. And they struck all the people who were in it with the edge of the sword, utterly destroying them. There was none left breathing. Then he burned Hazor with fire.

12. So all the cities of those kings, and all their kings, Joshua took and struck with the edge of the sword. He utterly destroyed them, as Moses the servant of the LORD had commanded.

13. But as for the cities that stood on their mounds, Israel burned none of them, except Hazor only, which Joshua burned.

14. And all the spoil of these cities and the livestock, the children of Israel took as booty for themselves; but they struck every man with the edge of the sword until they had destroyed them, and they left none breathing.

15. As the LORD had commanded Moses his servant, so Moses commanded Joshua, and so Joshua did. He left nothing undone of all that the LORD had commanded Moses.

16. Thus Joshua took all this land: the mountain country, all the South, all the land of Goshen, the lowland, and the Jordan plain--the mountains of Israel and its lowlands,

17. from Mount Halak and the ascent to Seir, even as far as Baal Gad in the Valley of Lebanon below Mount Hermon. He captured all their kings, and struck them down and killed them.

18. Joshua made war a long time with all those kings.

19. There was not a city that made peace with the children of Israel, except the Hivites, the inhabitants of Gibeon. All the others they took in battle.

20. For it was of the LORD to harden their hearts, that they should come against Israel in battle, that He might utterly destroy them, and that they might receive no mercy, but that He might destroy them, as the LORD had commanded Moses.

21. And at that time Joshua came and cut off the Anakim from the mountains: from Hebron, from Debir, from Anab, from all the mountains of Judah, and from all the mountains of Israel; Joshua utterly destroyed them with their cities.

22. None of the Anakim were left in the land of the children of Israel; they remained only in Gaza, in Gath, and in Ashdod.

23. So Joshua took the whole land, according to all that the LORD had said to Moses; and Joshua gave it as an inheritance to Israel according to their divisions by their tribes. Then the land rested from war.

## Chapter 12

1. These are the kings of the land whom the children of Israel defeated, and whose land they possessed on the other side of the Jordan toward the rising of the sun, from the River Arnon to Mount Hermon, and all the eastern Jordan plain:

2. One king was Sihon king of the Amorites, who dwelt in Heshbon and ruled half of Gilead, from Aroer, which is on the bank of the River Arnon, from the middle of that river, even as far as the River Jabbok, which is the border of the Ammonites,

3. and the eastern Jordan plain from the Sea of Chinneroth as far as the Sea of the Arabah (the Salt Sea), the road to Beth Jeshimoth, and southward below the slopes of Pisgah.

4. The other king was Og king of Bashan and his territory, who was of the remnant of the giants, who dwelt at Ashtaroth and at Edrei,

5. and reigned over Mount Hermon, over Salcah, over all Bashan, as far as the border of the Geshurites and the Maachathites, and over half of Gilead to the border of Sihon king of Heshbon.

6. These Moses the servant of the LORD and the children of Israel had conquered; and Moses the servant of the LORD had given it as a possession to the Reubenites, the Gadites, and half the tribe of Manasseh.

7. And these are the kings of the country which Joshua and the children of Israel conquered on this side of the Jordan, on the west, from Baal Gad in the Valley of Lebanon as far as Mount Halak and the ascent to Seir, which Joshua gave to the tribes of Israel as a possession according to their divisions,

8. in the mountain country, in the lowlands, in the Jordan plain, in the slopes, in the wilderness, and in the South--the Hittites, the Amorites, the Canaanites, the Perizzites, the Hivites, and the Jebusites:

9. the king of Jericho, one; the king of Ai, which is beside Bethel, one;

10. the king of Jerusalem, one; the king of Hebron, one;

11. the king of Jarmuth, one; the king of Lachish, one;

12. the king of Eglon, one; the king of Gezer, one;

13. the king of Debir, one; the king of Geder, one;

14. the king of Hormah, one; the king of Arad, one;

15. the king of Libnah, one; the king of Adullam, one;

16. the king of Makkedah, one; the king of Bethel, one;

17. the king of Tappuah, one; the king of Hepher, one;

18. the king of Aphek, one; the king of Lasharon, one;

19. the king of Madon, one; the king of Hazor, one;

20. the king of Shimron Meron, one; the king of Achshaph, one;

21. the king of Taanach, one; the king of Megiddo, one;

22. the king of Kedesh, one; the king of Jokneam in Carmel, one;

23. the king of Dor in the heights of Dor, one; the king of the people of Gilgal, one;

24. the king of Tirzah, one--all the kings, thirty-one.

## Chapter 13

1. Now Joshua was old, advanced in years. And the LORD said to him: "You are old, advanced in years, and there remains very much land yet to be possessed.

2. This is the land that yet remains: all the territory of the Philistines and all that of the Geshurites,

3. from Sihor, which is east of Egypt, as far as the border of Ekron northward (which is counted as Canaanite); the five lords of the Philistines--the Gazites, the Ashdodites, the Ashkelonites, the Gittites, and the Ekronites; also the Avites;

4. from the south, all the land of the Canaanites, and Mearah that belongs to the Sidonians as far as Aphek, to the border of the Amorites;

5. the land of the Gebalites, and all Lebanon, toward the sunrise, from Baal Gad below Mount Hermon as far as the entrance to Hamath;

6. all the inhabitants of the mountains from Lebanon as far as the Brook Misrephoth, and all the Sidonians--them I will drive out from before the children of Israel; only divide it by lot to Israel as an inheritance, as I have commanded you.

7. Now therefore, divide this land as an inheritance to the nine tribes and half the tribe of Manasseh."

8. With the other half-tribe the Reubenites and the Gadites received their inheritance, which Moses had given them, beyond the Jordan eastward, as Moses the servant of the LORD had given them:

9. from Aroer which is on the bank of the River Arnon, and the town that is in the midst of the ravine, and all the plain of Medeba as far as Dibon;

10. all the cities of Sihon king of the Amorites, who reigned in Heshbon, as far as the border of the children of Ammon;

11. Gilead, and the border of the Geshurites and Maachathites, all Mount Hermon, and all Bashan as far as Salcah;

12. all the kingdom of Og in Bashan, who reigned in Ashtaroth and Edrei, who remained of the remnant of the giants; for Moses had defeated and cast out these.

13. Nevertheless the children of Israel did not drive out the Geshurites or the Maachathites, but the Geshurites and the Maachathites dwell among the Israelites until this day.

14. Only to the tribe of Levi he had given no inheritance; the sacrifices of the LORD God of Israel made by fire are their inheritance, as He said to them.

15. And Moses had given to the tribe of the children of Reuben an inheritance according to their families.

16. Their territory was from Aroer, which is on the bank of the River Arnon, and the city that is in the midst of the ravine, and all the plain by Medeba;

17. Heshbon and all its cities that are in the plain: Dibon, Bamoth Baal, Beth Baal Meon,

18. Jahaza, Kedemoth, Mephaath,

19. Kirjathaim, Sibmah, Zereth Shahar on the mountain of the valley,

20. Beth Peor, the slopes of Pisgah, and Beth Jeshimoth--

21. all the cities of the plain and all the kingdom of Sihon king of the Amorites, who reigned in Heshbon, whom Moses had struck with the princes of Midian: Evi, Rekem, Zur, Hur, and Reba, who were princes of Sihon dwelling in the country.

22. The children of Israel also killed with the sword Balaam the son of Beor, the soothsayer, among those who were killed by them.

23. And the border of the children of Reuben was the bank of the Jordan. This was the inheritance of the children of Reuben according to their families, the cities and their villages.

24. Moses also had given an inheritance to the tribe of Gad, to the children of Gad according to their families.

25. Their territory was Jazer, and all the cities of Gilead, and half the land of the Ammonites as far as Aroer, which is before Rabbah,

26. and from Heshbon to Ramath Mizpah and Betonim, and from Mahanaim to the border of Debir,

27. and in the valley Beth Haram, Beth Nimrah, Succoth, and Zaphon, the rest of the kingdom of Sihon king of Heshbon, with the Jordan as its border, as far as the edge of the Sea of Chinnereth, on the other side of the Jordan eastward.

28. This is the inheritance of the children of Gad according to their families, the cities and their villages.

29. Moses also had given an inheritance to half the tribe of Manasseh; it was for half the tribe of the children of Manasseh according to their families:

30. Their territory was from Mahanaim, all Bashan, all the kingdom of Og king of Bashan, and all the towns of Jair which are in Bashan, sixty cities;

31. half of Gilead, and Ashtaroth and Edrei, cities of the kingdom of Og in Bashan, were for the children of Machir the son of Manasseh, for half of the children of Machir according to their families.

32. These are the areas which Moses had distributed as an inheritance in the plains of Moab on the other side of the Jordan, by Jericho eastward.

33. But to the tribe of Levi Moses had given no inheritance; the LORD God of Israel was their inheritance, as He had said to them.

## Chapter 14

1. These are the areas which the children of Israel inherited in the land of Canaan, which Eleazar the priest, Joshua the son of Nun, and the heads of the fathers of the tribes of the children of Israel distributed as an inheritance to them.

2. Their inheritance was by lot, as the LORD had commanded by the hand of Moses, for the nine tribes and the half-tribe.

3. For Moses had given the inheritance of the two tribes and the half-tribe on the other side of the Jordan; but to the Levites he had given no inheritance among them.

4. For the children of Joseph were two tribes: Manasseh and Ephraim. And they gave no part to the Levites in the land, except cities to dwell in, with their common-lands for their livestock and their property.

5. As the LORD had commanded Moses, so the children of Israel did; and they divided the land.

6. Then the children of Judah came to Joshua in Gilgal. And Caleb the son of Jephunneh the Kenizzite said to him: "You know the word which the LORD said to Moses the man of God concerning you and me in Kadesh Barnea.

7. I was forty years old when Moses the servant of the LORD sent me from Kadesh Barnea to spy out the land, and I brought back word to him as it was in my heart.

8. Nevertheless my brethren who went up with me made the heart of the people melt, but I wholly followed the LORD my God.

9. So Moses swore on that day, saying, "Surely the land where your foot has trodden shall be your inheritance and your children's forever, because you have wholly followed the LORD my God.'

10. And now, behold, the LORD has kept me alive, as He said, these forty-five years, ever since the LORD spoke this word to Moses while Israel wandered in the wilderness; and now, here I am this day, eighty-five years old.

11. As yet I am as strong this day as on the day that Moses sent me; just as my strength was then, so now is my strength for war, both for going out and for coming in.

12. Now therefore, give me this mountain of which the LORD spoke in that day; for you heard in that day how the Anakim were there, and that the cities were great and fortified. It may be that the LORD will be with me, and I shall be able to drive them out as the LORD said."

13. And Joshua blessed him, and gave Hebron to Caleb the son of Jephunneh as an inheritance.

14. Hebron therefore became the inheritance of Caleb the son of Jephunneh the Kenizzite to this day, because he wholly followed the LORD God of Israel.

15. And the name of Hebron formerly was Kirjath Arba (Arba was the greatest man among the Anakim). Then the land had rest from war.

## Chapter 15

1. So this was the lot of the tribe of the children of Judah according to their families: The border of Edom at the Wilderness of Zin southward was the extreme southern boundary.

2. And their southern border began at the shore of the Salt Sea, from the bay that faces southward.

3. Then it went out to the southern side of the Ascent of Akrabbim, passed along to Zin, ascended on the south side of Kadesh Barnea, passed along to Hezron, went up to Adar, and went around to Karkaa.

4. From there it passed toward Azmon and went out to the Brook of Egypt; and the border ended at the sea. This shall be your southern border.

5. The east border was the Salt Sea as far as the mouth of the Jordan. And the border on the northern quarter began at the bay of the sea at the mouth of the Jordan.

6. The border went up to Beth Hoglah and passed north of Beth Arabah; and the border went up to the stone of Bohan the son of Reuben.

7. Then the border went up toward Debir from the Valley of Achor, and it turned northward toward Gilgal, which is before the Ascent of Adummim, which is on the south side of the valley. The border continued toward the waters of En Shemesh and ended at En Rogel.

8. And the border went up by the Valley of the Son of Hinnom to the southern slope of the Jebusite city (which is Jerusalem). The border went up to the top of the mountain that lies before the Valley of Hinnom westward, which is at the end of the Valley of Rephaim northward.

9. Then the border went around from the top of the hill to the fountain of the water of Nephtoah, and extended to the cities of Mount Ephron. And the border went around to Baalah (which is Kirjath Jearim).

10. Then the border turned westward from Baalah to Mount Seir, passed along to the side of Mount Jearim on the north (which is Chesalon), went down to Beth Shemesh, and passed on to Timnah.

11. And the border went out to the side of Ekron northward. Then the border went around to Shicron, passed along to Mount Baalah, and extended to Jabneel; and the border ended at the sea.

12. The west border was the coastline of the Great Sea. This is the boundary of the children of Judah all around according to their families.

13. Now to Caleb the son of Jephunneh he gave a share among the children of Judah, according to the commandment of the LORD to Joshua, namely, Kirjath Arba, which is Hebron (Arba was the father of Anak).

14. Caleb drove out the three sons of Anak from there: Sheshai, Ahiman, and Talmai, the children of Anak.

15. Then he went up from there to the inhabitants of Debir (formerly the name of Debir was Kirjath Sepher).

16. And Caleb said, "He who attacks Kirjath Sepher and takes it, to him I will give Achsah my daughter as wife."

17. So Othniel the son of Kenaz, the brother of Caleb, took it; and he gave him Achsah his daughter as wife.

18. Now it was so, when she came to him, that she persuaded him to ask her father for a field. So she dismounted from her donkey, and Caleb said to her, "What do you wish?"

19. She answered, "Give me a blessing; since you have given me land in the South, give me also springs of water." So he gave her the upper springs and the lower springs.

20. This was the inheritance of the tribe of the children of Judah according to their families:

21. The cities at the limits of the tribe of the children of Judah, toward the border of Edom in the South, were Kabzeel, Eder, Jagur,

22. Kinah, Dimonah, Adadah,

23. Kedesh, Hazor, Ithnan,

24. Ziph, Telem, Bealoth,

25. Hazor, Hadattah, Kerioth, Hezron (which is Hazor),

26. Amam, Shema, Moladah,

27. Hazar Gaddah, Heshmon, Beth Pelet,

28. Hazar Shual, Beersheba, Bizjothjah,

29. Baalah, Ijim, Ezem,

30. Eltolad, Chesil, Hormah,

31. Ziklag, Madmannah, Sansannah,

32. Lebaoth, Shilhim, Ain, and Rimmon: all the cities are twenty-nine, with their villages.

33. In the lowland: Eshtaol, Zorah, Ashnah,

34. Zanoah, En Gannim, Tappuah, Enam,

35. Jarmuth, Adullam, Socoh, Azekah,

36. Sharaim, Adithaim, Gederah, and Gederothaim: fourteen cities with their villages;

37. Zenan, Hadashah, Migdal Gad,

38. Dilean, Mizpah, Joktheel,

39. Lachish, Bozkath, Eglon,

40. Cabbon, Lahmas, Kithlish,

41. Gederoth, Beth Dagon, Naamah, and Makkedah: sixteen cities with their villages;

42. Libnah, Ether, Ashan,

43. Jiphtah, Ashnah, Nezib,

44. Keilah, Achzib, and Mareshah: nine cities with their villages;

45. Ekron, with its towns and villages;

46. from Ekron to the sea, all that lay near Ashdod, with their villages;

47. Ashdod with its towns and villages, Gaza with its towns and villages--as far as the Brook of Egypt and the Great Sea with its coastline.

48. And in the mountain country: Shamir, Jattir, Sochoh,

49. Dannah, Kirjath Sannah (which is Debir),

50. Anab, Eshtemoh, Anim,

51. Goshen, Holon, and Giloh: eleven cities with their villages;

52. Arab, Dumah, Eshean,

53. Janum, Beth Tappuah, Aphekah,

54. Humtah, Kirjath Arba (which is Hebron), and Zior: nine cities with their villages;

55. Maon, Carmel, Ziph, Juttah,

56. Jezreel, Jokdeam, Zanoah,

57. Kain, Gibeah, and Timnah: ten cities with their villages;

58. Halhul, Beth Zur, Gedor,

59. Maarath, Beth Anoth, and Eltekon: six cities with their villages;

60. Kirjath Baal (which is Kirjath Jearim) and Rabbah: two cities with their villages.

61. In the wilderness: Beth Arabah, Middin, Secacah,

62. Nibshan, the City of Salt, and En Gedi: six cities with their villages.

63. As for the Jebusites, the inhabitants of Jerusalem, the children of Judah could not drive them out; but the Jebusites dwell with the children of Judah at Jerusalem to this day.

## Chapter 16

1. The lot fell to the children of Joseph from the Jordan, by Jericho, to the waters of Jericho on the east, to the wilderness that goes up from Jericho through the mountains to Bethel,

2. then went out from Bethel to Luz, passed along to the border of the Archites at Ataroth,

3. and went down westward to the boundary of the Japhletites, as far as the boundary of Lower Beth Horon to Gezer; and it ended at the sea.

4. So the children of Joseph, Manasseh and Ephraim, took their inheritance.

5. The border of the children of Ephraim, according to their families, was thus: The border of their inheritance on the east side was Ataroth Addar as far as Upper Beth Horon.

6. And the border went out toward the sea on the north side of Michmethath; then the border went around eastward to Taanath Shiloh, and passed by it on the east of Janohah.

7. Then it went down from Janohah to Ataroth and Naarah, reached to Jericho, and came out at the Jordan.

8. The border went out from Tappuah westward to the Brook Kanah, and it ended at the sea. This was the inheritance of the tribe of the children of Ephraim according to their families.

9. The separate cities for the children of Ephraim were among the inheritance of the children of Manasseh, all the cities with their villages.

10. And they did not drive out the Canaanites who dwelt in Gezer; but the Canaanites dwell among the Ephraimites to this day and have become forced laborers.

## Chapter 17

1. There was also a lot for the tribe of Manasseh, for he was the firstborn of Joseph: namely for Machir the firstborn of Manasseh, the father of Gilead, because he was a man of war; therefore he was given Gilead and Bashan.

2. And there was a lot for the rest of the children of Manasseh according to their families: for the children of Abiezer, the children of Helek, the children of Asriel, the children of Shechem, the children of Hepher, and the children of Shemida; these were the male children of Manasseh the son of Joseph according to their families.

3. But Zelophehad the son of Hepher, the son of Gilead, the son of Machir, the son of Manasseh, had no sons, but only daughters. And these are the names of his daughters: Mahlah, Noah, Hoglah, Milcah, and Tirzah.

4. And they came near before Eleazar the priest, before Joshua the son of Nun, and before the rulers, saying, "The LORD commanded Moses to give us an inheritance among our brothers." Therefore, according to the commandment of the LORD, he gave them an inheritance among their father's brothers.

5. Ten shares fell to Manasseh, besides the land of Gilead and Bashan, which were on the other side of the Jordan,

6. because the daughters of Manasseh received an inheritance among his sons; and the rest of Manasseh's sons had the land of Gilead.

7. And the territory of Manasseh was from Asher to Michmethath, that lies east of Shechem; and the border went along south to the inhabitants of En Tappuah.

8. Manasseh had the land of Tappuah, but Tappuah on the border of Manasseh belonged to the children of Ephraim.

9. And the border descended to the Brook Kanah, southward to the brook. These cities of Ephraim are among the cities of Manasseh. The border of Manasseh was on the north side of the brook; and it ended at the sea.

10. Southward it was Ephraim's, northward it was Manasseh's, and the sea was its border. Manasseh's territory was adjoining Asher on the north and Issachar on the east.

11. And in Issachar and in Asher, Manasseh had Beth Shean and its towns, Ibleam and its towns, the inhabitants of Dor and its towns, the inhabitants of En Dor and its towns, the inhabitants of Taanach and its towns, and the inhabitants of Megiddo and its towns--three hilly regions.

12. Yet the children of Manasseh could not drive out the inhabitants of those cities, but the Canaanites were determined to dwell in that land.

13. And it happened, when the children of Israel grew strong, that they put the Canaanites to forced labor, but did not utterly drive them out.

14. Then the children of Joseph spoke to Joshua, saying, "Why have you given us only one lot and one share to inherit, since we are a great people, inasmuch as the LORD has blessed us until now?"

15. So Joshua answered them, "If you are a great people, then go up to the forest country and clear a place for yourself there in the land of the Perizzites and the giants, since the mountains of Ephraim are too confined for you."

16. But the children of Joseph said, "The mountain country is not enough for us; and all the Canaanites who dwell in the land of the valley have chariots of iron, both those who are of Beth Shean and its towns and those who are of the Valley of Jezreel."

17. And Joshua spoke to the house of Joseph--to Ephraim and Manasseh--saying, "You are a great people and have great power; you shall not have only one lot,

18. but the mountain country shall be yours. Although it is wooded, you shall cut it down, and its farthest extent shall be yours; for you shall drive out the Canaanites, though they have iron chariots and are strong."

## Chapter 18

1. Now the whole congregation of the children of Israel assembled together at Shiloh, and set up the tabernacle of meeting there. And the land was subdued before them.

2. But there remained among the children of Israel seven tribes which had not yet received their inheritance.

3. Then Joshua said to the children of Israel: "How long will you neglect to go and possess the land which the LORD God of your fathers has given you?

4. Pick out from among you three men for each tribe, and I will send them; they shall rise and go through the land, survey it according to their inheritance, and come back to me.

5. And they shall divide it into seven parts. Judah shall remain in their territory on the south, and the house of Joseph shall remain in their territory on the north.

6. You shall therefore survey the land in seven parts and bring the survey here to me, that I may cast lots for you here before the LORD our God.

7. But the Levites have no part among you, for the priesthood of the LORD is their inheritance. And Gad, Reuben, and half the tribe of Manasseh have received their inheritance beyond the Jordan on the east, which Moses the servant of the LORD gave them."

8. Then the men arose to go away; and Joshua charged those who went to survey the land, saying, "Go, walk through the land, survey it, and come back to me, that I may cast lots for you here before the LORD in Shiloh."

9. So the men went, passed through the land, and wrote the survey in a book in seven parts by cities; and they came to Joshua at the camp in Shiloh.

10. Then Joshua cast lots for them in Shiloh before the LORD, and there Joshua divided the land to the children of Israel according to their divisions.

11. Now the lot of the tribe of the children of Benjamin came up according to their families, and the territory of their lot came out between the children of Judah and the children of Joseph.

12. Their border on the north side began at the Jordan, and the border went up to the side of Jericho on the north, and went up through the mountains westward; it ended at the Wilderness of Beth Aven.

13. The border went over from there toward Luz, to the side of Luz (which is Bethel) southward; and the border descended to Ataroth Addar, near the hill that lies on the south side of Lower Beth Horon.

14. Then the border extended around the west side to the south, from the hill that lies before Beth Horon southward; and it ended at Kirjath Baal (which is Kirjath Jearim), a city of the children of Judah. This was the west side.

15. The south side began at the end of Kirjath Jearim, and the border extended on the west and went out to the spring of the waters of Nephtoah.

16. Then the border came down to the end of the mountain that lies before the Valley of the Son of Hinnom, which is in the Valley of the Rephaim on the north, descended to the Valley of Hinnom, to the side of the Jebusite city on the south, and descended to En Rogel.

17. And it went around from the north, went out to En Shemesh, and extended toward Geliloth, which is before the Ascent of Adummim, and descended to the stone of Bohan the son of Reuben.

18. Then it passed along toward the north side of Arabah, and went down to Arabah.

19. And the border passed along to the north side of Beth Hoglah; then the border ended at the north bay at the Salt Sea, at the south end of the Jordan. This was the southern boundary.

20. The Jordan was its border on the east side. This was the inheritance of the children of Benjamin, according to its boundaries all around, according to their families.

21. Now the cities of the tribe of the children of Benjamin, according to their families, were Jericho, Beth Hoglah, Emek Keziz,

22. Beth Arabah, Zemaraim, Bethel,

23. Avim, Parah, Ophrah,

24. Chephar Haammoni, Ophni, and Gaba: twelve cities with their villages;

25. Gibeon, Ramah, Beeroth,

26. Mizpah, Chephirah, Mozah,

27. Rekem, Irpeel, Taralah,

28. Zelah, Eleph, Jebus (which is Jerusalem), Gibeath, and Kirjath: fourteen cities with their villages. This was the inheritance of the children of Benjamin according to their families.

## Chapter 19

1. The second lot came out for Simeon, for the tribe of the children of Simeon according to their families. And their inheritance was within the inheritance of the children of Judah.

2. They had in their inheritance Beersheba (Sheba), Moladah,

3. Hazar Shual, Balah, Ezem,

4. Eltolad, Bethul, Hormah,

5. Ziklag, Beth Marcaboth, Hazar Susah,

6. Beth Lebaoth, and Sharuhen: thirteen cities and their villages;

7. Ain, Rimmon, Ether, and Ashan: four cities and their villages;

8. and all the villages that were all around these cities as far as Baalath Beer, Ramah of the South. This was the inheritance of the tribe of the children of Simeon according to their families.

9. The inheritance of the children of Simeon was included in the share of the children of Judah, for the share of the children of Judah was too much for them. Therefore the children of Simeon had their inheritance within the inheritance of that people.

10. The third lot came out for the children of Zebulun according to their families, and the border of their inheritance was as far as Sarid.

11. Their border went toward the west and to Maralah, went to Dabbasheth, and extended along the brook that is east of Jokneam.

12. Then from Sarid it went eastward toward the sunrise along the border of Chisloth Tabor, and went out toward Daberath, bypassing Japhia.

13. And from there it passed along on the east of Gath Hepher, toward Eth Kazin, and extended to Rimmon, which borders on Neah.

14. Then the border went around it on the north side of Hannathon, and it ended in the Valley of Jiphthah El.

15. Included were Kattath, Nahallal, Shimron, Idalah, and Bethlehem: twelve cities with their villages.

16. This was the inheritance of the children of Zebulun according to their families, these cities with their villages.

17. The fourth lot came out to Issachar, for the children of Issachar according to their families.

18. And their territory went to Jezreel, and included Chesulloth, Shunem,

19. Haphraim, Shion, Anaharath,

20. Rabbith, Kishion, Abez,

21. Remeth, En Gannim, En Haddah, and Beth Pazzez.

22. And the border reached to Tabor, Shahazimah, and Beth Shemesh; their border ended at the Jordan: sixteen cities with their villages.

23. This was the inheritance of the tribe of the children of Issachar according to their families, the cities and their villages.

24. The fifth lot came out for the tribe of the children of Asher according to their families.

25. And their territory included Helkath, Hali, Beten, Achshaph,

26. Alammelech, Amad, and Mishal; it reached to Mount Carmel westward, along the Brook Shihor Libnath.

27. It turned toward the sunrise to Beth Dagon; and it reached to Zebulun and to the Valley of Jiphthah El, then northward beyond Beth Emek and Neiel, bypassing Cabul which was on the left,

28. including Ebron, Rehob, Hammon, and Kanah, as far as Greater Sidon.

29. And the border turned to Ramah and to the fortified city of Tyre; then the border turned to Hosah, and ended at the sea by the region of Achzib.

30. Also Ummah, Aphek, and Rehob were included: twenty-two cities with their villages.

31. This was the inheritance of the tribe of the children of Asher according to their families, these cities with their villages.

32. The sixth lot came out to the children of Naphtali, for the children of Naphtali according to their families.

33. And their border began at Heleph, enclosing the territory from the terebinth tree in Zaanannim, Adami Nekeb, and Jabneel, as far as Lakkum; it ended at the Jordan.

34. From Heleph the border extended westward to Aznoth Tabor, and went out from there toward Hukkok; it adjoined Zebulun on the south side and Asher on the west side, and ended at Judah by the Jordan toward the sunrise.

35. And the fortified cities are Ziddim, Zer, Hammath, Rakkath, Chinnereth,

36. Adamah, Ramah, Hazor,

37. Kedesh, Edrei, En Hazor,

38. Iron, Migdal El, Horem, Beth Anath, and Beth Shemesh: nineteen cities with their villages.

39. This was the inheritance of the tribe of the children of Naphtali according to their families, the cities and their villages.

40. The seventh lot came out for the tribe of the children of Dan according to their families.

41. And the territory of their inheritance was Zorah, Eshtaol, Ir Shemesh,

42. Shaalabbin, Aijalon, Jethlah,

43. Elon, Timnah, Ekron,

44. Eltekeh, Gibbethon, Baalath,

45. Jehud, Bene Berak, Gath Rimmon,

46. Me Jarkon, and Rakkon, with the region near Joppa.

47. And the border of the children of Dan went beyond these, because the children of Dan went up to fight against Leshem and took it; and they struck it with the edge of the sword, took possession of it, and dwelt in it. They called Leshem, Dan, after the name of Dan their father.

48. This is the inheritance of the tribe of the children of Dan according to their families, these cities with their villages.

49. When they had made an end of dividing the land as an inheritance according to their borders, the children of Israel gave an inheritance among them to Joshua the son of Nun.

50. According to the word of the LORD they gave him the city which he asked for, Timnath Serah in the mountains of Ephraim; and he built the city and dwelt in it.

51. These were the inheritances which Eleazar the priest, Joshua the son of Nun, and the heads of the fathers of the tribes of the children of Israel divided as an inheritance by lot in Shiloh before the LORD, at the door of the tabernacle of meeting. So they made an end of dividing the country.

## Chapter 20

1. The LORD also spoke to Joshua, saying,

2. "Speak to the children of Israel, saying: "Appoint for yourselves cities of refuge, of which I spoke to you through Moses,

3. that the slayer who kills a person accidentally or unintentionally may flee there; and they shall be your refuge from the avenger of blood.

4. And when he flees to one of those cities, and stands at the entrance of the gate of the city, and declares his case in the hearing of the elders of that city, they shall take him into the city as one of them, and give him a place, that he may dwell among them.

5. Then if the avenger of blood pursues him, they shall not deliver the slayer into his hand, because he struck his neighbor unintentionally, but did not hate him beforehand.

6. And he shall dwell in that city until he stands before the congregation for judgment, and until the death of the one who is high priest in those days. Then the slayer may return and come to his own city and his own house, to the city from which he fled."'

7. So they appointed Kedesh in Galilee, in the mountains of Naphtali, Shechem in the mountains of Ephraim, and Kirjath Arba (which is Hebron) in the mountains of Judah.

8. And on the other side of the Jordan, by Jericho eastward, they assigned Bezer in the wilderness on the plain, from the tribe of Reuben, Ramoth in Gilead, from the tribe of Gad, and Golan in Bashan, from the tribe of Manasseh.

9. These were the cities appointed for all the children of Israel and for the stranger who dwelt among them, that whoever killed a person accidentally might flee there, and not die by the hand of the avenger of blood until he stood before the congregation.

## Chapter 21

1. Then the heads of the fathers' houses of the Levites came near to Eleazar the priest, to Joshua the son of Nun, and to the heads of the fathers' houses of the tribes of the children of Israel.

2. And they spoke to them at Shiloh in the land of Canaan, saying, "The LORD commanded through Moses to give us cities to dwell in, with their common-lands for our livestock."

3. So the children of Israel gave to the Levites from their inheritance, at the commandment of the LORD, these cities and their common-lands:

4. Now the lot came out for the families of the Kohathites. And the children of Aaron the priest, who were of the Levites, had thirteen cities by lot from the tribe of Judah, from the tribe of Simeon, and from the tribe of Benjamin.

5. The rest of the children of Kohath had ten cities by lot from the families of the tribe of Ephraim, from the tribe of Dan, and from the half-tribe of Manasseh.

6. And the children of Gershon had thirteen cities by lot from the families of the tribe of Issachar, from the tribe of Asher, from the tribe of Naphtali, and from the half-tribe of Manasseh in Bashan.

7. The children of Merari according to their families had twelve cities from the tribe of Reuben, from the tribe of Gad, and from the tribe of Zebulun.

8. And the children of Israel gave these cities with their common-lands by lot to the Levites, as the LORD had commanded by the hand of Moses.

9. So they gave from the tribe of the children of Judah and from the tribe of the children of Simeon these cities which are designated by name,

10. which were for the children of Aaron, one of the families of the Kohathites, who were of the children of Levi; for the lot was theirs first.

11. And they gave them Kirjath Arba (Arba was the father of Anak), which is Hebron, in the mountains of Judah, with the common-land surrounding it.

12. But the fields of the city and its villages they gave to Caleb the son of Jephunneh as his possession.

13. Thus to the children of Aaron the priest they gave Hebron with its common-land (a city of refuge for the slayer), Libnah with its common-land,

14. Jattir with its common-land, Eshtemoa with its common-land,

15. Holon with its common-land, Debir with its common-land,

16. Ain with its common-land, Juttah with its common-land, and Beth Shemesh with its common-land: nine cities from those two tribes;

17. and from the tribe of Benjamin, Gibeon with its common-land, Geba with its common-land,

18. Anathoth with its common-land, and Almon with its common-land: four cities.

19. All the cities of the children of Aaron, the priests, were thirteen cities with their common-lands.

20. And the families of the children of Kohath, the Levites, the rest of the children of Kohath, even they had the cities of their lot from the tribe of Ephraim.

21. For they gave them Shechem with its common-land in the mountains of Ephraim (a city of refuge for the slayer), Gezer with its common-land,

22. Kibzaim with its common-land, and Beth Horon with its common-land: four cities;

23. and from the tribe of Dan, Eltekeh with its common-land, Gibbethon with its common-land,

24. Aijalon with its common-land, and Gath Rimmon with its common-land: four cities;

25. and from the half-tribe of Manasseh, Tanach with its common-land and Gath Rimmon with its common-land: two cities.

26. All the ten cities with their common-lands were for the rest of the families of the children of Kohath.

27. Also to the children of Gershon, of the families of the Levites, from the other half-tribe of Manasseh, they gave Golan in Bashan with its common-land (a city of refuge for the slayer), and Be Eshterah with its common-land: two cities;

28. and from the tribe of Issachar, Kishion with its common-land, Daberath with its common-land,

29. Jarmuth with its common-land, and En Gannim with its common-land: four cities;

30. and from the tribe of Asher, Mishal with its common-land, Abdon with its common-land,

31. Helkath with its common-land, and Rehob with its common-land: four cities;

32. and from the tribe of Naphtali, Kedesh in Galilee with its common-land (a city of refuge for the slayer), Hammoth Dor with its common-land, and Kartan with its common-land: three cities.

33. All the cities of the Gershonites according to their families were thirteen cities with their common-lands.

34. And to the families of the children of Merari, the rest of the Levites, from the tribe of Zebulun, Jokneam with its common-land, Kartah with its common-land,

35. Dimnah with its common-land, and Nahalal with its common-land: four cities;

36. and from the tribe of Reuben, Bezer with its common-land, Jahaz with its common-land,

37. Kedemoth with its common-land, and Mephaath with its common-land: four cities;

38. and from the tribe of Gad, Ramoth in Gilead with its common-land (a city of refuge for the slayer), Mahanaim with its common-land,

39. Heshbon with its common-land, and Jazer with its common-land: four cities in all.

40. So all the cities for the children of Merari according to their families, the rest of the families of the Levites, were by their lot twelve cities.

41. All the cities of the Levites within the possession of the children of Israel were forty-eight cities with their common-lands.

42. Every one of these cities had its common-land surrounding it; thus were all these cities.

43. So the LORD gave to Israel all the land of which He had sworn to give to their fathers, and they took possession of it and dwelt in it.

44. The LORD gave them rest all around, according to all that He had sworn to their fathers. And not a man of all their enemies stood against them; the LORD delivered all their enemies into their hand.

45. Not a word failed of any good thing which the LORD had spoken to the house of Israel. All came to pass.

## Chapter 22

1. Then Joshua called the Reubenites, the Gadites, and half the tribe of Manasseh,

2. and said to them: "You have kept all that Moses the servant of the LORD commanded you, and have obeyed my voice in all that I commanded you.

3. You have not left your brethren these many days, up to this day, but have kept the charge of the commandment of the LORD your God.

4. And now the LORD your God has given rest to your brethren, as He promised them; now therefore, return and go to your tents and to the land of your possession, which Moses the servant of the LORD gave you on the other side of the Jordan.

5. But take careful heed to do the commandment and the law which Moses the servant of the LORD commanded you, to love the LORD your God, to walk in all His ways, to keep His commandments, to hold fast to Him, and to serve Him with all your heart and with all your soul."

6. So Joshua blessed them and sent them away, and they went to their tents.

7. Now to half the tribe of Manasseh Moses had given a possession in Bashan, but to the other half of it Joshua gave a possession among their brethren on this side of the Jordan, westward. And indeed, when Joshua sent them away to their tents, he blessed them,

8. and spoke to them, saying, "Return with much riches to your tents, with very much livestock, with silver, with gold, with bronze, with iron, and with very much clothing. Divide the spoil of your enemies with your brethren."

9. So the children of Reuben, the children of Gad, and half the tribe of Manasseh returned, and departed from the children of Israel at Shiloh, which is in the land of Canaan, to go to the country of Gilead, to the land of their possession, which they had obtained according to the word of the LORD by the hand of Moses.

10. And when they came to the region of the Jordan which is in the land of Canaan, the children of Reuben, the children of Gad, and half the tribe of Manasseh built an altar there by the Jordan--a great, impressive altar.

11. Now the children of Israel heard someone say, "Behold, the children of Reuben, the children of Gad, and half the tribe of Manasseh have built an altar on the frontier of the land of Canaan, in the region of the Jordan--on the children of Israel's side."

12. And when the children of Israel heard of it, the whole congregation of the children of Israel gathered together at Shiloh to go to war against them.

13. Then the children of Israel sent Phinehas the son of Eleazar the priest to the children of Reuben, to the children of Gad, and to half the tribe of Manasseh, into the land of Gilead,

14. and with him ten rulers, one ruler each from the chief house of every tribe of Israel; and each one was the head of the house of his father among the divisions of Israel.

15. Then they came to the children of Reuben, to the children of Gad, and to half the tribe of Manasseh, to the land of Gilead, and they spoke with them, saying,

16. "Thus says the whole congregation of the LORD: "What treachery is this that you have committed against the God of Israel, to turn away this day from following the LORD, in that you have built for yourselves an altar, that you might rebel this day against the LORD?

17. Is the iniquity of Peor not enough for us, from which we are not cleansed till this day, although there was a plague in the congregation of the LORD,

18. but that you must turn away this day from following the LORD? And it shall be, if you rebel today against the LORD, that tomorrow He will be angry with the whole congregation of Israel.

19. Nevertheless, if the land of your possession is unclean, then cross over to the land of the possession of the LORD, where the LORD's tabernacle stands, and take possession among us; but do not rebel against the LORD, nor rebel against us, by building yourselves an altar besides the altar of the LORD our God.

20. Did not Achan the son of Zerah commit a trespass in the accursed thing, and wrath fell on all the congregation of Israel? And that man did not perish alone in his iniquity."'

21. Then the children of Reuben, the children of Gad, and half the tribe of Manasseh answered and said to the heads of the divisions of Israel:

22. "The LORD God of gods, the LORD God of gods, He knows, and let Israel itself know--if it is in rebellion, or if in treachery against the LORD, do not save us this day.

23. If we have built ourselves an altar to turn from following the LORD, or if to offer on it burnt offerings or grain offerings, or if to offer peace offerings on it, let the LORD Himself require an account.

24. But in fact we have done it for fear, for a reason, saying, "In time to come your descendants may speak to our descendants, saying, "What have you to do with the LORD God of Israel?

25. For the LORD has made the Jordan a border between you and us, you children of Reuben and children of Gad. You have no part in the LORD." So your descendants would make our descendants cease fearing the LORD.'

26. Therefore we said, "Let us now prepare to build ourselves an altar, not for burnt offering nor for sacrifice,

27. but that it may be a witness between you and us and our generations after us, that we may perform the service of the LORD before Him with our burnt offerings, with our sacrifices, and with our peace offerings; that your descendants may not say to our descendants in time to come, "You have no part in the LORD."'

28. Therefore we said that it will be, when they say this to us or to our generations in time to come, that we may say, "Here is the replica of the altar of the LORD which our fathers made, though not for burnt offerings nor for sacrifices; but it is a witness between you and us.'

29. Far be it from us that we should rebel against the LORD, and turn from following the LORD this day, to build an altar for burnt offerings, for grain offerings, or for sacrifices, besides the altar of the LORD our God which is before His tabernacle."

30. Now when Phinehas the priest and the rulers of the congregation, the heads of the divisions of Israel who were with him, heard the words that the children of Reuben, the children of Gad, and the children of Manasseh spoke, it pleased them.

31. Then Phinehas the son of Eleazar the priest said to the children of Reuben, the children of Gad, and the children of Manasseh, "This day we perceive that the LORD is among us, because you have not committed this treachery against the LORD. Now you have delivered the children of Israel out of the hand of the LORD."

32. And Phinehas the son of Eleazar the priest, and the rulers, returned from the children of Reuben and the children of Gad, from the land of Gilead to the land of Canaan, to the children of Israel, and brought back word to them.

33. So the thing pleased the children of Israel, and the children of Israel blessed God; they spoke no more of going against them in battle, to destroy the land where the children of Reuben and Gad dwelt.

34. The children of Reuben and the children of Gad called the altar, Witness, "For it is a witness between us that the LORD is God."

## Chapter 23

1. Now it came to pass, a long time after the LORD had given rest to Israel from all their enemies round about, that Joshua was old, advanced in age.

2. And Joshua called for all Israel, for their elders, for their heads, for their judges, and for their officers, and said to them: "I am old, advanced in age.

3. You have seen all that the LORD your God has done to all these nations because of you, for the LORD your God is He who has fought for you.

4. See, I have divided to you by lot these nations that remain, to be an inheritance for your tribes, from the Jordan, with all the nations that I have cut off, as far as the Great Sea westward.

5. And the LORD your God will expel them from before you and drive them out of your sight. So you shall possess their land, as the LORD your God promised you.

6. Therefore be very courageous to keep and to do all that is written in the Book of the Law of Moses, lest you turn aside from it to the right hand or to the left,

7. and lest you go among these nations, these who remain among you. You shall not make mention of the name of their gods, nor cause anyone to swear by them; you shall not serve them nor bow down to them,

8. but you shall hold fast to the LORD your God, as you have done to this day.

9. For the LORD has driven out from before you great and strong nations; but as for you, no one has been able to stand against you to this day.

10. One man of you shall chase a thousand, for the LORD your God is He who fights for you, as He promised you.

11. Therefore take careful heed to yourselves, that you love the LORD your God.

12. Or else, if indeed you do go back, and cling to the remnant of these nations--these that remain among you--and make marriages with them, and go in to them and they to you,

13. know for certain that the LORD your God will no longer drive out these nations from before you. But they shall be snares and traps to you, and scourges on your sides and thorns in your eyes, until you perish from this good land which the LORD your God has given you.

14. "Behold, this day I am going the way of all the earth. And you know in all your hearts and in all your souls that not one thing has failed of all the good things which the LORD your God spoke concerning you. All have come to pass for you; not one word of them has failed.

15. Therefore it shall come to pass, that as all the good things have come upon you which the LORD your God promised you, so the LORD will bring upon you all harmful things, until He has destroyed you from this good land which the LORD your God has given you.

16. When you have transgressed the covenant of the LORD your God, which He commanded you, and have gone and served other gods, and bowed down to them, then the anger of the LORD will burn against you, and you shall perish quickly from the good land which He has given you."

## Chapter 24

1. Then Joshua gathered all the tribes of Israel to Shechem and called for the elders of Israel, for their heads, for their judges, and for their officers; and they presented themselves before God.

2. And Joshua said to all the people, "Thus says the LORD God of Israel: "Your fathers, including Terah, the father of Abraham and the father of Nahor, dwelt on the other side of the River in old times; and they served other gods.

3. Then I took your father Abraham from the other side of the River, led him throughout all the land of Canaan, and multiplied his descendants and gave him Isaac.

4. To Isaac I gave Jacob and Esau. To Esau I gave the mountains of Seir to possess, but Jacob and his children went down to Egypt.

5. Also I sent Moses and Aaron, and I plagued Egypt, according to what I did among them. Afterward I brought you out.

6. "Then I brought your fathers out of Egypt, and you came to the sea; and the Egyptians pursued your fathers with chariots and horsemen to the Red Sea.

7. So they cried out to the LORD; and He put darkness between you and the Egyptians, brought the sea upon them, and covered them. And your eyes saw what I did in Egypt. Then you dwelt in the wilderness a long time.

8. And I brought you into the land of the Amorites, who dwelt on the other side of the Jordan, and they fought with you. But I gave them into your hand, that you might possess their land, and I destroyed them from before you.

9. Then Balak the son of Zippor, king of Moab, arose to make war against Israel, and sent and called Balaam the son of Beor to curse you.

10. But I would not listen to Balaam; therefore he continued to bless you. So I delivered you out of his hand.

11. Then you went over the Jordan and came to Jericho. And the men of Jericho fought against you--also the Amorites, the Perizzites, the Canaanites, the Hittites, the Girgashites, the Hivites, and the Jebusites. But I delivered them into your hand.

12. I sent the hornet before you which drove them out from before you, also the two kings of the Amorites, but not with your sword or with your bow.

13. I have given you a land for which you did not labor, and cities which you did not build, and you dwell in them; you eat of the vineyards and olive groves which you did not plant.'

14. "Now therefore, fear the LORD, serve Him in sincerity and in truth, and put away the gods which your fathers served on the other side of the River and in Egypt. Serve the LORD!

15. And if it seems evil to you to serve the LORD, choose for yourselves this day whom you will serve, whether the gods which your fathers served that were on the other side of the River, or the gods of the Amorites, in whose land you dwell. But as for me and my house, we will serve the LORD."

16. So the people answered and said: "Far be it from us that we should forsake the LORD to serve other gods;

17. for the LORD our God is He who brought us and our fathers up out of the land of Egypt, from the house of bondage, who did those great signs in our sight, and preserved us in all the way that we went and among all the people through whom we passed.

18. And the LORD drove out from before us all the people, including the Amorites who dwelt in the land. We also will serve the LORD, for He is our God."

19. But Joshua said to the people, "You cannot serve the LORD, for He is a holy God. He is a jealous God; He will not forgive your transgressions nor your sins.

20. If you forsake the LORD and serve foreign gods, then He will turn and do you harm and consume you, after He has done you good."

21. And the people said to Joshua, "No, but we will serve the LORD!"

22. So Joshua said to the people, "You are witnesses against yourselves that you have chosen the LORD for yourselves, to serve Him." And they said, "We are witnesses!"

23. "Now therefore," he said, "put away the foreign gods which are among you, and incline your heart to the LORD God of Israel."

24. And the people said to Joshua, "The LORD our God we will serve, and His voice we will obey!"

25. So Joshua made a covenant with the people that day, and made for them a statute and an ordinance in Shechem.

26. Then Joshua wrote these words in the Book of the Law of God. And he took a large stone, and set it up there under the oak that was by the sanctuary of the LORD.

27. And Joshua said to all the people, "Behold, this stone shall be a witness to us, for it has heard all the words of the LORD which He spoke to us. It shall therefore be a witness to you, lest you deny your God."

28. So Joshua let the people depart, each to his own inheritance.

29. Now it came to pass after these things that Joshua the son of Nun, the servant of the LORD, died, being one hundred and ten years old.

30. And they buried him within the border of his inheritance at Timnath Serah, which is in the mountains of Ephraim, on the north side of Mount Gaash.

31. Israel served the LORD all the days of Joshua, and all the days of the elders who outlived Joshua, who had known all the works of the LORD which He had done for Israel.

32. The bones of Joseph, which the children of Israel had brought up out of Egypt, they buried at Shechem, in the plot of ground which Jacob had bought from the sons of Hamor the father of Shechem for one hundred pieces of silver, and which had become an inheritance of the children of Joseph.

33. And Eleazar the son of Aaron died. They buried him in a hill belonging to Phinehas his son, which was given to him in the mountains of Ephraim.


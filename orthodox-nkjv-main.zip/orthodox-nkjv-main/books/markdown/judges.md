# judges

## Chapter 1

1. Now after the death of Joshua it came to pass that the children of Israel asked the LORD, saying, "Who shall be first to go up for us against the Canaanites to fight against them?"

2. And the LORD said, "Judah shall go up. Indeed I have delivered the land into his hand."

3. So Judah said to Simeon his brother, "Come up with me to my allotted territory, that we may fight against the Canaanites; and I will likewise go with you to your allotted territory." And Simeon went with him.

4. Then Judah went up, and the LORD delivered the Canaanites and the Perizzites into their hand; and they killed ten thousand men at Bezek.

5. And they found Adoni-Bezek in Bezek, and fought against him; and they defeated the Canaanites and the Perizzites.

6. Then Adoni-Bezek fled, and they pursued him and caught him and cut off his thumbs and big toes.

7. And Adoni-Bezek said, "Seventy kings with their thumbs and big toes cut off used to gather scraps under my table; as I have done, so God has repaid me." Then they brought him to Jerusalem, and there he died.

8. Now the children of Judah fought against Jerusalem and took it; they struck it with the edge of the sword and set the city on fire.

9. And afterward the children of Judah went down to fight against the Canaanites who dwelt in the mountains, in the South, and in the lowland.

10. Then Judah went against the Canaanites who dwelt in Hebron. (Now the name of Hebron was formerly Kirjath Arba.) And they killed Sheshai, Ahiman, and Talmai.

11. From there they went against the inhabitants of Debir. (The name of Debir was formerly Kirjath Sepher.)

12. Then Caleb said, "Whoever attacks Kirjath Sepher and takes it, to him I will give my daughter Achsah as wife."

13. And Othniel the son of Kenaz, Caleb's younger brother, took it; so he gave him his daughter Achsah as wife.

14. Now it happened, when she came to him, that she urged him to ask her father for a field. And she dismounted from her donkey, and Caleb said to her, "What do you wish?"

15. So she said to him, "Give me a blessing; since you have given me land in the South, give me also springs of water." And Caleb gave her the upper springs and the lower springs.

16. Now the children of the Kenite, Moses' father-in-law, went up from the City of Palms with the children of Judah into the Wilderness of Judah, which lies in the South near Arad; and they went and dwelt among the people.

17. And Judah went with his brother Simeon, and they attacked the Canaanites who inhabited Zephath, and utterly destroyed it. So the name of the city was called Hormah.

18. Also Judah took Gaza with its territory, Ashkelon with its territory, and Ekron with its territory.

19. So the LORD was with Judah. And they drove out the mountaineers, but they could not drive out the inhabitants of the lowland, because they had chariots of iron.

20. And they gave Hebron to Caleb, as Moses had said. Then he expelled from there the three sons of Anak.

21. But the children of Benjamin did not drive out the Jebusites who inhabited Jerusalem; so the Jebusites dwell with the children of Benjamin in Jerusalem to this day.

22. And the house of Joseph also went up against Bethel, and the LORD was with them.

23. So the house of Joseph sent men to spy out Bethel. (The name of the city was formerly Luz.)

24. And when the spies saw a man coming out of the city, they said to him, "Please show us the entrance to the city, and we will show you mercy."

25. So he showed them the entrance to the city, and they struck the city with the edge of the sword; but they let the man and all his family go.

26. And the man went to the land of the Hittites, built a city, and called its name Luz, which is its name to this day.

27. However, Manasseh did not drive out the inhabitants of Beth Shean and its villages, or Taanach and its villages, or the inhabitants of Dor and its villages, or the inhabitants of Ibleam and its villages, or the inhabitants of Megiddo and its villages; for the Canaanites were determined to dwell in that land.

28. And it came to pass, when Israel was strong, that they put the Canaanites under tribute, but did not completely drive them out.

29. Nor did Ephraim drive out the Canaanites who dwelt in Gezer; so the Canaanites dwelt in Gezer among them.

30. Nor did Zebulun drive out the inhabitants of Kitron or the inhabitants of Nahalol; so the Canaanites dwelt among them, and were put under tribute.

31. Nor did Asher drive out the inhabitants of Acco or the inhabitants of Sidon, or of Ahlab, Achzib, Helbah, Aphik, or Rehob.

32. So the Asherites dwelt among the Canaanites, the inhabitants of the land; for they did not drive them out.

33. Nor did Naphtali drive out the inhabitants of Beth Shemesh or the inhabitants of Beth Anath; but they dwelt among the Canaanites, the inhabitants of the land. Nevertheless the inhabitants of Beth Shemesh and Beth Anath were put under tribute to them.

34. And the Amorites forced the children of Dan into the mountains, for they would not allow them to come down to the valley;

35. and the Amorites were determined to dwell in Mount Heres, in Aijalon, and in Shaalbim; yet when the strength of the house of Joseph became greater, they were put under tribute.

36. Now the boundary of the Amorites was from the Ascent of Akrabbim, from Sela, and upward.

## Chapter 2

1. Then the Angel of the LORD came up from Gilgal to Bochim, and said: "I led you up from Egypt and brought you to the land of which I swore to your fathers; and I said, "I will never break My covenant with you.

2. And you shall make no covenant with the inhabitants of this land; you shall tear down their altars.' But you have not obeyed My voice. Why have you done this?

3. Therefore I also said, "I will not drive them out before you; but they shall be thorns in your side, and their gods shall be a snare to you."'

4. So it was, when the Angel of the LORD spoke these words to all the children of Israel, that the people lifted up their voices and wept.

5. Then they called the name of that place Bochim; and they sacrificed there to the LORD.

6. And when Joshua had dismissed the people, the children of Israel went each to his own inheritance to possess the land.

7. So the people served the LORD all the days of Joshua, and all the days of the elders who outlived Joshua, who had seen all the great works of the LORD which He had done for Israel.

8. Now Joshua the son of Nun, the servant of the LORD, died when he was one hundred and ten years old.

9. And they buried him within the border of his inheritance at Timnath Heres, in the mountains of Ephraim, on the north side of Mount Gaash.

10. When all that generation had been gathered to their fathers, another generation arose after them who did not know the LORD nor the work which He had done for Israel.

11. Then the children of Israel did evil in the sight of the LORD, and served the Baals;

12. and they forsook the LORD God of their fathers, who had brought them out of the land of Egypt; and they followed other gods from among the gods of the people who were all around them, and they bowed down to them; and they provoked the LORD to anger.

13. They forsook the LORD and served Baal and the Ashtoreths.

14. And the anger of the LORD was hot against Israel. So He delivered them into the hands of plunderers who despoiled them; and He sold them into the hands of their enemies all around, so that they could no longer stand before their enemies.

15. Wherever they went out, the hand of the LORD was against them for calamity, as the LORD had said, and as the LORD had sworn to them. And they were greatly distressed.

16. Nevertheless, the LORD raised up judges who delivered them out of the hand of those who plundered them.

17. Yet they would not listen to their judges, but they played the harlot with other gods, and bowed down to them. They turned quickly from the way in which their fathers walked, in obeying the commandments of the LORD; they did not do so.

18. And when the LORD raised up judges for them, the LORD was with the judge and delivered them out of the hand of their enemies all the days of the judge; for the LORD was moved to pity by their groaning because of those who oppressed them and harassed them.

19. And it came to pass, when the judge was dead, that they reverted and behaved more corruptly than their fathers, by following other gods, to serve them and bow down to them. They did not cease from their own doings nor from their stubborn way.

20. Then the anger of the LORD was hot against Israel; and He said, "Because this nation has transgressed My covenant which I commanded their fathers, and has not heeded My voice,

21. I also will no longer drive out before them any of the nations which Joshua left when he died,

22. so that through them I may test Israel, whether they will keep the ways of the LORD, to walk in them as their fathers kept them, or not."

23. Therefore the LORD left those nations, without driving them out immediately; nor did He deliver them into the hand of Joshua.

## Chapter 3

1. Now these are the nations which the LORD left, that He might test Israel by them, that is, all who had not known any of the wars in Canaan

2. (this was only so that the generations of the children of Israel might be taught to know war, at least those who had not formerly known it),

3. namely, five lords of the Philistines, all the Canaanites, the Sidonians, and the Hivites who dwelt in Mount Lebanon, from Mount Baal Hermon to the entrance of Hamath.

4. And they were left, that He might test Israel by them, to know whether they would obey the commandments of the LORD, which He had commanded their fathers by the hand of Moses.

5. Thus the children of Israel dwelt among the Canaanites, the Hittites, the Amorites, the Perizzites, the Hivites, and the Jebusites.

6. And they took their daughters to be their wives, and gave their daughters to their sons; and they served their gods.

7. So the children of Israel did evil in the sight of the LORD. They forgot the LORD their God, and served the Baals and Asherahs.

8. Therefore the anger of the LORD was hot against Israel, and He sold them into the hand of Cushan-Rishathaim king of Mesopotamia; and the children of Israel served Cushan-Rishathaim eight years.

9. When the children of Israel cried out to the LORD, the LORD raised up a deliverer for the children of Israel, who delivered them: Othniel the son of Kenaz, Caleb's younger brother.

10. The Spirit of the LORD came upon him, and he judged Israel. He went out to war, and the LORD delivered Cushan-Rishathaim king of Mesopotamia into his hand; and his hand prevailed over Cushan-Rishathaim.

11. So the land had rest for forty years. Then Othniel the son of Kenaz died.

12. And the children of Israel again did evil in the sight of the LORD. So the LORD strengthened Eglon king of Moab against Israel, because they had done evil in the sight of the LORD.

13. Then he gathered to himself the people of Ammon and Amalek, went and defeated Israel, and took possession of the City of Palms.

14. So the children of Israel served Eglon king of Moab eighteen years.

15. But when the children of Israel cried out to the LORD, the LORD raised up a deliverer for them: Ehud the son of Gera, the Benjamite, a left-handed man. By him the children of Israel sent tribute to Eglon king of Moab.

16. Now Ehud made himself a dagger (it was double-edged and a cubit in length) and fastened it under his clothes on his right thigh.

17. So he brought the tribute to Eglon king of Moab. (Now Eglon was a very fat man.)

18. And when he had finished presenting the tribute, he sent away the people who had carried the tribute.

19. But he himself turned back from the stone images that were at Gilgal, and said, "I have a secret message for you, O king." He said, "Keep silence!" And all who attended him went out from him.

20. So Ehud came to him (now he was sitting upstairs in his cool private chamber). Then Ehud said, "I have a message from God for you." So he arose from his seat.

21. Then Ehud reached with his left hand, took the dagger from his right thigh, and thrust it into his belly.

22. Even the hilt went in after the blade, and the fat closed over the blade, for he did not draw the dagger out of his belly; and his entrails came out.

23. Then Ehud went out through the porch and shut the doors of the upper room behind him and locked them.

24. When he had gone out, Eglon's servants came to look, and to their surprise, the doors of the upper room were locked. So they said, "He is probably attending to his needs in the cool chamber."

25. So they waited till they were embarrassed, and still he had not opened the doors of the upper room. Therefore they took the key and opened them. And there was their master, fallen dead on the floor.

26. But Ehud had escaped while they delayed, and passed beyond the stone images and escaped to Seirah.

27. And it happened, when he arrived, that he blew the trumpet in the mountains of Ephraim, and the children of Israel went down with him from the mountains; and he led them.

28. Then he said to them, "Follow me, for the LORD has delivered your enemies the Moabites into your hand." So they went down after him, seized the fords of the Jordan leading to Moab, and did not allow anyone to cross over.

29. And at that time they killed about ten thousand men of Moab, all stout men of valor; not a man escaped.

30. So Moab was subdued that day under the hand of Israel. And the land had rest for eighty years.

31. After him was Shamgar the son of Anath, who killed six hundred men of the Philistines with an ox goad; and he also delivered Israel.

## Chapter 4

1. When Ehud was dead, the children of Israel again did evil in the sight of the LORD.

2. So the LORD sold them into the hand of Jabin king of Canaan, who reigned in Hazor. The commander of his army was Sisera, who dwelt in Harosheth Hagoyim.

3. And the children of Israel cried out to the LORD; for Jabin had nine hundred chariots of iron, and for twenty years he had harshly oppressed the children of Israel.

4. Now Deborah, a prophetess, the wife of Lapidoth, was judging Israel at that time.

5. And she would sit under the palm tree of Deborah between Ramah and Bethel in the mountains of Ephraim. And the children of Israel came up to her for judgment.

6. Then she sent and called for Barak the son of Abinoam from Kedesh in Naphtali, and said to him, "Has not the LORD God of Israel commanded, "Go and deploy troops at Mount Tabor; take with you ten thousand men of the sons of Naphtali and of the sons of Zebulun;

7. and against you I will deploy Sisera, the commander of Jabin's army, with his chariots and his multitude at the River Kishon; and I will deliver him into your hand'?"

8. And Barak said to her, "If you will go with me, then I will go; but if you will not go with me, I will not go!"

9. So she said, "I will surely go with you; nevertheless there will be no glory for you in the journey you are taking, for the LORD will sell Sisera into the hand of a woman." Then Deborah arose and went with Barak to Kedesh.

10. And Barak called Zebulun and Naphtali to Kedesh; he went up with ten thousand men under his command, and Deborah went up with him.

11. Now Heber the Kenite, of the children of Hobab the father-in-law of Moses, had separated himself from the Kenites and pitched his tent near the terebinth tree at Zaanaim, which is beside Kedesh.

12. And they reported to Sisera that Barak the son of Abinoam had gone up to Mount Tabor.

13. So Sisera gathered together all his chariots, nine hundred chariots of iron, and all the people who were with him, from Harosheth Hagoyim to the River Kishon.

14. Then Deborah said to Barak, "Up! For this is the day in which the LORD has delivered Sisera into your hand. Has not the LORD gone out before you?" So Barak went down from Mount Tabor with ten thousand men following him.

15. And the LORD routed Sisera and all his chariots and all his army with the edge of the sword before Barak; and Sisera alighted from his chariot and fled away on foot.

16. But Barak pursued the chariots and the army as far as Harosheth Hagoyim, and all the army of Sisera fell by the edge of the sword; not a man was left.

17. However, Sisera had fled away on foot to the tent of Jael, the wife of Heber the Kenite; for there was peace between Jabin king of Hazor and the house of Heber the Kenite.

18. And Jael went out to meet Sisera, and said to him, "Turn aside, my lord, turn aside to me; do not fear." And when he had turned aside with her into the tent, she covered him with a blanket.

19. Then he said to her, "Please give me a little water to drink, for I am thirsty." So she opened a jug of milk, gave him a drink, and covered him.

20. And he said to her, "Stand at the door of the tent, and if any man comes and inquires of you, and says, "Is there any man here?' you shall say, "No."'

21. Then Jael, Heber's wife, took a tent peg and took a hammer in her hand, and went softly to him and drove the peg into his temple, and it went down into the ground; for he was fast asleep and weary. So he died.

22. And then, as Barak pursued Sisera, Jael came out to meet him, and said to him, "Come, I will show you the man whom you seek." And when he went into her tent, there lay Sisera, dead with the peg in his temple.

23. So on that day God subdued Jabin king of Canaan in the presence of the children of Israel.

24. And the hand of the children of Israel grew stronger and stronger against Jabin king of Canaan, until they had destroyed Jabin king of Canaan.

## Chapter 5

1. Then Deborah and Barak the son of Abinoam sang on that day, saying:

2. "When leaders lead in Israel, When the people willingly offer themselves, Bless the LORD!

3. "Hear, O kings! Give ear, O princes! I, even I, will sing to the LORD; I will sing praise to the LORD God of Israel.

4. "LORD, when You went out from Seir, When You marched from the field of Edom, The earth trembled and the heavens poured, The clouds also poured water;

5. The mountains gushed before the LORD, This Sinai, before the LORD God of Israel.

6. "In the days of Shamgar, son of Anath, In the days of Jael, The highways were deserted, And the travelers walked along the byways.

7. Village life ceased, it ceased in Israel, Until I, Deborah, arose, Arose a mother in Israel.

8. They chose new gods; Then there was war in the gates; Not a shield or spear was seen among forty thousand in Israel.

9. My heart is with the rulers of Israel Who offered themselves willingly with the people. Bless the LORD!

10. "Speak, you who ride on white donkeys, Who sit in judges' attire, And who walk along the road.

11. Far from the noise of the archers, among the watering places, There they shall recount the righteous acts of the LORD, The righteous acts for His villagers in Israel; Then the people of the LORD shall go down to the gates.

12. "Awake, awake, Deborah! Awake, awake, sing a song! Arise, Barak, and lead your captives away, O son of Abinoam!

13. "Then the survivors came down, the people against the nobles; The LORD came down for me against the mighty.

14. From Ephraim were those whose roots were in Amalek. After you, Benjamin, with your peoples, From Machir rulers came down, And from Zebulun those who bear the recruiter's staff.

15. And the princes of Issachar were with Deborah; As Issachar, so was Barak Sent into the valley under his command; Among the divisions of Reuben There were great resolves of heart.

16. Why did you sit among the sheepfolds, To hear the pipings for the flocks? The divisions of Reuben have great searchings of heart.

17. Gilead stayed beyond the Jordan, And why did Dan remain on ships? Asher continued at the seashore, And stayed by his inlets.

18. Zebulun is a people who jeopardized their lives to the point of death, Naphtali also, on the heights of the battlefield.

19. "The kings came and fought, Then the kings of Canaan fought In Taanach, by the waters of Megiddo; They took no spoils of silver.

20. They fought from the heavens; The stars from their courses fought against Sisera.

21. The torrent of Kishon swept them away, That ancient torrent, the torrent of Kishon. O my soul, march on in strength!

22. Then the horses' hooves pounded, The galloping, galloping of his steeds.

23. "Curse Meroz,' said the angel of the LORD, "Curse its inhabitants bitterly, Because they did not come to the help of the LORD, To the help of the LORD against the mighty.'

24. "Most blessed among women is Jael, The wife of Heber the Kenite; Blessed is she among women in tents.

25. He asked for water, she gave milk; She brought out cream in a lordly bowl.

26. She stretched her hand to the tent peg, Her right hand to the workmen's hammer; She pounded Sisera, she pierced his head, She split and struck through his temple.

27. At her feet he sank, he fell, he lay still; At her feet he sank, he fell; Where he sank, there he fell dead.

28. "The mother of Sisera looked through the window, And cried out through the lattice, "Why is his chariot so long in coming? Why tarries the clatter of his chariots?'

29. Her wisest ladies answered her, Yes, she answered herself,

30. "Are they not finding and dividing the spoil: To every man a girl or two; For Sisera, plunder of dyed garments, Plunder of garments embroidered and dyed, Two pieces of dyed embroidery for the neck of the looter?'

31. "Thus let all Your enemies perish, O LORD! But let those who love Him be like the sun When it comes out in full strength." So the land had rest for forty years.

## Chapter 6

1. Then the children of Israel did evil in the sight of the LORD. So the LORD delivered them into the hand of Midian for seven years,

2. and the hand of Midian prevailed against Israel. Because of the Midianites, the children of Israel made for themselves the dens, the caves, and the strongholds which are in the mountains.

3. So it was, whenever Israel had sown, Midianites would come up; also Amalekites and the people of the East would come up against them.

4. Then they would encamp against them and destroy the produce of the earth as far as Gaza, and leave no sustenance for Israel, neither sheep nor ox nor donkey.

5. For they would come up with their livestock and their tents, coming in as numerous as locusts; both they and their camels were without number; and they would enter the land to destroy it.

6. So Israel was greatly impoverished because of the Midianites, and the children of Israel cried out to the LORD.

7. And it came to pass, when the children of Israel cried out to the LORD because of the Midianites,

8. that the LORD sent a prophet to the children of Israel, who said to them, "Thus says the LORD God of Israel: "I brought you up from Egypt and brought you out of the house of bondage;

9. and I delivered you out of the hand of the Egyptians and out of the hand of all who oppressed you, and drove them out before you and gave you their land.

10. Also I said to you, "I am the LORD your God; do not fear the gods of the Amorites, in whose land you dwell." But you have not obeyed My voice."'

11. Now the Angel of the LORD came and sat under the terebinth tree which was in Ophrah, which belonged to Joash the Abiezrite, while his son Gideon threshed wheat in the winepress, in order to hide it from the Midianites.

12. And the Angel of the LORD appeared to him, and said to him, "The LORD is with you, you mighty man of valor!"

13. Gideon said to Him, "O my lord, if the LORD is with us, why then has all this happened to us? And where are all His miracles which our fathers told us about, saying, "Did not the LORD bring us up from Egypt?' But now the LORD has forsaken us and delivered us into the hands of the Midianites."

14. Then the LORD turned to him and said, "Go in this might of yours, and you shall save Israel from the hand of the Midianites. Have I not sent you?"

15. So he said to Him, "O my Lord, how can I save Israel? Indeed my clan is the weakest in Manasseh, and I am the least in my father's house."

16. And the LORD said to him, "Surely I will be with you, and you shall defeat the Midianites as one man."

17. Then he said to Him, "If now I have found favor in Your sight, then show me a sign that it is You who talk with me.

18. Do not depart from here, I pray, until I come to You and bring out my offering and set it before You." And He said, "I will wait until you come back."

19. So Gideon went in and prepared a young goat, and unleavened bread from an ephah of flour. The meat he put in a basket, and he put the broth in a pot; and he brought them out to Him under the terebinth tree and presented them.

20. The Angel of God said to him, "Take the meat and the unleavened bread and lay them on this rock, and pour out the broth." And he did so.

21. Then the Angel of the LORD put out the end of the staff that was in His hand, and touched the meat and the unleavened bread; and fire rose out of the rock and consumed the meat and the unleavened bread. And the Angel of the LORD departed out of his sight.

22. Now Gideon perceived that He was the Angel of the LORD. So Gideon said, "Alas, O Lord GOD! For I have seen the Angel of the LORD face to face."

23. Then the LORD said to him, "Peace be with you; do not fear, you shall not die."

24. So Gideon built an altar there to the LORD, and called it The-LORD-Is-Peace. To this day it is still in Ophrah of the Abiezrites.

25. Now it came to pass the same night that the LORD said to him, "Take your father's young bull, the second bull of seven years old, and tear down the altar of Baal that your father has, and cut down the wooden image that is beside it;

26. and build an altar to the LORD your God on top of this rock in the proper arrangement, and take the second bull and offer a burnt sacrifice with the wood of the image which you shall cut down."

27. So Gideon took ten men from among his servants and did as the LORD had said to him. But because he feared his father's household and the men of the city too much to do it by day, he did it by night.

28. And when the men of the city arose early in the morning, there was the altar of Baal, torn down; and the wooden image that was beside it was cut down, and the second bull was being offered on the altar which had been built.

29. So they said to one another, "Who has done this thing?" And when they had inquired and asked, they said, "Gideon the son of Joash has done this thing."

30. Then the men of the city said to Joash, "Bring out your son, that he may die, because he has torn down the altar of Baal, and because he has cut down the wooden image that was beside it."

31. But Joash said to all who stood against him, "Would you plead for Baal? Would you save him? Let the one who would plead for him be put to death by morning! If he is a god, let him plead for himself, because his altar has been torn down!"

32. Therefore on that day he called him Jerubbaal, saying, "Let Baal plead against him, because he has torn down his altar."

33. Then all the Midianites and Amalekites, the people of the East, gathered together; and they crossed over and encamped in the Valley of Jezreel.

34. But the Spirit of the LORD came upon Gideon; then he blew the trumpet, and the Abiezrites gathered behind him.

35. And he sent messengers throughout all Manasseh, who also gathered behind him. He also sent messengers to Asher, Zebulun, and Naphtali; and they came up to meet them.

36. So Gideon said to God, "If You will save Israel by my hand as You have said--

37. look, I shall put a fleece of wool on the threshing floor; if there is dew on the fleece only, and it is dry on all the ground, then I shall know that You will save Israel by my hand, as You have said."

38. And it was so. When he rose early the next morning and squeezed the fleece together, he wrung the dew out of the fleece, a bowlful of water.

39. Then Gideon said to God, "Do not be angry with me, but let me speak just once more: Let me test, I pray, just once more with the fleece; let it now be dry only on the fleece, but on all the ground let there be dew."

40. And God did so that night. It was dry on the fleece only, but there was dew on all the ground.

## Chapter 7

1. Then Jerubbaal (that is, Gideon) and all the people who were with him rose early and encamped beside the well of Harod, so that the camp of the Midianites was on the north side of them by the hill of Moreh in the valley.

2. And the LORD said to Gideon, "The people who are with you are too many for Me to give the Midianites into their hands, lest Israel claim glory for itself against Me, saying, "My own hand has saved me.'

3. Now therefore, proclaim in the hearing of the people, saying, "Whoever is fearful and afraid, let him turn and depart at once from Mount Gilead."' And twenty-two thousand of the people returned, and ten thousand remained.

4. But the LORD said to Gideon, "The people are still too many; bring them down to the water, and I will test them for you there. Then it will be, that of whom I say to you, "This one shall go with you,' the same shall go with you; and of whomever I say to you, "This one shall not go with you,' the same shall not go."

5. So he brought the people down to the water. And the LORD said to Gideon, "Everyone who laps from the water with his tongue, as a dog laps, you shall set apart by himself; likewise everyone who gets down on his knees to drink."

6. And the number of those who lapped, putting their hand to their mouth, was three hundred men; but all the rest of the people got down on their knees to drink water.

7. Then the LORD said to Gideon, "By the three hundred men who lapped I will save you, and deliver the Midianites into your hand. Let all the other people go, every man to his place."

8. So the people took provisions and their trumpets in their hands. And he sent away all the rest of Israel, every man to his tent, and retained those three hundred men. Now the camp of Midian was below him in the valley.

9. It happened on the same night that the LORD said to him, "Arise, go down against the camp, for I have delivered it into your hand.

10. But if you are afraid to go down, go down to the camp with Purah your servant,

11. and you shall hear what they say; and afterward your hands shall be strengthened to go down against the camp." Then he went down with Purah his servant to the outpost of the armed men who were in the camp.

12. Now the Midianites and Amalekites, all the people of the East, were lying in the valley as numerous as locusts; and their camels were without number, as the sand by the seashore in multitude.

13. And when Gideon had come, there was a man telling a dream to his companion. He said, "I have had a dream: To my surprise, a loaf of barley bread tumbled into the camp of Midian; it came to a tent and struck it so that it fell and overturned, and the tent collapsed."

14. Then his companion answered and said, "This is nothing else but the sword of Gideon the son of Joash, a man of Israel! Into his hand God has delivered Midian and the whole camp."

15. And so it was, when Gideon heard the telling of the dream and its interpretation, that he worshiped. He returned to the camp of Israel, and said, "Arise, for the LORD has delivered the camp of Midian into your hand."

16. Then he divided the three hundred men into three companies, and he put a trumpet into every man's hand, with empty pitchers, and torches inside the pitchers.

17. And he said to them, "Look at me and do likewise; watch, and when I come to the edge of the camp you shall do as I do:

18. When I blow the trumpet, I and all who are with me, then you also blow the trumpets on every side of the whole camp, and say, "The sword of the LORD and of Gideon!"'

19. So Gideon and the hundred men who were with him came to the outpost of the camp at the beginning of the middle watch, just as they had posted the watch; and they blew the trumpets and broke the pitchers that were in their hands.

20. Then the three companies blew the trumpets and broke the pitchers--they held the torches in their left hands and the trumpets in their right hands for blowing--and they cried, "The sword of the LORD and of Gideon!"

21. And every man stood in his place all around the camp; and the whole army ran and cried out and fled.

22. When the three hundred blew the trumpets, the LORD set every man's sword against his companion throughout the whole camp; and the army fled to Beth Acacia, toward Zererah, as far as the border of Abel Meholah, by Tabbath.

23. And the men of Israel gathered together from Naphtali, Asher, and all Manasseh, and pursued the Midianites.

24. Then Gideon sent messengers throughout all the mountains of Ephraim, saying, "Come down against the Midianites, and seize from them the watering places as far as Beth Barah and the Jordan." Then all the men of Ephraim gathered together and seized the watering places as far as Beth Barah and the Jordan.

25. And they captured two princes of the Midianites, Oreb and Zeeb. They killed Oreb at the rock of Oreb, and Zeeb they killed at the winepress of Zeeb. They pursued Midian and brought the heads of Oreb and Zeeb to Gideon on the other side of the Jordan.

## Chapter 8

1. Now the men of Ephraim said to him, "Why have you done this to us by not calling us when you went to fight with the Midianites?" And they reprimanded him sharply.

2. So he said to them, "What have I done now in comparison with you? Is not the gleaning of the grapes of Ephraim better than the vintage of Abiezer?

3. God has delivered into your hands the princes of Midian, Oreb and Zeeb. And what was I able to do in comparison with you?" Then their anger toward him subsided when he said that.

4. When Gideon came to the Jordan, he and the three hundred men who were with him crossed over, exhausted but still in pursuit.

5. Then he said to the men of Succoth, "Please give loaves of bread to the people who follow me, for they are exhausted, and I am pursuing Zebah and Zalmunna, kings of Midian."

6. And the leaders of Succoth said, "Are the hands of Zebah and Zalmunna now in your hand, that we should give bread to your army?"

7. So Gideon said, "For this cause, when the LORD has delivered Zebah and Zalmunna into my hand, then I will tear your flesh with the thorns of the wilderness and with briers!"

8. Then he went up from there to Penuel and spoke to them in the same way. And the men of Penuel answered him as the men of Succoth had answered.

9. So he also spoke to the men of Penuel, saying, "When I come back in peace, I will tear down this tower!"

10. Now Zebah and Zalmunna were at Karkor, and their armies with them, about fifteen thousand, all who were left of all the army of the people of the East; for one hundred and twenty thousand men who drew the sword had fallen.

11. Then Gideon went up by the road of those who dwell in tents on the east of Nobah and Jogbehah; and he attacked the army while the camp felt secure.

12. When Zebah and Zalmunna fled, he pursued them; and he took the two kings of Midian, Zebah and Zalmunna, and routed the whole army.

13. Then Gideon the son of Joash returned from battle, from the Ascent of Heres.

14. And he caught a young man of the men of Succoth and interrogated him; and he wrote down for him the leaders of Succoth and its elders, seventy-seven men.

15. Then he came to the men of Succoth and said, "Here are Zebah and Zalmunna, about whom you ridiculed me, saying, "Are the hands of Zebah and Zalmunna now in your hand, that we should give bread to your weary men?"'

16. And he took the elders of the city, and thorns of the wilderness and briers, and with them he taught the men of Succoth.

17. Then he tore down the tower of Penuel and killed the men of the city.

18. And he said to Zebah and Zalmunna, "What kind of men were they whom you killed at Tabor?" So they answered, "As you are, so were they; each one resembled the son of a king."

19. Then he said, "They were my brothers, the sons of my mother. As the LORD lives, if you had let them live, I would not kill you."

20. And he said to Jether his firstborn, "Rise, kill them!" But the youth would not draw his sword; for he was afraid, because he was still a youth.

21. So Zebah and Zalmunna said, "Rise yourself, and kill us; for as a man is, so is his strength." So Gideon arose and killed Zebah and Zalmunna, and took the crescent ornaments that were on their camels' necks.

22. Then the men of Israel said to Gideon, "Rule over us, both you and your son, and your grandson also; for you have delivered us from the hand of Midian."

23. But Gideon said to them, "I will not rule over you, nor shall my son rule over you; the LORD shall rule over you."

24. Then Gideon said to them, "I would like to make a request of you, that each of you would give me the earrings from his plunder." For they had golden earrings, because they were Ishmaelites.

25. So they answered, "We will gladly give them." And they spread out a garment, and each man threw into it the earrings from his plunder.

26. Now the weight of the gold earrings that he requested was one thousand seven hundred shekels of gold, besides the crescent ornaments, pendants, and purple robes which were on the kings of Midian, and besides the chains that were around their camels' necks.

27. Then Gideon made it into an ephod and set it up in his city, Ophrah. And all Israel played the harlot with it there. It became a snare to Gideon and to his house.

28. Thus Midian was subdued before the children of Israel, so that they lifted their heads no more. And the country was quiet for forty years in the days of Gideon.

29. Then Jerubbaal the son of Joash went and dwelt in his own house.

30. Gideon had seventy sons who were his own offspring, for he had many wives.

31. And his concubine who was in Shechem also bore him a son, whose name he called Abimelech.

32. Now Gideon the son of Joash died at a good old age, and was buried in the tomb of Joash his father, in Ophrah of the Abiezrites.

33. So it was, as soon as Gideon was dead, that the children of Israel again played the harlot with the Baals, and made Baal-Berith their god.

34. Thus the children of Israel did not remember the LORD their God, who had delivered them from the hands of all their enemies on every side;

35. nor did they show kindness to the house of Jerubbaal (Gideon) in accordance with the good he had done for Israel.

## Chapter 9

1. Then Abimelech the son of Jerubbaal went to Shechem, to his mother's brothers, and spoke with them and with all the family of the house of his mother's father, saying,

2. "Please speak in the hearing of all the men of Shechem: "Which is better for you, that all seventy of the sons of Jerubbaal reign over you, or that one reign over you?' Remember that I am your own flesh and bone."

3. And his mother's brothers spoke all these words concerning him in the hearing of all the men of Shechem; and their heart was inclined to follow Abimelech, for they said, "He is our brother."

4. So they gave him seventy shekels of silver from the temple of Baal-Berith, with which Abimelech hired worthless and reckless men; and they followed him.

5. Then he went to his father's house at Ophrah and killed his brothers, the seventy sons of Jerubbaal, on one stone. But Jotham the youngest son of Jerubbaal was left, because he hid himself.

6. And all the men of Shechem gathered together, all of Beth Millo, and they went and made Abimelech king beside the terebinth tree at the pillar that was in Shechem.

7. Now when they told Jotham, he went and stood on top of Mount Gerizim, and lifted his voice and cried out. And he said to them: "Listen to me, you men of Shechem, That God may listen to you!

8. "The trees once went forth to anoint a king over them. And they said to the olive tree, "Reign over us!'

9. But the olive tree said to them, "Should I cease giving my oil, With which they honor God and men, And go to sway over trees?'

10. "Then the trees said to the fig tree, "You come and reign over us!'

11. But the fig tree said to them, "Should I cease my sweetness and my good fruit, And go to sway over trees?'

12. "Then the trees said to the vine, "You come and reign over us!'

13. But the vine said to them, "Should I cease my new wine, Which cheers both God and men, And go to sway over trees?'

14. "Then all the trees said to the bramble, "You come and reign over us!'

15. And the bramble said to the trees, "If in truth you anoint me as king over you, Then come and take shelter in my shade; But if not, let fire come out of the bramble And devour the cedars of Lebanon!'

16. "Now therefore, if you have acted in truth and sincerity in making Abimelech king, and if you have dealt well with Jerubbaal and his house, and have done to him as he deserves--

17. for my father fought for you, risked his life, and delivered you out of the hand of Midian;

18. but you have risen up against my father's house this day, and killed his seventy sons on one stone, and made Abimelech, the son of his female servant, king over the men of Shechem, because he is your brother--

19. if then you have acted in truth and sincerity with Jerubbaal and with his house this day, then rejoice in Abimelech, and let him also rejoice in you.

20. But if not, let fire come from Abimelech and devour the men of Shechem and Beth Millo; and let fire come from the men of Shechem and from Beth Millo and devour Abimelech!"

21. And Jotham ran away and fled; and he went to Beer and dwelt there, for fear of Abimelech his brother.

22. After Abimelech had reigned over Israel three years,

23. God sent a spirit of ill will between Abimelech and the men of Shechem; and the men of Shechem dealt treacherously with Abimelech,

24. that the crime done to the seventy sons of Jerubbaal might be settled and their blood be laid on Abimelech their brother, who killed them, and on the men of Shechem, who aided him in the killing of his brothers.

25. And the men of Shechem set men in ambush against him on the tops of the mountains, and they robbed all who passed by them along that way; and it was told Abimelech.

26. Now Gaal the son of Ebed came with his brothers and went over to Shechem; and the men of Shechem put their confidence in him.

27. So they went out into the fields, and gathered grapes from their vineyards and trod them, and made merry. And they went into the house of their god, and ate and drank, and cursed Abimelech.

28. Then Gaal the son of Ebed said, "Who is Abimelech, and who is Shechem, that we should serve him? Is he not the son of Jerubbaal, and is not Zebul his officer? Serve the men of Hamor the father of Shechem; but why should we serve him?

29. If only this people were under my authority! Then I would remove Abimelech." So he said to Abimelech, "Increase your army and come out!"

30. When Zebul, the ruler of the city, heard the words of Gaal the son of Ebed, his anger was aroused.

31. And he sent messengers to Abimelech secretly, saying, "Take note! Gaal the son of Ebed and his brothers have come to Shechem; and here they are, fortifying the city against you.

32. Now therefore, get up by night, you and the people who are with you, and lie in wait in the field.

33. And it shall be, as soon as the sun is up in the morning, that you shall rise early and rush upon the city; and when he and the people who are with him come out against you, you may then do to them as you find opportunity."

34. So Abimelech and all the people who were with him rose by night, and lay in wait against Shechem in four companies.

35. When Gaal the son of Ebed went out and stood in the entrance to the city gate, Abimelech and the people who were with him rose from lying in wait.

36. And when Gaal saw the people, he said to Zebul, "Look, people are coming down from the tops of the mountains!" But Zebul said to him, "You see the shadows of the mountains as if they were men."

37. So Gaal spoke again and said, "See, people are coming down from the center of the land, and another company is coming from the Diviners' Terebinth Tree."

38. Then Zebul said to him, "Where indeed is your mouth now, with which you said, "Who is Abimelech, that we should serve him?' Are not these the people whom you despised? Go out, if you will, and fight with them now."

39. So Gaal went out, leading the men of Shechem, and fought with Abimelech.

40. And Abimelech chased him, and he fled from him; and many fell wounded, to the very entrance of the gate.

41. Then Abimelech dwelt at Arumah, and Zebul drove out Gaal and his brothers, so that they would not dwell in Shechem.

42. And it came about on the next day that the people went out into the field, and they told Abimelech.

43. So he took his people, divided them into three companies, and lay in wait in the field. And he looked, and there were the people, coming out of the city; and he rose against them and attacked them.

44. Then Abimelech and the company that was with him rushed forward and stood at the entrance of the gate of the city; and the other two companies rushed upon all who were in the fields and killed them.

45. So Abimelech fought against the city all that day; he took the city and killed the people who were in it; and he demolished the city and sowed it with salt.

46. Now when all the men of the tower of Shechem had heard that, they entered the stronghold of the temple of the god Berith.

47. And it was told Abimelech that all the men of the tower of Shechem were gathered together.

48. Then Abimelech went up to Mount Zalmon, he and all the people who were with him. And Abimelech took an ax in his hand and cut down a bough from the trees, and took it and laid it on his shoulder; then he said to the people who were with him, "What you have seen me do, make haste and do as I have done."

49. So each of the people likewise cut down his own bough and followed Abimelech, put them against the stronghold, and set the stronghold on fire above them, so that all the people of the tower of Shechem died, about a thousand men and women.

50. Then Abimelech went to Thebez, and he encamped against Thebez and took it.

51. But there was a strong tower in the city, and all the men and women--all the people of the city--fled there and shut themselves in; then they went up to the top of the tower.

52. So Abimelech came as far as the tower and fought against it; and he drew near the door of the tower to burn it with fire.

53. But a certain woman dropped an upper millstone on Abimelech's head and crushed his skull.

54. Then he called quickly to the young man, his armorbearer, and said to him, "Draw your sword and kill me, lest men say of me, "A woman killed him."' So his young man thrust him through, and he died.

55. And when the men of Israel saw that Abimelech was dead, they departed, every man to his place.

56. Thus God repaid the wickedness of Abimelech, which he had done to his father by killing his seventy brothers.

57. And all the evil of the men of Shechem God returned on their own heads, and on them came the curse of Jotham the son of Jerubbaal.

## Chapter 10

1. After Abimelech there arose to save Israel Tola the son of Puah, the son of Dodo, a man of Issachar; and he dwelt in Shamir in the mountains of Ephraim.

2. He judged Israel twenty-three years; and he died and was buried in Shamir.

3. After him arose Jair, a Gileadite; and he judged Israel twenty-two years.

4. Now he had thirty sons who rode on thirty donkeys; they also had thirty towns, which are called "Havoth Jair" to this day, which are in the land of Gilead.

5. And Jair died and was buried in Camon.

6. Then the children of Israel again did evil in the sight of the LORD, and served the Baals and the Ashtoreths, the gods of Syria, the gods of Sidon, the gods of Moab, the gods of the people of Ammon, and the gods of the Philistines; and they forsook the LORD and did not serve Him.

7. So the anger of the LORD was hot against Israel; and He sold them into the hands of the Philistines and into the hands of the people of Ammon.

8. From that year they harassed and oppressed the children of Israel for eighteen years--all the children of Israel who were on the other side of the Jordan in the land of the Amorites, in Gilead.

9. Moreover the people of Ammon crossed over the Jordan to fight against Judah also, against Benjamin, and against the house of Ephraim, so that Israel was severely distressed.

10. And the children of Israel cried out to the LORD, saying, "We have sinned against You, because we have both forsaken our God and served the Baals!"

11. So the LORD said to the children of Israel, "Did I not deliver you from the Egyptians and from the Amorites and from the people of Ammon and from the Philistines?

12. Also the Sidonians and Amalekites and Maonites oppressed you; and you cried out to Me, and I delivered you from their hand.

13. Yet you have forsaken Me and served other gods. Therefore I will deliver you no more.

14. Go and cry out to the gods which you have chosen; let them deliver you in your time of distress."

15. And the children of Israel said to the LORD, "We have sinned! Do to us whatever seems best to You; only deliver us this day, we pray."

16. So they put away the foreign gods from among them and served the LORD. And His soul could no longer endure the misery of Israel.

17. Then the people of Ammon gathered together and encamped in Gilead. And the children of Israel assembled together and encamped in Mizpah.

18. And the people, the leaders of Gilead, said to one another, "Who is the man who will begin the fight against the people of Ammon? He shall be head over all the inhabitants of Gilead."

## Chapter 11

1. Now Jephthah the Gileadite was a mighty man of valor, but he was the son of a harlot; and Gilead begot Jephthah.

2. Gilead's wife bore sons; and when his wife's sons grew up, they drove Jephthah out, and said to him, "You shall have no inheritance in our father's house, for you are the son of another woman."

3. Then Jephthah fled from his brothers and dwelt in the land of Tob; and worthless men banded together with Jephthah and went out raiding with him.

4. It came to pass after a time that the people of Ammon made war against Israel.

5. And so it was, when the people of Ammon made war against Israel, that the elders of Gilead went to get Jephthah from the land of Tob.

6. Then they said to Jephthah, "Come and be our commander, that we may fight against the people of Ammon."

7. So Jephthah said to the elders of Gilead, "Did you not hate me, and expel me from my father's house? Why have you come to me now when you are in distress?"

8. And the elders of Gilead said to Jephthah, "That is why we have turned again to you now, that you may go with us and fight against the people of Ammon, and be our head over all the inhabitants of Gilead."

9. So Jephthah said to the elders of Gilead, "If you take me back home to fight against the people of Ammon, and the LORD delivers them to me, shall I be your head?"

10. And the elders of Gilead said to Jephthah, "The LORD will be a witness between us, if we do not do according to your words."

11. Then Jephthah went with the elders of Gilead, and the people made him head and commander over them; and Jephthah spoke all his words before the LORD in Mizpah.

12. Now Jephthah sent messengers to the king of the people of Ammon, saying, "What do you have against me, that you have come to fight against me in my land?"

13. And the king of the people of Ammon answered the messengers of Jephthah, "Because Israel took away my land when they came up out of Egypt, from the Arnon as far as the Jabbok, and to the Jordan. Now therefore, restore those lands peaceably."

14. So Jephthah again sent messengers to the king of the people of Ammon,

15. and said to him, "Thus says Jephthah: "Israel did not take away the land of Moab, nor the land of the people of Ammon;

16. for when Israel came up from Egypt, they walked through the wilderness as far as the Red Sea and came to Kadesh.

17. Then Israel sent messengers to the king of Edom, saying, "Please let me pass through your land." But the king of Edom would not heed. And in like manner they sent to the king of Moab, but he would not consent. So Israel remained in Kadesh.

18. And they went along through the wilderness and bypassed the land of Edom and the land of Moab, came to the east side of the land of Moab, and encamped on the other side of the Arnon. But they did not enter the border of Moab, for the Arnon was the border of Moab.

19. Then Israel sent messengers to Sihon king of the Amorites, king of Heshbon; and Israel said to him, "Please let us pass through your land into our place."

20. But Sihon did not trust Israel to pass through his territory. So Sihon gathered all his people together, encamped in Jahaz, and fought against Israel.

21. And the LORD God of Israel delivered Sihon and all his people into the hand of Israel, and they defeated them. Thus Israel gained possession of all the land of the Amorites, who inhabited that country.

22. They took possession of all the territory of the Amorites, from the Arnon to the Jabbok and from the wilderness to the Jordan.

23. "And now the LORD God of Israel has dispossessed the Amorites from before His people Israel; should you then possess it?

24. Will you not possess whatever Chemosh your god gives you to possess? So whatever the LORD our God takes possession of before us, we will possess.

25. And now, are you any better than Balak the son of Zippor, king of Moab? Did he ever strive against Israel? Did he ever fight against them?

26. While Israel dwelt in Heshbon and its villages, in Aroer and its villages, and in all the cities along the banks of the Arnon, for three hundred years, why did you not recover them within that time?

27. Therefore I have not sinned against you, but you wronged me by fighting against me. May the LORD, the Judge, render judgment this day between the children of Israel and the people of Ammon."'

28. However, the king of the people of Ammon did not heed the words which Jephthah sent him.

29. Then the Spirit of the LORD came upon Jephthah, and he passed through Gilead and Manasseh, and passed through Mizpah of Gilead; and from Mizpah of Gilead he advanced toward the people of Ammon.

30. And Jephthah made a vow to the LORD, and said, "If You will indeed deliver the people of Ammon into my hands,

31. then it will be that whatever comes out of the doors of my house to meet me, when I return in peace from the people of Ammon, shall surely be the LORD's, and I will offer it up as a burnt offering."

32. So Jephthah advanced toward the people of Ammon to fight against them, and the LORD delivered them into his hands.

33. And he defeated them from Aroer as far as Minnith--twenty cities--and to Abel Keramim, with a very great slaughter. Thus the people of Ammon were subdued before the children of Israel.

34. When Jephthah came to his house at Mizpah, there was his daughter, coming out to meet him with timbrels and dancing; and she was his only child. Besides her he had neither son nor daughter.

35. And it came to pass, when he saw her, that he tore his clothes, and said, "Alas, my daughter! You have brought me very low! You are among those who trouble me! For I have given my word to the LORD, and I cannot go back on it."

36. So she said to him, "My father, if you have given your word to the LORD, do to me according to what has gone out of your mouth, because the LORD has avenged you of your enemies, the people of Ammon."

37. Then she said to her father, "Let this thing be done for me: let me alone for two months, that I may go and wander on the mountains and bewail my virginity, my friends and I."

38. So he said, "Go." And he sent her away for two months; and she went with her friends, and bewailed her virginity on the mountains.

39. And it was so at the end of two months that she returned to her father, and he carried out his vow with her which he had vowed. She knew no man. And it became a custom in Israel

40. that the daughters of Israel went four days each year to lament the daughter of Jephthah the Gileadite.

## Chapter 12

1. Then the men of Ephraim gathered together, crossed over toward Zaphon, and said to Jephthah, "Why did you cross over to fight against the people of Ammon, and did not call us to go with you? We will burn your house down on you with fire!"

2. And Jephthah said to them, "My people and I were in a great struggle with the people of Ammon; and when I called you, you did not deliver me out of their hands.

3. So when I saw that you would not deliver me, I took my life in my hands and crossed over against the people of Ammon; and the LORD delivered them into my hand. Why then have you come up to me this day to fight against me?"

4. Now Jephthah gathered together all the men of Gilead and fought against Ephraim. And the men of Gilead defeated Ephraim, because they said, "You Gileadites are fugitives of Ephraim among the Ephraimites and among the Manassites."

5. The Gileadites seized the fords of the Jordan before the Ephraimites arrived. And when any Ephraimite who escaped said, "Let me cross over," the men of Gilead would say to him, "Are you an Ephraimite?" If he said, "No,"

6. then they would say to him, "Then say, "Shibboleth'!" And he would say, "Sibboleth," for he could not pronounce it right. Then they would take him and kill him at the fords of the Jordan. There fell at that time forty-two thousand Ephraimites.

7. And Jephthah judged Israel six years. Then Jephthah the Gileadite died and was buried among the cities of Gilead.

8. After him, Ibzan of Bethlehem judged Israel.

9. He had thirty sons. And he gave away thirty daughters in marriage, and brought in thirty daughters from elsewhere for his sons. He judged Israel seven years.

10. Then Ibzan died and was buried at Bethlehem.

11. After him, Elon the Zebulunite judged Israel. He judged Israel ten years.

12. And Elon the Zebulunite died and was buried at Aijalon in the country of Zebulun.

13. After him, Abdon the son of Hillel the Pirathonite judged Israel.

14. He had forty sons and thirty grandsons, who rode on seventy young donkeys. He judged Israel eight years.

15. Then Abdon the son of Hillel the Pirathonite died and was buried in Pirathon in the land of Ephraim, in the mountains of the Amalekites.

## Chapter 13

1. Again the children of Israel did evil in the sight of the LORD, and the LORD delivered them into the hand of the Philistines for forty years.

2. Now there was a certain man from Zorah, of the family of the Danites, whose name was Manoah; and his wife was barren and had no children.

3. And the Angel of the LORD appeared to the woman and said to her, "Indeed now, you are barren and have borne no children, but you shall conceive and bear a son.

4. Now therefore, please be careful not to drink wine or similar drink, and not to eat anything unclean.

5. For behold, you shall conceive and bear a son. And no razor shall come upon his head, for the child shall be a Nazirite to God from the womb; and he shall begin to deliver Israel out of the hand of the Philistines."

6. So the woman came and told her husband, saying, "A Man of God came to me, and His countenance was like the countenance of the Angel of God, very awesome; but I did not ask Him where He was from, and He did not tell me His name.

7. And He said to me, "Behold, you shall conceive and bear a son. Now drink no wine or similar drink, nor eat anything unclean, for the child shall be a Nazirite to God from the womb to the day of his death."'

8. Then Manoah prayed to the LORD, and said, "O my Lord, please let the Man of God whom You sent come to us again and teach us what we shall do for the child who will be born."

9. And God listened to the voice of Manoah, and the Angel of God came to the woman again as she was sitting in the field; but Manoah her husband was not with her.

10. Then the woman ran in haste and told her husband, and said to him, "Look, the Man who came to me the other day has just now appeared to me!"

11. So Manoah arose and followed his wife. When he came to the Man, he said to Him, "Are You the Man who spoke to this woman?" And He said, "I am."

12. Manoah said, "Now let Your words come to pass! What will be the boy's rule of life, and his work?"

13. So the Angel of the LORD said to Manoah, "Of all that I said to the woman let her be careful.

14. She may not eat anything that comes from the vine, nor may she drink wine or similar drink, nor eat anything unclean. All that I commanded her let her observe."

15. Then Manoah said to the Angel of the LORD, "Please let us detain You, and we will prepare a young goat for You."

16. And the Angel of the LORD said to Manoah, "Though you detain Me, I will not eat your food. But if you offer a burnt offering, you must offer it to the LORD." (For Manoah did not know He was the Angel of the LORD.)

17. Then Manoah said to the Angel of the LORD, "What is Your name, that when Your words come to pass we may honor You?"

18. And the Angel of the LORD said to him, "Why do you ask My name, seeing it is wonderful?"

19. So Manoah took the young goat with the grain offering, and offered it upon the rock to the LORD. And He did a wondrous thing while Manoah and his wife looked on--

20. it happened as the flame went up toward heaven from the altar--the Angel of the LORD ascended in the flame of the altar! When Manoah and his wife saw this, they fell on their faces to the ground.

21. When the Angel of the LORD appeared no more to Manoah and his wife, then Manoah knew that He was the Angel of the LORD.

22. And Manoah said to his wife, "We shall surely die, because we have seen God!"

23. But his wife said to him, "If the LORD had desired to kill us, He would not have accepted a burnt offering and a grain offering from our hands, nor would He have shown us all these things, nor would He have told us such things as these at this time."

24. So the woman bore a son and called his name Samson; and the child grew, and the LORD blessed him.

25. And the Spirit of the LORD began to move upon him at Mahaneh Dan between Zorah and Eshtaol.

## Chapter 14

1. Now Samson went down to Timnah, and saw a woman in Timnah of the daughters of the Philistines.

2. So he went up and told his father and mother, saying, "I have seen a woman in Timnah of the daughters of the Philistines; now therefore, get her for me as a wife."

3. Then his father and mother said to him, "Is there no woman among the daughters of your brethren, or among all my people, that you must go and get a wife from the uncircumcised Philistines?" And Samson said to his father, "Get her for me, for she pleases me well."

4. But his father and mother did not know that it was of the LORD--that He was seeking an occasion to move against the Philistines. For at that time the Philistines had dominion over Israel.

5. So Samson went down to Timnah with his father and mother, and came to the vineyards of Timnah. Now to his surprise, a young lion came roaring against him.

6. And the Spirit of the LORD came mightily upon him, and he tore the lion apart as one would have torn apart a young goat, though he had nothing in his hand. But he did not tell his father or his mother what he had done.

7. Then he went down and talked with the woman; and she pleased Samson well.

8. After some time, when he returned to get her, he turned aside to see the carcass of the lion. And behold, a swarm of bees and honey were in the carcass of the lion.

9. He took some of it in his hands and went along, eating. When he came to his father and mother, he gave some to them, and they also ate. But he did not tell them that he had taken the honey out of the carcass of the lion.

10. So his father went down to the woman. And Samson gave a feast there, for young men used to do so.

11. And it happened, when they saw him, that they brought thirty companions to be with him.

12. Then Samson said to them, "Let me pose a riddle to you. If you can correctly solve and explain it to me within the seven days of the feast, then I will give you thirty linen garments and thirty changes of clothing.

13. But if you cannot explain it to me, then you shall give me thirty linen garments and thirty changes of clothing." And they said to him, "Pose your riddle, that we may hear it."

14. So he said to them: "Out of the eater came something to eat, And out of the strong came something sweet." Now for three days they could not explain the riddle.

15. But it came to pass on the seventh day that they said to Samson's wife, "Entice your husband, that he may explain the riddle to us, or else we will burn you and your father's house with fire. Have you invited us in order to take what is ours? Is that not so?"

16. Then Samson's wife wept on him, and said, "You only hate me! You do not love me! You have posed a riddle to the sons of my people, but you have not explained it to me." And he said to her, "Look, I have not explained it to my father or my mother; so should I explain it to you?"

17. Now she had wept on him the seven days while their feast lasted. And it happened on the seventh day that he told her, because she pressed him so much. Then she explained the riddle to the sons of her people.

18. So the men of the city said to him on the seventh day before the sun went down: "What is sweeter than honey? And what is stronger than a lion?" And he said to them: "If you had not plowed with my heifer, You would not have solved my riddle!"

19. Then the Spirit of the LORD came upon him mightily, and he went down to Ashkelon and killed thirty of their men, took their apparel, and gave the changes of clothing to those who had explained the riddle. So his anger was aroused, and he went back up to his father's house.

20. And Samson's wife was given to his companion, who had been his best man.

## Chapter 15

1. After a while, in the time of wheat harvest, it happened that Samson visited his wife with a young goat. And he said, "Let me go in to my wife, into her room." But her father would not permit him to go in.

2. Her father said, "I really thought that you thoroughly hated her; therefore I gave her to your companion. Is not her younger sister better than she? Please, take her instead."

3. And Samson said to them, "This time I shall be blameless regarding the Philistines if I harm them!"

4. Then Samson went and caught three hundred foxes; and he took torches, turned the foxes tail to tail, and put a torch between each pair of tails.

5. When he had set the torches on fire, he let the foxes go into the standing grain of the Philistines, and burned up both the shocks and the standing grain, as well as the vineyards and olive groves.

6. Then the Philistines said, "Who has done this?" And they answered, "Samson, the son-in-law of the Timnite, because he has taken his wife and given her to his companion." So the Philistines came up and burned her and her father with fire.

7. Samson said to them, "Since you would do a thing like this, I will surely take revenge on you, and after that I will cease."

8. So he attacked them hip and thigh with a great slaughter; then he went down and dwelt in the cleft of the rock of Etam.

9. Now the Philistines went up, encamped in Judah, and deployed themselves against Lehi.

10. And the men of Judah said, "Why have you come up against us?" So they answered, "We have come up to arrest Samson, to do to him as he has done to us."

11. Then three thousand men of Judah went down to the cleft of the rock of Etam, and said to Samson, "Do you not know that the Philistines rule over us? What is this you have done to us?" And he said to them, "As they did to me, so I have done to them."

12. But they said to him, "We have come down to arrest you, that we may deliver you into the hand of the Philistines." Then Samson said to them, "Swear to me that you will not kill me yourselves."

13. So they spoke to him, saying, "No, but we will tie you securely and deliver you into their hand; but we will surely not kill you." And they bound him with two new ropes and brought him up from the rock.

14. When he came to Lehi, the Philistines came shouting against him. Then the Spirit of the LORD came mightily upon him; and the ropes that were on his arms became like flax that is burned with fire, and his bonds broke loose from his hands.

15. He found a fresh jawbone of a donkey, reached out his hand and took it, and killed a thousand men with it.

16. Then Samson said: "With the jawbone of a donkey, Heaps upon heaps, With the jawbone of a donkey I have slain a thousand men!"

17. And so it was, when he had finished speaking, that he threw the jawbone from his hand, and called that place Ramath Lehi.

18. Then he became very thirsty; so he cried out to the LORD and said, "You have given this great deliverance by the hand of Your servant; and now shall I die of thirst and fall into the hand of the uncircumcised?"

19. So God split the hollow place that is in Lehi, and water came out, and he drank; and his spirit returned, and he revived. Therefore he called its name En Hakkore, which is in Lehi to this day.

20. And he judged Israel twenty years in the days of the Philistines.

## Chapter 16

1. Now Samson went to Gaza and saw a harlot there, and went in to her.

2. When the Gazites were told, "Samson has come here!" they surrounded the place and lay in wait for him all night at the gate of the city. They were quiet all night, saying, "In the morning, when it is daylight, we will kill him."

3. And Samson lay low till midnight; then he arose at midnight, took hold of the doors of the gate of the city and the two gateposts, pulled them up, bar and all, put them on his shoulders, and carried them to the top of the hill that faces Hebron.

4. Afterward it happened that he loved a woman in the Valley of Sorek, whose name was Delilah.

5. And the lords of the Philistines came up to her and said to her, "Entice him, and find out where his great strength lies, and by what means we may overpower him, that we may bind him to afflict him; and every one of us will give you eleven hundred pieces of silver."

6. So Delilah said to Samson, "Please tell me where your great strength lies, and with what you may be bound to afflict you."

7. And Samson said to her, "If they bind me with seven fresh bowstrings, not yet dried, then I shall become weak, and be like any other man."

8. So the lords of the Philistines brought up to her seven fresh bowstrings, not yet dried, and she bound him with them.

9. Now men were lying in wait, staying with her in the room. And she said to him, "The Philistines are upon you, Samson!" But he broke the bowstrings as a strand of yarn breaks when it touches fire. So the secret of his strength was not known.

10. Then Delilah said to Samson, "Look, you have mocked me and told me lies. Now, please tell me what you may be bound with."

11. So he said to her, "If they bind me securely with new ropes that have never been used, then I shall become weak, and be like any other man."

12. Therefore Delilah took new ropes and bound him with them, and said to him, "The Philistines are upon you, Samson!" And men were lying in wait, staying in the room. But he broke them off his arms like a thread.

13. Delilah said to Samson, "Until now you have mocked me and told me lies. Tell me what you may be bound with." And he said to her, "If you weave the seven locks of my head into the web of the loom"--

14. So she wove it tightly with the batten of the loom, and said to him, "The Philistines are upon you, Samson!" But he awoke from his sleep, and pulled out the batten and the web from the loom.

15. Then she said to him, "How can you say, "I love you,' when your heart is not with me? You have mocked me these three times, and have not told me where your great strength lies."

16. And it came to pass, when she pestered him daily with her words and pressed him, so that his soul was vexed to death,

17. that he told her all his heart, and said to her, "No razor has ever come upon my head, for I have been a Nazirite to God from my mother's womb. If I am shaven, then my strength will leave me, and I shall become weak, and be like any other man."

18. When Delilah saw that he had told her all his heart, she sent and called for the lords of the Philistines, saying, "Come up once more, for he has told me all his heart." So the lords of the Philistines came up to her and brought the money in their hand.

19. Then she lulled him to sleep on her knees, and called for a man and had him shave off the seven locks of his head. Then she began to torment him, and his strength left him.

20. And she said, "The Philistines are upon you, Samson!" So he awoke from his sleep, and said, "I will go out as before, at other times, and shake myself free!" But he did not know that the LORD had departed from him.

21. Then the Philistines took him and put out his eyes, and brought him down to Gaza. They bound him with bronze fetters, and he became a grinder in the prison.

22. However, the hair of his head began to grow again after it had been shaven.

23. Now the lords of the Philistines gathered together to offer a great sacrifice to Dagon their god, and to rejoice. And they said: "Our god has delivered into our hands Samson our enemy!"

24. When the people saw him, they praised their god; for they said: "Our god has delivered into our hands our enemy, The destroyer of our land, And the one who multiplied our dead."

25. So it happened, when their hearts were merry, that they said, "Call for Samson, that he may perform for us." So they called for Samson from the prison, and he performed for them. And they stationed him between the pillars.

26. Then Samson said to the lad who held him by the hand, "Let me feel the pillars which support the temple, so that I can lean on them."

27. Now the temple was full of men and women. All the lords of the Philistines were there--about three thousand men and women on the roof watching while Samson performed.

28. Then Samson called to the LORD, saying, "O Lord GOD, remember me, I pray! Strengthen me, I pray, just this once, O God, that I may with one blow take vengeance on the Philistines for my two eyes!"

29. And Samson took hold of the two middle pillars which supported the temple, and he braced himself against them, one on his right and the other on his left.

30. Then Samson said, "Let me die with the Philistines!" And he pushed with all his might, and the temple fell on the lords and all the people who were in it. So the dead that he killed at his death were more than he had killed in his life.

31. And his brothers and all his father's household came down and took him, and brought him up and buried him between Zorah and Eshtaol in the tomb of his father Manoah. He had judged Israel twenty years.

## Chapter 17

1. Now there was a man from the mountains of Ephraim, whose name was Micah.

2. And he said to his mother, "The eleven hundred shekels of silver that were taken from you, and on which you put a curse, even saying it in my ears--here is the silver with me; I took it." And his mother said, "May you be blessed by the LORD, my son!"

3. So when he had returned the eleven hundred shekels of silver to his mother, his mother said, "I had wholly dedicated the silver from my hand to the LORD for my son, to make a carved image and a molded image; now therefore, I will return it to you."

4. Thus he returned the silver to his mother. Then his mother took two hundred shekels of silver and gave them to the silversmith, and he made it into a carved image and a molded image; and they were in the house of Micah.

5. The man Micah had a shrine, and made an ephod and household idols; and he consecrated one of his sons, who became his priest.

6. In those days there was no king in Israel; everyone did what was right in his own eyes.

7. Now there was a young man from Bethlehem in Judah, of the family of Judah; he was a Levite, and was staying there.

8. The man departed from the city of Bethlehem in Judah to stay wherever he could find a place. Then he came to the mountains of Ephraim, to the house of Micah, as he journeyed.

9. And Micah said to him, "Where do you come from?" So he said to him, "I am a Levite from Bethlehem in Judah, and I am on my way to find a place to stay."

10. Micah said to him, "Dwell with me, and be a father and a priest to me, and I will give you ten shekels of silver per year, a suit of clothes, and your sustenance." So the Levite went in.

11. Then the Levite was content to dwell with the man; and the young man became like one of his sons to him.

12. So Micah consecrated the Levite, and the young man became his priest, and lived in the house of Micah.

13. Then Micah said, "Now I know that the LORD will be good to me, since I have a Levite as priest!"

## Chapter 18

1. In those days there was no king in Israel. And in those days the tribe of the Danites was seeking an inheritance for itself to dwell in; for until that day their inheritance among the tribes of Israel had not fallen to them.

2. So the children of Dan sent five men of their family from their territory, men of valor from Zorah and Eshtaol, to spy out the land and search it. They said to them, "Go, search the land." So they went to the mountains of Ephraim, to the house of Micah, and lodged there.

3. While they were at the house of Micah, they recognized the voice of the young Levite. They turned aside and said to him, "Who brought you here? What are you doing in this place? What do you have here?"

4. He said to them, "Thus and so Micah did for me. He has hired me, and I have become his priest."

5. So they said to him, "Please inquire of God, that we may know whether the journey on which we go will be prosperous."

6. And the priest said to them, "Go in peace. The presence of the LORD be with you on your way."

7. So the five men departed and went to Laish. They saw the people who were there, how they dwelt safely, in the manner of the Sidonians, quiet and secure. There were no rulers in the land who might put them to shame for anything. They were far from the Sidonians, and they had no ties with anyone.

8. Then the spies came back to their brethren at Zorah and Eshtaol, and their brethren said to them, "What is your report?"

9. So they said, "Arise, let us go up against them. For we have seen the land, and indeed it is very good. Would you do nothing? Do not hesitate to go, and enter to possess the land.

10. When you go, you will come to a secure people and a large land. For God has given it into your hands, a place where there is no lack of anything that is on the earth."

11. And six hundred men of the family of the Danites went from there, from Zorah and Eshtaol, armed with weapons of war.

12. Then they went up and encamped in Kirjath Jearim in Judah. (Therefore they call that place Mahaneh Dan to this day. There it is, west of Kirjath Jearim.)

13. And they passed from there to the mountains of Ephraim, and came to the house of Micah.

14. Then the five men who had gone to spy out the country of Laish answered and said to their brethren, "Do you know that there are in these houses an ephod, household idols, a carved image, and a molded image? Now therefore, consider what you should do."

15. So they turned aside there, and came to the house of the young Levite man--to the house of Micah--and greeted him.

16. The six hundred men armed with their weapons of war, who were of the children of Dan, stood by the entrance of the gate.

17. Then the five men who had gone to spy out the land went up. Entering there, they took the carved image, the ephod, the household idols, and the molded image. The priest stood at the entrance of the gate with the six hundred men who were armed with weapons of war.

18. When these went into Micah's house and took the carved image, the ephod, the household idols, and the molded image, the priest said to them, "What are you doing?"

19. And they said to him, "Be quiet, put your hand over your mouth, and come with us; be a father and a priest to us. Is it better for you to be a priest to the household of one man, or that you be a priest to a tribe and a family in Israel?"

20. So the priest's heart was glad; and he took the ephod, the household idols, and the carved image, and took his place among the people.

21. Then they turned and departed, and put the little ones, the livestock, and the goods in front of them.

22. When they were a good way from the house of Micah, the men who were in the houses near Micah's house gathered together and overtook the children of Dan.

23. And they called out to the children of Dan. So they turned around and said to Micah, "What ails you, that you have gathered such a company?"

24. So he said, "You have taken away my gods which I made, and the priest, and you have gone away. Now what more do I have? How can you say to me, "What ails you?"'

25. And the children of Dan said to him, "Do not let your voice be heard among us, lest angry men fall upon you, and you lose your life, with the lives of your household!"

26. Then the children of Dan went their way. And when Micah saw that they were too strong for him, he turned and went back to his house.

27. So they took the things Micah had made, and the priest who had belonged to him, and went to Laish, to a people quiet and secure; and they struck them with the edge of the sword and burned the city with fire.

28. There was no deliverer, because it was far from Sidon, and they had no ties with anyone. It was in the valley that belongs to Beth Rehob. So they rebuilt the city and dwelt there.

29. And they called the name of the city Dan, after the name of Dan their father, who was born to Israel. However, the name of the city formerly was Laish.

30. Then the children of Dan set up for themselves the carved image; and Jonathan the son of Gershom, the son of Manasseh, and his sons were priests to the tribe of Dan until the day of the captivity of the land.

31. So they set up for themselves Micah's carved image which he made, all the time that the house of God was in Shiloh.

## Chapter 19

1. And it came to pass in those days, when there was no king in Israel, that there was a certain Levite staying in the remote mountains of Ephraim. He took for himself a concubine from Bethlehem in Judah.

2. But his concubine played the harlot against him, and went away from him to her father's house at Bethlehem in Judah, and was there four whole months.

3. Then her husband arose and went after her, to speak kindly to her and bring her back, having his servant and a couple of donkeys with him. So she brought him into her father's house; and when the father of the young woman saw him, he was glad to meet him.

4. Now his father-in-law, the young woman's father, detained him; and he stayed with him three days. So they ate and drank and lodged there.

5. Then it came to pass on the fourth day that they arose early in the morning, and he stood to depart; but the young woman's father said to his son-in-law, "Refresh your heart with a morsel of bread, and afterward go your way."

6. So they sat down, and the two of them ate and drank together. Then the young woman's father said to the man, "Please be content to stay all night, and let your heart be merry."

7. And when the man stood to depart, his father-in-law urged him; so he lodged there again.

8. Then he arose early in the morning on the fifth day to depart, but the young woman's father said, "Please refresh your heart." So they delayed until afternoon; and both of them ate.

9. And when the man stood to depart--he and his concubine and his servant--his father-in-law, the young woman's father, said to him, "Look, the day is now drawing toward evening; please spend the night. See, the day is coming to an end; lodge here, that your heart may be merry. Tomorrow go your way early, so that you may get home."

10. However, the man was not willing to spend that night; so he rose and departed, and came opposite Jebus (that is, Jerusalem). With him were the two saddled donkeys; his concubine was also with him.

11. They were near Jebus, and the day was far spent; and the servant said to his master, "Come, please, and let us turn aside into this city of the Jebusites and lodge in it."

12. But his master said to him, "We will not turn aside here into a city of foreigners, who are not of the children of Israel; we will go on to Gibeah."

13. So he said to his servant, "Come, let us draw near to one of these places, and spend the night in Gibeah or in Ramah."

14. And they passed by and went their way; and the sun went down on them near Gibeah, which belongs to Benjamin.

15. They turned aside there to go in to lodge in Gibeah. And when he went in, he sat down in the open square of the city, for no one would take them into his house to spend the night.

16. Just then an old man came in from his work in the field at evening, who also was from the mountains of Ephraim; he was staying in Gibeah, whereas the men of the place were Benjamites.

17. And when he raised his eyes, he saw the traveler in the open square of the city; and the old man said, "Where are you going, and where do you come from?"

18. So he said to him, "We are passing from Bethlehem in Judah toward the remote mountains of Ephraim; I am from there. I went to Bethlehem in Judah; now I am going to the house of the LORD. But there is no one who will take me into his house,

19. although we have both straw and fodder for our donkeys, and bread and wine for myself, for your female servant, and for the young man who is with your servant; there is no lack of anything."

20. And the old man said, "Peace be with you! However, let all your needs be my responsibility; only do not spend the night in the open square."

21. So he brought him into his house, and gave fodder to the donkeys. And they washed their feet, and ate and drank.

22. As they were enjoying themselves, suddenly certain men of the city, perverted men, surrounded the house and beat on the door. They spoke to the master of the house, the old man, saying, "Bring out the man who came to your house, that we may know him carnally!"

23. But the man, the master of the house, went out to them and said to them, "No, my brethren! I beg you, do not act so wickedly! Seeing this man has come into my house, do not commit this outrage.

24. Look, here is my virgin daughter and the man's concubine; let me bring them out now. Humble them, and do with them as you please; but to this man do not do such a vile thing!"

25. But the men would not heed him. So the man took his concubine and brought her out to them. And they knew her and abused her all night until morning; and when the day began to break, they let her go.

26. Then the woman came as the day was dawning, and fell down at the door of the man's house where her master was, till it was light.

27. When her master arose in the morning, and opened the doors of the house and went out to go his way, there was his concubine, fallen at the door of the house with her hands on the threshold.

28. And he said to her, "Get up and let us be going." But there was no answer. So the man lifted her onto the donkey; and the man got up and went to his place.

29. When he entered his house he took a knife, laid hold of his concubine, and divided her into twelve pieces, limb by limb, and sent her throughout all the territory of Israel.

30. And so it was that all who saw it said, "No such deed has been done or seen from the day that the children of Israel came up from the land of Egypt until this day. Consider it, confer, and speak up!"

## Chapter 20

1. So all the children of Israel came out, from Dan to Beersheba, as well as from the land of Gilead, and the congregation gathered together as one man before the LORD at Mizpah.

2. And the leaders of all the people, all the tribes of Israel, presented themselves in the assembly of the people of God, four hundred thousand foot soldiers who drew the sword.

3. (Now the children of Benjamin heard that the children of Israel had gone up to Mizpah.) Then the children of Israel said, "Tell us, how did this wicked deed happen?"

4. So the Levite, the husband of the woman who was murdered, answered and said, "My concubine and I went into Gibeah, which belongs to Benjamin, to spend the night.

5. And the men of Gibeah rose against me, and surrounded the house at night because of me. They intended to kill me, but instead they ravished my concubine so that she died.

6. So I took hold of my concubine, cut her in pieces, and sent her throughout all the territory of the inheritance of Israel, because they committed lewdness and outrage in Israel.

7. Look! All of you are children of Israel; give your advice and counsel here and now!"

8. So all the people arose as one man, saying, "None of us will go to his tent, nor will any turn back to his house;

9. but now this is the thing which we will do to Gibeah: We will go up against it by lot.

10. We will take ten men out of every hundred throughout all the tribes of Israel, a hundred out of every thousand, and a thousand out of every ten thousand, to make provisions for the people, that when they come to Gibeah in Benjamin, they may repay all the vileness that they have done in Israel."

11. So all the men of Israel were gathered against the city, united together as one man.

12. Then the tribes of Israel sent men through all the tribe of Benjamin, saying, "What is this wickedness that has occurred among you?

13. Now therefore, deliver up the men, the perverted men who are in Gibeah, that we may put them to death and remove the evil from Israel!" But the children of Benjamin would not listen to the voice of their brethren, the children of Israel.

14. Instead, the children of Benjamin gathered together from their cities to Gibeah, to go to battle against the children of Israel.

15. And from their cities at that time the children of Benjamin numbered twenty-six thousand men who drew the sword, besides the inhabitants of Gibeah, who numbered seven hundred select men.

16. Among all this people were seven hundred select men who were left-handed; every one could sling a stone at a hair's breadth and not miss.

17. Now besides Benjamin, the men of Israel numbered four hundred thousand men who drew the sword; all of these were men of war.

18. Then the children of Israel arose and went up to the house of God to inquire of God. They said, "Which of us shall go up first to battle against the children of Benjamin?" The LORD said, "Judah first!"

19. So the children of Israel rose in the morning and encamped against Gibeah.

20. And the men of Israel went out to battle against Benjamin, and the men of Israel put themselves in battle array to fight against them at Gibeah.

21. Then the children of Benjamin came out of Gibeah, and on that day cut down to the ground twenty-two thousand men of the Israelites.

22. And the people, that is, the men of Israel, encouraged themselves and again formed the battle line at the place where they had put themselves in array on the first day.

23. Then the children of Israel went up and wept before the LORD until evening, and asked counsel of the LORD, saying, "Shall I again draw near for battle against the children of my brother Benjamin?" And the LORD said, "Go up against him."

24. So the children of Israel approached the children of Benjamin on the second day.

25. And Benjamin went out against them from Gibeah on the second day, and cut down to the ground eighteen thousand more of the children of Israel; all these drew the sword.

26. Then all the children of Israel, that is, all the people, went up and came to the house of God and wept. They sat there before the LORD and fasted that day until evening; and they offered burnt offerings and peace offerings before the LORD.

27. So the children of Israel inquired of the LORD (the ark of the covenant of God was there in those days,

28. and Phinehas the son of Eleazar, the son of Aaron, stood before it in those days), saying, "Shall I yet again go out to battle against the children of my brother Benjamin, or shall I cease?" And the LORD said, "Go up, for tomorrow I will deliver them into your hand."

29. Then Israel set men in ambush all around Gibeah.

30. And the children of Israel went up against the children of Benjamin on the third day, and put themselves in battle array against Gibeah as at the other times.

31. So the children of Benjamin went out against the people, and were drawn away from the city. They began to strike down and kill some of the people, as at the other times, in the highways (one of which goes up to Bethel and the other to Gibeah) and in the field, about thirty men of Israel.

32. And the children of Benjamin said, "They are defeated before us, as at first." But the children of Israel said, "Let us flee and draw them away from the city to the highways."

33. So all the men of Israel rose from their place and put themselves in battle array at Baal Tamar. Then Israel's men in ambush burst forth from their position in the plain of Geba.

34. And ten thousand select men from all Israel came against Gibeah, and the battle was fierce. But the Benjamites did not know that disaster was upon them.

35. The LORD defeated Benjamin before Israel. And the children of Israel destroyed that day twenty-five thousand one hundred Benjamites; all these drew the sword.

36. So the children of Benjamin saw that they were defeated. The men of Israel had given ground to the Benjamites, because they relied on the men in ambush whom they had set against Gibeah.

37. And the men in ambush quickly rushed upon Gibeah; the men in ambush spread out and struck the whole city with the edge of the sword.

38. Now the appointed signal between the men of Israel and the men in ambush was that they would make a great cloud of smoke rise up from the city,

39. whereupon the men of Israel would turn in battle. Now Benjamin had begun to strike and kill about thirty of the men of Israel. For they said, "Surely they are defeated before us, as in the first battle."

40. But when the cloud began to rise from the city in a column of smoke, the Benjamites looked behind them, and there was the whole city going up in smoke to heaven.

41. And when the men of Israel turned back, the men of Benjamin panicked, for they saw that disaster had come upon them.

42. Therefore they turned their backs before the men of Israel in the direction of the wilderness; but the battle overtook them, and whoever came out of the cities they destroyed in their midst.

43. They surrounded the Benjamites, chased them, and easily trampled them down as far as the front of Gibeah toward the east.

44. And eighteen thousand men of Benjamin fell; all these were men of valor.

45. Then they turned and fled toward the wilderness to the rock of Rimmon; and they cut down five thousand of them on the highways. Then they pursued them relentlessly up to Gidom, and killed two thousand of them.

46. So all who fell of Benjamin that day were twenty-five thousand men who drew the sword; all these were men of valor.

47. But six hundred men turned and fled toward the wilderness to the rock of Rimmon, and they stayed at the rock of Rimmon for four months.

48. And the men of Israel turned back against the children of Benjamin, and struck them down with the edge of the sword--from every city, men and beasts, all who were found. They also set fire to all the cities they came to.

## Chapter 21

1. Now the men of Israel had sworn an oath at Mizpah, saying, "None of us shall give his daughter to Benjamin as a wife."

2. Then the people came to the house of God, and remained there before God till evening. They lifted up their voices and wept bitterly,

3. and said, "O LORD God of Israel, why has this come to pass in Israel, that today there should be one tribe missing in Israel?"

4. So it was, on the next morning, that the people rose early and built an altar there, and offered burnt offerings and peace offerings.

5. The children of Israel said, "Who is there among all the tribes of Israel who did not come up with the assembly to the LORD?" For they had made a great oath concerning anyone who had not come up to the LORD at Mizpah, saying, "He shall surely be put to death."

6. And the children of Israel grieved for Benjamin their brother, and said, "One tribe is cut off from Israel today.

7. What shall we do for wives for those who remain, seeing we have sworn by the LORD that we will not give them our daughters as wives?"

8. And they said, "What one is there from the tribes of Israel who did not come up to Mizpah to the LORD?" And, in fact, no one had come to the camp from Jabesh Gilead to the assembly.

9. For when the people were counted, indeed, not one of the inhabitants of Jabesh Gilead was there.

10. So the congregation sent out there twelve thousand of their most valiant men, and commanded them, saying, "Go and strike the inhabitants of Jabesh Gilead with the edge of the sword, including the women and children.

11. And this is the thing that you shall do: You shall utterly destroy every male, and every woman who has known a man intimately."

12. So they found among the inhabitants of Jabesh Gilead four hundred young virgins who had not known a man intimately; and they brought them to the camp at Shiloh, which is in the land of Canaan.

13. Then the whole congregation sent word to the children of Benjamin who were at the rock of Rimmon, and announced peace to them.

14. So Benjamin came back at that time, and they gave them the women whom they had saved alive of the women of Jabesh Gilead; and yet they had not found enough for them.

15. And the people grieved for Benjamin, because the LORD had made a void in the tribes of Israel.

16. Then the elders of the congregation said, "What shall we do for wives for those who remain, since the women of Benjamin have been destroyed?"

17. And they said, "There must be an inheritance for the survivors of Benjamin, that a tribe may not be destroyed from Israel.

18. However, we cannot give them wives from our daughters, for the children of Israel have sworn an oath, saying, "Cursed be the one who gives a wife to Benjamin."'

19. Then they said, "In fact, there is a yearly feast of the LORD in Shiloh, which is north of Bethel, on the east side of the highway that goes up from Bethel to Shechem, and south of Lebonah."

20. Therefore they instructed the children of Benjamin, saying, "Go, lie in wait in the vineyards,

21. and watch; and just when the daughters of Shiloh come out to perform their dances, then come out from the vineyards, and every man catch a wife for himself from the daughters of Shiloh; then go to the land of Benjamin.

22. Then it shall be, when their fathers or their brothers come to us to complain, that we will say to them, "Be kind to them for our sakes, because we did not take a wife for any of them in the war; for it is not as though you have given the women to them at this time, making yourselves guilty of your oath."'

23. And the children of Benjamin did so; they took enough wives for their number from those who danced, whom they caught. Then they went and returned to their inheritance, and they rebuilt the cities and dwelt in them.

24. So the children of Israel departed from there at that time, every man to his tribe and family; they went out from there, every man to his inheritance.

25. In those days there was no king in Israel; everyone did what was right in his own eyes.


# lamentations

## Chapter 1

1. How lonely sits the city That was full of people! How like a widow is she, Who was great among the nations! The princess among the provinces Has become a slave!

2. She weeps bitterly in the night, Her tears are on her cheeks; Among all her lovers She has none to comfort her. All her friends have dealt treacherously with her; They have become her enemies.

3. Judah has gone into captivity, Under affliction and hard servitude; She dwells among the nations, She finds no rest; All her persecutors overtake her in dire straits.

4. The roads to Zion mourn Because no one comes to the set feasts. All her gates are desolate; Her priests sigh, Her virgins are afflicted, And she is in bitterness.

5. Her adversaries have become the master, Her enemies prosper; For the LORD has afflicted her Because of the multitude of her transgressions. Her children have gone into captivity before the enemy.

6. And from the daughter of Zion All her splendor has departed. Her princes have become like deer That find no pasture, That flee without strength Before the pursuer.

7. In the days of her affliction and roaming, Jerusalem remembers all her pleasant things That she had in the days of old. When her people fell into the hand of the enemy, With no one to help her, The adversaries saw her And mocked at her downfall.

8. Jerusalem has sinned gravely, Therefore she has become vile. All who honored her despise her Because they have seen her nakedness; Yes, she sighs and turns away.

9. Her uncleanness is in her skirts; She did not consider her destiny; Therefore her collapse was awesome; She had no comforter. "O LORD, behold my affliction, For the enemy is exalted!"

10. The adversary has spread his hand Over all her pleasant things; For she has seen the nations enter her sanctuary, Those whom You commanded Not to enter Your assembly.

11. All her people sigh, They seek bread; They have given their valuables for food to restore life. "See, O LORD, and consider, For I am scorned."

12. "Is it nothing to you, all you who pass by? Behold and see If there is any sorrow like my sorrow, Which has been brought on me, Which the LORD has inflicted In the day of His fierce anger.

13. "From above He has sent fire into my bones, And it overpowered them; He has spread a net for my feet And turned me back; He has made me desolate And faint all the day.

14. "The yoke of my transgressions was bound; They were woven together by His hands, And thrust upon my neck. He made my strength fail; The Lord delivered me into the hands of those whom I am not able to withstand.

15. "The Lord has trampled underfoot all my mighty men in my midst; He has called an assembly against me To crush my young men; The Lord trampled as in a winepress The virgin daughter of Judah.

16. "For these things I weep; My eye, my eye overflows with water; Because the comforter, who should restore my life, Is far from me. My children are desolate Because the enemy prevailed."

17. Zion spreads out her hands, But no one comforts her; The LORD has commanded concerning Jacob That those around him become his adversaries; Jerusalem has become an unclean thing among them.

18. "The LORD is righteous, For I rebelled against His commandment. Hear now, all peoples, And behold my sorrow; My virgins and my young men Have gone into captivity.

19. "I called for my lovers, But they deceived me; My priests and my elders Breathed their last in the city, While they sought food To restore their life.

20. "See, O LORD, that I am in distress; My soul is troubled; My heart is overturned within me, For I have been very rebellious. Outside the sword bereaves, At home it is like death.

21. "They have heard that I sigh, But no one comforts me. All my enemies have heard of my trouble; They are glad that You have done it. Bring on the day You have announced, That they may become like me.

22. "Let all their wickedness come before You, And do to them as You have done to me For all my transgressions; For my sighs are many, And my heart is faint."

## Chapter 2

1. How the Lord has covered the daughter of Zion With a cloud in His anger! He cast down from heaven to the earth The beauty of Israel, And did not remember His footstool In the day of His anger.

2. The Lord has swallowed up and has not pitied All the dwelling places of Jacob. He has thrown down in His wrath The strongholds of the daughter of Judah; He has brought them down to the ground; He has profaned the kingdom and its princes.

3. He has cut off in fierce anger Every horn of Israel; He has drawn back His right hand From before the enemy. He has blazed against Jacob like a flaming fire Devouring all around.

4. Standing like an enemy, He has bent His bow; With His right hand, like an adversary, He has slain all who were pleasing to His eye; On the tent of the daughter of Zion, He has poured out His fury like fire.

5. The Lord was like an enemy. He has swallowed up Israel, He has swallowed up all her palaces; He has destroyed her strongholds, And has increased mourning and lamentation In the daughter of Judah.

6. He has done violence to His tabernacle, As if it were a garden; He has destroyed His place of assembly; The LORD has caused The appointed feasts and Sabbaths to be forgotten in Zion. In His burning indignation He has spurned the king and the priest.

7. The Lord has spurned His altar, He has abandoned His sanctuary; He has given up the walls of her palaces Into the hand of the enemy. They have made a noise in the house of the LORD As on the day of a set feast.

8. The LORD has purposed to destroy The wall of the daughter of Zion. He has stretched out a line; He has not withdrawn His hand from destroying; Therefore He has caused the rampart and wall to lament; They languished together.

9. Her gates have sunk into the ground; He has destroyed and broken her bars. Her king and her princes are among the nations; The Law is no more, And her prophets find no vision from the LORD.

10. The elders of the daughter of Zion Sit on the ground and keep silence; They throw dust on their heads And gird themselves with sackcloth. The virgins of Jerusalem Bow their heads to the ground.

11. My eyes fail with tears, My heart is troubled; My bile is poured on the ground Because of the destruction of the daughter of my people, Because the children and the infants Faint in the streets of the city.

12. They say to their mothers, "Where is grain and wine?" As they swoon like the wounded In the streets of the city, As their life is poured out In their mothers' bosom.

13. How shall I console you? To what shall I liken you, O daughter of Jerusalem? What shall I compare with you, that I may comfort you, O virgin daughter of Zion? For your ruin is spread wide as the sea; Who can heal you?

14. Your prophets have seen for you False and deceptive visions; They have not uncovered your iniquity, To bring back your captives, But have envisioned for you false prophecies and delusions.

15. All who pass by clap their hands at you; They hiss and shake their heads At the daughter of Jerusalem: "Is this the city that is called "The perfection of beauty, The joy of the whole earth'?"

16. All your enemies have opened their mouth against you; They hiss and gnash their teeth. They say, "We have swallowed her up! Surely this is the day we have waited for; We have found it, we have seen it!|"

17. The LORD has done what He purposed; He has fulfilled His word Which He commanded in days of old. He has thrown down and has not pitied, And He has caused an enemy to rejoice over you; He has exalted the horn of your adversaries.

18. Their heart cried out to the Lord, "O wall of the daughter of Zion, Let tears run down like a river day and night; Give yourself no relief; Give your eyes no rest.

19. "Arise, cry out in the night, At the beginning of the watches; Pour out your heart like water before the face of the Lord. Lift your hands toward Him For the life of your young children, Who faint from hunger at the head of every street."

20. "See, O LORD, and consider! To whom have You done this? Should the women eat their offspring, The children they have cuddled? Should the priest and prophet be slain In the sanctuary of the Lord?

21. "Young and old lie On the ground in the streets; My virgins and my young men Have fallen by the sword; You have slain them in the day of Your anger, You have slaughtered and not pitied.

22. "You have invited as to a feast day The terrors that surround me. In the day of the LORD's anger There was no refugee or survivor. Those whom I have borne and brought up My enemies have destroyed."

## Chapter 3

1. I am the man who has seen affliction by the rod of His wrath.

2. He has led me and made me walk In darkness and not in light.

3. Surely He has turned His hand against me Time and time again throughout the day.

4. He has aged my flesh and my skin, And broken my bones.

5. He has besieged me And surrounded me with bitterness and woe.

6. He has set me in dark places Like the dead of long ago.

7. He has hedged me in so that I cannot get out; He has made my chain heavy.

8. Even when I cry and shout, He shuts out my prayer.

9. He has blocked my ways with hewn stone; He has made my paths crooked.

10. He has been to me a bear lying in wait, Like a lion in ambush.

11. He has turned aside my ways and torn me in pieces; He has made me desolate.

12. He has bent His bow And set me up as a target for the arrow.

13. He has caused the arrows of His quiver To pierce my loins.

14. I have become the ridicule of all my people-- Their taunting song all the day.

15. He has filled me with bitterness, He has made me drink wormwood.

16. He has also broken my teeth with gravel, And covered me with ashes.

17. You have moved my soul far from peace; I have forgotten prosperity.

18. And I said, "My strength and my hope Have perished from the LORD."

19. Remember my affliction and roaming, The wormwood and the gall.

20. My soul still remembers And sinks within me.

21. This I recall to my mind, Therefore I have hope.

22. Through the LORD's mercies we are not consumed, Because His compassions fail not.

23. They are new every morning; Great is Your faithfulness.

24. "The LORD is my portion," says my soul, "Therefore I hope in Him!"

25. The LORD is good to those who wait for Him, To the soul who seeks Him.

26. It is good that one should hope and wait quietly For the salvation of the LORD.

27. It is good for a man to bear The yoke in his youth.

28. Let him sit alone and keep silent, Because God has laid it on him;

29. Let him put his mouth in the dust-- There may yet be hope.

30. Let him give his cheek to the one who strikes him, And be full of reproach.

31. For the Lord will not cast off forever.

32. Though He causes grief, Yet He will show compassion According to the multitude of His mercies.

33. For He does not afflict willingly, Nor grieve the children of men.

34. To crush under one's feet All the prisoners of the earth,

35. To turn aside the justice due a man Before the face of the Most High,

36. Or subvert a man in his cause-- The Lord does not approve.

37. Who is he who speaks and it comes to pass, When the Lord has not commanded it?

38. Is it not from the mouth of the Most High That woe and well-being proceed?

39. Why should a living man complain, A man for the punishment of his sins?

40. Let us search out and examine our ways, And turn back to the LORD;

41. Let us lift our hearts and hands To God in heaven.

42. We have transgressed and rebelled; You have not pardoned.

43. You have covered Yourself with anger And pursued us; You have slain and not pitied.

44. You have covered Yourself with a cloud, That prayer should not pass through.

45. You have made us an offscouring and refuse In the midst of the peoples.

46. All our enemies Have opened their mouths against us.

47. Fear and a snare have come upon us, Desolation and destruction.

48. My eyes overflow with rivers of water For the destruction of the daughter of my people.

49. My eyes flow and do not cease, Without interruption,

50. Till the LORD from heaven Looks down and sees.

51. My eyes bring suffering to my soul Because of all the daughters of my city.

52. My enemies without cause Hunted me down like a bird.

53. They silenced my life in the pit And threw stones at me.

54. The waters flowed over my head; I said, "I am cut off!"

55. I called on Your name, O LORD, From the lowest pit.

56. You have heard my voice: "Do not hide Your ear From my sighing, from my cry for help."

57. You drew near on the day I called on You, And said, "Do not fear!"

58. O Lord, You have pleaded the case for my soul; You have redeemed my life.

59. O LORD, You have seen how I am wronged; Judge my case.

60. You have seen all their vengeance, All their schemes against me.

61. You have heard their reproach, O LORD, All their schemes against me,

62. The lips of my enemies And their whispering against me all the day.

63. Look at their sitting down and their rising up; I am their taunting song.

64. Repay them, O LORD, According to the work of their hands.

65. Give them a veiled heart; Your curse be upon them!

66. In Your anger, Pursue and destroy them From under the heavens of the LORD.

## Chapter 4

1. How the gold has become dim! How changed the fine gold! The stones of the sanctuary are scattered At the head of every street.

2. The precious sons of Zion, Valuable as fine gold, How they are regarded as clay pots, The work of the hands of the potter!

3. Even the jackals present their breasts To nurse their young; But the daughter of my people is cruel, Like ostriches in the wilderness.

4. The tongue of the infant clings To the roof of its mouth for thirst; The young children ask for bread, But no one breaks it for them.

5. Those who ate delicacies Are desolate in the streets; Those who were brought up in scarlet Embrace ash heaps.

6. The punishment of the iniquity of the daughter of my people Is greater than the punishment of the sin of Sodom, Which was overthrown in a moment, With no hand to help her!

7. Her Nazirites were brighter than snow And whiter than milk; They were more ruddy in body than rubies, Like sapphire in their appearance.

8. Now their appearance is blacker than soot; They go unrecognized in the streets; Their skin clings to their bones, It has become as dry as wood.

9. Those slain by the sword are better off Than those who die of hunger; For these pine away, Stricken for lack of the fruits of the field.

10. The hands of the compassionate women Have cooked their own children; They became food for them In the destruction of the daughter of my people.

11. The LORD has fulfilled His fury, He has poured out His fierce anger. He kindled a fire in Zion, And it has devoured its foundations.

12. The kings of the earth, And all inhabitants of the world, Would not have believed That the adversary and the enemy Could enter the gates of Jerusalem--

13. Because of the sins of her prophets And the iniquities of her priests, Who shed in her midst The blood of the just.

14. They wandered blind in the streets; They have defiled themselves with blood, So that no one would touch their garments.

15. They cried out to them, "Go away, unclean! Go away, go away, Do not touch us!" When they fled and wandered, Those among the nations said, "They shall no longer dwell here."

16. The face of the LORD scattered them; He no longer regards them. The people do not respect the priests Nor show favor to the elders.

17. Still our eyes failed us, Watching vainly for our help; In our watching we watched For a nation that could not save us.

18. They tracked our steps So that we could not walk in our streets. Our end was near; Our days were over, For our end had come.

19. Our pursuers were swifter Than the eagles of the heavens. They pursued us on the mountains And lay in wait for us in the wilderness.

20. The breath of our nostrils, the anointed of the LORD, Was caught in their pits, Of whom we said, "Under his shadow We shall live among the nations."

21. Rejoice and be glad, O daughter of Edom, You who dwell in the land of Uz! The cup shall also pass over to you And you shall become drunk and make yourself naked.

22. The punishment of your iniquity is accomplished, O daughter of Zion; He will no longer send you into captivity. He will punish your iniquity, O daughter of Edom; He will uncover your sins!

## Chapter 5

1. Remember, O LORD, what has come upon us; Look, and behold our reproach!

2. Our inheritance has been turned over to aliens, And our houses to foreigners.

3. We have become orphans and waifs, Our mothers are like widows.

4. We pay for the water we drink, And our wood comes at a price.

5. They pursue at our heels; We labor and have no rest.

6. We have given our hand to the Egyptians And the Assyrians, to be satisfied with bread.

7. Our fathers sinned and are no more, But we bear their iniquities.

8. Servants rule over us; There is none to deliver us from their hand.

9. We get our bread at the risk of our lives, Because of the sword in the wilderness.

10. Our skin is hot as an oven, Because of the fever of famine.

11. They ravished the women in Zion, The maidens in the cities of Judah.

12. Princes were hung up by their hands, And elders were not respected.

13. Young men ground at the millstones; Boys staggered under loads of wood.

14. The elders have ceased gathering at the gate, And the young men from their music.

15. The joy of our heart has ceased; Our dance has turned into mourning.

16. The crown has fallen from our head. Woe to us, for we have sinned!

17. Because of this our heart is faint; Because of these things our eyes grow dim;

18. Because of Mount Zion which is desolate, With foxes walking about on it.

19. You, O LORD, remain forever; Your throne from generation to generation.

20. Why do You forget us forever, And forsake us for so long a time?

21. Turn us back to You, O LORD, and we will be restored; Renew our days as of old,

22. Unless You have utterly rejected us, And are very angry with us!


# leviticus

## Chapter 1

1. Now the LORD called to Moses, and spoke to him from the tabernacle of meeting, saying,

2. "Speak to the children of Israel, and say to them: "When any one of you brings an offering to the LORD, you shall bring your offering of the livestock--of the herd and of the flock.

3. "If his offering is a burnt sacrifice of the herd, let him offer a male without blemish; he shall offer it of his own free will at the door of the tabernacle of meeting before the LORD.

4. Then he shall put his hand on the head of the burnt offering, and it will be accepted on his behalf to make atonement for him.

5. He shall kill the bull before the LORD; and the priests, Aaron's sons, shall bring the blood and sprinkle the blood all around on the altar that is by the door of the tabernacle of meeting.

6. And he shall skin the burnt offering and cut it into its pieces.

7. The sons of Aaron the priest shall put fire on the altar, and lay the wood in order on the fire.

8. Then the priests, Aaron's sons, shall lay the parts, the head, and the fat in order on the wood that is on the fire upon the altar;

9. but he shall wash its entrails and its legs with water. And the priest shall burn all on the altar as a burnt sacrifice, an offering made by fire, a sweet aroma to the LORD.

10. "If his offering is of the flocks--of the sheep or of the goats--as a burnt sacrifice, he shall bring a male without blemish.

11. He shall kill it on the north side of the altar before the LORD; and the priests, Aaron's sons, shall sprinkle its blood all around on the altar.

12. And he shall cut it into its pieces, with its head and its fat; and the priest shall lay them in order on the wood that is on the fire upon the altar;

13. but he shall wash the entrails and the legs with water. Then the priest shall bring it all and burn it on the altar; it is a burnt sacrifice, an offering made by fire, a sweet aroma to the LORD.

14. "And if the burnt sacrifice of his offering to the LORD is of birds, then he shall bring his offering of turtledoves or young pigeons.

15. The priest shall bring it to the altar, wring off its head, and burn it on the altar; its blood shall be drained out at the side of the altar.

16. And he shall remove its crop with its feathers and cast it beside the altar on the east side, into the place for ashes.

17. Then he shall split it at its wings, but shall not divide it completely; and the priest shall burn it on the altar, on the wood that is on the fire. It is a burnt sacrifice, an offering made by fire, a sweet aroma to the LORD.

## Chapter 2

1. "When anyone offers a grain offering to the LORD, his offering shall be of fine flour. And he shall pour oil on it, and put frankincense on it.

2. He shall bring it to Aaron's sons, the priests, one of whom shall take from it his handful of fine flour and oil with all the frankincense. And the priest shall burn it as a memorial on the altar, an offering made by fire, a sweet aroma to the LORD.

3. The rest of the grain offering shall be Aaron's and his sons'. It is most holy of the offerings to the LORD made by fire.

4. "And if you bring as an offering a grain offering baked in the oven, it shall be unleavened cakes of fine flour mixed with oil, or unleavened wafers anointed with oil.

5. But if your offering is a grain offering baked in a pan, it shall be of fine flour, unleavened, mixed with oil.

6. You shall break it in pieces and pour oil on it; it is a grain offering.

7. "If your offering is a grain offering baked in a covered pan, it shall be made of fine flour with oil.

8. You shall bring the grain offering that is made of these things to the LORD. And when it is presented to the priest, he shall bring it to the altar.

9. Then the priest shall take from the grain offering a memorial portion, and burn it on the altar. It is an offering made by fire, a sweet aroma to the LORD.

10. And what is left of the grain offering shall be Aaron's and his sons'. It is most holy of the offerings to the LORD made by fire.

11. "No grain offering which you bring to the LORD shall be made with leaven, for you shall burn no leaven nor any honey in any offering to the LORD made by fire.

12. As for the offering of the firstfruits, you shall offer them to the LORD, but they shall not be burned on the altar for a sweet aroma.

13. And every offering of your grain offering you shall season with salt; you shall not allow the salt of the covenant of your God to be lacking from your grain offering. With all your offerings you shall offer salt.

14. "If you offer a grain offering of your firstfruits to the LORD, you shall offer for the grain offering of your firstfruits green heads of grain roasted on the fire, grain beaten from full heads.

15. And you shall put oil on it, and lay frankincense on it. It is a grain offering.

16. Then the priest shall burn the memorial portion: part of its beaten grain and part of its oil, with all the frankincense, as an offering made by fire to the LORD.

## Chapter 3

1. "When his offering is a sacrifice of a peace offering, if he offers it of the herd, whether male or female, he shall offer it without blemish before the LORD.

2. And he shall lay his hand on the head of his offering, and kill it at the door of the tabernacle of meeting; and Aaron's sons, the priests, shall sprinkle the blood all around on the altar.

3. Then he shall offer from the sacrifice of the peace offering an offering made by fire to the LORD. The fat that covers the entrails and all the fat that is on the entrails,

4. the two kidneys and the fat that is on them by the flanks, and the fatty lobe attached to the liver above the kidneys, he shall remove;

5. and Aaron's sons shall burn it on the altar upon the burnt sacrifice, which is on the wood that is on the fire, as an offering made by fire, a sweet aroma to the LORD.

6. "If his offering as a sacrifice of a peace offering to the LORD is of the flock, whether male or female, he shall offer it without blemish.

7. If he offers a lamb as his offering, then he shall offer it before the LORD.

8. And he shall lay his hand on the head of his offering, and kill it before the tabernacle of meeting; and Aaron's sons shall sprinkle its blood all around on the altar.

9. "Then he shall offer from the sacrifice of the peace offering, as an offering made by fire to the LORD, its fat and the whole fat tail which he shall remove close to the backbone. And the fat that covers the entrails and all the fat that is on the entrails,

10. the two kidneys and the fat that is on them by the flanks, and the fatty lobe attached to the liver above the kidneys, he shall remove;

11. and the priest shall burn them on the altar as food, an offering made by fire to the LORD.

12. "And if his offering is a goat, then he shall offer it before the LORD.

13. He shall lay his hand on its head and kill it before the tabernacle of meeting; and the sons of Aaron shall sprinkle its blood all around on the altar.

14. Then he shall offer from it his offering, as an offering made by fire to the LORD. The fat that covers the entrails and all the fat that is on the entrails,

15. the two kidneys and the fat that is on them by the flanks, and the fatty lobe attached to the liver above the kidneys, he shall remove;

16. and the priest shall burn them on the altar as food, an offering made by fire for a sweet aroma; all the fat is the LORD's.

17. "This shall be a perpetual statute throughout your generations in all your dwellings: you shall eat neither fat nor blood."'

## Chapter 4

1. Now the LORD spoke to Moses, saying,

2. "Speak to the children of Israel, saying: "If a person sins unintentionally against any of the commandments of the LORD in anything which ought not to be done, and does any of them,

3. if the anointed priest sins, bringing guilt on the people, then let him offer to the LORD for his sin which he has sinned a young bull without blemish as a sin offering.

4. He shall bring the bull to the door of the tabernacle of meeting before the LORD, lay his hand on the bull's head, and kill the bull before the LORD.

5. Then the anointed priest shall take some of the bull's blood and bring it to the tabernacle of meeting.

6. The priest shall dip his finger in the blood and sprinkle some of the blood seven times before the LORD, in front of the veil of the sanctuary.

7. And the priest shall put some of the blood on the horns of the altar of sweet incense before the LORD, which is in the tabernacle of meeting; and he shall pour the remaining blood of the bull at the base of the altar of the burnt offering, which is at the door of the tabernacle of meeting.

8. He shall take from it all the fat of the bull as the sin offering. The fat that covers the entrails and all the fat which is on the entrails,

9. the two kidneys and the fat that is on them by the flanks, and the fatty lobe attached to the liver above the kidneys, he shall remove,

10. as it was taken from the bull of the sacrifice of the peace offering; and the priest shall burn them on the altar of the burnt offering.

11. But the bull's hide and all its flesh, with its head and legs, its entrails and offal--

12. the whole bull he shall carry outside the camp to a clean place, where the ashes are poured out, and burn it on wood with fire; where the ashes are poured out it shall be burned.

13. "Now if the whole congregation of Israel sins unintentionally, and the thing is hidden from the eyes of the assembly, and they have done something against any of the commandments of the LORD in anything which should not be done, and are guilty;

14. when the sin which they have committed becomes known, then the assembly shall offer a young bull for the sin, and bring it before the tabernacle of meeting.

15. And the elders of the congregation shall lay their hands on the head of the bull before the LORD. Then the bull shall be killed before the LORD.

16. The anointed priest shall bring some of the bull's blood to the tabernacle of meeting.

17. Then the priest shall dip his finger in the blood and sprinkle it seven times before the LORD, in front of the veil.

18. And he shall put some of the blood on the horns of the altar which is before the LORD, which is in the tabernacle of meeting; and he shall pour the remaining blood at the base of the altar of burnt offering, which is at the door of the tabernacle of meeting.

19. He shall take all the fat from it and burn it on the altar.

20. And he shall do with the bull as he did with the bull as a sin offering; thus he shall do with it. So the priest shall make atonement for them, and it shall be forgiven them.

21. Then he shall carry the bull outside the camp, and burn it as he burned the first bull. It is a sin offering for the assembly.

22. "When a ruler has sinned, and done something unintentionally against any of the commandments of the LORD his God in anything which should not be done, and is guilty,

23. or if his sin which he has committed comes to his knowledge, he shall bring as his offering a kid of the goats, a male without blemish.

24. And he shall lay his hand on the head of the goat, and kill it at the place where they kill the burnt offering before the LORD. It is a sin offering.

25. The priest shall take some of the blood of the sin offering with his finger, put it on the horns of the altar of burnt offering, and pour its blood at the base of the altar of burnt offering.

26. And he shall burn all its fat on the altar, like the fat of the sacrifice of the peace offering. So the priest shall make atonement for him concerning his sin, and it shall be forgiven him.

27. "If anyone of the common people sins unintentionally by doing something against any of the commandments of the LORD in anything which ought not to be done, and is guilty,

28. or if his sin which he has committed comes to his knowledge, then he shall bring as his offering a kid of the goats, a female without blemish, for his sin which he has committed.

29. And he shall lay his hand on the head of the sin offering, and kill the sin offering at the place of the burnt offering.

30. Then the priest shall take some of its blood with his finger, put it on the horns of the altar of burnt offering, and pour all the remaining blood at the base of the altar.

31. He shall remove all its fat, as fat is removed from the sacrifice of the peace offering; and the priest shall burn it on the altar for a sweet aroma to the LORD. So the priest shall make atonement for him, and it shall be forgiven him.

32. "If he brings a lamb as his sin offering, he shall bring a female without blemish.

33. Then he shall lay his hand on the head of the sin offering, and kill it as a sin offering at the place where they kill the burnt offering.

34. The priest shall take some of the blood of the sin offering with his finger, put it on the horns of the altar of burnt offering, and pour all the remaining blood at the base of the altar.

35. He shall remove all its fat, as the fat of the lamb is removed from the sacrifice of the peace offering. Then the priest shall burn it on the altar, according to the offerings made by fire to the LORD. So the priest shall make atonement for his sin that he has committed, and it shall be forgiven him.

## Chapter 5

1. "If a person sins in hearing the utterance of an oath, and is a witness, whether he has seen or known of the matter--if he does not tell it, he bears guilt.

2. "Or if a person touches any unclean thing, whether it is the carcass of an unclean beast, or the carcass of unclean livestock, or the carcass of unclean creeping things, and he is unaware of it, he also shall be unclean and guilty.

3. Or if he touches human uncleanness--whatever uncleanness with which a man may be defiled, and he is unaware of it--when he realizes it, then he shall be guilty.

4. "Or if a person swears, speaking thoughtlessly with his lips to do evil or to do good, whatever it is that a man may pronounce by an oath, and he is unaware of it--when he realizes it, then he shall be guilty in any of these matters.

5. "And it shall be, when he is guilty in any of these matters, that he shall confess that he has sinned in that thing;

6. and he shall bring his trespass offering to the LORD for his sin which he has committed, a female from the flock, a lamb or a kid of the goats as a sin offering. So the priest shall make atonement for him concerning his sin.

7. "If he is not able to bring a lamb, then he shall bring to the LORD, for his trespass which he has committed, two turtledoves or two young pigeons: one as a sin offering and the other as a burnt offering.

8. And he shall bring them to the priest, who shall offer that which is for the sin offering first, and wring off its head from its neck, but shall not divide it completely.

9. Then he shall sprinkle some of the blood of the sin offering on the side of the altar, and the rest of the blood shall be drained out at the base of the altar. It is a sin offering.

10. And he shall offer the second as a burnt offering according to the prescribed manner. So the priest shall make atonement on his behalf for his sin which he has committed, and it shall be forgiven him.

11. "But if he is not able to bring two turtledoves or two young pigeons, then he who sinned shall bring for his offering one-tenth of an ephah of fine flour as a sin offering. He shall put no oil on it, nor shall he put frankincense on it, for it is a sin offering.

12. Then he shall bring it to the priest, and the priest shall take his handful of it as a memorial portion, and burn it on the altar according to the offerings made by fire to the LORD. It is a sin offering.

13. The priest shall make atonement for him, for his sin that he has committed in any of these matters; and it shall be forgiven him. The rest shall be the priest's as a grain offering."'

14. Then the LORD spoke to Moses, saying:

15. "If a person commits a trespass, and sins unintentionally in regard to the holy things of the LORD, then he shall bring to the LORD as his trespass offering a ram without blemish from the flocks, with your valuation in shekels of silver according to the shekel of the sanctuary, as a trespass offering.

16. And he shall make restitution for the harm that he has done in regard to the holy thing, and shall add one-fifth to it and give it to the priest. So the priest shall make atonement for him with the ram of the trespass offering, and it shall be forgiven him.

17. "If a person sins, and commits any of these things which are forbidden to be done by the commandments of the LORD, though he does not know it, yet he is guilty and shall bear his iniquity.

18. And he shall bring to the priest a ram without blemish from the flock, with your valuation, as a trespass offering. So the priest shall make atonement for him regarding his ignorance in which he erred and did not know it, and it shall be forgiven him.

19. It is a trespass offering; he has certainly trespassed against the LORD."

## Chapter 6

1. And the LORD spoke to Moses, saying:

2. "If a person sins and commits a trespass against the LORD by lying to his neighbor about what was delivered to him for safekeeping, or about a pledge, or about a robbery, or if he has extorted from his neighbor,

3. or if he has found what was lost and lies concerning it, and swears falsely--in any one of these things that a man may do in which he sins:

4. then it shall be, because he has sinned and is guilty, that he shall restore what he has stolen, or the thing which he has extorted, or what was delivered to him for safekeeping, or the lost thing which he found,

5. or all that about which he has sworn falsely. He shall restore its full value, add one-fifth more to it, and give it to whomever it belongs, on the day of his trespass offering.

6. And he shall bring his trespass offering to the LORD, a ram without blemish from the flock, with your valuation, as a trespass offering, to the priest.

7. So the priest shall make atonement for him before the LORD, and he shall be forgiven for any one of these things that he may have done in which he trespasses."

8. Then the LORD spoke to Moses, saying,

9. "Command Aaron and his sons, saying, "This is the law of the burnt offering: The burnt offering shall be on the hearth upon the altar all night until morning, and the fire of the altar shall be kept burning on it.

10. And the priest shall put on his linen garment, and his linen trousers he shall put on his body, and take up the ashes of the burnt offering which the fire has consumed on the altar, and he shall put them beside the altar.

11. Then he shall take off his garments, put on other garments, and carry the ashes outside the camp to a clean place.

12. And the fire on the altar shall be kept burning on it; it shall not be put out. And the priest shall burn wood on it every morning, and lay the burnt offering in order on it; and he shall burn on it the fat of the peace offerings.

13. A fire shall always be burning on the altar; it shall never go out.

14. "This is the law of the grain offering: The sons of Aaron shall offer it on the altar before the LORD.

15. He shall take from it his handful of the fine flour of the grain offering, with its oil, and all the frankincense which is on the grain offering, and shall burn it on the altar for a sweet aroma, as a memorial to the LORD.

16. And the remainder of it Aaron and his sons shall eat; with unleavened bread it shall be eaten in a holy place; in the court of the tabernacle of meeting they shall eat it.

17. It shall not be baked with leaven. I have given it as their portion of My offerings made by fire; it is most holy, like the sin offering and the trespass offering.

18. All the males among the children of Aaron may eat it. It shall be a statute forever in your generations concerning the offerings made by fire to the LORD. Everyone who touches them must be holy."'

19. And the LORD spoke to Moses, saying,

20. "This is the offering of Aaron and his sons, which they shall offer to the LORD, beginning on the day when he is anointed: one-tenth of an ephah of fine flour as a daily grain offering, half of it in the morning and half of it at night.

21. It shall be made in a pan with oil. When it is mixed, you shall bring it in. The baked pieces of the grain offering you shall offer for a sweet aroma to the LORD.

22. The priest from among his sons, who is anointed in his place, shall offer it. It is a statute forever to the LORD. It shall be wholly burned.

23. For every grain offering for the priest shall be wholly burned. It shall not be eaten."

24. Also the LORD spoke to Moses, saying,

25. "Speak to Aaron and to his sons, saying, "This is the law of the sin offering: In the place where the burnt offering is killed, the sin offering shall be killed before the LORD. It is most holy.

26. The priest who offers it for sin shall eat it. In a holy place it shall be eaten, in the court of the tabernacle of meeting.

27. Everyone who touches its flesh must be holy. And when its blood is sprinkled on any garment, you shall wash that on which it was sprinkled, in a holy place.

28. But the earthen vessel in which it is boiled shall be broken. And if it is boiled in a bronze pot, it shall be both scoured and rinsed in water.

29. All the males among the priests may eat it. It is most holy.

30. But no sin offering from which any of the blood is brought into the tabernacle of meeting, to make atonement in the holy place, shall be eaten. It shall be burned in the fire.

## Chapter 7

1. "Likewise this is the law of the trespass offering (it is most holy):

2. In the place where they kill the burnt offering they shall kill the trespass offering. And its blood he shall sprinkle all around on the altar.

3. And he shall offer from it all its fat. The fat tail and the fat that covers the entrails,

4. the two kidneys and the fat that is on them by the flanks, and the fatty lobe attached to the liver above the kidneys, he shall remove;

5. and the priest shall burn them on the altar as an offering made by fire to the LORD. It is a trespass offering.

6. Every male among the priests may eat it. It shall be eaten in a holy place. It is most holy.

7. The trespass offering is like the sin offering; there is one law for them both: the priest who makes atonement with it shall have it.

8. And the priest who offers anyone's burnt offering, that priest shall have for himself the skin of the burnt offering which he has offered.

9. Also every grain offering that is baked in the oven and all that is prepared in the covered pan, or in a pan, shall be the priest's who offers it.

10. Every grain offering, whether mixed with oil or dry, shall belong to all the sons of Aaron, to one as much as the other.

11. "This is the law of the sacrifice of peace offerings which he shall offer to the LORD:

12. If he offers it for a thanksgiving, then he shall offer, with the sacrifice of thanksgiving, unleavened cakes mixed with oil, unleavened wafers anointed with oil, or cakes of blended flour mixed with oil.

13. Besides the cakes, as his offering he shall offer leavened bread with the sacrifice of thanksgiving of his peace offering.

14. And from it he shall offer one cake from each offering as a heave offering to the LORD. It shall belong to the priest who sprinkles the blood of the peace offering.

15. "The flesh of the sacrifice of his peace offering for thanksgiving shall be eaten the same day it is offered. He shall not leave any of it until morning.

16. But if the sacrifice of his offering is a vow or a voluntary offering, it shall be eaten the same day that he offers his sacrifice; but on the next day the remainder of it also may be eaten;

17. the remainder of the flesh of the sacrifice on the third day must be burned with fire.

18. And if any of the flesh of the sacrifice of his peace offering is eaten at all on the third day, it shall not be accepted, nor shall it be imputed to him; it shall be an abomination to him who offers it, and the person who eats of it shall bear guilt.

19. "The flesh that touches any unclean thing shall not be eaten. It shall be burned with fire. And as for the clean flesh, all who are clean may eat of it.

20. But the person who eats the flesh of the sacrifice of the peace offering that belongs to the LORD, while he is unclean, that person shall be cut off from his people.

21. Moreover the person who touches any unclean thing, such as human uncleanness, an unclean animal, or any abominable unclean thing, and who eats the flesh of the sacrifice of the peace offering that belongs to the LORD, that person shall be cut off from his people."'

22. And the LORD spoke to Moses, saying,

23. "Speak to the children of Israel, saying: "You shall not eat any fat, of ox or sheep or goat.

24. And the fat of an animal that dies naturally, and the fat of what is torn by wild beasts, may be used in any other way; but you shall by no means eat it.

25. For whoever eats the fat of the animal of which men offer an offering made by fire to the LORD, the person who eats it shall be cut off from his people.

26. Moreover you shall not eat any blood in any of your dwellings, whether of bird or beast.

27. Whoever eats any blood, that person shall be cut off from his people."'

28. Then the LORD spoke to Moses, saying,

29. "Speak to the children of Israel, saying: "He who offers the sacrifice of his peace offering to the LORD shall bring his offering to the LORD from the sacrifice of his peace offering.

30. His own hands shall bring the offerings made by fire to the LORD. The fat with the breast he shall bring, that the breast may be waved as a wave offering before the LORD.

31. And the priest shall burn the fat on the altar, but the breast shall be Aaron's and his sons'.

32. Also the right thigh you shall give to the priest as a heave offering from the sacrifices of your peace offerings.

33. He among the sons of Aaron, who offers the blood of the peace offering and the fat, shall have the right thigh for his part.

34. For the breast of the wave offering and the thigh of the heave offering I have taken from the children of Israel, from the sacrifices of their peace offerings, and I have given them to Aaron the priest and to his sons from the children of Israel by a statute forever."'

35. This is the consecrated portion for Aaron and his sons, from the offerings made by fire to the LORD, on the day when Moses presented them to minister to the LORD as priests.

36. The LORD commanded this to be given to them by the children of Israel, on the day that He anointed them, by a statute forever throughout their generations.

37. This is the law of the burnt offering, the grain offering, the sin offering, the trespass offering, the consecrations, and the sacrifice of the peace offering,

38. which the LORD commanded Moses on Mount Sinai, on the day when He commanded the children of Israel to offer their offerings to the LORD in the Wilderness of Sinai.

## Chapter 8

1. And the LORD spoke to Moses, saying:

2. "Take Aaron and his sons with him, and the garments, the anointing oil, a bull as the sin offering, two rams, and a basket of unleavened bread;

3. and gather all the congregation together at the door of the tabernacle of meeting."

4. So Moses did as the LORD commanded him. And the congregation was gathered together at the door of the tabernacle of meeting.

5. And Moses said to the congregation, "This is what the LORD commanded to be done."

6. Then Moses brought Aaron and his sons and washed them with water.

7. And he put the tunic on him, girded him with the sash, clothed him with the robe, and put the ephod on him; and he girded him with the intricately woven band of the ephod, and with it tied the ephod on him.

8. Then he put the breastplate on him, and he put the Urim and the Thummim in the breastplate.

9. And he put the turban on his head. Also on the turban, on its front, he put the golden plate, the holy crown, as the LORD had commanded Moses.

10. Also Moses took the anointing oil, and anointed the tabernacle and all that was in it, and consecrated them.

11. He sprinkled some of it on the altar seven times, anointed the altar and all its utensils, and the laver and its base, to consecrate them.

12. And he poured some of the anointing oil on Aaron's head and anointed him, to consecrate him.

13. Then Moses brought Aaron's sons and put tunics on them, girded them with sashes, and put hats on them, as the LORD had commanded Moses.

14. And he brought the bull for the sin offering. Then Aaron and his sons laid their hands on the head of the bull for the sin offering,

15. and Moses killed it. Then he took the blood, and put some on the horns of the altar all around with his finger, and purified the altar. And he poured the blood at the base of the altar, and consecrated it, to make atonement for it.

16. Then he took all the fat that was on the entrails, the fatty lobe attached to the liver, and the two kidneys with their fat, and Moses burned them on the altar.

17. But the bull, its hide, its flesh, and its offal, he burned with fire outside the camp, as the LORD had commanded Moses.

18. Then he brought the ram as the burnt offering. And Aaron and his sons laid their hands on the head of the ram,

19. and Moses killed it. Then he sprinkled the blood all around on the altar.

20. And he cut the ram into pieces; and Moses burned the head, the pieces, and the fat.

21. Then he washed the entrails and the legs in water. And Moses burned the whole ram on the altar. It was a burnt sacrifice for a sweet aroma, an offering made by fire to the LORD, as the LORD had commanded Moses.

22. And he brought the second ram, the ram of consecration. Then Aaron and his sons laid their hands on the head of the ram,

23. and Moses killed it. Also he took some of its blood and put it on the tip of Aaron's right ear, on the thumb of his right hand, and on the big toe of his right foot.

24. Then he brought Aaron's sons. And Moses put some of the blood on the tips of their right ears, on the thumbs of their right hands, and on the big toes of their right feet. And Moses sprinkled the blood all around on the altar.

25. Then he took the fat and the fat tail, all the fat that was on the entrails, the fatty lobe attached to the liver, the two kidneys and their fat, and the right thigh;

26. and from the basket of unleavened bread that was before the LORD he took one unleavened cake, a cake of bread anointed with oil, and one wafer, and put them on the fat and on the right thigh;

27. and he put all these in Aaron's hands and in his sons' hands, and waved them as a wave offering before the LORD.

28. Then Moses took them from their hands and burned them on the altar, on the burnt offering. They were consecration offerings for a sweet aroma. That was an offering made by fire to the LORD.

29. And Moses took the breast and waved it as a wave offering before the LORD. It was Moses' part of the ram of consecration, as the LORD had commanded Moses.

30. Then Moses took some of the anointing oil and some of the blood which was on the altar, and sprinkled it on Aaron, on his garments, on his sons, and on the garments of his sons with him; and he consecrated Aaron, his garments, his sons, and the garments of his sons with him.

31. And Moses said to Aaron and his sons, "Boil the flesh at the door of the tabernacle of meeting, and eat it there with the bread that is in the basket of consecration offerings, as I commanded, saying, "Aaron and his sons shall eat it.'

32. What remains of the flesh and of the bread you shall burn with fire.

33. And you shall not go outside the door of the tabernacle of meeting for seven days, until the days of your consecration are ended. For seven days he shall consecrate you.

34. As he has done this day, so the LORD has commanded to do, to make atonement for you.

35. Therefore you shall stay at the door of the tabernacle of meeting day and night for seven days, and keep the charge of the LORD, so that you may not die; for so I have been commanded."

36. So Aaron and his sons did all the things that the LORD had commanded by the hand of Moses.

## Chapter 9

1. It came to pass on the eighth day that Moses called Aaron and his sons and the elders of Israel.

2. And he said to Aaron, "Take for yourself a young bull as a sin offering and a ram as a burnt offering, without blemish, and offer them before the LORD.

3. And to the children of Israel you shall speak, saying, "Take a kid of the goats as a sin offering, and a calf and a lamb, both of the first year, without blemish, as a burnt offering,

4. also a bull and a ram as peace offerings, to sacrifice before the LORD, and a grain offering mixed with oil; for today the LORD will appear to you."'

5. So they brought what Moses commanded before the tabernacle of meeting. And all the congregation drew near and stood before the LORD.

6. Then Moses said, "This is the thing which the LORD commanded you to do, and the glory of the LORD will appear to you."

7. And Moses said to Aaron, "Go to the altar, offer your sin offering and your burnt offering, and make atonement for yourself and for the people. Offer the offering of the people, and make atonement for them, as the LORD commanded."

8. Aaron therefore went to the altar and killed the calf of the sin offering, which was for himself.

9. Then the sons of Aaron brought the blood to him. And he dipped his finger in the blood, put it on the horns of the altar, and poured the blood at the base of the altar.

10. But the fat, the kidneys, and the fatty lobe from the liver of the sin offering he burned on the altar, as the LORD had commanded Moses.

11. The flesh and the hide he burned with fire outside the camp.

12. And he killed the burnt offering; and Aaron's sons presented to him the blood, which he sprinkled all around on the altar.

13. Then they presented the burnt offering to him, with its pieces and head, and he burned them on the altar.

14. And he washed the entrails and the legs, and burned them with the burnt offering on the altar.

15. Then he brought the people's offering, and took the goat, which was the sin offering for the people, and killed it and offered it for sin, like the first one.

16. And he brought the burnt offering and offered it according to the prescribed manner.

17. Then he brought the grain offering, took a handful of it, and burned it on the altar, besides the burnt sacrifice of the morning.

18. He also killed the bull and the ram as sacrifices of peace offerings, which were for the people. And Aaron's sons presented to him the blood, which he sprinkled all around on the altar,

19. and the fat from the bull and the ram--the fatty tail, what covers the entrails and the kidneys, and the fatty lobe attached to the liver;

20. and they put the fat on the breasts. Then he burned the fat on the altar;

21. but the breasts and the right thigh Aaron waved as a wave offering before the LORD, as Moses had commanded.

22. Then Aaron lifted his hand toward the people, blessed them, and came down from offering the sin offering, the burnt offering, and peace offerings.

23. And Moses and Aaron went into the tabernacle of meeting, and came out and blessed the people. Then the glory of the LORD appeared to all the people,

24. and fire came out from before the LORD and consumed the burnt offering and the fat on the altar. When all the people saw it, they shouted and fell on their faces.

## Chapter 10

1. Then Nadab and Abihu, the sons of Aaron, each took his censer and put fire in it, put incense on it, and offered profane fire before the LORD, which He had not commanded them.

2. So fire went out from the LORD and devoured them, and they died before the LORD.

3. And Moses said to Aaron, "This is what the LORD spoke, saying: "By those who come near Me I must be regarded as holy; And before all the people I must be glorified."' So Aaron held his peace.

4. Then Moses called Mishael and Elzaphan, the sons of Uzziel the uncle of Aaron, and said to them, "Come near, carry your brethren from before the sanctuary out of the camp."

5. So they went near and carried them by their tunics out of the camp, as Moses had said.

6. And Moses said to Aaron, and to Eleazar and Ithamar, his sons, "Do not uncover your heads nor tear your clothes, lest you die, and wrath come upon all the people. But let your brethren, the whole house of Israel, bewail the burning which the LORD has kindled.

7. You shall not go out from the door of the tabernacle of meeting, lest you die, for the anointing oil of the LORD is upon you." And they did according to the word of Moses.

8. Then the LORD spoke to Aaron, saying:

9. "Do not drink wine or intoxicating drink, you, nor your sons with you, when you go into the tabernacle of meeting, lest you die. It shall be a statute forever throughout your generations,

10. that you may distinguish between holy and unholy, and between unclean and clean,

11. and that you may teach the children of Israel all the statutes which the LORD has spoken to them by the hand of Moses."

12. And Moses spoke to Aaron, and to Eleazar and Ithamar, his sons who were left: "Take the grain offering that remains of the offerings made by fire to the LORD, and eat it without leaven beside the altar; for it is most holy.

13. You shall eat it in a holy place, because it is your due and your sons' due, of the sacrifices made by fire to the LORD; for so I have been commanded.

14. The breast of the wave offering and the thigh of the heave offering you shall eat in a clean place, you, your sons, and your daughters with you; for they are your due and your sons' due, which are given from the sacrifices of peace offerings of the children of Israel.

15. The thigh of the heave offering and the breast of the wave offering they shall bring with the offerings of fat made by fire, to offer as a wave offering before the LORD. And it shall be yours and your sons' with you, by a statute forever, as the LORD has commanded."

16. Then Moses made careful inquiry about the goat of the sin offering, and there it was--burned up. And he was angry with Eleazar and Ithamar, the sons of Aaron who were left, saying,

17. "Why have you not eaten the sin offering in a holy place, since it is most holy, and God has given it to you to bear the guilt of the congregation, to make atonement for them before the LORD?

18. See! Its blood was not brought inside the holy place; indeed you should have eaten it in a holy place, as I commanded."

19. And Aaron said to Moses, "Look, this day they have offered their sin offering and their burnt offering before the LORD, and such things have befallen me! If I had eaten the sin offering today, would it have been accepted in the sight of the LORD?"

20. So when Moses heard that, he was content.

## Chapter 11

1. Now the LORD spoke to Moses and Aaron, saying to them,

2. "Speak to the children of Israel, saying, "These are the animals which you may eat among all the animals that are on the earth:

3. Among the animals, whatever divides the hoof, having cloven hooves and chewing the cud--that you may eat.

4. Nevertheless these you shall not eat among those that chew the cud or those that have cloven hooves: the camel, because it chews the cud but does not have cloven hooves, is unclean to you;

5. the rock hyrax, because it chews the cud but does not have cloven hooves, is unclean to you;

6. the hare, because it chews the cud but does not have cloven hooves, is unclean to you;

7. and the swine, though it divides the hoof, having cloven hooves, yet does not chew the cud, is unclean to you.

8. Their flesh you shall not eat, and their carcasses you shall not touch. They are unclean to you.

9. "These you may eat of all that are in the water: whatever in the water has fins and scales, whether in the seas or in the rivers--that you may eat.

10. But all in the seas or in the rivers that do not have fins and scales, all that move in the water or any living thing which is in the water, they are an abomination to you.

11. They shall be an abomination to you; you shall not eat their flesh, but you shall regard their carcasses as an abomination.

12. Whatever in the water does not have fins or scales--that shall be an abomination to you.

13. "And these you shall regard as an abomination among the birds; they shall not be eaten, they are an abomination: the eagle, the vulture, the buzzard,

14. the kite, and the falcon after its kind;

15. every raven after its kind,

16. the ostrich, the short-eared owl, the sea gull, and the hawk after its kind;

17. the little owl, the fisher owl, and the screech owl;

18. the white owl, the jackdaw, and the carrion vulture;

19. the stork, the heron after its kind, the hoopoe, and the bat.

20. "All flying insects that creep on all fours shall be an abomination to you.

21. Yet these you may eat of every flying insect that creeps on all fours: those which have jointed legs above their feet with which to leap on the earth.

22. These you may eat: the locust after its kind, the destroying locust after its kind, the cricket after its kind, and the grasshopper after its kind.

23. But all other flying insects which have four feet shall be an abomination to you.

24. "By these you shall become unclean; whoever touches the carcass of any of them shall be unclean until evening;

25. whoever carries part of the carcass of any of them shall wash his clothes and be unclean until evening:

26. The carcass of any animal which divides the foot, but is not cloven-hoofed or does not chew the cud, is unclean to you. Everyone who touches it shall be unclean.

27. And whatever goes on its paws, among all kinds of animals that go on all fours, those are unclean to you. Whoever touches any such carcass shall be unclean until evening.

28. Whoever carries any such carcass shall wash his clothes and be unclean until evening. It is unclean to you.

29. "These also shall be unclean to you among the creeping things that creep on the earth: the mole, the mouse, and the large lizard after its kind;

30. the gecko, the monitor lizard, the sand reptile, the sand lizard, and the chameleon.

31. These are unclean to you among all that creep. Whoever touches them when they are dead shall be unclean until evening.

32. Anything on which any of them falls, when they are dead shall be unclean, whether it is any item of wood or clothing or skin or sack, whatever item it is, in which any work is done, it must be put in water. And it shall be unclean until evening; then it shall be clean.

33. Any earthen vessel into which any of them falls you shall break; and whatever is in it shall be unclean:

34. in such a vessel, any edible food upon which water falls becomes unclean, and any drink that may be drunk from it becomes unclean.

35. And everything on which a part of any such carcass falls shall be unclean; whether it is an oven or cooking stove, it shall be broken down; for they are unclean, and shall be unclean to you.

36. Nevertheless a spring or a cistern, in which there is plenty of water, shall be clean, but whatever touches any such carcass becomes unclean.

37. And if a part of any such carcass falls on any planting seed which is to be sown, it remains clean.

38. But if water is put on the seed, and if a part of any such carcass falls on it, it becomes unclean to you.

39. "And if any animal which you may eat dies, he who touches its carcass shall be unclean until evening.

40. He who eats of its carcass shall wash his clothes and be unclean until evening. He also who carries its carcass shall wash his clothes and be unclean until evening.

41. "And every creeping thing that creeps on the earth shall be an abomination. It shall not be eaten.

42. Whatever crawls on its belly, whatever goes on all fours, or whatever has many feet among all creeping things that creep on the earth--these you shall not eat, for they are an abomination.

43. You shall not make yourselves abominable with any creeping thing that creeps; nor shall you make yourselves unclean with them, lest you be defiled by them.

44. For I am the LORD your God. You shall therefore consecrate yourselves, and you shall be holy; for I am holy. Neither shall you defile yourselves with any creeping thing that creeps on the earth.

45. For I am the LORD who brings you up out of the land of Egypt, to be your God. You shall therefore be holy, for I am holy.

46. "This is the law of the animals and the birds and every living creature that moves in the waters, and of every creature that creeps on the earth,

47. to distinguish between the unclean and the clean, and between the animal that may be eaten and the animal that may not be eaten."'

## Chapter 12

1. Then the LORD spoke to Moses, saying,

2. "Speak to the children of Israel, saying: "If a woman has conceived, and borne a male child, then she shall be unclean seven days; as in the days of her customary impurity she shall be unclean.

3. And on the eighth day the flesh of his foreskin shall be circumcised.

4. She shall then continue in the blood of her purification thirty-three days. She shall not touch any hallowed thing, nor come into the sanctuary until the days of her purification are fulfilled.

5. "But if she bears a female child, then she shall be unclean two weeks, as in her customary impurity, and she shall continue in the blood of her purification sixty-six days.

6. "When the days of her purification are fulfilled, whether for a son or a daughter, she shall bring to the priest a lamb of the first year as a burnt offering, and a young pigeon or a turtledove as a sin offering, to the door of the tabernacle of meeting.

7. Then he shall offer it before the LORD, and make atonement for her. And she shall be clean from the flow of her blood. This is the law for her who has borne a male or a female.

8. "And if she is not able to bring a lamb, then she may bring two turtledoves or two young pigeons--one as a burnt offering and the other as a sin offering. So the priest shall make atonement for her, and she will be clean."'

## Chapter 13

1. And the LORD spoke to Moses and Aaron, saying:

2. "When a man has on the skin of his body a swelling, a scab, or a bright spot, and it becomes on the skin of his body like a leprous sore, then he shall be brought to Aaron the priest or to one of his sons the priests.

3. The priest shall examine the sore on the skin of the body; and if the hair on the sore has turned white, and the sore appears to be deeper than the skin of his body, it is a leprous sore. Then the priest shall examine him, and pronounce him unclean.

4. But if the bright spot is white on the skin of his body, and does not appear to be deeper than the skin, and its hair has not turned white, then the priest shall isolate the one who has the sore seven days.

5. And the priest shall examine him on the seventh day; and indeed if the sore appears to be as it was, and the sore has not spread on the skin, then the priest shall isolate him another seven days.

6. Then the priest shall examine him again on the seventh day; and indeed if the sore has faded, and the sore has not spread on the skin, then the priest shall pronounce him clean; it is only a scab, and he shall wash his clothes and be clean.

7. But if the scab should at all spread over the skin, after he has been seen by the priest for his cleansing, he shall be seen by the priest again.

8. And if the priest sees that the scab has indeed spread on the skin, then the priest shall pronounce him unclean. It is leprosy.

9. "When the leprous sore is on a person, then he shall be brought to the priest.

10. And the priest shall examine him; and indeed if the swelling on the skin is white, and it has turned the hair white, and there is a spot of raw flesh in the swelling,

11. it is an old leprosy on the skin of his body. The priest shall pronounce him unclean, and shall not isolate him, for he is unclean.

12. "And if leprosy breaks out all over the skin, and the leprosy covers all the skin of the one who has the sore, from his head to his foot, wherever the priest looks,

13. then the priest shall consider; and indeed if the leprosy has covered all his body, he shall pronounce him clean who has the sore. It has all turned white. He is clean.

14. But when raw flesh appears on him, he shall be unclean.

15. And the priest shall examine the raw flesh and pronounce him to be unclean; for the raw flesh is unclean. It is leprosy.

16. Or if the raw flesh changes and turns white again, he shall come to the priest.

17. And the priest shall examine him; and indeed if the sore has turned white, then the priest shall pronounce him clean who has the sore. He is clean.

18. "If the body develops a boil in the skin, and it is healed,

19. and in the place of the boil there comes a white swelling or a bright spot, reddish-white, then it shall be shown to the priest;

20. and if, when the priest sees it, it indeed appears deeper than the skin, and its hair has turned white, the priest shall pronounce him unclean. It is a leprous sore which has broken out of the boil.

21. But if the priest examines it, and indeed there are no white hairs in it, and it is not deeper than the skin, but has faded, then the priest shall isolate him seven days;

22. and if it should at all spread over the skin, then the priest shall pronounce him unclean. It is a leprous sore.

23. But if the bright spot stays in one place, and has not spread, it is the scar of the boil; and the priest shall pronounce him clean.

24. "Or if the body receives a burn on its skin by fire, and the raw flesh of the burn becomes a bright spot, reddish-white or white,

25. then the priest shall examine it; and indeed if the hair of the bright spot has turned white, and it appears deeper than the skin, it is leprosy broken out in the burn. Therefore the priest shall pronounce him unclean. It is a leprous sore.

26. But if the priest examines it, and indeed there are no white hairs in the bright spot, and it is not deeper than the skin, but has faded, then the priest shall isolate him seven days.

27. And the priest shall examine him on the seventh day. If it has at all spread over the skin, then the priest shall pronounce him unclean. It is a leprous sore.

28. But if the bright spot stays in one place, and has not spread on the skin, but has faded, it is a swelling from the burn. The priest shall pronounce him clean, for it is the scar from the burn.

29. "If a man or woman has a sore on the head or the beard,

30. then the priest shall examine the sore; and indeed if it appears deeper than the skin, and there is in it thin yellow hair, then the priest shall pronounce him unclean. It is a scaly leprosy of the head or beard.

31. But if the priest examines the scaly sore, and indeed it does not appear deeper than the skin, and there is no black hair in it, then the priest shall isolate the one who has the scale seven days.

32. And on the seventh day the priest shall examine the sore; and indeed if the scale has not spread, and there is no yellow hair in it, and the scale does not appear deeper than the skin,

33. he shall shave himself, but the scale he shall not shave. And the priest shall isolate the one who has the scale another seven days.

34. On the seventh day the priest shall examine the scale; and indeed if the scale has not spread over the skin, and does not appear deeper than the skin, then the priest shall pronounce him clean. He shall wash his clothes and be clean.

35. But if the scale should at all spread over the skin after his cleansing,

36. then the priest shall examine him; and indeed if the scale has spread over the skin, the priest need not seek for yellow hair. He is unclean.

37. But if the scale appears to be at a standstill, and there is black hair grown up in it, the scale has healed. He is clean, and the priest shall pronounce him clean.

38. "If a man or a woman has bright spots on the skin of the body, specifically white bright spots,

39. then the priest shall look; and indeed if the bright spots on the skin of the body are dull white, it is a white spot that grows on the skin. He is clean.

40. "As for the man whose hair has fallen from his head, he is bald, but he is clean.

41. He whose hair has fallen from his forehead, he is bald on the forehead, but he is clean.

42. And if there is on the bald head or bald forehead a reddish-white sore, it is leprosy breaking out on his bald head or his bald forehead.

43. Then the priest shall examine it; and indeed if the swelling of the sore is reddish-white on his bald head or on his bald forehead, as the appearance of leprosy on the skin of the body,

44. he is a leprous man. He is unclean. The priest shall surely pronounce him unclean; his sore is on his head.

45. "Now the leper on whom the sore is, his clothes shall be torn and his head bare; and he shall cover his mustache, and cry, "Unclean! Unclean!'

46. He shall be unclean. All the days he has the sore he shall be unclean. He is unclean, and he shall dwell alone; his dwelling shall be outside the camp.

47. "Also, if a garment has a leprous plague in it, whether it is a woolen garment or a linen garment,

48. whether it is in the warp or woof of linen or wool, whether in leather or in anything made of leather,

49. and if the plague is greenish or reddish in the garment or in the leather, whether in the warp or in the woof, or in anything made of leather, it is a leprous plague and shall be shown to the priest.

50. The priest shall examine the plague and isolate that which has the plague seven days.

51. And he shall examine the plague on the seventh day. If the plague has spread in the garment, either in the warp or in the woof, in the leather or in anything made of leather, the plague is an active leprosy. It is unclean.

52. He shall therefore burn that garment in which is the plague, whether warp or woof, in wool or in linen, or anything of leather, for it is an active leprosy; the garment shall be burned in the fire.

53. "But if the priest examines it, and indeed the plague has not spread in the garment, either in the warp or in the woof, or in anything made of leather,

54. then the priest shall command that they wash the thing in which is the plague; and he shall isolate it another seven days.

55. Then the priest shall examine the plague after it has been washed; and indeed if the plague has not changed its color, though the plague has not spread, it is unclean, and you shall burn it in the fire; it continues eating away, whether the damage is outside or inside.

56. If the priest examines it, and indeed the plague has faded after washing it, then he shall tear it out of the garment, whether out of the warp or out of the woof, or out of the leather.

57. But if it appears again in the garment, either in the warp or in the woof, or in anything made of leather, it is a spreading plague; you shall burn with fire that in which is the plague.

58. And if you wash the garment, either warp or woof, or whatever is made of leather, if the plague has disappeared from it, then it shall be washed a second time, and shall be clean.

59. "This is the law of the leprous plague in a garment of wool or linen, either in the warp or woof, or in anything made of leather, to pronounce it clean or to pronounce it unclean."

## Chapter 14

1. Then the LORD spoke to Moses, saying,

2. "This shall be the law of the leper for the day of his cleansing: He shall be brought to the priest.

3. And the priest shall go out of the camp, and the priest shall examine him; and indeed, if the leprosy is healed in the leper,

4. then the priest shall command to take for him who is to be cleansed two living and clean birds, cedar wood, scarlet, and hyssop.

5. And the priest shall command that one of the birds be killed in an earthen vessel over running water.

6. As for the living bird, he shall take it, the cedar wood and the scarlet and the hyssop, and dip them and the living bird in the blood of the bird that was killed over the running water.

7. And he shall sprinkle it seven times on him who is to be cleansed from the leprosy, and shall pronounce him clean, and shall let the living bird loose in the open field.

8. He who is to be cleansed shall wash his clothes, shave off all his hair, and wash himself in water, that he may be clean. After that he shall come into the camp, and shall stay outside his tent seven days.

9. But on the seventh day he shall shave all the hair off his head and his beard and his eyebrows--all his hair he shall shave off. He shall wash his clothes and wash his body in water, and he shall be clean.

10. "And on the eighth day he shall take two male lambs without blemish, one ewe lamb of the first year without blemish, three-tenths of an ephah of fine flour mixed with oil as a grain offering, and one log of oil.

11. Then the priest who makes him clean shall present the man who is to be made clean, and those things, before the LORD, at the door of the tabernacle of meeting.

12. And the priest shall take one male lamb and offer it as a trespass offering, and the log of oil, and wave them as a wave offering before the LORD.

13. Then he shall kill the lamb in the place where he kills the sin offering and the burnt offering, in a holy place; for as the sin offering is the priest's, so is the trespass offering. It is most holy.

14. The priest shall take some of the blood of the trespass offering, and the priest shall put it on the tip of the right ear of him who is to be cleansed, on the thumb of his right hand, and on the big toe of his right foot.

15. And the priest shall take some of the log of oil, and pour it into the palm of his own left hand.

16. Then the priest shall dip his right finger in the oil that is in his left hand, and shall sprinkle some of the oil with his finger seven times before the LORD.

17. And of the rest of the oil in his hand, the priest shall put some on the tip of the right ear of him who is to be cleansed, on the thumb of his right hand, and on the big toe of his right foot, on the blood of the trespass offering.

18. The rest of the oil that is in the priest's hand he shall put on the head of him who is to be cleansed. So the priest shall make atonement for him before the LORD.

19. "Then the priest shall offer the sin offering, and make atonement for him who is to be cleansed from his uncleanness. Afterward he shall kill the burnt offering.

20. And the priest shall offer the burnt offering and the grain offering on the altar. So the priest shall make atonement for him, and he shall be clean.

21. "But if he is poor and cannot afford it, then he shall take one male lamb as a trespass offering to be waved, to make atonement for him, one-tenth of an ephah of fine flour mixed with oil as a grain offering, a log of oil,

22. and two turtledoves or two young pigeons, such as he is able to afford: one shall be a sin offering and the other a burnt offering.

23. He shall bring them to the priest on the eighth day for his cleansing, to the door of the tabernacle of meeting, before the LORD.

24. And the priest shall take the lamb of the trespass offering and the log of oil, and the priest shall wave them as a wave offering before the LORD.

25. Then he shall kill the lamb of the trespass offering, and the priest shall take some of the blood of the trespass offering and put it on the tip of the right ear of him who is to be cleansed, on the thumb of his right hand, and on the big toe of his right foot.

26. And the priest shall pour some of the oil into the palm of his own left hand.

27. Then the priest shall sprinkle with his right finger some of the oil that is in his left hand seven times before the LORD.

28. And the priest shall put some of the oil that is in his hand on the tip of the right ear of him who is to be cleansed, on the thumb of the right hand, and on the big toe of his right foot, on the place of the blood of the trespass offering.

29. The rest of the oil that is in the priest's hand he shall put on the head of him who is to be cleansed, to make atonement for him before the LORD.

30. And he shall offer one of the turtledoves or young pigeons, such as he can afford--

31. such as he is able to afford, the one as a sin offering and the other as a burnt offering, with the grain offering. So the priest shall make atonement for him who is to be cleansed before the LORD.

32. This is the law for one who had a leprous sore, who cannot afford the usual cleansing."

33. And the LORD spoke to Moses and Aaron, saying:

34. "When you have come into the land of Canaan, which I give you as a possession, and I put the leprous plague in a house in the land of your possession,

35. and he who owns the house comes and tells the priest, saying, "It seems to me that there is some plague in the house,'

36. then the priest shall command that they empty the house, before the priest goes into it to examine the plague, that all that is in the house may not be made unclean; and afterward the priest shall go in to examine the house.

37. And he shall examine the plague; and indeed if the plague is on the walls of the house with ingrained streaks, greenish or reddish, which appear to be deep in the wall,

38. then the priest shall go out of the house, to the door of the house, and shut up the house seven days.

39. And the priest shall come again on the seventh day and look; and indeed if the plague has spread on the walls of the house,

40. then the priest shall command that they take away the stones in which is the plague, and they shall cast them into an unclean place outside the city.

41. And he shall cause the house to be scraped inside, all around, and the dust that they scrape off they shall pour out in an unclean place outside the city.

42. Then they shall take other stones and put them in the place of those stones, and he shall take other mortar and plaster the house.

43. "Now if the plague comes back and breaks out in the house, after he has taken away the stones, after he has scraped the house, and after it is plastered,

44. then the priest shall come and look; and indeed if the plague has spread in the house, it is an active leprosy in the house. It is unclean.

45. And he shall break down the house, its stones, its timber, and all the plaster of the house, and he shall carry them outside the city to an unclean place.

46. Moreover he who goes into the house at all while it is shut up shall be unclean until evening.

47. And he who lies down in the house shall wash his clothes, and he who eats in the house shall wash his clothes.

48. "But if the priest comes in and examines it, and indeed the plague has not spread in the house after the house was plastered, then the priest shall pronounce the house clean, because the plague is healed.

49. And he shall take, to cleanse the house, two birds, cedar wood, scarlet, and hyssop.

50. Then he shall kill one of the birds in an earthen vessel over running water;

51. and he shall take the cedar wood, the hyssop, the scarlet, and the living bird, and dip them in the blood of the slain bird and in the running water, and sprinkle the house seven times.

52. And he shall cleanse the house with the blood of the bird and the running water and the living bird, with the cedar wood, the hyssop, and the scarlet.

53. Then he shall let the living bird loose outside the city in the open field, and make atonement for the house, and it shall be clean.

54. "This is the law for any leprous sore and scale,

55. for the leprosy of a garment and of a house,

56. for a swelling and a scab and a bright spot,

57. to teach when it is unclean and when it is clean. This is the law of leprosy."

## Chapter 15

1. And the LORD spoke to Moses and Aaron, saying,

2. "Speak to the children of Israel, and say to them: "When any man has a discharge from his body, his discharge is unclean.

3. And this shall be his uncleanness in regard to his discharge--whether his body runs with his discharge, or his body is stopped up by his discharge, it is his uncleanness.

4. Every bed is unclean on which he who has the discharge lies, and everything on which he sits shall be unclean.

5. And whoever touches his bed shall wash his clothes and bathe in water, and be unclean until evening.

6. He who sits on anything on which he who has the discharge sat shall wash his clothes and bathe in water, and be unclean until evening.

7. And he who touches the body of him who has the discharge shall wash his clothes and bathe in water, and be unclean until evening.

8. If he who has the discharge spits on him who is clean, then he shall wash his clothes and bathe in water, and be unclean until evening.

9. Any saddle on which he who has the discharge rides shall be unclean.

10. Whoever touches anything that was under him shall be unclean until evening. He who carries any of those things shall wash his clothes and bathe in water, and be unclean until evening.

11. And whomever the one who has the discharge touches, and has not rinsed his hands in water, he shall wash his clothes and bathe in water, and be unclean until evening.

12. The vessel of earth that he who has the discharge touches shall be broken, and every vessel of wood shall be rinsed in water.

13. "And when he who has a discharge is cleansed of his discharge, then he shall count for himself seven days for his cleansing, wash his clothes, and bathe his body in running water; then he shall be clean.

14. On the eighth day he shall take for himself two turtledoves or two young pigeons, and come before the LORD, to the door of the tabernacle of meeting, and give them to the priest.

15. Then the priest shall offer them, the one as a sin offering and the other as a burnt offering. So the priest shall make atonement for him before the LORD because of his discharge.

16. "If any man has an emission of semen, then he shall wash all his body in water, and be unclean until evening.

17. And any garment and any leather on which there is semen, it shall be washed with water, and be unclean until evening.

18. Also, when a woman lies with a man, and there is an emission of semen, they shall bathe in water, and be unclean until evening.

19. "If a woman has a discharge, and the discharge from her body is blood, she shall be set apart seven days; and whoever touches her shall be unclean until evening.

20. Everything that she lies on during her impurity shall be unclean; also everything that she sits on shall be unclean.

21. Whoever touches her bed shall wash his clothes and bathe in water, and be unclean until evening.

22. And whoever touches anything that she sat on shall wash his clothes and bathe in water, and be unclean until evening.

23. If anything is on her bed or on anything on which she sits, when he touches it, he shall be unclean until evening.

24. And if any man lies with her at all, so that her impurity is on him, he shall be unclean seven days; and every bed on which he lies shall be unclean.

25. "If a woman has a discharge of blood for many days, other than at the time of her customary impurity, or if it runs beyond her usual time of impurity, all the days of her unclean discharge shall be as the days of her customary impurity. She shall be unclean.

26. Every bed on which she lies all the days of her discharge shall be to her as the bed of her impurity; and whatever she sits on shall be unclean, as the uncleanness of her impurity.

27. Whoever touches those things shall be unclean; he shall wash his clothes and bathe in water, and be unclean until evening.

28. "But if she is cleansed of her discharge, then she shall count for herself seven days, and after that she shall be clean.

29. And on the eighth day she shall take for herself two turtledoves or two young pigeons, and bring them to the priest, to the door of the tabernacle of meeting.

30. Then the priest shall offer the one as a sin offering and the other as a burnt offering, and the priest shall make atonement for her before the LORD for the discharge of her uncleanness.

31. "Thus you shall separate the children of Israel from their uncleanness, lest they die in their uncleanness when they defile My tabernacle that is among them.

32. This is the law for one who has a discharge, and for him who emits semen and is unclean thereby,

33. and for her who is indisposed because of her customary impurity, and for one who has a discharge, either man or woman, and for him who lies with her who is unclean."'

## Chapter 16

1. Now the LORD spoke to Moses after the death of the two sons of Aaron, when they offered profane fire before the LORD, and died;

2. and the LORD said to Moses: "Tell Aaron your brother not to come at just any time into the Holy Place inside the veil, before the mercy seat which is on the ark, lest he die; for I will appear in the cloud above the mercy seat.

3. "Thus Aaron shall come into the Holy Place: with the blood of a young bull as a sin offering, and of a ram as a burnt offering.

4. He shall put the holy linen tunic and the linen trousers on his body; he shall be girded with a linen sash, and with the linen turban he shall be attired. These are holy garments. Therefore he shall wash his body in water, and put them on.

5. And he shall take from the congregation of the children of Israel two kids of the goats as a sin offering, and one ram as a burnt offering.

6. "Aaron shall offer the bull as a sin offering, which is for himself, and make atonement for himself and for his house.

7. He shall take the two goats and present them before the LORD at the door of the tabernacle of meeting.

8. Then Aaron shall cast lots for the two goats: one lot for the LORD and the other lot for the scapegoat.

9. And Aaron shall bring the goat on which the LORD's lot fell, and offer it as a sin offering.

10. But the goat on which the lot fell to be the scapegoat shall be presented alive before the LORD, to make atonement upon it, and to let it go as the scapegoat into the wilderness.

11. "And Aaron shall bring the bull of the sin offering, which is for himself, and make atonement for himself and for his house, and shall kill the bull as the sin offering which is for himself.

12. Then he shall take a censer full of burning coals of fire from the altar before the LORD, with his hands full of sweet incense beaten fine, and bring it inside the veil.

13. And he shall put the incense on the fire before the LORD, that the cloud of incense may cover the mercy seat that is on the Testimony, lest he die.

14. He shall take some of the blood of the bull and sprinkle it with his finger on the mercy seat on the east side; and before the mercy seat he shall sprinkle some of the blood with his finger seven times.

15. "Then he shall kill the goat of the sin offering, which is for the people, bring its blood inside the veil, do with that blood as he did with the blood of the bull, and sprinkle it on the mercy seat and before the mercy seat.

16. So he shall make atonement for the Holy Place, because of the uncleanness of the children of Israel, and because of their transgressions, for all their sins; and so he shall do for the tabernacle of meeting which remains among them in the midst of their uncleanness.

17. There shall be no man in the tabernacle of meeting when he goes in to make atonement in the Holy Place, until he comes out, that he may make atonement for himself, for his household, and for all the assembly of Israel.

18. And he shall go out to the altar that is before the LORD, and make atonement for it, and shall take some of the blood of the bull and some of the blood of the goat, and put it on the horns of the altar all around.

19. Then he shall sprinkle some of the blood on it with his finger seven times, cleanse it, and consecrate it from the uncleanness of the children of Israel.

20. "And when he has made an end of atoning for the Holy Place, the tabernacle of meeting, and the altar, he shall bring the live goat.

21. Aaron shall lay both his hands on the head of the live goat, confess over it all the iniquities of the children of Israel, and all their transgressions, concerning all their sins, putting them on the head of the goat, and shall send it away into the wilderness by the hand of a suitable man.

22. The goat shall bear on itself all their iniquities to an uninhabited land; and he shall release the goat in the wilderness.

23. "Then Aaron shall come into the tabernacle of meeting, shall take off the linen garments which he put on when he went into the Holy Place, and shall leave them there.

24. And he shall wash his body with water in a holy place, put on his garments, come out and offer his burnt offering and the burnt offering of the people, and make atonement for himself and for the people.

25. The fat of the sin offering he shall burn on the altar.

26. And he who released the goat as the scapegoat shall wash his clothes and bathe his body in water, and afterward he may come into the camp.

27. The bull for the sin offering and the goat for the sin offering, whose blood was brought in to make atonement in the Holy Place, shall be carried outside the camp. And they shall burn in the fire their skins, their flesh, and their offal.

28. Then he who burns them shall wash his clothes and bathe his body in water, and afterward he may come into the camp.

29. "This shall be a statute forever for you: In the seventh month, on the tenth day of the month, you shall afflict your souls, and do no work at all, whether a native of your own country or a stranger who dwells among you.

30. For on that day the priest shall make atonement for you, to cleanse you, that you may be clean from all your sins before the LORD.

31. It is a sabbath of solemn rest for you, and you shall afflict your souls. It is a statute forever.

32. And the priest, who is anointed and consecrated to minister as priest in his father's place, shall make atonement, and put on the linen clothes, the holy garments;

33. then he shall make atonement for the Holy Sanctuary, and he shall make atonement for the tabernacle of meeting and for the altar, and he shall make atonement for the priests and for all the people of the assembly.

34. This shall be an everlasting statute for you, to make atonement for the children of Israel, for all their sins, once a year." And he did as the LORD commanded Moses.

## Chapter 17

1. And the LORD spoke to Moses, saying,

2. "Speak to Aaron, to his sons, and to all the children of Israel, and say to them, "This is the thing which the LORD has commanded, saying:

3. "Whatever man of the house of Israel who kills an ox or lamb or goat in the camp, or who kills it outside the camp,

4. and does not bring it to the door of the tabernacle of meeting to offer an offering to the LORD before the tabernacle of the LORD, the guilt of bloodshed shall be imputed to that man. He has shed blood; and that man shall be cut off from among his people,

5. to the end that the children of Israel may bring their sacrifices which they offer in the open field, that they may bring them to the LORD at the door of the tabernacle of meeting, to the priest, and offer them as peace offerings to the LORD.

6. And the priest shall sprinkle the blood on the altar of the LORD at the door of the tabernacle of meeting, and burn the fat for a sweet aroma to the LORD.

7. They shall no more offer their sacrifices to demons, after whom they have played the harlot. This shall be a statute forever for them throughout their generations."'

8. "Also you shall say to them: "Whatever man of the house of Israel, or of the strangers who dwell among you, who offers a burnt offering or sacrifice,

9. and does not bring it to the door of the tabernacle of meeting, to offer it to the LORD, that man shall be cut off from among his people.

10. "And whatever man of the house of Israel, or of the strangers who dwell among you, who eats any blood, I will set My face against that person who eats blood, and will cut him off from among his people.

11. For the life of the flesh is in the blood, and I have given it to you upon the altar to make atonement for your souls; for it is the blood that makes atonement for the soul.'

12. Therefore I said to the children of Israel, "No one among you shall eat blood, nor shall any stranger who dwells among you eat blood.'

13. "Whatever man of the children of Israel, or of the strangers who dwell among you, who hunts and catches any animal or bird that may be eaten, he shall pour out its blood and cover it with dust;

14. for it is the life of all flesh. Its blood sustains its life. Therefore I said to the children of Israel, "You shall not eat the blood of any flesh, for the life of all flesh is its blood. Whoever eats it shall be cut off.'

15. "And every person who eats what died naturally or what was torn by beasts, whether he is a native of your own country or a stranger, he shall both wash his clothes and bathe in water, and be unclean until evening. Then he shall be clean.

16. But if he does not wash them or bathe his body, then he shall bear his guilt."

## Chapter 18

1. Then the LORD spoke to Moses, saying,

2. "Speak to the children of Israel, and say to them: "I am the LORD your God.

3. According to the doings of the land of Egypt, where you dwelt, you shall not do; and according to the doings of the land of Canaan, where I am bringing you, you shall not do; nor shall you walk in their ordinances.

4. You shall observe My judgments and keep My ordinances, to walk in them: I am the LORD your God.

5. You shall therefore keep My statutes and My judgments, which if a man does, he shall live by them: I am the LORD.

6. "None of you shall approach anyone who is near of kin to him, to uncover his nakedness: I am the LORD.

7. The nakedness of your father or the nakedness of your mother you shall not uncover. She is your mother; you shall not uncover her nakedness.

8. The nakedness of your father's wife you shall not uncover; it is your father's nakedness.

9. The nakedness of your sister, the daughter of your father, or the daughter of your mother, whether born at home or elsewhere, their nakedness you shall not uncover.

10. The nakedness of your son's daughter or your daughter's daughter, their nakedness you shall not uncover; for theirs is your own nakedness.

11. The nakedness of your father's wife's daughter, begotten by your father--she is your sister--you shall not uncover her nakedness.

12. You shall not uncover the nakedness of your father's sister; she is near of kin to your father.

13. You shall not uncover the nakedness of your mother's sister, for she is near of kin to your mother.

14. You shall not uncover the nakedness of your father's brother. You shall not approach his wife; she is your aunt.

15. You shall not uncover the nakedness of your daughter-in-law--she is your son's wife--you shall not uncover her nakedness.

16. You shall not uncover the nakedness of your brother's wife; it is your brother's nakedness.

17. You shall not uncover the nakedness of a woman and her daughter, nor shall you take her son's daughter or her daughter's daughter, to uncover her nakedness. They are near of kin to her. It is wickedness.

18. Nor shall you take a woman as a rival to her sister, to uncover her nakedness while the other is alive.

19. "Also you shall not approach a woman to uncover her nakedness as long as she is in her customary impurity.

20. Moreover you shall not lie carnally with your neighbor's wife, to defile yourself with her.

21. And you shall not let any of your descendants pass through the fire to Molech, nor shall you profane the name of your God: I am the LORD.

22. You shall not lie with a male as with a woman. It is an abomination.

23. Nor shall you mate with any animal, to defile yourself with it. Nor shall any woman stand before an animal to mate with it. It is perversion.

24. "Do not defile yourselves with any of these things; for by all these the nations are defiled, which I am casting out before you.

25. For the land is defiled; therefore I visit the punishment of its iniquity upon it, and the land vomits out its inhabitants.

26. You shall therefore keep My statutes and My judgments, and shall not commit any of these abominations, either any of your own nation or any stranger who dwells among you

27. (for all these abominations the men of the land have done, who were before you, and thus the land is defiled),

28. lest the land vomit you out also when you defile it, as it vomited out the nations that were before you.

29. For whoever commits any of these abominations, the persons who commit them shall be cut off from among their people.

30. "Therefore you shall keep My ordinance, so that you do not commit any of these abominable customs which were committed before you, and that you do not defile yourselves by them: I am the LORD your God."'

## Chapter 19

1. And the LORD spoke to Moses, saying,

2. "Speak to all the congregation of the children of Israel, and say to them: "You shall be holy, for I the LORD your God am holy.

3. "Every one of you shall revere his mother and his father, and keep My Sabbaths: I am the LORD your God.

4. "Do not turn to idols, nor make for yourselves molded gods: I am the LORD your God.

5. "And if you offer a sacrifice of a peace offering to the LORD, you shall offer it of your own free will.

6. It shall be eaten the same day you offer it, and on the next day. And if any remains until the third day, it shall be burned in the fire.

7. And if it is eaten at all on the third day, it is an abomination. It shall not be accepted.

8. Therefore everyone who eats it shall bear his iniquity, because he has profaned the hallowed offering of the LORD; and that person shall be cut off from his people.

9. "When you reap the harvest of your land, you shall not wholly reap the corners of your field, nor shall you gather the gleanings of your harvest.

10. And you shall not glean your vineyard, nor shall you gather every grape of your vineyard; you shall leave them for the poor and the stranger: I am the LORD your God.

11. "You shall not steal, nor deal falsely, nor lie to one another.

12. And you shall not swear by My name falsely, nor shall you profane the name of your God: I am the LORD.

13. "You shall not cheat your neighbor, nor rob him. The wages of him who is hired shall not remain with you all night until morning.

14. You shall not curse the deaf, nor put a stumbling block before the blind, but shall fear your God: I am the LORD.

15. "You shall do no injustice in judgment. You shall not be partial to the poor, nor honor the person of the mighty. In righteousness you shall judge your neighbor.

16. You shall not go about as a talebearer among your people; nor shall you take a stand against the life of your neighbor: I am the LORD.

17. "You shall not hate your brother in your heart. You shall surely rebuke your neighbor, and not bear sin because of him.

18. You shall not take vengeance, nor bear any grudge against the children of your people, but you shall love your neighbor as yourself: I am the LORD.

19. "You shall keep My statutes. You shall not let your livestock breed with another kind. You shall not sow your field with mixed seed. Nor shall a garment of mixed linen and wool come upon you.

20. "Whoever lies carnally with a woman who is betrothed to a man as a concubine, and who has not at all been redeemed nor given her freedom, for this there shall be scourging; but they shall not be put to death, because she was not free.

21. And he shall bring his trespass offering to the LORD, to the door of the tabernacle of meeting, a ram as a trespass offering.

22. The priest shall make atonement for him with the ram of the trespass offering before the LORD for his sin which he has committed. And the sin which he has committed shall be forgiven him.

23. "When you come into the land, and have planted all kinds of trees for food, then you shall count their fruit as uncircumcised. Three years it shall be as uncircumcised to you. It shall not be eaten.

24. But in the fourth year all its fruit shall be holy, a praise to the LORD.

25. And in the fifth year you may eat its fruit, that it may yield to you its increase: I am the LORD your God.

26. "You shall not eat anything with the blood, nor shall you practice divination or soothsaying.

27. You shall not shave around the sides of your head, nor shall you disfigure the edges of your beard.

28. You shall not make any cuttings in your flesh for the dead, nor tattoo any marks on you: I am the LORD.

29. "Do not prostitute your daughter, to cause her to be a harlot, lest the land fall into harlotry, and the land become full of wickedness.

30. "You shall keep My Sabbaths and reverence My sanctuary: I am the LORD.

31. "Give no regard to mediums and familiar spirits; do not seek after them, to be defiled by them: I am the LORD your God.

32. "You shall rise before the gray headed and honor the presence of an old man, and fear your God: I am the LORD.

33. "And if a stranger dwells with you in your land, you shall not mistreat him.

34. The stranger who dwells among you shall be to you as one born among you, and you shall love him as yourself; for you were strangers in the land of Egypt: I am the LORD your God.

35. "You shall do no injustice in judgment, in measurement of length, weight, or volume.

36. You shall have honest scales, honest weights, an honest ephah, and an honest hin: I am the LORD your God, who brought you out of the land of Egypt.

37. "Therefore you shall observe all My statutes and all My judgments, and perform them: I am the LORD."'

## Chapter 20

1. Then the LORD spoke to Moses, saying,

2. "Again, you shall say to the children of Israel: "Whoever of the children of Israel, or of the strangers who dwell in Israel, who gives any of his descendants to Molech, he shall surely be put to death. The people of the land shall stone him with stones.

3. I will set My face against that man, and will cut him off from his people, because he has given some of his descendants to Molech, to defile My sanctuary and profane My holy name.

4. And if the people of the land should in any way hide their eyes from the man, when he gives some of his descendants to Molech, and they do not kill him,

5. then I will set My face against that man and against his family; and I will cut him off from his people, and all who prostitute themselves with him to commit harlotry with Molech.

6. "And the person who turns to mediums and familiar spirits, to prostitute himself with them, I will set My face against that person and cut him off from his people.

7. Consecrate yourselves therefore, and be holy, for I am the LORD your God.

8. And you shall keep My statutes, and perform them: I am the LORD who sanctifies you.

9. "For everyone who curses his father or his mother shall surely be put to death. He has cursed his father or his mother. His blood shall be upon him.

10. "The man who commits adultery with another man's wife, he who commits adultery with his neighbor's wife, the adulterer and the adulteress, shall surely be put to death.

11. The man who lies with his father's wife has uncovered his father's nakedness; both of them shall surely be put to death. Their blood shall be upon them.

12. If a man lies with his daughter-in-law, both of them shall surely be put to death. They have committed perversion. Their blood shall be upon them.

13. If a man lies with a male as he lies with a woman, both of them have committed an abomination. They shall surely be put to death. Their blood shall be upon them.

14. If a man marries a woman and her mother, it is wickedness. They shall be burned with fire, both he and they, that there may be no wickedness among you.

15. If a man mates with an animal, he shall surely be put to death, and you shall kill the animal.

16. If a woman approaches any animal and mates with it, you shall kill the woman and the animal. They shall surely be put to death. Their blood is upon them.

17. "If a man takes his sister, his father's daughter or his mother's daughter, and sees her nakedness and she sees his nakedness, it is a wicked thing. And they shall be cut off in the sight of their people. He has uncovered his sister's nakedness. He shall bear his guilt.

18. If a man lies with a woman during her sickness and uncovers her nakedness, he has exposed her flow, and she has uncovered the flow of her blood. Both of them shall be cut off from their people.

19. "You shall not uncover the nakedness of your mother's sister nor of your father's sister, for that would uncover his near of kin. They shall bear their guilt.

20. If a man lies with his uncle's wife, he has uncovered his uncle's nakedness. They shall bear their sin; they shall die childless.

21. If a man takes his brother's wife, it is an unclean thing. He has uncovered his brother's nakedness. They shall be childless.

22. "You shall therefore keep all My statutes and all My judgments, and perform them, that the land where I am bringing you to dwell may not vomit you out.

23. And you shall not walk in the statutes of the nation which I am casting out before you; for they commit all these things, and therefore I abhor them.

24. But I have said to you, "You shall inherit their land, and I will give it to you to possess, a land flowing with milk and honey." I am the LORD your God, who has separated you from the peoples.

25. You shall therefore distinguish between clean animals and unclean, between unclean birds and clean, and you shall not make yourselves abominable by beast or by bird, or by any kind of living thing that creeps on the ground, which I have separated from you as unclean.

26. And you shall be holy to Me, for I the LORD am holy, and have separated you from the peoples, that you should be Mine.

27. "A man or a woman who is a medium, or who has familiar spirits, shall surely be put to death; they shall stone them with stones. Their blood shall be upon them."'

## Chapter 21

1. And the LORD said to Moses, "Speak to the priests, the sons of Aaron, and say to them: "None shall defile himself for the dead among his people,

2. except for his relatives who are nearest to him: his mother, his father, his son, his daughter, and his brother;

3. also his virgin sister who is near to him, who has had no husband, for her he may defile himself.

4. Otherwise he shall not defile himself, being a chief man among his people, to profane himself.

5. "They shall not make any bald place on their heads, nor shall they shave the edges of their beards nor make any cuttings in their flesh.

6. They shall be holy to their God and not profane the name of their God, for they offer the offerings of the LORD made by fire, and the bread of their God; therefore they shall be holy.

7. They shall not take a wife who is a harlot or a defiled woman, nor shall they take a woman divorced from her husband; for the priest is holy to his God.

8. Therefore you shall consecrate him, for he offers the bread of your God. He shall be holy to you, for I the LORD, who sanctify you, am holy.

9. The daughter of any priest, if she profanes herself by playing the harlot, she profanes her father. She shall be burned with fire.

10. "He who is the high priest among his brethren, on whose head the anointing oil was poured and who is consecrated to wear the garments, shall not uncover his head nor tear his clothes;

11. nor shall he go near any dead body, nor defile himself for his father or his mother;

12. nor shall he go out of the sanctuary, nor profane the sanctuary of his God; for the consecration of the anointing oil of his God is upon him: I am the LORD.

13. And he shall take a wife in her virginity.

14. A widow or a divorced woman or a defiled woman or a harlot--these he shall not marry; but he shall take a virgin of his own people as wife.

15. Nor shall he profane his posterity among his people, for I the LORD sanctify him."'

16. And the LORD spoke to Moses, saying,

17. "Speak to Aaron, saying: "No man of your descendants in succeeding generations, who has any defect, may approach to offer the bread of his God.

18. For any man who has a defect shall not approach: a man blind or lame, who has a marred face or any limb too long,

19. a man who has a broken foot or broken hand,

20. or is a hunchback or a dwarf, or a man who has a defect in his eye, or eczema or scab, or is a eunuch.

21. No man of the descendants of Aaron the priest, who has a defect, shall come near to offer the offerings made by fire to the LORD. He has a defect; he shall not come near to offer the bread of his God.

22. He may eat the bread of his God, both the most holy and the holy;

23. only he shall not go near the veil or approach the altar, because he has a defect, lest he profane My sanctuaries; for I the LORD sanctify them."'

24. And Moses told it to Aaron and his sons, and to all the children of Israel.

## Chapter 22

1. Then the LORD spoke to Moses, saying,

2. "Speak to Aaron and his sons, that they separate themselves from the holy things of the children of Israel, and that they do not profane My holy name by what they dedicate to Me: I am the LORD.

3. Say to them: "Whoever of all your descendants throughout your generations, who goes near the holy things which the children of Israel dedicate to the LORD, while he has uncleanness upon him, that person shall be cut off from My presence: I am the LORD.

4. "Whatever man of the descendants of Aaron, who is a leper or has a discharge, shall not eat the holy offerings until he is clean. And whoever touches anything made unclean by a corpse, or a man who has had an emission of semen,

5. or whoever touches any creeping thing by which he would be made unclean, or any person by whom he would become unclean, whatever his uncleanness may be--

6. the person who has touched any such thing shall be unclean until evening, and shall not eat the holy offerings unless he washes his body with water.

7. And when the sun goes down he shall be clean; and afterward he may eat the holy offerings, because it is his food.

8. Whatever dies naturally or is torn by beasts he shall not eat, to defile himself with it: I am the LORD.

9. "They shall therefore keep My ordinance, lest they bear sin for it and die thereby, if they profane it: I the LORD sanctify them.

10. "No outsider shall eat the holy offering; one who dwells with the priest, or a hired servant, shall not eat the holy thing.

11. But if the priest buys a person with his money, he may eat it; and one who is born in his house may eat his food.

12. If the priest's daughter is married to an outsider, she may not eat of the holy offerings.

13. But if the priest's daughter is a widow or divorced, and has no child, and has returned to her father's house as in her youth, she may eat her father's food; but no outsider shall eat it.

14. "And if a man eats the holy offering unintentionally, then he shall restore a holy offering to the priest, and add one-fifth to it.

15. They shall not profane the holy offerings of the children of Israel, which they offer to the LORD,

16. or allow them to bear the guilt of trespass when they eat their holy offerings; for I the LORD sanctify them."'

17. And the LORD spoke to Moses, saying,

18. "Speak to Aaron and his sons, and to all the children of Israel, and say to them: "Whatever man of the house of Israel, or of the strangers in Israel, who offers his sacrifice for any of his vows or for any of his freewill offerings, which they offer to the LORD as a burnt offering--

19. you shall offer of your own free will a male without blemish from the cattle, from the sheep, or from the goats.

20. Whatever has a defect, you shall not offer, for it shall not be acceptable on your behalf.

21. And whoever offers a sacrifice of a peace offering to the LORD, to fulfill his vow, or a freewill offering from the cattle or the sheep, it must be perfect to be accepted; there shall be no defect in it.

22. Those that are blind or broken or maimed, or have an ulcer or eczema or scabs, you shall not offer to the LORD, nor make an offering by fire of them on the altar to the LORD.

23. Either a bull or a lamb that has any limb too long or too short you may offer as a freewill offering, but for a vow it shall not be accepted.

24. "You shall not offer to the LORD what is bruised or crushed, or torn or cut; nor shall you make any offering of them in your land.

25. Nor from a foreigner's hand shall you offer any of these as the bread of your God, because their corruption is in them, and defects are in them. They shall not be accepted on your behalf."'

26. And the LORD spoke to Moses, saying:

27. "When a bull or a sheep or a goat is born, it shall be seven days with its mother; and from the eighth day and thereafter it shall be accepted as an offering made by fire to the LORD.

28. Whether it is a cow or ewe, do not kill both her and her young on the same day.

29. And when you offer a sacrifice of thanksgiving to the LORD, offer it of your own free will.

30. On the same day it shall be eaten; you shall leave none of it until morning: I am the LORD.

31. "Therefore you shall keep My commandments, and perform them: I am the LORD.

32. You shall not profane My holy name, but I will be hallowed among the children of Israel. I am the LORD who sanctifies you,

33. who brought you out of the land of Egypt, to be your God: I am the LORD."

## Chapter 23

1. And the LORD spoke to Moses, saying,

2. "Speak to the children of Israel, and say to them: "The feasts of the LORD, which you shall proclaim to be holy convocations, these are My feasts.

3. "Six days shall work be done, but the seventh day is a Sabbath of solemn rest, a holy convocation. You shall do no work on it; it is the Sabbath of the LORD in all your dwellings.

4. "These are the feasts of the LORD, holy convocations which you shall proclaim at their appointed times.

5. On the fourteenth day of the first month at twilight is the LORD's Passover.

6. And on the fifteenth day of the same month is the Feast of Unleavened Bread to the LORD; seven days you must eat unleavened bread.

7. On the first day you shall have a holy convocation; you shall do no customary work on it.

8. But you shall offer an offering made by fire to the LORD for seven days. The seventh day shall be a holy convocation; you shall do no customary work on it."'

9. And the LORD spoke to Moses, saying,

10. "Speak to the children of Israel, and say to them: "When you come into the land which I give to you, and reap its harvest, then you shall bring a sheaf of the firstfruits of your harvest to the priest.

11. He shall wave the sheaf before the LORD, to be accepted on your behalf; on the day after the Sabbath the priest shall wave it.

12. And you shall offer on that day, when you wave the sheaf, a male lamb of the first year, without blemish, as a burnt offering to the LORD.

13. Its grain offering shall be two-tenths of an ephah of fine flour mixed with oil, an offering made by fire to the LORD, for a sweet aroma; and its drink offering shall be of wine, one-fourth of a hin.

14. You shall eat neither bread nor parched grain nor fresh grain until the same day that you have brought an offering to your God; it shall be a statute forever throughout your generations in all your dwellings.

15. "And you shall count for yourselves from the day after the Sabbath, from the day that you brought the sheaf of the wave offering: seven Sabbaths shall be completed.

16. Count fifty days to the day after the seventh Sabbath; then you shall offer a new grain offering to the LORD.

17. You shall bring from your dwellings two wave loaves of two-tenths of an ephah. They shall be of fine flour; they shall be baked with leaven. They are the firstfruits to the LORD.

18. And you shall offer with the bread seven lambs of the first year, without blemish, one young bull, and two rams. They shall be as a burnt offering to the LORD, with their grain offering and their drink offerings, an offering made by fire for a sweet aroma to the LORD.

19. Then you shall sacrifice one kid of the goats as a sin offering, and two male lambs of the first year as a sacrifice of a peace offering.

20. The priest shall wave them with the bread of the firstfruits as a wave offering before the LORD, with the two lambs. They shall be holy to the LORD for the priest.

21. And you shall proclaim on the same day that it is a holy convocation to you. You shall do no customary work on it. It shall be a statute forever in all your dwellings throughout your generations.

22. "When you reap the harvest of your land, you shall not wholly reap the corners of your field when you reap, nor shall you gather any gleaning from your harvest. You shall leave them for the poor and for the stranger: I am the LORD your God."'

23. Then the LORD spoke to Moses, saying,

24. "Speak to the children of Israel, saying: "In the seventh month, on the first day of the month, you shall have a sabbath-rest, a memorial of blowing of trumpets, a holy convocation.

25. You shall do no customary work on it; and you shall offer an offering made by fire to the LORD."'

26. And the LORD spoke to Moses, saying:

27. "Also the tenth day of this seventh month shall be the Day of Atonement. It shall be a holy convocation for you; you shall afflict your souls, and offer an offering made by fire to the LORD.

28. And you shall do no work on that same day, for it is the Day of Atonement, to make atonement for you before the LORD your God.

29. For any person who is not afflicted in soul on that same day shall be cut off from his people.

30. And any person who does any work on that same day, that person I will destroy from among his people.

31. You shall do no manner of work; it shall be a statute forever throughout your generations in all your dwellings.

32. It shall be to you a sabbath of solemn rest, and you shall afflict your souls; on the ninth day of the month at evening, from evening to evening, you shall celebrate your sabbath."

33. Then the LORD spoke to Moses, saying,

34. "Speak to the children of Israel, saying: "The fifteenth day of this seventh month shall be the Feast of Tabernacles for seven days to the LORD.

35. On the first day there shall be a holy convocation. You shall do no customary work on it.

36. For seven days you shall offer an offering made by fire to the LORD. On the eighth day you shall have a holy convocation, and you shall offer an offering made by fire to the LORD. It is a sacred assembly, and you shall do no customary work on it.

37. "These are the feasts of the LORD which you shall proclaim to be holy convocations, to offer an offering made by fire to the LORD, a burnt offering and a grain offering, a sacrifice and drink offerings, everything on its day--

38. besides the Sabbaths of the LORD, besides your gifts, besides all your vows, and besides all your freewill offerings which you give to the LORD.

39. "Also on the fifteenth day of the seventh month, when you have gathered in the fruit of the land, you shall keep the feast of the LORD for seven days; on the first day there shall be a sabbath-rest, and on the eighth day a sabbath-rest.

40. And you shall take for yourselves on the first day the fruit of beautiful trees, branches of palm trees, the boughs of leafy trees, and willows of the brook; and you shall rejoice before the LORD your God for seven days.

41. You shall keep it as a feast to the LORD for seven days in the year. It shall be a statute forever in your generations. You shall celebrate it in the seventh month.

42. You shall dwell in booths for seven days. All who are native Israelites shall dwell in booths,

43. that your generations may know that I made the children of Israel dwell in booths when I brought them out of the land of Egypt: I am the LORD your God."'

44. So Moses declared to the children of Israel the feasts of the LORD.

## Chapter 24

1. Then the LORD spoke to Moses, saying:

2. "Command the children of Israel that they bring to you pure oil of pressed olives for the light, to make the lamps burn continually.

3. Outside the veil of the Testimony, in the tabernacle of meeting, Aaron shall be in charge of it from evening until morning before the LORD continually; it shall be a statute forever in your generations.

4. He shall be in charge of the lamps on the pure gold lampstand before the LORD continually.

5. "And you shall take fine flour and bake twelve cakes with it. Two-tenths of an ephah shall be in each cake.

6. You shall set them in two rows, six in a row, on the pure gold table before the LORD.

7. And you shall put pure frankincense on each row, that it may be on the bread for a memorial, an offering made by fire to the LORD.

8. Every Sabbath he shall set it in order before the LORD continually, being taken from the children of Israel by an everlasting covenant.

9. And it shall be for Aaron and his sons, and they shall eat it in a holy place; for it is most holy to him from the offerings of the LORD made by fire, by a perpetual statute."

10. Now the son of an Israelite woman, whose father was an Egyptian, went out among the children of Israel; and this Israelite woman's son and a man of Israel fought each other in the camp.

11. And the Israelite woman's son blasphemed the name of the LORD and cursed; and so they brought him to Moses. (His mother's name was Shelomith the daughter of Dibri, of the tribe of Dan.)

12. Then they put him in custody, that the mind of the LORD might be shown to them.

13. And the LORD spoke to Moses, saying,

14. "Take outside the camp him who has cursed; then let all who heard him lay their hands on his head, and let all the congregation stone him.

15. "Then you shall speak to the children of Israel, saying: "Whoever curses his God shall bear his sin.

16. And whoever blasphemes the name of the LORD shall surely be put to death. All the congregation shall certainly stone him, the stranger as well as him who is born in the land. When he blasphemes the name of the LORD, he shall be put to death.

17. "Whoever kills any man shall surely be put to death.

18. Whoever kills an animal shall make it good, animal for animal.

19. "If a man causes disfigurement of his neighbor, as he has done, so shall it be done to him--

20. fracture for fracture, eye for eye, tooth for tooth; as he has caused disfigurement of a man, so shall it be done to him.

21. And whoever kills an animal shall restore it; but whoever kills a man shall be put to death.

22. You shall have the same law for the stranger and for one from your own country; for I am the LORD your God."'

23. Then Moses spoke to the children of Israel; and they took outside the camp him who had cursed, and stoned him with stones. So the children of Israel did as the LORD commanded Moses.

## Chapter 25

1. And the LORD spoke to Moses on Mount Sinai, saying,

2. "Speak to the children of Israel, and say to them: "When you come into the land which I give you, then the land shall keep a sabbath to the LORD.

3. Six years you shall sow your field, and six years you shall prune your vineyard, and gather its fruit;

4. but in the seventh year there shall be a sabbath of solemn rest for the land, a sabbath to the LORD. You shall neither sow your field nor prune your vineyard.

5. What grows of its own accord of your harvest you shall not reap, nor gather the grapes of your untended vine, for it is a year of rest for the land.

6. And the sabbath produce of the land shall be food for you: for you, your male and female servants, your hired man, and the stranger who dwells with you,

7. for your livestock and the beasts that are in your land--all its produce shall be for food.

8. "And you shall count seven sabbaths of years for yourself, seven times seven years; and the time of the seven sabbaths of years shall be to you forty-nine years.

9. Then you shall cause the trumpet of the Jubilee to sound on the tenth day of the seventh month; on the Day of Atonement you shall make the trumpet to sound throughout all your land.

10. And you shall consecrate the fiftieth year, and proclaim liberty throughout all the land to all its inhabitants. It shall be a Jubilee for you; and each of you shall return to his possession, and each of you shall return to his family.

11. That fiftieth year shall be a Jubilee to you; in it you shall neither sow nor reap what grows of its own accord, nor gather the grapes of your untended vine.

12. For it is the Jubilee; it shall be holy to you; you shall eat its produce from the field.

13. "In this Year of Jubilee, each of you shall return to his possession.

14. And if you sell anything to your neighbor or buy from your neighbor's hand, you shall not oppress one another.

15. According to the number of years after the Jubilee you shall buy from your neighbor, and according to the number of years of crops he shall sell to you.

16. According to the multitude of years you shall increase its price, and according to the fewer number of years you shall diminish its price; for he sells to you according to the number of the years of the crops.

17. Therefore you shall not oppress one another, but you shall fear your God; for I am the LORD your God.

18. "So you shall observe My statutes and keep My judgments, and perform them; and you will dwell in the land in safety.

19. Then the land will yield its fruit, and you will eat your fill, and dwell there in safety.

20. "And if you say, "What shall we eat in the seventh year, since we shall not sow nor gather in our produce?"

21. Then I will command My blessing on you in the sixth year, and it will bring forth produce enough for three years.

22. And you shall sow in the eighth year, and eat old produce until the ninth year; until its produce comes in, you shall eat of the old harvest.

23. "The land shall not be sold permanently, for the land is Mine; for you are strangers and sojourners with Me.

24. And in all the land of your possession you shall grant redemption of the land.

25. "If one of your brethren becomes poor, and has sold some of his possession, and if his redeeming relative comes to redeem it, then he may redeem what his brother sold.

26. Or if the man has no one to redeem it, but he himself becomes able to redeem it,

27. then let him count the years since its sale, and restore the remainder to the man to whom he sold it, that he may return to his possession.

28. But if he is not able to have it restored to himself, then what was sold shall remain in the hand of him who bought it until the Year of Jubilee; and in the Jubilee it shall be released, and he shall return to his possession.

29. "If a man sells a house in a walled city, then he may redeem it within a whole year after it is sold; within a full year he may redeem it.

30. But if it is not redeemed within the space of a full year, then the house in the walled city shall belong permanently to him who bought it, throughout his generations. It shall not be released in the Jubilee.

31. However the houses of villages which have no wall around them shall be counted as the fields of the country. They may be redeemed, and they shall be released in the Jubilee.

32. Nevertheless the cities of the Levites, and the houses in the cities of their possession, the Levites may redeem at any time.

33. And if a man purchases a house from the Levites, then the house that was sold in the city of his possession shall be released in the Jubilee; for the houses in the cities of the Levites are their possession among the children of Israel.

34. But the field of the common-land of their cities may not be sold, for it is their perpetual possession.

35. "If one of your brethren becomes poor, and falls into poverty among you, then you shall help him, like a stranger or a sojourner, that he may live with you.

36. Take no usury or interest from him; but fear your God, that your brother may live with you.

37. You shall not lend him your money for usury, nor lend him your food at a profit.

38. I am the LORD your God, who brought you out of the land of Egypt, to give you the land of Canaan and to be your God.

39. "And if one of your brethren who dwells by you becomes poor, and sells himself to you, you shall not compel him to serve as a slave.

40. As a hired servant and a sojourner he shall be with you, and shall serve you until the Year of Jubilee.

41. And then he shall depart from you--he and his children with him--and shall return to his own family. He shall return to the possession of his fathers.

42. For they are My servants, whom I brought out of the land of Egypt; they shall not be sold as slaves.

43. You shall not rule over him with rigor, but you shall fear your God.

44. And as for your male and female slaves whom you may have--from the nations that are around you, from them you may buy male and female slaves.

45. Moreover you may buy the children of the strangers who dwell among you, and their families who are with you, which they beget in your land; and they shall become your property.

46. And you may take them as an inheritance for your children after you, to inherit them as a possession; they shall be your permanent slaves. But regarding your brethren, the children of Israel, you shall not rule over one another with rigor.

47. "Now if a sojourner or stranger close to you becomes rich, and one of your brethren who dwells by him becomes poor, and sells himself to the stranger or sojourner close to you, or to a member of the stranger's family,

48. after he is sold he may be redeemed again. One of his brothers may redeem him;

49. or his uncle or his uncle's son may redeem him; or anyone who is near of kin to him in his family may redeem him; or if he is able he may redeem himself.

50. Thus he shall reckon with him who bought him: The price of his release shall be according to the number of years, from the year that he was sold to him until the Year of Jubilee; it shall be according to the time of a hired servant for him.

51. If there are still many years remaining, according to them he shall repay the price of his redemption from the money with which he was bought.

52. And if there remain but a few years until the Year of Jubilee, then he shall reckon with him, and according to his years he shall repay him the price of his redemption.

53. He shall be with him as a yearly hired servant, and he shall not rule with rigor over him in your sight.

54. And if he is not redeemed in these years, then he shall be released in the Year of Jubilee--he and his children with him.

55. For the children of Israel are servants to Me; they are My servants whom I brought out of the land of Egypt: I am the LORD your God.

## Chapter 26

1. "You shall not make idols for yourselves; neither a carved image nor a sacred pillar shall you rear up for yourselves; nor shall you set up an engraved stone in your land, to bow down to it; for I am the LORD your God.

2. You shall keep My Sabbaths and reverence My sanctuary: I am the LORD.

3. "If you walk in My statutes and keep My commandments, and perform them,

4. then I will give you rain in its season, the land shall yield its produce, and the trees of the field shall yield their fruit.

5. Your threshing shall last till the time of vintage, and the vintage shall last till the time of sowing; you shall eat your bread to the full, and dwell in your land safely.

6. I will give peace in the land, and you shall lie down, and none will make you afraid; I will rid the land of evil beasts, and the sword will not go through your land.

7. You will chase your enemies, and they shall fall by the sword before you.

8. Five of you shall chase a hundred, and a hundred of you shall put ten thousand to flight; your enemies shall fall by the sword before you.

9. "For I will look on you favorably and make you fruitful, multiply you and confirm My covenant with you.

10. You shall eat the old harvest, and clear out the old because of the new.

11. I will set My tabernacle among you, and My soul shall not abhor you.

12. I will walk among you and be your God, and you shall be My people.

13. I am the LORD your God, who brought you out of the land of Egypt, that you should not be their slaves; I have broken the bands of your yoke and made you walk upright.

14. "But if you do not obey Me, and do not observe all these commandments,

15. and if you despise My statutes, or if your soul abhors My judgments, so that you do not perform all My commandments, but break My covenant,

16. I also will do this to you: I will even appoint terror over you, wasting disease and fever which shall consume the eyes and cause sorrow of heart. And you shall sow your seed in vain, for your enemies shall eat it.

17. I will set My face against you, and you shall be defeated by your enemies. 1 Those who hate you shall reign over you, and you shall flee when no one pursues you.

18. "And after all this, if you do not obey Me, then I will punish you seven times more for your sins.

19. I will break the pride of your power; I will make your heavens like iron and your earth like bronze.

20. And your strength shall be spent in vain; for your land shall not yield its produce, nor shall the trees of the land yield their fruit.

21. "Then, if you walk contrary to Me, and are not willing to obey Me, I will bring on you seven times more plagues, according to your sins.

22. I will also send wild beasts among you, which shall rob you of your children, destroy your livestock, and make you few in number; and your highways shall be desolate.

23. "And if by these things you are not reformed by Me, but walk contrary to Me,

24. then I also will walk contrary to you, and I will punish you yet seven times for your sins.

25. And I will bring a sword against you that will execute the vengeance of the covenant; when you are gathered together within your cities I will send pestilence among you; and you shall be delivered into the hand of the enemy.

26. When I have cut off your supply of bread, ten women shall bake your bread in one oven, and they shall bring back your bread by weight, and you shall eat and not be satisfied.

27. "And after all this, if you do not obey Me, but walk contrary to Me,

28. then I also will walk contrary to you in fury; and I, even I, will chastise you seven times for your sins.

29. You shall eat the flesh of your sons, and you shall eat the flesh of your daughters.

30. I will destroy your high places, cut down your incense altars, and cast your carcasses on the lifeless forms of your idols; and My soul shall abhor you.

31. I will lay your cities waste and bring your sanctuaries to desolation, and I will not smell the fragrance of your sweet aromas.

32. I will bring the land to desolation, and your enemies who dwell in it shall be astonished at it.

33. I will scatter you among the nations and draw out a sword after you; your land shall be desolate and your cities waste.

34. Then the land shall enjoy its sabbaths as long as it lies desolate and you are in your enemies' land; then the land shall rest and enjoy its sabbaths.

35. As long as it lies desolate it shall rest-- for the time it did not rest on your sabbaths when you dwelt in it.

36. "And as for those of you who are left, I will send faintness into their hearts in the lands of their enemies; the sound of a shaken leaf shall cause them to flee; they shall flee as though fleeing from a sword, and they shall fall when no one pursues.

37. They shall stumble over one another, as it were before a sword, when no one pursues; and you shall have no power to stand before your enemies.

38. You shall perish among the nations, and the land of your enemies shall eat you up.

39. And those of you who are left shall waste away in their iniquity in your enemies' lands; also in their fathers' iniquities, which are with them, they shall waste away.

40. "But if they confess their iniquity and the iniquity of their fathers, with their unfaithfulness in which they were unfaithful to Me, and that they also have walked contrary to Me,

41. and that I also have walked contrary to them and have brought them into the land of their enemies; if their uncircumcised hearts are humbled, and they accept their guilt--

42. then I will remember My covenant with Jacob, and My covenant with Isaac and My covenant with Abraham I will remember; I will remember the land.

43. The land also shall be left empty by them, and will enjoy its sabbaths while it lies desolate without them; they will accept their guilt, because they despised My judgments and because their soul abhorred My statutes.

44. Yet for all that, when they are in the land of their enemies, I will not cast them away, nor shall I abhor them, to utterly destroy them and break My covenant with them; for I am the LORD their God.

45. But for their sake I will remember the covenant of their ancestors, whom I brought out of the land of Egypt in the sight of the nations, that I might be their God: I am the LORD."'

46. These are the statutes and judgments and laws which the LORD made between Himself and the children of Israel on Mount Sinai by the hand of Moses.

## Chapter 27

1. Now the LORD spoke to Moses, saying,

2. "Speak to the children of Israel, and say to them: "When a man consecrates by a vow certain persons to the LORD, according to your valuation,

3. if your valuation is of a male from twenty years old up to sixty years old, then your valuation shall be fifty shekels of silver, according to the shekel of the sanctuary.

4. If it is a female, then your valuation shall be thirty shekels;

5. and if from five years old up to twenty years old, then your valuation for a male shall be twenty shekels, and for a female ten shekels;

6. and if from a month old up to five years old, then your valuation for a male shall be five shekels of silver, and for a female your valuation shall be three shekels of silver;

7. and if from sixty years old and above, if it is a male, then your valuation shall be fifteen shekels, and for a female ten shekels.

8. "But if he is too poor to pay your valuation, then he shall present himself before the priest, and the priest shall set a value for him; according to the ability of him who vowed, the priest shall value him.

9. "If it is an animal that men may bring as an offering to the LORD, all that anyone gives to the LORD shall be holy.

10. He shall not substitute it or exchange it, good for bad or bad for good; and if he at all exchanges animal for animal, then both it and the one exchanged for it shall be holy.

11. If it is an unclean animal which they do not offer as a sacrifice to the LORD, then he shall present the animal before the priest;

12. and the priest shall set a value for it, whether it is good or bad; as you, the priest, value it, so it shall be.

13. But if he wants at all to redeem it, then he must add one-fifth to your valuation.

14. "And when a man dedicates his house to be holy to the LORD, then the priest shall set a value for it, whether it is good or bad; as the priest values it, so it shall stand.

15. If he who dedicated it wants to redeem his house, then he must add one-fifth of the money of your valuation to it, and it shall be his.

16. "If a man dedicates to the LORD part of a field of his possession, then your valuation shall be according to the seed for it. A homer of barley seed shall be valued at fifty shekels of silver.

17. If he dedicates his field from the Year of Jubilee, according to your valuation it shall stand.

18. But if he dedicates his field after the Jubilee, then the priest shall reckon to him the money due according to the years that remain till the Year of Jubilee, and it shall be deducted from your valuation.

19. And if he who dedicates the field ever wishes to redeem it, then he must add one-fifth of the money of your valuation to it, and it shall belong to him.

20. But if he does not want to redeem the field, or if he has sold the field to another man, it shall not be redeemed anymore;

21. but the field, when it is released in the Jubilee, shall be holy to the LORD, as a devoted field; it shall be the possession of the priest.

22. "And if a man dedicates to the LORD a field which he has bought, which is not the field of his possession,

23. then the priest shall reckon to him the worth of your valuation, up to the Year of Jubilee, and he shall give your valuation on that day as a holy offering to the LORD.

24. In the Year of Jubilee the field shall return to him from whom it was bought, to the one who owned the land as a possession.

25. And all your valuations shall be according to the shekel of the sanctuary: twenty gerahs to the shekel.

26. "But the firstborn of the animals, which should be the LORD's firstborn, no man shall dedicate; whether it is an ox or sheep, it is the LORD's.

27. And if it is an unclean animal, then he shall redeem it according to your valuation, and shall add one-fifth to it; or if it is not redeemed, then it shall be sold according to your valuation.

28. "Nevertheless no devoted offering that a man may devote to the LORD of all that he has, both man and beast, or the field of his possession, shall be sold or redeemed; every devoted offering is most holy to the LORD.

29. No person under the ban, who may become doomed to destruction among men, shall be redeemed, but shall surely be put to death.

30. And all the tithe of the land, whether of the seed of the land or of the fruit of the tree, is the LORD's. It is holy to the LORD.

31. If a man wants at all to redeem any of his tithes, he shall add one-fifth to it.

32. And concerning the tithe of the herd or the flock, of whatever passes under the rod, the tenth one shall be holy to the LORD.

33. He shall not inquire whether it is good or bad, nor shall he exchange it; and if he exchanges it at all, then both it and the one exchanged for it shall be holy; it shall not be redeemed."'

34. These are the commandments which the LORD commanded Moses for the children of Israel on Mount Sinai.


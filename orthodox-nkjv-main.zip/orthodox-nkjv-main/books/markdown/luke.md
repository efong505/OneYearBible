# luke

## Chapter 1

1. Inasmuch as many have taken in hand to set in order a narrative of those things which have been fulfilled among us,

2. just as those who from the beginning were eyewitnesses and ministers of the word delivered them to us,

3. it seemed good to me also, having had perfect understanding of all things from the very first, to write to you an orderly account, most excellent Theophilus,

4. that you may know the certainty of those things in which you were instructed.

5. There was in the days of Herod, the king of Judea, a certain priest named Zacharias, of the division of Abijah. His wife was of the daughters of Aaron, and her name was Elizabeth.

6. And they were both righteous before God, walking in all the commandments and ordinances of the Lord blameless.

7. But they had no child, because Elizabeth was barren, and they were both well advanced in years.

8. So it was, that while he was serving as priest before God in the order of his division,

9. according to the custom of the priesthood, his lot fell to burn incense when he went into the temple of the Lord.

10. And the whole multitude of the people was praying outside at the hour of incense.

11. Then an angel of the Lord appeared to him, standing on the right side of the altar of incense.

12. And when Zacharias saw him, he was troubled, and fear fell upon him.

13. But the angel said to him, "Do not be afraid, Zacharias, for your prayer is heard; and your wife Elizabeth will bear you a son, and you shall call his name John.

14. And you will have joy and gladness, and many will rejoice at his birth.

15. For he will be great in the sight of the Lord, and shall drink neither wine nor strong drink. He will also be filled with the Holy Spirit, even from his mother's womb.

16. And he will turn many of the children of Israel to the Lord their God.

17. He will also go before Him in the spirit and power of Elijah, "to turn the hearts of the fathers to the children,' and the disobedient to the wisdom of the just, to make ready a people prepared for the Lord."

18. And Zacharias said to the angel, "How shall I know this? For I am an old man, and my wife is well advanced in years."

19. And the angel answered and said to him, "I am Gabriel, who stands in the presence of God, and was sent to speak to you and bring you these glad tidings.

20. But behold, you will be mute and not able to speak until the day these things take place, because you did not believe my words which will be fulfilled in their own time."

21. And the people waited for Zacharias, and marveled that he lingered so long in the temple.

22. But when he came out, he could not speak to them; and they perceived that he had seen a vision in the temple, for he beckoned to them and remained speechless.

23. So it was, as soon as the days of his service were completed, that he departed to his own house.

24. Now after those days his wife Elizabeth conceived; and she hid herself five months, saying,

25. "Thus the Lord has dealt with me, in the days when He looked on me, to take away my reproach among people."

26. Now in the sixth month the angel Gabriel was sent by God to a city of Galilee named Nazareth,

27. to a virgin betrothed to a man whose name was Joseph, of the house of David. The virgin's name was Mary.

28. And having come in, the angel said to her, "Rejoice, highly favored one, the Lord is with you; blessed are you among women!"

29. But when she saw him, she was troubled at his saying, and considered what manner of greeting this was.

30. Then the angel said to her, "Do not be afraid, Mary, for you have found favor with God.

31. And behold, you will conceive in your womb and bring forth a Son, and shall call His name JESUS.

32. He will be great, and will be called the Son of the Highest; and the Lord God will give Him the throne of His father David.

33. And He will reign over the house of Jacob forever, and of His kingdom there will be no end."

34. Then Mary said to the angel, "How can this be, since I do not know a man?"

35. And the angel answered and said to her, "The Holy Spirit will come upon you, and the power of the Highest will overshadow you; therefore, also, that Holy One who is to be born will be called the Son of God.

36. Now indeed, Elizabeth your relative has also conceived a son in her old age; and this is now the sixth month for her who was called barren.

37. For with God nothing will be impossible."

38. Then Mary said, "Behold the maidservant of the Lord! Let it be to me according to your word." And the angel departed from her.

39. Now Mary arose in those days and went into the hill country with haste, to a city of Judah,

40. and entered the house of Zacharias and greeted Elizabeth.

41. And it happened, when Elizabeth heard the greeting of Mary, that the babe leaped in her womb; and Elizabeth was filled with the Holy Spirit.

42. Then she spoke out with a loud voice and said, "Blessed are you among women, and blessed is the fruit of your womb!

43. But why is this granted to me, that the mother of my Lord should come to me?

44. For indeed, as soon as the voice of your greeting sounded in my ears, the babe leaped in my womb for joy.

45. Blessed is she who believed, for there will be a fulfillment of those things which were told her from the Lord."

46. And Mary said: "My soul magnifies the Lord,

47. And my spirit has rejoiced in God my Savior.

48. For He has regarded the lowly state of His maidservant; For behold, henceforth all generations will call me blessed.

49. For He who is mighty has done great things for me, And holy is His name.

50. And His mercy is on those who fear Him From generation to generation.

51. He has shown strength with His arm; He has scattered the proud in the imagination of their hearts.

52. He has put down the mighty from their thrones, And exalted the lowly.

53. He has filled the hungry with good things, And the rich He has sent away empty.

54. He has helped His servant Israel, In remembrance of His mercy,

55. As He spoke to our fathers, To Abraham and to his seed forever."

56. And Mary remained with her about three months, and returned to her house.

57. Now Elizabeth's full time came for her to be delivered, and she brought forth a son.

58. When her neighbors and relatives heard how the Lord had shown great mercy to her, they rejoiced with her.

59. So it was, on the eighth day, that they came to circumcise the child; and they would have called him by the name of his father, Zacharias.

60. His mother answered and said, "No; he shall be called John."

61. But they said to her, "There is no one among your relatives who is called by this name."

62. So they made signs to his father--what he would have him called.

63. And he asked for a writing tablet, and wrote, saying, "His name is John." So they all marveled.

64. Immediately his mouth was opened and his tongue loosed, and he spoke, praising God.

65. Then fear came on all who dwelt around them; and all these sayings were discussed throughout all the hill country of Judea.

66. And all those who heard them kept them in their hearts, saying, "What kind of child will this be?" And the hand of the Lord was with him.

67. Now his father Zacharias was filled with the Holy Spirit, and prophesied, saying:

68. "Blessed is the Lord God of Israel, For He has visited and redeemed His people,

69. And has raised up a horn of salvation for us In the house of His servant David,

70. As He spoke by the mouth of His holy prophets, Who have been since the world began,

71. That we should be saved from our enemies And from the hand of all who hate us,

72. To perform the mercy promised to our fathers And to remember His holy covenant,

73. The oath which He swore to our father Abraham:

74. To grant us that we, Being delivered from the hand of our enemies, Might serve Him without fear,

75. In holiness and righteousness before Him all the days of our life.

76. "And you, child, will be called the prophet of the Highest; For you will go before the face of the Lord to prepare His ways,

77. To give knowledge of salvation to His people By the remission of their sins,

78. Through the tender mercy of our God, With which the Dayspring from on high has visited us;

79. To give light to those who sit in darkness and the shadow of death, To guide our feet into the way of peace."

80. So the child grew and became strong in spirit, and was in the deserts till the day of his manifestation to Israel.

## Chapter 2

1. And it came to pass in those days that a decree went out from Caesar Augustus that all the world should be registered.

2. This census first took place while Quirinius was governing Syria.

3. So all went to be registered, everyone to his own city.

4. Joseph also went up from Galilee, out of the city of Nazareth, into Judea, to the city of David, which is called Bethlehem, because he was of the house and lineage of David,

5. to be registered with Mary, his betrothed wife, who was with child.

6. So it was, that while they were there, the days were completed for her to be delivered.

7. And she brought forth her firstborn Son, and wrapped Him in swaddling cloths, and laid Him in a manger, because there was no room for them in the inn.

8. Now there were in the same country shepherds living out in the fields, keeping watch over their flock by night.

9. And behold, an angel of the Lord stood before them, and the glory of the Lord shone around them, and they were greatly afraid.

10. Then the angel said to them, "Do not be afraid, for behold, I bring you good tidings of great joy which will be to all people.

11. For there is born to you this day in the city of David a Savior, who is Christ the Lord.

12. And this will be the sign to you: You will find a Babe wrapped in swaddling cloths, lying in a manger."

13. And suddenly there was with the angel a multitude of the heavenly host praising God and saying:

14. "Glory to God in the highest, And on earth peace, goodwill toward men!"

15. So it was, when the angels had gone away from them into heaven, that the shepherds said to one another, "Let us now go to Bethlehem and see this thing that has come to pass, which the Lord has made known to us."

16. And they came with haste and found Mary and Joseph, and the Babe lying in a manger.

17. Now when they had seen Him, they made widely known the saying which was told them concerning this Child.

18. And all those who heard it marveled at those things which were told them by the shepherds.

19. But Mary kept all these things and pondered them in her heart.

20. Then the shepherds returned, glorifying and praising God for all the things that they had heard and seen, as it was told them.

21. And when eight days were completed for the circumcision of the Child, His name was called JESUS, the name given by the angel before He was conceived in the womb.

22. Now when the days of her purification according to the law of Moses were completed, they brought Him to Jerusalem to present Him to the Lord

23. (as it is written in the law of the Lord, "Every male who opens the womb shall be called holy to the LORD"),

24. and to offer a sacrifice according to what is said in the law of the Lord, "A pair of turtledoves or two young pigeons."

25. And behold, there was a man in Jerusalem whose name was Simeon, and this man was just and devout, waiting for the Consolation of Israel, and the Holy Spirit was upon him.

26. And it had been revealed to him by the Holy Spirit that he would not see death before he had seen the Lord's Christ.

27. So he came by the Spirit into the temple. And when the parents brought in the Child Jesus, to do for Him according to the custom of the law,

28. he took Him up in his arms and blessed God and said:

29. "Lord, now You are letting Your servant depart in peace, According to Your word;

30. For my eyes have seen Your salvation

31. Which You have prepared before the face of all peoples,

32. A light to bring revelation to the Gentiles, And the glory of Your people Israel."

33. And Joseph and His mother marveled at those things which were spoken of Him.

34. Then Simeon blessed them, and said to Mary His mother, "Behold, this Child is destined for the fall and rising of many in Israel, and for a sign which will be spoken against

35. (yes, a sword will pierce through your own soul also), that the thoughts of many hearts may be revealed."

36. Now there was one, Anna, a prophetess, the daughter of Phanuel, of the tribe of Asher. She was of a great age, and had lived with a husband seven years from her virginity;

37. and this woman was a widow of about eighty-four years, who did not depart from the temple, but served God with fastings and prayers night and day.

38. And coming in that instant she gave thanks to the Lord, and spoke of Him to all those who looked for redemption in Jerusalem.

39. So when they had performed all things according to the law of the Lord, they returned to Galilee, to their own city, Nazareth.

40. And the Child grew and became strong in spirit, filled with wisdom; and the grace of God was upon Him.

41. His parents went to Jerusalem every year at the Feast of the Passover.

42. And when He was twelve years old, they went up to Jerusalem according to the custom of the feast.

43. When they had finished the days, as they returned, the Boy Jesus lingered behind in Jerusalem. And Joseph and His mother did not know it;

44. but supposing Him to have been in the company, they went a day's journey, and sought Him among their relatives and acquaintances.

45. So when they did not find Him, they returned to Jerusalem, seeking Him.

46. Now so it was that after three days they found Him in the temple, sitting in the midst of the teachers, both listening to them and asking them questions.

47. And all who heard Him were astonished at His understanding and answers.

48. So when they saw Him, they were amazed; and His mother said to Him, "Son, why have You done this to us? Look, Your father and I have sought You anxiously."

49. And He said to them, "Why did you seek Me? Did you not know that I must be about My Father's business?"

50. But they did not understand the statement which He spoke to them.

51. Then He went down with them and came to Nazareth, and was subject to them, but His mother kept all these things in her heart.

52. And Jesus increased in wisdom and stature, and in favor with God and men.

## Chapter 3

1. Now in the fifteenth year of the reign of Tiberius Caesar, Pontius Pilate being governor of Judea, Herod being tetrarch of Galilee, his brother Philip tetrarch of Iturea and the region of Trachonitis, and Lysanias tetrarch of Abilene,

2. while Annas and Caiaphas were high priests, the word of God came to John the son of Zacharias in the wilderness.

3. And he went into all the region around the Jordan, preaching a baptism of repentance for the remission of sins,

4. as it is written in the book of the words of Isaiah the prophet, saying: "The voice of one crying in the wilderness: "Prepare the way of the LORD; Make His paths straight.

5. Every valley shall be filled And every mountain and hill brought low; The crooked places shall be made straight And the rough ways smooth;

6. And all flesh shall see the salvation of God."'

7. Then he said to the multitudes that came out to be baptized by him, "Brood of vipers! Who warned you to flee from the wrath to come?

8. Therefore bear fruits worthy of repentance, and do not begin to say to yourselves, "We have Abraham as our father.' For I say to you that God is able to raise up children to Abraham from these stones.

9. And even now the ax is laid to the root of the trees. Therefore every tree which does not bear good fruit is cut down and thrown into the fire."

10. So the people asked him, saying, "What shall we do then?"

11. He answered and said to them, "He who has two tunics, let him give to him who has none; and he who has food, let him do likewise."

12. Then tax collectors also came to be baptized, and said to him, "Teacher, what shall we do?"

13. And he said to them, "Collect no more than what is appointed for you."

14. Likewise the soldiers asked him, saying, "And what shall we do?" So he said to them, "Do not intimidate anyone or accuse falsely, and be content with your wages."

15. Now as the people were in expectation, and all reasoned in their hearts about John, whether he was the Christ or not,

16. John answered, saying to all, "I indeed baptize you with water; but One mightier than I is coming, whose sandal strap I am not worthy to loose. He will baptize you with the Holy Spirit and fire.

17. His winnowing fan is in His hand, and He will thoroughly clean out His threshing floor, and gather the wheat into His barn; but the chaff He will burn with unquenchable fire."

18. And with many other exhortations he preached to the people.

19. But Herod the tetrarch, being rebuked by him concerning Herodias, his brother Philip's wife, and for all the evils which Herod had done,

20. also added this, above all, that he shut John up in prison.

21. When all the people were baptized, it came to pass that Jesus also was baptized; and while He prayed, the heaven was opened.

22. And the Holy Spirit descended in bodily form like a dove upon Him, and a voice came from heaven which said, "You are My beloved Son; in You I am well pleased."

23. Now Jesus Himself began His ministry at about thirty years of age, being (as was supposed) the son of Joseph, the son of Heli,

24. the son of Matthat, the son of Levi, the son of Melchi, the son of Janna, the son of Joseph,

25. the son of Mattathiah, the son of Amos, the son of Nahum, the son of Esli, the son of Naggai,

26. the son of Maath, the son of Mattathiah, the son of Semei, the son of Joseph, the son of Judah,

27. the son of Joannas, the son of Rhesa, the son of Zerubbabel, the son of Shealtiel, the son of Neri,

28. the son of Melchi, the son of Addi, the son of Cosam, the son of Elmodam, the son of Er,

29. the son of Jose, the son of Eliezer, the son of Jorim, the son of Matthat, the son of Levi,

30. the son of Simeon, the son of Judah, the son of Joseph, the son of Jonan, the son of Eliakim,

31. the son of Melea, the son of Menan, the son of Mattathah, the son of Nathan, the son of David,

32. the son of Jesse, the son of Obed, the son of Boaz, the son of Salmon, the son of Nahshon,

33. the son of Amminadab, the son of Ram, the son of Hezron, the son of Perez, the son of Judah,

34. the son of Jacob, the son of Isaac, the son of Abraham, the son of Terah, the son of Nahor,

35. the son of Serug, the son of Reu, the son of Peleg, the son of Eber, the son of Shelah,

36. the son of Cainan, the son of Arphaxad, the son of Shem, the son of Noah, the son of Lamech,

37. the son of Methuselah, the son of Enoch, the son of Jared, the son of Mahalalel, the son of Cainan,

38. the son of Enosh, the son of Seth, the son of Adam, the son of God.

## Chapter 4

1. Then Jesus, being filled with the Holy Spirit, returned from the Jordan and was led by the Spirit into the wilderness,

2. being tempted for forty days by the devil. And in those days He ate nothing, and afterward, when they had ended, He was hungry.

3. And the devil said to Him, "If You are the Son of God, command this stone to become bread."

4. But Jesus answered him, saying, "It is written, "Man shall not live by bread alone, but by every word of God."'

5. Then the devil, taking Him up on a high mountain, showed Him all the kingdoms of the world in a moment of time.

6. And the devil said to Him, "All this authority I will give You, and their glory; for this has been delivered to me, and I give it to whomever I wish.

7. Therefore, if You will worship before me, all will be Yours."

8. And Jesus answered and said to him, "Get behind Me, Satan! For it is written, "You shall worship the LORD your God, and Him only you shall serve."'

9. Then he brought Him to Jerusalem, set Him on the pinnacle of the temple, and said to Him, "If You are the Son of God, throw Yourself down from here.

10. For it is written: "He shall give His angels charge over you, To keep you,'

11. and, "In their hands they shall bear you up, Lest you dash your foot against a stone."'

12. And Jesus answered and said to him, "It has been said, "You shall not tempt the LORD your God."'

13. Now when the devil had ended every temptation, he departed from Him until an opportune time.

14. Then Jesus returned in the power of the Spirit to Galilee, and news of Him went out through all the surrounding region.

15. And He taught in their synagogues, being glorified by all.

16. So He came to Nazareth, where He had been brought up. And as His custom was, He went into the synagogue on the Sabbath day, and stood up to read.

17. And He was handed the book of the prophet Isaiah. And when He had opened the book, He found the place where it was written:

18. "The Spirit of the LORD is upon Me, Because He has anointed Me To preach the gospel to the poor; He has sent Me to heal the brokenhearted, To proclaim liberty to the captives And recovery of sight to the blind, To set at liberty those who are oppressed;

19. To proclaim the acceptable year of the LORD."

20. Then He closed the book, and gave it back to the attendant and sat down. And the eyes of all who were in the synagogue were fixed on Him.

21. And He began to say to them, "Today this Scripture is fulfilled in your hearing."

22. So all bore witness to Him, and marveled at the gracious words which proceeded out of His mouth. And they said, "Is this not Joseph's son?"

23. He said to them, "You will surely say this proverb to Me, "Physician, heal yourself! Whatever we have heard done in Capernaum, do also here in Your country."'

24. Then He said, "Assuredly, I say to you, no prophet is accepted in his own country.

25. But I tell you truly, many widows were in Israel in the days of Elijah, when the heaven was shut up three years and six months, and there was a great famine throughout all the land;

26. but to none of them was Elijah sent except to Zarephath, in the region of Sidon, to a woman who was a widow.

27. And many lepers were in Israel in the time of Elisha the prophet, and none of them was cleansed except Naaman the Syrian."

28. So all those in the synagogue, when they heard these things, were filled with wrath,

29. and rose up and thrust Him out of the city; and they led Him to the brow of the hill on which their city was built, that they might throw Him down over the cliff.

30. Then passing through the midst of them, He went His way.

31. Then He went down to Capernaum, a city of Galilee, and was teaching them on the Sabbaths.

32. And they were astonished at His teaching, for His word was with authority.

33. Now in the synagogue there was a man who had a spirit of an unclean demon. And he cried out with a loud voice,

34. saying, "Let us alone! What have we to do with You, Jesus of Nazareth? Did You come to destroy us? I know who You are--the Holy One of God!"

35. But Jesus rebuked him, saying, "Be quiet, and come out of him!" And when the demon had thrown him in their midst, it came out of him and did not hurt him.

36. Then they were all amazed and spoke among themselves, saying, "What a word this is! For with authority and power He commands the unclean spirits, and they come out."

37. And the report about Him went out into every place in the surrounding region.

38. Now He arose from the synagogue and entered Simon's house. But Simon's wife's mother was sick with a high fever, and they made request of Him concerning her.

39. So He stood over her and rebuked the fever, and it left her. And immediately she arose and served them.

40. When the sun was setting, all those who had any that were sick with various diseases brought them to Him; and He laid His hands on every one of them and healed them.

41. And demons also came out of many, crying out and saying, "You are the Christ, the Son of God!" And He, rebuking them, did not allow them to speak, for they knew that He was the Christ.

42. Now when it was day, He departed and went into a deserted place. And the crowd sought Him and came to Him, and tried to keep Him from leaving them;

43. but He said to them, "I must preach the kingdom of God to the other cities also, because for this purpose I have been sent."

44. And He was preaching in the synagogues of Galilee.

## Chapter 5

1. So it was, as the multitude pressed about Him to hear the word of God, that He stood by the Lake of Gennesaret,

2. and saw two boats standing by the lake; but the fishermen had gone from them and were washing their nets.

3. Then He got into one of the boats, which was Simon's, and asked him to put out a little from the land. And He sat down and taught the multitudes from the boat.

4. When He had stopped speaking, He said to Simon, "Launch out into the deep and let down your nets for a catch."

5. But Simon answered and said to Him, "Master, we have toiled all night and caught nothing; nevertheless at Your word I will let down the net."

6. And when they had done this, they caught a great number of fish, and their net was breaking.

7. So they signaled to their partners in the other boat to come and help them. And they came and filled both the boats, so that they began to sink.

8. When Simon Peter saw it, he fell down at Jesus' knees, saying, "Depart from me, for I am a sinful man, O Lord!"

9. For he and all who were with him were astonished at the catch of fish which they had taken;

10. and so also were James and John, the sons of Zebedee, who were partners with Simon. And Jesus said to Simon, "Do not be afraid. From now on you will catch men."

11. So when they had brought their boats to land, they forsook all and followed Him.

12. And it happened when He was in a certain city, that behold, a man who was full of leprosy saw Jesus; and he fell on his face and implored Him, saying, "Lord, if You are willing, You can make me clean."

13. Then He put out His hand and touched him, saying, "I am willing; be cleansed." Immediately the leprosy left him.

14. And He charged him to tell no one, "But go and show yourself to the priest, and make an offering for your cleansing, as a testimony to them, just as Moses commanded."

15. However, the report went around concerning Him all the more; and great multitudes came together to hear, and to be healed by Him of their infirmities.

16. So He Himself often withdrew into the wilderness and prayed.

17. Now it happened on a certain day, as He was teaching, that there were Pharisees and teachers of the law sitting by, who had come out of every town of Galilee, Judea, and Jerusalem. And the power of the Lord was present to heal them.

18. Then behold, men brought on a bed a man who was paralyzed, whom they sought to bring in and lay before Him.

19. And when they could not find how they might bring him in, because of the crowd, they went up on the housetop and let him down with his bed through the tiling into the midst before Jesus.

20. When He saw their faith, He said to him, "Man, your sins are forgiven you."

21. And the scribes and the Pharisees began to reason, saying, "Who is this who speaks blasphemies? Who can forgive sins but God alone?"

22. But when Jesus perceived their thoughts, He answered and said to them, "Why are you reasoning in your hearts?

23. Which is easier, to say, "Your sins are forgiven you,' or to say, "Rise up and walk'?

24. But that you may know that the Son of Man has power on earth to forgive sins"--He said to the man who was paralyzed, "I say to you, arise, take up your bed, and go to your house."

25. Immediately he rose up before them, took up what he had been lying on, and departed to his own house, glorifying God.

26. And they were all amazed, and they glorified God and were filled with fear, saying, "We have seen strange things today!"

27. After these things He went out and saw a tax collector named Levi, sitting at the tax office. And He said to him, "Follow Me."

28. So he left all, rose up, and followed Him.

29. Then Levi gave Him a great feast in his own house. And there were a great number of tax collectors and others who sat down with them.

30. And their scribes and the Pharisees complained against His disciples, saying, "Why do You eat and drink with tax collectors and sinners?"

31. Jesus answered and said to them, "Those who are well have no need of a physician, but those who are sick.

32. I have not come to call the righteous, but sinners, to repentance."

33. Then they said to Him, "Why do the disciples of John fast often and make prayers, and likewise those of the Pharisees, but Yours eat and drink?"

34. And He said to them, "Can you make the friends of the bridegroom fast while the bridegroom is with them?

35. But the days will come when the bridegroom will be taken away from them; then they will fast in those days."

36. Then He spoke a parable to them: "No one puts a piece from a new garment on an old one; otherwise the new makes a tear, and also the piece that was taken out of the new does not match the old.

37. And no one puts new wine into old wineskins; or else the new wine will burst the wineskins and be spilled, and the wineskins will be ruined.

38. But new wine must be put into new wineskins, and both are preserved.

39. And no one, having drunk old wine, immediately desires new; for he says, "The old is better."'

## Chapter 6

1. Now it happened on the second Sabbath after the first that He went through the grainfields. And His disciples plucked the heads of grain and ate them, rubbing them in their hands.

2. And some of the Pharisees said to them, "Why are you doing what is not lawful to do on the Sabbath?"

3. But Jesus answering them said, "Have you not even read this, what David did when he was hungry, he and those who were with him:

4. how he went into the house of God, took and ate the showbread, and also gave some to those with him, which is not lawful for any but the priests to eat?"

5. And He said to them, "The Son of Man is also Lord of the Sabbath."

6. Now it happened on another Sabbath, also, that He entered the synagogue and taught. And a man was there whose right hand was withered.

7. So the scribes and Pharisees watched Him closely, whether He would heal on the Sabbath, that they might find an accusation against Him.

8. But He knew their thoughts, and said to the man who had the withered hand, "Arise and stand here." And he arose and stood.

9. Then Jesus said to them, "I will ask you one thing: Is it lawful on the Sabbath to do good or to do evil, to save life or to destroy?"

10. And when He had looked around at them all, He said to the man, "Stretch out your hand." And he did so, and his hand was restored as whole as the other.

11. But they were filled with rage, and discussed with one another what they might do to Jesus.

12. Now it came to pass in those days that He went out to the mountain to pray, and continued all night in prayer to God.

13. And when it was day, He called His disciples to Himself; and from them He chose twelve whom He also named apostles:

14. Simon, whom He also named Peter, and Andrew his brother; James and John; Philip and Bartholomew;

15. Matthew and Thomas; James the son of Alphaeus, and Simon called the Zealot;

16. Judas the son of James, and Judas Iscariot who also became a traitor.

17. And He came down with them and stood on a level place with a crowd of His disciples and a great multitude of people from all Judea and Jerusalem, and from the seacoast of Tyre and Sidon, who came to hear Him and be healed of their diseases,

18. as well as those who were tormented with unclean spirits. And they were healed.

19. And the whole multitude sought to touch Him, for power went out from Him and healed them all.

20. Then He lifted up His eyes toward His disciples, and said: "Blessed are you poor, For yours is the kingdom of God.

21. Blessed are you who hunger now, For you shall be filled. Blessed are you who weep now, For you shall laugh.

22. Blessed are you when men hate you, And when they exclude you, And revile you, and cast out your name as evil, For the Son of Man's sake.

23. Rejoice in that day and leap for joy! For indeed your reward is great in heaven, For in like manner their fathers did to the prophets.

24. "But woe to you who are rich, For you have received your consolation.

25. Woe to you who are full, For you shall hunger. Woe to you who laugh now, For you shall mourn and weep.

26. Woe to you when all men speak well of you, For so did their fathers to the false prophets.

27. "But I say to you who hear: Love your enemies, do good to those who hate you,

28. bless those who curse you, and pray for those who spitefully use you.

29. To him who strikes you on the one cheek, offer the other also. And from him who takes away your cloak, do not withhold your tunic either.

30. Give to everyone who asks of you. And from him who takes away your goods do not ask them back.

31. And just as you want men to do to you, you also do to them likewise.

32. "But if you love those who love you, what credit is that to you? For even sinners love those who love them.

33. And if you do good to those who do good to you, what credit is that to you? For even sinners do the same.

34. And if you lend to those from whom you hope to receive back, what credit is that to you? For even sinners lend to sinners to receive as much back.

35. But love your enemies, do good, and lend, hoping for nothing in return; and your reward will be great, and you will be sons of the Most High. For He is kind to the unthankful and evil.

36. Therefore be merciful, just as your Father also is merciful.

37. "Judge not, and you shall not be judged. Condemn not, and you shall not be condemned. Forgive, and you will be forgiven.

38. Give, and it will be given to you: good measure, pressed down, shaken together, and running over will be put into your bosom. For with the same measure that you use, it will be measured back to you."

39. And He spoke a parable to them: "Can the blind lead the blind? Will they not both fall into the ditch?

40. A disciple is not above his teacher, but everyone who is perfectly trained will be like his teacher.

41. And why do you look at the speck in your brother's eye, but do not perceive the plank in your own eye?

42. Or how can you say to your brother, "Brother, let me remove the speck that is in your eye,' when you yourself do not see the plank that is in your own eye? Hypocrite! First remove the plank from your own eye, and then you will see clearly to remove the speck that is in your brother's eye.

43. "For a good tree does not bear bad fruit, nor does a bad tree bear good fruit.

44. For every tree is known by its own fruit. For men do not gather figs from thorns, nor do they gather grapes from a bramble bush.

45. A good man out of the good treasure of his heart brings forth good; and an evil man out of the evil treasure of his heart brings forth evil. For out of the abundance of the heart his mouth speaks.

46. "But why do you call Me "Lord, Lord,' and not do the things which I say?

47. Whoever comes to Me, and hears My sayings and does them, I will show you whom he is like:

48. He is like a man building a house, who dug deep and laid the foundation on the rock. And when the flood arose, the stream beat vehemently against that house, and could not shake it, for it was founded on the rock.

49. But he who heard and did nothing is like a man who built a house on the earth without a foundation, against which the stream beat vehemently; and immediately it fell. And the ruin of that house was great."

## Chapter 7

1. Now when He concluded all His sayings in the hearing of the people, He entered Capernaum.

2. And a certain centurion's servant, who was dear to him, was sick and ready to die.

3. So when he heard about Jesus, he sent elders of the Jews to Him, pleading with Him to come and heal his servant.

4. And when they came to Jesus, they begged Him earnestly, saying that the one for whom He should do this was deserving,

5. "for he loves our nation, and has built us a synagogue."

6. Then Jesus went with them. And when He was already not far from the house, the centurion sent friends to Him, saying to Him, "Lord, do not trouble Yourself, for I am not worthy that You should enter under my roof.

7. Therefore I did not even think myself worthy to come to You. But say the word, and my servant will be healed.

8. For I also am a man placed under authority, having soldiers under me. And I say to one, "Go,' and he goes; and to another, "Come,' and he comes; and to my servant, "Do this,' and he does it."

9. When Jesus heard these things, He marveled at him, and turned around and said to the crowd that followed Him, "I say to you, I have not found such great faith, not even in Israel!"

10. And those who were sent, returning to the house, found the servant well who had been sick.

11. Now it happened, the day after, that He went into a city called Nain; and many of His disciples went with Him, and a large crowd.

12. And when He came near the gate of the city, behold, a dead man was being carried out, the only son of his mother; and she was a widow. And a large crowd from the city was with her.

13. When the Lord saw her, He had compassion on her and said to her, "Do not weep."

14. Then He came and touched the open coffin, and those who carried him stood still. And He said, "Young man, I say to you, arise."

15. So he who was dead sat up and began to speak. And He presented him to his mother.

16. Then fear came upon all, and they glorified God, saying, "A great prophet has risen up among us"; and, "God has visited His people."

17. And this report about Him went throughout all Judea and all the surrounding region.

18. Then the disciples of John reported to him concerning all these things.

19. And John, calling two of his disciples to him, sent them to Jesus, saying, "Are You the Coming One, or do we look for another?"

20. When the men had come to Him, they said, "John the Baptist has sent us to You, saying, "Are You the Coming One, or do we look for another?"'

21. And that very hour He cured many of infirmities, afflictions, and evil spirits; and to many blind He gave sight.

22. Jesus answered and said to them, "Go and tell John the things you have seen and heard: that the blind see, the lame walk, the lepers are cleansed, the deaf hear, the dead are raised, the poor have the gospel preached to them.

23. And blessed is he who is not offended because of Me."

24. When the messengers of John had departed, He began to speak to the multitudes concerning John: "What did you go out into the wilderness to see? A reed shaken by the wind?

25. But what did you go out to see? A man clothed in soft garments? Indeed those who are gorgeously appareled and live in luxury are in kings' courts.

26. But what did you go out to see? A prophet? Yes, I say to you, and more than a prophet.

27. This is he of whom it is written: "Behold, I send My messenger before Your face, Who will prepare Your way before You.'

28. For I say to you, among those born of women there is not a greater prophet than John the Baptist; but he who is least in the kingdom of God is greater than he."

29. And when all the people heard Him, even the tax collectors justified God, having been baptized with the baptism of John.

30. But the Pharisees and lawyers rejected the will of God for themselves, not having been baptized by him.

31. And the Lord said, "To what then shall I liken the men of this generation, and what are they like?

32. They are like children sitting in the marketplace and calling to one another, saying: "We played the flute for you, And you did not dance; We mourned to you, And you did not weep.'

33. For John the Baptist came neither eating bread nor drinking wine, and you say, "He has a demon.'

34. The Son of Man has come eating and drinking, and you say, "Look, a glutton and a winebibber, a friend of tax collectors and sinners!'

35. But wisdom is justified by all her children."

36. Then one of the Pharisees asked Him to eat with him. And He went to the Pharisee's house, and sat down to eat.

37. And behold, a woman in the city who was a sinner, when she knew that Jesus sat at the table in the Pharisee's house, brought an alabaster flask of fragrant oil,

38. and stood at His feet behind Him weeping; and she began to wash His feet with her tears, and wiped them with the hair of her head; and she kissed His feet and anointed them with the fragrant oil.

39. Now when the Pharisee who had invited Him saw this, he spoke to himself, saying, "This Man, if He were a prophet, would know who and what manner of woman this is who is touching Him, for she is a sinner."

40. And Jesus answered and said to him, "Simon, I have something to say to you." So he said, "Teacher, say it."

41. "There was a certain creditor who had two debtors. One owed five hundred denarii, and the other fifty.

42. And when they had nothing with which to repay, he freely forgave them both. Tell Me, therefore, which of them will love him more?"

43. Simon answered and said, "I suppose the one whom he forgave more." And He said to him, "You have rightly judged."

44. Then He turned to the woman and said to Simon, "Do you see this woman? I entered your house; you gave Me no water for My feet, but she has washed My feet with her tears and wiped them with the hair of her head.

45. You gave Me no kiss, but this woman has not ceased to kiss My feet since the time I came in.

46. You did not anoint My head with oil, but this woman has anointed My feet with fragrant oil.

47. Therefore I say to you, her sins, which are many, are forgiven, for she loved much. But to whom little is forgiven, the same loves little."

48. Then He said to her, "Your sins are forgiven."

49. And those who sat at the table with Him began to say to themselves, "Who is this who even forgives sins?"

50. Then He said to the woman, "Your faith has saved you. Go in peace."

## Chapter 8

1. Now it came to pass, afterward, that He went through every city and village, preaching and bringing the glad tidings of the kingdom of God. And the twelve were with Him,

2. and certain women who had been healed of evil spirits and infirmities--Mary called Magdalene, out of whom had come seven demons,

3. and Joanna the wife of Chuza, Herod's steward, and Susanna, and many others who provided for Him from their substance.

4. And when a great multitude had gathered, and they had come to Him from every city, He spoke by a parable:

5. "A sower went out to sow his seed. And as he sowed, some fell by the wayside; and it was trampled down, and the birds of the air devoured it.

6. Some fell on rock; and as soon as it sprang up, it withered away because it lacked moisture.

7. And some fell among thorns, and the thorns sprang up with it and choked it.

8. But others fell on good ground, sprang up, and yielded a crop a hundredfold." When He had said these things He cried, "He who has ears to hear, let him hear!"

9. Then His disciples asked Him, saying, "What does this parable mean?"

10. And He said, "To you it has been given to know the mysteries of the kingdom of God, but to the rest it is given in parables, that "Seeing they may not see, And hearing they may not understand.'

11. "Now the parable is this: The seed is the word of God.

12. Those by the wayside are the ones who hear; then the devil comes and takes away the word out of their hearts, lest they should believe and be saved.

13. But the ones on the rock are those who, when they hear, receive the word with joy; and these have no root, who believe for a while and in time of temptation fall away.

14. Now the ones that fell among thorns are those who, when they have heard, go out and are choked with cares, riches, and pleasures of life, and bring no fruit to maturity.

15. But the ones that fell on the good ground are those who, having heard the word with a noble and good heart, keep it and bear fruit with patience.

16. "No one, when he has lit a lamp, covers it with a vessel or puts it under a bed, but sets it on a lampstand, that those who enter may see the light.

17. For nothing is secret that will not be revealed, nor anything hidden that will not be known and come to light.

18. Therefore take heed how you hear. For whoever has, to him more will be given; and whoever does not have, even what he seems to have will be taken from him."

19. Then His mother and brothers came to Him, and could not approach Him because of the crowd.

20. And it was told Him by some, who said, "Your mother and Your brothers are standing outside, desiring to see You."

21. But He answered and said to them, "My mother and My brothers are these who hear the word of God and do it."

22. Now it happened, on a certain day, that He got into a boat with His disciples. And He said to them, "Let us cross over to the other side of the lake." And they launched out.

23. But as they sailed He fell asleep. And a windstorm came down on the lake, and they were filling with water, and were in jeopardy.

24. And they came to Him and awoke Him, saying, "Master, Master, we are perishing!" Then He arose and rebuked the wind and the raging of the water. And they ceased, and there was a calm.

25. But He said to them, "Where is your faith?" And they were afraid, and marveled, saying to one another, "Who can this be? For He commands even the winds and water, and they obey Him!"

26. Then they sailed to the country of the Gadarenes, which is opposite Galilee.

27. And when He stepped out on the land, there met Him a certain man from the city who had demons for a long time. And he wore no clothes, nor did he live in a house but in the tombs.

28. When he saw Jesus, he cried out, fell down before Him, and with a loud voice said, "What have I to do with You, Jesus, Son of the Most High God? I beg You, do not torment me!"

29. For He had commanded the unclean spirit to come out of the man. For it had often seized him, and he was kept under guard, bound with chains and shackles; and he broke the bonds and was driven by the demon into the wilderness.

30. Jesus asked him, saying, "What is your name?" And he said, "Legion," because many demons had entered him.

31. And they begged Him that He would not command them to go out into the abyss.

32. Now a herd of many swine was feeding there on the mountain. So they begged Him that He would permit them to enter them. And He permitted them.

33. Then the demons went out of the man and entered the swine, and the herd ran violently down the steep place into the lake and drowned.

34. When those who fed them saw what had happened, they fled and told it in the city and in the country.

35. Then they went out to see what had happened, and came to Jesus, and found the man from whom the demons had departed, sitting at the feet of Jesus, clothed and in his right mind. And they were afraid.

36. They also who had seen it told them by what means he who had been demon-possessed was healed.

37. Then the whole multitude of the surrounding region of the Gadarenes asked Him to depart from them, for they were seized with great fear. And He got into the boat and returned.

38. Now the man from whom the demons had departed begged Him that he might be with Him. But Jesus sent him away, saying,

39. "Return to your own house, and tell what great things God has done for you." And he went his way and proclaimed throughout the whole city what great things Jesus had done for him.

40. So it was, when Jesus returned, that the multitude welcomed Him, for they were all waiting for Him.

41. And behold, there came a man named Jairus, and he was a ruler of the synagogue. And he fell down at Jesus' feet and begged Him to come to his house,

42. for he had an only daughter about twelve years of age, and she was dying. But as He went, the multitudes thronged Him.

43. Now a woman, having a flow of blood for twelve years, who had spent all her livelihood on physicians and could not be healed by any,

44. came from behind and touched the border of His garment. And immediately her flow of blood stopped.

45. And Jesus said, "Who touched Me?" When all denied it, Peter and those with him said, "Master, the multitudes throng and press You, and You say, "Who touched Me?"'

46. But Jesus said, "Somebody touched Me, for I perceived power going out from Me."

47. Now when the woman saw that she was not hidden, she came trembling; and falling down before Him, she declared to Him in the presence of all the people the reason she had touched Him and how she was healed immediately.

48. And He said to her, "Daughter, be of good cheer; your faith has made you well. Go in peace."

49. While He was still speaking, someone came from the ruler of the synagogue's house, saying to him, "Your daughter is dead. Do not trouble the Teacher."

50. But when Jesus heard it, He answered him, saying, "Do not be afraid; only believe, and she will be made well."

51. When He came into the house, He permitted no one to go in except Peter, James, and John, and the father and mother of the girl.

52. Now all wept and mourned for her; but He said, "Do not weep; she is not dead, but sleeping."

53. And they ridiculed Him, knowing that she was dead.

54. But He put them all outside, took her by the hand and called, saying, "Little girl, arise."

55. Then her spirit returned, and she arose immediately. And He commanded that she be given something to eat.

56. And her parents were astonished, but He charged them to tell no one what had happened.

## Chapter 9

1. Then He called His twelve disciples together and gave them power and authority over all demons, and to cure diseases.

2. He sent them to preach the kingdom of God and to heal the sick.

3. And He said to them, "Take nothing for the journey, neither staffs nor bag nor bread nor money; and do not have two tunics apiece.

4. "Whatever house you enter, stay there, and from there depart.

5. And whoever will not receive you, when you go out of that city, shake off the very dust from your feet as a testimony against them."

6. So they departed and went through the towns, preaching the gospel and healing everywhere.

7. Now Herod the tetrarch heard of all that was done by Him; and he was perplexed, because it was said by some that John had risen from the dead,

8. and by some that Elijah had appeared, and by others that one of the old prophets had risen again.

9. Herod said, "John I have beheaded, but who is this of whom I hear such things?" So he sought to see Him.

10. And the apostles, when they had returned, told Him all that they had done. Then He took them and went aside privately into a deserted place belonging to the city called Bethsaida.

11. But when the multitudes knew it, they followed Him; and He received them and spoke to them about the kingdom of God, and healed those who had need of healing.

12. When the day began to wear away, the twelve came and said to Him, "Send the multitude away, that they may go into the surrounding towns and country, and lodge and get provisions; for we are in a deserted place here."

13. But He said to them, "You give them something to eat." And they said, "We have no more than five loaves and two fish, unless we go and buy food for all these people."

14. For there were about five thousand men. Then He said to His disciples, "Make them sit down in groups of fifty."

15. And they did so, and made them all sit down.

16. Then He took the five loaves and the two fish, and looking up to heaven, He blessed and broke them, and gave them to the disciples to set before the multitude.

17. So they all ate and were filled, and twelve baskets of the leftover fragments were taken up by them.

18. And it happened, as He was alone praying, that His disciples joined Him, and He asked them, saying, "Who do the crowds say that I am?"

19. So they answered and said, "John the Baptist, but some say Elijah; and others say that one of the old prophets has risen again."

20. He said to them, "But who do you say that I am?" Peter answered and said, "The Christ of God."

21. And He strictly warned and commanded them to tell this to no one,

22. saying, "The Son of Man must suffer many things, and be rejected by the elders and chief priests and scribes, and be killed, and be raised the third day."

23. Then He said to them all, "If anyone desires to come after Me, let him deny himself, and take up his cross daily, and follow Me.

24. For whoever desires to save his life will lose it, but whoever loses his life for My sake will save it.

25. For what profit is it to a man if he gains the whole world, and is himself destroyed or lost?

26. For whoever is ashamed of Me and My words, of him the Son of Man will be ashamed when He comes in His own glory, and in His Father's, and of the holy angels.

27. But I tell you truly, there are some standing here who shall not taste death till they see the kingdom of God."

28. Now it came to pass, about eight days after these sayings, that He took Peter, John, and James and went up on the mountain to pray.

29. As He prayed, the appearance of His face was altered, and His robe became white and glistening.

30. And behold, two men talked with Him, who were Moses and Elijah,

31. who appeared in glory and spoke of His decease which He was about to accomplish at Jerusalem.

32. But Peter and those with him were heavy with sleep; and when they were fully awake, they saw His glory and the two men who stood with Him.

33. Then it happened, as they were parting from Him, that Peter said to Jesus, "Master, it is good for us to be here; and let us make three tabernacles: one for You, one for Moses, and one for Elijah"--not knowing what he said.

34. While he was saying this, a cloud came and overshadowed them; and they were fearful as they entered the cloud.

35. And a voice came out of the cloud, saying, "This is My beloved Son. Hear Him!"

36. When the voice had ceased, Jesus was found alone. But they kept quiet, and told no one in those days any of the things they had seen.

37. Now it happened on the next day, when they had come down from the mountain, that a great multitude met Him.

38. Suddenly a man from the multitude cried out, saying, "Teacher, I implore You, look on my son, for he is my only child.

39. And behold, a spirit seizes him, and he suddenly cries out; it convulses him so that he foams at the mouth; and it departs from him with great difficulty, bruising him.

40. So I implored Your disciples to cast it out, but they could not."

41. Then Jesus answered and said, "O faithless and perverse generation, how long shall I be with you and bear with you? Bring your son here."

42. And as he was still coming, the demon threw him down and convulsed him. Then Jesus rebuked the unclean spirit, healed the child, and gave him back to his father.

43. And they were all amazed at the majesty of God. But while everyone marveled at all the things which Jesus did, He said to His disciples,

44. "Let these words sink down into your ears, for the Son of Man is about to be betrayed into the hands of men."

45. But they did not understand this saying, and it was hidden from them so that they did not perceive it; and they were afraid to ask Him about this saying.

46. Then a dispute arose among them as to which of them would be greatest.

47. And Jesus, perceiving the thought of their heart, took a little child and set him by Him,

48. and said to them, "Whoever receives this little child in My name receives Me; and whoever receives Me receives Him who sent Me. For he who is least among you all will be great."

49. Now John answered and said, "Master, we saw someone casting out demons in Your name, and we forbade him because he does not follow with us."

50. But Jesus said to him, "Do not forbid him, for he who is not against us is on our side."

51. Now it came to pass, when the time had come for Him to be received up, that He steadfastly set His face to go to Jerusalem,

52. and sent messengers before His face. And as they went, they entered a village of the Samaritans, to prepare for Him.

53. But they did not receive Him, because His face was set for the journey to Jerusalem.

54. And when His disciples James and John saw this, they said, "Lord, do You want us to command fire to come down from heaven and consume them, just as Elijah did?"

55. But He turned and rebuked them, and said, "You do not know what manner of spirit you are of.

56. For the Son of Man did not come to destroy men's lives but to save them." And they went to another village.

57. Now it happened as they journeyed on the road, that someone said to Him, "Lord, I will follow You wherever You go."

58. And Jesus said to him, "Foxes have holes and birds of the air have nests, but the Son of Man has nowhere to lay His head."

59. Then He said to another, "Follow Me." But he said, "Lord, let me first go and bury my father."

60. Jesus said to him, "Let the dead bury their own dead, but you go and preach the kingdom of God."

61. And another also said, "Lord, I will follow You, but let me first go and bid them farewell who are at my house."

62. But Jesus said to him, "No one, having put his hand to the plow, and looking back, is fit for the kingdom of God."

## Chapter 10

1. After these things the Lord appointed seventy others also, and sent them two by two before His face into every city and place where He Himself was about to go.

2. Then He said to them, "The harvest truly is great, but the laborers are few; therefore pray the Lord of the harvest to send out laborers into His harvest.

3. Go your way; behold, I send you out as lambs among wolves.

4. Carry neither money bag, knapsack, nor sandals; and greet no one along the road.

5. But whatever house you enter, first say, "Peace to this house.'

6. And if a son of peace is there, your peace will rest on it; if not, it will return to you.

7. And remain in the same house, eating and drinking such things as they give, for the laborer is worthy of his wages. Do not go from house to house.

8. Whatever city you enter, and they receive you, eat such things as are set before you.

9. And heal the sick there, and say to them, "The kingdom of God has come near to you.'

10. But whatever city you enter, and they do not receive you, go out into its streets and say,

11. "The very dust of your city which clings to us we wipe off against you. Nevertheless know this, that the kingdom of God has come near you.'

12. But I say to you that it will be more tolerable in that Day for Sodom than for that city.

13. "Woe to you, Chorazin! Woe to you, Bethsaida! For if the mighty works which were done in you had been done in Tyre and Sidon, they would have repented long ago, sitting in sackcloth and ashes.

14. But it will be more tolerable for Tyre and Sidon at the judgment than for you.

15. And you, Capernaum, who are exalted to heaven, will be brought down to Hades.

16. He who hears you hears Me, he who rejects you rejects Me, and he who rejects Me rejects Him who sent Me."

17. Then the seventy returned with joy, saying, "Lord, even the demons are subject to us in Your name."

18. And He said to them, "I saw Satan fall like lightning from heaven.

19. Behold, I give you the authority to trample on serpents and scorpions, and over all the power of the enemy, and nothing shall by any means hurt you.

20. Nevertheless do not rejoice in this, that the spirits are subject to you, but rather rejoice because your names are written in heaven."

21. In that hour Jesus rejoiced in the Spirit and said, "I thank You, Father, Lord of heaven and earth, that You have hidden these things from the wise and prudent and revealed them to babes. Even so, Father, for so it seemed good in Your sight.

22. All things have been delivered to Me by My Father, and no one knows who the Son is except the Father, and who the Father is except the Son, and the one to whom the Son wills to reveal Him."

23. Then He turned to His disciples and said privately, "Blessed are the eyes which see the things you see;

24. for I tell you that many prophets and kings have desired to see what you see, and have not seen it, and to hear what you hear, and have not heard it."

25. And behold, a certain lawyer stood up and tested Him, saying, "Teacher, what shall I do to inherit eternal life?"

26. He said to him, "What is written in the law? What is your reading of it?"

27. So he answered and said, ""You shall love the LORD your God with all your heart, with all your soul, with all your strength, and with all your mind,' and "your neighbor as yourself."'

28. And He said to him, "You have answered rightly; do this and you will live."

29. But he, wanting to justify himself, said to Jesus, "And who is my neighbor?"

30. Then Jesus answered and said: "A certain man went down from Jerusalem to Jericho, and fell among thieves, who stripped him of his clothing, wounded him, and departed, leaving him half dead.

31. Now by chance a certain priest came down that road. And when he saw him, he passed by on the other side.

32. Likewise a Levite, when he arrived at the place, came and looked, and passed by on the other side.

33. But a certain Samaritan, as he journeyed, came where he was. And when he saw him, he had compassion.

34. So he went to him and bandaged his wounds, pouring on oil and wine; and he set him on his own animal, brought him to an inn, and took care of him.

35. On the next day, when he departed, he took out two denarii, gave them to the innkeeper, and said to him, "Take care of him; and whatever more you spend, when I come again, I will repay you.'

36. So which of these three do you think was neighbor to him who fell among the thieves?"

37. And he said, "He who showed mercy on him." Then Jesus said to him, "Go and do likewise."

38. Now it happened as they went that He entered a certain village; and a certain woman named Martha welcomed Him into her house.

39. And she had a sister called Mary, who also sat at Jesus' feet and heard His word.

40. But Martha was distracted with much serving, and she approached Him and said, "Lord, do You not care that my sister has left me to serve alone? Therefore tell her to help me."

41. And Jesus answered and said to her, "Martha, Martha, you are worried and troubled about many things.

42. But one thing is needed, and Mary has chosen that good part, which will not be taken away from her."

## Chapter 11

1. Now it came to pass, as He was praying in a certain place, when He ceased, that one of His disciples said to Him, "Lord, teach us to pray, as John also taught his disciples."

2. So He said to them, "When you pray, say: Our Father in heaven, Hallowed be Your name. Your kingdom come. Your will be done On earth as it is in heaven.

3. Give us day by day our daily bread.

4. And forgive us our sins, For we also forgive everyone who is indebted to us. And do not lead us into temptation, But deliver us from the evil one."

5. And He said to them, "Which of you shall have a friend, and go to him at midnight and say to him, "Friend, lend me three loaves;

6. for a friend of mine has come to me on his journey, and I have nothing to set before him';

7. and he will answer from within and say, "Do not trouble me; the door is now shut, and my children are with me in bed; I cannot rise and give to you'?

8. I say to you, though he will not rise and give to him because he is his friend, yet because of his persistence he will rise and give him as many as he needs.

9. "So I say to you, ask, and it will be given to you; seek, and you will find; knock, and it will be opened to you.

10. For everyone who asks receives, and he who seeks finds, and to him who knocks it will be opened.

11. If a son asks for bread from any father among you, will he give him a stone? Or if he asks for a fish, will he give him a serpent instead of a fish?

12. Or if he asks for an egg, will he offer him a scorpion?

13. If you then, being evil, know how to give good gifts to your children, how much more will your heavenly Father give the Holy Spirit to those who ask Him!"

14. And He was casting out a demon, and it was mute. So it was, when the demon had gone out, that the mute spoke; and the multitudes marveled.

15. But some of them said, "He casts out demons by Beelzebub, the ruler of the demons."

16. Others, testing Him, sought from Him a sign from heaven.

17. But He, knowing their thoughts, said to them: "Every kingdom divided against itself is brought to desolation, and a house divided against a house falls.

18. If Satan also is divided against himself, how will his kingdom stand? Because you say I cast out demons by Beelzebub.

19. And if I cast out demons by Beelzebub, by whom do your sons cast them out? Therefore they will be your judges.

20. But if I cast out demons with the finger of God, surely the kingdom of God has come upon you.

21. When a strong man, fully armed, guards his own palace, his goods are in peace.

22. But when a stronger than he comes upon him and overcomes him, he takes from him all his armor in which he trusted, and divides his spoils.

23. He who is not with Me is against Me, and he who does not gather with Me scatters.

24. "When an unclean spirit goes out of a man, he goes through dry places, seeking rest; and finding none, he says, "I will return to my house from which I came.'

25. And when he comes, he finds it swept and put in order.

26. Then he goes and takes with him seven other spirits more wicked than himself, and they enter and dwell there; and the last state of that man is worse than the first."

27. And it happened, as He spoke these things, that a certain woman from the crowd raised her voice and said to Him, "Blessed is the womb that bore You, and the breasts which nursed You!"

28. But He said, "More than that, blessed are those who hear the word of God and keep it!"

29. And while the crowds were thickly gathered together, He began to say, "This is an evil generation. It seeks a sign, and no sign will be given to it except the sign of Jonah the prophet.

30. For as Jonah became a sign to the Ninevites, so also the Son of Man will be to this generation.

31. The queen of the South will rise up in the judgment with the men of this generation and condemn them, for she came from the ends of the earth to hear the wisdom of Solomon; and indeed a greater than Solomon is here.

32. The men of Nineveh will rise up in the judgment with this generation and condemn it, for they repented at the preaching of Jonah; and indeed a greater than Jonah is here.

33. "No one, when he has lit a lamp, puts it in a secret place or under a basket, but on a lampstand, that those who come in may see the light.

34. The lamp of the body is the eye. Therefore, when your eye is good, your whole body also is full of light. But when your eye is bad, your body also is full of darkness.

35. Therefore take heed that the light which is in you is not darkness.

36. If then your whole body is full of light, having no part dark, the whole body will be full of light, as when the bright shining of a lamp gives you light."

37. And as He spoke, a certain Pharisee asked Him to dine with him. So He went in and sat down to eat.

38. When the Pharisee saw it, he marveled that He had not first washed before dinner.

39. Then the Lord said to him, "Now you Pharisees make the outside of the cup and dish clean, but your inward part is full of greed and wickedness.

40. Foolish ones! Did not He who made the outside make the inside also?

41. But rather give alms of such things as you have; then indeed all things are clean to you.

42. "But woe to you Pharisees! For you tithe mint and rue and all manner of herbs, and pass by justice and the love of God. These you ought to have done, without leaving the others undone.

43. Woe to you Pharisees! For you love the best seats in the synagogues and greetings in the marketplaces.

44. Woe to you, scribes and Pharisees, hypocrites! For you are like graves which are not seen, and the men who walk over them are not aware of them."

45. Then one of the lawyers answered and said to Him, "Teacher, by saying these things You reproach us also."

46. And He said, "Woe to you also, lawyers! For you load men with burdens hard to bear, and you yourselves do not touch the burdens with one of your fingers.

47. Woe to you! For you build the tombs of the prophets, and your fathers killed them.

48. In fact, you bear witness that you approve the deeds of your fathers; for they indeed killed them, and you build their tombs.

49. Therefore the wisdom of God also said, "I will send them prophets and apostles, and some of them they will kill and persecute,'

50. that the blood of all the prophets which was shed from the foundation of the world may be required of this generation,

51. from the blood of Abel to the blood of Zechariah who perished between the altar and the temple. Yes, I say to you, it shall be required of this generation.

52. "Woe to you lawyers! For you have taken away the key of knowledge. You did not enter in yourselves, and those who were entering in you hindered."

53. And as He said these things to them, the scribes and the Pharisees began to assail Him vehemently, and to cross-examine Him about many things,

54. lying in wait for Him, and seeking to catch Him in something He might say, that they might accuse Him.

## Chapter 12

1. In the meantime, when an innumerable multitude of people had gathered together, so that they trampled one another, He began to say to His disciples first of all, "Beware of the leaven of the Pharisees, which is hypocrisy.

2. For there is nothing covered that will not be revealed, nor hidden that will not be known.

3. Therefore whatever you have spoken in the dark will be heard in the light, and what you have spoken in the ear in inner rooms will be proclaimed on the housetops.

4. "And I say to you, My friends, do not be afraid of those who kill the body, and after that have no more that they can do.

5. But I will show you whom you should fear: Fear Him who, after He has killed, has power to cast into hell; yes, I say to you, fear Him!

6. "Are not five sparrows sold for two copper coins? And not one of them is forgotten before God.

7. But the very hairs of your head are all numbered. Do not fear therefore; you are of more value than many sparrows.

8. "Also I say to you, whoever confesses Me before men, him the Son of Man also will confess before the angels of God.

9. But he who denies Me before men will be denied before the angels of God.

10. "And anyone who speaks a word against the Son of Man, it will be forgiven him; but to him who blasphemes against the Holy Spirit, it will not be forgiven.

11. "Now when they bring you to the synagogues and magistrates and authorities, do not worry about how or what you should answer, or what you should say.

12. For the Holy Spirit will teach you in that very hour what you ought to say."

13. Then one from the crowd said to Him, "Teacher, tell my brother to divide the inheritance with me."

14. But He said to him, "Man, who made Me a judge or an arbitrator over you?"

15. And He said to them, "Take heed and beware of covetousness, for one's life does not consist in the abundance of the things he possesses."

16. Then He spoke a parable to them, saying: "The ground of a certain rich man yielded plentifully.

17. And he thought within himself, saying, "What shall I do, since I have no room to store my crops?'

18. So he said, "I will do this: I will pull down my barns and build greater, and there I will store all my crops and my goods.

19. And I will say to my soul, "Soul, you have many goods laid up for many years; take your ease; eat, drink, and be merry."'

20. But God said to him, "Fool! This night your soul will be required of you; then whose will those things be which you have provided?'

21. "So is he who lays up treasure for himself, and is not rich toward God."

22. Then He said to His disciples, "Therefore I say to you, do not worry about your life, what you will eat; nor about the body, what you will put on.

23. Life is more than food, and the body is more than clothing.

24. Consider the ravens, for they neither sow nor reap, which have neither storehouse nor barn; and God feeds them. Of how much more value are you than the birds?

25. And which of you by worrying can add one cubit to his stature?

26. If you then are not able to do the least, why are you anxious for the rest?

27. Consider the lilies, how they grow: they neither toil nor spin; and yet I say to you, even Solomon in all his glory was not arrayed like one of these.

28. If then God so clothes the grass, which today is in the field and tomorrow is thrown into the oven, how much more will He clothe you, O you of little faith?

29. "And do not seek what you should eat or what you should drink, nor have an anxious mind.

30. For all these things the nations of the world seek after, and your Father knows that you need these things.

31. But seek the kingdom of God, and all these things shall be added to you.

32. "Do not fear, little flock, for it is your Father's good pleasure to give you the kingdom.

33. Sell what you have and give alms; provide yourselves money bags which do not grow old, a treasure in the heavens that does not fail, where no thief approaches nor moth destroys.

34. For where your treasure is, there your heart will be also.

35. "Let your waist be girded and your lamps burning;

36. and you yourselves be like men who wait for their master, when he will return from the wedding, that when he comes and knocks they may open to him immediately.

37. Blessed are those servants whom the master, when he comes, will find watching. Assuredly, I say to you that he will gird himself and have them sit down to eat, and will come and serve them.

38. And if he should come in the second watch, or come in the third watch, and find them so, blessed are those servants.

39. But know this, that if the master of the house had known what hour the thief would come, he would have watched and not allowed his house to be broken into.

40. Therefore you also be ready, for the Son of Man is coming at an hour you do not expect."

41. Then Peter said to Him, "Lord, do You speak this parable only to us, or to all people?"

42. And the Lord said, "Who then is that faithful and wise steward, whom his master will make ruler over his household, to give them their portion of food in due season?

43. Blessed is that servant whom his master will find so doing when he comes.

44. Truly, I say to you that he will make him ruler over all that he has.

45. But if that servant says in his heart, "My master is delaying his coming,' and begins to beat the male and female servants, and to eat and drink and be drunk,

46. the master of that servant will come on a day when he is not looking for him, and at an hour when he is not aware, and will cut him in two and appoint him his portion with the unbelievers.

47. And that servant who knew his master's will, and did not prepare himself or do according to his will, shall be beaten with many stripes.

48. But he who did not know, yet committed things deserving of stripes, shall be beaten with few. For everyone to whom much is given, from him much will be required; and to whom much has been committed, of him they will ask the more.

49. "I came to send fire on the earth, and how I wish it were already kindled!

50. But I have a baptism to be baptized with, and how distressed I am till it is accomplished!

51. Do you suppose that I came to give peace on earth? I tell you, not at all, but rather division.

52. For from now on five in one house will be divided: three against two, and two against three.

53. Father will be divided against son and son against father, mother against daughter and daughter against mother, mother-in-law against her daughter-in-law and daughter-in-law against her mother-in-law."

54. Then He also said to the multitudes, "Whenever you see a cloud rising out of the west, immediately you say, "A shower is coming'; and so it is.

55. And when you see the south wind blow, you say, "There will be hot weather'; and there is.

56. Hypocrites! You can discern the face of the sky and of the earth, but how is it you do not discern this time?

57. "Yes, and why, even of yourselves, do you not judge what is right?

58. When you go with your adversary to the magistrate, make every effort along the way to settle with him, lest he drag you to the judge, the judge deliver you to the officer, and the officer throw you into prison.

59. I tell you, you shall not depart from there till you have paid the very last mite."

## Chapter 13

1. There were present at that season some who told Him about the Galileans whose blood Pilate had mingled with their sacrifices.

2. And Jesus answered and said to them, "Do you suppose that these Galileans were worse sinners than all other Galileans, because they suffered such things?

3. I tell you, no; but unless you repent you will all likewise perish.

4. Or those eighteen on whom the tower in Siloam fell and killed them, do you think that they were worse sinners than all other men who dwelt in Jerusalem?

5. I tell you, no; but unless you repent you will all likewise perish."

6. He also spoke this parable: "A certain man had a fig tree planted in his vineyard, and he came seeking fruit on it and found none.

7. Then he said to the keeper of his vineyard, "Look, for three years I have come seeking fruit on this fig tree and find none. Cut it down; why does it use up the ground?'

8. But he answered and said to him, "Sir, let it alone this year also, until I dig around it and fertilize it.

9. And if it bears fruit, well. But if not, after that you can cut it down."'

10. Now He was teaching in one of the synagogues on the Sabbath.

11. And behold, there was a woman who had a spirit of infirmity eighteen years, and was bent over and could in no way raise herself up.

12. But when Jesus saw her, He called her to Him and said to her, "Woman, you are loosed from your infirmity."

13. And He laid His hands on her, and immediately she was made straight, and glorified God.

14. But the ruler of the synagogue answered with indignation, because Jesus had healed on the Sabbath; and he said to the crowd, "There are six days on which men ought to work; therefore come and be healed on them, and not on the Sabbath day."

15. The Lord then answered him and said, "Hypocrite! Does not each one of you on the Sabbath loose his ox or donkey from the stall, and lead it away to water it?

16. So ought not this woman, being a daughter of Abraham, whom Satan has bound--think of it--for eighteen years, be loosed from this bond on the Sabbath?"

17. And when He said these things, all His adversaries were put to shame; and all the multitude rejoiced for all the glorious things that were done by Him.

18. Then He said, "What is the kingdom of God like? And to what shall I compare it?

19. It is like a mustard seed, which a man took and put in his garden; and it grew and became a large tree, and the birds of the air nested in its branches."

20. And again He said, "To what shall I liken the kingdom of God?

21. It is like leaven, which a woman took and hid in three measures of meal till it was all leavened."

22. And He went through the cities and villages, teaching, and journeying toward Jerusalem.

23. Then one said to Him, "Lord, are there few who are saved?" And He said to them,

24. "Strive to enter through the narrow gate, for many, I say to you, will seek to enter and will not be able.

25. When once the Master of the house has risen up and shut the door, and you begin to stand outside and knock at the door, saying, "Lord, Lord, open for us,' and He will answer and say to you, "I do not know you, where you are from,'

26. then you will begin to say, "We ate and drank in Your presence, and You taught in our streets.'

27. But He will say, "I tell you I do not know you, where you are from. Depart from Me, all you workers of iniquity.'

28. There will be weeping and gnashing of teeth, when you see Abraham and Isaac and Jacob and all the prophets in the kingdom of God, and yourselves thrust out.

29. They will come from the east and the west, from the north and the south, and sit down in the kingdom of God.

30. And indeed there are last who will be first, and there are first who will be last."

31. On that very day some Pharisees came, saying to Him, "Get out and depart from here, for Herod wants to kill You."

32. And He said to them, "Go, tell that fox, "Behold, I cast out demons and perform cures today and tomorrow, and the third day I shall be perfected.'

33. Nevertheless I must journey today, tomorrow, and the day following; for it cannot be that a prophet should perish outside of Jerusalem.

34. "O Jerusalem, Jerusalem, the one who kills the prophets and stones those who are sent to her! How often I wanted to gather your children together, as a hen gathers her brood under her wings, but you were not willing!

35. See! Your house is left to you desolate; and assuredly, I say to you, you shall not see Me until the time comes when you say, "Blessed is He who comes in the name of the LORD!"'

## Chapter 14

1. Now it happened, as He went into the house of one of the rulers of the Pharisees to eat bread on the Sabbath, that they watched Him closely.

2. And behold, there was a certain man before Him who had dropsy.

3. And Jesus, answering, spoke to the lawyers and Pharisees, saying, "Is it lawful to heal on the Sabbath?"

4. But they kept silent. And He took him and healed him, and let him go.

5. Then He answered them, saying, "Which of you, having a donkey or an ox that has fallen into a pit, will not immediately pull him out on the Sabbath day?"

6. And they could not answer Him regarding these things.

7. So He told a parable to those who were invited, when He noted how they chose the best places, saying to them:

8. "When you are invited by anyone to a wedding feast, do not sit down in the best place, lest one more honorable than you be invited by him;

9. and he who invited you and him come and say to you, "Give place to this man,' and then you begin with shame to take the lowest place.

10. But when you are invited, go and sit down in the lowest place, so that when he who invited you comes he may say to you, "Friend, go up higher.' Then you will have glory in the presence of those who sit at the table with you.

11. For whoever exalts himself will be humbled, and he who humbles himself will be exalted."

12. Then He also said to him who invited Him, "When you give a dinner or a supper, do not ask your friends, your brothers, your relatives, nor rich neighbors, lest they also invite you back, and you be repaid.

13. But when you give a feast, invite the poor, the maimed, the lame, the blind.

14. And you will be blessed, because they cannot repay you; for you shall be repaid at the resurrection of the just."

15. Now when one of those who sat at the table with Him heard these things, he said to Him, "Blessed is he who shall eat bread in the kingdom of God!"

16. Then He said to him, "A certain man gave a great supper and invited many,

17. and sent his servant at supper time to say to those who were invited, "Come, for all things are now ready.'

18. But they all with one accord began to make excuses. The first said to him, "I have bought a piece of ground, and I must go and see it. I ask you to have me excused.'

19. And another said, "I have bought five yoke of oxen, and I am going to test them. I ask you to have me excused.'

20. Still another said, "I have married a wife, and therefore I cannot come.'

21. So that servant came and reported these things to his master. Then the master of the house, being angry, said to his servant, "Go out quickly into the streets and lanes of the city, and bring in here the poor and the maimed and the lame and the blind.'

22. And the servant said, "Master, it is done as you commanded, and still there is room.'

23. Then the master said to the servant, "Go out into the highways and hedges, and compel them to come in, that my house may be filled.

24. For I say to you that none of those men who were invited shall taste my supper."'

25. Now great multitudes went with Him. And He turned and said to them,

26. "If anyone comes to Me and does not hate his father and mother, wife and children, brothers and sisters, yes, and his own life also, he cannot be My disciple.

27. And whoever does not bear his cross and come after Me cannot be My disciple.

28. For which of you, intending to build a tower, does not sit down first and count the cost, whether he has enough to finish it--

29. lest, after he has laid the foundation, and is not able to finish, all who see it begin to mock him,

30. saying, "This man began to build and was not able to finish.'

31. Or what king, going to make war against another king, does not sit down first and consider whether he is able with ten thousand to meet him who comes against him with twenty thousand?

32. Or else, while the other is still a great way off, he sends a delegation and asks conditions of peace.

33. So likewise, whoever of you does not forsake all that he has cannot be My disciple.

34. "Salt is good; but if the salt has lost its flavor, how shall it be seasoned?

35. It is neither fit for the land nor for the dunghill, but men throw it out. He who has ears to hear, let him hear!"

## Chapter 15

1. Then all the tax collectors and the sinners drew near to Him to hear Him.

2. And the Pharisees and scribes complained, saying, "This Man receives sinners and eats with them."

3. So He spoke this parable to them, saying:

4. "What man of you, having a hundred sheep, if he loses one of them, does not leave the ninety-nine in the wilderness, and go after the one which is lost until he finds it?

5. And when he has found it, he lays it on his shoulders, rejoicing.

6. And when he comes home, he calls together his friends and neighbors, saying to them, "Rejoice with me, for I have found my sheep which was lost!'

7. I say to you that likewise there will be more joy in heaven over one sinner who repents than over ninety-nine just persons who need no repentance.

8. "Or what woman, having ten silver coins, if she loses one coin, does not light a lamp, sweep the house, and search carefully until she finds it?

9. And when she has found it, she calls her friends and neighbors together, saying, "Rejoice with me, for I have found the piece which I lost!'

10. Likewise, I say to you, there is joy in the presence of the angels of God over one sinner who repents."

11. Then He said: "A certain man had two sons.

12. And the younger of them said to his father, "Father, give me the portion of goods that falls to me.' So he divided to them his livelihood.

13. And not many days after, the younger son gathered all together, journeyed to a far country, and there wasted his possessions with prodigal living.

14. But when he had spent all, there arose a severe famine in that land, and he began to be in want.

15. Then he went and joined himself to a citizen of that country, and he sent him into his fields to feed swine.

16. And he would gladly have filled his stomach with the pods that the swine ate, and no one gave him anything.

17. "But when he came to himself, he said, "How many of my father's hired servants have bread enough and to spare, and I perish with hunger!

18. I will arise and go to my father, and will say to him, "Father, I have sinned against heaven and before you,

19. and I am no longer worthy to be called your son. Make me like one of your hired servants."'

20. "And he arose and came to his father. But when he was still a great way off, his father saw him and had compassion, and ran and fell on his neck and kissed him.

21. And the son said to him, "Father, I have sinned against heaven and in your sight, and am no longer worthy to be called your son.'

22. "But the father said to his servants, "Bring out the best robe and put it on him, and put a ring on his hand and sandals on his feet.

23. And bring the fatted calf here and kill it, and let us eat and be merry;

24. for this my son was dead and is alive again; he was lost and is found.' And they began to be merry.

25. "Now his older son was in the field. And as he came and drew near to the house, he heard music and dancing.

26. So he called one of the servants and asked what these things meant.

27. And he said to him, "Your brother has come, and because he has received him safe and sound, your father has killed the fatted calf.'

28. "But he was angry and would not go in. Therefore his father came out and pleaded with him.

29. So he answered and said to his father, "Lo, these many years I have been serving you; I never transgressed your commandment at any time; and yet you never gave me a young goat, that I might make merry with my friends.

30. But as soon as this son of yours came, who has devoured your livelihood with harlots, you killed the fatted calf for him.'

31. "And he said to him, "Son, you are always with me, and all that I have is yours.

32. It was right that we should make merry and be glad, for your brother was dead and is alive again, and was lost and is found."'

## Chapter 16

1. He also said to His disciples: "There was a certain rich man who had a steward, and an accusation was brought to him that this man was wasting his goods.

2. So he called him and said to him, "What is this I hear about you? Give an account of your stewardship, for you can no longer be steward.'

3. "Then the steward said within himself, "What shall I do? For my master is taking the stewardship away from me. I cannot dig; I am ashamed to beg.

4. I have resolved what to do, that when I am put out of the stewardship, they may receive me into their houses.'

5. "So he called every one of his master's debtors to him, and said to the first, "How much do you owe my master?'

6. And he said, "A hundred measures of oil.' So he said to him, "Take your bill, and sit down quickly and write fifty.'

7. Then he said to another, "And how much do you owe?' So he said, "A hundred measures of wheat.' And he said to him, "Take your bill, and write eighty.'

8. So the master commended the unjust steward because he had dealt shrewdly. For the sons of this world are more shrewd in their generation than the sons of light.

9. "And I say to you, make friends for yourselves by unrighteous mammon, that when you fail, they may receive you into an everlasting home.

10. He who is faithful in what is least is faithful also in much; and he who is unjust in what is least is unjust also in much.

11. Therefore if you have not been faithful in the unrighteous mammon, who will commit to your trust the true riches?

12. And if you have not been faithful in what is another man's, who will give you what is your own?

13. "No servant can serve two masters; for either he will hate the one and love the other, or else he will be loyal to the one and despise the other. You cannot serve God and mammon."

14. Now the Pharisees, who were lovers of money, also heard all these things, and they derided Him.

15. And He said to them, "You are those who justify yourselves before men, but God knows your hearts. For what is highly esteemed among men is an abomination in the sight of God.

16. "The law and the prophets were until John. Since that time the kingdom of God has been preached, and everyone is pressing into it.

17. And it is easier for heaven and earth to pass away than for one tittle of the law to fail.

18. "Whoever divorces his wife and marries another commits adultery; and whoever marries her who is divorced from her husband commits adultery.

19. "There was a certain rich man who was clothed in purple and fine linen and fared sumptuously every day.

20. But there was a certain beggar named Lazarus, full of sores, who was laid at his gate,

21. desiring to be fed with the crumbs which fell from the rich man's table. Moreover the dogs came and licked his sores.

22. So it was that the beggar died, and was carried by the angels to Abraham's bosom. The rich man also died and was buried.

23. And being in torments in Hades, he lifted up his eyes and saw Abraham afar off, and Lazarus in his bosom.

24. "Then he cried and said, "Father Abraham, have mercy on me, and send Lazarus that he may dip the tip of his finger in water and cool my tongue; for I am tormented in this flame.'

25. But Abraham said, "Son, remember that in your lifetime you received your good things, and likewise Lazarus evil things; but now he is comforted and you are tormented.

26. And besides all this, between us and you there is a great gulf fixed, so that those who want to pass from here to you cannot, nor can those from there pass to us.'

27. "Then he said, "I beg you therefore, father, that you would send him to my father's house,

28. for I have five brothers, that he may testify to them, lest they also come to this place of torment.'

29. Abraham said to him, "They have Moses and the prophets; let them hear them.'

30. And he said, "No, father Abraham; but if one goes to them from the dead, they will repent.'

31. But he said to him, "If they do not hear Moses and the prophets, neither will they be persuaded though one rise from the dead."'

## Chapter 17

1. Then He said to the disciples, "It is impossible that no offenses should come, but woe to him through whom they do come!

2. It would be better for him if a millstone were hung around his neck, and he were thrown into the sea, than that he should offend one of these little ones.

3. Take heed to yourselves. If your brother sins against you, rebuke him; and if he repents, forgive him.

4. And if he sins against you seven times in a day, and seven times in a day returns to you, saying, "I repent,' you shall forgive him."

5. And the apostles said to the Lord, "Increase our faith."

6. So the Lord said, "If you have faith as a mustard seed, you can say to this mulberry tree, "Be pulled up by the roots and be planted in the sea,' and it would obey you.

7. And which of you, having a servant plowing or tending sheep, will say to him when he has come in from the field, "Come at once and sit down to eat'?

8. But will he not rather say to him, "Prepare something for my supper, and gird yourself and serve me till I have eaten and drunk, and afterward you will eat and drink'?

9. Does he thank that servant because he did the things that were commanded him? I think not.

10. So likewise you, when you have done all those things which you are commanded, say, "We are unprofitable servants. We have done what was our duty to do."'

11. Now it happened as He went to Jerusalem that He passed through the midst of Samaria and Galilee.

12. Then as He entered a certain village, there met Him ten men who were lepers, who stood afar off.

13. And they lifted up their voices and said, "Jesus, Master, have mercy on us!"

14. So when He saw them, He said to them, "Go, show yourselves to the priests." And so it was that as they went, they were cleansed.

15. And one of them, when he saw that he was healed, returned, and with a loud voice glorified God,

16. and fell down on his face at His feet, giving Him thanks. And he was a Samaritan.

17. So Jesus answered and said, "Were there not ten cleansed? But where are the nine?

18. Were there not any found who returned to give glory to God except this foreigner?"

19. And He said to him, "Arise, go your way. Your faith has made you well."

20. Now when He was asked by the Pharisees when the kingdom of God would come, He answered them and said, "The kingdom of God does not come with observation;

21. nor will they say, "See here!' or "See there!' For indeed, the kingdom of God is within you."

22. Then He said to the disciples, "The days will come when you will desire to see one of the days of the Son of Man, and you will not see it.

23. And they will say to you, "Look here!' or "Look there!' Do not go after them or follow them.

24. For as the lightning that flashes out of one part under heaven shines to the other part under heaven, so also the Son of Man will be in His day.

25. But first He must suffer many things and be rejected by this generation.

26. And as it was in the days of Noah, so it will be also in the days of the Son of Man:

27. They ate, they drank, they married wives, they were given in marriage, until the day that Noah entered the ark, and the flood came and destroyed them all.

28. Likewise as it was also in the days of Lot: They ate, they drank, they bought, they sold, they planted, they built;

29. but on the day that Lot went out of Sodom it rained fire and brimstone from heaven and destroyed them all.

30. Even so will it be in the day when the Son of Man is revealed.

31. "In that day, he who is on the housetop, and his goods are in the house, let him not come down to take them away. And likewise the one who is in the field, let him not turn back.

32. Remember Lot's wife.

33. Whoever seeks to save his life will lose it, and whoever loses his life will preserve it.

34. I tell you, in that night there will be two men in one bed: the one will be taken and the other will be left.

35. Two women will be grinding together: the one will be taken and the other left.

36. Two men will be in the field: the one will be taken and the other left."

37. And they answered and said to Him, "Where, Lord?" So He said to them, "Wherever the body is, there the eagles will be gathered together."

## Chapter 18

1. Then He spoke a parable to them, that men always ought to pray and not lose heart,

2. saying: "There was in a certain city a judge who did not fear God nor regard man.

3. Now there was a widow in that city; and she came to him, saying, "Get justice for me from my adversary.'

4. And he would not for a while; but afterward he said within himself, "Though I do not fear God nor regard man,

5. yet because this widow troubles me I will avenge her, lest by her continual coming she weary me."'

6. Then the Lord said, "Hear what the unjust judge said.

7. And shall God not avenge His own elect who cry out day and night to Him, though He bears long with them?

8. I tell you that He will avenge them speedily. Nevertheless, when the Son of Man comes, will He really find faith on the earth?"

9. Also He spoke this parable to some who trusted in themselves that they were righteous, and despised others:

10. "Two men went up to the temple to pray, one a Pharisee and the other a tax collector.

11. The Pharisee stood and prayed thus with himself, "God, I thank You that I am not like other men--extortioners, unjust, adulterers, or even as this tax collector.

12. I fast twice a week; I give tithes of all that I possess.'

13. And the tax collector, standing afar off, would not so much as raise his eyes to heaven, but beat his breast, saying, "God, be merciful to me a sinner!'

14. I tell you, this man went down to his house justified rather than the other; for everyone who exalts himself will be humbled, and he who humbles himself will be exalted."

15. Then they also brought infants to Him that He might touch them; but when the disciples saw it, they rebuked them.

16. But Jesus called them to Him and said, "Let the little children come to Me, and do not forbid them; for of such is the kingdom of God.

17. Assuredly, I say to you, whoever does not receive the kingdom of God as a little child will by no means enter it."

18. Now a certain ruler asked Him, saying, "Good Teacher, what shall I do to inherit eternal life?"

19. So Jesus said to him, "Why do you call Me good? No one is good but One, that is, God.

20. You know the commandments: "Do not commit adultery,' "Do not murder,' "Do not steal,' "Do not bear false witness,' "Honor your father and your mother."'

21. And he said, "All these things I have kept from my youth."

22. So when Jesus heard these things, He said to him, "You still lack one thing. Sell all that you have and distribute to the poor, and you will have treasure in heaven; and come, follow Me."

23. But when he heard this, he became very sorrowful, for he was very rich.

24. And when Jesus saw that he became very sorrowful, He said, "How hard it is for those who have riches to enter the kingdom of God!

25. For it is easier for a camel to go through the eye of a needle than for a rich man to enter the kingdom of God."

26. And those who heard it said, "Who then can be saved?"

27. But He said, "The things which are impossible with men are possible with God."

28. Then Peter said, "See, we have left all and followed You."

29. So He said to them, "Assuredly, I say to you, there is no one who has left house or parents or brothers or wife or children, for the sake of the kingdom of God,

30. who shall not receive many times more in this present time, and in the age to come eternal life."

31. Then He took the twelve aside and said to them, "Behold, we are going up to Jerusalem, and all things that are written by the prophets concerning the Son of Man will be accomplished.

32. For He will be delivered to the Gentiles and will be mocked and insulted and spit upon.

33. They will scourge Him and kill Him. And the third day He will rise again."

34. But they understood none of these things; this saying was hidden from them, and they did not know the things which were spoken.

35. Then it happened, as He was coming near Jericho, that a certain blind man sat by the road begging.

36. And hearing a multitude passing by, he asked what it meant.

37. So they told him that Jesus of Nazareth was passing by.

38. And he cried out, saying, "Jesus, Son of David, have mercy on me!"

39. Then those who went before warned him that he should be quiet; but he cried out all the more, "Son of David, have mercy on me!"

40. So Jesus stood still and commanded him to be brought to Him. And when he had come near, He asked him,

41. saying, "What do you want Me to do for you?" He said, "Lord, that I may receive my sight."

42. Then Jesus said to him, "Receive your sight; your faith has made you well."

43. And immediately he received his sight, and followed Him, glorifying God. And all the people, when they saw it, gave praise to God.

## Chapter 19

1. Then Jesus entered and passed through Jericho.

2. Now behold, there was a man named Zacchaeus who was a chief tax collector, and he was rich.

3. And he sought to see who Jesus was, but could not because of the crowd, for he was of short stature.

4. So he ran ahead and climbed up into a sycamore tree to see Him, for He was going to pass that way.

5. And when Jesus came to the place, He looked up and saw him, and said to him, "Zacchaeus, make haste and come down, for today I must stay at your house."

6. So he made haste and came down, and received Him joyfully.

7. But when they saw it, they all complained, saying, "He has gone to be a guest with a man who is a sinner."

8. Then Zacchaeus stood and said to the Lord, "Look, Lord, I give half of my goods to the poor; and if I have taken anything from anyone by false accusation, I restore fourfold."

9. And Jesus said to him, "Today salvation has come to this house, because he also is a son of Abraham;

10. for the Son of Man has come to seek and to save that which was lost."

11. Now as they heard these things, He spoke another parable, because He was near Jerusalem and because they thought the kingdom of God would appear immediately.

12. Therefore He said: "A certain nobleman went into a far country to receive for himself a kingdom and to return.

13. So he called ten of his servants, delivered to them ten minas, and said to them, "Do business till I come.'

14. But his citizens hated him, and sent a delegation after him, saying, "We will not have this man to reign over us.'

15. "And so it was that when he returned, having received the kingdom, he then commanded these servants, to whom he had given the money, to be called to him, that he might know how much every man had gained by trading.

16. Then came the first, saying, "Master, your mina has earned ten minas.'

17. And he said to him, "Well done, good servant; because you were faithful in a very little, have authority over ten cities.'

18. And the second came, saying, "Master, your mina has earned five minas.'

19. Likewise he said to him, "You also be over five cities.'

20. "Then another came, saying, "Master, here is your mina, which I have kept put away in a handkerchief.

21. For I feared you, because you are an austere man. You collect what you did not deposit, and reap what you did not sow.'

22. And he said to him, "Out of your own mouth I will judge you, you wicked servant. You knew that I was an austere man, collecting what I did not deposit and reaping what I did not sow.

23. Why then did you not put my money in the bank, that at my coming I might have collected it with interest?'

24. "And he said to those who stood by, "Take the mina from him, and give it to him who has ten minas.'

25. (But they said to him, "Master, he has ten minas.')

26. "For I say to you, that to everyone who has will be given; and from him who does not have, even what he has will be taken away from him.

27. But bring here those enemies of mine, who did not want me to reign over them, and slay them before me."'

28. When He had said this, He went on ahead, going up to Jerusalem.

29. And it came to pass, when He drew near to Bethphage and Bethany, at the mountain called Olivet, that He sent two of His disciples,

30. saying, "Go into the village opposite you, where as you enter you will find a colt tied, on which no one has ever sat. Loose it and bring it here.

31. And if anyone asks you, "Why are you loosing it?' thus you shall say to him, "Because the Lord has need of it."'

32. So those who were sent went their way and found it just as He had said to them.

33. But as they were loosing the colt, the owners of it said to them, "Why are you loosing the colt?"

34. And they said, "The Lord has need of him."

35. Then they brought him to Jesus. And they threw their own clothes on the colt, and they set Jesus on him.

36. And as He went, many spread their clothes on the road.

37. Then, as He was now drawing near the descent of the Mount of Olives, the whole multitude of the disciples began to rejoice and praise God with a loud voice for all the mighty works they had seen,

38. saying: ""Blessed is the King who comes in the name of the LORD!' Peace in heaven and glory in the highest!"

39. And some of the Pharisees called to Him from the crowd, "Teacher, rebuke Your disciples."

40. But He answered and said to them, "I tell you that if these should keep silent, the stones would immediately cry out."

41. Now as He drew near, He saw the city and wept over it,

42. saying, "If you had known, even you, especially in this your day, the things that make for your peace! But now they are hidden from your eyes.

43. For days will come upon you when your enemies will build an embankment around you, surround you and close you in on every side,

44. and level you, and your children within you, to the ground; and they will not leave in you one stone upon another, because you did not know the time of your visitation."

45. Then He went into the temple and began to drive out those who bought and sold in it,

46. saying to them, "It is written, "My house is a house of prayer,' but you have made it a "den of thieves."'

47. And He was teaching daily in the temple. But the chief priests, the scribes, and the leaders of the people sought to destroy Him,

48. and were unable to do anything; for all the people were very attentive to hear Him.

## Chapter 20

1. Now it happened on one of those days, as He taught the people in the temple and preached the gospel, that the chief priests and the scribes, together with the elders, confronted Him

2. and spoke to Him, saying, "Tell us, by what authority are You doing these things? Or who is he who gave You this authority?"

3. But He answered and said to them, "I also will ask you one thing, and answer Me:

4. The baptism of John--was it from heaven or from men?"

5. And they reasoned among themselves, saying, "If we say, "From heaven,' He will say, "Why then did you not believe him?'

6. But if we say, "From men,' all the people will stone us, for they are persuaded that John was a prophet."

7. So they answered that they did not know where it was from.

8. And Jesus said to them, "Neither will I tell you by what authority I do these things."

9. Then He began to tell the people this parable: "A certain man planted a vineyard, leased it to vinedressers, and went into a far country for a long time.

10. Now at vintage-time he sent a servant to the vinedressers, that they might give him some of the fruit of the vineyard. But the vinedressers beat him and sent him away empty-handed.

11. Again he sent another servant; and they beat him also, treated him shamefully, and sent him away empty-handed.

12. And again he sent a third; and they wounded him also and cast him out.

13. "Then the owner of the vineyard said, "What shall I do? I will send my beloved son. Probably they will respect him when they see him.'

14. But when the vinedressers saw him, they reasoned among themselves, saying, "This is the heir. Come, let us kill him, that the inheritance may be ours.'

15. So they cast him out of the vineyard and killed him. Therefore what will the owner of the vineyard do to them?

16. He will come and destroy those vinedressers and give the vineyard to others." And when they heard it they said, "Certainly not!"

17. Then He looked at them and said, "What then is this that is written: "The stone which the builders rejected Has become the chief cornerstone'?

18. Whoever falls on that stone will be broken; but on whomever it falls, it will grind him to powder."

19. And the chief priests and the scribes that very hour sought to lay hands on Him, but they feared the people--for they knew He had spoken this parable against them.

20. So they watched Him, and sent spies who pretended to be righteous, that they might seize on His words, in order to deliver Him to the power and the authority of the governor.

21. Then they asked Him, saying, "Teacher, we know that You say and teach rightly, and You do not show personal favoritism, but teach the way of God in truth:

22. Is it lawful for us to pay taxes to Caesar or not?"

23. But He perceived their craftiness, and said to them, "Why do you test Me?

24. Show Me a denarius. Whose image and inscription does it have?" They answered and said, "Caesar's."

25. And He said to them, "Render therefore to Caesar the things that are Caesar's, and to God the things that are God's."

26. But they could not catch Him in His words in the presence of the people. And they marveled at His answer and kept silent.

27. Then some of the Sadducees, who deny that there is a resurrection, came to Him and asked Him,

28. saying: "Teacher, Moses wrote to us that if a man's brother dies, having a wife, and he dies without children, his brother should take his wife and raise up offspring for his brother.

29. Now there were seven brothers. And the first took a wife, and died without children.

30. And the second took her as wife, and he died childless.

31. Then the third took her, and in like manner the seven also; and they left no children, and died.

32. Last of all the woman died also.

33. Therefore, in the resurrection, whose wife does she become? For all seven had her as wife."

34. Jesus answered and said to them, "The sons of this age marry and are given in marriage.

35. But those who are counted worthy to attain that age, and the resurrection from the dead, neither marry nor are given in marriage;

36. nor can they die anymore, for they are equal to the angels and are sons of God, being sons of the resurrection.

37. But even Moses showed in the burning bush passage that the dead are raised, when he called the Lord "the God of Abraham, the God of Isaac, and the God of Jacob.'

38. For He is not the God of the dead but of the living, for all live to Him."

39. Then some of the scribes answered and said, "Teacher, You have spoken well."

40. But after that they dared not question Him anymore.

41. And He said to them, "How can they say that the Christ is the Son of David?

42. Now David himself said in the Book of Psalms: "The LORD said to my Lord, "Sit at My right hand,

43. Till I make Your enemies Your footstool."'

44. Therefore David calls Him "Lord'; how is He then his Son?"

45. Then, in the hearing of all the people, He said to His disciples,

46. "Beware of the scribes, who desire to go around in long robes, love greetings in the marketplaces, the best seats in the synagogues, and the best places at feasts,

47. who devour widows' houses, and for a pretense make long prayers. These will receive greater condemnation."

## Chapter 21

1. And He looked up and saw the rich putting their gifts into the treasury,

2. and He saw also a certain poor widow putting in two mites.

3. So He said, "Truly I say to you that this poor widow has put in more than all;

4. for all these out of their abundance have put in offerings for God, but she out of her poverty put in all the livelihood that she had."

5. Then, as some spoke of the temple, how it was adorned with beautiful stones and donations, He said,

6. "These things which you see--the days will come in which not one stone shall be left upon another that shall not be thrown down."

7. So they asked Him, saying, "Teacher, but when will these things be? And what sign will there be when these things are about to take place?"

8. And He said: "Take heed that you not be deceived. For many will come in My name, saying, "I am He,' and, "The time has drawn near.' Therefore do not go after them.

9. But when you hear of wars and commotions, do not be terrified; for these things must come to pass first, but the end will not come immediately."

10. Then He said to them, "Nation will rise against nation, and kingdom against kingdom.

11. And there will be great earthquakes in various places, and famines and pestilences; and there will be fearful sights and great signs from heaven.

12. But before all these things, they will lay their hands on you and persecute you, delivering you up to the synagogues and prisons. You will be brought before kings and rulers for My name's sake.

13. But it will turn out for you as an occasion for testimony.

14. Therefore settle it in your hearts not to meditate beforehand on what you will answer;

15. for I will give you a mouth and wisdom which all your adversaries will not be able to contradict or resist.

16. You will be betrayed even by parents and brothers, relatives and friends; and they will put some of you to death.

17. And you will be hated by all for My name's sake.

18. But not a hair of your head shall be lost.

19. By your patience possess your souls.

20. "But when you see Jerusalem surrounded by armies, then know that its desolation is near.

21. Then let those who are in Judea flee to the mountains, let those who are in the midst of her depart, and let not those who are in the country enter her.

22. For these are the days of vengeance, that all things which are written may be fulfilled.

23. But woe to those who are pregnant and to those who are nursing babies in those days! For there will be great distress in the land and wrath upon this people.

24. And they will fall by the edge of the sword, and be led away captive into all nations. And Jerusalem will be trampled by Gentiles until the times of the Gentiles are fulfilled.

25. "And there will be signs in the sun, in the moon, and in the stars; and on the earth distress of nations, with perplexity, the sea and the waves roaring;

26. men's hearts failing them from fear and the expectation of those things which are coming on the earth, for the powers of the heavens will be shaken.

27. Then they will see the Son of Man coming in a cloud with power and great glory.

28. Now when these things begin to happen, look up and lift up your heads, because your redemption draws near."

29. Then He spoke to them a parable: "Look at the fig tree, and all the trees.

30. When they are already budding, you see and know for yourselves that summer is now near.

31. So you also, when you see these things happening, know that the kingdom of God is near.

32. Assuredly, I say to you, this generation will by no means pass away till all things take place.

33. Heaven and earth will pass away, but My words will by no means pass away.

34. "But take heed to yourselves, lest your hearts be weighed down with carousing, drunkenness, and cares of this life, and that Day come on you unexpectedly.

35. For it will come as a snare on all those who dwell on the face of the whole earth.

36. Watch therefore, and pray always that you may be counted worthy to escape all these things that will come to pass, and to stand before the Son of Man."

37. And in the daytime He was teaching in the temple, but at night He went out and stayed on the mountain called Olivet.

38. Then early in the morning all the people came to Him in the temple to hear Him.

## Chapter 22

1. Now the Feast of Unleavened Bread drew near, which is called Passover.

2. And the chief priests and the scribes sought how they might kill Him, for they feared the people.

3. Then Satan entered Judas, surnamed Iscariot, who was numbered among the twelve.

4. So he went his way and conferred with the chief priests and captains, how he might betray Him to them.

5. And they were glad, and agreed to give him money.

6. So he promised and sought opportunity to betray Him to them in the absence of the multitude.

7. Then came the Day of Unleavened Bread, when the Passover must be killed.

8. And He sent Peter and John, saying, "Go and prepare the Passover for us, that we may eat."

9. So they said to Him, "Where do You want us to prepare?"

10. And He said to them, "Behold, when you have entered the city, a man will meet you carrying a pitcher of water; follow him into the house which he enters.

11. Then you shall say to the master of the house, "The Teacher says to you, "Where is the guest room where I may eat the Passover with My disciples?"'

12. Then he will show you a large, furnished upper room; there make ready."

13. So they went and found it just as He had said to them, and they prepared the Passover.

14. When the hour had come, He sat down, and the twelve apostles with Him.

15. Then He said to them, "With fervent desire I have desired to eat this Passover with you before I suffer;

16. for I say to you, I will no longer eat of it until it is fulfilled in the kingdom of God."

17. Then He took the cup, and gave thanks, and said, "Take this and divide it among yourselves;

18. for I say to you, I will not drink of the fruit of the vine until the kingdom of God comes."

19. And He took bread, gave thanks and broke it, and gave it to them, saying, "This is My body which is given for you; do this in remembrance of Me."

20. Likewise He also took the cup after supper, saying, "This cup is the new covenant in My blood, which is shed for you.

21. But behold, the hand of My betrayer is with Me on the table.

22. And truly the Son of Man goes as it has been determined, but woe to that man by whom He is betrayed!"

23. Then they began to question among themselves, which of them it was who would do this thing.

24. Now there was also a dispute among them, as to which of them should be considered the greatest.

25. And He said to them, "The kings of the Gentiles exercise lordship over them, and those who exercise authority over them are called "benefactors.'

26. But not so among you; on the contrary, he who is greatest among you, let him be as the younger, and he who governs as he who serves.

27. For who is greater, he who sits at the table, or he who serves? Is it not he who sits at the table? Yet I am among you as the One who serves.

28. "But you are those who have continued with Me in My trials.

29. And I bestow upon you a kingdom, just as My Father bestowed one upon Me,

30. that you may eat and drink at My table in My kingdom, and sit on thrones judging the twelve tribes of Israel."

31. And the Lord said, "Simon, Simon! Indeed, Satan has asked for you, that he may sift you as wheat.

32. But I have prayed for you, that your faith should not fail; and when you have returned to Me, strengthen your brethren."

33. But he said to Him, "Lord, I am ready to go with You, both to prison and to death."

34. Then He said, "I tell you, Peter, the rooster shall not crow this day before you will deny three times that you know Me."

35. And He said to them, "When I sent you without money bag, knapsack, and sandals, did you lack anything?" So they said, "Nothing."

36. Then He said to them, "But now, he who has a money bag, let him take it, and likewise a knapsack; and he who has no sword, let him sell his garment and buy one.

37. For I say to you that this which is written must still be accomplished in Me: "And He was numbered with the transgressors.' For the things concerning Me have an end."

38. So they said, "Lord, look, here are two swords." And He said to them, "It is enough."

39. Coming out, He went to the Mount of Olives, as He was accustomed, and His disciples also followed Him.

40. When He came to the place, He said to them, "Pray that you may not enter into temptation."

41. And He was withdrawn from them about a stone's throw, and He knelt down and prayed,

42. saying, "Father, if it is Your will, take this cup away from Me; nevertheless not My will, but Yours, be done."

43. Then an angel appeared to Him from heaven, strengthening Him.

44. And being in agony, He prayed more earnestly. Then His sweat became like great drops of blood falling down to the ground.

45. When He rose up from prayer, and had come to His disciples, He found them sleeping from sorrow.

46. Then He said to them, "Why do you sleep? Rise and pray, lest you enter into temptation."

47. And while He was still speaking, behold, a multitude; and he who was called Judas, one of the twelve, went before them and drew near to Jesus to kiss Him.

48. But Jesus said to him, "Judas, are you betraying the Son of Man with a kiss?"

49. When those around Him saw what was going to happen, they said to Him, "Lord, shall we strike with the sword?"

50. And one of them struck the servant of the high priest and cut off his right ear.

51. But Jesus answered and said, "Permit even this." And He touched his ear and healed him.

52. Then Jesus said to the chief priests, captains of the temple, and the elders who had come to Him, "Have you come out, as against a robber, with swords and clubs?

53. When I was with you daily in the temple, you did not try to seize Me. But this is your hour, and the power of darkness."

54. Having arrested Him, they led Him and brought Him into the high priest's house. But Peter followed at a distance.

55. Now when they had kindled a fire in the midst of the courtyard and sat down together, Peter sat among them.

56. And a certain servant girl, seeing him as he sat by the fire, looked intently at him and said, "This man was also with Him."

57. But he denied Him, saying, "Woman, I do not know Him."

58. And after a little while another saw him and said, "You also are of them." But Peter said, "Man, I am not!"

59. Then after about an hour had passed, another confidently affirmed, saying, "Surely this fellow also was with Him, for he is a Galilean."

60. But Peter said, "Man, I do not know what you are saying!" Immediately, while he was still speaking, the rooster crowed.

61. And the Lord turned and looked at Peter. Then Peter remembered the word of the Lord, how He had said to him, "Before the rooster crows, you will deny Me three times."

62. So Peter went out and wept bitterly.

63. Now the men who held Jesus mocked Him and beat Him.

64. And having blindfolded Him, they struck Him on the face and asked Him, saying, "Prophesy! Who is the one who struck You?"

65. And many other things they blasphemously spoke against Him.

66. As soon as it was day, the elders of the people, both chief priests and scribes, came together and led Him into their council, saying,

67. "If You are the Christ, tell us." But He said to them, "If I tell you, you will by no means believe.

68. And if I also ask you, you will by no means answer Me or let Me go.

69. Hereafter the Son of Man will sit on the right hand of the power of God."

70. Then they all said, "Are You then the Son of God?" So He said to them, "You rightly say that I am."

71. And they said, "What further testimony do we need? For we have heard it ourselves from His own mouth."

## Chapter 23

1. Then the whole multitude of them arose and led Him to Pilate.

2. And they began to accuse Him, saying, "We found this fellow perverting the nation, and forbidding to pay taxes to Caesar, saying that He Himself is Christ, a King."

3. Then Pilate asked Him, saying, "Are You the King of the Jews?" He answered him and said, "It is as you say."

4. So Pilate said to the chief priests and the crowd, "I find no fault in this Man."

5. But they were the more fierce, saying, "He stirs up the people, teaching throughout all Judea, beginning from Galilee to this place."

6. When Pilate heard of Galilee, he asked if the Man were a Galilean.

7. And as soon as he knew that He belonged to Herod's jurisdiction, he sent Him to Herod, who was also in Jerusalem at that time.

8. Now when Herod saw Jesus, he was exceedingly glad; for he had desired for a long time to see Him, because he had heard many things about Him, and he hoped to see some miracle done by Him.

9. Then he questioned Him with many words, but He answered him nothing.

10. And the chief priests and scribes stood and vehemently accused Him.

11. Then Herod, with his men of war, treated Him with contempt and mocked Him, arrayed Him in a gorgeous robe, and sent Him back to Pilate.

12. That very day Pilate and Herod became friends with each other, for previously they had been at enmity with each other.

13. Then Pilate, when he had called together the chief priests, the rulers, and the people,

14. said to them, "You have brought this Man to me, as one who misleads the people. And indeed, having examined Him in your presence, I have found no fault in this Man concerning those things of which you accuse Him;

15. no, neither did Herod, for I sent you back to him; and indeed nothing deserving of death has been done by Him.

16. I will therefore chastise Him and release Him"

17. (for it was necessary for him to release one to them at the feast).

18. And they all cried out at once, saying, "Away with this Man, and release to us Barabbas"--

19. who had been thrown into prison for a certain rebellion made in the city, and for murder.

20. Pilate, therefore, wishing to release Jesus, again called out to them.

21. But they shouted, saying, "Crucify Him, crucify Him!"

22. Then he said to them the third time, "Why, what evil has He done? I have found no reason for death in Him. I will therefore chastise Him and let Him go."

23. But they were insistent, demanding with loud voices that He be crucified. And the voices of these men and of the chief priests prevailed.

24. So Pilate gave sentence that it should be as they requested.

25. And he released to them the one they requested, who for rebellion and murder had been thrown into prison; but he delivered Jesus to their will.

26. Now as they led Him away, they laid hold of a certain man, Simon a Cyrenian, who was coming from the country, and on him they laid the cross that he might bear it after Jesus.

27. And a great multitude of the people followed Him, and women who also mourned and lamented Him.

28. But Jesus, turning to them, said, "Daughters of Jerusalem, do not weep for Me, but weep for yourselves and for your children.

29. For indeed the days are coming in which they will say, "Blessed are the barren, wombs that never bore, and breasts which never nursed!'

30. Then they will begin "to say to the mountains, "Fall on us!" and to the hills, "Cover us!"'

31. For if they do these things in the green wood, what will be done in the dry?"

32. There were also two others, criminals, led with Him to be put to death.

33. And when they had come to the place called Calvary, there they crucified Him, and the criminals, one on the right hand and the other on the left.

34. Then Jesus said, "Father, forgive them, for they do not know what they do." And they divided His garments and cast lots.

35. And the people stood looking on. But even the rulers with them sneered, saying, "He saved others; let Him save Himself if He is the Christ, the chosen of God."

36. The soldiers also mocked Him, coming and offering Him sour wine,

37. and saying, "If You are the King of the Jews, save Yourself."

38. And an inscription also was written over Him in letters of Greek, Latin, and Hebrew: THIS IS THE KING OF THE JEWS.

39. Then one of the criminals who were hanged blasphemed Him, saying, "If You are the Christ, save Yourself and us."

40. But the other, answering, rebuked him, saying, "Do you not even fear God, seeing you are under the same condemnation?

41. And we indeed justly, for we receive the due reward of our deeds; but this Man has done nothing wrong."

42. Then he said to Jesus, "Lord, remember me when You come into Your kingdom."

43. And Jesus said to him, "Assuredly, I say to you, today you will be with Me in Paradise."

44. Now it was about the sixth hour, and there was darkness over all the earth until the ninth hour.

45. Then the sun was darkened, and the veil of the temple was torn in two.

46. And when Jesus had cried out with a loud voice, He said, "Father, "into Your hands I commit My spirit."' Having said this, He breathed His last.

47. So when the centurion saw what had happened, he glorified God, saying, "Certainly this was a righteous Man!"

48. And the whole crowd who came together to that sight, seeing what had been done, beat their breasts and returned.

49. But all His acquaintances, and the women who followed Him from Galilee, stood at a distance, watching these things.

50. Now behold, there was a man named Joseph, a council member, a good and just man.

51. He had not consented to their decision and deed. He was from Arimathea, a city of the Jews, who himself was also waiting for the kingdom of God.

52. This man went to Pilate and asked for the body of Jesus.

53. Then he took it down, wrapped it in linen, and laid it in a tomb that was hewn out of the rock, where no one had ever lain before.

54. That day was the Preparation, and the Sabbath drew near.

55. And the women who had come with Him from Galilee followed after, and they observed the tomb and how His body was laid.

56. Then they returned and prepared spices and fragrant oils. And they rested on the Sabbath according to the commandment.

## Chapter 24

1. Now on the first day of the week, very early in the morning, they, and certain other women with them, came to the tomb bringing the spices which they had prepared.

2. But they found the stone rolled away from the tomb.

3. Then they went in and did not find the body of the Lord Jesus.

4. And it happened, as they were greatly perplexed about this, that behold, two men stood by them in shining garments.

5. Then, as they were afraid and bowed their faces to the earth, they said to them, "Why do you seek the living among the dead?

6. He is not here, but is risen! Remember how He spoke to you when He was still in Galilee,

7. saying, "The Son of Man must be delivered into the hands of sinful men, and be crucified, and the third day rise again."'

8. And they remembered His words.

9. Then they returned from the tomb and told all these things to the eleven and to all the rest.

10. It was Mary Magdalene, Joanna, Mary the mother of James, and the other women with them, who told these things to the apostles.

11. And their words seemed to them like idle tales, and they did not believe them.

12. But Peter arose and ran to the tomb; and stooping down, he saw the linen cloths lying by themselves; and he departed, marveling to himself at what had happened.

13. Now behold, two of them were traveling that same day to a village called Emmaus, which was seven miles from Jerusalem.

14. And they talked together of all these things which had happened.

15. So it was, while they conversed and reasoned, that Jesus Himself drew near and went with them.

16. But their eyes were restrained, so that they did not know Him.

17. And He said to them, "What kind of conversation is this that you have with one another as you walk and are sad?"

18. Then the one whose name was Cleopas answered and said to Him, "Are You the only stranger in Jerusalem, and have You not known the things which happened there in these days?"

19. And He said to them, "What things?" So they said to Him, "The things concerning Jesus of Nazareth, who was a Prophet mighty in deed and word before God and all the people,

20. and how the chief priests and our rulers delivered Him to be condemned to death, and crucified Him.

21. But we were hoping that it was He who was going to redeem Israel. Indeed, besides all this, today is the third day since these things happened.

22. Yes, and certain women of our company, who arrived at the tomb early, astonished us.

23. When they did not find His body, they came saying that they had also seen a vision of angels who said He was alive.

24. And certain of those who were with us went to the tomb and found it just as the women had said; but Him they did not see."

25. Then He said to them, "O foolish ones, and slow of heart to believe in all that the prophets have spoken!

26. Ought not the Christ to have suffered these things and to enter into His glory?"

27. And beginning at Moses and all the Prophets, He expounded to them in all the Scriptures the things concerning Himself.

28. Then they drew near to the village where they were going, and He indicated that He would have gone farther.

29. But they constrained Him, saying, "Abide with us, for it is toward evening, and the day is far spent." And He went in to stay with them.

30. Now it came to pass, as He sat at the table with them, that He took bread, blessed and broke it, and gave it to them.

31. Then their eyes were opened and they knew Him; and He vanished from their sight.

32. And they said to one another, "Did not our heart burn within us while He talked with us on the road, and while He opened the Scriptures to us?"

33. So they rose up that very hour and returned to Jerusalem, and found the eleven and those who were with them gathered together,

34. saying, "The Lord is risen indeed, and has appeared to Simon!"

35. And they told about the things that had happened on the road, and how He was known to them in the breaking of bread.

36. Now as they said these things, Jesus Himself stood in the midst of them, and said to them, "Peace to you."

37. But they were terrified and frightened, and supposed they had seen a spirit.

38. And He said to them, "Why are you troubled? And why do doubts arise in your hearts?

39. Behold My hands and My feet, that it is I Myself. Handle Me and see, for a spirit does not have flesh and bones as you see I have."

40. When He had said this, He showed them His hands and His feet.

41. But while they still did not believe for joy, and marveled, He said to them, "Have you any food here?"

42. So they gave Him a piece of a broiled fish and some honeycomb.

43. And He took it and ate in their presence.

44. Then He said to them, "These are the words which I spoke to you while I was still with you, that all things must be fulfilled which were written in the Law of Moses and the Prophets and the Psalms concerning Me."

45. And He opened their understanding, that they might comprehend the Scriptures.

46. Then He said to them, "Thus it is written, and thus it was necessary for the Christ to suffer and to rise from the dead the third day,

47. and that repentance and remission of sins should be preached in His name to all nations, beginning at Jerusalem.

48. And you are witnesses of these things.

49. Behold, I send the Promise of My Father upon you; but tarry in the city of Jerusalem until you are endued with power from on high."

50. And He led them out as far as Bethany, and He lifted up His hands and blessed them.

51. Now it came to pass, while He blessed them, that He was parted from them and carried up into heaven.

52. And they worshiped Him, and returned to Jerusalem with great joy,

53. and were continually in the temple praising and blessing God. Amen.


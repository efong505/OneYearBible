# malachi

## Chapter 1

1. The burden of the word of the LORD to Israel by Malachi.

2. "I have loved you," says the LORD. "Yet you say, "In what way have You loved us?' Was not Esau Jacob's brother?" Says the LORD. "Yet Jacob I have loved;

3. But Esau I have hated, And laid waste his mountains and his heritage For the jackals of the wilderness."

4. Even though Edom has said, "We have been impoverished, But we will return and build the desolate places," Thus says the LORD of hosts: "They may build, but I will throw down; They shall be called the Territory of Wickedness, And the people against whom the LORD will have indignation forever.

5. Your eyes shall see, And you shall say, "The LORD is magnified beyond the border of Israel.'

6. "A son honors his father, And a servant his master. If then I am the Father, Where is My honor? And if I am a Master, Where is My reverence? Says the LORD of hosts To you priests who despise My name. Yet you say, "In what way have we despised Your name?'

7. "You offer defiled food on My altar, But say, "In what way have we defiled You?' By saying, "The table of the LORD is contemptible.'

8. And when you offer the blind as a sacrifice, Is it not evil? And when you offer the lame and sick, Is it not evil? Offer it then to your governor! Would he be pleased with you? Would he accept you favorably?" Says the LORD of hosts.

9. "But now entreat God's favor, That He may be gracious to us. While this is being done by your hands, Will He accept you favorably?" Says the LORD of hosts.

10. "Who is there even among you who would shut the doors, So that you would not kindle fire on My altar in vain? I have no pleasure in you," Says the LORD of hosts, "Nor will I accept an offering from your hands.

11. For from the rising of the sun, even to its going down, My name shall be great among the Gentiles; In every place incense shall be offered to My name, And a pure offering; For My name shall be great among the nations," Says the LORD of hosts.

12. "But you profane it, In that you say, "The table of the LORD is defiled; And its fruit, its food, is contemptible.'

13. You also say, "Oh, what a weariness!' And you sneer at it," Says the LORD of hosts. "And you bring the stolen, the lame, and the sick; Thus you bring an offering! Should I accept this from your hand?" Says the LORD.

14. "But cursed be the deceiver Who has in his flock a male, And takes a vow, But sacrifices to the Lord what is blemished-- For I am a great King," Says the LORD of hosts, "And My name is to be feared among the nations.

## Chapter 2

1. "And now, O priests, this commandment is for you.

2. If you will not hear, And if you will not take it to heart, To give glory to My name," Says the LORD of hosts, "I will send a curse upon you, And I will curse your blessings. Yes, I have cursed them already, Because you do not take it to heart.

3. "Behold, I will rebuke your descendants And spread refuse on your faces, The refuse of your solemn feasts; And one will take you away with it.

4. Then you shall know that I have sent this commandment to you, That My covenant with Levi may continue," Says the LORD of hosts.

5. "My covenant was with him, one of life and peace, And I gave them to him that he might fear Me; So he feared Me And was reverent before My name.

6. The law of truth was in his mouth, And injustice was not found on his lips. He walked with Me in peace and equity, And turned many away from iniquity.

7. "For the lips of a priest should keep knowledge, And people should seek the law from his mouth; For he is the messenger of the LORD of hosts.

8. But you have departed from the way; You have caused many to stumble at the law. You have corrupted the covenant of Levi," Says the LORD of hosts.

9. "Therefore I also have made you contemptible and base Before all the people, Because you have not kept My ways But have shown partiality in the law."

10. Have we not all one Father? Has not one God created us? Why do we deal treacherously with one another By profaning the covenant of the fathers?

11. Judah has dealt treacherously, And an abomination has been committed in Israel and in Jerusalem, For Judah has profaned The LORD's holy institution which He loves: He has married the daughter of a foreign god.

12. May the LORD cut off from the tents of Jacob The man who does this, being awake and aware, Yet who brings an offering to the LORD of hosts!

13. And this is the second thing you do: You cover the altar of the LORD with tears, With weeping and crying; So He does not regard the offering anymore, Nor receive it with goodwill from your hands.

14. Yet you say, "For what reason?" Because the LORD has been witness Between you and the wife of your youth, With whom you have dealt treacherously; Yet she is your companion And your wife by covenant.

15. But did He not make them one, Having a remnant of the Spirit? And why one? He seeks godly offspring. Therefore take heed to your spirit, And let none deal treacherously with the wife of his youth.

16. "For the LORD God of Israel says That He hates divorce, For it covers one's garment with violence," Says the LORD of hosts. "Therefore take heed to your spirit, That you do not deal treacherously."

17. You have wearied the LORD with your words; Yet you say, "In what way have we wearied Him?" In that you say, "Everyone who does evil Is good in the sight of the LORD, And He delights in them," Or, "Where is the God of justice?"

## Chapter 3

1. "Behold, I send My messenger, And he will prepare the way before Me. And the Lord, whom you seek, Will suddenly come to His temple, Even the Messenger of the covenant, In whom you delight. Behold, He is coming," Says the LORD of hosts.

2. "But who can endure the day of His coming? And who can stand when He appears? For He is like a refiner's fire And like launderers' soap.

3. He will sit as a refiner and a purifier of silver; He will purify the sons of Levi, And purge them as gold and silver, That they may offer to the LORD An offering in righteousness.

4. "Then the offering of Judah and Jerusalem Will be pleasant to the LORD, As in the days of old, As in former years.

5. And I will come near you for judgment; I will be a swift witness Against sorcerers, Against adulterers, Against perjurers, Against those who exploit wage earners and widows and orphans, And against those who turn away an alien-- Because they do not fear Me," Says the LORD of hosts.

6. "For I am the LORD, I do not change; Therefore you are not consumed, O sons of Jacob.

7. Yet from the days of your fathers You have gone away from My ordinances And have not kept them. Return to Me, and I will return to you," Says the LORD of hosts. "But you said, "In what way shall we return?'

8. "Will a man rob God? Yet you have robbed Me! But you say, "In what way have we robbed You?' In tithes and offerings.

9. You are cursed with a curse, For you have robbed Me, Even this whole nation.

10. Bring all the tithes into the storehouse, That there may be food in My house, And try Me now in this," Says the LORD of hosts, "If I will not open for you the windows of heaven And pour out for you such blessing That there will not be room enough to receive it.

11. "And I will rebuke the devourer for your sakes, So that he will not destroy the fruit of your ground, Nor shall the vine fail to bear fruit for you in the field," Says the LORD of hosts;

12. And all nations will call you blessed, For you will be a delightful land," Says the LORD of hosts.

13. "Your words have been harsh against Me," Says the LORD, "Yet you say, "What have we spoken against You?'

14. You have said, "It is useless to serve God; What profit is it that we have kept His ordinance, And that we have walked as mourners Before the LORD of hosts?

15. So now we call the proud blessed, For those who do wickedness are raised up; They even tempt God and go free."'

16. Then those who feared the LORD spoke to one another, And the LORD listened and heard them; So a book of remembrance was written before Him For those who fear the LORD And who meditate on His name.

17. "They shall be Mine," says the LORD of hosts, "On the day that I make them My jewels. And I will spare them As a man spares his own son who serves him."

18. Then you shall again discern Between the righteous and the wicked, Between one who serves God And one who does not serve Him.

## Chapter 4

1. "For behold, the day is coming, Burning like an oven, And all the proud, yes, all who do wickedly will be stubble. And the day which is coming shall burn them up," Says the LORD of hosts, "That will leave them neither root nor branch.

2. But to you who fear My name The Sun of Righteousness shall arise With healing in His wings; And you shall go out And grow fat like stall-fed calves.

3. You shall trample the wicked, For they shall be ashes under the soles of your feet On the day that I do this," Says the LORD of hosts.

4. "Remember the Law of Moses, My servant, Which I commanded him in Horeb for all Israel, With the statutes and judgments.

5. Behold, I will send you Elijah the prophet Before the coming of the great and dreadful day of the LORD.

6. And he will turn The hearts of the fathers to the children, And the hearts of the children to their fathers, Lest I come and strike the earth with a curse."


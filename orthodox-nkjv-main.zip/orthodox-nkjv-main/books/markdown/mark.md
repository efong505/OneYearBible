# mark

## Chapter 1

1. The beginning of the gospel of Jesus Christ, the Son of God.

2. As it is written in the Prophets: "Behold, I send My messenger before Your face, Who will prepare Your way before You."

3. "The voice of one crying in the wilderness: "Prepare the way of the LORD; Make His paths straight."'

4. John came baptizing in the wilderness and preaching a baptism of repentance for the remission of sins.

5. Then all the land of Judea, and those from Jerusalem, went out to him and were all baptized by him in the Jordan River, confessing their sins.

6. Now John was clothed with camel's hair and with a leather belt around his waist, and he ate locusts and wild honey.

7. And he preached, saying, "There comes One after me who is mightier than I, whose sandal strap I am not worthy to stoop down and loose.

8. I indeed baptized you with water, but He will baptize you with the Holy Spirit."

9. It came to pass in those days that Jesus came from Nazareth of Galilee, and was baptized by John in the Jordan.

10. And immediately, coming up from the water, He saw the heavens parting and the Spirit descending upon Him like a dove.

11. Then a voice came from heaven, "You are My beloved Son, in whom I am well pleased."

12. Immediately the Spirit drove Him into the wilderness.

13. And He was there in the wilderness forty days, tempted by Satan, and was with the wild beasts; and the angels ministered to Him.

14. Now after John was put in prison, Jesus came to Galilee, preaching the gospel of the kingdom of God,

15. and saying, "The time is fulfilled, and the kingdom of God is at hand. Repent, and believe in the gospel."

16. And as He walked by the Sea of Galilee, He saw Simon and Andrew his brother casting a net into the sea; for they were fishermen.

17. Then Jesus said to them, "Follow Me, and I will make you become fishers of men."

18. They immediately left their nets and followed Him.

19. When He had gone a little farther from there, He saw James the son of Zebedee, and John his brother, who also were in the boat mending their nets.

20. And immediately He called them, and they left their father Zebedee in the boat with the hired servants, and went after Him.

21. Then they went into Capernaum, and immediately on the Sabbath He entered the synagogue and taught.

22. And they were astonished at His teaching, for He taught them as one having authority, and not as the scribes.

23. Now there was a man in their synagogue with an unclean spirit. And he cried out,

24. saying, "Let us alone! What have we to do with You, Jesus of Nazareth? Did You come to destroy us? I know who You are--the Holy One of God!"

25. But Jesus rebuked him, saying, "Be quiet, and come out of him!"

26. And when the unclean spirit had convulsed him and cried out with a loud voice, he came out of him.

27. Then they were all amazed, so that they questioned among themselves, saying, "What is this? What new doctrine is this? For with authority He commands even the unclean spirits, and they obey Him."

28. And immediately His fame spread throughout all the region around Galilee.

29. Now as soon as they had come out of the synagogue, they entered the house of Simon and Andrew, with James and John.

30. But Simon's wife's mother lay sick with a fever, and they told Him about her at once.

31. So He came and took her by the hand and lifted her up, and immediately the fever left her. And she served them.

32. At evening, when the sun had set, they brought to Him all who were sick and those who were demon-possessed.

33. And the whole city was gathered together at the door.

34. Then He healed many who were sick with various diseases, and cast out many demons; and He did not allow the demons to speak, because they knew Him.

35. Now in the morning, having risen a long while before daylight, He went out and departed to a solitary place; and there He prayed.

36. And Simon and those who were with Him searched for Him.

37. When they found Him, they said to Him, "Everyone is looking for You."

38. But He said to them, "Let us go into the next towns, that I may preach there also, because for this purpose I have come forth."

39. And He was preaching in their synagogues throughout all Galilee, and casting out demons.

40. Now a leper came to Him, imploring Him, kneeling down to Him and saying to Him, "If You are willing, You can make me clean."

41. Then Jesus, moved with compassion, stretched out His hand and touched him, and said to him, "I am willing; be cleansed."

42. As soon as He had spoken, immediately the leprosy left him, and he was cleansed.

43. And He strictly warned him and sent him away at once,

44. and said to him, "See that you say nothing to anyone; but go your way, show yourself to the priest, and offer for your cleansing those things which Moses commanded, as a testimony to them."

45. However, he went out and began to proclaim it freely, and to spread the matter, so that Jesus could no longer openly enter the city, but was outside in deserted places; and they came to Him from every direction.

## Chapter 2

1. And again He entered Capernaum after some days, and it was heard that He was in the house.

2. Immediately many gathered together, so that there was no longer room to receive them, not even near the door. And He preached the word to them.

3. Then they came to Him, bringing a paralytic who was carried by four men.

4. And when they could not come near Him because of the crowd, they uncovered the roof where He was. So when they had broken through, they let down the bed on which the paralytic was lying.

5. When Jesus saw their faith, He said to the paralytic, "Son, your sins are forgiven you."

6. And some of the scribes were sitting there and reasoning in their hearts,

7. "Why does this Man speak blasphemies like this? Who can forgive sins but God alone?"

8. But immediately, when Jesus perceived in His spirit that they reasoned thus within themselves, He said to them, "Why do you reason about these things in your hearts?

9. Which is easier, to say to the paralytic, "Your sins are forgiven you,' or to say, "Arise, take up your bed and walk'?

10. But that you may know that the Son of Man has power on earth to forgive sins"--He said to the paralytic,

11. "I say to you, arise, take up your bed, and go to your house."

12. Immediately he arose, took up the bed, and went out in the presence of them all, so that all were amazed and glorified God, saying, "We never saw anything like this!"

13. Then He went out again by the sea; and all the multitude came to Him, and He taught them.

14. As He passed by, He saw Levi the son of Alphaeus sitting at the tax office. And He said to him, "Follow Me." So he arose and followed Him.

15. Now it happened, as He was dining in Levi's house, that many tax collectors and sinners also sat together with Jesus and His disciples; for there were many, and they followed Him.

16. And when the scribes and Pharisees saw Him eating with the tax collectors and sinners, they said to His disciples, "How is it that He eats and drinks with tax collectors and sinners?"

17. When Jesus heard it, He said to them, "Those who are well have no need of a physician, but those who are sick. I did not come to call the righteous, but sinners, to repentance."

18. The disciples of John and of the Pharisees were fasting. Then they came and said to Him, "Why do the disciples of John and of the Pharisees fast, but Your disciples do not fast?"

19. And Jesus said to them, "Can the friends of the bridegroom fast while the bridegroom is with them? As long as they have the bridegroom with them they cannot fast.

20. But the days will come when the bridegroom will be taken away from them, and then they will fast in those days.

21. No one sews a piece of unshrunk cloth on an old garment; or else the new piece pulls away from the old, and the tear is made worse.

22. And no one puts new wine into old wineskins; or else the new wine bursts the wineskins, the wine is spilled, and the wineskins are ruined. But new wine must be put into new wineskins."

23. Now it happened that He went through the grainfields on the Sabbath; and as they went His disciples began to pluck the heads of grain.

24. And the Pharisees said to Him, "Look, why do they do what is not lawful on the Sabbath?"

25. But He said to them, "Have you never read what David did when he was in need and hungry, he and those with him:

26. how he went into the house of God in the days of Abiathar the high priest, and ate the showbread, which is not lawful to eat except for the priests, and also gave some to those who were with him?"

27. And He said to them, "The Sabbath was made for man, and not man for the Sabbath.

28. Therefore the Son of Man is also Lord of the Sabbath."

## Chapter 3

1. And He entered the synagogue again, and a man was there who had a withered hand.

2. So they watched Him closely, whether He would heal him on the Sabbath, so that they might accuse Him.

3. And He said to the man who had the withered hand, "Step forward."

4. Then He said to them, "Is it lawful on the Sabbath to do good or to do evil, to save life or to kill?" But they kept silent.

5. And when He had looked around at them with anger, being grieved by the hardness of their hearts, He said to the man, "Stretch out your hand." And he stretched it out, and his hand was restored as whole as the other.

6. Then the Pharisees went out and immediately plotted with the Herodians against Him, how they might destroy Him.

7. But Jesus withdrew with His disciples to the sea. And a great multitude from Galilee followed Him, and from Judea

8. and Jerusalem and Idumea and beyond the Jordan; and those from Tyre and Sidon, a great multitude, when they heard how many things He was doing, came to Him.

9. So He told His disciples that a small boat should be kept ready for Him because of the multitude, lest they should crush Him.

10. For He healed many, so that as many as had afflictions pressed about Him to touch Him.

11. And the unclean spirits, whenever they saw Him, fell down before Him and cried out, saying, "You are the Son of God."

12. But He sternly warned them that they should not make Him known.

13. And He went up on the mountain and called to Him those He Himself wanted. And they came to Him.

14. Then He appointed twelve, that they might be with Him and that He might send them out to preach,

15. and to have power to heal sicknesses and to cast out demons:

16. Simon, to whom He gave the name Peter;

17. James the son of Zebedee and John the brother of James, to whom He gave the name Boanerges, that is, "Sons of Thunder";

18. Andrew, Philip, Bartholomew, Matthew, Thomas, James the son of Alphaeus, Thaddaeus, Simon the Cananite;

19. and Judas Iscariot, who also betrayed Him. And they went into a house.

20. Then the multitude came together again, so that they could not so much as eat bread.

21. But when His own people heard about this, they went out to lay hold of Him, for they said, "He is out of His mind."

22. And the scribes who came down from Jerusalem said, "He has Beelzebub," and, "By the ruler of the demons He casts out demons."

23. So He called them to Himself and said to them in parables: "How can Satan cast out Satan?

24. If a kingdom is divided against itself, that kingdom cannot stand.

25. And if a house is divided against itself, that house cannot stand.

26. And if Satan has risen up against himself, and is divided, he cannot stand, but has an end.

27. No one can enter a strong man's house and plunder his goods, unless he first binds the strong man. And then he will plunder his house.

28. "Assuredly, I say to you, all sins will be forgiven the sons of men, and whatever blasphemies they may utter;

29. but he who blasphemes against the Holy Spirit never has forgiveness, but is subject to eternal condemnation"--

30. because they said, "He has an unclean spirit."

31. Then His brothers and His mother came, and standing outside they sent to Him, calling Him.

32. And a multitude was sitting around Him; and they said to Him, "Look, Your mother and Your brothers are outside seeking You."

33. But He answered them, saying, "Who is My mother, or My brothers?"

34. And He looked around in a circle at those who sat about Him, and said, "Here are My mother and My brothers!

35. For whoever does the will of God is My brother and My sister and mother."

## Chapter 4

1. And again He began to teach by the sea. And a great multitude was gathered to Him, so that He got into a boat and sat in it on the sea; and the whole multitude was on the land facing the sea.

2. Then He taught them many things by parables, and said to them in His teaching:

3. "Listen! Behold, a sower went out to sow.

4. And it happened, as he sowed, that some seed fell by the wayside; and the birds of the air came and devoured it.

5. Some fell on stony ground, where it did not have much earth; and immediately it sprang up because it had no depth of earth.

6. But when the sun was up it was scorched, and because it had no root it withered away.

7. And some seed fell among thorns; and the thorns grew up and choked it, and it yielded no crop.

8. But other seed fell on good ground and yielded a crop that sprang up, increased and produced: some thirtyfold, some sixty, and some a hundred."

9. And He said to them, "He who has ears to hear, let him hear!"

10. But when He was alone, those around Him with the twelve asked Him about the parable.

11. And He said to them, "To you it has been given to know the mystery of the kingdom of God; but to those who are outside, all things come in parables,

12. so that "Seeing they may see and not perceive, And hearing they may hear and not understand; Lest they should turn, And their sins be forgiven them."'

13. And He said to them, "Do you not understand this parable? How then will you understand all the parables?

14. The sower sows the word.

15. And these are the ones by the wayside where the word is sown. When they hear, Satan comes immediately and takes away the word that was sown in their hearts.

16. These likewise are the ones sown on stony ground who, when they hear the word, immediately receive it with gladness;

17. and they have no root in themselves, and so endure only for a time. Afterward, when tribulation or persecution arises for the word's sake, immediately they stumble.

18. Now these are the ones sown among thorns; they are the ones who hear the word,

19. and the cares of this world, the deceitfulness of riches, and the desires for other things entering in choke the word, and it becomes unfruitful.

20. But these are the ones sown on good ground, those who hear the word, accept it, and bear fruit: some thirtyfold, some sixty, and some a hundred."

21. Also He said to them, "Is a lamp brought to be put under a basket or under a bed? Is it not to be set on a lampstand?

22. For there is nothing hidden which will not be revealed, nor has anything been kept secret but that it should come to light.

23. If anyone has ears to hear, let him hear."

24. Then He said to them, "Take heed what you hear. With the same measure you use, it will be measured to you; and to you who hear, more will be given.

25. For whoever has, to him more will be given; but whoever does not have, even what he has will be taken away from him."

26. And He said, "The kingdom of God is as if a man should scatter seed on the ground,

27. and should sleep by night and rise by day, and the seed should sprout and grow, he himself does not know how.

28. For the earth yields crops by itself: first the blade, then the head, after that the full grain in the head.

29. But when the grain ripens, immediately he puts in the sickle, because the harvest has come."

30. Then He said, "To what shall we liken the kingdom of God? Or with what parable shall we picture it?

31. It is like a mustard seed which, when it is sown on the ground, is smaller than all the seeds on earth;

32. but when it is sown, it grows up and becomes greater than all herbs, and shoots out large branches, so that the birds of the air may nest under its shade."

33. And with many such parables He spoke the word to them as they were able to hear it.

34. But without a parable He did not speak to them. And when they were alone, He explained all things to His disciples.

35. On the same day, when evening had come, He said to them, "Let us cross over to the other side."

36. Now when they had left the multitude, they took Him along in the boat as He was. And other little boats were also with Him.

37. And a great windstorm arose, and the waves beat into the boat, so that it was already filling.

38. But He was in the stern, asleep on a pillow. And they awoke Him and said to Him, "Teacher, do You not care that we are perishing?"

39. Then He arose and rebuked the wind, and said to the sea, "Peace, be still!" And the wind ceased and there was a great calm.

40. But He said to them, "Why are you so fearful? How is it that you have no faith?"

41. And they feared exceedingly, and said to one another, "Who can this be, that even the wind and the sea obey Him!"

## Chapter 5

1. Then they came to the other side of the sea, to the country of the Gadarenes.

2. And when He had come out of the boat, immediately there met Him out of the tombs a man with an unclean spirit,

3. who had his dwelling among the tombs; and no one could bind him, not even with chains,

4. because he had often been bound with shackles and chains. And the chains had been pulled apart by him, and the shackles broken in pieces; neither could anyone tame him.

5. And always, night and day, he was in the mountains and in the tombs, crying out and cutting himself with stones.

6. When he saw Jesus from afar, he ran and worshiped Him.

7. And he cried out with a loud voice and said, "What have I to do with You, Jesus, Son of the Most High God? I implore You by God that You do not torment me."

8. For He said to him, "Come out of the man, unclean spirit!"

9. Then He asked him, "What is your name?" And he answered, saying, "My name is Legion; for we are many."

10. Also he begged Him earnestly that He would not send them out of the country.

11. Now a large herd of swine was feeding there near the mountains.

12. So all the demons begged Him, saying, "Send us to the swine, that we may enter them."

13. And at once Jesus gave them permission. Then the unclean spirits went out and entered the swine (there were about two thousand); and the herd ran violently down the steep place into the sea, and drowned in the sea.

14. So those who fed the swine fled, and they told it in the city and in the country. And they went out to see what it was that had happened.

15. Then they came to Jesus, and saw the one who had been demon-possessed and had the legion, sitting and clothed and in his right mind. And they were afraid.

16. And those who saw it told them how it happened to him who had been demon-possessed, and about the swine.

17. Then they began to plead with Him to depart from their region.

18. And when He got into the boat, he who had been demon-possessed begged Him that he might be with Him.

19. However, Jesus did not permit him, but said to him, "Go home to your friends, and tell them what great things the Lord has done for you, and how He has had compassion on you."

20. And he departed and began to proclaim in Decapolis all that Jesus had done for him; and all marveled.

21. Now when Jesus had crossed over again by boat to the other side, a great multitude gathered to Him; and He was by the sea.

22. And behold, one of the rulers of the synagogue came, Jairus by name. And when he saw Him, he fell at His feet

23. and begged Him earnestly, saying, "My little daughter lies at the point of death. Come and lay Your hands on her, that she may be healed, and she will live."

24. So Jesus went with him, and a great multitude followed Him and thronged Him.

25. Now a certain woman had a flow of blood for twelve years,

26. and had suffered many things from many physicians. She had spent all that she had and was no better, but rather grew worse.

27. When she heard about Jesus, she came behind Him in the crowd and touched His garment.

28. For she said, "If only I may touch His clothes, I shall be made well."

29. Immediately the fountain of her blood was dried up, and she felt in her body that she was healed of the affliction.

30. And Jesus, immediately knowing in Himself that power had gone out of Him, turned around in the crowd and said, "Who touched My clothes?"

31. But His disciples said to Him, "You see the multitude thronging You, and You say, "Who touched Me?"'

32. And He looked around to see her who had done this thing.

33. But the woman, fearing and trembling, knowing what had happened to her, came and fell down before Him and told Him the whole truth.

34. And He said to her, "Daughter, your faith has made you well. Go in peace, and be healed of your affliction."

35. While He was still speaking, some came from the ruler of the synagogue's house who said, "Your daughter is dead. Why trouble the Teacher any further?"

36. As soon as Jesus heard the word that was spoken, He said to the ruler of the synagogue, "Do not be afraid; only believe."

37. And He permitted no one to follow Him except Peter, James, and John the brother of James.

38. Then He came to the house of the ruler of the synagogue, and saw a tumult and those who wept and wailed loudly.

39. When He came in, He said to them, "Why make this commotion and weep? The child is not dead, but sleeping."

40. And they ridiculed Him. But when He had put them all outside, He took the father and the mother of the child, and those who were with Him, and entered where the child was lying.

41. Then He took the child by the hand, and said to her, "Talitha, cumi," which is translated, "Little girl, I say to you, arise."

42. Immediately the girl arose and walked, for she was twelve years of age. And they were overcome with great amazement.

43. But He commanded them strictly that no one should know it, and said that something should be given her to eat.

## Chapter 6

1. Then He went out from there and came to His own country, and His disciples followed Him.

2. And when the Sabbath had come, He began to teach in the synagogue. And many hearing Him were astonished, saying, "Where did this Man get these things? And what wisdom is this which is given to Him, that such mighty works are performed by His hands!

3. Is this not the carpenter, the Son of Mary, and brother of James, Joses, Judas, and Simon? And are not His sisters here with us?" So they were offended at Him.

4. But Jesus said to them, "A prophet is not without honor except in his own country, among his own relatives, and in his own house."

5. Now He could do no mighty work there, except that He laid His hands on a few sick people and healed them.

6. And He marveled because of their unbelief. Then He went about the villages in a circuit, teaching.

7. And He called the twelve to Himself, and began to send them out two by two, and gave them power over unclean spirits.

8. He commanded them to take nothing for the journey except a staff--no bag, no bread, no copper in their money belts--

9. but to wear sandals, and not to put on two tunics.

10. Also He said to them, "In whatever place you enter a house, stay there till you depart from that place.

11. And whoever will not receive you nor hear you, when you depart from there, shake off the dust under your feet as a testimony against them. Assuredly, I say to you, it will be more tolerable for Sodom and Gomorrah in the day of judgment than for that city!"

12. So they went out and preached that people should repent.

13. And they cast out many demons, and anointed with oil many who were sick, and healed them.

14. Now King Herod heard of Him, for His name had become well known. And he said, "John the Baptist is risen from the dead, and therefore these powers are at work in him."

15. Others said, "It is Elijah." And others said, "It is the Prophet, or like one of the prophets."

16. But when Herod heard, he said, "This is John, whom I beheaded; he has been raised from the dead!"

17. For Herod himself had sent and laid hold of John, and bound him in prison for the sake of Herodias, his brother Philip's wife; for he had married her.

18. Because John had said to Herod, "It is not lawful for you to have your brother's wife."

19. Therefore Herodias held it against him and wanted to kill him, but she could not;

20. for Herod feared John, knowing that he was a just and holy man, and he protected him. And when he heard him, he did many things, and heard him gladly.

21. Then an opportune day came when Herod on his birthday gave a feast for his nobles, the high officers, and the chief men of Galilee.

22. And when Herodias' daughter herself came in and danced, and pleased Herod and those who sat with him, the king said to the girl, "Ask me whatever you want, and I will give it to you."

23. He also swore to her, "Whatever you ask me, I will give you, up to half my kingdom."

24. So she went out and said to her mother, "What shall I ask?" And she said, "The head of John the Baptist!"

25. Immediately she came in with haste to the king and asked, saying, "I want you to give me at once the head of John the Baptist on a platter."

26. And the king was exceedingly sorry; yet, because of the oaths and because of those who sat with him, he did not want to refuse her.

27. Immediately the king sent an executioner and commanded his head to be brought. And he went and beheaded him in prison,

28. brought his head on a platter, and gave it to the girl; and the girl gave it to her mother.

29. When his disciples heard of it, they came and took away his corpse and laid it in a tomb.

30. Then the apostles gathered to Jesus and told Him all things, both what they had done and what they had taught.

31. And He said to them, "Come aside by yourselves to a deserted place and rest a while." For there were many coming and going, and they did not even have time to eat.

32. So they departed to a deserted place in the boat by themselves.

33. But the multitudes saw them departing, and many knew Him and ran there on foot from all the cities. They arrived before them and came together to Him.

34. And Jesus, when He came out, saw a great multitude and was moved with compassion for them, because they were like sheep not having a shepherd. So He began to teach them many things.

35. When the day was now far spent, His disciples came to Him and said, "This is a deserted place, and already the hour is late.

36. Send them away, that they may go into the surrounding country and villages and buy themselves bread; for they have nothing to eat."

37. But He answered and said to them, "You give them something to eat." And they said to Him, "Shall we go and buy two hundred denarii worth of bread and give them something to eat?"

38. But He said to them, "How many loaves do you have? Go and see." And when they found out they said, "Five, and two fish."

39. Then He commanded them to make them all sit down in groups on the green grass.

40. So they sat down in ranks, in hundreds and in fifties.

41. And when He had taken the five loaves and the two fish, He looked up to heaven, blessed and broke the loaves, and gave them to His disciples to set before them; and the two fish He divided among them all.

42. So they all ate and were filled.

43. And they took up twelve baskets full of fragments and of the fish.

44. Now those who had eaten the loaves were about five thousand men.

45. Immediately He made His disciples get into the boat and go before Him to the other side, to Bethsaida, while He sent the multitude away.

46. And when He had sent them away, He departed to the mountain to pray.

47. Now when evening came, the boat was in the middle of the sea; and He was alone on the land.

48. Then He saw them straining at rowing, for the wind was against them. Now about the fourth watch of the night He came to them, walking on the sea, and would have passed them by.

49. And when they saw Him walking on the sea, they supposed it was a ghost, and cried out;

50. for they all saw Him and were troubled. But immediately He talked with them and said to them, "Be of good cheer! It is I; do not be afraid."

51. Then He went up into the boat to them, and the wind ceased. And they were greatly amazed in themselves beyond measure, and marveled.

52. For they had not understood about the loaves, because their heart was hardened.

53. When they had crossed over, they came to the land of Gennesaret and anchored there.

54. And when they came out of the boat, immediately the people recognized Him,

55. ran through that whole surrounding region, and began to carry about on beds those who were sick to wherever they heard He was.

56. Wherever He entered, into villages, cities, or the country, they laid the sick in the marketplaces, and begged Him that they might just touch the hem of His garment. And as many as touched Him were made well.

## Chapter 7

1. Then the Pharisees and some of the scribes came together to Him, having come from Jerusalem.

2. Now when they saw some of His disciples eat bread with defiled, that is, with unwashed hands, they found fault.

3. For the Pharisees and all the Jews do not eat unless they wash their hands in a special way, holding the tradition of the elders.

4. When they come from the marketplace, they do not eat unless they wash. And there are many other things which they have received and hold, like the washing of cups, pitchers, copper vessels, and couches.

5. Then the Pharisees and scribes asked Him, "Why do Your disciples not walk according to the tradition of the elders, but eat bread with unwashed hands?"

6. He answered and said to them, "Well did Isaiah prophesy of you hypocrites, as it is written: "This people honors Me with their lips, But their heart is far from Me.

7. And in vain they worship Me, Teaching as doctrines the commandments of men.'

8. For laying aside the commandment of God, you hold the tradition of men--the washing of pitchers and cups, and many other such things you do."

9. He said to them, "All too well you reject the commandment of God, that you may keep your tradition.

10. For Moses said, "Honor your father and your mother'; and, "He who curses father or mother, let him be put to death.'

11. But you say, "If a man says to his father or mother, "Whatever profit you might have received from me is Corban"--' (that is, a gift to God),

12. then you no longer let him do anything for his father or his mother,

13. making the word of God of no effect through your tradition which you have handed down. And many such things you do."

14. When He had called all the multitude to Himself, He said to them, "Hear Me, everyone, and understand:

15. There is nothing that enters a man from outside which can defile him; but the things which come out of him, those are the things that defile a man.

16. If anyone has ears to hear, let him hear!"

17. When He had entered a house away from the crowd, His disciples asked Him concerning the parable.

18. So He said to them, "Are you thus without understanding also? Do you not perceive that whatever enters a man from outside cannot defile him,

19. because it does not enter his heart but his stomach, and is eliminated, thus purifying all foods?"

20. And He said, "What comes out of a man, that defiles a man.

21. For from within, out of the heart of men, proceed evil thoughts, adulteries, fornications, murders,

22. thefts, covetousness, wickedness, deceit, lewdness, an evil eye, blasphemy, pride, foolishness.

23. All these evil things come from within and defile a man."

24. From there He arose and went to the region of Tyre and Sidon. And He entered a house and wanted no one to know it, but He could not be hidden.

25. For a woman whose young daughter had an unclean spirit heard about Him, and she came and fell at His feet.

26. The woman was a Greek, a Syro-Phoenician by birth, and she kept asking Him to cast the demon out of her daughter.

27. But Jesus said to her, "Let the children be filled first, for it is not good to take the children's bread and throw it to the little dogs."

28. And she answered and said to Him, "Yes, Lord, yet even the little dogs under the table eat from the children's crumbs."

29. Then He said to her, "For this saying go your way; the demon has gone out of your daughter."

30. And when she had come to her house, she found the demon gone out, and her daughter lying on the bed.

31. Again, departing from the region of Tyre and Sidon, He came through the midst of the region of Decapolis to the Sea of Galilee.

32. Then they brought to Him one who was deaf and had an impediment in his speech, and they begged Him to put His hand on him.

33. And He took him aside from the multitude, and put His fingers in his ears, and He spat and touched his tongue.

34. Then, looking up to heaven, He sighed, and said to him, "Ephphatha," that is, "Be opened."

35. Immediately his ears were opened, and the impediment of his tongue was loosed, and he spoke plainly.

36. Then He commanded them that they should tell no one; but the more He commanded them, the more widely they proclaimed it.

37. And they were astonished beyond measure, saying, "He has done all things well. He makes both the deaf to hear and the mute to speak."

## Chapter 8

1. In those days, the multitude being very great and having nothing to eat, Jesus called His disciples to Him and said to them,

2. "I have compassion on the multitude, because they have now continued with Me three days and have nothing to eat.

3. And if I send them away hungry to their own houses, they will faint on the way; for some of them have come from afar."

4. Then His disciples answered Him, "How can one satisfy these people with bread here in the wilderness?"

5. He asked them, "How many loaves do you have?" And they said, "Seven."

6. So He commanded the multitude to sit down on the ground. And He took the seven loaves and gave thanks, broke them and gave them to His disciples to set before them; and they set them before the multitude.

7. They also had a few small fish; and having blessed them, He said to set them also before them.

8. So they ate and were filled, and they took up seven large baskets of leftover fragments.

9. Now those who had eaten were about four thousand. And He sent them away,

10. immediately got into the boat with His disciples, and came to the region of Dalmanutha.

11. Then the Pharisees came out and began to dispute with Him, seeking from Him a sign from heaven, testing Him.

12. But He sighed deeply in His spirit, and said, "Why does this generation seek a sign? Assuredly, I say to you, no sign shall be given to this generation."

13. And He left them, and getting into the boat again, departed to the other side.

14. Now the disciples had forgotten to take bread, and they did not have more than one loaf with them in the boat.

15. Then He charged them, saying, "Take heed, beware of the leaven of the Pharisees and the leaven of Herod."

16. And they reasoned among themselves, saying, "It is because we have no bread."

17. But Jesus, being aware of it, said to them, "Why do you reason because you have no bread? Do you not yet perceive nor understand? Is your heart still hardened?

18. Having eyes, do you not see? And having ears, do you not hear? And do you not remember?

19. When I broke the five loaves for the five thousand, how many baskets full of fragments did you take up?" They said to Him, "Twelve."

20. "Also, when I broke the seven for the four thousand, how many large baskets full of fragments did you take up?" And they said, "Seven."

21. So He said to them, "How is it you do not understand?"

22. Then He came to Bethsaida; and they brought a blind man to Him, and begged Him to touch him.

23. So He took the blind man by the hand and led him out of the town. And when He had spit on his eyes and put His hands on him, He asked him if he saw anything.

24. And he looked up and said, "I see men like trees, walking."

25. Then He put His hands on his eyes again and made him look up. And he was restored and saw everyone clearly.

26. Then He sent him away to his house, saying, "Neither go into the town, nor tell anyone in the town."

27. Now Jesus and His disciples went out to the towns of Caesarea Philippi; and on the road He asked His disciples, saying to them, "Who do men say that I am?"

28. So they answered, "John the Baptist; but some say, Elijah; and others, one of the prophets."

29. He said to them, "But who do you say that I am?" Peter answered and said to Him, "You are the Christ."

30. Then He strictly warned them that they should tell no one about Him.

31. And He began to teach them that the Son of Man must suffer many things, and be rejected by the elders and chief priests and scribes, and be killed, and after three days rise again.

32. He spoke this word openly. Then Peter took Him aside and began to rebuke Him.

33. But when He had turned around and looked at His disciples, He rebuked Peter, saying, "Get behind Me, Satan! For you are not mindful of the things of God, but the things of men."

34. When He had called the people to Himself, with His disciples also, He said to them, "Whoever desires to come after Me, let him deny himself, and take up his cross, and follow Me.

35. For whoever desires to save his life will lose it, but whoever loses his life for My sake and the gospel's will save it.

36. For what will it profit a man if he gains the whole world, and loses his own soul?

37. Or what will a man give in exchange for his soul?

38. For whoever is ashamed of Me and My words in this adulterous and sinful generation, of him the Son of Man also will be ashamed when He comes in the glory of His Father with the holy angels."

## Chapter 9

1. And He said to them, "Assuredly, I say to you that there are some standing here who will not taste death till they see the kingdom of God present with power."

2. Now after six days Jesus took Peter, James, and John, and led them up on a high mountain apart by themselves; and He was transfigured before them.

3. His clothes became shining, exceedingly white, like snow, such as no launderer on earth can whiten them.

4. And Elijah appeared to them with Moses, and they were talking with Jesus.

5. Then Peter answered and said to Jesus, "Rabbi, it is good for us to be here; and let us make three tabernacles: one for You, one for Moses, and one for Elijah"--

6. because he did not know what to say, for they were greatly afraid.

7. And a cloud came and overshadowed them; and a voice came out of the cloud, saying, "This is My beloved Son. Hear Him!"

8. Suddenly, when they had looked around, they saw no one anymore, but only Jesus with themselves.

9. Now as they came down from the mountain, He commanded them that they should tell no one the things they had seen, till the Son of Man had risen from the dead.

10. So they kept this word to themselves, questioning what the rising from the dead meant.

11. And they asked Him, saying, "Why do the scribes say that Elijah must come first?"

12. Then He answered and told them, "Indeed, Elijah is coming first and restores all things. And how is it written concerning the Son of Man, that He must suffer many things and be treated with contempt?

13. But I say to you that Elijah has also come, and they did to him whatever they wished, as it is written of him."

14. And when He came to the disciples, He saw a great multitude around them, and scribes disputing with them.

15. Immediately, when they saw Him, all the people were greatly amazed, and running to Him, greeted Him.

16. And He asked the scribes, "What are you discussing with them?"

17. Then one of the crowd answered and said, "Teacher, I brought You my son, who has a mute spirit.

18. And wherever it seizes him, it throws him down; he foams at the mouth, gnashes his teeth, and becomes rigid. So I spoke to Your disciples, that they should cast it out, but they could not."

19. He answered him and said, "O faithless generation, how long shall I be with you? How long shall I bear with you? Bring him to Me."

20. Then they brought him to Him. And when he saw Him, immediately the spirit convulsed him, and he fell on the ground and wallowed, foaming at the mouth.

21. So He asked his father, "How long has this been happening to him?" And he said, "From childhood.

22. And often he has thrown him both into the fire and into the water to destroy him. But if You can do anything, have compassion on us and help us."

23. Jesus said to him, "If you can believe, all things are possible to him who believes."

24. Immediately the father of the child cried out and said with tears, "Lord, I believe; help my unbelief!"

25. When Jesus saw that the people came running together, He rebuked the unclean spirit, saying to it, "Deaf and dumb spirit, I command you, come out of him and enter him no more!"

26. Then the spirit cried out, convulsed him greatly, and came out of him. And he became as one dead, so that many said, "He is dead."

27. But Jesus took him by the hand and lifted him up, and he arose.

28. And when He had come into the house, His disciples asked Him privately, "Why could we not cast it out?"

29. So He said to them, "This kind can come out by nothing but prayer and fasting."

30. Then they departed from there and passed through Galilee, and He did not want anyone to know it.

31. For He taught His disciples and said to them, "The Son of Man is being betrayed into the hands of men, and they will kill Him. And after He is killed, He will rise the third day."

32. But they did not understand this saying, and were afraid to ask Him.

33. Then He came to Capernaum. And when He was in the house He asked them, "What was it you disputed among yourselves on the road?"

34. But they kept silent, for on the road they had disputed among themselves who would be the greatest.

35. And He sat down, called the twelve, and said to them, "If anyone desires to be first, he shall be last of all and servant of all."

36. Then He took a little child and set him in the midst of them. And when He had taken him in His arms, He said to them,

37. "Whoever receives one of these little children in My name receives Me; and whoever receives Me, receives not Me but Him who sent Me."

38. Now John answered Him, saying, "Teacher, we saw someone who does not follow us casting out demons in Your name, and we forbade him because he does not follow us."

39. But Jesus said, "Do not forbid him, for no one who works a miracle in My name can soon afterward speak evil of Me.

40. For he who is not against us is on our side.

41. For whoever gives you a cup of water to drink in My name, because you belong to Christ, assuredly, I say to you, he will by no means lose his reward.

42. "But whoever causes one of these little ones who believe in Me to stumble, it would be better for him if a millstone were hung around his neck, and he were thrown into the sea.

43. If your hand causes you to sin, cut it off. It is better for you to enter into life maimed, rather than having two hands, to go to hell, into the fire that shall never be quenched--

44. where "Their worm does not die And the fire is not quenched.'

45. And if your foot causes you to sin, cut it off. It is better for you to enter life lame, rather than having two feet, to be cast into hell, into the fire that shall never be quenched--

46. where "Their worm does not die And the fire is not quenched.'

47. And if your eye causes you to sin, pluck it out. It is better for you to enter the kingdom of God with one eye, rather than having two eyes, to be cast into hell fire--

48. where "Their worm does not die And the fire is not quenched.'

49. "For everyone will be seasoned with fire, and every sacrifice will be seasoned with salt.

50. Salt is good, but if the salt loses its flavor, how will you season it? Have salt in yourselves, and have peace with one another."

## Chapter 10

1. Then He arose from there and came to the region of Judea by the other side of the Jordan. And multitudes gathered to Him again, and as He was accustomed, He taught them again.

2. The Pharisees came and asked Him, "Is it lawful for a man to divorce his wife?" testing Him.

3. And He answered and said to them, "What did Moses command you?"

4. They said, "Moses permitted a man to write a certificate of divorce, and to dismiss her."

5. And Jesus answered and said to them, "Because of the hardness of your heart he wrote you this precept.

6. But from the beginning of the creation, God "made them male and female.'

7. "For this reason a man shall leave his father and mother and be joined to his wife,

8. and the two shall become one flesh'; so then they are no longer two, but one flesh.

9. Therefore what God has joined together, let not man separate."

10. In the house His disciples also asked Him again about the same matter.

11. So He said to them, "Whoever divorces his wife and marries another commits adultery against her.

12. And if a woman divorces her husband and marries another, she commits adultery."

13. Then they brought little children to Him, that He might touch them; but the disciples rebuked those who brought them.

14. But when Jesus saw it, He was greatly displeased and said to them, "Let the little children come to Me, and do not forbid them; for of such is the kingdom of God.

15. Assuredly, I say to you, whoever does not receive the kingdom of God as a little child will by no means enter it."

16. And He took them up in His arms, laid His hands on them, and blessed them.

17. Now as He was going out on the road, one came running, knelt before Him, and asked Him, "Good Teacher, what shall I do that I may inherit eternal life?"

18. So Jesus said to him, "Why do you call Me good? No one is good but One, that is, God.

19. You know the commandments: "Do not commit adultery,' "Do not murder,' "Do not steal,' "Do not bear false witness,' "Do not defraud,' "Honor your father and your mother."'

20. And he answered and said to Him, "Teacher, all these things I have kept from my youth."

21. Then Jesus, looking at him, loved him, and said to him, "One thing you lack: Go your way, sell whatever you have and give to the poor, and you will have treasure in heaven; and come, take up the cross, and follow Me."

22. But he was sad at this word, and went away sorrowful, for he had great possessions.

23. Then Jesus looked around and said to His disciples, "How hard it is for those who have riches to enter the kingdom of God!"

24. And the disciples were astonished at His words. But Jesus answered again and said to them, "Children, how hard it is for those who trust in riches to enter the kingdom of God!

25. It is easier for a camel to go through the eye of a needle than for a rich man to enter the kingdom of God."

26. And they were greatly astonished, saying among themselves, "Who then can be saved?"

27. But Jesus looked at them and said, "With men it is impossible, but not with God; for with God all things are possible."

28. Then Peter began to say to Him, "See, we have left all and followed You."

29. So Jesus answered and said, "Assuredly, I say to you, there is no one who has left house or brothers or sisters or father or mother or wife or children or lands, for My sake and the gospel's,

30. who shall not receive a hundredfold now in this time--houses and brothers and sisters and mothers and children and lands, with persecutions--and in the age to come, eternal life.

31. But many who are first will be last, and the last first."

32. Now they were on the road, going up to Jerusalem, and Jesus was going before them; and they were amazed. And as they followed they were afraid. Then He took the twelve aside again and began to tell them the things that would happen to Him:

33. "Behold, we are going up to Jerusalem, and the Son of Man will be betrayed to the chief priests and to the scribes; and they will condemn Him to death and deliver Him to the Gentiles;

34. and they will mock Him, and scourge Him, and spit on Him, and kill Him. And the third day He will rise again."

35. Then James and John, the sons of Zebedee, came to Him, saying, "Teacher, we want You to do for us whatever we ask."

36. And He said to them, "What do you want Me to do for you?"

37. They said to Him, "Grant us that we may sit, one on Your right hand and the other on Your left, in Your glory."

38. But Jesus said to them, "You do not know what you ask. Are you able to drink the cup that I drink, and be baptized with the baptism that I am baptized with?"

39. They said to Him, "We are able." So Jesus said to them, "You will indeed drink the cup that I drink, and with the baptism I am baptized with you will be baptized;

40. but to sit on My right hand and on My left is not Mine to give, but it is for those for whom it is prepared."

41. And when the ten heard it, they began to be greatly displeased with James and John.

42. But Jesus called them to Himself and said to them, "You know that those who are considered rulers over the Gentiles lord it over them, and their great ones exercise authority over them.

43. Yet it shall not be so among you; but whoever desires to become great among you shall be your servant.

44. And whoever of you desires to be first shall be slave of all.

45. For even the Son of Man did not come to be served, but to serve, and to give His life a ransom for many."

46. Now they came to Jericho. As He went out of Jericho with His disciples and a great multitude, blind Bartimaeus, the son of Timaeus, sat by the road begging.

47. And when he heard that it was Jesus of Nazareth, he began to cry out and say, "Jesus, Son of David, have mercy on me!"

48. Then many warned him to be quiet; but he cried out all the more, "Son of David, have mercy on me!"

49. So Jesus stood still and commanded him to be called. Then they called the blind man, saying to him, "Be of good cheer. Rise, He is calling you."

50. And throwing aside his garment, he rose and came to Jesus.

51. So Jesus answered and said to him, "What do you want Me to do for you?" The blind man said to Him, "Rabboni, that I may receive my sight."

52. Then Jesus said to him, "Go your way; your faith has made you well." And immediately he received his sight and followed Jesus on the road.

## Chapter 11

1. Now when they drew near Jerusalem, to Bethphage and Bethany, at the Mount of Olives, He sent two of His disciples;

2. and He said to them, "Go into the village opposite you; and as soon as you have entered it you will find a colt tied, on which no one has sat. Loose it and bring it.

3. And if anyone says to you, "Why are you doing this?' say, "The Lord has need of it,' and immediately he will send it here."

4. So they went their way, and found the colt tied by the door outside on the street, and they loosed it.

5. But some of those who stood there said to them, "What are you doing, loosing the colt?"

6. And they spoke to them just as Jesus had commanded. So they let them go.

7. Then they brought the colt to Jesus and threw their clothes on it, and He sat on it.

8. And many spread their clothes on the road, and others cut down leafy branches from the trees and spread them on the road.

9. Then those who went before and those who followed cried out, saying: "Hosanna! "Blessed is He who comes in the name of the LORD!'

10. Blessed is the kingdom of our father David That comes in the name of the Lord! Hosanna in the highest!"

11. And Jesus went into Jerusalem and into the temple. So when He had looked around at all things, as the hour was already late, He went out to Bethany with the twelve.

12. Now the next day, when they had come out from Bethany, He was hungry.

13. And seeing from afar a fig tree having leaves, He went to see if perhaps He would find something on it. When He came to it, He found nothing but leaves, for it was not the season for figs.

14. In response Jesus said to it, "Let no one eat fruit from you ever again." And His disciples heard it.

15. So they came to Jerusalem. Then Jesus went into the temple and began to drive out those who bought and sold in the temple, and overturned the tables of the money changers and the seats of those who sold doves.

16. And He would not allow anyone to carry wares through the temple.

17. Then He taught, saying to them, "Is it not written, "My house shall be called a house of prayer for all nations'? But you have made it a "den of thieves."'

18. And the scribes and chief priests heard it and sought how they might destroy Him; for they feared Him, because all the people were astonished at His teaching.

19. When evening had come, He went out of the city.

20. Now in the morning, as they passed by, they saw the fig tree dried up from the roots.

21. And Peter, remembering, said to Him, "Rabbi, look! The fig tree which You cursed has withered away."

22. So Jesus answered and said to them, "Have faith in God.

23. For assuredly, I say to you, whoever says to this mountain, "Be removed and be cast into the sea,' and does not doubt in his heart, but believes that those things he says will be done, he will have whatever he says.

24. Therefore I say to you, whatever things you ask when you pray, believe that you receive them, and you will have them.

25. "And whenever you stand praying, if you have anything against anyone, forgive him, that your Father in heaven may also forgive you your trespasses.

26. But if you do not forgive, neither will your Father in heaven forgive your trespasses."

27. Then they came again to Jerusalem. And as He was walking in the temple, the chief priests, the scribes, and the elders came to Him.

28. And they said to Him, "By what authority are You doing these things? And who gave You this authority to do these things?"

29. But Jesus answered and said to them, "I also will ask you one question; then answer Me, and I will tell you by what authority I do these things:

30. The baptism of John--was it from heaven or from men? Answer Me."

31. And they reasoned among themselves, saying, "If we say, "From heaven,' He will say, "Why then did you not believe him?'

32. But if we say, "From men"'--they feared the people, for all counted John to have been a prophet indeed.

33. So they answered and said to Jesus, "We do not know." And Jesus answered and said to them, "Neither will I tell you by what authority I do these things."

## Chapter 12

1. Then He began to speak to them in parables: "A man planted a vineyard and set a hedge around it, dug a place for the wine vat and built a tower. And he leased it to vinedressers and went into a far country.

2. Now at vintage-time he sent a servant to the vinedressers, that he might receive some of the fruit of the vineyard from the vinedressers.

3. And they took him and beat him and sent him away empty-handed.

4. Again he sent them another servant, and at him they threw stones, wounded him in the head, and sent him away shamefully treated.

5. And again he sent another, and him they killed; and many others, beating some and killing some.

6. Therefore still having one son, his beloved, he also sent him to them last, saying, "They will respect my son.'

7. But those vinedressers said among themselves, "This is the heir. Come, let us kill him, and the inheritance will be ours.'

8. So they took him and killed him and cast him out of the vineyard.

9. "Therefore what will the owner of the vineyard do? He will come and destroy the vinedressers, and give the vineyard to others.

10. Have you not even read this Scripture: "The stone which the builders rejected Has become the chief cornerstone.

11. This was the LORD's doing, And it is marvelous in our eyes'?"

12. And they sought to lay hands on Him, but feared the multitude, for they knew He had spoken the parable against them. So they left Him and went away.

13. Then they sent to Him some of the Pharisees and the Herodians, to catch Him in His words.

14. When they had come, they said to Him, "Teacher, we know that You are true, and care about no one; for You do not regard the person of men, but teach the way of God in truth. Is it lawful to pay taxes to Caesar, or not?

15. Shall we pay, or shall we not pay?" But He, knowing their hypocrisy, said to them, "Why do you test Me? Bring Me a denarius that I may see it."

16. So they brought it. And He said to them, "Whose image and inscription is this?" They said to Him, "Caesar's."

17. And Jesus answered and said to them, "Render to Caesar the things that are Caesar's, and to God the things that are God's." And they marveled at Him.

18. Then some Sadducees, who say there is no resurrection, came to Him; and they asked Him, saying:

19. "Teacher, Moses wrote to us that if a man's brother dies, and leaves his wife behind, and leaves no children, his brother should take his wife and raise up offspring for his brother.

20. Now there were seven brothers. The first took a wife; and dying, he left no offspring.

21. And the second took her, and he died; nor did he leave any offspring. And the third likewise.

22. So the seven had her and left no offspring. Last of all the woman died also.

23. Therefore, in the resurrection, when they rise, whose wife will she be? For all seven had her as wife."

24. Jesus answered and said to them, "Are you not therefore mistaken, because you do not know the Scriptures nor the power of God?

25. For when they rise from the dead, they neither marry nor are given in marriage, but are like angels in heaven.

26. But concerning the dead, that they rise, have you not read in the book of Moses, in the burning bush passage, how God spoke to him, saying, "I am the God of Abraham, the God of Isaac, and the God of Jacob'?

27. He is not the God of the dead, but the God of the living. You are therefore greatly mistaken."

28. Then one of the scribes came, and having heard them reasoning together, perceiving that He had answered them well, asked Him, "Which is the first commandment of all?"

29. Jesus answered him, "The first of all the commandments is: "Hear, O Israel, the LORD our God, the LORD is one.

30. And you shall love the LORD your God with all your heart, with all your soul, with all your mind, and with all your strength.' This is the first commandment.

31. And the second, like it, is this: "You shall love your neighbor as yourself.' There is no other commandment greater than these."

32. So the scribe said to Him, "Well said, Teacher. You have spoken the truth, for there is one God, and there is no other but He.

33. And to love Him with all the heart, with all the understanding, with all the soul, and with all the strength, and to love one's neighbor as oneself, is more than all the whole burnt offerings and sacrifices."

34. Now when Jesus saw that he answered wisely, He said to him, "You are not far from the kingdom of God." But after that no one dared question Him.

35. Then Jesus answered and said, while He taught in the temple, "How is it that the scribes say that the Christ is the Son of David?

36. For David himself said by the Holy Spirit: "The LORD said to my Lord, "Sit at My right hand, Till I make Your enemies Your footstool."'

37. Therefore David himself calls Him "Lord'; how is He then his Son?" And the common people heard Him gladly.

38. Then He said to them in His teaching, "Beware of the scribes, who desire to go around in long robes, love greetings in the marketplaces,

39. the best seats in the synagogues, and the best places at feasts,

40. who devour widows' houses, and for a pretense make long prayers. These will receive greater condemnation."

41. Now Jesus sat opposite the treasury and saw how the people put money into the treasury. And many who were rich put in much.

42. Then one poor widow came and threw in two mites, which make a quadrans.

43. So He called His disciples to Himself and said to them, "Assuredly, I say to you that this poor widow has put in more than all those who have given to the treasury;

44. for they all put in out of their abundance, but she out of her poverty put in all that she had, her whole livelihood."

## Chapter 13

1. Then as He went out of the temple, one of His disciples said to Him, "Teacher, see what manner of stones and what buildings are here!"

2. And Jesus answered and said to him, "Do you see these great buildings? Not one stone shall be left upon another, that shall not be thrown down."

3. Now as He sat on the Mount of Olives opposite the temple, Peter, James, John, and Andrew asked Him privately,

4. "Tell us, when will these things be? And what will be the sign when all these things will be fulfilled?"

5. And Jesus, answering them, began to say: "Take heed that no one deceives you.

6. For many will come in My name, saying, "I am He,' and will deceive many.

7. But when you hear of wars and rumors of wars, do not be troubled; for such things must happen, but the end is not yet.

8. For nation will rise against nation, and kingdom against kingdom. And there will be earthquakes in various places, and there will be famines and troubles. These are the beginnings of sorrows.

9. "But watch out for yourselves, for they will deliver you up to councils, and you will be beaten in the synagogues. You will be brought before rulers and kings for My sake, for a testimony to them.

10. And the gospel must first be preached to all the nations.

11. But when they arrest you and deliver you up, do not worry beforehand, or premeditate what you will speak. But whatever is given you in that hour, speak that; for it is not you who speak, but the Holy Spirit.

12. Now brother will betray brother to death, and a father his child; and children will rise up against parents and cause them to be put to death.

13. And you will be hated by all for My name's sake. But he who endures to the end shall be saved.

14. "So when you see the "abomination of desolation,' spoken of by Daniel the prophet, standing where it ought not" (let the reader understand), "then let those who are in Judea flee to the mountains.

15. Let him who is on the housetop not go down into the house, nor enter to take anything out of his house.

16. And let him who is in the field not go back to get his clothes.

17. But woe to those who are pregnant and to those who are nursing babies in those days!

18. And pray that your flight may not be in winter.

19. For in those days there will be tribulation, such as has not been since the beginning of the creation which God created until this time, nor ever shall be.

20. And unless the Lord had shortened those days, no flesh would be saved; but for the elect's sake, whom He chose, He shortened the days.

21. "Then if anyone says to you, "Look, here is the Christ!' or, "Look, He is there!' do not believe it.

22. For false christs and false prophets will rise and show signs and wonders to deceive, if possible, even the elect.

23. But take heed; see, I have told you all things beforehand.

24. "But in those days, after that tribulation, the sun will be darkened, and the moon will not give its light;

25. the stars of heaven will fall, and the powers in the heavens will be shaken.

26. Then they will see the Son of Man coming in the clouds with great power and glory.

27. And then He will send His angels, and gather together His elect from the four winds, from the farthest part of earth to the farthest part of heaven.

28. "Now learn this parable from the fig tree: When its branch has already become tender, and puts forth leaves, you know that summer is near.

29. So you also, when you see these things happening, know that it is near--at the doors!

30. Assuredly, I say to you, this generation will by no means pass away till all these things take place.

31. Heaven and earth will pass away, but My words will by no means pass away.

32. "But of that day and hour no one knows, not even the angels in heaven, nor the Son, but only the Father.

33. Take heed, watch and pray; for you do not know when the time is.

34. It is like a man going to a far country, who left his house and gave authority to his servants, and to each his work, and commanded the doorkeeper to watch.

35. Watch therefore, for you do not know when the master of the house is coming--in the evening, at midnight, at the crowing of the rooster, or in the morning--

36. lest, coming suddenly, he find you sleeping.

37. And what I say to you, I say to all: Watch!"

## Chapter 14

1. After two days it was the Passover and the Feast of Unleavened Bread. And the chief priests and the scribes sought how they might take Him by trickery and put Him to death.

2. But they said, "Not during the feast, lest there be an uproar of the people."

3. And being in Bethany at the house of Simon the leper, as He sat at the table, a woman came having an alabaster flask of very costly oil of spikenard. Then she broke the flask and poured it on His head.

4. But there were some who were indignant among themselves, and said, "Why was this fragrant oil wasted?

5. For it might have been sold for more than three hundred denarii and given to the poor." And they criticized her sharply.

6. But Jesus said, "Let her alone. Why do you trouble her? She has done a good work for Me.

7. For you have the poor with you always, and whenever you wish you may do them good; but Me you do not have always.

8. She has done what she could. She has come beforehand to anoint My body for burial.

9. Assuredly, I say to you, wherever this gospel is preached in the whole world, what this woman has done will also be told as a memorial to her."

10. Then Judas Iscariot, one of the twelve, went to the chief priests to betray Him to them.

11. And when they heard it, they were glad, and promised to give him money. So he sought how he might conveniently betray Him.

12. Now on the first day of Unleavened Bread, when they killed the Passover lamb, His disciples said to Him, "Where do You want us to go and prepare, that You may eat the Passover?"

13. And He sent out two of His disciples and said to them, "Go into the city, and a man will meet you carrying a pitcher of water; follow him.

14. Wherever he goes in, say to the master of the house, "The Teacher says, "Where is the guest room in which I may eat the Passover with My disciples?"'

15. Then he will show you a large upper room, furnished and prepared; there make ready for us."

16. So His disciples went out, and came into the city, and found it just as He had said to them; and they prepared the Passover.

17. In the evening He came with the twelve.

18. Now as they sat and ate, Jesus said, "Assuredly, I say to you, one of you who eats with Me will betray Me."

19. And they began to be sorrowful, and to say to Him one by one, "Is it I?" And another said, "Is it I?"

20. He answered and said to them, "It is one of the twelve, who dips with Me in the dish.

21. The Son of Man indeed goes just as it is written of Him, but woe to that man by whom the Son of Man is betrayed! It would have been good for that man if he had never been born."

22. And as they were eating, Jesus took bread, blessed and broke it, and gave it to them and said, "Take, eat; this is My body."

23. Then He took the cup, and when He had given thanks He gave it to them, and they all drank from it.

24. And He said to them, "This is My blood of the new covenant, which is shed for many.

25. Assuredly, I say to you, I will no longer drink of the fruit of the vine until that day when I drink it new in the kingdom of God."

26. And when they had sung a hymn, they went out to the Mount of Olives.

27. Then Jesus said to them, "All of you will be made to stumble because of Me this night, for it is written: "I will strike the Shepherd, And the sheep will be scattered.'

28. "But after I have been raised, I will go before you to Galilee."

29. Peter said to Him, "Even if all are made to stumble, yet I will not be."

30. Jesus said to him, "Assuredly, I say to you that today, even this night, before the rooster crows twice, you will deny Me three times."

31. But he spoke more vehemently, "If I have to die with You, I will not deny You!" And they all said likewise.

32. Then they came to a place which was named Gethsemane; and He said to His disciples, "Sit here while I pray."

33. And He took Peter, James, and John with Him, and He began to be troubled and deeply distressed.

34. Then He said to them, "My soul is exceedingly sorrowful, even to death. Stay here and watch."

35. He went a little farther, and fell on the ground, and prayed that if it were possible, the hour might pass from Him.

36. And He said, "Abba, Father, all things are possible for You. Take this cup away from Me; nevertheless, not what I will, but what You will."

37. Then He came and found them sleeping, and said to Peter, "Simon, are you sleeping? Could you not watch one hour?

38. Watch and pray, lest you enter into temptation. The spirit indeed is willing, but the flesh is weak."

39. Again He went away and prayed, and spoke the same words.

40. And when He returned, He found them asleep again, for their eyes were heavy; and they did not know what to answer Him.

41. Then He came the third time and said to them, "Are you still sleeping and resting? It is enough! The hour has come; behold, the Son of Man is being betrayed into the hands of sinners.

42. Rise, let us be going. See, My betrayer is at hand."

43. And immediately, while He was still speaking, Judas, one of the twelve, with a great multitude with swords and clubs, came from the chief priests and the scribes and the elders.

44. Now His betrayer had given them a signal, saying, "Whomever I kiss, He is the One; seize Him and lead Him away safely."

45. As soon as he had come, immediately he went up to Him and said to Him, "Rabbi, Rabbi!" and kissed Him.

46. Then they laid their hands on Him and took Him.

47. And one of those who stood by drew his sword and struck the servant of the high priest, and cut off his ear.

48. Then Jesus answered and said to them, "Have you come out, as against a robber, with swords and clubs to take Me?

49. I was daily with you in the temple teaching, and you did not seize Me. But the Scriptures must be fulfilled."

50. Then they all forsook Him and fled.

51. Now a certain young man followed Him, having a linen cloth thrown around his naked body. And the young men laid hold of him,

52. and he left the linen cloth and fled from them naked.

53. And they led Jesus away to the high priest; and with him were assembled all the chief priests, the elders, and the scribes.

54. But Peter followed Him at a distance, right into the courtyard of the high priest. And he sat with the servants and warmed himself at the fire.

55. Now the chief priests and all the council sought testimony against Jesus to put Him to death, but found none.

56. For many bore false witness against Him, but their testimonies did not agree.

57. Then some rose up and bore false witness against Him, saying,

58. "We heard Him say, "I will destroy this temple made with hands, and within three days I will build another made without hands."'

59. But not even then did their testimony agree.

60. And the high priest stood up in the midst and asked Jesus, saying, "Do You answer nothing? What is it these men testify against You?"

61. But He kept silent and answered nothing. Again the high priest asked Him, saying to Him, "Are You the Christ, the Son of the Blessed?"

62. Jesus said, "I am. And you will see the Son of Man sitting at the right hand of the Power, and coming with the clouds of heaven."

63. Then the high priest tore his clothes and said, "What further need do we have of witnesses?

64. You have heard the blasphemy! What do you think?" And they all condemned Him to be deserving of death.

65. Then some began to spit on Him, and to blindfold Him, and to beat Him, and to say to Him, "Prophesy!" And the officers struck Him with the palms of their hands.

66. Now as Peter was below in the courtyard, one of the servant girls of the high priest came.

67. And when she saw Peter warming himself, she looked at him and said, "You also were with Jesus of Nazareth."

68. But he denied it, saying, "I neither know nor understand what you are saying." And he went out on the porch, and a rooster crowed.

69. And the servant girl saw him again, and began to say to those who stood by, "This is one of them."

70. But he denied it again. And a little later those who stood by said to Peter again, "Surely you are one of them; for you are a Galilean, and your speech shows it."

71. Then he began to curse and swear, "I do not know this Man of whom you speak!"

72. A second time the rooster crowed. Then Peter called to mind the word that Jesus had said to him, "Before the rooster crows twice, you will deny Me three times." And when he thought about it, he wept.

## Chapter 15

1. Immediately, in the morning, the chief priests held a consultation with the elders and scribes and the whole council; and they bound Jesus, led Him away, and delivered Him to Pilate.

2. Then Pilate asked Him, "Are You the King of the Jews?" He answered and said to him, "It is as you say."

3. And the chief priests accused Him of many things, but He answered nothing.

4. Then Pilate asked Him again, saying, "Do You answer nothing? See how many things they testify against You!"

5. But Jesus still answered nothing, so that Pilate marveled.

6. Now at the feast he was accustomed to releasing one prisoner to them, whomever they requested.

7. And there was one named Barabbas, who was chained with his fellow rebels; they had committed murder in the rebellion.

8. Then the multitude, crying aloud, began to ask him to do just as he had always done for them.

9. But Pilate answered them, saying, "Do you want me to release to you the King of the Jews?"

10. For he knew that the chief priests had handed Him over because of envy.

11. But the chief priests stirred up the crowd, so that he should rather release Barabbas to them.

12. Pilate answered and said to them again, "What then do you want me to do with Him whom you call the King of the Jews?"

13. So they cried out again, "Crucify Him!"

14. Then Pilate said to them, "Why, what evil has He done?" But they cried out all the more, "Crucify Him!"

15. So Pilate, wanting to gratify the crowd, released Barabbas to them; and he delivered Jesus, after he had scourged Him, to be crucified.

16. Then the soldiers led Him away into the hall called Praetorium, and they called together the whole garrison.

17. And they clothed Him with purple; and they twisted a crown of thorns, put it on His head,

18. and began to salute Him, "Hail, King of the Jews!"

19. Then they struck Him on the head with a reed and spat on Him; and bowing the knee, they worshiped Him.

20. And when they had mocked Him, they took the purple off Him, put His own clothes on Him, and led Him out to crucify Him.

21. Then they compelled a certain man, Simon a Cyrenian, the father of Alexander and Rufus, as he was coming out of the country and passing by, to bear His cross.

22. And they brought Him to the place Golgotha, which is translated, Place of a Skull.

23. Then they gave Him wine mingled with myrrh to drink, but He did not take it.

24. And when they crucified Him, they divided His garments, casting lots for them to determine what every man should take.

25. Now it was the third hour, and they crucified Him.

26. And the inscription of His accusation was written above: THE KING OF THE JEWS.

27. With Him they also crucified two robbers, one on His right and the other on His left.

28. So the Scripture was fulfilled which says, "And He was numbered with the transgressors."

29. And those who passed by blasphemed Him, wagging their heads and saying, "Aha! You who destroy the temple and build it in three days,

30. save Yourself, and come down from the cross!"

31. Likewise the chief priests also, mocking among themselves with the scribes, said, "He saved others; Himself He cannot save.

32. Let the Christ, the King of Israel, descend now from the cross, that we may see and believe." Even those who were crucified with Him reviled Him.

33. Now when the sixth hour had come, there was darkness over the whole land until the ninth hour.

34. And at the ninth hour Jesus cried out with a loud voice, saying, "Eloi, Eloi, lama sabachthani?" which is translated, "My God, My God, why have You forsaken Me?"

35. Some of those who stood by, when they heard that, said, "Look, He is calling for Elijah!"

36. Then someone ran and filled a sponge full of sour wine, put it on a reed, and offered it to Him to drink, saying, "Let Him alone; let us see if Elijah will come to take Him down."

37. And Jesus cried out with a loud voice, and breathed His last.

38. Then the veil of the temple was torn in two from top to bottom.

39. So when the centurion, who stood opposite Him, saw that He cried out like this and breathed His last, he said, "Truly this Man was the Son of God!"

40. There were also women looking on from afar, among whom were Mary Magdalene, Mary the mother of James the Less and of Joses, and Salome,

41. who also followed Him and ministered to Him when He was in Galilee, and many other women who came up with Him to Jerusalem.

42. Now when evening had come, because it was the Preparation Day, that is, the day before the Sabbath,

43. Joseph of Arimathea, a prominent council member, who was himself waiting for the kingdom of God, coming and taking courage, went in to Pilate and asked for the body of Jesus.

44. Pilate marveled that He was already dead; and summoning the centurion, he asked him if He had been dead for some time.

45. So when he found out from the centurion, he granted the body to Joseph.

46. Then he bought fine linen, took Him down, and wrapped Him in the linen. And he laid Him in a tomb which had been hewn out of the rock, and rolled a stone against the door of the tomb.

47. And Mary Magdalene and Mary the mother of Joses observed where He was laid.

## Chapter 16

1. Now when the Sabbath was past, Mary Magdalene, Mary the mother of James, and Salome bought spices, that they might come and anoint Him.

2. Very early in the morning, on the first day of the week, they came to the tomb when the sun had risen.

3. And they said among themselves, "Who will roll away the stone from the door of the tomb for us?"

4. But when they looked up, they saw that the stone had been rolled away--for it was very large.

5. And entering the tomb, they saw a young man clothed in a long white robe sitting on the right side; and they were alarmed.

6. But he said to them, "Do not be alarmed. You seek Jesus of Nazareth, who was crucified. He is risen! He is not here. See the place where they laid Him.

7. But go, tell His disciples--and Peter--that He is going before you into Galilee; there you will see Him, as He said to you."

8. So they went out quickly and fled from the tomb, for they trembled and were amazed. And they said nothing to anyone, for they were afraid.

9. Now when He rose early on the first day of the week, He appeared first to Mary Magdalene, out of whom He had cast seven demons.

10. She went and told those who had been with Him, as they mourned and wept.

11. And when they heard that He was alive and had been seen by her, they did not believe.

12. After that, He appeared in another form to two of them as they walked and went into the country.

13. And they went and told it to the rest, but they did not believe them either.

14. Later He appeared to the eleven as they sat at the table; and He rebuked their unbelief and hardness of heart, because they did not believe those who had seen Him after He had risen.

15. And He said to them, "Go into all the world and preach the gospel to every creature.

16. He who believes and is baptized will be saved; but he who does not believe will be condemned.

17. And these signs will follow those who believe: In My name they will cast out demons; they will speak with new tongues;

18. they will take up serpents; and if they drink anything deadly, it will by no means hurt them; they will lay hands on the sick, and they will recover."

19. So then, after the Lord had spoken to them, He was received up into heaven, and sat down at the right hand of God.

20. And they went out and preached everywhere, the Lord working with them and confirming the word through the accompanying signs. Amen.


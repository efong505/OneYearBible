# matthew

## Chapter 1

1. The book of the genealogy of Jesus Christ, the Son of David, the Son of Abraham:

2. Abraham begot Isaac, Isaac begot Jacob, and Jacob begot Judah and his brothers.

3. Judah begot Perez and Zerah by Tamar, Perez begot Hezron, and Hezron begot Ram.

4. Ram begot Amminadab, Amminadab begot Nahshon, and Nahshon begot Salmon.

5. Salmon begot Boaz by Rahab, Boaz begot Obed by Ruth, Obed begot Jesse,

6. and Jesse begot David the king. David the king begot Solomon by her who had been the wife of Uriah.

7. Solomon begot Rehoboam, Rehoboam begot Abijah, and Abijah begot Asa.

8. Asa begot Jehoshaphat, Jehoshaphat begot Joram, and Joram begot Uzziah.

9. Uzziah begot Jotham, Jotham begot Ahaz, and Ahaz begot Hezekiah.

10. Hezekiah begot Manasseh, Manasseh begot Amon, and Amon begot Josiah.

11. Josiah begot Jeconiah and his brothers about the time they were carried away to Babylon.

12. And after they were brought to Babylon, Jeconiah begot Shealtiel, and Shealtiel begot Zerubbabel.

13. Zerubbabel begot Abiud, Abiud begot Eliakim, and Eliakim begot Azor.

14. Azor begot Zadok, Zadok begot Achim, and Achim begot Eliud.

15. Eliud begot Eleazar, Eleazar begot Matthan, and Matthan begot Jacob.

16. And Jacob begot Joseph the husband of Mary, of whom was born Jesus who is called Christ.

17. So all the generations from Abraham to David are fourteen generations, from David until the captivity in Babylon are fourteen generations, and from the captivity in Babylon until the Christ are fourteen generations.

18. Now the birth of Jesus Christ was as follows: After His mother Mary was betrothed to Joseph, before they came together, she was found with child of the Holy Spirit.

19. Then Joseph her husband, being a just man, and not wanting to make her a public example, was minded to put her away secretly.

20. But while he thought about these things, behold, an angel of the Lord appeared to him in a dream, saying, "Joseph, son of David, do not be afraid to take to you Mary your wife, for that which is conceived in her is of the Holy Spirit.

21. And she will bring forth a Son, and you shall call His name JESUS, for He will save His people from their sins."

22. So all this was done that it might be fulfilled which was spoken by the Lord through the prophet, saying:

23. "Behold, the virgin shall be with child, and bear a Son, and they shall call His name Immanuel," which is translated, "God with us."

24. Then Joseph, being aroused from sleep, did as the angel of the Lord commanded him and took to him his wife,

25. and did not know her till she had brought forth her firstborn Son. And he called His name JESUS.

## Chapter 2

1. Now after Jesus was born in Bethlehem of Judea in the days of Herod the king, behold, wise men from the East came to Jerusalem,

2. saying, "Where is He who has been born King of the Jews? For we have seen His star in the East and have come to worship Him."

3. When Herod the king heard this, he was troubled, and all Jerusalem with him.

4. And when he had gathered all the chief priests and scribes of the people together, he inquired of them where the Christ was to be born.

5. So they said to him, "In Bethlehem of Judea, for thus it is written by the prophet:

6. "But you, Bethlehem, in the land of Judah, Are not the least among the rulers of Judah; For out of you shall come a Ruler Who will shepherd My people Israel."'

7. Then Herod, when he had secretly called the wise men, determined from them what time the star appeared.

8. And he sent them to Bethlehem and said, "Go and search carefully for the young Child, and when you have found Him, bring back word to me, that I may come and worship Him also."

9. When they heard the king, they departed; and behold, the star which they had seen in the East went before them, till it came and stood over where the young Child was.

10. When they saw the star, they rejoiced with exceedingly great joy.

11. And when they had come into the house, they saw the young Child with Mary His mother, and fell down and worshiped Him. And when they had opened their treasures, they presented gifts to Him: gold, frankincense, and myrrh.

12. Then, being divinely warned in a dream that they should not return to Herod, they departed for their own country another way.

13. Now when they had departed, behold, an angel of the Lord appeared to Joseph in a dream, saying, "Arise, take the young Child and His mother, flee to Egypt, and stay there until I bring you word; for Herod will seek the young Child to destroy Him."

14. When he arose, he took the young Child and His mother by night and departed for Egypt,

15. and was there until the death of Herod, that it might be fulfilled which was spoken by the Lord through the prophet, saying, "Out of Egypt I called My Son."

16. Then Herod, when he saw that he was deceived by the wise men, was exceedingly angry; and he sent forth and put to death all the male children who were in Bethlehem and in all its districts, from two years old and under, according to the time which he had determined from the wise men.

17. Then was fulfilled what was spoken by Jeremiah the prophet, saying:

18. "A voice was heard in Ramah, Lamentation, weeping, and great mourning, Rachel weeping for her children, Refusing to be comforted, Because they are no more."

19. Now when Herod was dead, behold, an angel of the Lord appeared in a dream to Joseph in Egypt,

20. saying, "Arise, take the young Child and His mother, and go to the land of Israel, for those who sought the young Child's life are dead."

21. Then he arose, took the young Child and His mother, and came into the land of Israel.

22. But when he heard that Archelaus was reigning over Judea instead of his father Herod, he was afraid to go there. And being warned by God in a dream, he turned aside into the region of Galilee.

23. And he came and dwelt in a city called Nazareth, that it might be fulfilled which was spoken by the prophets, "He shall be called a Nazarene."

## Chapter 3

1. In those days John the Baptist came preaching in the wilderness of Judea,

2. and saying, "Repent, for the kingdom of heaven is at hand!"

3. For this is he who was spoken of by the prophet Isaiah, saying: "The voice of one crying in the wilderness: "Prepare the way of the LORD; Make His paths straight."'

4. Now John himself was clothed in camel's hair, with a leather belt around his waist; and his food was locusts and wild honey.

5. Then Jerusalem, all Judea, and all the region around the Jordan went out to him

6. and were baptized by him in the Jordan, confessing their sins.

7. But when he saw many of the Pharisees and Sadducees coming to his baptism, he said to them, "Brood of vipers! Who warned you to flee from the wrath to come?

8. Therefore bear fruits worthy of repentance,

9. and do not think to say to yourselves, "We have Abraham as our father.' For I say to you that God is able to raise up children to Abraham from these stones.

10. And even now the ax is laid to the root of the trees. Therefore every tree which does not bear good fruit is cut down and thrown into the fire.

11. I indeed baptize you with water unto repentance, but He who is coming after me is mightier than I, whose sandals I am not worthy to carry. He will baptize you with the Holy Spirit and fire.

12. His winnowing fan is in His hand, and He will thoroughly clean out His threshing floor, and gather His wheat into the barn; but He will burn up the chaff with unquenchable fire."

13. Then Jesus came from Galilee to John at the Jordan to be baptized by him.

14. And John tried to prevent Him, saying, "I need to be baptized by You, and are You coming to me?"

15. But Jesus answered and said to him, "Permit it to be so now, for thus it is fitting for us to fulfill all righteousness." Then he allowed Him.

16. When He had been baptized, Jesus came up immediately from the water; and behold, the heavens were opened to Him, and He saw the Spirit of God descending like a dove and alighting upon Him.

17. And suddenly a voice came from heaven, saying, "This is My beloved Son, in whom I am well pleased."

## Chapter 4

1. Then Jesus was led up by the Spirit into the wilderness to be tempted by the devil.

2. And when He had fasted forty days and forty nights, afterward He was hungry.

3. Now when the tempter came to Him, he said, "If You are the Son of God, command that these stones become bread."

4. But He answered and said, "It is written, "Man shall not live by bread alone, but by every word that proceeds from the mouth of God."'

5. Then the devil took Him up into the holy city, set Him on the pinnacle of the temple,

6. and said to Him, "If You are the Son of God, throw Yourself down. For it is written: "He shall give His angels charge over you,' and, "In their hands they shall bear you up, Lest you dash your foot against a stone."'

7. Jesus said to him, "It is written again, "You shall not tempt the LORD your God."'

8. Again, the devil took Him up on an exceedingly high mountain, and showed Him all the kingdoms of the world and their glory.

9. And he said to Him, "All these things I will give You if You will fall down and worship me."

10. Then Jesus said to him, "Away with you, Satan! For it is written, "You shall worship the LORD your God, and Him only you shall serve."'

11. Then the devil left Him, and behold, angels came and ministered to Him.

12. Now when Jesus heard that John had been put in prison, He departed to Galilee.

13. And leaving Nazareth, He came and dwelt in Capernaum, which is by the sea, in the regions of Zebulun and Naphtali,

14. that it might be fulfilled which was spoken by Isaiah the prophet, saying:

15. "The land of Zebulun and the land of Naphtali, By the way of the sea, beyond the Jordan, Galilee of the Gentiles:

16. The people who sat in darkness have seen a great light, And upon those who sat in the region and shadow of death Light has dawned."

17. From that time Jesus began to preach and to say, "Repent, for the kingdom of heaven is at hand."

18. And Jesus, walking by the Sea of Galilee, saw two brothers, Simon called Peter, and Andrew his brother, casting a net into the sea; for they were fishermen.

19. Then He said to them, "Follow Me, and I will make you fishers of men." rm820They immediately left their nets and followed Him.

21. Going on from there, He saw two other brothers, James the son of Zebedee, and John his brother, in the boat with Zebedee their father, mending their nets. He called them,

22. and immediately they left the boat and their father, and followed Him.

23. And Jesus went about all Galilee, teaching in their synagogues, preaching the gospel of the kingdom, and healing all kinds of sickness and all kinds of disease among the people.

24. Then His fame went throughout all Syria; and they brought to Him all sick people who were afflicted with various diseases and torments, and those who were demon-possessed, epileptics, and paralytics; and He healed them.

25. Great multitudes followed Him--from Galilee, and from Decapolis, Jerusalem, Judea, and beyond the Jordan.

## Chapter 5

1. And seeing the multitudes, He went up on a mountain, and when He was seated His disciples came to Him.

2. Then He opened His mouth and taught them, saying:

3. "Blessed are the poor in spirit, For theirs is the kingdom of heaven.

4. Blessed are those who mourn, For they shall be comforted.

5. Blessed are the meek, For they shall inherit the earth.

6. Blessed are those who hunger and thirst for righteousness, For they shall be filled.

7. Blessed are the merciful, For they shall obtain mercy.

8. Blessed are the pure in heart, For they shall see God.

9. Blessed are the peacemakers, For they shall be called sons of God.

10. Blessed are those who are persecuted for righteousness' sake, For theirs is the kingdom of heaven.

11. "Blessed are you when they revile and persecute you, and say all kinds of evil against you falsely for My sake.

12. Rejoice and be exceedingly glad, for great is your reward in heaven, for so they persecuted the prophets who were before you.

13. "You are the salt of the earth; but if the salt loses its flavor, how shall it be seasoned? It is then good for nothing but to be thrown out and trampled underfoot by men.

14. "You are the light of the world. A city that is set on a hill cannot be hidden.

15. Nor do they light a lamp and put it under a basket, but on a lampstand, and it gives light to all who are in the house.

16. Let your light so shine before men, that they may see your good works and glorify your Father in heaven.

17. "Do not think that I came to destroy the Law or the Prophets. I did not come to destroy but to fulfill.

18. For assuredly, I say to you, till heaven and earth pass away, one jot or one tittle will by no means pass from the law till all is fulfilled.

19. Whoever therefore breaks one of the least of these commandments, and teaches men so, shall be called least in the kingdom of heaven; but whoever does and teaches them, he shall be called great in the kingdom of heaven.

20. For I say to you, that unless your righteousness exceeds the righteousness of the scribes and Pharisees, you will by no means enter the kingdom of heaven.

21. "You have heard that it was said to those of old, "You shall not murder, and whoever murders will be in danger of the judgment.'

22. But I say to you that whoever is angry with his brother without a cause shall be in danger of the judgment. And whoever says to his brother, "Raca!' shall be in danger of the council. But whoever says, "You fool!' shall be in danger of hell fire.

23. Therefore if you bring your gift to the altar, and there remember that your brother has something against you,

24. leave your gift there before the altar, and go your way. First be reconciled to your brother, and then come and offer your gift.

25. Agree with your adversary quickly, while you are on the way with him, lest your adversary deliver you to the judge, the judge hand you over to the officer, and you be thrown into prison.

26. Assuredly, I say to you, you will by no means get out of there till you have paid the last penny.

27. "You have heard that it was said to those of old, "You shall not commit adultery.'

28. But I say to you that whoever looks at a woman to lust for her has already committed adultery with her in his heart.

29. If your right eye causes you to sin, pluck it out and cast it from you; for it is more profitable for you that one of your members perish, than for your whole body to be cast into hell.

30. And if your right hand causes you to sin, cut it off and cast it from you; for it is more profitable for you that one of your members perish, than for your whole body to be cast into hell.

31. "Furthermore it has been said, "Whoever divorces his wife, let him give her a certificate of divorce.'

32. But I say to you that whoever divorces his wife for any reason except sexual immorality causes her to commit adultery; and whoever marries a woman who is divorced commits adultery.

33. "Again you have heard that it was said to those of old, "You shall not swear falsely, but shall perform your oaths to the Lord.'

34. But I say to you, do not swear at all: neither by heaven, for it is God's throne;

35. nor by the earth, for it is His footstool; nor by Jerusalem, for it is the city of the great King.

36. Nor shall you swear by your head, because you cannot make one hair white or black.

37. But let your "Yes' be "Yes,' and your "No,' "No.' For whatever is more than these is from the evil one.

38. "You have heard that it was said, "An eye for an eye and a tooth for a tooth.'

39. But I tell you not to resist an evil person. But whoever slaps you on your right cheek, turn the other to him also.

40. If anyone wants to sue you and take away your tunic, let him have your cloak also.

41. And whoever compels you to go one mile, go with him two.

42. Give to him who asks you, and from him who wants to borrow from you do not turn away.

43. "You have heard that it was said, "You shall love your neighbor and hate your enemy.'

44. But I say to you, love your enemies, bless those who curse you, do good to those who hate you, and pray for those who spitefully use you and persecute you,

45. that you may be sons of your Father in heaven; for He makes His sun rise on the evil and on the good, and sends rain on the just and on the unjust.

46. For if you love those who love you, what reward have you? Do not even the tax collectors do the same?

47. And if you greet your brethren only, what do you do more than others? Do not even the tax collectors do so?

48. Therefore you shall be perfect, just as your Father in heaven is perfect.

## Chapter 6

1. "Take heed that you do not do your charitable deeds before men, to be seen by them. Otherwise you have no reward from your Father in heaven.

2. Therefore, when you do a charitable deed, do not sound a trumpet before you as the hypocrites do in the synagogues and in the streets, that they may have glory from men. Assuredly, I say to you, they have their reward.

3. But when you do a charitable deed, do not let your left hand know what your right hand is doing,

4. that your charitable deed may be in secret; and your Father who sees in secret will Himself reward you openly.

5. "And when you pray, you shall not be like the hypocrites. For they love to pray standing in the synagogues and on the corners of the streets, that they may be seen by men. Assuredly, I say to you, they have their reward.

6. But you, when you pray, go into your room, and when you have shut your door, pray to your Father who is in the secret place; and your Father who sees in secret will reward you openly.

7. And when you pray, do not use vain repetitions as the heathen do. For they think that they will be heard for their many words.

8. "Therefore do not be like them. For your Father knows the things you have need of before you ask Him.

9. In this manner, therefore, pray: Our Father in heaven, Hallowed be Your name.

10. Your kingdom come. Your will be done On earth as it is in heaven.

11. Give us this day our daily bread.

12. And forgive us our debts, As we forgive our debtors.

13. And do not lead us into temptation, But deliver us from the evil one. For Yours is the kingdom and the power and the glory forever. Amen.

14. "For if you forgive men their trespasses, your heavenly Father will also forgive you.

15. But if you do not forgive men their trespasses, neither will your Father forgive your trespasses.

16. "Moreover, when you fast, do not be like the hypocrites, with a sad countenance. For they disfigure their faces that they may appear to men to be fasting. Assuredly, I say to you, they have their reward.

17. But you, when you fast, anoint your head and wash your face,

18. so that you do not appear to men to be fasting, but to your Father who is in the secret place; and your Father who sees in secret will reward you openly.

19. "Do not lay up for yourselves treasures on earth, where moth and rust destroy and where thieves break in and steal;

20. but lay up for yourselves treasures in heaven, where neither moth nor rust destroys and where thieves do not break in and steal.

21. For where your treasure is, there your heart will be also.

22. "The lamp of the body is the eye. If therefore your eye is good, your whole body will be full of light.

23. But if your eye is bad, your whole body will be full of darkness. If therefore the light that is in you is darkness, how great is that darkness!

24. "No one can serve two masters; for either he will hate the one and love the other, or else he will be loyal to the one and despise the other. You cannot serve God and mammon.

25. "Therefore I say to you, do not worry about your life, what you will eat or what you will drink; nor about your body, what you will put on. Is not life more than food and the body more than clothing?

26. Look at the birds of the air, for they neither sow nor reap nor gather into barns; yet your heavenly Father feeds them. Are you not of more value than they?

27. Which of you by worrying can add one cubit to his stature?

28. "So why do you worry about clothing? Consider the lilies of the field, how they grow: they neither toil nor spin;

29. and yet I say to you that even Solomon in all his glory was not arrayed like one of these.

30. Now if God so clothes the grass of the field, which today is, and tomorrow is thrown into the oven, will He not much more clothe you, O you of little faith?

31. "Therefore do not worry, saying, "What shall we eat?' or "What shall we drink?' or "What shall we wear?'

32. For after all these things the Gentiles seek. For your heavenly Father knows that you need all these things.

33. But seek first the kingdom of God and His righteousness, and all these things shall be added to you.

34. Therefore do not worry about tomorrow, for tomorrow will worry about its own things. Sufficient for the day is its own trouble.

## Chapter 7

1. "Judge not, that you be not judged.

2. For with what judgment you judge, you will be judged; and with the measure you use, it will be measured back to you.

3. And why do you look at the speck in your brother's eye, but do not consider the plank in your own eye?

4. Or how can you say to your brother, "Let me remove the speck from your eye'; and look, a plank is in your own eye?

5. Hypocrite! First remove the plank from your own eye, and then you will see clearly to remove the speck from your brother's eye.

6. "Do not give what is holy to the dogs; nor cast your pearls before swine, lest they trample them under their feet, and turn and tear you in pieces.

7. "Ask, and it will be given to you; seek, and you will find; knock, and it will be opened to you.

8. For everyone who asks receives, and he who seeks finds, and to him who knocks it will be opened.

9. Or what man is there among you who, if his son asks for bread, will give him a stone?

10. Or if he asks for a fish, will he give him a serpent?

11. If you then, being evil, know how to give good gifts to your children, how much more will your Father who is in heaven give good things to those who ask Him!

12. Therefore, whatever you want men to do to you, do also to them, for this is the Law and the Prophets.

13. "Enter by the narrow gate; for wide is the gate and broad is the way that leads to destruction, and there are many who go in by it.

14. Because narrow is the gate and difficult is the way which leads to life, and there are few who find it.

15. "Beware of false prophets, who come to you in sheep's clothing, but inwardly they are ravenous wolves.

16. You will know them by their fruits. Do men gather grapes from thornbushes or figs from thistles?

17. Even so, every good tree bears good fruit, but a bad tree bears bad fruit.

18. A good tree cannot bear bad fruit, nor can a bad tree bear good fruit.

19. Every tree that does not bear good fruit is cut down and thrown into the fire.

20. Therefore by their fruits you will know them.

21. "Not everyone who says to Me, "Lord, Lord,' shall enter the kingdom of heaven, but he who does the will of My Father in heaven.

22. Many will say to Me in that day, "Lord, Lord, have we not prophesied in Your name, cast out demons in Your name, and done many wonders in Your name?'

23. And then I will declare to them, "I never knew you; depart from Me, you who practice lawlessness!'

24. "Therefore whoever hears these sayings of Mine, and does them, I will liken him to a wise man who built his house on the rock:

25. and the rain descended, the floods came, and the winds blew and beat on that house; and it did not fall, for it was founded on the rock.

26. "But everyone who hears these sayings of Mine, and does not do them, will be like a foolish man who built his house on the sand:

27. and the rain descended, the floods came, and the winds blew and beat on that house; and it fell. And great was its fall."

28. And so it was, when Jesus had ended these sayings, that the people were astonished at His teaching,

29. for He taught them as one having authority, and not as the scribes.

## Chapter 8

1. When He had come down from the mountain, great multitudes followed Him.

2. And behold, a leper came and worshiped Him, saying, "Lord, if You are willing, You can make me clean."

3. Then Jesus put out His hand and touched him, saying, "I am willing; be cleansed." Immediately his leprosy was cleansed.

4. And Jesus said to him, "See that you tell no one; but go your way, show yourself to the priest, and offer the gift that Moses commanded, as a testimony to them."

5. Now when Jesus had entered Capernaum, a centurion came to Him, pleading with Him,

6. saying, "Lord, my servant is lying at home paralyzed, dreadfully tormented."

7. And Jesus said to him, "I will come and heal him."

8. The centurion answered and said, "Lord, I am not worthy that You should come under my roof. But only speak a word, and my servant will be healed.

9. For I also am a man under authority, having soldiers under me. And I say to this one, "Go,' and he goes; and to another, "Come,' and he comes; and to my servant, "Do this,' and he does it."

10. When Jesus heard it, He marveled, and said to those who followed, "Assuredly, I say to you, I have not found such great faith, not even in Israel!

11. And I say to you that many will come from east and west, and sit down with Abraham, Isaac, and Jacob in the kingdom of heaven.

12. But the sons of the kingdom will be cast out into outer darkness. There will be weeping and gnashing of teeth."

13. Then Jesus said to the centurion, "Go your way; and as you have believed, so let it be done for you." And his servant was healed that same hour.

14. Now when Jesus had come into Peter's house, He saw his wife's mother lying sick with a fever.

15. So He touched her hand, and the fever left her. And she arose and served them.

16. When evening had come, they brought to Him many who were demon-possessed. And He cast out the spirits with a word, and healed all who were sick,

17. that it might be fulfilled which was spoken by Isaiah the prophet, saying: "He Himself took our infirmities And bore our sicknesses."

18. And when Jesus saw great multitudes about Him, He gave a command to depart to the other side.

19. Then a certain scribe came and said to Him, "Teacher, I will follow You wherever You go."

20. And Jesus said to him, "Foxes have holes and birds of the air have nests, but the Son of Man has nowhere to lay His head."

21. Then another of His disciples said to Him, "Lord, let me first go and bury my father."

22. But Jesus said to him, "Follow Me, and let the dead bury their own dead."

23. Now when He got into a boat, His disciples followed Him.

24. And suddenly a great tempest arose on the sea, so that the boat was covered with the waves. But He was asleep.

25. Then His disciples came to Him and awoke Him, saying, "Lord, save us! We are perishing!"

26. But He said to them, "Why are you fearful, O you of little faith?" Then He arose and rebuked the winds and the sea, and there was a great calm.

27. So the men marveled, saying, "Who can this be, that even the winds and the sea obey Him?"

28. When He had come to the other side, to the country of the Gergesenes, there met Him two demon-possessed men, coming out of the tombs, exceedingly fierce, so that no one could pass that way.

29. And suddenly they cried out, saying, "What have we to do with You, Jesus, You Son of God? Have You come here to torment us before the time?"

30. Now a good way off from them there was a herd of many swine feeding.

31. So the demons begged Him, saying, "If You cast us out, permit us to go away into the herd of swine."

32. And He said to them, "Go." So when they had come out, they went into the herd of swine. And suddenly the whole herd of swine ran violently down the steep place into the sea, and perished in the water.

33. Then those who kept them fled; and they went away into the city and told everything, including what had happened to the demon-possessed men.

34. And behold, the whole city came out to meet Jesus. And when they saw Him, they begged Him to depart from their region.

## Chapter 9

1. So He got into a boat, crossed over, and came to His own city.

2. Then behold, they brought to Him a paralytic lying on a bed. When Jesus saw their faith, He said to the paralytic, "Son, be of good cheer; your sins are forgiven you."

3. And at once some of the scribes said within themselves, "This Man blasphemes!"

4. But Jesus, knowing their thoughts, said, "Why do you think evil in your hearts?

5. For which is easier, to say, "Your sins are forgiven you,' or to say, "Arise and walk'?

6. But that you may know that the Son of Man has power on earth to forgive sins"--then He said to the paralytic, "Arise, take up your bed, and go to your house."

7. And he arose and departed to his house.

8. Now when the multitudes saw it, they marveled and glorified God, who had given such power to men.

9. As Jesus passed on from there, He saw a man named Matthew sitting at the tax office. And He said to him, "Follow Me." So he arose and followed Him.

10. Now it happened, as Jesus sat at the table in the house, that behold, many tax collectors and sinners came and sat down with Him and His disciples.

11. And when the Pharisees saw it, they said to His disciples, "Why does your Teacher eat with tax collectors and sinners?"

12. When Jesus heard that, He said to them, "Those who are well have no need of a physician, but those who are sick.

13. But go and learn what this means: "I desire mercy and not sacrifice.' For I did not come to call the righteous, but sinners, to repentance."

14. Then the disciples of John came to Him, saying, "Why do we and the Pharisees fast often, but Your disciples do not fast?"

15. And Jesus said to them, "Can the friends of the bridegroom mourn as long as the bridegroom is with them? But the days will come when the bridegroom will be taken away from them, and then they will fast.

16. No one puts a piece of unshrunk cloth on an old garment; for the patch pulls away from the garment, and the tear is made worse.

17. Nor do they put new wine into old wineskins, or else the wineskins break, the wine is spilled, and the wineskins are ruined. But they put new wine into new wineskins, and both are preserved."

18. While He spoke these things to them, behold, a ruler came and worshiped Him, saying, "My daughter has just died, but come and lay Your hand on her and she will live."

19. So Jesus arose and followed him, and so did His disciples.

20. And suddenly, a woman who had a flow of blood for twelve years came from behind and touched the hem of His garment.

21. For she said to herself, "If only I may touch His garment, I shall be made well."

22. But Jesus turned around, and when He saw her He said, "Be of good cheer, daughter; your faith has made you well." And the woman was made well from that hour.

23. When Jesus came into the ruler's house, and saw the flute players and the noisy crowd wailing,

24. He said to them, "Make room, for the girl is not dead, but sleeping." And they ridiculed Him.

25. But when the crowd was put outside, He went in and took her by the hand, and the girl arose.

26. And the report of this went out into all that land.

27. When Jesus departed from there, two blind men followed Him, crying out and saying, "Son of David, have mercy on us!"

28. And when He had come into the house, the blind men came to Him. And Jesus said to them, "Do you believe that I am able to do this?" They said to Him, "Yes, Lord."

29. Then He touched their eyes, saying, "According to your faith let it be to you."

30. And their eyes were opened. And Jesus sternly warned them, saying, "See that no one knows it."

31. But when they had departed, they spread the news about Him in all that country.

32. As they went out, behold, they brought to Him a man, mute and demon-possessed.

33. And when the demon was cast out, the mute spoke. And the multitudes marveled, saying, "It was never seen like this in Israel!"

34. But the Pharisees said, "He casts out demons by the ruler of the demons."

35. Then Jesus went about all the cities and villages, teaching in their synagogues, preaching the gospel of the kingdom, and healing every sickness and every disease among the people.

36. But when He saw the multitudes, He was moved with compassion for them, because they were weary and scattered, like sheep having no shepherd.

37. Then He said to His disciples, "The harvest truly is plentiful, but the laborers are few.

38. Therefore pray the Lord of the harvest to send out laborers into His harvest."

## Chapter 10

1. And when He had called His twelve disciples to Him, He gave them power over unclean spirits, to cast them out, and to heal all kinds of sickness and all kinds of disease.

2. Now the names of the twelve apostles are these: first, Simon, who is called Peter, and Andrew his brother; James the son of Zebedee, and John his brother;

3. Philip and Bartholomew; Thomas and Matthew the tax collector; James the son of Alphaeus, and Lebbaeus, whose surname was Thaddaeus;

4. Simon the Cananite, and Judas Iscariot, who also betrayed Him.

5. These twelve Jesus sent out and commanded them, saying: "Do not go into the way of the Gentiles, and do not enter a city of the Samaritans.

6. But go rather to the lost sheep of the house of Israel.

7. And as you go, preach, saying, "The kingdom of heaven is at hand.'

8. Heal the sick, cleanse the lepers, raise the dead, cast out demons. Freely you have received, freely give.

9. Provide neither gold nor silver nor copper in your money belts,

10. nor bag for your journey, nor two tunics, nor sandals, nor staffs; for a worker is worthy of his food.

11. "Now whatever city or town you enter, inquire who in it is worthy, and stay there till you go out.

12. And when you go into a household, greet it.

13. If the household is worthy, let your peace come upon it. But if it is not worthy, let your peace return to you.

14. And whoever will not receive you nor hear your words, when you depart from that house or city, shake off the dust from your feet.

15. Assuredly, I say to you, it will be more tolerable for the land of Sodom and Gomorrah in the day of judgment than for that city!

16. "Behold, I send you out as sheep in the midst of wolves. Therefore be wise as serpents and harmless as doves.

17. But beware of men, for they will deliver you up to councils and scourge you in their synagogues.

18. You will be brought before governors and kings for My sake, as a testimony to them and to the Gentiles.

19. But when they deliver you up, do not worry about how or what you should speak. For it will be given to you in that hour what you should speak;

20. for it is not you who speak, but the Spirit of your Father who speaks in you.

21. "Now brother will deliver up brother to death, and a father his child; and children will rise up against parents and cause them to be put to death.

22. And you will be hated by all for My name's sake. But he who endures to the end will be saved.

23. When they persecute you in this city, flee to another. For assuredly, I say to you, you will not have gone through the cities of Israel before the Son of Man comes.

24. "A disciple is not above his teacher, nor a servant above his master.

25. It is enough for a disciple that he be like his teacher, and a servant like his master. If they have called the master of the house Beelzebub, how much more will they call those of his household!

26. Therefore do not fear them. For there is nothing covered that will not be revealed, and hidden that will not be known.

27. "Whatever I tell you in the dark, speak in the light; and what you hear in the ear, preach on the housetops.

28. And do not fear those who kill the body but cannot kill the soul. But rather fear Him who is able to destroy both soul and body in hell.

29. Are not two sparrows sold for a copper coin? And not one of them falls to the ground apart from your Father's will.

30. But the very hairs of your head are all numbered.

31. Do not fear therefore; you are of more value than many sparrows.

32. "Therefore whoever confesses Me before men, him I will also confess before My Father who is in heaven.

33. But whoever denies Me before men, him I will also deny before My Father who is in heaven.

34. "Do not think that I came to bring peace on earth. I did not come to bring peace but a sword.

35. For I have come to "set a man against his father, a daughter against her mother, and a daughter-in-law against her mother-in-law';

36. and "a man's enemies will be those of his own household.'

37. He who loves father or mother more than Me is not worthy of Me. And he who loves son or daughter more than Me is not worthy of Me.

38. And he who does not take his cross and follow after Me is not worthy of Me.

39. He who finds his life will lose it, and he who loses his life for My sake will find it.

40. "He who receives you receives Me, and he who receives Me receives Him who sent Me.

41. He who receives a prophet in the name of a prophet shall receive a prophet's reward. And he who receives a righteous man in the name of a righteous man shall receive a righteous man's reward.

42. And whoever gives one of these little ones only a cup of cold water in the name of a disciple, assuredly, I say to you, he shall by no means lose his reward."

## Chapter 11

1. Now it came to pass, when Jesus finished commanding His twelve disciples, that He departed from there to teach and to preach in their cities.

2. And when John had heard in prison about the works of Christ, he sent two of his disciples

3. and said to Him, "Are You the Coming One, or do we look for another?"

4. Jesus answered and said to them, "Go and tell John the things which you hear and see:

5. The blind see and the lame walk; the lepers are cleansed and the deaf hear; the dead are raised up and the poor have the gospel preached to them.

6. And blessed is he who is not offended because of Me."

7. As they departed, Jesus began to say to the multitudes concerning John: "What did you go out into the wilderness to see? A reed shaken by the wind?

8. But what did you go out to see? A man clothed in soft garments? Indeed, those who wear soft clothing are in kings' houses.

9. But what did you go out to see? A prophet? Yes, I say to you, and more than a prophet.

10. For this is he of whom it is written: "Behold, I send My messenger before Your face, Who will prepare Your way before You.'

11. "Assuredly, I say to you, among those born of women there has not risen one greater than John the Baptist; but he who is least in the kingdom of heaven is greater than he.

12. And from the days of John the Baptist until now the kingdom of heaven suffers violence, and the violent take it by force.

13. For all the prophets and the law prophesied until John.

14. And if you are willing to receive it, he is Elijah who is to come.

15. He who has ears to hear, let him hear!

16. "But to what shall I liken this generation? It is like children sitting in the marketplaces and calling to their companions,

17. and saying: "We played the flute for you, And you did not dance; We mourned to you, And you did not lament.'

18. For John came neither eating nor drinking, and they say, "He has a demon.'

19. The Son of Man came eating and drinking, and they say, "Look, a glutton and a winebibber, a friend of tax collectors and sinners!' But wisdom is justified by her children."

20. Then He began to rebuke the cities in which most of His mighty works had been done, because they did not repent:

21. "Woe to you, Chorazin! Woe to you, Bethsaida! For if the mighty works which were done in you had been done in Tyre and Sidon, they would have repented long ago in sackcloth and ashes.

22. But I say to you, it will be more tolerable for Tyre and Sidon in the day of judgment than for you.

23. And you, Capernaum, who are exalted to heaven, will be brought down to Hades; for if the mighty works which were done in you had been done in Sodom, it would have remained until this day.

24. But I say to you that it shall be more tolerable for the land of Sodom in the day of judgment than for you."

25. At that time Jesus answered and said, "I thank You, Father, Lord of heaven and earth, that You have hidden these things from the wise and prudent and have revealed them to babes.

26. Even so, Father, for so it seemed good in Your sight.

27. All things have been delivered to Me by My Father, and no one knows the Son except the Father. Nor does anyone know the Father except the Son, and the one to whom the Son wills to reveal Him.

28. Come to Me, all you who labor and are heavy laden, and I will give you rest.

29. Take My yoke upon you and learn from Me, for I am gentle and lowly in heart, and you will find rest for your souls.

30. For My yoke is easy and My burden is light."

## Chapter 12

1. At that time Jesus went through the grainfields on the Sabbath. And His disciples were hungry, and began to pluck heads of grain and to eat.

2. And when the Pharisees saw it, they said to Him, "Look, Your disciples are doing what is not lawful to do on the Sabbath!"

3. But He said to them, "Have you not read what David did when he was hungry, he and those who were with him:

4. how he entered the house of God and ate the showbread which was not lawful for him to eat, nor for those who were with him, but only for the priests?

5. Or have you not read in the law that on the Sabbath the priests in the temple profane the Sabbath, and are blameless?

6. Yet I say to you that in this place there is One greater than the temple.

7. But if you had known what this means, "I desire mercy and not sacrifice,' you would not have condemned the guiltless.

8. For the Son of Man is Lord even of the Sabbath."

9. Now when He had departed from there, He went into their synagogue.

10. And behold, there was a man who had a withered hand. And they asked Him, saying, "Is it lawful to heal on the Sabbath?"--that they might accuse Him.

11. Then He said to them, "What man is there among you who has one sheep, and if it falls into a pit on the Sabbath, will not lay hold of it and lift it out?

12. Of how much more value then is a man than a sheep? Therefore it is lawful to do good on the Sabbath."

13. Then He said to the man, "Stretch out your hand." And he stretched it out, and it was restored as whole as the other.

14. Then the Pharisees went out and plotted against Him, how they might destroy Him.

15. But when Jesus knew it, He withdrew from there. And great multitudes followed Him, and He healed them all.

16. Yet He warned them not to make Him known,

17. that it might be fulfilled which was spoken by Isaiah the prophet, saying:

18. "Behold! My Servant whom I have chosen, My Beloved in whom My soul is well pleased! I will put My Spirit upon Him, And He will declare justice to the Gentiles.

19. He will not quarrel nor cry out, Nor will anyone hear His voice in the streets.

20. A bruised reed He will not break, And smoking flax He will not quench, Till He sends forth justice to victory;

21. And in His name Gentiles will trust."

22. Then one was brought to Him who was demon-possessed, blind and mute; and He healed him, so that the blind and mute man both spoke and saw.

23. And all the multitudes were amazed and said, "Could this be the Son of David?"

24. Now when the Pharisees heard it they said, "This fellow does not cast out demons except by Beelzebub, the ruler of the demons."

25. But Jesus knew their thoughts, and said to them: "Every kingdom divided against itself is brought to desolation, and every city or house divided against itself will not stand.

26. If Satan casts out Satan, he is divided against himself. How then will his kingdom stand?

27. And if I cast out demons by Beelzebub, by whom do your sons cast them out? Therefore they shall be your judges.

28. But if I cast out demons by the Spirit of God, surely the kingdom of God has come upon you.

29. Or how can one enter a strong man's house and plunder his goods, unless he first binds the strong man? And then he will plunder his house.

30. He who is not with Me is against Me, and he who does not gather with Me scatters abroad.

31. "Therefore I say to you, every sin and blasphemy will be forgiven men, but the blasphemy against the Spirit will not be forgiven men.

32. Anyone who speaks a word against the Son of Man, it will be forgiven him; but whoever speaks against the Holy Spirit, it will not be forgiven him, either in this age or in the age to come.

33. "Either make the tree good and its fruit good, or else make the tree bad and its fruit bad; for a tree is known by its fruit.

34. Brood of vipers! How can you, being evil, speak good things? For out of the abundance of the heart the mouth speaks.

35. A good man out of the good treasure of his heart brings forth good things, and an evil man out of the evil treasure brings forth evil things.

36. But I say to you that for every idle word men may speak, they will give account of it in the day of judgment.

37. For by your words you will be justified, and by your words you will be condemned."

38. Then some of the scribes and Pharisees answered, saying, "Teacher, we want to see a sign from You."

39. But He answered and said to them, "An evil and adulterous generation seeks after a sign, and no sign will be given to it except the sign of the prophet Jonah.

40. For as Jonah was three days and three nights in the belly of the great fish, so will the Son of Man be three days and three nights in the heart of the earth.

41. The men of Nineveh will rise up in the judgment with this generation and condemn it, because they repented at the preaching of Jonah; and indeed a greater than Jonah is here.

42. The queen of the South will rise up in the judgment with this generation and condemn it, for she came from the ends of the earth to hear the wisdom of Solomon; and indeed a greater than Solomon is here.

43. "When an unclean spirit goes out of a man, he goes through dry places, seeking rest, and finds none.

44. Then he says, "I will return to my house from which I came.' And when he comes, he finds it empty, swept, and put in order.

45. Then he goes and takes with him seven other spirits more wicked than himself, and they enter and dwell there; and the last state of that man is worse than the first. So shall it also be with this wicked generation."

46. While He was still talking to the multitudes, behold, His mother and brothers stood outside, seeking to speak with Him.

47. Then one said to Him, "Look, Your mother and Your brothers are standing outside, seeking to speak with You."

48. But He answered and said to the one who told Him, "Who is My mother and who are My brothers?"

49. And He stretched out His hand toward His disciples and said, "Here are My mother and My brothers!

50. For whoever does the will of My Father in heaven is My brother and sister and mother."

## Chapter 13

1. On the same day Jesus went out of the house and sat by the sea.

2. And great multitudes were gathered together to Him, so that He got into a boat and sat; and the whole multitude stood on the shore.

3. Then He spoke many things to them in parables, saying: "Behold, a sower went out to sow.

4. And as he sowed, some seed fell by the wayside; and the birds came and devoured them.

5. Some fell on stony places, where they did not have much earth; and they immediately sprang up because they had no depth of earth.

6. But when the sun was up they were scorched, and because they had no root they withered away.

7. And some fell among thorns, and the thorns sprang up and choked them.

8. But others fell on good ground and yielded a crop: some a hundredfold, some sixty, some thirty.

9. He who has ears to hear, let him hear!"

10. And the disciples came and said to Him, "Why do You speak to them in parables?"

11. He answered and said to them, "Because it has been given to you to know the mysteries of the kingdom of heaven, but to them it has not been given.

12. For whoever has, to him more will be given, and he will have abundance; but whoever does not have, even what he has will be taken away from him.

13. Therefore I speak to them in parables, because seeing they do not see, and hearing they do not hear, nor do they understand.

14. And in them the prophecy of Isaiah is fulfilled, which says: "Hearing you will hear and shall not understand, And seeing you will see and not perceive;

15. For the hearts of this people have grown dull. Their ears are hard of hearing, And their eyes they have closed, Lest they should see with their eyes and hear with their ears, Lest they should understand with their hearts and turn, So that I should heal them.'

16. But blessed are your eyes for they see, and your ears for they hear;

17. for assuredly, I say to you that many prophets and righteous men desired to see what you see, and did not see it, and to hear what you hear, and did not hear it.

18. "Therefore hear the parable of the sower:

19. When anyone hears the word of the kingdom, and does not understand it, then the wicked one comes and snatches away what was sown in his heart. This is he who received seed by the wayside.

20. But he who received the seed on stony places, this is he who hears the word and immediately receives it with joy;

21. yet he has no root in himself, but endures only for a while. For when tribulation or persecution arises because of the word, immediately he stumbles.

22. Now he who received seed among the thorns is he who hears the word, and the cares of this world and the deceitfulness of riches choke the word, and he becomes unfruitful.

23. But he who received seed on the good ground is he who hears the word and understands it, who indeed bears fruit and produces: some a hundredfold, some sixty, some thirty."

24. Another parable He put forth to them, saying: "The kingdom of heaven is like a man who sowed good seed in his field;

25. but while men slept, his enemy came and sowed tares among the wheat and went his way.

26. But when the grain had sprouted and produced a crop, then the tares also appeared.

27. So the servants of the owner came and said to him, "Sir, did you not sow good seed in your field? How then does it have tares?'

28. He said to them, "An enemy has done this.' The servants said to him, "Do you want us then to go and gather them up?'

29. But he said, "No, lest while you gather up the tares you also uproot the wheat with them.

30. Let both grow together until the harvest, and at the time of harvest I will say to the reapers, "First gather together the tares and bind them in bundles to burn them, but gather the wheat into my barn.""'

31. Another parable He put forth to them, saying: "The kingdom of heaven is like a mustard seed, which a man took and sowed in his field,

32. which indeed is the least of all the seeds; but when it is grown it is greater than the herbs and becomes a tree, so that the birds of the air come and nest in its branches."

33. Another parable He spoke to them: "The kingdom of heaven is like leaven, which a woman took and hid in three measures of meal till it was all leavened."

34. All these things Jesus spoke to the multitude in parables; and without a parable He did not speak to them,

35. that it might be fulfilled which was spoken by the prophet, saying: "I will open My mouth in parables; I will utter things kept secret from the foundation of the world."

36. Then Jesus sent the multitude away and went into the house. And His disciples came to Him, saying, "Explain to us the parable of the tares of the field."

37. He answered and said to them: "He who sows the good seed is the Son of Man.

38. The field is the world, the good seeds are the sons of the kingdom, but the tares are the sons of the wicked one.

39. The enemy who sowed them is the devil, the harvest is the end of the age, and the reapers are the angels.

40. Therefore as the tares are gathered and burned in the fire, so it will be at the end of this age.

41. The Son of Man will send out His angels, and they will gather out of His kingdom all things that offend, and those who practice lawlessness,

42. and will cast them into the furnace of fire. There will be wailing and gnashing of teeth.

43. Then the righteous will shine forth as the sun in the kingdom of their Father. He who has ears to hear, let him hear!

44. "Again, the kingdom of heaven is like treasure hidden in a field, which a man found and hid; and for joy over it he goes and sells all that he has and buys that field.

45. "Again, the kingdom of heaven is like a merchant seeking beautiful pearls,

46. who, when he had found one pearl of great price, went and sold all that he had and bought it.

47. "Again, the kingdom of heaven is like a dragnet that was cast into the sea and gathered some of every kind,

48. which, when it was full, they drew to shore; and they sat down and gathered the good into vessels, but threw the bad away.

49. So it will be at the end of the age. The angels will come forth, separate the wicked from among the just,

50. and cast them into the furnace of fire. There will be wailing and gnashing of teeth."

51. Jesus said to them, "Have you understood all these things?" They said to Him, "Yes, Lord."

52. Then He said to them, "Therefore every scribe instructed concerning the kingdom of heaven is like a householder who brings out of his treasure things new and old."

53. Now it came to pass, when Jesus had finished these parables, that He departed from there.

54. When He had come to His own country, He taught them in their synagogue, so that they were astonished and said, "Where did this Man get this wisdom and these mighty works?

55. Is this not the carpenter's son? Is not His mother called Mary? And His brothers James, Joses, Simon, and Judas?

56. And His sisters, are they not all with us? Where then did this Man get all these things?"

57. So they were offended at Him. But Jesus said to them, "A prophet is not without honor except in his own country and in his own house."

58. Now He did not do many mighty works there because of their unbelief.

## Chapter 14

1. At that time Herod the tetrarch heard the report about Jesus

2. and said to his servants, "This is John the Baptist; he is risen from the dead, and therefore these powers are at work in him."

3. For Herod had laid hold of John and bound him, and put him in prison for the sake of Herodias, his brother Philip's wife.

4. Because John had said to him, "It is not lawful for you to have her."

5. And although he wanted to put him to death, he feared the multitude, because they counted him as a prophet.

6. But when Herod's birthday was celebrated, the daughter of Herodias danced before them and pleased Herod.

7. Therefore he promised with an oath to give her whatever she might ask.

8. So she, having been prompted by her mother, said, "Give me John the Baptist's head here on a platter."

9. And the king was sorry; nevertheless, because of the oaths and because of those who sat with him, he commanded it to be given to her.

10. So he sent and had John beheaded in prison.

11. And his head was brought on a platter and given to the girl, and she brought it to her mother.

12. Then his disciples came and took away the body and buried it, and went and told Jesus.

13. When Jesus heard it, He departed from there by boat to a deserted place by Himself. But when the multitudes heard it, they followed Him on foot from the cities.

14. And when Jesus went out He saw a great multitude; and He was moved with compassion for them, and healed their sick.

15. When it was evening, His disciples came to Him, saying, "This is a deserted place, and the hour is already late. Send the multitudes away, that they may go into the villages and buy themselves food."

16. But Jesus said to them, "They do not need to go away. You give them something to eat."

17. And they said to Him, "We have here only five loaves and two fish."

18. He said, "Bring them here to Me."

19. Then He commanded the multitudes to sit down on the grass. And He took the five loaves and the two fish, and looking up to heaven, He blessed and broke and gave the loaves to the disciples; and the disciples gave to the multitudes.

20. So they all ate and were filled, and they took up twelve baskets full of the fragments that remained.

21. Now those who had eaten were about five thousand men, besides women and children.

22. Immediately Jesus made His disciples get into the boat and go before Him to the other side, while He sent the multitudes away.

23. And when He had sent the multitudes away, He went up on the mountain by Himself to pray. Now when evening came, He was alone there.

24. But the boat was now in the middle of the sea, tossed by the waves, for the wind was contrary.

25. Now in the fourth watch of the night Jesus went to them, walking on the sea.

26. And when the disciples saw Him walking on the sea, they were troubled, saying, "It is a ghost!" And they cried out for fear.

27. But immediately Jesus spoke to them, saying, "Be of good cheer! It is I; do not be afraid."

28. And Peter answered Him and said, "Lord, if it is You, command me to come to You on the water."

29. So He said, "Come." And when Peter had come down out of the boat, he walked on the water to go to Jesus.

30. But when he saw that the wind was boisterous, he was afraid; and beginning to sink he cried out, saying, "Lord, save me!"

31. And immediately Jesus stretched out His hand and caught him, and said to him, "O you of little faith, why did you doubt?"

32. And when they got into the boat, the wind ceased.

33. Then those who were in the boat came and worshiped Him, saying, "Truly You are the Son of God."

34. When they had crossed over, they came to the land of Gennesaret.

35. And when the men of that place recognized Him, they sent out into all that surrounding region, brought to Him all who were sick,

36. and begged Him that they might only touch the hem of His garment. And as many as touched it were made perfectly well.

## Chapter 15

1. Then the scribes and Pharisees who were from Jerusalem came to Jesus, saying,

2. "Why do Your disciples transgress the tradition of the elders? For they do not wash their hands when they eat bread."

3. He answered and said to them, "Why do you also transgress the commandment of God because of your tradition?

4. For God commanded, saying, "Honor your father and your mother'; and, "He who curses father or mother, let him be put to death.'

5. But you say, "Whoever says to his father or mother, "Whatever profit you might have received from me is a gift to God"--

6. then he need not honor his father or mother.' Thus you have made the commandment of God of no effect by your tradition.

7. Hypocrites! Well did Isaiah prophesy about you, saying:

8. "These people draw near to Me with their mouth, And honor Me with their lips, But their heart is far from Me.

9. And in vain they worship Me, Teaching as doctrines the commandments of men."'

10. When He had called the multitude to Himself, He said to them, "Hear and understand:

11. Not what goes into the mouth defiles a man; but what comes out of the mouth, this defiles a man."

12. Then His disciples came and said to Him, "Do You know that the Pharisees were offended when they heard this saying?"

13. But He answered and said, "Every plant which My heavenly Father has not planted will be uprooted.

14. Let them alone. They are blind leaders of the blind. And if the blind leads the blind, both will fall into a ditch."

15. Then Peter answered and said to Him, "Explain this parable to us."

16. So Jesus said, "Are you also still without understanding?

17. Do you not yet understand that whatever enters the mouth goes into the stomach and is eliminated?

18. But those things which proceed out of the mouth come from the heart, and they defile a man.

19. For out of the heart proceed evil thoughts, murders, adulteries, fornications, thefts, false witness, blasphemies.

20. These are the things which defile a man, but to eat with unwashed hands does not defile a man."

21. Then Jesus went out from there and departed to the region of Tyre and Sidon.

22. And behold, a woman of Canaan came from that region and cried out to Him, saying, "Have mercy on me, O Lord, Son of David! My daughter is severely demon-possessed."

23. But He answered her not a word. And His disciples came and urged Him, saying, "Send her away, for she cries out after us."

24. But He answered and said, "I was not sent except to the lost sheep of the house of Israel."

25. Then she came and worshiped Him, saying, "Lord, help me!"

26. But He answered and said, "It is not good to take the children's bread and throw it to the little dogs."

27. And she said, "Yes, Lord, yet even the little dogs eat the crumbs which fall from their masters' table."

28. Then Jesus answered and said to her, "O woman, great is your faith! Let it be to you as you desire." And her daughter was healed from that very hour.

29. Jesus departed from there, skirted the Sea of Galilee, and went up on the mountain and sat down there.

30. Then great multitudes came to Him, having with them the lame, blind, mute, maimed, and many others; and they laid them down at Jesus' feet, and He healed them.

31. So the multitude marveled when they saw the mute speaking, the maimed made whole, the lame walking, and the blind seeing; and they glorified the God of Israel.

32. Now Jesus called His disciples to Himself and said, "I have compassion on the multitude, because they have now continued with Me three days and have nothing to eat. And I do not want to send them away hungry, lest they faint on the way."

33. Then His disciples said to Him, "Where could we get enough bread in the wilderness to fill such a great multitude?"

34. Jesus said to them, "How many loaves do you have?" And they said, "Seven, and a few little fish."

35. So He commanded the multitude to sit down on the ground.

36. And He took the seven loaves and the fish and gave thanks, broke them and gave them to His disciples; and the disciples gave to the multitude.

37. So they all ate and were filled, and they took up seven large baskets full of the fragments that were left.

38. Now those who ate were four thousand men, besides women and children.

39. And He sent away the multitude, got into the boat, and came to the region of Magdala.

## Chapter 16

1. Then the Pharisees and Sadducees came, and testing Him asked that He would show them a sign from heaven.

2. He answered and said to them, "When it is evening you say, "It will be fair weather, for the sky is red';

3. and in the morning, "It will be foul weather today, for the sky is red and threatening.' Hypocrites! You know how to discern the face of the sky, but you cannot discern the signs of the times.

4. A wicked and adulterous generation seeks after a sign, and no sign shall be given to it except the sign of the prophet Jonah." And He left them and departed.

5. Now when His disciples had come to the other side, they had forgotten to take bread.

6. Then Jesus said to them, "Take heed and beware of the leaven of the Pharisees and the Sadducees."

7. And they reasoned among themselves, saying, "It is because we have taken no bread."

8. But Jesus, being aware of it, said to them, "O you of little faith, why do you reason among yourselves because you have brought no bread?

9. Do you not yet understand, or remember the five loaves of the five thousand and how many baskets you took up?

10. Nor the seven loaves of the four thousand and how many large baskets you took up?

11. How is it you do not understand that I did not speak to you concerning bread?--but to beware of the leaven of the Pharisees and Sadducees."

12. Then they understood that He did not tell them to beware of the leaven of bread, but of the doctrine of the Pharisees and Sadducees.

13. When Jesus came into the region of Caesarea Philippi, He asked His disciples, saying, "Who do men say that I, the Son of Man, am?"

14. So they said, "Some say John the Baptist, some Elijah, and others Jeremiah or one of the prophets."

15. He said to them, "But who do you say that I am?"

16. Simon Peter answered and said, "You are the Christ, the Son of the living God."

17. Jesus answered and said to him, "Blessed are you, Simon Bar-Jonah, for flesh and blood has not revealed this to you, but My Father who is in heaven.

18. And I also say to you that you are Peter, and on this rock I will build My church, and the gates of Hades shall not prevail against it.

19. And I will give you the keys of the kingdom of heaven, and whatever you bind on earth will be bound in heaven, and whatever you loose on earth will be loosed in heaven."

20. Then He commanded His disciples that they should tell no one that He was Jesus the Christ.

21. From that time Jesus began to show to His disciples that He must go to Jerusalem, and suffer many things from the elders and chief priests and scribes, and be killed, and be raised the third day.

22. Then Peter took Him aside and began to rebuke Him, saying, "Far be it from You, Lord; this shall not happen to You!"

23. But He turned and said to Peter, "Get behind Me, Satan! You are an offense to Me, for you are not mindful of the things of God, but the things of men."

24. Then Jesus said to His disciples, "If anyone desires to come after Me, let him deny himself, and take up his cross, and follow Me.

25. For whoever desires to save his life will lose it, but whoever loses his life for My sake will find it.

26. For what profit is it to a man if he gains the whole world, and loses his own soul? Or what will a man give in exchange for his soul?

27. For the Son of Man will come in the glory of His Father with His angels, and then He will reward each according to his works.

28. Assuredly, I say to you, there are some standing here who shall not taste death till they see the Son of Man coming in His kingdom."

## Chapter 17

1. Now after six days Jesus took Peter, James, and John his brother, led them up on a high mountain by themselves;

2. and He was transfigured before them. His face shone like the sun, and His clothes became as white as the light.

3. And behold, Moses and Elijah appeared to them, talking with Him.

4. Then Peter answered and said to Jesus, "Lord, it is good for us to be here; if You wish, let us make here three tabernacles: one for You, one for Moses, and one for Elijah."

5. While he was still speaking, behold, a bright cloud overshadowed them; and suddenly a voice came out of the cloud, saying, "This is My beloved Son, in whom I am well pleased. Hear Him!"

6. And when the disciples heard it, they fell on their faces and were greatly afraid.

7. But Jesus came and touched them and said, "Arise, and do not be afraid."

8. When they had lifted up their eyes, they saw no one but Jesus only.

9. Now as they came down from the mountain, Jesus commanded them, saying, "Tell the vision to no one until the Son of Man is risen from the dead."

10. And His disciples asked Him, saying, "Why then do the scribes say that Elijah must come first?"

11. Jesus answered and said to them, "Indeed, Elijah is coming first and will restore all things.

12. But I say to you that Elijah has come already, and they did not know him but did to him whatever they wished. Likewise the Son of Man is also about to suffer at their hands."

13. Then the disciples understood that He spoke to them of John the Baptist.

14. And when they had come to the multitude, a man came to Him, kneeling down to Him and saying,

15. "Lord, have mercy on my son, for he is an epileptic and suffers severely; for he often falls into the fire and often into the water.

16. So I brought him to Your disciples, but they could not cure him."

17. Then Jesus answered and said, "O faithless and perverse generation, how long shall I be with you? How long shall I bear with you? Bring him here to Me."

18. And Jesus rebuked the demon, and it came out of him; and the child was cured from that very hour.

19. Then the disciples came to Jesus privately and said, "Why could we not cast it out?"

20. So Jesus said to them, "Because of your unbelief; for assuredly, I say to you, if you have faith as a mustard seed, you will say to this mountain, "Move from here to there,' and it will move; and nothing will be impossible for you.

21. However, this kind does not go out except by prayer and fasting."

22. Now while they were staying in Galilee, Jesus said to them, "The Son of Man is about to be betrayed into the hands of men,

23. and they will kill Him, and the third day He will be raised up." And they were exceedingly sorrowful.

24. When they had come to Capernaum, those who received the temple tax came to Peter and said, "Does your Teacher not pay the temple tax?"

25. He said, "Yes." And when he had come into the house, Jesus anticipated him, saying, "What do you think, Simon? From whom do the kings of the earth take customs or taxes, from their sons or from strangers?"

26. Peter said to Him, "From strangers." Jesus said to him, "Then the sons are free.

27. Nevertheless, lest we offend them, go to the sea, cast in a hook, and take the fish that comes up first. And when you have opened its mouth, you will find a piece of money; take that and give it to them for Me and you."

## Chapter 18

1. At that time the disciples came to Jesus, saying, "Who then is greatest in the kingdom of heaven?"

2. Then Jesus called a little child to Him, set him in the midst of them,

3. and said, "Assuredly, I say to you, unless you are converted and become as little children, you will by no means enter the kingdom of heaven.

4. Therefore whoever humbles himself as this little child is the greatest in the kingdom of heaven.

5. Whoever receives one little child like this in My name receives Me.

6. "Whoever causes one of these little ones who believe in Me to sin, it would be better for him if a millstone were hung around his neck, and he were drowned in the depth of the sea.

7. Woe to the world because of offenses! For offenses must come, but woe to that man by whom the offense comes!

8. "If your hand or foot causes you to sin, cut it off and cast it from you. It is better for you to enter into life lame or maimed, rather than having two hands or two feet, to be cast into the everlasting fire.

9. And if your eye causes you to sin, pluck it out and cast it from you. It is better for you to enter into life with one eye, rather than having two eyes, to be cast into hell fire.

10. "Take heed that you do not despise one of these little ones, for I say to you that in heaven their angels always see the face of My Father who is in heaven.

11. For the Son of Man has come to save that which was lost.

12. "What do you think? If a man has a hundred sheep, and one of them goes astray, does he not leave the ninety-nine and go to the mountains to seek the one that is straying?

13. And if he should find it, assuredly, I say to you, he rejoices more over that sheep than over the ninety-nine that did not go astray.

14. Even so it is not the will of your Father who is in heaven that one of these little ones should perish.

15. "Moreover if your brother sins against you, go and tell him his fault between you and him alone. If he hears you, you have gained your brother.

16. But if he will not hear, take with you one or two more, that "by the mouth of two or three witnesses every word may be established.'

17. And if he refuses to hear them, tell it to the church. But if he refuses even to hear the church, let him be to you like a heathen and a tax collector.

18. "Assuredly, I say to you, whatever you bind on earth will be bound in heaven, and whatever you loose on earth will be loosed in heaven.

19. "Again I say to you that if two of you agree on earth concerning anything that they ask, it will be done for them by My Father in heaven.

20. For where two or three are gathered together in My name, I am there in the midst of them."

21. Then Peter came to Him and said, "Lord, how often shall my brother sin against me, and I forgive him? Up to seven times?"

22. Jesus said to him, "I do not say to you, up to seven times, but up to seventy times seven.

23. Therefore the kingdom of heaven is like a certain king who wanted to settle accounts with his servants.

24. And when he had begun to settle accounts, one was brought to him who owed him ten thousand talents.

25. But as he was not able to pay, his master commanded that he be sold, with his wife and children and all that he had, and that payment be made.

26. The servant therefore fell down before him, saying, "Master, have patience with me, and I will pay you all.'

27. Then the master of that servant was moved with compassion, released him, and forgave him the debt.

28. "But that servant went out and found one of his fellow servants who owed him a hundred denarii; and he laid hands on him and took him by the throat, saying, "Pay me what you owe!'

29. So his fellow servant fell down at his feet and begged him, saying, "Have patience with me, and I will pay you all.'

30. And he would not, but went and threw him into prison till he should pay the debt.

31. So when his fellow servants saw what had been done, they were very grieved, and came and told their master all that had been done.

32. Then his master, after he had called him, said to him, "You wicked servant! I forgave you all that debt because you begged me.

33. Should you not also have had compassion on your fellow servant, just as I had pity on you?'

34. And his master was angry, and delivered him to the torturers until he should pay all that was due to him.

35. "So My heavenly Father also will do to you if each of you, from his heart, does not forgive his brother his trespasses."

## Chapter 19

1. Now it came to pass, when Jesus had finished these sayings, that He departed from Galilee and came to the region of Judea beyond the Jordan.

2. And great multitudes followed Him, and He healed them there.

3. The Pharisees also came to Him, testing Him, and saying to Him, "Is it lawful for a man to divorce his wife for just any reason?"

4. And He answered and said to them, "Have you not read that He who made them at the beginning "made them male and female,'

5. and said, "For this reason a man shall leave his father and mother and be joined to his wife, and the two shall become one flesh'?

6. So then, they are no longer two but one flesh. Therefore what God has joined together, let not man separate."

7. They said to Him, "Why then did Moses command to give a certificate of divorce, and to put her away?"

8. He said to them, "Moses, because of the hardness of your hearts, permitted you to divorce your wives, but from the beginning it was not so.

9. And I say to you, whoever divorces his wife, except for sexual immorality, and marries another, commits adultery; and whoever marries her who is divorced commits adultery."

10. His disciples said to Him, "If such is the case of the man with his wife, it is better not to marry."

11. But He said to them, "All cannot accept this saying, but only those to whom it has been given:

12. For there are eunuchs who were born thus from their mother's womb, and there are eunuchs who were made eunuchs by men, and there are eunuchs who have made themselves eunuchs for the kingdom of heaven's sake. He who is able to accept it, let him accept it."

13. Then little children were brought to Him that He might put His hands on them and pray, but the disciples rebuked them.

14. But Jesus said, "Let the little children come to Me, and do not forbid them; for of such is the kingdom of heaven."

15. And He laid His hands on them and departed from there.

16. Now behold, one came and said to Him, "Good Teacher, what good thing shall I do that I may have eternal life?"

17. So He said to him, "Why do you call Me good? No one is good but One, that is, God. But if you want to enter into life, keep the commandments."

18. He said to Him, "Which ones?" Jesus said, ""You shall not murder,' "You shall not commit adultery,' "You shall not steal,' "You shall not bear false witness,'

19. "Honor your father and your mother,' and, "You shall love your neighbor as yourself."'

20. The young man said to Him, "All these things I have kept from my youth. What do I still lack?"

21. Jesus said to him, "If you want to be perfect, go, sell what you have and give to the poor, and you will have treasure in heaven; and come, follow Me."

22. But when the young man heard that saying, he went away sorrowful, for he had great possessions.

23. Then Jesus said to His disciples, "Assuredly, I say to you that it is hard for a rich man to enter the kingdom of heaven.

24. And again I say to you, it is easier for a camel to go through the eye of a needle than for a rich man to enter the kingdom of God."

25. When His disciples heard it, they were greatly astonished, saying, "Who then can be saved?"

26. But Jesus looked at them and said to them, "With men this is impossible, but with God all things are possible."

27. Then Peter answered and said to Him, "See, we have left all and followed You. Therefore what shall we have?"

28. So Jesus said to them, "Assuredly I say to you, that in the regeneration, when the Son of Man sits on the throne of His glory, you who have followed Me will also sit on twelve thrones, judging the twelve tribes of Israel.

29. And everyone who has left houses or brothers or sisters or father or mother or wife or children or lands, for My name's sake, shall receive a hundredfold, and inherit eternal life.

30. But many who are first will be last, and the last first.

## Chapter 20

1. "For the kingdom of heaven is like a landowner who went out early in the morning to hire laborers for his vineyard.

2. Now when he had agreed with the laborers for a denarius a day, he sent them into his vineyard.

3. And he went out about the third hour and saw others standing idle in the marketplace,

4. and said to them, "You also go into the vineyard, and whatever is right I will give you.' So they went.

5. Again he went out about the sixth and the ninth hour, and did likewise.

6. And about the eleventh hour he went out and found others standing idle, and said to them, "Why have you been standing here idle all day?'

7. They said to him, "Because no one hired us.' He said to them, "You also go into the vineyard, and whatever is right you will receive.'

8. "So when evening had come, the owner of the vineyard said to his steward, "Call the laborers and give them their wages, beginning with the last to the first.'

9. And when those came who were hired about the eleventh hour, they each received a denarius.

10. But when the first came, they supposed that they would receive more; and they likewise received each a denarius.

11. And when they had received it, they complained against the landowner,

12. saying, "These last men have worked only one hour, and you made them equal to us who have borne the burden and the heat of the day.'

13. But he answered one of them and said, "Friend, I am doing you no wrong. Did you not agree with me for a denarius?

14. Take what is yours and go your way. I wish to give to this last man the same as to you.

15. Is it not lawful for me to do what I wish with my own things? Or is your eye evil because I am good?'

16. So the last will be first, and the first last. For many are called, but few chosen."

17. Now Jesus, going up to Jerusalem, took the twelve disciples aside on the road and said to them,

18. "Behold, we are going up to Jerusalem, and the Son of Man will be betrayed to the chief priests and to the scribes; and they will condemn Him to death,

19. and deliver Him to the Gentiles to mock and to scourge and to crucify. And the third day He will rise again."

20. Then the mother of Zebedee's sons came to Him with her sons, kneeling down and asking something from Him.

21. And He said to her, "What do you wish?" She said to Him, "Grant that these two sons of mine may sit, one on Your right hand and the other on the left, in Your kingdom."

22. But Jesus answered and said, "You do not know what you ask. Are you able to drink the cup that I am about to drink, and be baptized with the baptism that I am baptized with?" They said to Him, "We are able."

23. So He said to them, "You will indeed drink My cup, and be baptized with the baptism that I am baptized with; but to sit on My right hand and on My left is not Mine to give, but it is for those for whom it is prepared by My Father."

24. And when the ten heard it, they were greatly displeased with the two brothers.

25. But Jesus called them to Himself and said, "You know that the rulers of the Gentiles lord it over them, and those who are great exercise authority over them.

26. Yet it shall not be so among you; but whoever desires to become great among you, let him be your servant.

27. And whoever desires to be first among you, let him be your slave--

28. just as the Son of Man did not come to be served, but to serve, and to give His life a ransom for many."

29. Now as they went out of Jericho, a great multitude followed Him.

30. And behold, two blind men sitting by the road, when they heard that Jesus was passing by, cried out, saying, "Have mercy on us, O Lord, Son of David!"

31. Then the multitude warned them that they should be quiet; but they cried out all the more, saying, "Have mercy on us, O Lord, Son of David!"

32. So Jesus stood still and called them, and said, "What do you want Me to do for you?"

33. They said to Him, "Lord, that our eyes may be opened."

34. So Jesus had compassion and touched their eyes. And immediately their eyes received sight, and they followed Him.

## Chapter 21

1. Now when they drew near Jerusalem, and came to Bethphage, at the Mount of Olives, then Jesus sent two disciples,

2. saying to them, "Go into the village opposite you, and immediately you will find a donkey tied, and a colt with her. Loose them and bring them to Me.

3. And if anyone says anything to you, you shall say, "The Lord has need of them,' and immediately he will send them."

4. All this was done that it might be fulfilled which was spoken by the prophet, saying:

5. "Tell the daughter of Zion, "Behold, your King is coming to you, Lowly, and sitting on a donkey, A colt, the foal of a donkey."'

6. So the disciples went and did as Jesus commanded them.

7. They brought the donkey and the colt, laid their clothes on them, and set Him on them.

8. And a very great multitude spread their clothes on the road; others cut down branches from the trees and spread them on the road.

9. Then the multitudes who went before and those who followed cried out, saying: "Hosanna to the Son of David! "Blessed is He who comes in the name of the LORD!' Hosanna in the highest!"

10. And when He had come into Jerusalem, all the city was moved, saying, "Who is this?"

11. So the multitudes said, "This is Jesus, the prophet from Nazareth of Galilee."

12. Then Jesus went into the temple of God and drove out all those who bought and sold in the temple, and overturned the tables of the money changers and the seats of those who sold doves.

13. And He said to them, "It is written, "My house shall be called a house of prayer,' but you have made it a "den of thieves."'

14. Then the blind and the lame came to Him in the temple, and He healed them.

15. But when the chief priests and scribes saw the wonderful things that He did, and the children crying out in the temple and saying, "Hosanna to the Son of David!" they were indignant

16. and said to Him, "Do You hear what these are saying?" And Jesus said to them, "Yes. Have you never read, "Out of the mouth of babes and nursing infants You have perfected praise'?"

17. Then He left them and went out of the city to Bethany, and He lodged there.

18. Now in the morning, as He returned to the city, He was hungry.

19. And seeing a fig tree by the road, He came to it and found nothing on it but leaves, and said to it, "Let no fruit grow on you ever again." Immediately the fig tree withered away.

20. And when the disciples saw it, they marveled, saying, "How did the fig tree wither away so soon?"

21. So Jesus answered and said to them, "Assuredly, I say to you, if you have faith and do not doubt, you will not only do what was done to the fig tree, but also if you say to this mountain, "Be removed and be cast into the sea,' it will be done.

22. And whatever things you ask in prayer, believing, you will receive."

23. Now when He came into the temple, the chief priests and the elders of the people confronted Him as He was teaching, and said, "By what authority are You doing these things? And who gave You this authority?"

24. But Jesus answered and said to them, "I also will ask you one thing, which if you tell Me, I likewise will tell you by what authority I do these things:

25. The baptism of John--where was it from? From heaven or from men?" And they reasoned among themselves, saying, "If we say, "From heaven,' He will say to us, "Why then did you not believe him?'

26. But if we say, "From men,' we fear the multitude, for all count John as a prophet."

27. So they answered Jesus and said, "We do not know." And He said to them, "Neither will I tell you by what authority I do these things.

28. "But what do you think? A man had two sons, and he came to the first and said, "Son, go, work today in my vineyard.'

29. He answered and said, "I will not,' but afterward he regretted it and went.

30. Then he came to the second and said likewise. And he answered and said, "I go, sir,' but he did not go.

31. Which of the two did the will of his father?" They said to Him, "The first." Jesus said to them, "Assuredly, I say to you that tax collectors and harlots enter the kingdom of God before you.

32. For John came to you in the way of righteousness, and you did not believe him; but tax collectors and harlots believed him; and when you saw it, you did not afterward relent and believe him.

33. "Hear another parable: There was a certain landowner who planted a vineyard and set a hedge around it, dug a winepress in it and built a tower. And he leased it to vinedressers and went into a far country.

34. Now when vintage-time drew near, he sent his servants to the vinedressers, that they might receive its fruit.

35. And the vinedressers took his servants, beat one, killed one, and stoned another.

36. Again he sent other servants, more than the first, and they did likewise to them.

37. Then last of all he sent his son to them, saying, "They will respect my son.'

38. But when the vinedressers saw the son, they said among themselves, "This is the heir. Come, let us kill him and seize his inheritance.'

39. So they took him and cast him out of the vineyard and killed him.

40. "Therefore, when the owner of the vineyard comes, what will he do to those vinedressers?"

41. They said to Him, "He will destroy those wicked men miserably, and lease his vineyard to other vinedressers who will render to him the fruits in their seasons."

42. Jesus said to them, "Have you never read in the Scriptures: "The stone which the builders rejected Has become the chief cornerstone. This was the LORD's doing, And it is marvelous in our eyes'?

43. "Therefore I say to you, the kingdom of God will be taken from you and given to a nation bearing the fruits of it.

44. And whoever falls on this stone will be broken; but on whomever it falls, it will grind him to powder."

45. Now when the chief priests and Pharisees heard His parables, they perceived that He was speaking of them.

46. But when they sought to lay hands on Him, they feared the multitudes, because they took Him for a prophet.

## Chapter 22

1. And Jesus answered and spoke to them again by parables and said:

2. "The kingdom of heaven is like a certain king who arranged a marriage for his son,

3. and sent out his servants to call those who were invited to the wedding; and they were not willing to come.

4. Again, he sent out other servants, saying, "Tell those who are invited, "See, I have prepared my dinner; my oxen and fatted cattle are killed, and all things are ready. Come to the wedding."'

5. But they made light of it and went their ways, one to his own farm, another to his business.

6. And the rest seized his servants, treated them spitefully, and killed them.

7. But when the king heard about it, he was furious. And he sent out his armies, destroyed those murderers, and burned up their city.

8. Then he said to his servants, "The wedding is ready, but those who were invited were not worthy.

9. Therefore go into the highways, and as many as you find, invite to the wedding.'

10. So those servants went out into the highways and gathered together all whom they found, both bad and good. And the wedding hall was filled with guests.

11. "But when the king came in to see the guests, he saw a man there who did not have on a wedding garment.

12. So he said to him, "Friend, how did you come in here without a wedding garment?' And he was speechless.

13. Then the king said to the servants, "Bind him hand and foot, take him away, and cast him into outer darkness; there will be weeping and gnashing of teeth.'

14. "For many are called, but few are chosen."

15. Then the Pharisees went and plotted how they might entangle Him in His talk.

16. And they sent to Him their disciples with the Herodians, saying, "Teacher, we know that You are true, and teach the way of God in truth; nor do You care about anyone, for You do not regard the person of men.

17. Tell us, therefore, what do You think? Is it lawful to pay taxes to Caesar, or not?"

18. But Jesus perceived their wickedness, and said, "Why do you test Me, you hypocrites?

19. Show Me the tax money." So they brought Him a denarius.

20. And He said to them, "Whose image and inscription is this?"

21. They said to Him, "Caesar's." And He said to them, "Render therefore to Caesar the things that are Caesar's, and to God the things that are God's."

22. When they had heard these words, they marveled, and left Him and went their way.

23. The same day the Sadducees, who say there is no resurrection, came to Him and asked Him,

24. saying: "Teacher, Moses said that if a man dies, having no children, his brother shall marry his wife and raise up offspring for his brother.

25. Now there were with us seven brothers. The first died after he had married, and having no offspring, left his wife to his brother.

26. Likewise the second also, and the third, even to the seventh.

27. Last of all the woman died also.

28. Therefore, in the resurrection, whose wife of the seven will she be? For they all had her."

29. Jesus answered and said to them, "You are mistaken, not knowing the Scriptures nor the power of God.

30. For in the resurrection they neither marry nor are given in marriage, but are like angels of God in heaven.

31. But concerning the resurrection of the dead, have you not read what was spoken to you by God, saying,

32. "I am the God of Abraham, the God of Isaac, and the God of Jacob'? God is not the God of the dead, but of the living."

33. And when the multitudes heard this, they were astonished at His teaching.

34. But when the Pharisees heard that He had silenced the Sadducees, they gathered together.

35. Then one of them, a lawyer, asked Him a question, testing Him, and saying,

36. "Teacher, which is the great commandment in the law?"

37. Jesus said to him, ""You shall love the LORD your God with all your heart, with all your soul, and with all your mind.'

38. This is the first and great commandment.

39. And the second is like it: "You shall love your neighbor as yourself.'

40. On these two commandments hang all the Law and the Prophets."

41. While the Pharisees were gathered together, Jesus asked them,

42. saying, "What do you think about the Christ? Whose Son is He?" They said to Him, "The Son of David."

43. He said to them, "How then does David in the Spirit call Him "Lord,' saying:

44. "The LORD said to my Lord, "Sit at My right hand, Till I make Your enemies Your footstool"'?

45. If David then calls Him "Lord,' how is He his Son?"

46. And no one was able to answer Him a word, nor from that day on did anyone dare question Him anymore.

## Chapter 23

1. Then Jesus spoke to the multitudes and to His disciples,

2. saying: "The scribes and the Pharisees sit in Moses' seat.

3. Therefore whatever they tell you to observe, that observe and do, but do not do according to their works; for they say, and do not do.

4. For they bind heavy burdens, hard to bear, and lay them on men's shoulders; but they themselves will not move them with one of their fingers.

5. But all their works they do to be seen by men. They make their phylacteries broad and enlarge the borders of their garments.

6. They love the best places at feasts, the best seats in the synagogues,

7. greetings in the marketplaces, and to be called by men, "Rabbi, Rabbi.'

8. But you, do not be called "Rabbi'; for One is your Teacher, the Christ, and you are all brethren.

9. Do not call anyone on earth your father; for One is your Father, He who is in heaven.

10. And do not be called teachers; for One is your Teacher, the Christ.

11. But he who is greatest among you shall be your servant.

12. And whoever exalts himself will be humbled, and he who humbles himself will be exalted.

13. "But woe to you, scribes and Pharisees, hypocrites! For you shut up the kingdom of heaven against men; for you neither go in yourselves, nor do you allow those who are entering to go in.

14. Woe to you, scribes and Pharisees, hypocrites! For you devour widows' houses, and for a pretense make long prayers. Therefore you will receive greater condemnation.

15. "Woe to you, scribes and Pharisees, hypocrites! For you travel land and sea to win one proselyte, and when he is won, you make him twice as much a son of hell as yourselves.

16. "Woe to you, blind guides, who say, "Whoever swears by the temple, it is nothing; but whoever swears by the gold of the temple, he is obliged to perform it.'

17. Fools and blind! For which is greater, the gold or the temple that sanctifies the gold?

18. And, "Whoever swears by the altar, it is nothing; but whoever swears by the gift that is on it, he is obliged to perform it.'

19. Fools and blind! For which is greater, the gift or the altar that sanctifies the gift?

20. Therefore he who swears by the altar, swears by it and by all things on it.

21. He who swears by the temple, swears by it and by Him who dwells in it.

22. And he who swears by heaven, swears by the throne of God and by Him who sits on it.

23. "Woe to you, scribes and Pharisees, hypocrites! For you pay tithe of mint and anise and cummin, and have neglected the weightier matters of the law: justice and mercy and faith. These you ought to have done, without leaving the others undone.

24. Blind guides, who strain out a gnat and swallow a camel!

25. "Woe to you, scribes and Pharisees, hypocrites! For you cleanse the outside of the cup and dish, but inside they are full of extortion and self-indulgence.

26. Blind Pharisee, first cleanse the inside of the cup and dish, that the outside of them may be clean also.

27. "Woe to you, scribes and Pharisees, hypocrites! For you are like whitewashed tombs which indeed appear beautiful outwardly, but inside are full of dead men's bones and all uncleanness.

28. Even so you also outwardly appear righteous to men, but inside you are full of hypocrisy and lawlessness.

29. "Woe to you, scribes and Pharisees, hypocrites! Because you build the tombs of the prophets and adorn the monuments of the righteous,

30. and say, "If we had lived in the days of our fathers, we would not have been partakers with them in the blood of the prophets.'

31. "Therefore you are witnesses against yourselves that you are sons of those who murdered the prophets.

32. Fill up, then, the measure of your fathers' guilt.

33. Serpents, brood of vipers! How can you escape the condemnation of hell?

34. Therefore, indeed, I send you prophets, wise men, and scribes: some of them you will kill and crucify, and some of them you will scourge in your synagogues and persecute from city to city,

35. that on you may come all the righteous blood shed on the earth, from the blood of righteous Abel to the blood of Zechariah, son of Berechiah, whom you murdered between the temple and the altar.

36. Assuredly, I say to you, all these things will come upon this generation.

37. "O Jerusalem, Jerusalem, the one who kills the prophets and stones those who are sent to her! How often I wanted to gather your children together, as a hen gathers her chicks under her wings, but you were not willing!

38. See! Your house is left to you desolate;

39. for I say to you, you shall see Me no more till you say, "Blessed is He who comes in the name of the LORD!"'

## Chapter 24

1. Then Jesus went out and departed from the temple, and His disciples came up to show Him the buildings of the temple.

2. And Jesus said to them, "Do you not see all these things? Assuredly, I say to you, not one stone shall be left here upon another, that shall not be thrown down."

3. Now as He sat on the Mount of Olives, the disciples came to Him privately, saying, "Tell us, when will these things be? And what will be the sign of Your coming, and of the end of the age?"

4. And Jesus answered and said to them: "Take heed that no one deceives you.

5. For many will come in My name, saying, "I am the Christ,' and will deceive many.

6. And you will hear of wars and rumors of wars. See that you are not troubled; for all these things must come to pass, but the end is not yet.

7. For nation will rise against nation, and kingdom against kingdom. And there will be famines, pestilences, and earthquakes in various places.

8. All these are the beginning of sorrows.

9. "Then they will deliver you up to tribulation and kill you, and you will be hated by all nations for My name's sake.

10. And then many will be offended, will betray one another, and will hate one another.

11. Then many false prophets will rise up and deceive many.

12. And because lawlessness will abound, the love of many will grow cold.

13. But he who endures to the end shall be saved.

14. And this gospel of the kingdom will be preached in all the world as a witness to all the nations, and then the end will come.

15. "Therefore when you see the "abomination of desolation,' spoken of by Daniel the prophet, standing in the holy place" (whoever reads, let him understand),

16. "then let those who are in Judea flee to the mountains.

17. Let him who is on the housetop not go down to take anything out of his house.

18. And let him who is in the field not go back to get his clothes.

19. But woe to those who are pregnant and to those who are nursing babies in those days!

20. And pray that your flight may not be in winter or on the Sabbath.

21. For then there will be great tribulation, such as has not been since the beginning of the world until this time, no, nor ever shall be.

22. And unless those days were shortened, no flesh would be saved; but for the elect's sake those days will be shortened.

23. "Then if anyone says to you, "Look, here is the Christ!' or "There!' do not believe it.

24. For false christs and false prophets will rise and show great signs and wonders to deceive, if possible, even the elect.

25. See, I have told you beforehand.

26. "Therefore if they say to you, "Look, He is in the desert!' do not go out; or "Look, He is in the inner rooms!' do not believe it.

27. For as the lightning comes from the east and flashes to the west, so also will the coming of the Son of Man be.

28. For wherever the carcass is, there the eagles will be gathered together.

29. "Immediately after the tribulation of those days the sun will be darkened, and the moon will not give its light; the stars will fall from heaven, and the powers of the heavens will be shaken.

30. Then the sign of the Son of Man will appear in heaven, and then all the tribes of the earth will mourn, and they will see the Son of Man coming on the clouds of heaven with power and great glory.

31. And He will send His angels with a great sound of a trumpet, and they will gather together His elect from the four winds, from one end of heaven to the other.

32. "Now learn this parable from the fig tree: When its branch has already become tender and puts forth leaves, you know that summer is near.

33. So you also, when you see all these things, know that it is near--at the doors!

34. Assuredly, I say to you, this generation will by no means pass away till all these things take place.

35. Heaven and earth will pass away, but My words will by no means pass away.

36. "But of that day and hour no one knows, not even the angels of heaven, but My Father only.

37. But as the days of Noah were, so also will the coming of the Son of Man be.

38. For as in the days before the flood, they were eating and drinking, marrying and giving in marriage, until the day that Noah entered the ark,

39. and did not know until the flood came and took them all away, so also will the coming of the Son of Man be.

40. Then two men will be in the field: one will be taken and the other left.

41. Two women will be grinding at the mill: one will be taken and the other left.

42. Watch therefore, for you do not know what hour your Lord is coming.

43. But know this, that if the master of the house had known what hour the thief would come, he would have watched and not allowed his house to be broken into.

44. Therefore you also be ready, for the Son of Man is coming at an hour you do not expect.

45. "Who then is a faithful and wise servant, whom his master made ruler over his household, to give them food in due season?

46. Blessed is that servant whom his master, when he comes, will find so doing.

47. Assuredly, I say to you that he will make him ruler over all his goods.

48. But if that evil servant says in his heart, "My master is delaying his coming,'

49. and begins to beat his fellow servants, and to eat and drink with the drunkards,

50. the master of that servant will come on a day when he is not looking for him and at an hour that he is not aware of,

51. and will cut him in two and appoint him his portion with the hypocrites. There shall be weeping and gnashing of teeth.

## Chapter 25

1. "Then the kingdom of heaven shall be likened to ten virgins who took their lamps and went out to meet the bridegroom.

2. Now five of them were wise, and five were foolish.

3. Those who were foolish took their lamps and took no oil with them,

4. but the wise took oil in their vessels with their lamps.

5. But while the bridegroom was delayed, they all slumbered and slept.

6. "And at midnight a cry was heard: "Behold, the bridegroom is coming; go out to meet him!'

7. Then all those virgins arose and trimmed their lamps.

8. And the foolish said to the wise, "Give us some of your oil, for our lamps are going out.'

9. But the wise answered, saying, "No, lest there should not be enough for us and you; but go rather to those who sell, and buy for yourselves.'

10. And while they went to buy, the bridegroom came, and those who were ready went in with him to the wedding; and the door was shut.

11. "Afterward the other virgins came also, saying, "Lord, Lord, open to us!'

12. But he answered and said, "Assuredly, I say to you, I do not know you.'

13. "Watch therefore, for you know neither the day nor the hour in which the Son of Man is coming.

14. "For the kingdom of heaven is like a man traveling to a far country, who called his own servants and delivered his goods to them.

15. And to one he gave five talents, to another two, and to another one, to each according to his own ability; and immediately he went on a journey.

16. Then he who had received the five talents went and traded with them, and made another five talents.

17. And likewise he who had received two gained two more also.

18. But he who had received one went and dug in the ground, and hid his lord's money.

19. After a long time the lord of those servants came and settled accounts with them.

20. "So he who had received five talents came and brought five other talents, saying, "Lord, you delivered to me five talents; look, I have gained five more talents besides them.'

21. His lord said to him, "Well done, good and faithful servant; you were faithful over a few things, I will make you ruler over many things. Enter into the joy of your lord.'

22. He also who had received two talents came and said, "Lord, you delivered to me two talents; look, I have gained two more talents besides them.'

23. His lord said to him, "Well done, good and faithful servant; you have been faithful over a few things, I will make you ruler over many things. Enter into the joy of your lord.'

24. "Then he who had received the one talent came and said, "Lord, I knew you to be a hard man, reaping where you have not sown, and gathering where you have not scattered seed.

25. And I was afraid, and went and hid your talent in the ground. Look, there you have what is yours.'

26. "But his lord answered and said to him, "You wicked and lazy servant, you knew that I reap where I have not sown, and gather where I have not scattered seed.

27. So you ought to have deposited my money with the bankers, and at my coming I would have received back my own with interest.

28. So take the talent from him, and give it to him who has ten talents.

29. "For to everyone who has, more will be given, and he will have abundance; but from him who does not have, even what he has will be taken away.

30. And cast the unprofitable servant into the outer darkness. There will be weeping and gnashing of teeth.'

31. "When the Son of Man comes in His glory, and all the holy angels with Him, then He will sit on the throne of His glory.

32. All the nations will be gathered before Him, and He will separate them one from another, as a shepherd divides his sheep from the goats.

33. And He will set the sheep on His right hand, but the goats on the left.

34. Then the King will say to those on His right hand, "Come, you blessed of My Father, inherit the kingdom prepared for you from the foundation of the world:

35. for I was hungry and you gave Me food; I was thirsty and you gave Me drink; I was a stranger and you took Me in;

36. I was naked and you clothed Me; I was sick and you visited Me; I was in prison and you came to Me.'

37. "Then the righteous will answer Him, saying, "Lord, when did we see You hungry and feed You, or thirsty and give You drink?

38. When did we see You a stranger and take You in, or naked and clothe You?

39. Or when did we see You sick, or in prison, and come to You?'

40. And the King will answer and say to them, "Assuredly, I say to you, inasmuch as you did it to one of the least of these My brethren, you did it to Me.'

41. "Then He will also say to those on the left hand, "Depart from Me, you cursed, into the everlasting fire prepared for the devil and his angels:

42. for I was hungry and you gave Me no food; I was thirsty and you gave Me no drink;

43. I was a stranger and you did not take Me in, naked and you did not clothe Me, sick and in prison and you did not visit Me.'

44. "Then they also will answer Him, saying, "Lord, when did we see You hungry or thirsty or a stranger or naked or sick or in prison, and did not minister to You?'

45. Then He will answer them, saying, "Assuredly, I say to you, inasmuch as you did not do it to one of the least of these, you did not do it to Me.'

46. And these will go away into everlasting punishment, but the righteous into eternal life."

## Chapter 26

1. Now it came to pass, when Jesus had finished all these sayings, that He said to His disciples,

2. "You know that after two days is the Passover, and the Son of Man will be delivered up to be crucified."

3. Then the chief priests, the scribes, and the elders of the people assembled at the palace of the high priest, who was called Caiaphas,

4. and plotted to take Jesus by trickery and kill Him.

5. But they said, "Not during the feast, lest there be an uproar among the people."

6. And when Jesus was in Bethany at the house of Simon the leper,

7. a woman came to Him having an alabaster flask of very costly fragrant oil, and she poured it on His head as He sat at the table.

8. But when His disciples saw it, they were indignant, saying, "Why this waste?

9. For this fragrant oil might have been sold for much and given to the poor."

10. But when Jesus was aware of it, He said to them, "Why do you trouble the woman? For she has done a good work for Me.

11. For you have the poor with you always, but Me you do not have always.

12. For in pouring this fragrant oil on My body, she did it for My burial.

13. Assuredly, I say to you, wherever this gospel is preached in the whole world, what this woman has done will also be told as a memorial to her."

14. Then one of the twelve, called Judas Iscariot, went to the chief priests

15. and said, "What are you willing to give me if I deliver Him to you?" And they counted out to him thirty pieces of silver.

16. So from that time he sought opportunity to betray Him.

17. Now on the first day of the Feast of the Unleavened Bread the disciples came to Jesus, saying to Him, "Where do You want us to prepare for You to eat the Passover?"

18. And He said, "Go into the city to a certain man, and say to him, "The Teacher says, "My time is at hand; I will keep the Passover at your house with My disciples.""'

19. So the disciples did as Jesus had directed them; and they prepared the Passover.

20. When evening had come, He sat down with the twelve.

21. Now as they were eating, He said, "Assuredly, I say to you, one of you will betray Me."

22. And they were exceedingly sorrowful, and each of them began to say to Him, "Lord, is it I?"

23. He answered and said, "He who dipped his hand with Me in the dish will betray Me.

24. The Son of Man indeed goes just as it is written of Him, but woe to that man by whom the Son of Man is betrayed! It would have been good for that man if he had not been born."

25. Then Judas, who was betraying Him, answered and said, "Rabbi, is it I?" He said to him, "You have said it."

26. And as they were eating, Jesus took bread, blessed and broke it, and gave it to the disciples and said, "Take, eat; this is My body."

27. Then He took the cup, and gave thanks, and gave it to them, saying, "Drink from it, all of you.

28. For this is My blood of the new covenant, which is shed for many for the remission of sins.

29. But I say to you, I will not drink of this fruit of the vine from now on until that day when I drink it new with you in My Father's kingdom."

30. And when they had sung a hymn, they went out to the Mount of Olives.

31. Then Jesus said to them, "All of you will be made to stumble because of Me this night, for it is written: "I will strike the Shepherd, And the sheep of the flock will be scattered.'

32. But after I have been raised, I will go before you to Galilee."

33. Peter answered and said to Him, "Even if all are made to stumble because of You, I will never be made to stumble."

34. Jesus said to him, "Assuredly, I say to you that this night, before the rooster crows, you will deny Me three times."

35. Peter said to Him, "Even if I have to die with You, I will not deny You!" And so said all the disciples.

36. Then Jesus came with them to a place called Gethsemane, and said to the disciples, "Sit here while I go and pray over there."

37. And He took with Him Peter and the two sons of Zebedee, and He began to be sorrowful and deeply distressed.

38. Then He said to them, "My soul is exceedingly sorrowful, even to death. Stay here and watch with Me."

39. He went a little farther and fell on His face, and prayed, saying, "O My Father, if it is possible, let this cup pass from Me; nevertheless, not as I will, but as You will."

40. Then He came to the disciples and found them sleeping, and said to Peter, "What! Could you not watch with Me one hour?

41. Watch and pray, lest you enter into temptation. The spirit indeed is willing, but the flesh is weak."

42. Again, a second time, He went away and prayed, saying, "O My Father, if this cup cannot pass away from Me unless I drink it, Your will be done."

43. And He came and found them asleep again, for their eyes were heavy.

44. So He left them, went away again, and prayed the third time, saying the same words.

45. Then He came to His disciples and said to them, "Are you still sleeping and resting? Behold, the hour is at hand, and the Son of Man is being betrayed into the hands of sinners.

46. Rise, let us be going. See, My betrayer is at hand."

47. And while He was still speaking, behold, Judas, one of the twelve, with a great multitude with swords and clubs, came from the chief priests and elders of the people.

48. Now His betrayer had given them a sign, saying, "Whomever I kiss, He is the One; seize Him."

49. Immediately he went up to Jesus and said, "Greetings, Rabbi!" and kissed Him.

50. But Jesus said to him, "Friend, why have you come?" Then they came and laid hands on Jesus and took Him.

51. And suddenly, one of those who were with Jesus stretched out his hand and drew his sword, struck the servant of the high priest, and cut off his ear.

52. But Jesus said to him, "Put your sword in its place, for all who take the sword will perish by the sword.

53. Or do you think that I cannot now pray to My Father, and He will provide Me with more than twelve legions of angels?

54. How then could the Scriptures be fulfilled, that it must happen thus?"

55. In that hour Jesus said to the multitudes, "Have you come out, as against a robber, with swords and clubs to take Me? I sat daily with you, teaching in the temple, and you did not seize Me.

56. But all this was done that the Scriptures of the prophets might be fulfilled." Then all the disciples forsook Him and fled.

57. And those who had laid hold of Jesus led Him away to Caiaphas the high priest, where the scribes and the elders were assembled.

58. But Peter followed Him at a distance to the high priest's courtyard. And he went in and sat with the servants to see the end.

59. Now the chief priests, the elders, and all the council sought false testimony against Jesus to put Him to death,

60. but found none. Even though many false witnesses came forward, they found none. But at last two false witnesses came forward

61. and said, "This fellow said, "I am able to destroy the temple of God and to build it in three days."'

62. And the high priest arose and said to Him, "Do You answer nothing? What is it these men testify against You?"

63. But Jesus kept silent. And the high priest answered and said to Him, "I put You under oath by the living God: Tell us if You are the Christ, the Son of God!"

64. Jesus said to him, "It is as you said. Nevertheless, I say to you, hereafter you will see the Son of Man sitting at the right hand of the Power, and coming on the clouds of heaven."

65. Then the high priest tore his clothes, saying, "He has spoken blasphemy! What further need do we have of witnesses? Look, now you have heard His blasphemy!

66. What do you think?" They answered and said, "He is deserving of death."

67. Then they spat in His face and beat Him; and others struck Him with the palms of their hands,

68. saying, "Prophesy to us, Christ! Who is the one who struck You?"

69. Now Peter sat outside in the courtyard. And a servant girl came to him, saying, "You also were with Jesus of Galilee."

70. But he denied it before them all, saying, "I do not know what you are saying."

71. And when he had gone out to the gateway, another girl saw him and said to those who were there, "This fellow also was with Jesus of Nazareth."

72. But again he denied with an oath, "I do not know the Man!"

73. And a little later those who stood by came up and said to Peter, "Surely you also are one of them, for your speech betrays you."

74. Then he began to curse and swear, saying, "I do not know the Man!" Immediately a rooster crowed.

75. And Peter remembered the word of Jesus who had said to him, "Before the rooster crows, you will deny Me three times." So he went out and wept bitterly.

## Chapter 27

1. When morning came, all the chief priests and elders of the people plotted against Jesus to put Him to death.

2. And when they had bound Him, they led Him away and delivered Him to Pontius Pilate the governor.

3. Then Judas, His betrayer, seeing that He had been condemned, was remorseful and brought back the thirty pieces of silver to the chief priests and elders,

4. saying, "I have sinned by betraying innocent blood." And they said, "What is that to us? You see to it!"

5. Then he threw down the pieces of silver in the temple and departed, and went and hanged himself.

6. But the chief priests took the silver pieces and said, "It is not lawful to put them into the treasury, because they are the price of blood."

7. And they consulted together and bought with them the potter's field, to bury strangers in.

8. Therefore that field has been called the Field of Blood to this day.

9. Then was fulfilled what was spoken by Jeremiah the prophet, saying, "And they took the thirty pieces of silver, the value of Him who was priced, whom they of the children of Israel priced,

10. and gave them for the potter's field, as the LORD directed me."

11. Now Jesus stood before the governor. And the governor asked Him, saying, "Are You the King of the Jews?" Jesus said to him, "It is as you say."

12. And while He was being accused by the chief priests and elders, He answered nothing.

13. Then Pilate said to Him, "Do You not hear how many things they testify against You?"

14. But He answered him not one word, so that the governor marveled greatly.

15. Now at the feast the governor was accustomed to releasing to the multitude one prisoner whom they wished.

16. And at that time they had a notorious prisoner called Barabbas.

17. Therefore, when they had gathered together, Pilate said to them, "Whom do you want me to release to you? Barabbas, or Jesus who is called Christ?"

18. For he knew that they had handed Him over because of envy.

19. While he was sitting on the judgment seat, his wife sent to him, saying, "Have nothing to do with that just Man, for I have suffered many things today in a dream because of Him."

20. But the chief priests and elders persuaded the multitudes that they should ask for Barabbas and destroy Jesus.

21. The governor answered and said to them, "Which of the two do you want me to release to you?" They said, "Barabbas!"

22. Pilate said to them, "What then shall I do with Jesus who is called Christ?" They all said to him, "Let Him be crucified!"

23. Then the governor said, "Why, what evil has He done?" But they cried out all the more, saying, "Let Him be crucified!"

24. When Pilate saw that he could not prevail at all, but rather that a tumult was rising, he took water and washed his hands before the multitude, saying, "I am innocent of the blood of this just Person. You see to it."

25. And all the people answered and said, "His blood be on us and on our children."

26. Then he released Barabbas to them; and when he had scourged Jesus, he delivered Him to be crucified.

27. Then the soldiers of the governor took Jesus into the Praetorium and gathered the whole garrison around Him.

28. And they stripped Him and put a scarlet robe on Him.

29. When they had twisted a crown of thorns, they put it on His head, and a reed in His right hand. And they bowed the knee before Him and mocked Him, saying, "Hail, King of the Jews!"

30. Then they spat on Him, and took the reed and struck Him on the head.

31. And when they had mocked Him, they took the robe off Him, put His own clothes on Him, and led Him away to be crucified.

32. Now as they came out, they found a man of Cyrene, Simon by name. Him they compelled to bear His cross.

33. And when they had come to a place called Golgotha, that is to say, Place of a Skull,

34. they gave Him sour wine mingled with gall to drink. But when He had tasted it, He would not drink.

35. Then they crucified Him, and divided His garments, casting lots, that it might be fulfilled which was spoken by the prophet: "They divided My garments among them, And for My clothing they cast lots."

36. Sitting down, they kept watch over Him there.

37. And they put up over His head the accusation written against Him: THIS IS JESUS THE KING OF THE JEWS.

38. Then two robbers were crucified with Him, one on the right and another on the left.

39. And those who passed by blasphemed Him, wagging their heads

40. and saying, "You who destroy the temple and build it in three days, save Yourself! If You are the Son of God, come down from the cross."

41. Likewise the chief priests also, mocking with the scribes and elders, said,

42. "He saved others; Himself He cannot save. If He is the King of Israel, let Him now come down from the cross, and we will believe Him.

43. He trusted in God; let Him deliver Him now if He will have Him; for He said, "I am the Son of God."'

44. Even the robbers who were crucified with Him reviled Him with the same thing.

45. Now from the sixth hour until the ninth hour there was darkness over all the land.

46. And about the ninth hour Jesus cried out with a loud voice, saying, "Eli, Eli, lama sabachthani?" that is, "My God, My God, why have You forsaken Me?"

47. Some of those who stood there, when they heard that, said, "This Man is calling for Elijah!"

48. Immediately one of them ran and took a sponge, filled it with sour wine and put it on a reed, and offered it to Him to drink.

49. The rest said, "Let Him alone; let us see if Elijah will come to save Him."

50. And Jesus cried out again with a loud voice, and yielded up His spirit.

51. Then, behold, the veil of the temple was torn in two from top to bottom; and the earth quaked, and the rocks were split,

52. and the graves were opened; and many bodies of the saints who had fallen asleep were raised;

53. and coming out of the graves after His resurrection, they went into the holy city and appeared to many.

54. So when the centurion and those with him, who were guarding Jesus, saw the earthquake and the things that had happened, they feared greatly, saying, "Truly this was the Son of God!"

55. And many women who followed Jesus from Galilee, ministering to Him, were there looking on from afar,

56. among whom were Mary Magdalene, Mary the mother of James and Joses, and the mother of Zebedee's sons.

57. Now when evening had come, there came a rich man from Arimathea, named Joseph, who himself had also become a disciple of Jesus.

58. This man went to Pilate and asked for the body of Jesus. Then Pilate commanded the body to be given to him.

59. When Joseph had taken the body, he wrapped it in a clean linen cloth,

60. and laid it in his new tomb which he had hewn out of the rock; and he rolled a large stone against the door of the tomb, and departed.

61. And Mary Magdalene was there, and the other Mary, sitting opposite the tomb.

62. On the next day, which followed the Day of Preparation, the chief priests and Pharisees gathered together to Pilate,

63. saying, "Sir, we remember, while He was still alive, how that deceiver said, "After three days I will rise.'

64. Therefore command that the tomb be made secure until the third day, lest His disciples come by night and steal Him away, and say to the people, "He has risen from the dead.' So the last deception will be worse than the first."

65. Pilate said to them, "You have a guard; go your way, make it as secure as you know how."

66. So they went and made the tomb secure, sealing the stone and setting the guard.

## Chapter 28

1. Now after the Sabbath, as the first day of the week began to dawn, Mary Magdalene and the other Mary came to see the tomb.

2. And behold, there was a great earthquake; for an angel of the Lord descended from heaven, and came and rolled back the stone from the door, and sat on it.

3. His countenance was like lightning, and his clothing as white as snow.

4. And the guards shook for fear of him, and became like dead men.

5. But the angel answered and said to the women, "Do not be afraid, for I know that you seek Jesus who was crucified.

6. He is not here; for He is risen, as He said. Come, see the place where the Lord lay.

7. And go quickly and tell His disciples that He is risen from the dead, and indeed He is going before you into Galilee; there you will see Him. Behold, I have told you."

8. So they went out quickly from the tomb with fear and great joy, and ran to bring His disciples word.

9. And as they went to tell His disciples, behold, Jesus met them, saying, "Rejoice!" So they came and held Him by the feet and worshiped Him.

10. Then Jesus said to them, "Do not be afraid. Go and tell My brethren to go to Galilee, and there they will see Me."

11. Now while they were going, behold, some of the guard came into the city and reported to the chief priests all the things that had happened.

12. When they had assembled with the elders and consulted together, they gave a large sum of money to the soldiers,

13. saying, "Tell them, "His disciples came at night and stole Him away while we slept.'

14. And if this comes to the governor's ears, we will appease him and make you secure."

15. So they took the money and did as they were instructed; and this saying is commonly reported among the Jews until this day.

16. Then the eleven disciples went away into Galilee, to the mountain which Jesus had appointed for them.

17. When they saw Him, they worshiped Him; but some doubted.

18. And Jesus came and spoke to them, saying, "All authority has been given to Me in heaven and on earth.

19. Go therefore and make disciples of all the nations, baptizing them in the name of the Father and of the Son and of the Holy Spirit,

20. teaching them to observe all things that I have commanded you; and lo, I am with you always, even to the end of the age." Amen.


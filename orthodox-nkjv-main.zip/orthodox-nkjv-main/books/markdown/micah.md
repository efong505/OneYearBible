# micah

## Chapter 1

1. The word of the LORD that came to Micah of Moresheth in the days of Jotham, Ahaz, and Hezekiah, kings of Judah, which he saw concerning Samaria and Jerusalem.

2. Hear, all you peoples! Listen, O earth, and all that is in it! Let the Lord GOD be a witness against you, The Lord from His holy temple.

3. For behold, the LORD is coming out of His place; He will come down And tread on the high places of the earth.

4. The mountains will melt under Him, And the valleys will split Like wax before the fire, Like waters poured down a steep place.

5. All this is for the transgression of Jacob And for the sins of the house of Israel. What is the transgression of Jacob? Is it not Samaria? And what are the high places of Judah? Are they not Jerusalem?

6. "Therefore I will make Samaria a heap of ruins in the field, Places for planting a vineyard; I will pour down her stones into the valley, And I will uncover her foundations.

7. All her carved images shall be beaten to pieces, And all her pay as a harlot shall be burned with the fire; All her idols I will lay desolate, For she gathered it from the pay of a harlot, And they shall return to the pay of a harlot."

8. Therefore I will wail and howl, I will go stripped and naked; I will make a wailing like the jackals And a mourning like the ostriches,

9. For her wounds are incurable. For it has come to Judah; It has come to the gate of My people-- To Jerusalem.

10. Tell it not in Gath, Weep not at all; In Beth Aphrah Roll yourself in the dust.

11. Pass by in naked shame, you inhabitant of Shaphir; The inhabitant of Zaanan does not go out. Beth Ezel mourns; Its place to stand is taken away from you.

12. For the inhabitant of Maroth pined for good, But disaster came down from the LORD To the gate of Jerusalem.

13. O inhabitant of Lachish, Harness the chariot to the swift steeds (She was the beginning of sin to the daughter of Zion), For the transgressions of Israel were found in you.

14. Therefore you shall give presents to Moresheth Gath; The houses of Achzib shall be a lie to the kings of Israel.

15. I will yet bring an heir to you, O inhabitant of Mareshah; The glory of Israel shall come to Adullam.

16. Make yourself bald and cut off your hair, Because of your precious children; Enlarge your baldness like an eagle, For they shall go from you into captivity.

## Chapter 2

1. Woe to those who devise iniquity, And work out evil on their beds! At morning light they practice it, Because it is in the power of their hand.

2. They covet fields and take them by violence, Also houses, and seize them. So they oppress a man and his house, A man and his inheritance.

3. Therefore thus says the LORD: "Behold, against this family I am devising disaster, From which you cannot remove your necks; Nor shall you walk haughtily, For this is an evil time.

4. In that day one shall take up a proverb against you, And lament with a bitter lamentation, saying: "We are utterly destroyed! He has changed the heritage of my people; How He has removed it from me! To a turncoat He has divided our fields."'

5. Therefore you will have no one to determine boundaries by lot In the assembly of the LORD.

6. "Do not prattle," you say to those who prophesy. So they shall not prophesy to you; They shall not return insult for insult.

7. You who are named the house of Jacob: "Is the Spirit of the LORD restricted? Are these His doings? Do not My words do good To him who walks uprightly?

8. "Lately My people have risen up as an enemy-- You pull off the robe with the garment From those who trust you, as they pass by, Like men returned from war.

9. The women of My people you cast out From their pleasant houses; From their children You have taken away My glory forever.

10. "Arise and depart, For this is not your rest; Because it is defiled, it shall destroy, Yes, with utter destruction.

11. If a man should walk in a false spirit And speak a lie, saying, "I will prophesy to you of wine and drink,' Even he would be the prattler of this people.

12. "I will surely assemble all of you, O Jacob, I will surely gather the remnant of Israel; I will put them together like sheep of the fold, Like a flock in the midst of their pasture; They shall make a loud noise because of so many people.

13. The one who breaks open will come up before them; They will break out, Pass through the gate, And go out by it; Their king will pass before them, With the LORD at their head."

## Chapter 3

1. And I said: "Hear now, O heads of Jacob, And you rulers of the house of Israel: Is it not for you to know justice?

2. You who hate good and love evil; Who strip the skin from My people, And the flesh from their bones;

3. Who also eat the flesh of My people, Flay their skin from them, Break their bones, And chop them in pieces Like meat for the pot, Like flesh in the caldron."

4. Then they will cry to the LORD, But He will not hear them; He will even hide His face from them at that time, Because they have been evil in their deeds.

5. Thus says the LORD concerning the prophets Who make my people stray; Who chant "Peace" While they chew with their teeth, But who prepare war against him Who puts nothing into their mouths:

6. "Therefore you shall have night without vision, And you shall have darkness without divination; The sun shall go down on the prophets, And the day shall be dark for them.

7. So the seers shall be ashamed, And the diviners abashed; Indeed they shall all cover their lips; For there is no answer from God."

8. But truly I am full of power by the Spirit of the LORD, And of justice and might, To declare to Jacob his transgression And to Israel his sin.

9. Now hear this, You heads of the house of Jacob And rulers of the house of Israel, Who abhor justice And pervert all equity,

10. Who build up Zion with bloodshed And Jerusalem with iniquity:

11. Her heads judge for a bribe, Her priests teach for pay, And her prophets divine for money. Yet they lean on the LORD, and say, "Is not the LORD among us? No harm can come upon us."

12. Therefore because of you Zion shall be plowed like a field, Jerusalem shall become heaps of ruins, And the mountain of the temple Like the bare hills of the forest.

## Chapter 4

1. Now it shall come to pass in the latter days That the mountain of the LORD's house Shall be established on the top of the mountains, And shall be exalted above the hills; And peoples shall flow to it.

2. Many nations shall come and say, "Come, and let us go up to the mountain of the LORD, To the house of the God of Jacob; He will teach us His ways, And we shall walk in His paths." For out of Zion the law shall go forth, And the word of the LORD from Jerusalem.

3. He shall judge between many peoples, And rebuke strong nations afar off; They shall beat their swords into plowshares, And their spears into pruning hooks; Nation shall not lift up sword against nation, Neither shall they learn war anymore.

4. But everyone shall sit under his vine and under his fig tree, And no one shall make them afraid; For the mouth of the LORD of hosts has spoken.

5. For all people walk each in the name of his god, But we will walk in the name of the LORD our God Forever and ever.

6. "In that day," says the LORD, "I will assemble the lame, I will gather the outcast And those whom I have afflicted;

7. I will make the lame a remnant, And the outcast a strong nation; So the LORD will reign over them in Mount Zion From now on, even forever.

8. And you, O tower of the flock, The stronghold of the daughter of Zion, To you shall it come, Even the former dominion shall come, The kingdom of the daughter of Jerusalem."

9. Now why do you cry aloud? Is there no king in your midst? Has your counselor perished? For pangs have seized you like a woman in labor.

10. Be in pain, and labor to bring forth, O daughter of Zion, Like a woman in birth pangs. For now you shall go forth from the city, You shall dwell in the field, And to Babylon you shall go. There you shall be delivered; There the LORD will redeem you From the hand of your enemies.

11. Now also many nations have gathered against you, Who say, "Let her be defiled, And let our eye look upon Zion."

12. But they do not know the thoughts of the LORD, Nor do they understand His counsel; For He will gather them like sheaves to the threshing floor.

13. "Arise and thresh, O daughter of Zion; For I will make your horn iron, And I will make your hooves bronze; You shall beat in pieces many peoples; I will consecrate their gain to the LORD, And their substance to the Lord of the whole earth."

## Chapter 5

1. Now gather yourself in troops, O daughter of troops; He has laid siege against us; They will strike the judge of Israel with a rod on the cheek.

2. "But you, Bethlehem Ephrathah, Though you are little among the thousands of Judah, Yet out of you shall come forth to Me The One to be Ruler in Israel, Whose goings forth are from of old, From everlasting."

3. Therefore He shall give them up, Until the time that she who is in labor has given birth; Then the remnant of His brethren Shall return to the children of Israel.

4. And He shall stand and feed His flock In the strength of the LORD, In the majesty of the name of the LORD His God; And they shall abide, For now He shall be great To the ends of the earth;

5. And this One shall be peace. When the Assyrian comes into our land, And when he treads in our palaces, Then we will raise against him Seven shepherds and eight princely men.

6. They shall waste with the sword the land of Assyria, And the land of Nimrod at its entrances; Thus He shall deliver us from the Assyrian, When he comes into our land And when he treads within our borders.

7. Then the remnant of Jacob Shall be in the midst of many peoples, Like dew from the LORD, Like showers on the grass, That tarry for no man Nor wait for the sons of men.

8. And the remnant of Jacob Shall be among the Gentiles, In the midst of many peoples, Like a lion among the beasts of the forest, Like a young lion among flocks of sheep, Who, if he passes through, Both treads down and tears in pieces, And none can deliver.

9. Your hand shall be lifted against your adversaries, And all your enemies shall be cut off.

10. "And it shall be in that day," says the LORD, "That I will cut off your horses from your midst And destroy your chariots.

11. I will cut off the cities of your land And throw down all your strongholds.

12. I will cut off sorceries from your hand, And you shall have no soothsayers.

13. Your carved images I will also cut off, And your sacred pillars from your midst; You shall no more worship the work of your hands;

14. I will pluck your wooden images from your midst; Thus I will destroy your cities.

15. And I will execute vengeance in anger and fury On the nations that have not heard."

## Chapter 6

1. Hear now what the LORD says: "Arise, plead your case before the mountains, And let the hills hear your voice.

2. Hear, O you mountains, the LORD's complaint, And you strong foundations of the earth; For the LORD has a complaint against His people, And He will contend with Israel.

3. "O My people, what have I done to you? And how have I wearied you? Testify against Me.

4. For I brought you up from the land of Egypt, I redeemed you from the house of bondage; And I sent before you Moses, Aaron, and Miriam.

5. O My people, remember now What Balak king of Moab counseled, And what Balaam the son of Beor answered him, From Acacia Grove to Gilgal, That you may know the righteousness of the LORD."

6. With what shall I come before the LORD, And bow myself before the High God? Shall I come before Him with burnt offerings, With calves a year old?

7. Will the LORD be pleased with thousands of rams, Ten thousand rivers of oil? Shall I give my firstborn for my transgression, The fruit of my body for the sin of my soul?

8. He has shown you, O man, what is good; And what does the LORD require of you But to do justly, To love mercy, And to walk humbly with your God?

9. The LORD's voice cries to the city-- Wisdom shall see Your name: "Hear the rod! Who has appointed it?

10. Are there yet the treasures of wickedness In the house of the wicked, And the short measure that is an abomination?

11. Shall I count pure those with the wicked scales, And with the bag of deceitful weights?

12. For her rich men are full of violence, Her inhabitants have spoken lies, And their tongue is deceitful in their mouth.

13. "Therefore I will also make you sick by striking you, By making you desolate because of your sins.

14. You shall eat, but not be satisfied; Hunger shall be in your midst. You may carry some away, but shall not save them; And what you do rescue I will give over to the sword.

15. "You shall sow, but not reap; You shall tread the olives, but not anoint yourselves with oil; And make sweet wine, but not drink wine.

16. For the statutes of Omri are kept; All the works of Ahab's house are done; And you walk in their counsels, That I may make you a desolation, And your inhabitants a hissing. Therefore you shall bear the reproach of My people."

## Chapter 7

1. Woe is me! For I am like those who gather summer fruits, Like those who glean vintage grapes; There is no cluster to eat Of the first-ripe fruit which my soul desires.

2. The faithful man has perished from the earth, And there is no one upright among men. They all lie in wait for blood; Every man hunts his brother with a net.

3. That they may successfully do evil with both hands-- The prince asks for gifts, The judge seeks a bribe, And the great man utters his evil desire; So they scheme together.

4. The best of them is like a brier; The most upright is sharper than a thorn hedge; The day of your watchman and your punishment comes; Now shall be their perplexity.

5. Do not trust in a friend; Do not put your confidence in a companion; Guard the doors of your mouth From her who lies in your bosom.

6. For son dishonors father, Daughter rises against her mother, Daughter-in-law against her mother-in-law; A man's enemies are the men of his own household.

7. Therefore I will look to the LORD; I will wait for the God of my salvation; My God will hear me.

8. Do not rejoice over me, my enemy; When I fall, I will arise; When I sit in darkness, The LORD will be a light to me.

9. I will bear the indignation of the LORD, Because I have sinned against Him, Until He pleads my case And executes justice for me. He will bring me forth to the light; I will see His righteousness.

10. Then she who is my enemy will see, And shame will cover her who said to me, "Where is the LORD your God?" My eyes will see her; Now she will be trampled down Like mud in the streets.

11. In the day when your walls are to be built, In that day the decree shall go far and wide.

12. In that day they shall come to you From Assyria and the fortified cities, From the fortress to the River, From sea to sea, And mountain to mountain.

13. Yet the land shall be desolate Because of those who dwell in it, And for the fruit of their deeds.

14. Shepherd Your people with Your staff, The flock of Your heritage, Who dwell solitarily in a woodland, In the midst of Carmel; Let them feed in Bashan and Gilead, As in days of old.

15. "As in the days when you came out of the land of Egypt, I will show them wonders."

16. The nations shall see and be ashamed of all their might; They shall put their hand over their mouth; Their ears shall be deaf.

17. They shall lick the dust like a serpent; They shall crawl from their holes like snakes of the earth. They shall be afraid of the LORD our God, And shall fear because of You.

18. Who is a God like You, Pardoning iniquity And passing over the transgression of the remnant of His heritage? He does not retain His anger forever, Because He delights in mercy.

19. He will again have compassion on us, And will subdue our iniquities. You will cast all our sins Into the depths of the sea.

20. You will give truth to Jacob And mercy to Abraham, Which You have sworn to our fathers From days of old.


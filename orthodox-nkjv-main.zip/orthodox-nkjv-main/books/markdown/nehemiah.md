# nehemiah

## Chapter 1

1. The words of Nehemiah the son of Hachaliah. It came to pass in the month of Chislev, in the twentieth year, as I was in Shushan the citadel,

2. that Hanani one of my brethren came with men from Judah; and I asked them concerning the Jews who had escaped, who had survived the captivity, and concerning Jerusalem.

3. And they said to me, "The survivors who are left from the captivity in the province are there in great distress and reproach. The wall of Jerusalem is also broken down, and its gates are burned with fire."

4. So it was, when I heard these words, that I sat down and wept, and mourned for many days; I was fasting and praying before the God of heaven.

5. And I said: "I pray, LORD God of heaven, O great and awesome God, You who keep Your covenant and mercy with those who love You and observe Your commandments,

6. please let Your ear be attentive and Your eyes open, that You may hear the prayer of Your servant which I pray before You now, day and night, for the children of Israel Your servants, and confess the sins of the children of Israel which we have sinned against You. Both my father's house and I have sinned.

7. We have acted very corruptly against You, and have not kept the commandments, the statutes, nor the ordinances which You commanded Your servant Moses.

8. Remember, I pray, the word that You commanded Your servant Moses, saying, "If you are unfaithful, I will scatter you among the nations;

9. but if you return to Me, and keep My commandments and do them, though some of you were cast out to the farthest part of the heavens, yet I will gather them from there, and bring them to the place which I have chosen as a dwelling for My name.'

10. Now these are Your servants and Your people, whom You have redeemed by Your great power, and by Your strong hand.

11. O Lord, I pray, please let Your ear be attentive to the prayer of Your servant, and to the prayer of Your servants who desire to fear Your name; and let Your servant prosper this day, I pray, and grant him mercy in the sight of this man." For I was the king's cupbearer.

## Chapter 2

1. And it came to pass in the month of Nisan, in the twentieth year of King Artaxerxes, when wine was before him, that I took the wine and gave it to the king. Now I had never been sad in his presence before.

2. Therefore the king said to me, "Why is your face sad, since you are not sick? This is nothing but sorrow of heart." So I became dreadfully afraid,

3. and said to the king, "May the king live forever! Why should my face not be sad, when the city, the place of my fathers' tombs, lies waste, and its gates are burned with fire?"

4. Then the king said to me, "What do you request?" So I prayed to the God of heaven.

5. And I said to the king, "If it pleases the king, and if your servant has found favor in your sight, I ask that you send me to Judah, to the city of my fathers' tombs, that I may rebuild it."

6. Then the king said to me (the queen also sitting beside him), "How long will your journey be? And when will you return?" So it pleased the king to send me; and I set him a time.

7. Furthermore I said to the king, "If it pleases the king, let letters be given to me for the governors of the region beyond the River, that they must permit me to pass through till I come to Judah,

8. and a letter to Asaph the keeper of the king's forest, that he must give me timber to make beams for the gates of the citadel which pertains to the temple, for the city wall, and for the house that I will occupy." And the king granted them to me according to the good hand of my God upon me.

9. Then I went to the governors in the region beyond the River, and gave them the king's letters. Now the king had sent captains of the army and horsemen with me.

10. When Sanballat the Horonite and Tobiah the Ammonite official heard of it, they were deeply disturbed that a man had come to seek the well-being of the children of Israel.

11. So I came to Jerusalem and was there three days.

12. Then I arose in the night, I and a few men with me; I told no one what my God had put in my heart to do at Jerusalem; nor was there any animal with me, except the one on which I rode.

13. And I went out by night through the Valley Gate to the Serpent Well and the Refuse Gate, and viewed the walls of Jerusalem which were broken down and its gates which were burned with fire.

14. Then I went on to the Fountain Gate and to the King's Pool, but there was no room for the animal under me to pass.

15. So I went up in the night by the valley, and viewed the wall; then I turned back and entered by the Valley Gate, and so returned.

16. And the officials did not know where I had gone or what I had done; I had not yet told the Jews, the priests, the nobles, the officials, or the others who did the work.

17. Then I said to them, "You see the distress that we are in, how Jerusalem lies waste, and its gates are burned with fire. Come and let us build the wall of Jerusalem, that we may no longer be a reproach."

18. And I told them of the hand of my God which had been good upon me, and also of the king's words that he had spoken to me. So they said, "Let us rise up and build." Then they set their hands to this good work.

19. But when Sanballat the Horonite, Tobiah the Ammonite official, and Geshem the Arab heard of it, they laughed at us and despised us, and said, "What is this thing that you are doing? Will you rebel against the king?"

20. So I answered them, and said to them, "The God of heaven Himself will prosper us; therefore we His servants will arise and build, but you have no heritage or right or memorial in Jerusalem."

## Chapter 3

1. Then Eliashib the high priest rose up with his brethren the priests and built the Sheep Gate; they consecrated it and hung its doors. They built as far as the Tower of the Hundred, and consecrated it, then as far as the Tower of Hananel.

2. Next to Eliashib the men of Jericho built. And next to them Zaccur the son of Imri built.

3. Also the sons of Hassenaah built the Fish Gate; they laid its beams and hung its doors with its bolts and bars.

4. And next to them Meremoth the son of Urijah, the son of Koz, made repairs. Next to them Meshullam the son of Berechiah, the son of Meshezabel, made repairs. Next to them Zadok the son of Baana made repairs.

5. Next to them the Tekoites made repairs; but their nobles did not put their shoulders to the work of their Lord.

6. Moreover Jehoiada the son of Paseah and Meshullam the son of Besodeiah repaired the Old Gate; they laid its beams and hung its doors, with its bolts and bars.

7. And next to them Melatiah the Gibeonite, Jadon the Meronothite, the men of Gibeon and Mizpah, repaired the residence of the governor of the region beyond the River.

8. Next to him Uzziel the son of Harhaiah, one of the goldsmiths, made repairs. Also next to him Hananiah, one of the perfumers, made repairs; and they fortified Jerusalem as far as the Broad Wall.

9. And next to them Rephaiah the son of Hur, leader of half the district of Jerusalem, made repairs.

10. Next to them Jedaiah the son of Harumaph made repairs in front of his house. And next to him Hattush the son of Hashabniah made repairs.

11. Malchijah the son of Harim and Hashub the son of Pahath-Moab repaired another section, as well as the Tower of the Ovens.

12. And next to him was Shallum the son of Hallohesh, leader of half the district of Jerusalem; he and his daughters made repairs.

13. Hanun and the inhabitants of Zanoah repaired the Valley Gate. They built it, hung its doors with its bolts and bars, and repaired a thousand cubits of the wall as far as the Refuse Gate.

14. Malchijah the son of Rechab, leader of the district of Beth Haccerem, repaired the Refuse Gate; he built it and hung its doors with its bolts and bars.

15. Shallun the son of Col-Hozeh, leader of the district of Mizpah, repaired the Fountain Gate; he built it, covered it, hung its doors with its bolts and bars, and repaired the wall of the Pool of Shelah by the King's Garden, as far as the stairs that go down from the City of David.

16. After him Nehemiah the son of Azbuk, leader of half the district of Beth Zur, made repairs as far as the place in front of the tombs of David, to the man-made pool, and as far as the House of the Mighty.

17. After him the Levites, under Rehum the son of Bani, made repairs. Next to him Hashabiah, leader of half the district of Keilah, made repairs for his district.

18. After him their brethren, under Bavai the son of Henadad, leader of the other half of the district of Keilah, made repairs.

19. And next to him Ezer the son of Jeshua, the leader of Mizpah, repaired another section in front of the Ascent to the Armory at the buttress.

20. After him Baruch the son of Zabbai carefully repaired the other section, from the buttress to the door of the house of Eliashib the high priest.

21. After him Meremoth the son of Urijah, the son of Koz, repaired another section, from the door of the house of Eliashib to the end of the house of Eliashib.

22. And after him the priests, the men of the plain, made repairs.

23. After him Benjamin and Hasshub made repairs opposite their house. After them Azariah the son of Maaseiah, the son of Ananiah, made repairs by his house.

24. After him Binnui the son of Henadad repaired another section, from the house of Azariah to the buttress, even as far as the corner.

25. Palal the son of Uzai made repairs opposite the buttress, and on the tower which projects from the king's upper house that was by the court of the prison. After him Pedaiah the son of Parosh made repairs.

26. Moreover the Nethinim who dwelt in Ophel made repairs as far as the place in front of the Water Gate toward the east, and on the projecting tower.

27. After them the Tekoites repaired another section, next to the great projecting tower, and as far as the wall of Ophel.

28. Beyond the Horse Gate the priests made repairs, each in front of his own house.

29. After them Zadok the son of Immer made repairs in front of his own house. After him Shemaiah the son of Shechaniah, the keeper of the East Gate, made repairs.

30. After him Hananiah the son of Shelemiah, and Hanun, the sixth son of Zalaph, repaired another section. After him Meshullam the son of Berechiah made repairs in front of his dwelling.

31. After him Malchijah, one of the goldsmiths, made repairs as far as the house of the Nethinim and of the merchants, in front of the Miphkad Gate, and as far as the upper room at the corner.

32. And between the upper room at the corner, as far as the Sheep Gate, the goldsmiths and the merchants made repairs.

## Chapter 4

1. But it so happened, when Sanballat heard that we were rebuilding the wall, that he was furious and very indignant, and mocked the Jews.

2. And he spoke before his brethren and the army of Samaria, and said, "What are these feeble Jews doing? Will they fortify themselves? Will they offer sacrifices? Will they complete it in a day? Will they revive the stones from the heaps of rubbish--stones that are burned?"

3. Now Tobiah the Ammonite was beside him, and he said, "Whatever they build, if even a fox goes up on it, he will break down their stone wall."

4. Hear, O our God, for we are despised; turn their reproach on their own heads, and give them as plunder to a land of captivity!

5. Do not cover their iniquity, and do not let their sin be blotted out from before You; for they have provoked You to anger before the builders.

6. So we built the wall, and the entire wall was joined together up to half its height, for the people had a mind to work.

7. Now it happened, when Sanballat, Tobiah, the Arabs, the Ammonites, and the Ashdodites heard that the walls of Jerusalem were being restored and the gaps were beginning to be closed, that they became very angry,

8. and all of them conspired together to come and attack Jerusalem and create confusion.

9. Nevertheless we made our prayer to our God, and because of them we set a watch against them day and night.

10. Then Judah said, "The strength of the laborers is failing, and there is so much rubbish that we are not able to build the wall."

11. And our adversaries said, "They will neither know nor see anything, till we come into their midst and kill them and cause the work to cease."

12. So it was, when the Jews who dwelt near them came, that they told us ten times, "From whatever place you turn, they will be upon us."

13. Therefore I positioned men behind the lower parts of the wall, at the openings; and I set the people according to their families, with their swords, their spears, and their bows.

14. And I looked, and arose and said to the nobles, to the leaders, and to the rest of the people, "Do not be afraid of them. Remember the Lord, great and awesome, and fight for your brethren, your sons, your daughters, your wives, and your houses."

15. And it happened, when our enemies heard that it was known to us, and that God had brought their plot to nothing, that all of us returned to the wall, everyone to his work.

16. So it was, from that time on, that half of my servants worked at construction, while the other half held the spears, the shields, the bows, and wore armor; and the leaders were behind all the house of Judah.

17. Those who built on the wall, and those who carried burdens, loaded themselves so that with one hand they worked at construction, and with the other held a weapon.

18. Every one of the builders had his sword girded at his side as he built. And the one who sounded the trumpet was beside me.

19. Then I said to the nobles, the rulers, and the rest of the people, "The work is great and extensive, and we are separated far from one another on the wall.

20. Wherever you hear the sound of the trumpet, rally to us there. Our God will fight for us."

21. So we labored in the work, and half of the men held the spears from daybreak until the stars appeared.

22. At the same time I also said to the people, "Let each man and his servant stay at night in Jerusalem, that they may be our guard by night and a working party by day."

23. So neither I, my brethren, my servants, nor the men of the guard who followed me took off our clothes, except that everyone took them off for washing.

## Chapter 5

1. And there was a great outcry of the people and their wives against their Jewish brethren.

2. For there were those who said, "We, our sons, and our daughters are many; therefore let us get grain, that we may eat and live."

3. There were also some who said, "We have mortgaged our lands and vineyards and houses, that we might buy grain because of the famine."

4. There were also those who said, "We have borrowed money for the king's tax on our lands and vineyards.

5. Yet now our flesh is as the flesh of our brethren, our children as their children; and indeed we are forcing our sons and our daughters to be slaves, and some of our daughters have been brought into slavery. It is not in our power to redeem them, for other men have our lands and vineyards."

6. And I became very angry when I heard their outcry and these words.

7. After serious thought, I rebuked the nobles and rulers, and said to them, "Each of you is exacting usury from his brother." So I called a great assembly against them.

8. And I said to them, "According to our ability we have redeemed our Jewish brethren who were sold to the nations. Now indeed, will you even sell your brethren? Or should they be sold to us?" Then they were silenced and found nothing to say.

9. Then I said, "What you are doing is not good. Should you not walk in the fear of our God because of the reproach of the nations, our enemies?

10. I also, with my brethren and my servants, am lending them money and grain. Please, let us stop this usury!

11. Restore now to them, even this day, their lands, their vineyards, their olive groves, and their houses, also a hundredth of the money and the grain, the new wine and the oil, that you have charged them."

12. So they said, "We will restore it, and will require nothing from them; we will do as you say." Then I called the priests, and required an oath from them that they would do according to this promise.

13. Then I shook out the fold of my garment and said, "So may God shake out each man from his house, and from his property, who does not perform this promise. Even thus may he be shaken out and emptied." And all the assembly said, "Amen!" and praised the LORD. Then the people did according to this promise.

14. Moreover, from the time that I was appointed to be their governor in the land of Judah, from the twentieth year until the thirty-second year of King Artaxerxes, twelve years, neither I nor my brothers ate the governor's provisions.

15. But the former governors who were before me laid burdens on the people, and took from them bread and wine, besides forty shekels of silver. Yes, even their servants bore rule over the people, but I did not do so, because of the fear of God.

16. Indeed, I also continued the work on this wall, and we did not buy any land. All my servants were gathered there for the work.

17. And at my table were one hundred and fifty Jews and rulers, besides those who came to us from the nations around us.

18. Now that which was prepared daily was one ox and six choice sheep. Also fowl were prepared for me, and once every ten days an abundance of all kinds of wine. Yet in spite of this I did not demand the governor's provisions, because the bondage was heavy on this people.

19. Remember me, my God, for good, according to all that I have done for this people.

## Chapter 6

1. Now it happened when Sanballat, Tobiah, Geshem the Arab, and the rest of our enemies heard that I had rebuilt the wall, and that there were no breaks left in it (though at that time I had not hung the doors in the gates),

2. that Sanballat and Geshem sent to me, saying, "Come, let us meet together among the villages in the plain of Ono." But they thought to do me harm.

3. So I sent messengers to them, saying, "I am doing a great work, so that I cannot come down. Why should the work cease while I leave it and go down to you?"

4. But they sent me this message four times, and I answered them in the same manner.

5. Then Sanballat sent his servant to me as before, the fifth time, with an open letter in his hand.

6. In it was written: It is reported among the nations, and Geshem says, that you and the Jews plan to rebel; therefore, according to these rumors, you are rebuilding the wall, that you may be their king.

7. And you have also appointed prophets to proclaim concerning you at Jerusalem, saying, "There is a king in Judah!" Now these matters will be reported to the king. So come, therefore, and let us consult together.

8. Then I sent to him, saying, "No such things as you say are being done, but you invent them in your own heart."

9. For they all were trying to make us afraid, saying, "Their hands will be weakened in the work, and it will not be done." Now therefore, O God, strengthen my hands.

10. Afterward I came to the house of Shemaiah the son of Delaiah, the son of Mehetabel, who was a secret informer; and he said, "Let us meet together in the house of God, within the temple, and let us close the doors of the temple, for they are coming to kill you; indeed, at night they will come to kill you."

11. And I said, "Should such a man as I flee? And who is there such as I who would go into the temple to save his life? I will not go in!"

12. Then I perceived that God had not sent him at all, but that he pronounced this prophecy against me because Tobiah and Sanballat had hired him.

13. For this reason he was hired, that I should be afraid and act that way and sin, so that they might have cause for an evil report, that they might reproach me.

14. My God, remember Tobiah and Sanballat, according to these their works, and the prophetess Noadiah and the rest of the prophets who would have made me afraid.

15. So the wall was finished on the twenty-fifth day of Elul, in fifty-two days.

16. And it happened, when all our enemies heard of it, and all the nations around us saw these things, that they were very disheartened in their own eyes; for they perceived that this work was done by our God.

17. Also in those days the nobles of Judah sent many letters to Tobiah, and the letters of Tobiah came to them.

18. For many in Judah were pledged to him, because he was the son-in-law of Shechaniah the son of Arah, and his son Jehohanan had married the daughter of Meshullam the son of Berechiah.

19. Also they reported his good deeds before me, and reported my words to him. Tobiah sent letters to frighten me.

## Chapter 7

1. Then it was, when the wall was built and I had hung the doors, when the gatekeepers, the singers, and the Levites had been appointed,

2. that I gave the charge of Jerusalem to my brother Hanani, and Hananiah the leader of the citadel, for he was a faithful man and feared God more than many.

3. And I said to them, "Do not let the gates of Jerusalem be opened until the sun is hot; and while they stand guard, let them shut and bar the doors; and appoint guards from among the inhabitants of Jerusalem, one at his watch station and another in front of his own house."

4. Now the city was large and spacious, but the people in it were few, and the houses were not rebuilt.

5. Then my God put it into my heart to gather the nobles, the rulers, and the people, that they might be registered by genealogy. And I found a register of the genealogy of those who had come up in the first return, and found written in it:

6. These are the people of the province who came back from the captivity, of those who had been carried away, whom Nebuchadnezzar the king of Babylon had carried away, and who returned to Jerusalem and Judah, everyone to his city.

7. Those who came with Zerubbabel were Jeshua, Nehemiah, Azariah, Raamiah, Nahamani, Mordecai, Bilshan, Mispereth, Bigvai, Nehum, and Baanah. The number of the men of the people of Israel:

8. the sons of Parosh, two thousand one hundred and seventy-two;

9. the sons of Shephatiah, three hundred and seventy-two;

10. the sons of Arah, six hundred and fifty-two;

11. the sons of Pahath-Moab, of the sons of Jeshua and Joab, two thousand eight hundred and eighteen;

12. the sons of Elam, one thousand two hundred and fifty-four;

13. the sons of Zattu, eight hundred and forty-five;

14. the sons of Zaccai, seven hundred and sixty;

15. the sons of Binnui, six hundred and forty-eight;

16. the sons of Bebai, six hundred and twenty-eight;

17. the sons of Azgad, two thousand three hundred and twenty-two;

18. the sons of Adonikam, six hundred and sixty-seven;

19. the sons of Bigvai, two thousand and sixty-seven;

20. the sons of Adin, six hundred and fifty-five;

21. the sons of Ater of Hezekiah, ninety-eight;

22. the sons of Hashum, three hundred and twenty-eight;

23. the sons of Bezai, three hundred and twenty-four;

24. the sons of Hariph, one hundred and twelve;

25. the sons of Gibeon, ninety-five;

26. the men of Bethlehem and Netophah, one hundred and eighty-eight;

27. the men of Anathoth, one hundred and twenty-eight;

28. the men of Beth Azmaveth, forty-two;

29. the men of Kirjath Jearim, Chephirah, and Beeroth, seven hundred and forty-three;

30. the men of Ramah and Geba, six hundred and twenty-one;

31. the men of Michmas, one hundred and twenty-two;

32. the men of Bethel and Ai, one hundred and twenty-three;

33. the men of the other Nebo, fifty-two;

34. the sons of the other Elam, one thousand two hundred and fifty-four;

35. the sons of Harim, three hundred and twenty;

36. the sons of Jericho, three hundred and forty-five;

37. the sons of Lod, Hadid, and Ono, seven hundred and twenty-one;

38. the sons of Senaah, three thousand nine hundred and thirty.

39. The priests: the sons of Jedaiah, of the house of Jeshua, nine hundred and seventy-three;

40. the sons of Immer, one thousand and fifty-two;

41. the sons of Pashhur, one thousand two hundred and forty-seven;

42. the sons of Harim, one thousand and seventeen.

43. The Levites: the sons of Jeshua, of Kadmiel, and of the sons of Hodevah, seventy-four.

44. The singers: the sons of Asaph, one hundred and forty-eight.

45. The gatekeepers: the sons of Shallum, the sons of Ater, the sons of Talmon, the sons of Akkub, the sons of Hatita, the sons of Shobai, one hundred and thirty-eight.

46. The Nethinim: the sons of Ziha, the sons of Hasupha, the sons of Tabbaoth,

47. the sons of Keros, the sons of Sia, the sons of Padon,

48. the sons of Lebana, the sons of Hagaba, the sons of Salmai,

49. the sons of Hanan, the sons of Giddel, the sons of Gahar,

50. the sons of Reaiah, the sons of Rezin, the sons of Nekoda,

51. the sons of Gazzam, the sons of Uzza, the sons of Paseah,

52. the sons of Besai, the sons of Meunim, the sons of Nephishesim,

53. the sons of Bakbuk, the sons of Hakupha, the sons of Harhur,

54. the sons of Bazlith, the sons of Mehida, the sons of Harsha,

55. the sons of Barkos, the sons of Sisera, the sons of Tamah,

56. the sons of Neziah, and the sons of Hatipha.

57. The sons of Solomon's servants: the sons of Sotai, the sons of Sophereth, the sons of Perida,

58. the sons of Jaala, the sons of Darkon, the sons of Giddel,

59. the sons of Shephatiah, the sons of Hattil, the sons of Pochereth of Zebaim, and the sons of Amon.

60. All the Nethinim, and the sons of Solomon's servants, were three hundred and ninety-two.

61. And these were the ones who came up from Tel Melah, Tel Harsha, Cherub, Addon, and Immer, but they could not identify their father's house nor their lineage, whether they were of Israel:

62. the sons of Delaiah, the sons of Tobiah, the sons of Nekoda, six hundred and forty-two;

63. and of the priests: the sons of Habaiah, the sons of Koz, the sons of Barzillai, who took a wife of the daughters of Barzillai the Gileadite, and was called by their name.

64. These sought their listing among those who were registered by genealogy, but it was not found; therefore they were excluded from the priesthood as defiled.

65. And the governor said to them that they should not eat of the most holy things till a priest could consult with the Urim and Thummim.

66. Altogether the whole assembly was forty-two thousand three hundred and sixty,

67. besides their male and female servants, of whom there were seven thousand three hundred and thirty-seven; and they had two hundred and forty-five men and women singers.

68. Their horses were seven hundred and thirty-six, their mules two hundred and forty-five,

69. their camels four hundred and thirty-five, and donkeys six thousand seven hundred and twenty.

70. And some of the heads of the fathers' houses gave to the work. The governor gave to the treasury one thousand gold drachmas, fifty basins, and five hundred and thirty priestly garments.

71. Some of the heads of the fathers' houses gave to the treasury of the work twenty thousand gold drachmas, and two thousand two hundred silver minas.

72. And that which the rest of the people gave was twenty thousand gold drachmas, two thousand silver minas, and sixty-seven priestly garments.

73. So the priests, the Levites, the gatekeepers, the singers, some of the people, the Nethinim, and all Israel dwelt in their cities. When the seventh month came, the children of Israel were in their cities.

## Chapter 8

1. Now all the people gathered together as one man in the open square that was in front of the Water Gate; and they told Ezra the scribe to bring the Book of the Law of Moses, which the LORD had commanded Israel.

2. So Ezra the priest brought the Law before the assembly of men and women and all who could hear with understanding on the first day of the seventh month.

3. Then he read from it in the open square that was in front of the Water Gate from morning until midday, before the men and women and those who could understand; and the ears of all the people were attentive to the Book of the Law.

4. So Ezra the scribe stood on a platform of wood which they had made for the purpose; and beside him, at his right hand, stood Mattithiah, Shema, Anaiah, Urijah, Hilkiah, and Maaseiah; and at his left hand Pedaiah, Mishael, Malchijah, Hashum, Hashbadana, Zechariah, and Meshullam.

5. And Ezra opened the book in the sight of all the people, for he was standing above all the people; and when he opened it, all the people stood up.

6. And Ezra blessed the LORD, the great God. Then all the people answered, "Amen, Amen!" while lifting up their hands. And they bowed their heads and worshiped the LORD with their faces to the ground.

7. Also Jeshua, Bani, Sherebiah, Jamin, Akkub, Shabbethai, Hodijah, Maaseiah, Kelita, Azariah, Jozabad, Hanan, Pelaiah, and the Levites, helped the people to understand the Law; and the people stood in their place.

8. So they read distinctly from the book, in the Law of God; and they gave the sense, and helped them to understand the reading.

9. And Nehemiah, who was the governor, Ezra the priest and scribe, and the Levites who taught the people said to all the people, "This day is holy to the LORD your God; do not mourn nor weep." For all the people wept, when they heard the words of the Law.

10. Then he said to them, "Go your way, eat the fat, drink the sweet, and send portions to those for whom nothing is prepared; for this day is holy to our Lord. Do not sorrow, for the joy of the LORD is your strength."

11. So the Levites quieted all the people, saying, "Be still, for the day is holy; do not be grieved."

12. And all the people went their way to eat and drink, to send portions and rejoice greatly, because they understood the words that were declared to them.

13. Now on the second day the heads of the fathers' houses of all the people, with the priests and Levites, were gathered to Ezra the scribe, in order to understand the words of the Law.

14. And they found written in the Law, which the LORD had commanded by Moses, that the children of Israel should dwell in booths during the feast of the seventh month,

15. and that they should announce and proclaim in all their cities and in Jerusalem, saying, "Go out to the mountain, and bring olive branches, branches of oil trees, myrtle branches, palm branches, and branches of leafy trees, to make booths, as it is written."

16. Then the people went out and brought them and made themselves booths, each one on the roof of his house, or in their courtyards or the courts of the house of God, and in the open square of the Water Gate and in the open square of the Gate of Ephraim.

17. So the whole assembly of those who had returned from the captivity made booths and sat under the booths; for since the days of Joshua the son of Nun until that day the children of Israel had not done so. And there was very great gladness.

18. Also day by day, from the first day until the last day, he read from the Book of the Law of God. And they kept the feast seven days; and on the eighth day there was a sacred assembly, according to the prescribed manner.

## Chapter 9

1. Now on the twenty-fourth day of this month the children of Israel were assembled with fasting, in sackcloth, and with dust on their heads.

2. Then those of Israelite lineage separated themselves from all foreigners; and they stood and confessed their sins and the iniquities of their fathers.

3. And they stood up in their place and read from the Book of the Law of the LORD their God for one-fourth of the day; and for another fourth they confessed and worshiped the LORD their God.

4. Then Jeshua, Bani, Kadmiel, Shebaniah, Bunni, Sherebiah, Bani, and Chenani stood on the stairs of the Levites and cried out with a loud voice to the LORD their God.

5. And the Levites, Jeshua, Kadmiel, Bani, Hashabniah, Sherebiah, Hodijah, Shebaniah, and Pethahiah, said: "Stand up and bless the LORD your God Forever and ever! "Blessed be Your glorious name, Which is exalted above all blessing and praise!

6. You alone are the LORD; You have made heaven, The heaven of heavens, with all their host, The earth and everything on it, The seas and all that is in them, And You preserve them all. The host of heaven worships You.

7. "You are the LORD God, Who chose Abram, And brought him out of Ur of the Chaldeans, And gave him the name Abraham;

8. You found his heart faithful before You, And made a covenant with him To give the land of the Canaanites, The Hittites, the Amorites, The Perizzites, the Jebusites, And the Girgashites-- To give it to his descendants. You have performed Your words, For You are righteous.

9. "You saw the affliction of our fathers in Egypt, And heard their cry by the Red Sea.

10. You showed signs and wonders against Pharaoh, Against all his servants, And against all the people of his land. For You knew that they acted proudly against them. So You made a name for Yourself, as it is this day.

11. And You divided the sea before them, So that they went through the midst of the sea on the dry land; And their persecutors You threw into the deep, As a stone into the mighty waters.

12. Moreover You led them by day with a cloudy pillar, And by night with a pillar of fire, To give them light on the road Which they should travel.

13. "You came down also on Mount Sinai, And spoke with them from heaven, And gave them just ordinances and true laws, Good statutes and commandments.

14. You made known to them Your holy Sabbath, And commanded them precepts, statutes and laws, By the hand of Moses Your servant.

15. You gave them bread from heaven for their hunger, And brought them water out of the rock for their thirst, And told them to go in to possess the land Which You had sworn to give them.

16. "But they and our fathers acted proudly, Hardened their necks, And did not heed Your commandments.

17. They refused to obey, And they were not mindful of Your wonders That You did among them. But they hardened their necks, And in their rebellion They appointed a leader To return to their bondage. But You are God, Ready to pardon, Gracious and merciful, Slow to anger, Abundant in kindness, And did not forsake them.

18. "Even when they made a molded calf for themselves, And said, "This is your god That brought you up out of Egypt,' And worked great provocations,

19. Yet in Your manifold mercies You did not forsake them in the wilderness. The pillar of the cloud did not depart from them by day, To lead them on the road; Nor the pillar of fire by night, To show them light, And the way they should go.

20. You also gave Your good Spirit to instruct them, And did not withhold Your manna from their mouth, And gave them water for their thirst.

21. Forty years You sustained them in the wilderness; They lacked nothing; Their clothes did not wear out And their feet did not swell.

22. "Moreover You gave them kingdoms and nations, And divided them into districts. So they took possession of the land of Sihon, The land of the king of Heshbon, And the land of Og king of Bashan.

23. You also multiplied their children as the stars of heaven, And brought them into the land Which You had told their fathers To go in and possess.

24. So the people went in And possessed the land; You subdued before them the inhabitants of the land, The Canaanites, And gave them into their hands, With their kings And the people of the land, That they might do with them as they wished.

25. And they took strong cities and a rich land, And possessed houses full of all goods, Cisterns already dug, vineyards, olive groves, And fruit trees in abundance. So they ate and were filled and grew fat, And delighted themselves in Your great goodness.

26. "Nevertheless they were disobedient And rebelled against You, Cast Your law behind their backs And killed Your prophets, who testified against them To turn them to Yourself; And they worked great provocations.

27. Therefore You delivered them into the hand of their enemies, Who oppressed them; And in the time of their trouble, When they cried to You, You heard from heaven; And according to Your abundant mercies You gave them deliverers who saved them From the hand of their enemies.

28. "But after they had rest, They again did evil before You. Therefore You left them in the hand of their enemies, So that they had dominion over them; Yet when they returned and cried out to You, You heard from heaven; And many times You delivered them according to Your mercies,

29. And testified against them, That You might bring them back to Your law. Yet they acted proudly, And did not heed Your commandments, But sinned against Your judgments, "Which if a man does, he shall live by them.' And they shrugged their shoulders, Stiffened their necks, And would not hear.

30. Yet for many years You had patience with them, And testified against them by Your Spirit in Your prophets. Yet they would not listen; Therefore You gave them into the hand of the peoples of the lands.

31. Nevertheless in Your great mercy You did not utterly consume them nor forsake them; For You are God, gracious and merciful.

32. "Now therefore, our God, The great, the mighty, and awesome God, Who keeps covenant and mercy: Do not let all the trouble seem small before You That has come upon us, Our kings and our princes, Our priests and our prophets, Our fathers and on all Your people, From the days of the kings of Assyria until this day.

33. However You are just in all that has befallen us; For You have dealt faithfully, But we have done wickedly.

34. Neither our kings nor our princes, Our priests nor our fathers, Have kept Your law, Nor heeded Your commandments and Your testimonies, With which You testified against them.

35. For they have not served You in their kingdom, Or in the many good things that You gave them, Or in the large and rich land which You set before them; Nor did they turn from their wicked works.

36. "Here we are, servants today! And the land that You gave to our fathers, To eat its fruit and its bounty, Here we are, servants in it!

37. And it yields much increase to the kings You have set over us, Because of our sins; Also they have dominion over our bodies and our cattle At their pleasure; And we are in great distress.

38. "And because of all this, We make a sure covenant and write it; Our leaders, our Levites, and our priests seal it."

## Chapter 10

1. Now those who placed their seal on the document were: Nehemiah the governor, the son of Hacaliah, and Zedekiah,

2. Seraiah, Azariah, Jeremiah,

3. Pashhur, Amariah, Malchijah,

4. Hattush, Shebaniah, Malluch,

5. Harim, Meremoth, Obadiah,

6. Daniel, Ginnethon, Baruch,

7. Meshullam, Abijah, Mijamin,

8. Maaziah, Bilgai, and Shemaiah. These were the priests.

9. The Levites: Jeshua the son of Azaniah, Binnui of the sons of Henadad, and Kadmiel.

10. Their brethren: Shebaniah, Hodijah, Kelita, Pelaiah, Hanan,

11. Micha, Rehob, Hashabiah,

12. Zaccur, Sherebiah, Shebaniah,

13. Hodijah, Bani, and Beninu.

14. The leaders of the people: Parosh, Pahath-Moab, Elam, Zattu, Bani,

15. Bunni, Azgad, Bebai,

16. Adonijah, Bigvai, Adin,

17. Ater, Hezekiah, Azzur,

18. Hodijah, Hashum, Bezai,

19. Hariph, Anathoth, Nebai,

20. Magpiash, Meshullam, Hezir,

21. Meshezabel, Zadok, Jaddua,

22. Pelatiah, Hanan, Anaiah,

23. Hoshea, Hananiah, Hasshub,

24. Hallohesh, Pilha, Shobek,

25. Rehum, Hashabnah, Maaseiah,

26. Ahijah, Hanan, Anan,

27. Malluch, Harim, and Baanah.

28. Now the rest of the people--the priests, the Levites, the gatekeepers, the singers, the Nethinim, and all those who had separated themselves from the peoples of the lands to the Law of God, their wives, their sons, and their daughters, everyone who had knowledge and understanding--

29. these joined with their brethren, their nobles, and entered into a curse and an oath to walk in God's Law, which was given by Moses the servant of God, and to observe and do all the commandments of the LORD our Lord, and His ordinances and His statutes:

30. We would not give our daughters as wives to the peoples of the land, nor take their daughters for our sons;

31. if the peoples of the land brought wares or any grain to sell on the Sabbath day, we would not buy it from them on the Sabbath, or on a holy day; and we would forego the seventh year's produce and the exacting of every debt.

32. Also we made ordinances for ourselves, to exact from ourselves yearly one-third of a shekel for the service of the house of our God:

33. for the showbread, for the regular grain offering, for the regular burnt offering of the Sabbaths, the New Moons, and the set feasts; for the holy things, for the sin offerings to make atonement for Israel, and all the work of the house of our God.

34. We cast lots among the priests, the Levites, and the people, for bringing the wood offering into the house of our God, according to our fathers' houses, at the appointed times year by year, to burn on the altar of the LORD our God as it is written in the Law.

35. And we made ordinances to bring the firstfruits of our ground and the firstfruits of all fruit of all trees, year by year, to the house of the LORD;

36. to bring the firstborn of our sons and our cattle, as it is written in the Law, and the firstborn of our herds and our flocks, to the house of our God, to the priests who minister in the house of our God;

37. to bring the firstfruits of our dough, our offerings, the fruit from all kinds of trees, the new wine and oil, to the priests, to the storerooms of the house of our God; and to bring the tithes of our land to the Levites, for the Levites should receive the tithes in all our farming communities.

38. And the priest, the descendant of Aaron, shall be with the Levites when the Levites receive tithes; and the Levites shall bring up a tenth of the tithes to the house of our God, to the rooms of the storehouse.

39. For the children of Israel and the children of Levi shall bring the offering of the grain, of the new wine and the oil, to the storerooms where the articles of the sanctuary are, where the priests who minister and the gatekeepers and the singers are; and we will not neglect the house of our God.

## Chapter 11

1. Now the leaders of the people dwelt at Jerusalem; the rest of the people cast lots to bring one out of ten to dwell in Jerusalem, the holy city, and nine-tenths were to dwell in other cities.

2. And the people blessed all the men who willingly offered themselves to dwell at Jerusalem.

3. These are the heads of the province who dwelt in Jerusalem. (But in the cities of Judah everyone dwelt in his own possession in their cities--Israelites, priests, Levites, Nethinim, and descendants of Solomon's servants.)

4. Also in Jerusalem dwelt some of the children of Judah and of the children of Benjamin. The children of Judah: Athaiah the son of Uzziah, the son of Zechariah, the son of Amariah, the son of Shephatiah, the son of Mahalalel, of the children of Perez;

5. and Maaseiah the son of Baruch, the son of Col-Hozeh, the son of Hazaiah, the son of Adaiah, the son of Joiarib, the son of Zechariah, the son of Shiloni.

6. All the sons of Perez who dwelt at Jerusalem were four hundred and sixty-eight valiant men.

7. And these are the sons of Benjamin: Sallu the son of Meshullam, the son of Joed, the son of Pedaiah, the son of Kolaiah, the son of Maaseiah, the son of Ithiel, the son of Jeshaiah;

8. and after him Gabbai and Sallai, nine hundred and twenty-eight.

9. Joel the son of Zichri was their overseer, and Judah the son of Senuah was second over the city.

10. Of the priests: Jedaiah the son of Joiarib, and Jachin;

11. Seraiah the son of Hilkiah, the son of Meshullam, the son of Zadok, the son of Meraioth, the son of Ahitub, was the leader of the house of God.

12. Their brethren who did the work of the house were eight hundred and twenty-two; and Adaiah the son of Jeroham, the son of Pelaliah, the son of Amzi, the son of Zechariah, the son of Pashhur, the son of Malchijah,

13. and his brethren, heads of the fathers' houses, were two hundred and forty-two; and Amashai the son of Azarel, the son of Ahzai, the son of Meshillemoth, the son of Immer,

14. and their brethren, mighty men of valor, were one hundred and twenty-eight. Their overseer was Zabdiel the son of one of the great men.

15. Also of the Levites: Shemaiah the son of Hasshub, the son of Azrikam, the son of Hashabiah, the son of Bunni;

16. Shabbethai and Jozabad, of the heads of the Levites, had the oversight of the business outside of the house of God;

17. Mattaniah the son of Micha, the son of Zabdi, the son of Asaph, the leader who began the thanksgiving with prayer; Bakbukiah, the second among his brethren; and Abda the son of Shammua, the son of Galal, the son of Jeduthun.

18. All the Levites in the holy city were two hundred and eighty-four.

19. Moreover the gatekeepers, Akkub, Talmon, and their brethren who kept the gates, were one hundred and seventy-two.

20. And the rest of Israel, of the priests and Levites, were in all the cities of Judah, everyone in his inheritance.

21. But the Nethinim dwelt in Ophel. And Ziha and Gishpa were over the Nethinim.

22. Also the overseer of the Levites at Jerusalem was Uzzi the son of Bani, the son of Hashabiah, the son of Mattaniah, the son of Micha, of the sons of Asaph, the singers in charge of the service of the house of God.

23. For it was the king's command concerning them that a certain portion should be for the singers, a quota day by day.

24. Pethahiah the son of Meshezabel, of the children of Zerah the son of Judah, was the king's deputy in all matters concerning the people.

25. And as for the villages with their fields, some of the children of Judah dwelt in Kirjath Arba and its villages, Dibon and its villages, Jekabzeel and its villages;

26. in Jeshua, Moladah, Beth Pelet,

27. Hazar Shual, and Beersheba and its villages;

28. in Ziklag and Meconah and its villages;

29. in En Rimmon, Zorah, Jarmuth,

30. Zanoah, Adullam, and their villages; in Lachish and its fields; in Azekah and its villages. They dwelt from Beersheba to the Valley of Hinnom.

31. Also the children of Benjamin from Geba dwelt in Michmash, Aija, and Bethel, and their villages;

32. in Anathoth, Nob, Ananiah;

33. in Hazor, Ramah, Gittaim;

34. in Hadid, Zeboim, Neballat;

35. in Lod, Ono, and the Valley of Craftsmen.

36. Some of the Judean divisions of Levites were in Benjamin.

## Chapter 12

1. Now these are the priests and the Levites who came up with Zerubbabel the son of Shealtiel, and Jeshua: Seraiah, Jeremiah, Ezra,

2. Amariah, Malluch, Hattush,

3. Shechaniah, Rehum, Meremoth,

4. Iddo, Ginnethoi, Abijah,

5. Mijamin, Maadiah, Bilgah,

6. Shemaiah, Joiarib, Jedaiah,

7. Sallu, Amok, Hilkiah, and Jedaiah. These were the heads of the priests and their brethren in the days of Jeshua.

8. Moreover the Levites were Jeshua, Binnui, Kadmiel, Sherebiah, Judah, and Mattaniah who led the thanksgiving psalms, he and his brethren.

9. Also Bakbukiah and Unni, their brethren, stood across from them in their duties.

10. Jeshua begot Joiakim, Joiakim begot Eliashib, Eliashib begot Joiada,

11. Joiada begot Jonathan, and Jonathan begot Jaddua.

12. Now in the days of Joiakim, the priests, the heads of the fathers' houses were: of Seraiah, Meraiah; of Jeremiah, Hananiah;

13. of Ezra, Meshullam; of Amariah, Jehohanan;

14. of Melichu, Jonathan; of Shebaniah, Joseph;

15. of Harim, Adna; of Meraioth, Helkai;

16. of Iddo, Zechariah; of Ginnethon, Meshullam;

17. of Abijah, Zichri; the son of Minjamin; of Moadiah, Piltai;

18. of Bilgah, Shammua; of Shemaiah, Jehonathan;

19. of Joiarib, Mattenai; of Jedaiah, Uzzi;

20. of Sallai, Kallai; of Amok, Eber;

21. of Hilkiah, Hashabiah; and of Jedaiah, Nethanel.

22. During the reign of Darius the Persian, a record was also kept of the Levites and priests who had been heads of their fathers' houses in the days of Eliashib, Joiada, Johanan, and Jaddua.

23. The sons of Levi, the heads of the fathers' houses until the days of Johanan the son of Eliashib, were written in the book of the chronicles.

24. And the heads of the Levites were Hashabiah, Sherebiah, and Jeshua the son of Kadmiel, with their brothers across from them, to praise and give thanks, group alternating with group, according to the command of David the man of God.

25. Mattaniah, Bakbukiah, Obadiah, Meshullam, Talmon, and Akkub were gatekeepers keeping the watch at the storerooms of the gates.

26. These lived in the days of Joiakim the son of Jeshua, the son of Jozadak, and in the days of Nehemiah the governor, and of Ezra the priest, the scribe.

27. Now at the dedication of the wall of Jerusalem they sought out the Levites in all their places, to bring them to Jerusalem to celebrate the dedication with gladness, both with thanksgivings and singing, with cymbals and stringed instruments and harps.

28. And the sons of the singers gathered together from the countryside around Jerusalem, from the villages of the Netophathites,

29. from the house of Gilgal, and from the fields of Geba and Azmaveth; for the singers had built themselves villages all around Jerusalem.

30. Then the priests and Levites purified themselves, and purified the people, the gates, and the wall.

31. So I brought the leaders of Judah up on the wall, and appointed two large thanksgiving choirs. One went to the right hand on the wall toward the Refuse Gate.

32. After them went Hoshaiah and half of the leaders of Judah,

33. and Azariah, Ezra, Meshullam,

34. Judah, Benjamin, Shemaiah, Jeremiah,

35. and some of the priests' sons with trumpets--Zechariah the son of Jonathan, the son of Shemaiah, the son of Mattaniah, the son of Michaiah, the son of Zaccur, the son of Asaph,

36. and his brethren, Shemaiah, Azarel, Milalai, Gilalai, Maai, Nethanel, Judah, and Hanani, with the musical instruments of David the man of God. And Ezra the scribe went before them.

37. By the Fountain Gate, in front of them, they went up the stairs of the City of David, on the stairway of the wall, beyond the house of David, as far as the Water Gate eastward.

38. The other thanksgiving choir went the opposite way, and I was behind them with half of the people on the wall, going past the Tower of the Ovens as far as the Broad Wall,

39. and above the Gate of Ephraim, above the Old Gate, above the Fish Gate, the Tower of Hananel, the Tower of the Hundred, as far as the Sheep Gate; and they stopped by the Gate of the Prison.

40. So the two thanksgiving choirs stood in the house of God, likewise I and the half of the rulers with me;

41. and the priests, Eliakim, Maaseiah, Minjamin, Michaiah, Elioenai, Zechariah, and Hananiah, with trumpets;

42. also Maaseiah, Shemaiah, Eleazar, Uzzi, Jehohanan, Malchijah, Elam, and Ezer. The singers sang loudly with Jezrahiah the director.

43. Also that day they offered great sacrifices, and rejoiced, for God had made them rejoice with great joy; the women and the children also rejoiced, so that the joy of Jerusalem was heard afar off.

44. And at the same time some were appointed over the rooms of the storehouse for the offerings, the firstfruits, and the tithes, to gather into them from the fields of the cities the portions specified by the Law for the priests and Levites; for Judah rejoiced over the priests and Levites who ministered.

45. Both the singers and the gatekeepers kept the charge of their God and the charge of the purification, according to the command of David and Solomon his son.

46. For in the days of David and Asaph of old there were chiefs of the singers, and songs of praise and thanksgiving to God.

47. In the days of Zerubbabel and in the days of Nehemiah all Israel gave the portions for the singers and the gatekeepers, a portion for each day. They also consecrated holy things for the Levites, and the Levites consecrated them for the children of Aaron.

## Chapter 13

1. On that day they read from the Book of Moses in the hearing of the people, and in it was found written that no Ammonite or Moabite should ever come into the assembly of God,

2. because they had not met the children of Israel with bread and water, but hired Balaam against them to curse them. However, our God turned the curse into a blessing.

3. So it was, when they had heard the Law, that they separated all the mixed multitude from Israel.

4. Now before this, Eliashib the priest, having authority over the storerooms of the house of our God, was allied with Tobiah.

5. And he had prepared for him a large room, where previously they had stored the grain offerings, the frankincense, the articles, the tithes of grain, the new wine and oil, which were commanded to be given to the Levites and singers and gatekeepers, and the offerings for the priests.

6. But during all this I was not in Jerusalem, for in the thirty-second year of Artaxerxes king of Babylon I had returned to the king. Then after certain days I obtained leave from the king,

7. and I came to Jerusalem and discovered the evil that Eliashib had done for Tobiah, in preparing a room for him in the courts of the house of God.

8. And it grieved me bitterly; therefore I threw all the household goods of Tobiah out of the room.

9. Then I commanded them to cleanse the rooms; and I brought back into them the articles of the house of God, with the grain offering and the frankincense.

10. I also realized that the portions for the Levites had not been given them; for each of the Levites and the singers who did the work had gone back to his field.

11. So I contended with the rulers, and said, "Why is the house of God forsaken?" And I gathered them together and set them in their place.

12. Then all Judah brought the tithe of the grain and the new wine and the oil to the storehouse.

13. And I appointed as treasurers over the storehouse Shelemiah the priest and Zadok the scribe, and of the Levites, Pedaiah; and next to them was Hanan the son of Zaccur, the son of Mattaniah; for they were considered faithful, and their task was to distribute to their brethren.

14. Remember me, O my God, concerning this, and do not wipe out my good deeds that I have done for the house of my God, and for its services!

15. In those days I saw people in Judah treading wine presses on the Sabbath, and bringing in sheaves, and loading donkeys with wine, grapes, figs, and all kinds of burdens, which they brought into Jerusalem on the Sabbath day. And I warned them about the day on which they were selling provisions.

16. Men of Tyre dwelt there also, who brought in fish and all kinds of goods, and sold them on the Sabbath to the children of Judah, and in Jerusalem.

17. Then I contended with the nobles of Judah, and said to them, "What evil thing is this that you do, by which you profane the Sabbath day?

18. Did not your fathers do thus, and did not our God bring all this disaster on us and on this city? Yet you bring added wrath on Israel by profaning the Sabbath."

19. So it was, at the gates of Jerusalem, as it began to be dark before the Sabbath, that I commanded the gates to be shut, and charged that they must not be opened till after the Sabbath. Then I posted some of my servants at the gates, so that no burdens would be brought in on the Sabbath day.

20. Now the merchants and sellers of all kinds of wares lodged outside Jerusalem once or twice.

21. Then I warned them, and said to them, "Why do you spend the night around the wall? If you do so again, I will lay hands on you!" From that time on they came no more on the Sabbath.

22. And I commanded the Levites that they should cleanse themselves, and that they should go and guard the gates, to sanctify the Sabbath day. Remember me, O my God, concerning this also, and spare me according to the greatness of Your mercy!

23. In those days I also saw Jews who had married women of Ashdod, Ammon, and Moab.

24. And half of their children spoke the language of Ashdod, and could not speak the language of Judah, but spoke according to the language of one or the other people.

25. So I contended with them and cursed them, struck some of them and pulled out their hair, and made them swear by God, saying, "You shall not give your daughters as wives to their sons, nor take their daughters for your sons or yourselves.

26. Did not Solomon king of Israel sin by these things? Yet among many nations there was no king like him, who was beloved of his God; and God made him king over all Israel. Nevertheless pagan women caused even him to sin.

27. Should we then hear of your doing all this great evil, transgressing against our God by marrying pagan women?"

28. And one of the sons of Joiada, the son of Eliashib the high priest, was a son-in-law of Sanballat the Horonite; therefore I drove him from me.

29. Remember them, O my God, because they have defiled the priesthood and the covenant of the priesthood and the Levites.

30. Thus I cleansed them of everything pagan. I also assigned duties to the priests and the Levites, each to his service,

31. and to bringing the wood offering and the firstfruits at appointed times. Remember me, O my God, for good!


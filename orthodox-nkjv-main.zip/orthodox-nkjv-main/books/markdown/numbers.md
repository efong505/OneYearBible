# numbers

## Chapter 1

1. Now the LORD spoke to Moses in the Wilderness of Sinai, in the tabernacle of meeting, on the first day of the second month, in the second year after they had come out of the land of Egypt, saying:

2. "Take a census of all the congregation of the children of Israel, by their families, by their fathers' houses, according to the number of names, every male individually,

3. from twenty years old and above--all who are able to go to war in Israel. You and Aaron shall number them by their armies.

4. And with you there shall be a man from every tribe, each one the head of his father's house.

5. "These are the names of the men who shall stand with you: from Reuben, Elizur the son of Shedeur;

6. from Simeon, Shelumiel the son of Zurishaddai;

7. from Judah, Nahshon the son of Amminadab;

8. from Issachar, Nethanel the son of Zuar;

9. from Zebulun, Eliab the son of Helon;

10. from the sons of Joseph: from Ephraim, Elishama the son of Ammihud; from Manasseh, Gamaliel the son of Pedahzur;

11. from Benjamin, Abidan the son of Gideoni;

12. from Dan, Ahiezer the son of Ammishaddai;

13. from Asher, Pagiel the son of Ocran;

14. from Gad, Eliasaph the son of Deuel;

15. from Naphtali, Ahira the son of Enan."

16. These were chosen from the congregation, leaders of their fathers' tribes, heads of the divisions in Israel.

17. Then Moses and Aaron took these men who had been mentioned by name,

18. and they assembled all the congregation together on the first day of the second month; and they recited their ancestry by families, by their fathers' houses, according to the number of names, from twenty years old and above, each one individually.

19. As the LORD commanded Moses, so he numbered them in the Wilderness of Sinai.

20. Now the children of Reuben, Israel's oldest son, their genealogies by their families, by their fathers' house, according to the number of names, every male individually, from twenty years old and above, all who were able to go to war:

21. those who were numbered of the tribe of Reuben were forty-six thousand five hundred.

22. From the children of Simeon, their genealogies by their families, by their fathers' house, of those who were numbered, according to the number of names, every male individually, from twenty years old and above, all who were able to go to war:

23. those who were numbered of the tribe of Simeon were fifty-nine thousand three hundred.

24. From the children of Gad, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

25. those who were numbered of the tribe of Gad were forty-five thousand six hundred and fifty.

26. From the children of Judah, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

27. those who were numbered of the tribe of Judah were seventy-four thousand six hundred.

28. From the children of Issachar, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

29. those who were numbered of the tribe of Issachar were fifty-four thousand four hundred.

30. From the children of Zebulun, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

31. those who were numbered of the tribe of Zebulun were fifty-seven thousand four hundred.

32. From the sons of Joseph, the children of Ephraim, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

33. those who were numbered of the tribe of Ephraim were forty thousand five hundred.

34. From the children of Manasseh, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

35. those who were numbered of the tribe of Manasseh were thirty-two thousand two hundred.

36. From the children of Benjamin, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

37. those who were numbered of the tribe of Benjamin were thirty-five thousand four hundred.

38. From the children of Dan, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

39. those who were numbered of the tribe of Dan were sixty-two thousand seven hundred.

40. From the children of Asher, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

41. those who were numbered of the tribe of Asher were forty-one thousand five hundred.

42. From the children of Naphtali, their genealogies by their families, by their fathers' house, according to the number of names, from twenty years old and above, all who were able to go to war:

43. those who were numbered of the tribe of Naphtali were fifty-three thousand four hundred.

44. These are the ones who were numbered, whom Moses and Aaron numbered, with the leaders of Israel, twelve men, each one representing his father's house.

45. So all who were numbered of the children of Israel, by their fathers' houses, from twenty years old and above, all who were able to go to war in Israel--

46. all who were numbered were six hundred and three thousand five hundred and fifty.

47. But the Levites were not numbered among them by their fathers' tribe;

48. for the LORD had spoken to Moses, saying:

49. "Only the tribe of Levi you shall not number, nor take a census of them among the children of Israel;

50. but you shall appoint the Levites over the tabernacle of the Testimony, over all its furnishings, and over all things that belong to it; they shall carry the tabernacle and all its furnishings; they shall attend to it and camp around the tabernacle.

51. And when the tabernacle is to go forward, the Levites shall take it down; and when the tabernacle is to be set up, the Levites shall set it up. The outsider who comes near shall be put to death.

52. The children of Israel shall pitch their tents, everyone by his own camp, everyone by his own standard, according to their armies;

53. but the Levites shall camp around the tabernacle of the Testimony, that there may be no wrath on the congregation of the children of Israel; and the Levites shall keep charge of the tabernacle of the Testimony."

54. Thus the children of Israel did; according to all that the LORD commanded Moses, so they did.

## Chapter 2

1. And the LORD spoke to Moses and Aaron, saying:

2. "Everyone of the children of Israel shall camp by his own standard, beside the emblems of his father's house; they shall camp some distance from the tabernacle of meeting.

3. On the east side, toward the rising of the sun, those of the standard of the forces with Judah shall camp according to their armies; and Nahshon the son of Amminadab shall be the leader of the children of Judah."

4. And his army was numbered at seventy-four thousand six hundred.

5. "Those who camp next to him shall be the tribe of Issachar, and Nethanel the son of Zuar shall be the leader of the children of Issachar."

6. And his army was numbered at fifty-four thousand four hundred.

7. "Then comes the tribe of Zebulun, and Eliab the son of Helon shall be the leader of the children of Zebulun."

8. And his army was numbered at fifty-seven thousand four hundred.

9. "All who were numbered according to their armies of the forces with Judah, one hundred and eighty-six thousand four hundred--these shall break camp first.

10. "On the south side shall be the standard of the forces with Reuben according to their armies, and the leader of the children of Reuben shall be Elizur the son of Shedeur."

11. And his army was numbered at forty-six thousand five hundred.

12. "Those who camp next to him shall be the tribe of Simeon, and the leader of the children of Simeon shall be Shelumiel the son of Zurishaddai."

13. And his army was numbered at fifty-nine thousand three hundred.

14. "Then comes the tribe of Gad, and the leader of the children of Gad shall be Eliasaph the son of Reuel."

15. And his army was numbered at forty-five thousand six hundred and fifty.

16. "All who were numbered according to their armies of the forces with Reuben, one hundred and fifty-one thousand four hundred and fifty--they shall be the second to break camp.

17. "And the tabernacle of meeting shall move out with the camp of the Levites in the middle of the camps; as they camp, so they shall move out, everyone in his place, by their standards.

18. "On the west side shall be the standard of the forces with Ephraim according to their armies, and the leader of the children of Ephraim shall be Elishama the son of Ammihud."

19. And his army was numbered at forty thousand five hundred.

20. "Next to him comes the tribe of Manasseh, and the leader of the children of Manasseh shall be Gamaliel the son of Pedahzur."

21. And his army was numbered at thirty-two thousand two hundred.

22. "Then comes the tribe of Benjamin, and the leader of the children of Benjamin shall be Abidan the son of Gideoni."

23. And his army was numbered at thirty-five thousand four hundred.

24. "All who were numbered according to their armies of the forces with Ephraim, one hundred and eight thousand one hundred--they shall be the third to break camp.

25. "The standard of the forces with Dan shall be on the north side according to their armies, and the leader of the children of Dan shall be Ahiezer the son of Ammishaddai."

26. And his army was numbered at sixty-two thousand seven hundred.

27. "Those who camp next to him shall be the tribe of Asher, and the leader of the children of Asher shall be Pagiel the son of Ocran."

28. And his army was numbered at forty-one thousand five hundred.

29. "Then comes the tribe of Naphtali, and the leader of the children of Naphtali shall be Ahira the son of Enan."

30. And his army was numbered at fifty-three thousand four hundred.

31. "All who were numbered of the forces with Dan, one hundred and fifty-seven thousand six hundred--they shall break camp last, with their standards."

32. These are the ones who were numbered of the children of Israel by their fathers' houses. All who were numbered according to their armies of the forces were six hundred and three thousand five hundred and fifty.

33. But the Levites were not numbered among the children of Israel, just as the LORD commanded Moses.

34. Thus the children of Israel did according to all that the LORD commanded Moses; so they camped by their standards and so they broke camp, each one by his family, according to their fathers' houses.

## Chapter 3

1. Now these are the records of Aaron and Moses when the LORD spoke with Moses on Mount Sinai.

2. And these are the names of the sons of Aaron: Nadab, the firstborn, and Abihu, Eleazar, and Ithamar.

3. These are the names of the sons of Aaron, the anointed priests, whom he consecrated to minister as priests.

4. Nadab and Abihu had died before the LORD when they offered profane fire before the LORD in the Wilderness of Sinai; and they had no children. So Eleazar and Ithamar ministered as priests in the presence of Aaron their father.

5. And the LORD spoke to Moses, saying:

6. "Bring the tribe of Levi near, and present them before Aaron the priest, that they may serve him.

7. And they shall attend to his needs and the needs of the whole congregation before the tabernacle of meeting, to do the work of the tabernacle.

8. Also they shall attend to all the furnishings of the tabernacle of meeting, and to the needs of the children of Israel, to do the work of the tabernacle.

9. And you shall give the Levites to Aaron and his sons; they are given entirely to him from among the children of Israel.

10. So you shall appoint Aaron and his sons, and they shall attend to their priesthood; but the outsider who comes near shall be put to death."

11. Then the LORD spoke to Moses, saying:

12. "Now behold, I Myself have taken the Levites from among the children of Israel instead of every firstborn who opens the womb among the children of Israel. Therefore the Levites shall be Mine,

13. because all the firstborn are Mine. On the day that I struck all the firstborn in the land of Egypt, I sanctified to Myself all the firstborn in Israel, both man and beast. They shall be Mine: I am the LORD."

14. Then the LORD spoke to Moses in the Wilderness of Sinai, saying:

15. "Number the children of Levi by their fathers' houses, by their families; you shall number every male from a month old and above."

16. So Moses numbered them according to the word of the LORD, as he was commanded.

17. These were the sons of Levi by their names: Gershon, Kohath, and Merari.

18. And these are the names of the sons of Gershon by their families: Libni and Shimei.

19. And the sons of Kohath by their families: Amram, Izehar, Hebron, and Uzziel.

20. And the sons of Merari by their families: Mahli and Mushi. These are the families of the Levites by their fathers' houses.

21. From Gershon came the family of the Libnites and the family of the Shimites; these were the families of the Gershonites.

22. Those who were numbered, according to the number of all the males from a month old and above--of those who were numbered there were seven thousand five hundred.

23. The families of the Gershonites were to camp behind the tabernacle westward.

24. And the leader of the father's house of the Gershonites was Eliasaph the son of Lael.

25. The duties of the children of Gershon in the tabernacle of meeting included the tabernacle, the tent with its covering, the screen for the door of the tabernacle of meeting,

26. the screen for the door of the court, the hangings of the court which are around the tabernacle and the altar, and their cords, according to all the work relating to them.

27. From Kohath came the family of the Amramites, the family of the Izharites, the family of the Hebronites, and the family of the Uzzielites; these were the families of the Kohathites.

28. According to the number of all the males, from a month old and above, there were eight thousand six hundred keeping charge of the sanctuary.

29. The families of the children of Kohath were to camp on the south side of the tabernacle.

30. And the leader of the fathers' house of the families of the Kohathites was Elizaphan the son of Uzziel.

31. Their duty included the ark, the table, the lampstand, the altars, the utensils of the sanctuary with which they ministered, the screen, and all the work relating to them.

32. And Eleazar the son of Aaron the priest was to be chief over the leaders of the Levites, with oversight of those who kept charge of the sanctuary.

33. From Merari came the family of the Mahlites and the family of the Mushites; these were the families of Merari.

34. And those who were numbered, according to the number of all the males from a month old and above, were six thousand two hundred.

35. The leader of the fathers' house of the families of Merari was Zuriel the son of Abihail. These were to camp on the north side of the tabernacle.

36. And the appointed duty of the children of Merari included the boards of the tabernacle, its bars, its pillars, its sockets, its utensils, all the work relating to them,

37. and the pillars of the court all around, with their sockets, their pegs, and their cords.

38. Moreover those who were to camp before the tabernacle on the east, before the tabernacle of meeting, were Moses, Aaron, and his sons, keeping charge of the sanctuary, to meet the needs of the children of Israel; but the outsider who came near was to be put to death.

39. All who were numbered of the Levites, whom Moses and Aaron numbered at the commandment of the LORD, by their families, all the males from a month old and above, were twenty-two thousand.

40. Then the LORD said to Moses: "Number all the firstborn males of the children of Israel from a month old and above, and take the number of their names.

41. And you shall take the Levites for Me--I am the LORD--instead of all the firstborn among the children of Israel, and the livestock of the Levites instead of all the firstborn among the livestock of the children of Israel."

42. So Moses numbered all the firstborn among the children of Israel, as the LORD commanded him.

43. And all the firstborn males, according to the number of names from a month old and above, of those who were numbered of them, were twenty-two thousand two hundred and seventy-three.

44. Then the LORD spoke to Moses, saying:

45. "Take the Levites instead of all the firstborn among the children of Israel, and the livestock of the Levites instead of their livestock. The Levites shall be Mine: I am the LORD.

46. And for the redemption of the two hundred and seventy-three of the firstborn of the children of Israel, who are more than the number of the Levites,

47. you shall take five shekels for each one individually; you shall take them in the currency of the shekel of the sanctuary, the shekel of twenty gerahs.

48. And you shall give the money, with which the excess number of them is redeemed, to Aaron and his sons."

49. So Moses took the redemption money from those who were over and above those who were redeemed by the Levites.

50. From the firstborn of the children of Israel he took the money, one thousand three hundred and sixty-five shekels, according to the shekel of the sanctuary.

51. And Moses gave their redemption money to Aaron and his sons, according to the word of the LORD, as the LORD commanded Moses.

## Chapter 4

1. Then the LORD spoke to Moses and Aaron, saying:

2. "Take a census of the sons of Kohath from among the children of Levi, by their families, by their fathers' house,

3. from thirty years old and above, even to fifty years old, all who enter the service to do the work in the tabernacle of meeting.

4. "This is the service of the sons of Kohath in the tabernacle of meeting, relating to the most holy things:

5. When the camp prepares to journey, Aaron and his sons shall come, and they shall take down the covering veil and cover the ark of the Testimony with it.

6. Then they shall put on it a covering of badger skins, and spread over that a cloth entirely of blue; and they shall insert its poles.

7. "On the table of showbread they shall spread a blue cloth, and put on it the dishes, the pans, the bowls, and the pitchers for pouring; and the showbread shall be on it.

8. They shall spread over them a scarlet cloth, and cover the same with a covering of badger skins; and they shall insert its poles.

9. And they shall take a blue cloth and cover the lampstand of the light, with its lamps, its wick-trimmers, its trays, and all its oil vessels, with which they service it.

10. Then they shall put it with all its utensils in a covering of badger skins, and put it on a carrying beam.

11. "Over the golden altar they shall spread a blue cloth, and cover it with a covering of badger skins; and they shall insert its poles.

12. Then they shall take all the utensils of service with which they minister in the sanctuary, put them in a blue cloth, cover them with a covering of badger skins, and put them on a carrying beam.

13. Also they shall take away the ashes from the altar, and spread a purple cloth over it.

14. They shall put on it all its implements with which they minister there--the firepans, the forks, the shovels, the basins, and all the utensils of the altar--and they shall spread on it a covering of badger skins, and insert its poles.

15. And when Aaron and his sons have finished covering the sanctuary and all the furnishings of the sanctuary, when the camp is set to go, then the sons of Kohath shall come to carry them; but they shall not touch any holy thing, lest they die. "These are the things in the tabernacle of meeting which the sons of Kohath are to carry.

16. "The appointed duty of Eleazar the son of Aaron the priest is the oil for the light, the sweet incense, the daily grain offering, the anointing oil, the oversight of all the tabernacle, of all that is in it, with the sanctuary and its furnishings."

17. Then the LORD spoke to Moses and Aaron, saying:

18. "Do not cut off the tribe of the families of the Kohathites from among the Levites;

19. but do this in regard to them, that they may live and not die when they approach the most holy things: Aaron and his sons shall go in and appoint each of them to his service and his task.

20. But they shall not go in to watch while the holy things are being covered, lest they die."

21. Then the LORD spoke to Moses, saying:

22. "Also take a census of the sons of Gershon, by their fathers' house, by their families.

23. From thirty years old and above, even to fifty years old, you shall number them, all who enter to perform the service, to do the work in the tabernacle of meeting.

24. This is the service of the families of the Gershonites, in serving and carrying:

25. They shall carry the curtains of the tabernacle and the tabernacle of meeting with its covering, the covering of badger skins that is on it, the screen for the door of the tabernacle of meeting,

26. the screen for the door of the gate of the court, the hangings of the court which are around the tabernacle and altar, and their cords, all the furnishings for their service and all that is made for these things: so shall they serve.

27. "Aaron and his sons shall assign all the service of the sons of the Gershonites, all their tasks and all their service. And you shall appoint to them all their tasks as their duty.

28. This is the service of the families of the sons of Gershon in the tabernacle of meeting. And their duties shall be under the authority of Ithamar the son of Aaron the priest.

29. "As for the sons of Merari, you shall number them by their families and by their fathers' house.

30. From thirty years old and above, even to fifty years old, you shall number them, everyone who enters the service to do the work of the tabernacle of meeting.

31. And this is what they must carry as all their service for the tabernacle of meeting: the boards of the tabernacle, its bars, its pillars, its sockets,

32. and the pillars around the court with their sockets, pegs, and cords, with all their furnishings and all their service; and you shall assign to each man by name the items he must carry.

33. This is the service of the families of the sons of Merari, as all their service for the tabernacle of meeting, under the authority of Ithamar the son of Aaron the priest."

34. And Moses, Aaron, and the leaders of the congregation numbered the sons of the Kohathites by their families and by their fathers' house,

35. from thirty years old and above, even to fifty years old, everyone who entered the service for work in the tabernacle of meeting;

36. and those who were numbered by their families were two thousand seven hundred and fifty.

37. These were the ones who were numbered of the families of the Kohathites, all who might serve in the tabernacle of meeting, whom Moses and Aaron numbered according to the commandment of the LORD by the hand of Moses.

38. And those who were numbered of the sons of Gershon, by their families and by their fathers' house,

39. from thirty years old and above, even to fifty years old, everyone who entered the service for work in the tabernacle of meeting--

40. those who were numbered by their families, by their fathers' house, were two thousand six hundred and thirty.

41. These are the ones who were numbered of the families of the sons of Gershon, of all who might serve in the tabernacle of meeting, whom Moses and Aaron numbered according to the commandment of the LORD.

42. Those of the families of the sons of Merari who were numbered, by their families, by their fathers' house,

43. from thirty years old and above, even to fifty years old, everyone who entered the service for work in the tabernacle of meeting--

44. those who were numbered by their families were three thousand two hundred.

45. These are the ones who were numbered of the families of the sons of Merari, whom Moses and Aaron numbered according to the word of the LORD by the hand of Moses.

46. All who were numbered of the Levites, whom Moses, Aaron, and the leaders of Israel numbered, by their families and by their fathers' houses,

47. from thirty years old and above, even to fifty years old, everyone who came to do the work of service and the work of bearing burdens in the tabernacle of meeting--

48. those who were numbered were eight thousand five hundred and eighty.

49. According to the commandment of the LORD they were numbered by the hand of Moses, each according to his service and according to his task; thus were they numbered by him, as the LORD commanded Moses.

## Chapter 5

1. And the LORD spoke to Moses, saying:

2. "Command the children of Israel that they put out of the camp every leper, everyone who has a discharge, and whoever becomes defiled by a corpse.

3. You shall put out both male and female; you shall put them outside the camp, that they may not defile their camps in the midst of which I dwell."

4. And the children of Israel did so, and put them outside the camp; as the LORD spoke to Moses, so the children of Israel did.

5. Then the LORD spoke to Moses, saying,

6. "Speak to the children of Israel: "When a man or woman commits any sin that men commit in unfaithfulness against the LORD, and that person is guilty,

7. then he shall confess the sin which he has committed. He shall make restitution for his trespass in full, plus one-fifth of it, and give it to the one he has wronged.

8. But if the man has no relative to whom restitution may be made for the wrong, the restitution for the wrong must go to the LORD for the priest, in addition to the ram of the atonement with which atonement is made for him.

9. Every offering of all the holy things of the children of Israel, which they bring to the priest, shall be his.

10. And every man's holy things shall be his; whatever any man gives the priest shall be his."'

11. And the LORD spoke to Moses, saying,

12. "Speak to the children of Israel, and say to them: "If any man's wife goes astray and behaves unfaithfully toward him,

13. and a man lies with her carnally, and it is hidden from the eyes of her husband, and it is concealed that she has defiled herself, and there was no witness against her, nor was she caught--

14. if the spirit of jealousy comes upon him and he becomes jealous of his wife, who has defiled herself; or if the spirit of jealousy comes upon him and he becomes jealous of his wife, although she has not defiled herself--

15. then the man shall bring his wife to the priest. He shall bring the offering required for her, one-tenth of an ephah of barley meal; he shall pour no oil on it and put no frankincense on it, because it is a grain offering of jealousy, an offering for remembering, for bringing iniquity to remembrance.

16. "And the priest shall bring her near, and set her before the LORD.

17. The priest shall take holy water in an earthen vessel, and take some of the dust that is on the floor of the tabernacle and put it into the water.

18. Then the priest shall stand the woman before the LORD, uncover the woman's head, and put the offering for remembering in her hands, which is the grain offering of jealousy. And the priest shall have in his hand the bitter water that brings a curse.

19. And the priest shall put her under oath, and say to the woman, "If no man has lain with you, and if you have not gone astray to uncleanness while under your husband's authority, be free from this bitter water that brings a curse.

20. But if you have gone astray while under your husband's authority, and if you have defiled yourself and some man other than your husband has lain with you"--

21. then the priest shall put the woman under the oath of the curse, and he shall say to the woman--"the LORD make you a curse and an oath among your people, when the LORD makes your thigh rot and your belly swell;

22. and may this water that causes the curse go into your stomach, and make your belly swell and your thigh rot." "Then the woman shall say, "Amen, so be it."

23. "Then the priest shall write these curses in a book, and he shall scrape them off into the bitter water.

24. And he shall make the woman drink the bitter water that brings a curse, and the water that brings the curse shall enter her to become bitter.

25. Then the priest shall take the grain offering of jealousy from the woman's hand, shall wave the offering before the LORD, and bring it to the altar;

26. and the priest shall take a handful of the offering, as its memorial portion, burn it on the altar, and afterward make the woman drink the water.

27. When he has made her drink the water, then it shall be, if she has defiled herself and behaved unfaithfully toward her husband, that the water that brings a curse will enter her and become bitter, and her belly will swell, her thigh will rot, and the woman will become a curse among her people.

28. But if the woman has not defiled herself, and is clean, then she shall be free and may conceive children.

29. "This is the law of jealousy, when a wife, while under her husband's authority, goes astray and defiles herself,

30. or when the spirit of jealousy comes upon a man, and he becomes jealous of his wife; then he shall stand the woman before the LORD, and the priest shall execute all this law upon her.

31. Then the man shall be free from iniquity, but that woman shall bear her guilt."'

## Chapter 6

1. Then the LORD spoke to Moses, saying,

2. "Speak to the children of Israel, and say to them: "When either a man or woman consecrates an offering to take the vow of a Nazirite, to separate himself to the LORD,

3. he shall separate himself from wine and similar drink; he shall drink neither vinegar made from wine nor vinegar made from similar drink; neither shall he drink any grape juice, nor eat fresh grapes or raisins.

4. All the days of his separation he shall eat nothing that is produced by the grapevine, from seed to skin.

5. "All the days of the vow of his separation no razor shall come upon his head; until the days are fulfilled for which he separated himself to the LORD, he shall be holy. Then he shall let the locks of the hair of his head grow.

6. All the days that he separates himself to the LORD he shall not go near a dead body.

7. He shall not make himself unclean even for his father or his mother, for his brother or his sister, when they die, because his separation to God is on his head.

8. All the days of his separation he shall be holy to the LORD.

9. "And if anyone dies very suddenly beside him, and he defiles his consecrated head, then he shall shave his head on the day of his cleansing; on the seventh day he shall shave it.

10. Then on the eighth day he shall bring two turtledoves or two young pigeons to the priest, to the door of the tabernacle of meeting;

11. and the priest shall offer one as a sin offering and the other as a burnt offering, and make atonement for him, because he sinned in regard to the corpse; and he shall sanctify his head that same day.

12. He shall consecrate to the LORD the days of his separation, and bring a male lamb in its first year as a trespass offering; but the former days shall be lost, because his separation was defiled.

13. "Now this is the law of the Nazirite: When the days of his separation are fulfilled, he shall be brought to the door of the tabernacle of meeting.

14. And he shall present his offering to the LORD: one male lamb in its first year without blemish as a burnt offering, one ewe lamb in its first year without blemish as a sin offering, one ram without blemish as a peace offering,

15. a basket of unleavened bread, cakes of fine flour mixed with oil, unleavened wafers anointed with oil, and their grain offering with their drink offerings.

16. "Then the priest shall bring them before the LORD and offer his sin offering and his burnt offering;

17. and he shall offer the ram as a sacrifice of a peace offering to the LORD, with the basket of unleavened bread; the priest shall also offer its grain offering and its drink offering.

18. Then the Nazirite shall shave his consecrated head at the door of the tabernacle of meeting, and shall take the hair from his consecrated head and put it on the fire which is under the sacrifice of the peace offering.

19. "And the priest shall take the boiled shoulder of the ram, one unleavened cake from the basket, and one unleavened wafer, and put them upon the hands of the Nazirite after he has shaved his consecrated hair,

20. and the priest shall wave them as a wave offering before the LORD; they are holy for the priest, together with the breast of the wave offering and the thigh of the heave offering. After that the Nazirite may drink wine.'

21. "This is the law of the Nazirite who vows to the LORD the offering for his separation, and besides that, whatever else his hand is able to provide; according to the vow which he takes, so he must do according to the law of his separation."

22. And the LORD spoke to Moses, saying:

23. "Speak to Aaron and his sons, saying, "This is the way you shall bless the children of Israel. Say to them:

24. "The LORD bless you and keep you;

25. The LORD make His face shine upon you, And be gracious to you;

26. The LORD lift up His countenance upon you, And give you peace."'

27. "So they shall put My name on the children of Israel, and I will bless them."

## Chapter 7

1. Now it came to pass, when Moses had finished setting up the tabernacle, that he anointed it and consecrated it and all its furnishings, and the altar and all its utensils; so he anointed them and consecrated them.

2. Then the leaders of Israel, the heads of their fathers' houses, who were the leaders of the tribes and over those who were numbered, made an offering.

3. And they brought their offering before the LORD, six covered carts and twelve oxen, a cart for every two of the leaders, and for each one an ox; and they presented them before the tabernacle.

4. Then the LORD spoke to Moses, saying,

5. "Accept these from them, that they may be used in doing the work of the tabernacle of meeting; and you shall give them to the Levites, to every man according to his service."

6. So Moses took the carts and the oxen, and gave them to the Levites.

7. Two carts and four oxen he gave to the sons of Gershon, according to their service;

8. and four carts and eight oxen he gave to the sons of Merari, according to their service, under the authority of Ithamar the son of Aaron the priest.

9. But to the sons of Kohath he gave none, because theirs was the service of the holy things, which they carried on their shoulders.

10. Now the leaders offered the dedication offering for the altar when it was anointed; so the leaders offered their offering before the altar.

11. For the LORD said to Moses, "They shall offer their offering, one leader each day, for the dedication of the altar."

12. And the one who offered his offering on the first day was Nahshon the son of Amminadab, from the tribe of Judah.

13. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

14. one gold pan of ten shekels, full of incense;

15. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

16. one kid of the goats as a sin offering;

17. and for the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Nahshon the son of Amminadab.

18. On the second day Nethanel the son of Zuar, leader of Issachar, presented an offering.

19. For his offering he offered one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

20. one gold pan of ten shekels, full of incense;

21. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

22. one kid of the goats as a sin offering;

23. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Nethanel the son of Zuar.

24. On the third day Eliab the son of Helon, leader of the children of Zebulun, presented an offering.

25. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

26. one gold pan of ten shekels, full of incense;

27. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

28. one kid of the goats as a sin offering;

29. and for the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Eliab the son of Helon.

30. On the fourth day Elizur the son of Shedeur, leader of the children of Reuben, presented an offering.

31. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

32. one gold pan of ten shekels, full of incense;

33. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

34. one kid of the goats as a sin offering;

35. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Elizur the son of Shedeur.

36. On the fifth day Shelumiel the son of Zurishaddai, leader of the children of Simeon, presented an offering.

37. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

38. one gold pan of ten shekels, full of incense;

39. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

40. one kid of the goats as a sin offering;

41. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Shelumiel the son of Zurishaddai.

42. On the sixth day Eliasaph the son of Deuel, leader of the children of Gad, presented an offering.

43. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

44. one gold pan of ten shekels, full of incense;

45. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

46. one kid of the goats as a sin offering;

47. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Eliasaph the son of Deuel.

48. On the seventh day Elishama the son of Ammihud, leader of the children of Ephraim, presented an offering.

49. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

50. one gold pan of ten shekels, full of incense;

51. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

52. one kid of the goats as a sin offering;

53. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Elishama the son of Ammihud.

54. On the eighth day Gamaliel the son of Pedahzur, leader of the children of Manasseh, presented an offering.

55. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

56. one gold pan of ten shekels, full of incense;

57. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

58. one kid of the goats as a sin offering;

59. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Gamaliel the son of Pedahzur.

60. On the ninth day Abidan the son of Gideoni, leader of the children of Benjamin, presented an offering.

61. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

62. one gold pan of ten shekels, full of incense;

63. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

64. one kid of the goats as a sin offering;

65. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Abidan the son of Gideoni.

66. On the tenth day Ahiezer the son of Ammishaddai, leader of the children of Dan, presented an offering.

67. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

68. one gold pan of ten shekels, full of incense;

69. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

70. one kid of the goats as a sin offering;

71. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Ahiezer the son of Ammishaddai.

72. On the eleventh day Pagiel the son of Ocran, leader of the children of Asher, presented an offering.

73. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

74. one gold pan of ten shekels, full of incense;

75. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

76. one kid of the goats as a sin offering;

77. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Pagiel the son of Ocran.

78. On the twelfth day Ahira the son of Enan, leader of the children of Naphtali, presented an offering.

79. His offering was one silver platter, the weight of which was one hundred and thirty shekels, and one silver bowl of seventy shekels, according to the shekel of the sanctuary, both of them full of fine flour mixed with oil as a grain offering;

80. one gold pan of ten shekels, full of incense;

81. one young bull, one ram, and one male lamb in its first year, as a burnt offering;

82. one kid of the goats as a sin offering;

83. and as the sacrifice of peace offerings: two oxen, five rams, five male goats, and five male lambs in their first year. This was the offering of Ahira the son of Enan.

84. This was the dedication offering for the altar from the leaders of Israel, when it was anointed: twelve silver platters, twelve silver bowls, and twelve gold pans.

85. Each silver platter weighed one hundred and thirty shekels and each bowl seventy shekels. All the silver of the vessels weighed two thousand four hundred shekels, according to the shekel of the sanctuary.

86. The twelve gold pans full of incense weighed ten shekels apiece, according to the shekel of the sanctuary; all the gold of the pans weighed one hundred and twenty shekels.

87. All the oxen for the burnt offering were twelve young bulls, the rams twelve, the male lambs in their first year twelve, with their grain offering, and the kids of the goats as a sin offering twelve.

88. And all the oxen for the sacrifice of peace offerings were twenty-four bulls, the rams sixty, the male goats sixty, and the lambs in their first year sixty. This was the dedication offering for the altar after it was anointed.

89. Now when Moses went into the tabernacle of meeting to speak with Him, he heard the voice of One speaking to him from above the mercy seat that was on the ark of the Testimony, from between the two cherubim; thus He spoke to him.

## Chapter 8

1. And the LORD spoke to Moses, saying:

2. "Speak to Aaron, and say to him, "When you arrange the lamps, the seven lamps shall give light in front of the lampstand."'

3. And Aaron did so; he arranged the lamps to face toward the front of the lampstand, as the LORD commanded Moses.

4. Now this workmanship of the lampstand was hammered gold; from its shaft to its flowers it was hammered work. According to the pattern which the LORD had shown Moses, so he made the lampstand.

5. Then the LORD spoke to Moses, saying:

6. "Take the Levites from among the children of Israel and cleanse them ceremonially.

7. Thus you shall do to them to cleanse them: Sprinkle water of purification on them, and let them shave all their body, and let them wash their clothes, and so make themselves clean.

8. Then let them take a young bull with its grain offering of fine flour mixed with oil, and you shall take another young bull as a sin offering.

9. And you shall bring the Levites before the tabernacle of meeting, and you shall gather together the whole congregation of the children of Israel.

10. So you shall bring the Levites before the LORD, and the children of Israel shall lay their hands on the Levites;

11. and Aaron shall offer the Levites before the LORD like a wave offering from the children of Israel, that they may perform the work of the LORD.

12. Then the Levites shall lay their hands on the heads of the young bulls, and you shall offer one as a sin offering and the other as a burnt offering to the LORD, to make atonement for the Levites.

13. "And you shall stand the Levites before Aaron and his sons, and then offer them like a wave offering to the LORD.

14. Thus you shall separate the Levites from among the children of Israel, and the Levites shall be Mine.

15. After that the Levites shall go in to service the tabernacle of meeting. So you shall cleanse them and offer them like a wave offering.

16. For they are wholly given to Me from among the children of Israel; I have taken them for Myself instead of all who open the womb, the firstborn of all the children of Israel.

17. For all the firstborn among the children of Israel are Mine, both man and beast; on the day that I struck all the firstborn in the land of Egypt I sanctified them to Myself.

18. I have taken the Levites instead of all the firstborn of the children of Israel.

19. And I have given the Levites as a gift to Aaron and his sons from among the children of Israel, to do the work for the children of Israel in the tabernacle of meeting, and to make atonement for the children of Israel, that there be no plague among the children of Israel when the children of Israel come near the sanctuary."

20. Thus Moses and Aaron and all the congregation of the children of Israel did to the Levites; according to all that the LORD commanded Moses concerning the Levites, so the children of Israel did to them.

21. And the Levites purified themselves and washed their clothes; then Aaron presented them like a wave offering before the LORD, and Aaron made atonement for them to cleanse them.

22. After that the Levites went in to do their work in the tabernacle of meeting before Aaron and his sons; as the LORD commanded Moses concerning the Levites, so they did to them.

23. Then the LORD spoke to Moses, saying,

24. "This is what pertains to the Levites: From twenty-five years old and above one may enter to perform service in the work of the tabernacle of meeting;

25. and at the age of fifty years they must cease performing this work, and shall work no more.

26. They may minister with their brethren in the tabernacle of meeting, to attend to needs, but they themselves shall do no work. Thus you shall do to the Levites regarding their duties."

## Chapter 9

1. Now the LORD spoke to Moses in the Wilderness of Sinai, in the first month of the second year after they had come out of the land of Egypt, saying:

2. "Let the children of Israel keep the Passover at its appointed time.

3. On the fourteenth day of this month, at twilight, you shall keep it at its appointed time. According to all its rites and ceremonies you shall keep it."

4. So Moses told the children of Israel that they should keep the Passover.

5. And they kept the Passover on the fourteenth day of the first month, at twilight, in the Wilderness of Sinai; according to all that the LORD commanded Moses, so the children of Israel did.

6. Now there were certain men who were defiled by a human corpse, so that they could not keep the Passover on that day; and they came before Moses and Aaron that day.

7. And those men said to him, "We became defiled by a human corpse. Why are we kept from presenting the offering of the LORD at its appointed time among the children of Israel?"

8. And Moses said to them, "Stand still, that I may hear what the LORD will command concerning you."

9. Then the LORD spoke to Moses, saying,

10. "Speak to the children of Israel, saying: "If anyone of you or your posterity is unclean because of a corpse, or is far away on a journey, he may still keep the LORD's Passover.

11. On the fourteenth day of the second month, at twilight, they may keep it. They shall eat it with unleavened bread and bitter herbs.

12. They shall leave none of it until morning, nor break one of its bones. According to all the ordinances of the Passover they shall keep it.

13. But the man who is clean and is not on a journey, and ceases to keep the Passover, that same person shall be cut off from among his people, because he did not bring the offering of the LORD at its appointed time; that man shall bear his sin.

14. "And if a stranger dwells among you, and would keep the LORD's Passover, he must do so according to the rite of the Passover and according to its ceremony; you shall have one ordinance, both for the stranger and the native of the land."'

15. Now on the day that the tabernacle was raised up, the cloud covered the tabernacle, the tent of the Testimony; from evening until morning it was above the tabernacle like the appearance of fire.

16. So it was always: the cloud covered it by day, and the appearance of fire by night.

17. Whenever the cloud was taken up from above the tabernacle, after that the children of Israel would journey; and in the place where the cloud settled, there the children of Israel would pitch their tents.

18. At the command of the LORD the children of Israel would journey, and at the command of the LORD they would camp; as long as the cloud stayed above the tabernacle they remained encamped.

19. Even when the cloud continued long, many days above the tabernacle, the children of Israel kept the charge of the LORD and did not journey.

20. So it was, when the cloud was above the tabernacle a few days: according to the command of the LORD they would remain encamped, and according to the command of the LORD they would journey.

21. So it was, when the cloud remained only from evening until morning: when the cloud was taken up in the morning, then they would journey; whether by day or by night, whenever the cloud was taken up, they would journey.

22. Whether it was two days, a month, or a year that the cloud remained above the tabernacle, the children of Israel would remain encamped and not journey; but when it was taken up, they would journey.

23. At the command of the LORD they remained encamped, and at the command of the LORD they journeyed; they kept the charge of the LORD, at the command of the LORD by the hand of Moses.

## Chapter 10

1. And the LORD spoke to Moses, saying:

2. "Make two silver trumpets for yourself; you shall make them of hammered work; you shall use them for calling the congregation and for directing the movement of the camps.

3. When they blow both of them, all the congregation shall gather before you at the door of the tabernacle of meeting.

4. But if they blow only one, then the leaders, the heads of the divisions of Israel, shall gather to you.

5. When you sound the advance, the camps that lie on the east side shall then begin their journey.

6. When you sound the advance the second time, then the camps that lie on the south side shall begin their journey; they shall sound the call for them to begin their journeys.

7. And when the assembly is to be gathered together, you shall blow, but not sound the advance.

8. The sons of Aaron, the priests, shall blow the trumpets; and these shall be to you as an ordinance forever throughout your generations.

9. "When you go to war in your land against the enemy who oppresses you, then you shall sound an alarm with the trumpets, and you will be remembered before the LORD your God, and you will be saved from your enemies.

10. Also in the day of your gladness, in your appointed feasts, and at the beginning of your months, you shall blow the trumpets over your burnt offerings and over the sacrifices of your peace offerings; and they shall be a memorial for you before your God: I am the LORD your God."

11. Now it came to pass on the twentieth day of the second month, in the second year, that the cloud was taken up from above the tabernacle of the Testimony.

12. And the children of Israel set out from the Wilderness of Sinai on their journeys; then the cloud settled down in the Wilderness of Paran.

13. So they started out for the first time according to the command of the LORD by the hand of Moses.

14. The standard of the camp of the children of Judah set out first according to their armies; over their army was Nahshon the son of Amminadab.

15. Over the army of the tribe of the children of Issachar was Nethanel the son of Zuar.

16. And over the army of the tribe of the children of Zebulun was Eliab the son of Helon.

17. Then the tabernacle was taken down; and the sons of Gershon and the sons of Merari set out, carrying the tabernacle.

18. And the standard of the camp of Reuben set out according to their armies; over their army was Elizur the son of Shedeur.

19. Over the army of the tribe of the children of Simeon was Shelumiel the son of Zurishaddai.

20. And over the army of the tribe of the children of Gad was Eliasaph the son of Deuel.

21. Then the Kohathites set out, carrying the holy things. (The tabernacle would be prepared for their arrival.)

22. And the standard of the camp of the children of Ephraim set out according to their armies; over their army was Elishama the son of Ammihud.

23. Over the army of the tribe of the children of Manasseh was Gamaliel the son of Pedahzur.

24. And over the army of the tribe of the children of Benjamin was Abidan the son of Gideoni.

25. Then the standard of the camp of the children of Dan (the rear guard of all the camps) set out according to their armies; over their army was Ahiezer the son of Ammishaddai.

26. Over the army of the tribe of the children of Asher was Pagiel the son of Ocran.

27. And over the army of the tribe of the children of Naphtali was Ahira the son of Enan.

28. Thus was the order of march of the children of Israel, according to their armies, when they began their journey.

29. Now Moses said to Hobab the son of Reuel the Midianite, Moses' father-in-law, "We are setting out for the place of which the LORD said, "I will give it to you.' Come with us, and we will treat you well; for the LORD has promised good things to Israel."

30. And he said to him, "I will not go, but I will depart to my own land and to my relatives."

31. So Moses said, "Please do not leave, inasmuch as you know how we are to camp in the wilderness, and you can be our eyes.

32. And it shall be, if you go with us--indeed it shall be--that whatever good the LORD will do to us, the same we will do to you."

33. So they departed from the mountain of the LORD on a journey of three days; and the ark of the covenant of the LORD went before them for the three days' journey, to search out a resting place for them.

34. And the cloud of the LORD was above them by day when they went out from the camp.

35. So it was, whenever the ark set out, that Moses said: "Rise up, O LORD! Let Your enemies be scattered, And let those who hate You flee before You."

36. And when it rested, he said: "Return, O LORD, To the many thousands of Israel."

## Chapter 11

1. Now when the people complained, it displeased the LORD; for the LORD heard it, and His anger was aroused. So the fire of the LORD burned among them, and consumed some in the outskirts of the camp.

2. Then the people cried out to Moses, and when Moses prayed to the LORD, the fire was quenched.

3. So he called the name of the place Taberah, because the fire of the LORD had burned among them.

4. Now the mixed multitude who were among them yielded to intense craving; so the children of Israel also wept again and said: "Who will give us meat to eat?

5. We remember the fish which we ate freely in Egypt, the cucumbers, the melons, the leeks, the onions, and the garlic;

6. but now our whole being is dried up; there is nothing at all except this manna before our eyes!"

7. Now the manna was like coriander seed, and its color like the color of bdellium.

8. The people went about and gathered it, ground it on millstones or beat it in the mortar, cooked it in pans, and made cakes of it; and its taste was like the taste of pastry prepared with oil.

9. And when the dew fell on the camp in the night, the manna fell on it.

10. Then Moses heard the people weeping throughout their families, everyone at the door of his tent; and the anger of the LORD was greatly aroused; Moses also was displeased.

11. So Moses said to the LORD, "Why have You afflicted Your servant? And why have I not found favor in Your sight, that You have laid the burden of all these people on me?

12. Did I conceive all these people? Did I beget them, that You should say to me, "Carry them in your bosom, as a guardian carries a nursing child,' to the land which You swore to their fathers?

13. Where am I to get meat to give to all these people? For they weep all over me, saying, "Give us meat, that we may eat.'

14. I am not able to bear all these people alone, because the burden is too heavy for me.

15. If You treat me like this, please kill me here and now--if I have found favor in Your sight--and do not let me see my wretchedness!"

16. So the LORD said to Moses: "Gather to Me seventy men of the elders of Israel, whom you know to be the elders of the people and officers over them; bring them to the tabernacle of meeting, that they may stand there with you.

17. Then I will come down and talk with you there. I will take of the Spirit that is upon you and will put the same upon them; and they shall bear the burden of the people with you, that you may not bear it yourself alone.

18. Then you shall say to the people, "Consecrate yourselves for tomorrow, and you shall eat meat; for you have wept in the hearing of the LORD, saying, "Who will give us meat to eat? For it was well with us in Egypt." Therefore the LORD will give you meat, and you shall eat.

19. You shall eat, not one day, nor two days, nor five days, nor ten days, nor twenty days,

20. but for a whole month, until it comes out of your nostrils and becomes loathsome to you, because you have despised the LORD who is among you, and have wept before Him, saying, "Why did we ever come up out of Egypt?""'

21. And Moses said, "The people whom I am among are six hundred thousand men on foot; yet You have said, "I will give them meat, that they may eat for a whole month.'

22. Shall flocks and herds be slaughtered for them, to provide enough for them? Or shall all the fish of the sea be gathered together for them, to provide enough for them?"

23. And the LORD said to Moses, "Has the LORD's arm been shortened? Now you shall see whether what I say will happen to you or not."

24. So Moses went out and told the people the words of the LORD, and he gathered the seventy men of the elders of the people and placed them around the tabernacle.

25. Then the LORD came down in the cloud, and spoke to him, and took of the Spirit that was upon him, and placed the same upon the seventy elders; and it happened, when the Spirit rested upon them, that they prophesied, although they never did so again.

26. But two men had remained in the camp: the name of one was Eldad, and the name of the other Medad. And the Spirit rested upon them. Now they were among those listed, but who had not gone out to the tabernacle; yet they prophesied in the camp.

27. And a young man ran and told Moses, and said, "Eldad and Medad are prophesying in the camp."

28. So Joshua the son of Nun, Moses' assistant, one of his choice men, answered and said, "Moses my lord, forbid them!"

29. Then Moses said to him, "Are you zealous for my sake? Oh, that all the LORD's people were prophets and that the LORD would put His Spirit upon them!"

30. And Moses returned to the camp, he and the elders of Israel.

31. Now a wind went out from the LORD, and it brought quail from the sea and left them fluttering near the camp, about a day's journey on this side and about a day's journey on the other side, all around the camp, and about two cubits above the surface of the ground.

32. And the people stayed up all that day, all night, and all the next day, and gathered the quail (he who gathered least gathered ten homers); and they spread them out for themselves all around the camp.

33. But while the meat was still between their teeth, before it was chewed, the wrath of the LORD was aroused against the people, and the LORD struck the people with a very great plague.

34. So he called the name of that place Kibroth Hattaavah, because there they buried the people who had yielded to craving.

35. From Kibroth Hattaavah the people moved to Hazeroth, and camped at Hazeroth.

## Chapter 12

1. Then Miriam and Aaron spoke against Moses because of the Ethiopian woman whom he had married; for he had married an Ethiopian woman.

2. So they said, "Has the LORD indeed spoken only through Moses? Has He not spoken through us also?" And the LORD heard it.

3. (Now the man Moses was very humble, more than all men who were on the face of the earth.)

4. Suddenly the LORD said to Moses, Aaron, and Miriam, "Come out, you three, to the tabernacle of meeting!" So the three came out.

5. Then the LORD came down in the pillar of cloud and stood in the door of the tabernacle, and called Aaron and Miriam. And they both went forward.

6. Then He said, If there is a prophet among you, I, the LORD, make Myself known to him in a vision; I speak to him in a dream.

7. Not so with My servant Moses; He is faithful in all My house.

8. I speak with him face to face, Even plainly, and not in dark sayings; And he sees the form of the LORD. Why then were you not afraid To speak against My servant Moses?"

9. So the anger of the LORD was aroused against them, and He departed.

10. And when the cloud departed from above the tabernacle, suddenly Miriam became leprous, as white as snow. Then Aaron turned toward Miriam, and there she was, a leper.

11. So Aaron said to Moses, "Oh, my lord! Please do not lay this sin on us, in which we have done foolishly and in which we have sinned.

12. Please do not let her be as one dead, whose flesh is half consumed when he comes out of his mother's womb!"

13. So Moses cried out to the LORD, saying, "Please heal her, O God, I pray!"

14. Then the LORD said to Moses, "If her father had but spit in her face, would she not be shamed seven days? Let her be shut out of the camp seven days, and afterward she may be received again."

15. So Miriam was shut out of the camp seven days, and the people did not journey till Miriam was brought in again.

16. And afterward the people moved from Hazeroth and camped in the Wilderness of Paran.

## Chapter 13

1. And the LORD spoke to Moses, saying,

2. "Send men to spy out the land of Canaan, which I am giving to the children of Israel; from each tribe of their fathers you shall send a man, every one a leader among them."

3. So Moses sent them from the Wilderness of Paran according to the command of the LORD, all of them men who were heads of the children of Israel.

4. Now these were their names: from the tribe of Reuben, Shammua the son of Zaccur;

5. from the tribe of Simeon, Shaphat the son of Hori;

6. from the tribe of Judah, Caleb the son of Jephunneh;

7. from the tribe of Issachar, Igal the son of Joseph;

8. from the tribe of Ephraim, Hoshea the son of Nun;

9. from the tribe of Benjamin, Palti the son of Raphu;

10. from the tribe of Zebulun, Gaddiel the son of Sodi;

11. from the tribe of Joseph, that is, from the tribe of Manasseh, Gaddi the son of Susi;

12. from the tribe of Dan, Ammiel the son of Gemalli;

13. from the tribe of Asher, Sethur the son of Michael;

14. from the tribe of Naphtali, Nahbi the son of Vophsi;

15. from the tribe of Gad, Geuel the son of Machi.

16. These are the names of the men whom Moses sent to spy out the land. And Moses called Hoshea the son of Nun, Joshua.

17. Then Moses sent them to spy out the land of Canaan, and said to them, "Go up this way into the South, and go up to the mountains,

18. and see what the land is like: whether the people who dwell in it are strong or weak, few or many;

19. whether the land they dwell in is good or bad; whether the cities they inhabit are like camps or strongholds;

20. whether the land is rich or poor; and whether there are forests there or not. Be of good courage. And bring some of the fruit of the land." Now the time was the season of the first ripe grapes.

21. So they went up and spied out the land from the Wilderness of Zin as far as Rehob, near the entrance of Hamath.

22. And they went up through the South and came to Hebron; Ahiman, Sheshai, and Talmai, the descendants of Anak, were there. (Now Hebron was built seven years before Zoan in Egypt.)

23. Then they came to the Valley of Eshcol, and there cut down a branch with one cluster of grapes; they carried it between two of them on a pole. They also brought some of the pomegranates and figs.

24. The place was called the Valley of Eshcol, because of the cluster which the men of Israel cut down there.

25. And they returned from spying out the land after forty days.

26. Now they departed and came back to Moses and Aaron and all the congregation of the children of Israel in the Wilderness of Paran, at Kadesh; they brought back word to them and to all the congregation, and showed them the fruit of the land.

27. Then they told him, and said: "We went to the land where you sent us. It truly flows with milk and honey, and this is its fruit.

28. Nevertheless the people who dwell in the land are strong; the cities are fortified and very large; moreover we saw the descendants of Anak there.

29. The Amalekites dwell in the land of the South; the Hittites, the Jebusites, and the Amorites dwell in the mountains; and the Canaanites dwell by the sea and along the banks of the Jordan."

30. Then Caleb quieted the people before Moses, and said, "Let us go up at once and take possession, for we are well able to overcome it."

31. But the men who had gone up with him said, "We are not able to go up against the people, for they are stronger than we."

32. And they gave the children of Israel a bad report of the land which they had spied out, saying, "The land through which we have gone as spies is a land that devours its inhabitants, and all the people whom we saw in it are men of great stature.

33. There we saw the giants (the descendants of Anak came from the giants); and we were like grasshoppers in our own sight, and so we were in their sight."

## Chapter 14

1. So all the congregation lifted up their voices and cried, and the people wept that night.

2. And all the children of Israel complained against Moses and Aaron, and the whole congregation said to them, "If only we had died in the land of Egypt! Or if only we had died in this wilderness!

3. Why has the LORD brought us to this land to fall by the sword, that our wives and children should become victims? Would it not be better for us to return to Egypt?"

4. So they said to one another, "Let us select a leader and return to Egypt."

5. Then Moses and Aaron fell on their faces before all the assembly of the congregation of the children of Israel.

6. But Joshua the son of Nun and Caleb the son of Jephunneh, who were among those who had spied out the land, tore their clothes;

7. and they spoke to all the congregation of the children of Israel, saying: "The land we passed through to spy out is an exceedingly good land.

8. If the LORD delights in us, then He will bring us into this land and give it to us, "a land which flows with milk and honey.'

9. Only do not rebel against the LORD, nor fear the people of the land, for they are our bread; their protection has departed from them, and the LORD is with us. Do not fear them."

10. And all the congregation said to stone them with stones. Now the glory of the LORD appeared in the tabernacle of meeting before all the children of Israel.

11. Then the LORD said to Moses: "How long will these people reject Me? And how long will they not believe Me, with all the signs which I have performed among them?

12. I will strike them with the pestilence and disinherit them, and I will make of you a nation greater and mightier than they."

13. And Moses said to the LORD: "Then the Egyptians will hear it, for by Your might You brought these people up from among them,

14. and they will tell it to the inhabitants of this land. They have heard that You, LORD, are among these people; that You, LORD, are seen face to face and Your cloud stands above them, and You go before them in a pillar of cloud by day and in a pillar of fire by night.

15. Now if You kill these people as one man, then the nations which have heard of Your fame will speak, saying,

16. "Because the LORD was not able to bring this people to the land which He swore to give them, therefore He killed them in the wilderness.'

17. And now, I pray, let the power of my Lord be great, just as You have spoken, saying,

18. "The LORD is longsuffering and abundant in mercy, forgiving iniquity and transgression; but He by no means clears the guilty, visiting the iniquity of the fathers on the children to the third and fourth generation.'

19. Pardon the iniquity of this people, I pray, according to the greatness of Your mercy, just as You have forgiven this people, from Egypt even until now."

20. Then the LORD said: "I have pardoned, according to your word;

21. but truly, as I live, all the earth shall be filled with the glory of the LORD--

22. because all these men who have seen My glory and the signs which I did in Egypt and in the wilderness, and have put Me to the test now these ten times, and have not heeded My voice,

23. they certainly shall not see the land of which I swore to their fathers, nor shall any of those who rejected Me see it.

24. But My servant Caleb, because he has a different spirit in him and has followed Me fully, I will bring into the land where he went, and his descendants shall inherit it.

25. Now the Amalekites and the Canaanites dwell in the valley; tomorrow turn and move out into the wilderness by the Way of the Red Sea."

26. And the LORD spoke to Moses and Aaron, saying,

27. "How long shall I bear with this evil congregation who complain against Me? I have heard the complaints which the children of Israel make against Me.

28. Say to them, "As I live,' says the LORD, "just as you have spoken in My hearing, so I will do to you:

29. The carcasses of you who have complained against Me shall fall in this wilderness, all of you who were numbered, according to your entire number, from twenty years old and above.

30. Except for Caleb the son of Jephunneh and Joshua the son of Nun, you shall by no means enter the land which I swore I would make you dwell in.

31. But your little ones, whom you said would be victims, I will bring in, and they shall know the land which you have despised.

32. But as for you, your carcasses shall fall in this wilderness.

33. And your sons shall be shepherds in the wilderness forty years, and bear the brunt of your infidelity, until your carcasses are consumed in the wilderness.

34. According to the number of the days in which you spied out the land, forty days, for each day you shall bear your guilt one year, namely forty years, and you shall know My rejection.

35. I the LORD have spoken this. I will surely do so to all this evil congregation who are gathered together against Me. In this wilderness they shall be consumed, and there they shall die."'

36. Now the men whom Moses sent to spy out the land, who returned and made all the congregation complain against him by bringing a bad report of the land,

37. those very men who brought the evil report about the land, died by the plague before the LORD.

38. But Joshua the son of Nun and Caleb the son of Jephunneh remained alive, of the men who went to spy out the land.

39. Then Moses told these words to all the children of Israel, and the people mourned greatly.

40. And they rose early in the morning and went up to the top of the mountain, saying, "Here we are, and we will go up to the place which the LORD has promised, for we have sinned!"

41. And Moses said, "Now why do you transgress the command of the LORD? For this will not succeed.

42. Do not go up, lest you be defeated by your enemies, for the LORD is not among you.

43. For the Amalekites and the Canaanites are there before you, and you shall fall by the sword; because you have turned away from the LORD, the LORD will not be with you."

44. But they presumed to go up to the mountaintop. Nevertheless, neither the ark of the covenant of the LORD nor Moses departed from the camp.

45. Then the Amalekites and the Canaanites who dwelt in that mountain came down and attacked them, and drove them back as far as Hormah.

## Chapter 15

1. And the LORD spoke to Moses, saying,

2. "Speak to the children of Israel, and say to them: "When you have come into the land you are to inhabit, which I am giving to you,

3. and you make an offering by fire to the LORD, a burnt offering or a sacrifice, to fulfill a vow or as a freewill offering or in your appointed feasts, to make a sweet aroma to the LORD, from the herd or the flock,

4. then he who presents his offering to the LORD shall bring a grain offering of one-tenth of an ephah of fine flour mixed with one-fourth of a hin of oil;

5. and one-fourth of a hin of wine as a drink offering you shall prepare with the burnt offering or the sacrifice, for each lamb.

6. Or for a ram you shall prepare as a grain offering two-tenths of an ephah of fine flour mixed with one-third of a hin of oil;

7. and as a drink offering you shall offer one-third of a hin of wine as a sweet aroma to the LORD.

8. And when you prepare a young bull as a burnt offering, or as a sacrifice to fulfill a vow, or as a peace offering to the LORD,

9. then shall be offered with the young bull a grain offering of three-tenths of an ephah of fine flour mixed with half a hin of oil;

10. and you shall bring as the drink offering half a hin of wine as an offering made by fire, a sweet aroma to the LORD.

11. "Thus it shall be done for each young bull, for each ram, or for each lamb or young goat.

12. According to the number that you prepare, so you shall do with everyone according to their number.

13. All who are native-born shall do these things in this manner, in presenting an offering made by fire, a sweet aroma to the LORD.

14. And if a stranger dwells with you, or whoever is among you throughout your generations, and would present an offering made by fire, a sweet aroma to the LORD, just as you do, so shall he do.

15. One ordinance shall be for you of the assembly and for the stranger who dwells with you, an ordinance forever throughout your generations; as you are, so shall the stranger be before the LORD.

16. One law and one custom shall be for you and for the stranger who dwells with you."'

17. Again the LORD spoke to Moses, saying,

18. "Speak to the children of Israel, and say to them: "When you come into the land to which I bring you,

19. then it will be, when you eat of the bread of the land, that you shall offer up a heave offering to the LORD.

20. You shall offer up a cake of the first of your ground meal as a heave offering; as a heave offering of the threshing floor, so shall you offer it up.

21. Of the first of your ground meal you shall give to the LORD a heave offering throughout your generations.

22. "If you sin unintentionally, and do not observe all these commandments which the LORD has spoken to Moses--

23. all that the LORD has commanded you by the hand of Moses, from the day the LORD gave commandment and onward throughout your generations--

24. then it will be, if it is unintentionally committed, without the knowledge of the congregation, that the whole congregation shall offer one young bull as a burnt offering, as a sweet aroma to the LORD, with its grain offering and its drink offering, according to the ordinance, and one kid of the goats as a sin offering.

25. So the priest shall make atonement for the whole congregation of the children of Israel, and it shall be forgiven them, for it was unintentional; they shall bring their offering, an offering made by fire to the LORD, and their sin offering before the LORD, for their unintended sin.

26. It shall be forgiven the whole congregation of the children of Israel and the stranger who dwells among them, because all the people did it unintentionally.

27. "And if a person sins unintentionally, then he shall bring a female goat in its first year as a sin offering.

28. So the priest shall make atonement for the person who sins unintentionally, when he sins unintentionally before the LORD, to make atonement for him; and it shall be forgiven him.

29. You shall have one law for him who sins unintentionally, for him who is native-born among the children of Israel and for the stranger who dwells among them.

30. "But the person who does anything presumptuously, whether he is native-born or a stranger, that one brings reproach on the LORD, and he shall be cut off from among his people.

31. Because he has despised the word of the LORD, and has broken His commandment, that person shall be completely cut off; his guilt shall be upon him."'

32. Now while the children of Israel were in the wilderness, they found a man gathering sticks on the Sabbath day.

33. And those who found him gathering sticks brought him to Moses and Aaron, and to all the congregation.

34. They put him under guard, because it had not been explained what should be done to him.

35. Then the LORD said to Moses, "The man must surely be put to death; all the congregation shall stone him with stones outside the camp."

36. So, as the LORD commanded Moses, all the congregation brought him outside the camp and stoned him with stones, and he died.

37. Again the LORD spoke to Moses, saying,

38. "Speak to the children of Israel: Tell them to make tassels on the corners of their garments throughout their generations, and to put a blue thread in the tassels of the corners.

39. And you shall have the tassel, that you may look upon it and remember all the commandments of the LORD and do them, and that you may not follow the harlotry to which your own heart and your own eyes are inclined,

40. and that you may remember and do all My commandments, and be holy for your God.

41. I am the LORD your God, who brought you out of the land of Egypt, to be your God: I am the LORD your God."

## Chapter 16

1. Now Korah the son of Izhar, the son of Kohath, the son of Levi, with Dathan and Abiram the sons of Eliab, and On the son of Peleth, sons of Reuben, took men;

2. and they rose up before Moses with some of the children of Israel, two hundred and fifty leaders of the congregation, representatives of the congregation, men of renown.

3. They gathered together against Moses and Aaron, and said to them, "You take too much upon yourselves, for all the congregation is holy, every one of them, and the LORD is among them. Why then do you exalt yourselves above the assembly of the LORD?"

4. So when Moses heard it, he fell on his face;

5. and he spoke to Korah and all his company, saying, "Tomorrow morning the LORD will show who is His and who is holy, and will cause him to come near to Him. That one whom He chooses He will cause to come near to Him.

6. Do this: Take censers, Korah and all your company;

7. put fire in them and put incense in them before the LORD tomorrow, and it shall be that the man whom the LORD chooses is the holy one. You take too much upon yourselves, you sons of Levi!"

8. Then Moses said to Korah, "Hear now, you sons of Levi:

9. Is it a small thing to you that the God of Israel has separated you from the congregation of Israel, to bring you near to Himself, to do the work of the tabernacle of the LORD, and to stand before the congregation to serve them;

10. and that He has brought you near to Himself, you and all your brethren, the sons of Levi, with you? And are you seeking the priesthood also?

11. Therefore you and all your company are gathered together against the LORD. And what is Aaron that you complain against him?"

12. And Moses sent to call Dathan and Abiram the sons of Eliab, but they said, "We will not come up!

13. Is it a small thing that you have brought us up out of a land flowing with milk and honey, to kill us in the wilderness, that you should keep acting like a prince over us?

14. Moreover you have not brought us into a land flowing with milk and honey, nor given us inheritance of fields and vineyards. Will you put out the eyes of these men? We will not come up!"

15. Then Moses was very angry, and said to the LORD, "Do not respect their offering. I have not taken one donkey from them, nor have I hurt one of them."

16. And Moses said to Korah, "Tomorrow, you and all your company be present before the LORD--you and they, as well as Aaron.

17. Let each take his censer and put incense in it, and each of you bring his censer before the LORD, two hundred and fifty censers; both you and Aaron, each with his censer."

18. So every man took his censer, put fire in it, laid incense on it, and stood at the door of the tabernacle of meeting with Moses and Aaron.

19. And Korah gathered all the congregation against them at the door of the tabernacle of meeting. Then the glory of the LORD appeared to all the congregation.

20. And the LORD spoke to Moses and Aaron, saying,

21. "Separate yourselves from among this congregation, that I may consume them in a moment."

22. Then they fell on their faces, and said, "O God, the God of the spirits of all flesh, shall one man sin, and You be angry with all the congregation?"

23. So the LORD spoke to Moses, saying,

24. "Speak to the congregation, saying, "Get away from the tents of Korah, Dathan, and Abiram."'

25. Then Moses rose and went to Dathan and Abiram, and the elders of Israel followed him.

26. And he spoke to the congregation, saying, "Depart now from the tents of these wicked men! Touch nothing of theirs, lest you be consumed in all their sins."

27. So they got away from around the tents of Korah, Dathan, and Abiram; and Dathan and Abiram came out and stood at the door of their tents, with their wives, their sons, and their little children.

28. And Moses said: "By this you shall know that the LORD has sent me to do all these works, for I have not done them of my own will.

29. If these men die naturally like all men, or if they are visited by the common fate of all men, then the LORD has not sent me.

30. But if the LORD creates a new thing, and the earth opens its mouth and swallows them up with all that belongs to them, and they go down alive into the pit, then you will understand that these men have rejected the LORD."

31. Now it came to pass, as he finished speaking all these words, that the ground split apart under them,

32. and the earth opened its mouth and swallowed them up, with their households and all the men with Korah, with all their goods.

33. So they and all those with them went down alive into the pit; the earth closed over them, and they perished from among the assembly.

34. Then all Israel who were around them fled at their cry, for they said, "Lest the earth swallow us up also!"

35. And a fire came out from the LORD and consumed the two hundred and fifty men who were offering incense.

36. Then the LORD spoke to Moses, saying:

37. "Tell Eleazar, the son of Aaron the priest, to pick up the censers out of the blaze, for they are holy, and scatter the fire some distance away.

38. The censers of these men who sinned against their own souls, let them be made into hammered plates as a covering for the altar. Because they presented them before the LORD, therefore they are holy; and they shall be a sign to the children of Israel."

39. So Eleazar the priest took the bronze censers, which those who were burned up had presented, and they were hammered out as a covering on the altar,

40. to be a memorial to the children of Israel that no outsider, who is not a descendant of Aaron, should come near to offer incense before the LORD, that he might not become like Korah and his companions, just as the LORD had said to him through Moses.

41. On the next day all the congregation of the children of Israel complained against Moses and Aaron, saying, "You have killed the people of the LORD."

42. Now it happened, when the congregation had gathered against Moses and Aaron, that they turned toward the tabernacle of meeting; and suddenly the cloud covered it, and the glory of the LORD appeared.

43. Then Moses and Aaron came before the tabernacle of meeting.

44. And the LORD spoke to Moses, saying,

45. "Get away from among this congregation, that I may consume them in a moment." And they fell on their faces.

46. So Moses said to Aaron, "Take a censer and put fire in it from the altar, put incense on it, and take it quickly to the congregation and make atonement for them; for wrath has gone out from the LORD. The plague has begun."

47. Then Aaron took it as Moses commanded, and ran into the midst of the assembly; and already the plague had begun among the people. So he put in the incense and made atonement for the people.

48. And he stood between the dead and the living; so the plague was stopped.

49. Now those who died in the plague were fourteen thousand seven hundred, besides those who died in the Korah incident.

50. So Aaron returned to Moses at the door of the tabernacle of meeting, for the plague had stopped.

## Chapter 17

1. And the LORD spoke to Moses, saying:

2. "Speak to the children of Israel, and get from them a rod from each father's house, all their leaders according to their fathers' houses--twelve rods. Write each man's name on his rod.

3. And you shall write Aaron's name on the rod of Levi. For there shall be one rod for the head of each father's house.

4. Then you shall place them in the tabernacle of meeting before the Testimony, where I meet with you.

5. And it shall be that the rod of the man whom I choose will blossom; thus I will rid Myself of the complaints of the children of Israel, which they make against you."

6. So Moses spoke to the children of Israel, and each of their leaders gave him a rod apiece, for each leader according to their fathers' houses, twelve rods; and the rod of Aaron was among their rods.

7. And Moses placed the rods before the LORD in the tabernacle of witness.

8. Now it came to pass on the next day that Moses went into the tabernacle of witness, and behold, the rod of Aaron, of the house of Levi, had sprouted and put forth buds, had produced blossoms and yielded ripe almonds.

9. Then Moses brought out all the rods from before the LORD to all the children of Israel; and they looked, and each man took his rod.

10. And the LORD said to Moses, "Bring Aaron's rod back before the Testimony, to be kept as a sign against the rebels, that you may put their complaints away from Me, lest they die."

11. Thus did Moses; just as the LORD had commanded him, so he did.

12. So the children of Israel spoke to Moses, saying, "Surely we die, we perish, we all perish!

13. Whoever even comes near the tabernacle of the LORD must die. Shall we all utterly die?"

## Chapter 18

1. Then the LORD said to Aaron: "You and your sons and your father's house with you shall bear the iniquity related to the sanctuary, and you and your sons with you shall bear the iniquity associated with your priesthood.

2. Also bring with you your brethren of the tribe of Levi, the tribe of your father, that they may be joined with you and serve you while you and your sons are with you before the tabernacle of witness.

3. They shall attend to your needs and all the needs of the tabernacle; but they shall not come near the articles of the sanctuary and the altar, lest they die--they and you also.

4. They shall be joined with you and attend to the needs of the tabernacle of meeting, for all the work of the tabernacle; but an outsider shall not come near you.

5. And you shall attend to the duties of the sanctuary and the duties of the altar, that there may be no more wrath on the children of Israel.

6. Behold, I Myself have taken your brethren the Levites from among the children of Israel; they are a gift to you, given by the LORD, to do the work of the tabernacle of meeting.

7. Therefore you and your sons with you shall attend to your priesthood for everything at the altar and behind the veil; and you shall serve. I give your priesthood to you as a gift for service, but the outsider who comes near shall be put to death."

8. And the LORD spoke to Aaron: "Here, I Myself have also given you charge of My heave offerings, all the holy gifts of the children of Israel; I have given them as a portion to you and your sons, as an ordinance forever.

9. This shall be yours of the most holy things reserved from the fire: every offering of theirs, every grain offering and every sin offering and every trespass offering which they render to Me, shall be most holy for you and your sons.

10. In a most holy place you shall eat it; every male shall eat it. It shall be holy to you.

11. "This also is yours: the heave offering of their gift, with all the wave offerings of the children of Israel; I have given them to you, and your sons and daughters with you, as an ordinance forever. everyone who is clean in your house may eat it.

12. "All the best of the oil, all the best of the new wine and the grain, their firstfruits which they offer to the LORD, I have given them to you.

13. Whatever first ripe fruit is in their land, which they bring to the LORD, shall be yours. Everyone who is clean in your house may eat it.

14. "Every devoted thing in Israel shall be yours.

15. "Everything that first opens the womb of all flesh, which they bring to the LORD, whether man or beast, shall be yours; nevertheless the firstborn of man you shall surely redeem, and the firstborn of unclean animals you shall redeem.

16. And those redeemed of the devoted things you shall redeem when one month old, according to your valuation, for five shekels of silver, according to the shekel of the sanctuary, which is twenty gerahs.

17. But the firstborn of a cow, the firstborn of a sheep, or the firstborn of a goat you shall not redeem; they are holy. You shall sprinkle their blood on the altar, and burn their fat as an offering made by fire for a sweet aroma to the LORD.

18. And their flesh shall be yours, just as the wave breast and the right thigh are yours.

19. "All the heave offerings of the holy things, which the children of Israel offer to the LORD, I have given to you and your sons and daughters with you as an ordinance forever; it is a covenant of salt forever before the LORD with you and your descendants with you."

20. Then the LORD said to Aaron: "You shall have no inheritance in their land, nor shall you have any portion among them; I am your portion and your inheritance among the children of Israel.

21. "Behold, I have given the children of Levi all the tithes in Israel as an inheritance in return for the work which they perform, the work of the tabernacle of meeting.

22. Hereafter the children of Israel shall not come near the tabernacle of meeting, lest they bear sin and die.

23. But the Levites shall perform the work of the tabernacle of meeting, and they shall bear their iniquity; it shall be a statute forever, throughout your generations, that among the children of Israel they shall have no inheritance.

24. For the tithes of the children of Israel, which they offer up as a heave offering to the LORD, I have given to the Levites as an inheritance; therefore I have said to them, "Among the children of Israel they shall have no inheritance."'

25. Then the LORD spoke to Moses, saying,

26. "Speak thus to the Levites, and say to them: "When you take from the children of Israel the tithes which I have given you from them as your inheritance, then you shall offer up a heave offering of it to the LORD, a tenth of the tithe.

27. And your heave offering shall be reckoned to you as though it were the grain of the threshing floor and as the fullness of the winepress.

28. Thus you shall also offer a heave offering to the LORD from all your tithes which you receive from the children of Israel, and you shall give the LORD's heave offering from it to Aaron the priest.

29. Of all your gifts you shall offer up every heave offering due to the LORD, from all the best of them, the consecrated part of them.'

30. Therefore you shall say to them: "When you have lifted up the best of it, then the rest shall be accounted to the Levites as the produce of the threshing floor and as the produce of the winepress.

31. You may eat it in any place, you and your households, for it is your reward for your work in the tabernacle of meeting.

32. And you shall bear no sin because of it, when you have lifted up the best of it. But you shall not profane the holy gifts of the children of Israel, lest you die."'

## Chapter 19

1. Now the LORD spoke to Moses and Aaron, saying,

2. "This is the ordinance of the law which the LORD has commanded, saying: "Speak to the children of Israel, that they bring you a red heifer without blemish, in which there is no defect and on which a yoke has never come.

3. You shall give it to Eleazar the priest, that he may take it outside the camp, and it shall be slaughtered before him;

4. and Eleazar the priest shall take some of its blood with his finger, and sprinkle some of its blood seven times directly in front of the tabernacle of meeting.

5. Then the heifer shall be burned in his sight: its hide, its flesh, its blood, and its offal shall be burned.

6. And the priest shall take cedar wood and hyssop and scarlet, and cast them into the midst of the fire burning the heifer.

7. Then the priest shall wash his clothes, he shall bathe in water, and afterward he shall come into the camp; the priest shall be unclean until evening.

8. And the one who burns it shall wash his clothes in water, bathe in water, and shall be unclean until evening.

9. Then a man who is clean shall gather up the ashes of the heifer, and store them outside the camp in a clean place; and they shall be kept for the congregation of the children of Israel for the water of purification; it is for purifying from sin.

10. And the one who gathers the ashes of the heifer shall wash his clothes, and be unclean until evening. It shall be a statute forever to the children of Israel and to the stranger who dwells among them.

11. "He who touches the dead body of anyone shall be unclean seven days.

12. He shall purify himself with the water on the third day and on the seventh day; then he will be clean. But if he does not purify himself on the third day and on the seventh day, he will not be clean.

13. Whoever touches the body of anyone who has died, and does not purify himself, defiles the tabernacle of the LORD. That person shall be cut off from Israel. He shall be unclean, because the water of purification was not sprinkled on him; his uncleanness is still on him.

14. "This is the law when a man dies in a tent: All who come into the tent and all who are in the tent shall be unclean seven days;

15. and every open vessel, which has no cover fastened on it, is unclean.

16. Whoever in the open field touches one who is slain by a sword or who has died, or a bone of a man, or a grave, shall be unclean seven days.

17. "And for an unclean person they shall take some of the ashes of the heifer burnt for purification from sin, and running water shall be put on them in a vessel.

18. A clean person shall take hyssop and dip it in the water, sprinkle it on the tent, on all the vessels, on the persons who were there, or on the one who touched a bone, the slain, the dead, or a grave.

19. The clean person shall sprinkle the unclean on the third day and on the seventh day; and on the seventh day he shall purify himself, wash his clothes, and bathe in water; and at evening he shall be clean.

20. "But the man who is unclean and does not purify himself, that person shall be cut off from among the assembly, because he has defiled the sanctuary of the LORD. The water of purification has not been sprinkled on him; he is unclean.

21. It shall be a perpetual statute for them. He who sprinkles the water of purification shall wash his clothes; and he who touches the water of purification shall be unclean until evening.

22. Whatever the unclean person touches shall be unclean; and the person who touches it shall be unclean until evening."'

## Chapter 20

1. Then the children of Israel, the whole congregation, came into the Wilderness of Zin in the first month, and the people stayed in Kadesh; and Miriam died there and was buried there.

2. Now there was no water for the congregation; so they gathered together against Moses and Aaron.

3. And the people contended with Moses and spoke, saying: "If only we had died when our brethren died before the LORD!

4. Why have you brought up the assembly of the LORD into this wilderness, that we and our animals should die here?

5. And why have you made us come up out of Egypt, to bring us to this evil place? It is not a place of grain or figs or vines or pomegranates; nor is there any water to drink."

6. So Moses and Aaron went from the presence of the assembly to the door of the tabernacle of meeting, and they fell on their faces. And the glory of the LORD appeared to them.

7. Then the LORD spoke to Moses, saying,

8. "Take the rod; you and your brother Aaron gather the congregation together. Speak to the rock before their eyes, and it will yield its water; thus you shall bring water for them out of the rock, and give drink to the congregation and their animals."

9. So Moses took the rod from before the LORD as He commanded him.

10. And Moses and Aaron gathered the assembly together before the rock; and he said to them, "Hear now, you rebels! Must we bring water for you out of this rock?"

11. Then Moses lifted his hand and struck the rock twice with his rod; and water came out abundantly, and the congregation and their animals drank.

12. Then the LORD spoke to Moses and Aaron, "Because you did not believe Me, to hallow Me in the eyes of the children of Israel, therefore you shall not bring this assembly into the land which I have given them."

13. This was the water of Meribah, because the children of Israel contended with the LORD, and He was hallowed among them.

14. Now Moses sent messengers from Kadesh to the king of Edom. "Thus says your brother Israel: "You know all the hardship that has befallen us,

15. how our fathers went down to Egypt, and we dwelt in Egypt a long time, and the Egyptians afflicted us and our fathers.

16. When we cried out to the LORD, He heard our voice and sent the Angel and brought us up out of Egypt; now here we are in Kadesh, a city on the edge of your border.

17. Please let us pass through your country. We will not pass through fields or vineyards, nor will we drink water from wells; we will go along the King's Highway; we will not turn aside to the right hand or to the left until we have passed through your territory."'

18. Then Edom said to him, "You shall not pass through my land, lest I come out against you with the sword."

19. So the children of Israel said to him, "We will go by the Highway, and if I or my livestock drink any of your water, then I will pay for it; let me only pass through on foot, nothing more."

20. Then he said, "You shall not pass through." So Edom came out against them with many men and with a strong hand.

21. Thus Edom refused to give Israel passage through his territory; so Israel turned away from him.

22. Now the children of Israel, the whole congregation, journeyed from Kadesh and came to Mount Hor.

23. And the LORD spoke to Moses and Aaron in Mount Hor by the border of the land of Edom, saying:

24. "Aaron shall be gathered to his people, for he shall not enter the land which I have given to the children of Israel, because you rebelled against My word at the water of Meribah.

25. Take Aaron and Eleazar his son, and bring them up to Mount Hor;

26. and strip Aaron of his garments and put them on Eleazar his son; for Aaron shall be gathered to his people and die there."

27. So Moses did just as the LORD commanded, and they went up to Mount Hor in the sight of all the congregation.

28. Moses stripped Aaron of his garments and put them on Eleazar his son; and Aaron died there on the top of the mountain. Then Moses and Eleazar came down from the mountain.

29. Now when all the congregation saw that Aaron was dead, all the house of Israel mourned for Aaron thirty days.

## Chapter 21

1. The king of Arad, the Canaanite, who dwelt in the South, heard that Israel was coming on the road to Atharim. Then he fought against Israel and took some of them prisoners.

2. So Israel made a vow to the LORD, and said, "If You will indeed deliver this people into my hand, then I will utterly destroy their cities."

3. And the LORD listened to the voice of Israel and delivered up the Canaanites, and they utterly destroyed them and their cities. So the name of that place was called Hormah.

4. Then they journeyed from Mount Hor by the Way of the Red Sea, to go around the land of Edom; and the soul of the people became very discouraged on the way.

5. And the people spoke against God and against Moses: "Why have you brought us up out of Egypt to die in the wilderness? For there is no food and no water, and our soul loathes this worthless bread."

6. So the LORD sent fiery serpents among the people, and they bit the people; and many of the people of Israel died.

7. Therefore the people came to Moses, and said, "We have sinned, for we have spoken against the LORD and against you; pray to the LORD that He take away the serpents from us." So Moses prayed for the people.

8. Then the LORD said to Moses, "Make a fiery serpent, and set it on a pole; and it shall be that everyone who is bitten, when he looks at it, shall live."

9. So Moses made a bronze serpent, and put it on a pole; and so it was, if a serpent had bitten anyone, when he looked at the bronze serpent, he lived.

10. Now the children of Israel moved on and camped in Oboth.

11. And they journeyed from Oboth and camped at Ije Abarim, in the wilderness which is east of Moab, toward the sunrise.

12. From there they moved and camped in the Valley of Zered.

13. From there they moved and camped on the other side of the Arnon, which is in the wilderness that extends from the border of the Amorites; for the Arnon is the border of Moab, between Moab and the Amorites.

14. Therefore it is said in the Book of the Wars of the LORD: "Waheb in Suphah, The brooks of the Arnon,

15. And the slope of the brooks That reaches to the dwelling of Ar, And lies on the border of Moab."

16. From there they went to Beer, which is the well where the LORD said to Moses, "Gather the people together, and I will give them water."

17. Then Israel sang this song: "Spring up, O well! All of you sing to it--

18. The well the leaders sank, Dug by the nation's nobles, By the lawgiver, with their staves." And from the wilderness they went to Mattanah,

19. from Mattanah to Nahaliel, from Nahaliel to Bamoth,

20. and from Bamoth, in the valley that is in the country of Moab, to the top of Pisgah which looks down on the wasteland.

21. Then Israel sent messengers to Sihon king of the Amorites, saying,

22. "Let me pass through your land. We will not turn aside into fields or vineyards; we will not drink water from wells. We will go by the King's Highway until we have passed through your territory."

23. But Sihon would not allow Israel to pass through his territory. So Sihon gathered all his people together and went out against Israel in the wilderness, and he came to Jahaz and fought against Israel.

24. Then Israel defeated him with the edge of the sword, and took possession of his land from the Arnon to the Jabbok, as far as the people of Ammon; for the border of the people of Ammon was fortified.

25. So Israel took all these cities, and Israel dwelt in all the cities of the Amorites, in Heshbon and in all its villages.

26. For Heshbon was the city of Sihon king of the Amorites, who had fought against the former king of Moab, and had taken all his land from his hand as far as the Arnon.

27. Therefore those who speak in proverbs say: "Come to Heshbon, let it be built; Let the city of Sihon be repaired.

28. "For fire went out from Heshbon, A flame from the city of Sihon; It consumed Ar of Moab, The lords of the heights of the Arnon.

29. Woe to you, Moab! You have perished, O people of Chemosh! He has given his sons as fugitives, And his daughters into captivity, To Sihon king of the Amorites.

30. "But we have shot at them; Heshbon has perished as far as Dibon. Then we laid waste as far as Nophah, Which reaches to Medeba."

31. Thus Israel dwelt in the land of the Amorites.

32. Then Moses sent to spy out Jazer; and they took its villages and drove out the Amorites who were there.

33. And they turned and went up by the way to Bashan. So Og king of Bashan went out against them, he and all his people, to battle at Edrei.

34. Then the LORD said to Moses, "Do not fear him, for I have delivered him into your hand, with all his people and his land; and you shall do to him as you did to Sihon king of the Amorites, who dwelt at Heshbon."

35. So they defeated him, his sons, and all his people, until there was no survivor left him; and they took possession of his land.

## Chapter 22

1. Then the children of Israel moved, and camped in the plains of Moab on the side of the Jordan across from Jericho.

2. Now Balak the son of Zippor saw all that Israel had done to the Amorites.

3. And Moab was exceedingly afraid of the people because they were many, and Moab was sick with dread because of the children of Israel.

4. So Moab said to the elders of Midian, "Now this company will lick up everything around us, as an ox licks up the grass of the field." And Balak the son of Zippor was king of the Moabites at that time.

5. Then he sent messengers to Balaam the son of Beor at Pethor, which is near the River in the land of the sons of his people, to call him, saying: "Look, a people has come from Egypt. See, they cover the face of the earth, and are settling next to me!

6. Therefore please come at once, curse this people for me, for they are too mighty for me. Perhaps I shall be able to defeat them and drive them out of the land, for I know that he whom you bless is blessed, and he whom you curse is cursed."

7. So the elders of Moab and the elders of Midian departed with the diviner's fee in their hand, and they came to Balaam and spoke to him the words of Balak.

8. And he said to them, "Lodge here tonight, and I will bring back word to you, as the LORD speaks to me." So the princes of Moab stayed with Balaam.

9. Then God came to Balaam and said, "Who are these men with you?"

10. So Balaam said to God, "Balak the son of Zippor, king of Moab, has sent to me, saying,

11. "Look, a people has come out of Egypt, and they cover the face of the earth. Come now, curse them for me; perhaps I shall be able to overpower them and drive them out."'

12. And God said to Balaam, "You shall not go with them; you shall not curse the people, for they are blessed."

13. So Balaam rose in the morning and said to the princes of Balak, "Go back to your land, for the LORD has refused to give me permission to go with you."

14. And the princes of Moab rose and went to Balak, and said, "Balaam refuses to come with us."

15. Then Balak again sent princes, more numerous and more honorable than they.

16. And they came to Balaam and said to him, "Thus says Balak the son of Zippor: "Please let nothing hinder you from coming to me;

17. for I will certainly honor you greatly, and I will do whatever you say to me. Therefore please come, curse this people for me."'

18. Then Balaam answered and said to the servants of Balak, "Though Balak were to give me his house full of silver and gold, I could not go beyond the word of the LORD my God, to do less or more.

19. Now therefore, please, you also stay here tonight, that I may know what more the LORD will say to me."

20. And God came to Balaam at night and said to him, "If the men come to call you, rise and go with them; but only the word which I speak to you--that you shall do."

21. So Balaam rose in the morning, saddled his donkey, and went with the princes of Moab.

22. Then God's anger was aroused because he went, and the Angel of the LORD took His stand in the way as an adversary against him. And he was riding on his donkey, and his two servants were with him.

23. Now the donkey saw the Angel of the LORD standing in the way with His drawn sword in His hand, and the donkey turned aside out of the way and went into the field. So Balaam struck the donkey to turn her back onto the road.

24. Then the Angel of the LORD stood in a narrow path between the vineyards, with a wall on this side and a wall on that side.

25. And when the donkey saw the Angel of the LORD, she pushed herself against the wall and crushed Balaam's foot against the wall; so he struck her again.

26. Then the Angel of the LORD went further, and stood in a narrow place where there was no way to turn either to the right hand or to the left.

27. And when the donkey saw the Angel of the LORD, she lay down under Balaam; so Balaam's anger was aroused, and he struck the donkey with his staff.

28. Then the LORD opened the mouth of the donkey, and she said to Balaam, "What have I done to you, that you have struck me these three times?"

29. And Balaam said to the donkey, "Because you have abused me. I wish there were a sword in my hand, for now I would kill you!"

30. So the donkey said to Balaam, "Am I not your donkey on which you have ridden, ever since I became yours, to this day? Was I ever disposed to do this to you?" And he said, "No."

31. Then the LORD opened Balaam's eyes, and he saw the Angel of the LORD standing in the way with His drawn sword in His hand; and he bowed his head and fell flat on his face.

32. And the Angel of the LORD said to him, "Why have you struck your donkey these three times? Behold, I have come out to stand against you, because your way is perverse before Me.

33. The donkey saw Me and turned aside from Me these three times. If she had not turned aside from Me, surely I would also have killed you by now, and let her live."

34. And Balaam said to the Angel of the LORD, "I have sinned, for I did not know You stood in the way against me. Now therefore, if it displeases You, I will turn back."

35. Then the Angel of the LORD said to Balaam, "Go with the men, but only the word that I speak to you, that you shall speak." So Balaam went with the princes of Balak.

36. Now when Balak heard that Balaam was coming, he went out to meet him at the city of Moab, which is on the border at the Arnon, the boundary of the territory.

37. Then Balak said to Balaam, "Did I not earnestly send to you, calling for you? Why did you not come to me? Am I not able to honor you?"

38. And Balaam said to Balak, "Look, I have come to you! Now, have I any power at all to say anything? The word that God puts in my mouth, that I must speak."

39. So Balaam went with Balak, and they came to Kirjath Huzoth.

40. Then Balak offered oxen and sheep, and he sent some to Balaam and to the princes who were with him.

41. So it was, the next day, that Balak took Balaam and brought him up to the high places of Baal, that from there he might observe the extent of the people.

## Chapter 23

1. Then Balaam said to Balak, "Build seven altars for me here, and prepare for me here seven bulls and seven rams."

2. And Balak did just as Balaam had spoken, and Balak and Balaam offered a bull and a ram on each altar.

3. Then Balaam said to Balak, "Stand by your burnt offering, and I will go; perhaps the LORD will come to meet me, and whatever He shows me I will tell you." So he went to a desolate height.

4. And God met Balaam, and he said to Him, "I have prepared the seven altars, and I have offered on each altar a bull and a ram."

5. Then the LORD put a word in Balaam's mouth, and said, "Return to Balak, and thus you shall speak."

6. So he returned to him, and there he was, standing by his burnt offering, he and all the princes of Moab.

7. And he took up his oracle and said: "Balak the king of Moab has brought me from Aram, From the mountains of the east. "Come, curse Jacob for me, And come, denounce Israel!'

8. "How shall I curse whom God has not cursed? And how shall I denounce whom the LORD has not denounced?

9. For from the top of the rocks I see him, And from the hills I behold him; There! A people dwelling alone, Not reckoning itself among the nations.

10. "Who can count the dust of Jacob, Or number one-fourth of Israel? Let me die the death of the righteous, And let my end be like his!"

11. Then Balak said to Balaam, "What have you done to me? I took you to curse my enemies, and look, you have blessed them bountifully!"

12. So he answered and said, "Must I not take heed to speak what the LORD has put in my mouth?"

13. Then Balak said to him, "Please come with me to another place from which you may see them; you shall see only the outer part of them, and shall not see them all; curse them for me from there."

14. So he brought him to the field of Zophim, to the top of Pisgah, and built seven altars, and offered a bull and a ram on each altar.

15. And he said to Balak, "Stand here by your burnt offering while I meet the LORD over there."

16. Then the LORD met Balaam, and put a word in his mouth, and said, "Go back to Balak, and thus you shall speak."

17. So he came to him, and there he was, standing by his burnt offering, and the princes of Moab were with him. And Balak said to him, "What has the LORD spoken?"

18. Then he took up his oracle and said: "Rise up, Balak, and hear! Listen to me, son of Zippor!

19. "God is not a man, that He should lie, Nor a son of man, that He should repent. Has He said, and will He not do? Or has He spoken, and will He not make it good?

20. Behold, I have received a command to bless; He has blessed, and I cannot reverse it.

21. "He has not observed iniquity in Jacob, Nor has He seen wickedness in Israel. The LORD his God is with him, And the shout of a King is among them.

22. God brings them out of Egypt; He has strength like a wild ox.

23. "For there is no sorcery against Jacob, Nor any divination against Israel. It now must be said of Jacob And of Israel, "Oh, what God has done!'

24. Look, a people rises like a lioness, And lifts itself up like a lion; It shall not lie down until it devours the prey, And drinks the blood of the slain."

25. Then Balak said to Balaam, "Neither curse them at all, nor bless them at all!"

26. So Balaam answered and said to Balak, "Did I not tell you, saying, "All that the LORD speaks, that I must do'?"

27. Then Balak said to Balaam, "Please come, I will take you to another place; perhaps it will please God that you may curse them for me from there."

28. So Balak took Balaam to the top of Peor, that overlooks the wasteland.

29. Then Balaam said to Balak, "Build for me here seven altars, and prepare for me here seven bulls and seven rams."

30. And Balak did as Balaam had said, and offered a bull and a ram on every altar.

## Chapter 24

1. Now when Balaam saw that it pleased the LORD to bless Israel, he did not go as at other times, to seek to use sorcery, but he set his face toward the wilderness.

2. And Balaam raised his eyes, and saw Israel encamped according to their tribes; and the Spirit of God came upon him.

3. Then he took up his oracle and said: "The utterance of Balaam the son of Beor, The utterance of the man whose eyes are opened,

4. The utterance of him who hears the words of God, Who sees the vision of the Almighty, Who falls down, with eyes wide open:

5. "How lovely are your tents, O Jacob! Your dwellings, O Israel!

6. Like valleys that stretch out, Like gardens by the riverside, Like aloes planted by the LORD, Like cedars beside the waters.

7. He shall pour water from his buckets, And his seed shall be in many waters. "His king shall be higher than Agag, And his kingdom shall be exalted.

8. "God brings him out of Egypt; He has strength like a wild ox; He shall consume the nations, his enemies; He shall break their bones And pierce them with his arrows.

9. "He bows down, he lies down as a lion; And as a lion, who shall rouse him?' "Blessed is he who blesses you, And cursed is he who curses you."

10. Then Balak's anger was aroused against Balaam, and he struck his hands together; and Balak said to Balaam, "I called you to curse my enemies, and look, you have bountifully blessed them these three times!

11. Now therefore, flee to your place. I said I would greatly honor you, but in fact, the LORD has kept you back from honor."

12. So Balaam said to Balak, "Did I not also speak to your messengers whom you sent to me, saying,

13. "If Balak were to give me his house full of silver and gold, I could not go beyond the word of the LORD, to do good or bad of my own will. What the LORD says, that I must speak'?

14. And now, indeed, I am going to my people. Come, I will advise you what this people will do to your people in the latter days."

15. So he took up his oracle and said: "The utterance of Balaam the son of Beor, And the utterance of the man whose eyes are opened;

16. The utterance of him who hears the words of God, And has the knowledge of the Most High, Who sees the vision of the Almighty, Who falls down, with eyes wide open:

17. "I see Him, but not now; I behold Him, but not near; A Star shall come out of Jacob; A Scepter shall rise out of Israel, And batter the brow of Moab, And destroy all the sons of tumult.

18. "And Edom shall be a possession; Seir also, his enemies, shall be a possession, While Israel does valiantly.

19. Out of Jacob One shall have dominion, And destroy the remains of the city."

20. Then he looked on Amalek, and he took up his oracle and said: "Amalek was first among the nations, But shall be last until he perishes."

21. Then he looked on the Kenites, and he took up his oracle and said: "Firm is your dwelling place, And your nest is set in the rock;

22. Nevertheless Kain shall be burned. How long until Asshur carries you away captive?"

23. Then he took up his oracle and said: "Alas! Who shall live when God does this?

24. But ships shall come from the coasts of Cyprus, And they shall afflict Asshur and afflict Eber, And so shall Amalek, until he perishes."

25. So Balaam rose and departed and returned to his place; Balak also went his way.

## Chapter 25

1. Now Israel remained in Acacia Grove, and the people began to commit harlotry with the women of Moab.

2. They invited the people to the sacrifices of their gods, and the people ate and bowed down to their gods.

3. So Israel was joined to Baal of Peor, and the anger of the LORD was aroused against Israel.

4. Then the LORD said to Moses, "Take all the leaders of the people and hang the offenders before the LORD, out in the sun, that the fierce anger of the LORD may turn away from Israel."

5. So Moses said to the judges of Israel, "Every one of you kill his men who were joined to Baal of Peor."

6. And indeed, one of the children of Israel came and presented to his brethren a Midianite woman in the sight of Moses and in the sight of all the congregation of the children of Israel, who were weeping at the door of the tabernacle of meeting.

7. Now when Phinehas the son of Eleazar, the son of Aaron the priest, saw it, he rose from among the congregation and took a javelin in his hand;

8. and he went after the man of Israel into the tent and thrust both of them through, the man of Israel, and the woman through her body. So the plague was stopped among the children of Israel.

9. And those who died in the plague were twenty-four thousand.

10. Then the LORD spoke to Moses, saying:

11. "Phinehas the son of Eleazar, the son of Aaron the priest, has turned back My wrath from the children of Israel, because he was zealous with My zeal among them, so that I did not consume the children of Israel in My zeal.

12. Therefore say, "Behold, I give to him My covenant of peace;

13. and it shall be to him and his descendants after him a covenant of an everlasting priesthood, because he was zealous for his God, and made atonement for the children of Israel."'

14. Now the name of the Israelite who was killed, who was killed with the Midianite woman, was Zimri the son of Salu, a leader of a father's house among the Simeonites.

15. And the name of the Midianite woman who was killed was Cozbi the daughter of Zur; he was head of the people of a father's house in Midian.

16. Then the LORD spoke to Moses, saying:

17. "Harass the Midianites, and attack them;

18. for they harassed you with their schemes by which they seduced you in the matter of Peor and in the matter of Cozbi, the daughter of a leader of Midian, their sister, who was killed in the day of the plague because of Peor."

## Chapter 26

1. And it came to pass, after the plague, that the LORD spoke to Moses and Eleazar the son of Aaron the priest, saying:

2. "Take a census of all the congregation of the children of Israel from twenty years old and above, by their fathers' houses, all who are able to go to war in Israel."

3. So Moses and Eleazar the priest spoke with them in the plains of Moab by the Jordan, across from Jericho, saying:

4. "Take a census of the people from twenty years old and above, just as the LORD commanded Moses and the children of Israel who came out of the land of Egypt."

5. Reuben was the firstborn of Israel. The children of Reuben were: of Hanoch, the family of the Hanochites; of Pallu, the family of the Palluites;

6. of Hezron, the family of the Hezronites; of Carmi, the family of the Carmites.

7. These are the families of the Reubenites: those who were numbered of them were forty-three thousand seven hundred and thirty.

8. And the son of Pallu was Eliab.

9. The sons of Eliab were Nemuel, Dathan, and Abiram. These are the Dathan and Abiram, representatives of the congregation, who contended against Moses and Aaron in the company of Korah, when they contended against the LORD;

10. and the earth opened its mouth and swallowed them up together with Korah when that company died, when the fire devoured two hundred and fifty men; and they became a sign.

11. Nevertheless the children of Korah did not die.

12. The sons of Simeon according to their families were: of Nemuel, the family of the Nemuelites; of Jamin, the family of the Jaminites; of Jachin, the family of the Jachinites;

13. of Zerah, the family of the Zarhites; of Shaul, the family of the Shaulites.

14. These are the families of the Simeonites: twenty-two thousand two hundred.

15. The sons of Gad according to their families were: of Zephon, the family of the Zephonites; of Haggi, the family of the Haggites; of Shuni, the family of the Shunites;

16. of Ozni, the family of the Oznites; of Eri, the family of the Erites;

17. of Arod, the family of the Arodites; of Areli, the family of the Arelites.

18. These are the families of the sons of Gad according to those who were numbered of them: forty thousand five hundred.

19. The sons of Judah were Er and Onan; and Er and Onan died in the land of Canaan.

20. And the sons of Judah according to their families were: of Shelah, the family of the Shelanites; of Perez, the family of the Parzites; of Zerah, the family of the Zarhites.

21. And the sons of Perez were: of Hezron, the family of the Hezronites; of Hamul, the family of the Hamulites.

22. These are the families of Judah according to those who were numbered of them: seventy-six thousand five hundred.

23. The sons of Issachar according to their families were: of Tola, the family of the Tolaites; of Puah, the family of the Punites;

24. of Jashub, the family of the Jashubites; of Shimron, the family of the Shimronites.

25. These are the families of Issachar according to those who were numbered of them: sixty-four thousand three hundred.

26. The sons of Zebulun according to their families were: of Sered, the family of the Sardites; of Elon, the family of the Elonites; of Jahleel, the family of the Jahleelites.

27. These are the families of the Zebulunites according to those who were numbered of them: sixty thousand five hundred.

28. The sons of Joseph according to their families, by Manasseh and Ephraim, were:

29. The sons of Manasseh: of Machir, the family of the Machirites; and Machir begot Gilead; of Gilead, the family of the Gileadites.

30. These are the sons of Gilead: of Jeezer, the family of the Jeezerites; of Helek, the family of the Helekites;

31. of Asriel, the family of the Asrielites; of Shechem, the family of the Shechemites;

32. of Shemida, the family of the Shemidaites; of Hepher, the family of the Hepherites.

33. Now Zelophehad the son of Hepher had no sons, but daughters; and the names of the daughters of Zelophehad were Mahlah, Noah, Hoglah, Milcah, and Tirzah.

34. These are the families of Manasseh; and those who were numbered of them were fifty-two thousand seven hundred.

35. These are the sons of Ephraim according to their families: of Shuthelah, the family of the Shuthalhites; of Becher, the family of the Bachrites; of Tahan, the family of the Tahanites.

36. And these are the sons of Shuthelah: of Eran, the family of the Eranites.

37. These are the families of the sons of Ephraim according to those who were numbered of them: thirty-two thousand five hundred. These are the sons of Joseph according to their families.

38. The sons of Benjamin according to their families were: of Bela, the family of the Belaites; of Ashbel, the family of the Ashbelites; of Ahiram, the family of the Ahiramites;

39. of Shupham, the family of the Shuphamites; of Hupham, the family of the Huphamites.

40. And the sons of Bela were Ard and Naaman: of Ard, the family of the Ardites; of Naaman, the family of the Naamites.

41. These are the sons of Benjamin according to their families; and those who were numbered of them were forty-five thousand six hundred.

42. These are the sons of Dan according to their families: of Shuham, the family of the Shuhamites. These are the families of Dan according to their families.

43. All the families of the Shuhamites, according to those who were numbered of them, were sixty-four thousand four hundred.

44. The sons of Asher according to their families were: of Jimna, the family of the Jimnites; of Jesui, the family of the Jesuites; of Beriah, the family of the Beriites.

45. Of the sons of Beriah: of Heber, the family of the Heberites; of Malchiel, the family of the Malchielites.

46. And the name of the daughter of Asher was Serah.

47. These are the families of the sons of Asher according to those who were numbered of them: fifty-three thousand four hundred.

48. The sons of Naphtali according to their families were: of Jahzeel, the family of the Jahzeelites; of Guni, the family of the Gunites;

49. of Jezer, the family of the Jezerites; of Shillem, the family of the Shillemites.

50. These are the families of Naphtali according to their families; and those who were numbered of them were forty-five thousand four hundred.

51. These are those who were numbered of the children of Israel: six hundred and one thousand seven hundred and thirty.

52. Then the LORD spoke to Moses, saying:

53. "To these the land shall be divided as an inheritance, according to the number of names.

54. To a large tribe you shall give a larger inheritance, and to a small tribe you shall give a smaller inheritance. Each shall be given its inheritance according to those who were numbered of them.

55. But the land shall be divided by lot; they shall inherit according to the names of the tribes of their fathers.

56. According to the lot their inheritance shall be divided between the larger and the smaller."

57. And these are those who were numbered of the Levites according to their families: of Gershon, the family of the Gershonites; of Kohath, the family of the Kohathites; of Merari, the family of the Merarites.

58. These are the families of the Levites: the family of the Libnites, the family of the Hebronites, the family of the Mahlites, the family of the Mushites, and the family of the Korathites. And Kohath begot Amram.

59. The name of Amram's wife was Jochebed the daughter of Levi, who was born to Levi in Egypt; and to Amram she bore Aaron and Moses and their sister Miriam.

60. To Aaron were born Nadab and Abihu, Eleazar and Ithamar.

61. And Nadab and Abihu died when they offered profane fire before the LORD.

62. Now those who were numbered of them were twenty-three thousand, every male from a month old and above; for they were not numbered among the other children of Israel, because there was no inheritance given to them among the children of Israel.

63. These are those who were numbered by Moses and Eleazar the priest, who numbered the children of Israel in the plains of Moab by the Jordan, across from Jericho.

64. But among these there was not a man of those who were numbered by Moses and Aaron the priest when they numbered the children of Israel in the Wilderness of Sinai.

65. For the LORD had said of them, "They shall surely die in the wilderness." So there was not left a man of them, except Caleb the son of Jephunneh and Joshua the son of Nun.

## Chapter 27

1. Then came the daughters of Zelophehad the son of Hepher, the son of Gilead, the son of Machir, the son of Manasseh, from the families of Manasseh the son of Joseph; and these were the names of his daughters: Mahlah, Noah, Hoglah, Milcah, and Tirzah.

2. And they stood before Moses, before Eleazar the priest, and before the leaders and all the congregation, by the doorway of the tabernacle of meeting, saying:

3. "Our father died in the wilderness; but he was not in the company of those who gathered together against the LORD, in company with Korah, but he died in his own sin; and he had no sons.

4. Why should the name of our father be removed from among his family because he had no son? Give us a possession among our father's brothers."

5. So Moses brought their case before the LORD.

6. And the LORD spoke to Moses, saying:

7. "The daughters of Zelophehad speak what is right; you shall surely give them a possession of inheritance among their father's brothers, and cause the inheritance of their father to pass to them.

8. And you shall speak to the children of Israel, saying: "If a man dies and has no son, then you shall cause his inheritance to pass to his daughter.

9. If he has no daughter, then you shall give his inheritance to his brothers.

10. If he has no brothers, then you shall give his inheritance to his father's brothers.

11. And if his father has no brothers, then you shall give his inheritance to the relative closest to him in his family, and he shall possess it."' And it shall be to the children of Israel a statute of judgment, just as the LORD commanded Moses.

12. Now the LORD said to Moses: "Go up into this Mount Abarim, and see the land which I have given to the children of Israel.

13. And when you have seen it, you also shall be gathered to your people, as Aaron your brother was gathered.

14. For in the Wilderness of Zin, during the strife of the congregation, you rebelled against My command to hallow Me at the waters before their eyes." (These are the waters of Meribah, at Kadesh in the Wilderness of Zin.)

15. Then Moses spoke to the LORD, saying:

16. "Let the LORD, the God of the spirits of all flesh, set a man over the congregation,

17. who may go out before them and go in before them, who may lead them out and bring them in, that the congregation of the LORD may not be like sheep which have no shepherd."

18. And the LORD said to Moses: "Take Joshua the son of Nun with you, a man in whom is the Spirit, and lay your hand on him;

19. set him before Eleazar the priest and before all the congregation, and inaugurate him in their sight.

20. And you shall give some of your authority to him, that all the congregation of the children of Israel may be obedient.

21. He shall stand before Eleazar the priest, who shall inquire before the LORD for him by the judgment of the Urim. At his word they shall go out, and at his word they shall come in, he and all the children of Israel with him--all the congregation."

22. So Moses did as the LORD commanded him. He took Joshua and set him before Eleazar the priest and before all the congregation.

23. And he laid his hands on him and inaugurated him, just as the LORD commanded by the hand of Moses.

## Chapter 28

1. Now the LORD spoke to Moses, saying,

2. "Command the children of Israel, and say to them, "My offering, My food for My offerings made by fire as a sweet aroma to Me, you shall be careful to offer to Me at their appointed time.'

3. "And you shall say to them, "This is the offering made by fire which you shall offer to the LORD: two male lambs in their first year without blemish, day by day, as a regular burnt offering.

4. The one lamb you shall offer in the morning, the other lamb you shall offer in the evening,

5. and one-tenth of an ephah of fine flour as a grain offering mixed with one-fourth of a hin of pressed oil.

6. It is a regular burnt offering which was ordained at Mount Sinai for a sweet aroma, an offering made by fire to the LORD.

7. And its drink offering shall be one-fourth of a hin for each lamb; in a holy place you shall pour out the drink to the LORD as an offering.

8. The other lamb you shall offer in the evening; as the morning grain offering and its drink offering, you shall offer it as an offering made by fire, a sweet aroma to the LORD.

9. "And on the Sabbath day two lambs in their first year, without blemish, and two-tenths of an ephah of fine flour as a grain offering, mixed with oil, with its drink offering--

10. this is the burnt offering for every Sabbath, besides the regular burnt offering with its drink offering.

11. "At the beginnings of your months you shall present a burnt offering to the LORD: two young bulls, one ram, and seven lambs in their first year, without blemish;

12. three-tenths of an ephah of fine flour as a grain offering, mixed with oil, for each bull; two-tenths of an ephah of fine flour as a grain offering, mixed with oil, for the one ram;

13. and one-tenth of an ephah of fine flour, mixed with oil, as a grain offering for each lamb, as a burnt offering of sweet aroma, an offering made by fire to the LORD.

14. Their drink offering shall be half a hin of wine for a bull, one-third of a hin for a ram, and one-fourth of a hin for a lamb; this is the burnt offering for each month throughout the months of the year.

15. Also one kid of the goats as a sin offering to the LORD shall be offered, besides the regular burnt offering and its drink offering.

16. "On the fourteenth day of the first month is the Passover of the LORD.

17. And on the fifteenth day of this month is the feast; unleavened bread shall be eaten for seven days.

18. On the first day you shall have a holy convocation. You shall do no customary work.

19. And you shall present an offering made by fire as a burnt offering to the LORD: two young bulls, one ram, and seven lambs in their first year. Be sure they are without blemish.

20. Their grain offering shall be of fine flour mixed with oil: three-tenths of an ephah you shall offer for a bull, and two-tenths for a ram;

21. you shall offer one-tenth of an ephah for each of the seven lambs;

22. also one goat as a sin offering, to make atonement for you.

23. You shall offer these besides the burnt offering of the morning, which is for a regular burnt offering.

24. In this manner you shall offer the food of the offering made by fire daily for seven days, as a sweet aroma to the LORD; it shall be offered besides the regular burnt offering and its drink offering.

25. And on the seventh day you shall have a holy convocation. You shall do no customary work.

26. "Also on the day of the firstfruits, when you bring a new grain offering to the LORD at your Feast of Weeks, you shall have a holy convocation. You shall do no customary work.

27. You shall present a burnt offering as a sweet aroma to the LORD: two young bulls, one ram, and seven lambs in their first year,

28. with their grain offering of fine flour mixed with oil: three-tenths of an ephah for each bull, two-tenths for the one ram,

29. and one-tenth for each of the seven lambs;

30. also one kid of the goats, to make atonement for you.

31. Be sure they are without blemish. You shall present them with their drink offerings, besides the regular burnt offering with its grain offering.

## Chapter 29

1. "And in the seventh month, on the first day of the month, you shall have a holy convocation. You shall do no customary work. For you it is a day of blowing the trumpets.

2. You shall offer a burnt offering as a sweet aroma to the LORD: one young bull, one ram, and seven lambs in their first year, without blemish.

3. Their grain offering shall be fine flour mixed with oil: three-tenths of an ephah for the bull, two-tenths for the ram,

4. and one-tenth for each of the seven lambs;

5. also one kid of the goats as a sin offering, to make atonement for you;

6. besides the burnt offering with its grain offering for the New Moon, the regular burnt offering with its grain offering, and their drink offerings, according to their ordinance, as a sweet aroma, an offering made by fire to the LORD.

7. "On the tenth day of this seventh month you shall have a holy convocation. You shall afflict your souls; you shall not do any work.

8. You shall present a burnt offering to the LORD as a sweet aroma: one young bull, one ram, and seven lambs in their first year. Be sure they are without blemish.

9. Their grain offering shall be of fine flour mixed with oil: three-tenths of an ephah for the bull, two-tenths for the one ram,

10. and one-tenth for each of the seven lambs;

11. also one kid of the goats as a sin offering, besides the sin offering for atonement, the regular burnt offering with its grain offering, and their drink offerings. ]

12. "On the fifteenth day of the seventh month you shall have a holy convocation. You shall do no customary work, and you shall keep a feast to the LORD seven days.

13. You shall present a burnt offering, an offering made by fire as a sweet aroma to the LORD: thirteen young bulls, two rams, and fourteen lambs in their first year. They shall be without blemish.

14. Their grain offering shall be of fine flour mixed with oil: three-tenths of an ephah for each of the thirteen bulls, two-tenths for each of the two rams,

15. and one-tenth for each of the fourteen lambs;

16. also one kid of the goats as a sin offering, besides the regular burnt offering, its grain offering, and its drink offering.

17. "On the second day present twelve young bulls, two rams, fourteen lambs in their first year without blemish,

18. and their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, by their number, according to the ordinance;

19. also one kid of the goats as a sin offering, besides the regular burnt offering with its grain offering, and their drink offerings.

20. "On the third day present eleven bulls, two rams, fourteen lambs in their first year without blemish,

21. and their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, by their number, according to the ordinance;

22. also one goat as a sin offering, besides the regular burnt offering, its grain offering, and its drink offering.

23. "On the fourth day present ten bulls, two rams, and fourteen lambs in their first year, without blemish,

24. and their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, by their number, according to the ordinance;

25. also one kid of the goats as a sin offering, besides the regular burnt offering, its grain offering, and its drink offering.

26. "On the fifth day present nine bulls, two rams, and fourteen lambs in their first year without blemish,

27. and their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, by their number, according to the ordinance;

28. also one goat as a sin offering, besides the regular burnt offering, its grain offering, and its drink offering.

29. "On the sixth day present eight bulls, two rams, and fourteen lambs in their first year without blemish,

30. and their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, by their number, according to the ordinance;

31. also one goat as a sin offering, besides the regular burnt offering, its grain offering, and its drink offering.

32. "On the seventh day present seven bulls, two rams, and fourteen lambs in their first year without blemish,

33. and their grain offering and their drink offerings for the bulls, for the rams, and for the lambs, by their number, according to the ordinance;

34. also one goat as a sin offering, besides the regular burnt offering, its grain offering, and its drink offering.

35. "On the eighth day you shall have a sacred assembly. You shall do no customary work.

36. You shall present a burnt offering, an offering made by fire as a sweet aroma to the LORD: one bull, one ram, seven lambs in their first year without blemish,

37. and their grain offering and their drink offerings for the bull, for the ram, and for the lambs, by their number, according to the ordinance;

38. also one goat as a sin offering, besides the regular burnt offering, its grain offering, and its drink offering.

39. "These you shall present to the LORD at your appointed feasts (besides your vowed offerings and your freewill offerings) as your burnt offerings and your grain offerings, as your drink offerings and your peace offerings."'

40. So Moses told the children of Israel everything, just as the LORD commanded Moses.

## Chapter 30

1. Then Moses spoke to the heads of the tribes concerning the children of Israel, saying, "This is the thing which the LORD has commanded:

2. If a man makes a vow to the LORD, or swears an oath to bind himself by some agreement, he shall not break his word; he shall do according to all that proceeds out of his mouth.

3. "Or if a woman makes a vow to the LORD, and binds herself by some agreement while in her father's house in her youth,

4. and her father hears her vow and the agreement by which she has bound herself, and her father holds his peace, then all her vows shall stand, and every agreement with which she has bound herself shall stand.

5. But if her father overrules her on the day that he hears, then none of her vows nor her agreements by which she has bound herself shall stand; and the LORD will release her, because her father overruled her.

6. "If indeed she takes a husband, while bound by her vows or by a rash utterance from her lips by which she bound herself,

7. and her husband hears it, and makes no response to her on the day that he hears, then her vows shall stand, and her agreements by which she bound herself shall stand.

8. But if her husband overrules her on the day that he hears it, he shall make void her vow which she took and what she uttered with her lips, by which she bound herself, and the LORD will release her.

9. "Also any vow of a widow or a divorced woman, by which she has bound herself, shall stand against her.

10. "If she vowed in her husband's house, or bound herself by an agreement with an oath,

11. and her husband heard it, and made no response to her and did not overrule her, then all her vows shall stand, and every agreement by which she bound herself shall stand.

12. But if her husband truly made them void on the day he heard them, then whatever proceeded from her lips concerning her vows or concerning the agreement binding her, it shall not stand; her husband has made them void, and the LORD will release her.

13. Every vow and every binding oath to afflict her soul, her husband may confirm it, or her husband may make it void.

14. Now if her husband makes no response whatever to her from day to day, then he confirms all her vows or all the agreements that bind her; he confirms them, because he made no response to her on the day that he heard them.

15. But if he does make them void after he has heard them, then he shall bear her guilt."

16. These are the statutes which the LORD commanded Moses, between a man and his wife, and between a father and his daughter in her youth in her father's house.

## Chapter 31

1. And the LORD spoke to Moses, saying:

2. "Take vengeance on the Midianites for the children of Israel. Afterward you shall be gathered to your people."

3. So Moses spoke to the people, saying, "Arm some of yourselves for war, and let them go against the Midianites to take vengeance for the LORD on Midian.

4. A thousand from each tribe of all the tribes of Israel you shall send to the war."

5. So there were recruited from the divisions of Israel one thousand from each tribe, twelve thousand armed for war.

6. Then Moses sent them to the war, one thousand from each tribe; he sent them to the war with Phinehas the son of Eleazar the priest, with the holy articles and the signal trumpets in his hand.

7. And they warred against the Midianites, just as the LORD commanded Moses, and they killed all the males.

8. They killed the kings of Midian with the rest of those who were killed--Evi, Rekem, Zur, Hur, and Reba, the five kings of Midian. Balaam the son of Beor they also killed with the sword.

9. And the children of Israel took the women of Midian captive, with their little ones, and took as spoil all their cattle, all their flocks, and all their goods.

10. They also burned with fire all the cities where they dwelt, and all their forts.

11. And they took all the spoil and all the booty--of man and beast.

12. Then they brought the captives, the booty, and the spoil to Moses, to Eleazar the priest, and to the congregation of the children of Israel, to the camp in the plains of Moab by the Jordan, across from Jericho.

13. And Moses, Eleazar the priest, and all the leaders of the congregation, went to meet them outside the camp.

14. But Moses was angry with the officers of the army, with the captains over thousands and captains over hundreds, who had come from the battle.

15. And Moses said to them: "Have you kept all the women alive?

16. Look, these women caused the children of Israel, through the counsel of Balaam, to trespass against the LORD in the incident of Peor, and there was a plague among the congregation of the LORD.

17. Now therefore, kill every male among the little ones, and kill every woman who has known a man intimately.

18. But keep alive for yourselves all the young girls who have not known a man intimately.

19. And as for you, remain outside the camp seven days; whoever has killed any person, and whoever has touched any slain, purify yourselves and your captives on the third day and on the seventh day.

20. Purify every garment, everything made of leather, everything woven of goats' hair, and everything made of wood."

21. Then Eleazar the priest said to the men of war who had gone to the battle, "This is the ordinance of the law which the LORD commanded Moses:

22. "Only the gold, the silver, the bronze, the iron, the tin, and the lead,

23. everything that can endure fire, you shall put through the fire, and it shall be clean; and it shall be purified with the water of purification. But all that cannot endure fire you shall put through water.

24. And you shall wash your clothes on the seventh day and be clean, and afterward you may come into the camp."

25. Now the LORD spoke to Moses, saying:

26. "Count up the plunder that was taken--of man and beast--you and Eleazar the priest and the chief fathers of the congregation;

27. and divide the plunder into two parts, between those who took part in the war, who went out to battle, and all the congregation.

28. And levy a tribute for the LORD on the men of war who went out to battle: one of every five hundred of the persons, the cattle, the donkeys, and the sheep;

29. take it from their half, and give it to Eleazar the priest as a heave offering to the LORD.

30. And from the children of Israel's half you shall take one of every fifty, drawn from the persons, the cattle, the donkeys, and the sheep, from all the livestock, and give them to the Levites who keep charge of the tabernacle of the LORD."

31. So Moses and Eleazar the priest did as the LORD commanded Moses.

32. The booty remaining from the plunder, which the men of war had taken, was six hundred and seventy-five thousand sheep,

33. seventy-two thousand cattle,

34. sixty-one thousand donkeys,

35. and thirty-two thousand persons in all, of women who had not known a man intimately.

36. And the half, the portion for those who had gone out to war, was in number three hundred and thirty-seven thousand five hundred sheep;

37. and the LORD's tribute of the sheep was six hundred and seventy-five.

38. The cattle were thirty-six thousand, of which the LORD's tribute was seventy-two.

39. The donkeys were thirty thousand five hundred, of which the LORD's tribute was sixty-one.

40. The persons were sixteen thousand, of which the LORD's tribute was thirty-two persons.

41. So Moses gave the tribute which was the LORD's heave offering to Eleazar the priest, as the LORD commanded Moses.

42. And from the children of Israel's half, which Moses separated from the men who fought--

43. now the half belonging to the congregation was three hundred and thirty-seven thousand five hundred sheep,

44. thirty-six thousand cattle,

45. thirty thousand five hundred donkeys,

46. and sixteen thousand persons--

47. and from the children of Israel's half Moses took one of every fifty, drawn from man and beast, and gave them to the Levites, who kept charge of the tabernacle of the LORD, as the LORD commanded Moses.

48. Then the officers who were over thousands of the army, the captains of thousands and captains of hundreds, came near to Moses;

49. and they said to Moses, "Your servants have taken a count of the men of war who are under our command, and not a man of us is missing.

50. Therefore we have brought an offering for the LORD, what every man found of ornaments of gold: armlets and bracelets and signet rings and earrings and necklaces, to make atonement for ourselves before the LORD."

51. So Moses and Eleazar the priest received the gold from them, all the fashioned ornaments.

52. And all the gold of the offering that they offered to the LORD, from the captains of thousands and captains of hundreds, was sixteen thousand seven hundred and fifty shekels.

53. (The men of war had taken spoil, every man for himself.)

54. And Moses and Eleazar the priest received the gold from the captains of thousands and of hundreds, and brought it into the tabernacle of meeting as a memorial for the children of Israel before the LORD.

## Chapter 32

1. Now the children of Reuben and the children of Gad had a very great multitude of livestock; and when they saw the land of Jazer and the land of Gilead, that indeed the region was a place for livestock,

2. the children of Gad and the children of Reuben came and spoke to Moses, to Eleazar the priest, and to the leaders of the congregation, saying,

3. "Ataroth, Dibon, Jazer, Nimrah, Heshbon, Elealeh, Shebam, Nebo, and Beon,

4. the country which the LORD defeated before the congregation of Israel, is a land for livestock, and your servants have livestock."

5. Therefore they said, "If we have found favor in your sight, let this land be given to your servants as a possession. Do not take us over the Jordan."

6. And Moses said to the children of Gad and to the children of Reuben: "Shall your brethren go to war while you sit here?

7. Now why will you discourage the heart of the children of Israel from going over into the land which the LORD has given them?

8. Thus your fathers did when I sent them away from Kadesh Barnea to see the land.

9. For when they went up to the Valley of Eshcol and saw the land, they discouraged the heart of the children of Israel, so that they did not go into the land which the LORD had given them.

10. So the LORD's anger was aroused on that day, and He swore an oath, saying,

11. "Surely none of the men who came up from Egypt, from twenty years old and above, shall see the land of which I swore to Abraham, Isaac, and Jacob, because they have not wholly followed Me,

12. except Caleb the son of Jephunneh, the Kenizzite, and Joshua the son of Nun, for they have wholly followed the LORD.'

13. So the LORD's anger was aroused against Israel, and He made them wander in the wilderness forty years, until all the generation that had done evil in the sight of the LORD was gone.

14. And look! You have risen in your fathers' place, a brood of sinful men, to increase still more the fierce anger of the LORD against Israel.

15. For if you turn away from following Him, He will once again leave them in the wilderness, and you will destroy all these people."

16. Then they came near to him and said: "We will build sheepfolds here for our livestock, and cities for our little ones,

17. but we ourselves will be armed, ready to go before the children of Israel until we have brought them to their place; and our little ones will dwell in the fortified cities because of the inhabitants of the land.

18. We will not return to our homes until every one of the children of Israel has received his inheritance.

19. For we will not inherit with them on the other side of the Jordan and beyond, because our inheritance has fallen to us on this eastern side of the Jordan."

20. Then Moses said to them: "If you do this thing, if you arm yourselves before the LORD for the war,

21. and all your armed men cross over the Jordan before the LORD until He has driven out His enemies from before Him,

22. and the land is subdued before the LORD, then afterward you may return and be blameless before the LORD and before Israel; and this land shall be your possession before the LORD.

23. But if you do not do so, then take note, you have sinned against the LORD; and be sure your sin will find you out.

24. Build cities for your little ones and folds for your sheep, and do what has proceeded out of your mouth."

25. And the children of Gad and the children of Reuben spoke to Moses, saying: "Your servants will do as my lord commands.

26. Our little ones, our wives, our flocks, and all our livestock will be there in the cities of Gilead;

27. but your servants will cross over, every man armed for war, before the LORD to battle, just as my lord says."

28. So Moses gave command concerning them to Eleazar the priest, to Joshua the son of Nun, and to the chief fathers of the tribes of the children of Israel.

29. And Moses said to them: "If the children of Gad and the children of Reuben cross over the Jordan with you, every man armed for battle before the LORD, and the land is subdued before you, then you shall give them the land of Gilead as a possession.

30. But if they do not cross over armed with you, they shall have possessions among you in the land of Canaan."

31. Then the children of Gad and the children of Reuben answered, saying: "As the LORD has said to your servants, so we will do.

32. We will cross over armed before the LORD into the land of Canaan, but the possession of our inheritance shall remain with us on this side of the Jordan."

33. So Moses gave to the children of Gad, to the children of Reuben, and to half the tribe of Manasseh the son of Joseph, the kingdom of Sihon king of the Amorites and the kingdom of Og king of Bashan, the land with its cities within the borders, the cities of the surrounding country.

34. And the children of Gad built Dibon and Ataroth and Aroer,

35. Atroth and Shophan and Jazer and Jogbehah,

36. Beth Nimrah and Beth Haran, fortified cities, and folds for sheep.

37. And the children of Reuben built Heshbon and Elealeh and Kirjathaim,

38. Nebo and Baal Meon (their names being changed) and Shibmah; and they gave other names to the cities which they built.

39. And the children of Machir the son of Manasseh went to Gilead and took it, and dispossessed the Amorites who were in it.

40. So Moses gave Gilead to Machir the son of Manasseh, and he dwelt in it.

41. Also Jair the son of Manasseh went and took its small towns, and called them Havoth Jair.

42. Then Nobah went and took Kenath and its villages, and he called it Nobah, after his own name.

## Chapter 33

1. These are the journeys of the children of Israel, who went out of the land of Egypt by their armies under the hand of Moses and Aaron.

2. Now Moses wrote down the starting points of their journeys at the command of the LORD. And these are their journeys according to their starting points:

3. They departed from Rameses in the first month, on the fifteenth day of the first month; on the day after the Passover the children of Israel went out with boldness in the sight of all the Egyptians.

4. For the Egyptians were burying all their firstborn, whom the LORD had killed among them. Also on their gods the LORD had executed judgments.

5. Then the children of Israel moved from Rameses and camped at Succoth.

6. They departed from Succoth and camped at Etham, which is on the edge of the wilderness.

7. They moved from Etham and turned back to Pi Hahiroth, which is east of Baal Zephon; and they camped near Migdol.

8. They departed from before Hahiroth and passed through the midst of the sea into the wilderness, went three days' journey in the Wilderness of Etham, and camped at Marah.

9. They moved from Marah and came to Elim. At Elim were twelve springs of water and seventy palm trees; so they camped there.

10. They moved from Elim and camped by the Red Sea.

11. They moved from the Red Sea and camped in the Wilderness of Sin.

12. They journeyed from the Wilderness of Sin and camped at Dophkah.

13. They departed from Dophkah and camped at Alush.

14. They moved from Alush and camped at Rephidim, where there was no water for the people to drink.

15. They departed from Rephidim and camped in the Wilderness of Sinai.

16. They moved from the Wilderness of Sinai and camped at Kibroth Hattaavah.

17. They departed from Kibroth Hattaavah and camped at Hazeroth.

18. They departed from Hazeroth and camped at Rithmah.

19. They departed from Rithmah and camped at Rimmon Perez.

20. They departed from Rimmon Perez and camped at Libnah.

21. They moved from Libnah and camped at Rissah.

22. They journeyed from Rissah and camped at Kehelathah.

23. They went from Kehelathah and camped at Mount Shepher.

24. They moved from Mount Shepher and camped at Haradah.

25. They moved from Haradah and camped at Makheloth.

26. They moved from Makheloth and camped at Tahath.

27. They departed from Tahath and camped at Terah.

28. They moved from Terah and camped at Mithkah.

29. They went from Mithkah and camped at Hashmonah.

30. They departed from Hashmonah and camped at Moseroth.

31. They departed from Moseroth and camped at Bene Jaakan.

32. They moved from Bene Jaakan and camped at Hor Hagidgad.

33. They went from Hor Hagidgad and camped at Jotbathah.

34. They moved from Jotbathah and camped at Abronah.

35. They departed from Abronah and camped at Ezion Geber.

36. They moved from Ezion Geber and camped in the Wilderness of Zin, which is Kadesh.

37. They moved from Kadesh and camped at Mount Hor, on the boundary of the land of Edom.

38. Then Aaron the priest went up to Mount Hor at the command of the LORD, and died there in the fortieth year after the children of Israel had come out of the land of Egypt, on the first day of the fifth month.

39. Aaron was one hundred and twenty-three years old when he died on Mount Hor.

40. Now the king of Arad, the Canaanite, who dwelt in the South in the land of Canaan, heard of the coming of the children of Israel.

41. So they departed from Mount Hor and camped at Zalmonah.

42. They departed from Zalmonah and camped at Punon.

43. They departed from Punon and camped at Oboth.

44. They departed from Oboth and camped at Ije Abarim, at the border of Moab.

45. They departed from Ijim and camped at Dibon Gad.

46. They moved from Dibon Gad and camped at Almon Diblathaim.

47. They moved from Almon Diblathaim and camped in the mountains of Abarim, before Nebo.

48. They departed from the mountains of Abarim and camped in the plains of Moab by the Jordan, across from Jericho.

49. They camped by the Jordan, from Beth Jesimoth as far as the Abel Acacia Grove in the plains of Moab.

50. Now the LORD spoke to Moses in the plains of Moab by the Jordan, across from Jericho, saying,

51. "Speak to the children of Israel, and say to them: "When you have crossed the Jordan into the land of Canaan,

52. then you shall drive out all the inhabitants of the land from before you, destroy all their engraved stones, destroy all their molded images, and demolish all their high places;

53. you shall dispossess the inhabitants of the land and dwell in it, for I have given you the land to possess.

54. And you shall divide the land by lot as an inheritance among your families; to the larger you shall give a larger inheritance, and to the smaller you shall give a smaller inheritance; there everyone's inheritance shall be whatever falls to him by lot. You shall inherit according to the tribes of your fathers.

55. But if you do not drive out the inhabitants of the land from before you, then it shall be that those whom you let remain shall be irritants in your eyes and thorns in your sides, and they shall harass you in the land where you dwell.

56. Moreover it shall be that I will do to you as I thought to do to them."'

## Chapter 34

1. Then the LORD spoke to Moses, saying,

2. "Command the children of Israel, and say to them: "When you come into the land of Canaan, this is the land that shall fall to you as an inheritance--the land of Canaan to its boundaries.

3. Your southern border shall be from the Wilderness of Zin along the border of Edom; then your southern border shall extend eastward to the end of the Salt Sea;

4. your border shall turn from the southern side of the Ascent of Akrabbim, continue to Zin, and be on the south of Kadesh Barnea; then it shall go on to Hazar Addar, and continue to Azmon;

5. the border shall turn from Azmon to the Brook of Egypt, and it shall end at the Sea.

6. "As for the western border, you shall have the Great Sea for a border; this shall be your western border.

7. "And this shall be your northern border: From the Great Sea you shall mark out your border line to Mount Hor;

8. from Mount Hor you shall mark out your border to the entrance of Hamath; then the direction of the border shall be toward Zedad;

9. the border shall proceed to Ziphron, and it shall end at Hazar Enan. This shall be your northern border.

10. "You shall mark out your eastern border from Hazar Enan to Shepham;

11. the border shall go down from Shepham to Riblah on the east side of Ain; the border shall go down and reach to the eastern side of the Sea of Chinnereth;

12. the border shall go down along the Jordan, and it shall end at the Salt Sea. This shall be your land with its surrounding boundaries."'

13. Then Moses commanded the children of Israel, saying: "This is the land which you shall inherit by lot, which the LORD has commanded to give to the nine tribes and to the half-tribe.

14. For the tribe of the children of Reuben according to the house of their fathers, and the tribe of the children of Gad according to the house of their fathers, have received their inheritance; and the half-tribe of Manasseh has received its inheritance.

15. The two tribes and the half-tribe have received their inheritance on this side of the Jordan, across from Jericho eastward, toward the sunrise."

16. And the LORD spoke to Moses, saying,

17. "These are the names of the men who shall divide the land among you as an inheritance: Eleazar the priest and Joshua the son of Nun.

18. And you shall take one leader of every tribe to divide the land for the inheritance.

19. These are the names of the men: from the tribe of Judah, Caleb the son of Jephunneh;

20. from the tribe of the children of Simeon, Shemuel the son of Ammihud;

21. from the tribe of Benjamin, Elidad the son of Chislon;

22. a leader from the tribe of the children of Dan, Bukki the son of Jogli;

23. from the sons of Joseph: a leader from the tribe of the children of Manasseh, Hanniel the son of Ephod,

24. and a leader from the tribe of the children of Ephraim, Kemuel the son of Shiphtan;

25. a leader from the tribe of the children of Zebulun, Elizaphan the son of Parnach;

26. a leader from the tribe of the children of Issachar, Paltiel the son of Azzan;

27. a leader from the tribe of the children of Asher, Ahihud the son of Shelomi;

28. and a leader from the tribe of the children of Naphtali, Pedahel the son of Ammihud."

29. These are the ones the LORD commanded to divide the inheritance among the children of Israel in the land of Canaan.

## Chapter 35

1. And the LORD spoke to Moses in the plains of Moab by the Jordan across from Jericho, saying:

2. "Command the children of Israel that they give the Levites cities to dwell in from the inheritance of their possession, and you shall also give the Levites common-land around the cities.

3. They shall have the cities to dwell in; and their common-land shall be for their cattle, for their herds, and for all their animals.

4. The common-land of the cities which you will give the Levites shall extend from the wall of the city outward a thousand cubits all around.

5. And you shall measure outside the city on the east side two thousand cubits, on the south side two thousand cubits, on the west side two thousand cubits, and on the north side two thousand cubits. The city shall be in the middle. This shall belong to them as common-land for the cities.

6. "Now among the cities which you will give to the Levites you shall appoint six cities of refuge, to which a manslayer may flee. And to these you shall add forty-two cities.

7. So all the cities you will give to the Levites shall be forty-eight; these you shall give with their common-land.

8. And the cities which you will give shall be from the possession of the children of Israel; from the larger tribe you shall give many, from the smaller you shall give few. Each shall give some of its cities to the Levites, in proportion to the inheritance that each receives."

9. Then the LORD spoke to Moses, saying,

10. "Speak to the children of Israel, and say to them: "When you cross the Jordan into the land of Canaan,

11. then you shall appoint cities to be cities of refuge for you, that the manslayer who kills any person accidentally may flee there.

12. They shall be cities of refuge for you from the avenger, that the manslayer may not die until he stands before the congregation in judgment.

13. And of the cities which you give, you shall have six cities of refuge.

14. You shall appoint three cities on this side of the Jordan, and three cities you shall appoint in the land of Canaan, which will be cities of refuge.

15. These six cities shall be for refuge for the children of Israel, for the stranger, and for the sojourner among them, that anyone who kills a person accidentally may flee there.

16. "But if he strikes him with an iron implement, so that he dies, he is a murderer; the murderer shall surely be put to death.

17. And if he strikes him with a stone in the hand, by which one could die, and he does die, he is a murderer; the murderer shall surely be put to death.

18. Or if he strikes him with a wooden hand weapon, by which one could die, and he does die, he is a murderer; the murderer shall surely be put to death.

19. The avenger of blood himself shall put the murderer to death; when he meets him, he shall put him to death.

20. If he pushes him out of hatred or, while lying in wait, hurls something at him so that he dies,

21. or in enmity he strikes him with his hand so that he dies, the one who struck him shall surely be put to death. He is a murderer. The avenger of blood shall put the murderer to death when he meets him.

22. "However, if he pushes him suddenly without enmity, or throws anything at him without lying in wait,

23. or uses a stone, by which a man could die, throwing it at him without seeing him, so that he dies, while he was not his enemy or seeking his harm,

24. then the congregation shall judge between the manslayer and the avenger of blood according to these judgments.

25. So the congregation shall deliver the manslayer from the hand of the avenger of blood, and the congregation shall return him to the city of refuge where he had fled, and he shall remain there until the death of the high priest who was anointed with the holy oil.

26. But if the manslayer at any time goes outside the limits of the city of refuge where he fled,

27. and the avenger of blood finds him outside the limits of his city of refuge, and the avenger of blood kills the manslayer, he shall not be guilty of blood,

28. because he should have remained in his city of refuge until the death of the high priest. But after the death of the high priest the manslayer may return to the land of his possession.

29. "And these things shall be a statute of judgment to you throughout your generations in all your dwellings.

30. Whoever kills a person, the murderer shall be put to death on the testimony of witnesses; but one witness is not sufficient testimony against a person for the death penalty.

31. Moreover you shall take no ransom for the life of a murderer who is guilty of death, but he shall surely be put to death.

32. And you shall take no ransom for him who has fled to his city of refuge, that he may return to dwell in the land before the death of the priest.

33. So you shall not pollute the land where you are; for blood defiles the land, and no atonement can be made for the land, for the blood that is shed on it, except by the blood of him who shed it.

34. Therefore do not defile the land which you inhabit, in the midst of which I dwell; for I the LORD dwell among the children of Israel."'

## Chapter 36

1. Now the chief fathers of the families of the children of Gilead the son of Machir, the son of Manasseh, of the families of the sons of Joseph, came near and spoke before Moses and before the leaders, the chief fathers of the children of Israel.

2. And they said: "The LORD commanded my lord Moses to give the land as an inheritance by lot to the children of Israel, and my lord was commanded by the LORD to give the inheritance of our brother Zelophehad to his daughters.

3. Now if they are married to any of the sons of the other tribes of the children of Israel, then their inheritance will be taken from the inheritance of our fathers, and it will be added to the inheritance of the tribe into which they marry; so it will be taken from the lot of our inheritance.

4. And when the Jubilee of the children of Israel comes, then their inheritance will be added to the inheritance of the tribe into which they marry; so their inheritance will be taken away from the inheritance of the tribe of our fathers."

5. Then Moses commanded the children of Israel according to the word of the LORD, saying: "What the tribe of the sons of Joseph speaks is right.

6. This is what the LORD commands concerning the daughters of Zelophehad, saying, "Let them marry whom they think best, but they may marry only within the family of their father's tribe.'

7. So the inheritance of the children of Israel shall not change hands from tribe to tribe, for every one of the children of Israel shall keep the inheritance of the tribe of his fathers.

8. And every daughter who possesses an inheritance in any tribe of the children of Israel shall be the wife of one of the family of her father's tribe, so that the children of Israel each may possess the inheritance of his fathers.

9. Thus no inheritance shall change hands from one tribe to another, but every tribe of the children of Israel shall keep its own inheritance."

10. Just as the LORD commanded Moses, so did the daughters of Zelophehad;

11. for Mahlah, Tirzah, Hoglah, Milcah, and Noah, the daughters of Zelophehad, were married to the sons of their father's brothers.

12. They were married into the families of the children of Manasseh the son of Joseph, and their inheritance remained in the tribe of their father's family.

13. These are the commandments and the judgments which the LORD commanded the children of Israel by the hand of Moses in the plains of Moab by the Jordan, across from Jericho.


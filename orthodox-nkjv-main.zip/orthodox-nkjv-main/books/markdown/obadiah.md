# obadiah

## Chapter 1

1. The vision of Obadiah. Thus says the Lord GOD concerning Edom (We have heard a report from the LORD, And a messenger has been sent among the nations, saying, "Arise, and let us rise up against her for battle"):

2. "Behold, I will make you small among the nations; You shall be greatly despised.

3. The pride of your heart has deceived you, You who dwell in the clefts of the rock, Whose habitation is high; You who say in your heart, "Who will bring me down to the ground?'

4. Though you ascend as high as the eagle, And though you set your nest among the stars, From there I will bring you down," says the LORD.

5. "If thieves had come to you, If robbers by night-- Oh, how you will be cut off!-- Would they not have stolen till they had enough? If grape-gatherers had come to you, Would they not have left some gleanings?

6. "Oh, how Esau shall be searched out! How his hidden treasures shall be sought after!

7. All the men in your confederacy Shall force you to the border; The men at peace with you Shall deceive you and prevail against you. Those who eat your bread shall lay a trap for you. No one is aware of it.

8. "Will I not in that day," says the LORD, "Even destroy the wise men from Edom, And understanding from the mountains of Esau?

9. Then your mighty men, O Teman, shall be dismayed, To the end that everyone from the mountains of Esau May be cut off by slaughter.

10. "For violence against your brother Jacob, Shame shall cover you, And you shall be cut off forever.

11. In the day that you stood on the other side-- In the day that strangers carried captive his forces, When foreigners entered his gates And cast lots for Jerusalem-- Even you were as one of them.

12. "But you should not have gazed on the day of your brother In the day of his captivity; Nor should you have rejoiced over the children of Judah In the day of their destruction; Nor should you have spoken proudly In the day of distress.

13. You should not have entered the gate of My people In the day of their calamity. Indeed, you should not have gazed on their affliction In the day of their calamity, Nor laid hands on their substance In the day of their calamity.

14. You should not have stood at the crossroads To cut off those among them who escaped; Nor should you have delivered up those among them who remained In the day of distress.

15. "For the day of the LORD upon all the nations is near; As you have done, it shall be done to you; Your reprisal shall return upon your own head.

16. For as you drank on My holy mountain, So shall all the nations drink continually; Yes, they shall drink, and swallow, And they shall be as though they had never been.

17. "But on Mount Zion there shall be deliverance, And there shall be holiness; The house of Jacob shall possess their possessions.

18. The house of Jacob shall be a fire, And the house of Joseph a flame; But the house of Esau shall be stubble; They shall kindle them and devour them, And no survivor shall remain of the house of Esau," For the LORD has spoken.

19. The South shall possess the mountains of Esau, And the Lowland shall possess Philistia. They shall possess the fields of Ephraim And the fields of Samaria. Benjamin shall possess Gilead.

20. And the captives of this host of the children of Israel Shall possess the land of the Canaanites As far as Zarephath. The captives of Jerusalem who are in Sepharad Shall possess the cities of the South.

21. Then saviors shall come to Mount Zion To judge the mountains of Esau, And the kingdom shall be the LORD's.


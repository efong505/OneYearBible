# philemon

## Chapter 1

1. Paul, a prisoner of Christ Jesus, and Timothy our brother, To Philemon our beloved friend and fellow laborer,

2. to the beloved Apphia, Archippus our fellow soldier, and to the church in your house:

3. Grace to you and peace from God our Father and the Lord Jesus Christ.

4. I thank my God, making mention of you always in my prayers,

5. hearing of your love and faith which you have toward the Lord Jesus and toward all the saints,

6. that the sharing of your faith may become effective by the acknowledgment of every good thing which is in you in Christ Jesus.

7. For we have great joy and consolation in your love, because the hearts of the saints have been refreshed by you, brother.

8. Therefore, though I might be very bold in Christ to command you what is fitting,

9. yet for love's sake I rather appeal to you--being such a one as Paul, the aged, and now also a prisoner of Jesus Christ--

10. I appeal to you for my son Onesimus, whom I have begotten while in my chains,

11. who once was unprofitable to you, but now is profitable to you and to me.

12. I am sending him back. You therefore receive him, that is, my own heart,

13. whom I wished to keep with me, that on your behalf he might minister to me in my chains for the gospel.

14. But without your consent I wanted to do nothing, that your good deed might not be by compulsion, as it were, but voluntary.

15. For perhaps he departed for a while for this purpose, that you might receive him forever,

16. no longer as a slave but more than a slave--a beloved brother, especially to me but how much more to you, both in the flesh and in the Lord.

17. If then you count me as a partner, receive him as you would me.

18. But if he has wronged you or owes anything, put that on my account.

19. I, Paul, am writing with my own hand. I will repay--not to mention to you that you owe me even your own self besides.

20. Yes, brother, let me have joy from you in the Lord; refresh my heart in the Lord.

21. Having confidence in your obedience, I write to you, knowing that you will do even more than I say.

22. But, meanwhile, also prepare a guest room for me, for I trust that through your prayers I shall be granted to you.

23. Epaphras, my fellow prisoner in Christ Jesus, greets you,

24. as do Mark, Aristarchus, Demas, Luke, my fellow laborers.

25. The grace of our Lord Jesus Christ be with your spirit. Amen.


# psalm

## Chapter 1

1. Blessed is the man Who walks not in the counsel of the ungodly, Nor stands in the path of sinners, Nor sits in the seat of the scornful;

2. But his delight is in the law of the LORD, And in His law he meditates day and night.

3. He shall be like a tree Planted by the rivers of water, That brings forth its fruit in its season, Whose leaf also shall not wither; And whatever he does shall prosper.

4. The ungodly are not so, But are like the chaff which the wind drives away.

5. Therefore the ungodly shall not stand in the judgment, Nor sinners in the congregation of the righteous.

6. For the LORD knows the way of the righteous, But the way of the ungodly shall perish.

## Chapter 2

1. Why do the nations rage, And the people plot a vain thing?

2. The kings of the earth set themselves, And the rulers take counsel together, Against the LORD and against His Anointed, saying,

3. "Let us break Their bonds in pieces And cast away Their cords from us."

4. He who sits in the heavens shall laugh; The LORD shall hold them in derision.

5. Then He shall speak to them in His wrath, And distress them in His deep displeasure:

6. "Yet I have set My King On My holy hill of Zion."

7. "I will declare the decree: The LORD has said to Me, "You are My Son, Today I have begotten You.

8. Ask of Me, and I will give You The nations for Your inheritance, And the ends of the earth for Your possession.

9. You shall break them with a rod of iron; You shall dash them to pieces like a potter's vessel."'

10. Now therefore, be wise, O kings; Be instructed, you judges of the earth.

11. Serve the LORD with fear, And rejoice with trembling.

12. Kiss the Son, lest He be angry, And you perish in the way, When His wrath is kindled but a little. Blessed are all those who put their trust in Him.

## Chapter 3

1. LORD, how they have increased who trouble me! Many are they who rise up against me.

2. Many are they who say of me, "There is no help for him in God."Selah

3. But You, O LORD, are a shield for me, My glory and the One who lifts up my head.

4. I cried to the LORD with my voice, And He heard me from His holy hill.Selah

5. I lay down and slept; I awoke, for the LORD sustained me.

6. I will not be afraid of ten thousands of people Who have set themselves against me all around.

7. Arise, O LORD; Save me, O my God! For You have struck all my enemies on the cheekbone; You have broken the teeth of the ungodly.

8. Salvation belongs to the LORD. Your blessing is upon Your people.Selah

## Chapter 4

1. Hear me when I call, O God of my righteousness! You have relieved me in my distress; Have mercy on me, and hear my prayer.

2. How long, O you sons of men, Will you turn my glory to shame? How long will you love worthlessness And seek falsehood?Selah

3. But know that the LORD has set apart for Himself him who is godly; The LORD will hear when I call to Him.

4. Be angry, and do not sin. Meditate within your heart on your bed, and be still.Selah

5. Offer the sacrifices of righteousness, And put your trust in the LORD.

6. There are many who say, "Who will show us any good?" LORD, lift up the light of Your countenance upon us.

7. You have put gladness in my heart, More than in the season that their grain and wine increased.

8. I will both lie down in peace, and sleep; For You alone, O LORD, make me dwell in safety.

## Chapter 5

1. Give ear to my words, O LORD, Consider my meditation.

2. Give heed to the voice of my cry, My King and my God, For to You I will pray.

3. My voice You shall hear in the morning, O LORD; In the morning I will direct it to You, And I will look up.

4. For You are not a God who takes pleasure in wickedness, Nor shall evil dwell with You.

5. The boastful shall not stand in Your sight; You hate all workers of iniquity.

6. You shall destroy those who speak falsehood; The LORD abhors the bloodthirsty and deceitful man.

7. But as for me, I will come into Your house in the multitude of Your mercy; In fear of You I will worship toward Your holy temple.

8. Lead me, O LORD, in Your righteousness because of my enemies; Make Your way straight before my face.

9. For there is no faithfulness in their mouth; Their inward part is destruction; Their throat is an open tomb; They flatter with their tongue.

10. Pronounce them guilty, O God! Let them fall by their own counsels; Cast them out in the multitude of their transgressions, For they have rebelled against You.

11. But let all those rejoice who put their trust in You; Let them ever shout for joy, because You defend them; Let those also who love Your name Be joyful in You.

12. For You, O LORD, will bless the righteous; With favor You will surround him as with a shield.

## Chapter 6

1. O LORD, do not rebuke me in Your anger, Nor chasten me in Your hot displeasure.

2. Have mercy on me, O LORD, for I am weak; O LORD, heal me, for my bones are troubled.

3. My soul also is greatly troubled; But You, O LORD--how long?

4. Return, O LORD, deliver me! Oh, save me for Your mercies' sake!

5. For in death there is no remembrance of You; In the grave who will give You thanks?

6. I am weary with my groaning; All night I make my bed swim; I drench my couch with my tears.

7. My eye wastes away because of grief; It grows old because of all my enemies.

8. Depart from me, all you workers of iniquity; For the LORD has heard the voice of my weeping.

9. The LORD has heard my supplication; The LORD will receive my prayer.

10. Let all my enemies be ashamed and greatly troubled; Let them turn back and be ashamed suddenly.

## Chapter 7

1. O LORD my God, in You I put my trust; Save me from all those who persecute me; And deliver me,

2. Lest they tear me like a lion, Rending me in pieces, while there is none to deliver.

3. O LORD my God, if I have done this: If there is iniquity in my hands,

4. If I have repaid evil to him who was at peace with me, Or have plundered my enemy without cause,

5. Let the enemy pursue me and overtake me; Yes, let him trample my life to the earth, And lay my honor in the dust.Selah

6. Arise, O LORD, in Your anger; Lift Yourself up because of the rage of my enemies; Rise up for me to the judgment You have commanded!

7. So the congregation of the peoples shall surround You; For their sakes, therefore, return on high.

8. The LORD shall judge the peoples; Judge me, O LORD, according to my righteousness, And according to my integrity within me.

9. Oh, let the wickedness of the wicked come to an end, But establish the just; For the righteous God tests the hearts and minds.

10. My defense is of God, Who saves the upright in heart.

11. God is a just judge, And God is angry with the wicked every day.

12. If he does not turn back, He will sharpen His sword; He bends His bow and makes it ready.

13. He also prepares for Himself instruments of death; He makes His arrows into fiery shafts.

14. Behold, the wicked brings forth iniquity; Yes, he conceives trouble and brings forth falsehood.

15. He made a pit and dug it out, And has fallen into the ditch which he made.

16. His trouble shall return upon his own head, And his violent dealing shall come down on his own crown.

17. I will praise the LORD according to His righteousness, And will sing praise to the name of the LORD Most High.

## Chapter 8

1. O LORD, our Lord, How excellent is Your name in all the earth, Who have set Your glory above the heavens!

2. Out of the mouth of babes and nursing infants You have ordained strength, Because of Your enemies, That You may silence the enemy and the avenger.

3. When I consider Your heavens, the work of Your fingers, The moon and the stars, which You have ordained,

4. What is man that You are mindful of him, And the son of man that You visit him?

5. For You have made him a little lower than the angels, And You have crowned him with glory and honor.

6. You have made him to have dominion over the works of Your hands; You have put all things under his feet,

7. All sheep and oxen-- Even the beasts of the field,

8. The birds of the air, And the fish of the sea That pass through the paths of the seas.

9. O LORD, our Lord, How excellent is Your name in all the earth!

## Chapter 9

1. I will praise You, O LORD, with my whole heart; I will tell of all Your marvelous works.

2. I will be glad and rejoice in You; I will sing praise to Your name, O Most High.

3. When my enemies turn back, They shall fall and perish at Your presence.

4. For You have maintained my right and my cause; You sat on the throne judging in righteousness.

5. You have rebuked the nations, You have destroyed the wicked; You have blotted out their name forever and ever.

6. O enemy, destructions are finished forever! And you have destroyed cities; Even their memory has perished.

7. But the LORD shall endure forever; He has prepared His throne for judgment.

8. He shall judge the world in righteousness, And He shall administer judgment for the peoples in uprightness.

9. The LORD also will be a refuge for the oppressed, A refuge in times of trouble.

10. And those who know Your name will put their trust in You; For You, LORD, have not forsaken those who seek You.

11. Sing praises to the LORD, who dwells in Zion! Declare His deeds among the people.

12. When He avenges blood, He remembers them; He does not forget the cry of the humble.

13. Have mercy on me, O LORD! Consider my trouble from those who hate me, You who lift me up from the gates of death,

14. That I may tell of all Your praise In the gates of the daughter of Zion. I will rejoice in Your salvation.

15. The nations have sunk down in the pit which they made; In the net which they hid, their own foot is caught.

16. The LORD is known by the judgment He executes; The wicked is snared in the work of his own hands.

17. The wicked shall be turned into hell, And all the nations that forget God.

18. For the needy shall not always be forgotten; The expectation of the poor shall not perish forever.

19. Arise, O LORD, Do not let man prevail; Let the nations be judged in Your sight.

20. Put them in fear, O LORD, That the nations may know themselves to be but men.Selah

## Chapter 10

1. Why do You stand afar off, O LORD? Why do You hide in times of trouble?

2. The wicked in his pride persecutes the poor; Let them be caught in the plots which they have devised.

3. For the wicked boasts of his heart's desire; He blesses the greedy and renounces the LORD.

4. The wicked in his proud countenance does not seek God; God is in none of his thoughts.

5. His ways are always prospering; Your judgments are far above, out of his sight; As for all his enemies, he sneers at them.

6. He has said in his heart, "I shall not be moved; I shall never be in adversity."

7. His mouth is full of cursing and deceit and oppression; Under his tongue is trouble and iniquity.

8. He sits in the lurking places of the villages; In the secret places he murders the innocent; His eyes are secretly fixed on the helpless.

9. He lies in wait secretly, as a lion in his den; He lies in wait to catch the poor; He catches the poor when he draws him into his net.

10. So he crouches, he lies low, That the helpless may fall by his strength.

11. He has said in his heart, "God has forgotten; He hides His face; He will never see."

12. Arise, O LORD! O God, lift up Your hand! Do not forget the humble.

13. Why do the wicked renounce God? He has said in his heart, "You will not require an account."

14. But You have seen, for You observe trouble and grief, To repay it by Your hand. The helpless commits himself to You; You are the helper of the fatherless.

15. Break the arm of the wicked and the evil man; Seek out his wickedness until You find none.

16. The LORD is King forever and ever; The nations have perished out of His land.

17. LORD, You have heard the desire of the humble; You will prepare their heart; You will cause Your ear to hear,

18. To do justice to the fatherless and the oppressed, That the man of the earth may oppress no more.

## Chapter 11

1. In the LORD I put my trust; How can you say to my soul, "Flee as a bird to your mountain"?

2. For look! The wicked bend their bow, They make ready their arrow on the string, That they may shoot secretly at the upright in heart.

3. If the foundations are destroyed, What can the righteous do?

4. The LORD is in His holy temple, The LORD's throne is in heaven; His eyes behold, His eyelids test the sons of men.

5. The LORD tests the righteous, But the wicked and the one who loves violence His soul hates.

6. Upon the wicked He will rain coals; Fire and brimstone and a burning wind Shall be the portion of their cup.

7. For the LORD is righteous, He loves righteousness; His countenance beholds the upright.

## Chapter 12

1. Help, LORD, for the godly man ceases! For the faithful disappear from among the sons of men.

2. They speak idly everyone with his neighbor; With flattering lips and a double heart they speak.

3. May the LORD cut off all flattering lips, And the tongue that speaks proud things,

4. Who have said, "With our tongue we will prevail; Our lips are our own; Who is lord over us?"

5. "For the oppression of the poor, for the sighing of the needy, Now I will arise," says the LORD; "I will set him in the safety for which he yearns."

6. The words of the LORD are pure words, Like silver tried in a furnace of earth, Purified seven times.

7. You shall keep them, O LORD, You shall preserve them from this generation forever.

8. The wicked prowl on every side, When vileness is exalted among the sons of men.

## Chapter 13

1. How long, O LORD? Will You forget me forever? How long will You hide Your face from me?

2. How long shall I take counsel in my soul, Having sorrow in my heart daily? How long will my enemy be exalted over me?

3. Consider and hear me, O LORD my God; Enlighten my eyes, Lest I sleep the sleep of death;

4. Lest my enemy say, "I have prevailed against him"; Lest those who trouble me rejoice when I am moved.

5. But I have trusted in Your mercy; My heart shall rejoice in Your salvation.

6. I will sing to the LORD, Because He has dealt bountifully with me.

## Chapter 14

1. The fool has said in his heart, "There is no God." They are corrupt, They have done abominable works, There is none who does good.

2. The LORD looks down from heaven upon the children of men, To see if there are any who understand, who seek God.

3. They have all turned aside, They have together become corrupt; There is none who does good, No, not one.

4. Have all the workers of iniquity no knowledge, Who eat up my people as they eat bread, And do not call on the LORD?

5. There they are in great fear, For God is with the generation of the righteous.

6. You shame the counsel of the poor, But the LORD is his refuge.

7. Oh, that the salvation of Israel would come out of Zion! When the LORD brings back the captivity of His people, Let Jacob rejoice and Israel be glad.

## Chapter 15

1. LORD, who may abide in Your tabernacle? Who may dwell in Your holy hill?

2. He who walks uprightly, And works righteousness, And speaks the truth in his heart;

3. He who does not backbite with his tongue, Nor does evil to his neighbor, Nor does he take up a reproach against his friend;

4. In whose eyes a vile person is despised, But he honors those who fear the LORD; He who swears to his own hurt and does not change;

5. He who does not put out his money at usury, Nor does he take a bribe against the innocent. He who does these things shall never be moved.

## Chapter 16

1. Preserve me, O God, for in You I put my trust.

2. O my soul, you have said to the LORD, "You are my Lord, My goodness is nothing apart from You."

3. As for the saints who are on the earth, "They are the excellent ones, in whom is all my delight."

4. Their sorrows shall be multiplied who hasten after another god; Their drink offerings of blood I will not offer, Nor take up their names on my lips.

5. O LORD, You are the portion of my inheritance and my cup; You maintain my lot.

6. The lines have fallen to me in pleasant places; Yes, I have a good inheritance.

7. I will bless the LORD who has given me counsel; My heart also instructs me in the night seasons.

8. I have set the LORD always before me; Because He is at my right hand I shall not be moved.

9. Therefore my heart is glad, and my glory rejoices; My flesh also will rest in hope.

10. For You will not leave my soul in Sheol, Nor will You allow Your Holy One to see corruption.

11. You will show me the path of life; In Your presence is fullness of joy; At Your right hand are pleasures forevermore.

## Chapter 17

1. Hear a just cause, O LORD, Attend to my cry; Give ear to my prayer which is not from deceitful lips.

2. Let my vindication come from Your presence; Let Your eyes look on the things that are upright.

3. You have tested my heart; You have visited me in the night; You have tried me and have found nothing; I have purposed that my mouth shall not transgress.

4. Concerning the works of men, By the word of Your lips, I have kept away from the paths of the destroyer.

5. Uphold my steps in Your paths, That my footsteps may not slip.

6. I have called upon You, for You will hear me, O God; Incline Your ear to me, and hear my speech.

7. Show Your marvelous lovingkindness by Your right hand, O You who save those who trust in You From those who rise up against them.

8. Keep me as the apple of Your eye; Hide me under the shadow of Your wings,

9. From the wicked who oppress me, From my deadly enemies who surround me.

10. They have closed up their fat hearts; With their mouths they speak proudly.

11. They have now surrounded us in our steps; They have set their eyes, crouching down to the earth,

12. As a lion is eager to tear his prey, And like a young lion lurking in secret places.

13. Arise, O LORD, Confront him, cast him down; Deliver my life from the wicked with Your sword,

14. With Your hand from men, O LORD, From men of the world who have their portion in this life, And whose belly You fill with Your hidden treasure. They are satisfied with children, And leave the rest of their possession for their babes.

15. As for me, I will see Your face in righteousness; I shall be satisfied when I awake in Your likeness.

## Chapter 18

1. I will love You, O LORD, my strength.

2. The LORD is my rock and my fortress and my deliverer; My God, my strength, in whom I will trust; My shield and the horn of my salvation, my stronghold.

3. I will call upon the LORD, who is worthy to be praised; So shall I be saved from my enemies.

4. The pangs of death surrounded me, And the floods of ungodliness made me afraid.

5. The sorrows of Sheol surrounded me; The snares of death confronted me.

6. In my distress I called upon the LORD, And cried out to my God; He heard my voice from His temple, And my cry came before Him, even to His ears.

7. Then the earth shook and trembled; The foundations of the hills also quaked and were shaken, Because He was angry.

8. Smoke went up from His nostrils, And devouring fire from His mouth; Coals were kindled by it.

9. He bowed the heavens also, and came down With darkness under His feet.

10. And He rode upon a cherub, and flew; He flew upon the wings of the wind.

11. He made darkness His secret place; His canopy around Him was dark waters And thick clouds of the skies.

12. From the brightness before Him, His thick clouds passed with hailstones and coals of fire.

13. The LORD thundered from heaven, And the Most High uttered His voice, Hailstones and coals of fire.

14. He sent out His arrows and scattered the foe, Lightnings in abundance, and He vanquished them.

15. Then the channels of the sea were seen, The foundations of the world were uncovered At Your rebuke, O LORD, At the blast of the breath of Your nostrils.

16. He sent from above, He took me; He drew me out of many waters.

17. He delivered me from my strong enemy, From those who hated me, For they were too strong for me.

18. They confronted me in the day of my calamity, But the LORD was my support.

19. He also brought me out into a broad place; He delivered me because He delighted in me.

20. The LORD rewarded me according to my righteousness; According to the cleanness of my hands He has recompensed me.

21. For I have kept the ways of the LORD, And have not wickedly departed from my God.

22. For all His judgments were before me, And I did not put away His statutes from me.

23. I was also blameless before Him, And I kept myself from my iniquity.

24. Therefore the LORD has recompensed me according to my righteousness, According to the cleanness of my hands in His sight.

25. With the merciful You will show Yourself merciful; With a blameless man You will show Yourself blameless;

26. With the pure You will show Yourself pure; And with the devious You will show Yourself shrewd.

27. For You will save the humble people, But will bring down haughty looks.

28. For You will light my lamp; The LORD my God will enlighten my darkness.

29. For by You I can run against a troop, By my God I can leap over a wall.

30. As for God, His way is perfect; The word of the LORD is proven; He is a shield to all who trust in Him.

31. For who is God, except the LORD? And who is a rock, except our God?

32. It is God who arms me with strength, And makes my way perfect.

33. He makes my feet like the feet of deer, And sets me on my high places.

34. He teaches my hands to make war, So that my arms can bend a bow of bronze.

35. You have also given me the shield of Your salvation; Your right hand has held me up, Your gentleness has made me great.

36. You enlarged my path under me, So my feet did not slip.

37. I have pursued my enemies and overtaken them; Neither did I turn back again till they were destroyed.

38. I have wounded them, So that they could not rise; They have fallen under my feet.

39. For You have armed me with strength for the battle; You have subdued under me those who rose up against me.

40. You have also given me the necks of my enemies, So that I destroyed those who hated me.

41. They cried out, but there was none to save; Even to the LORD, but He did not answer them.

42. Then I beat them as fine as the dust before the wind; I cast them out like dirt in the streets.

43. You have delivered me from the strivings of the people; You have made me the head of the nations; A people I have not known shall serve me.

44. As soon as they hear of me they obey me; The foreigners submit to me.

45. The foreigners fade away, And come frightened from their hideouts.

46. The LORD lives! Blessed be my Rock! Let the God of my salvation be exalted.

47. It is God who avenges me, And subdues the peoples under me;

48. He delivers me from my enemies. You also lift me up above those who rise against me; You have delivered me from the violent man.

49. Therefore I will give thanks to You, O LORD, among the Gentiles, And sing praises to Your name.

50. Great deliverance He gives to His king, And shows mercy to His anointed, To David and his descendants forevermore.

## Chapter 19

1. The heavens declare the glory of God; And the firmament shows His handiwork.

2. Day unto day utters speech, And night unto night reveals knowledge.

3. There is no speech nor language Where their voice is not heard.

4. Their line has gone out through all the earth, And their words to the end of the world. In them He has set a tabernacle for the sun,

5. Which is like a bridegroom coming out of his chamber, And rejoices like a strong man to run its race.

6. Its rising is from one end of heaven, And its circuit to the other end; And there is nothing hidden from its heat.

7. The law of the LORD is perfect, converting the soul; The testimony of the LORD is sure, making wise the simple;

8. The statutes of the LORD are right, rejoicing the heart; The commandment of the LORD is pure, enlightening the eyes;

9. The fear of the LORD is clean, enduring forever; The judgments of the LORD are true and righteous altogether.

10. More to be desired are they than gold, Yea, than much fine gold; Sweeter also than honey and the honeycomb.

11. Moreover by them Your servant is warned, And in keeping them there is great reward.

12. Who can understand his errors? Cleanse me from secret faults.

13. Keep back Your servant also from presumptuous sins; Let them not have dominion over me. Then I shall be blameless, And I shall be innocent of great transgression.

14. Let the words of my mouth and the meditation of my heart Be acceptable in Your sight, O LORD, my strength and my Redeemer.

## Chapter 20

1. May the LORD answer you in the day of trouble; May the name of the God of Jacob defend you;

2. May He send you help from the sanctuary, And strengthen you out of Zion;

3. May He remember all your offerings, And accept your burnt sacrifice.Selah

4. May He grant you according to your heart's desire, And fulfill all your purpose.

5. We will rejoice in your salvation, And in the name of our God we will set up our banners! May the LORD fulfill all your petitions.

6. Now I know that the LORD saves His anointed; He will answer him from His holy heaven With the saving strength of His right hand.

7. Some trust in chariots, and some in horses; But we will remember the name of the LORD our God.

8. They have bowed down and fallen; But we have risen and stand upright.

9. Save, LORD! May the King answer us when we call.

## Chapter 21

1. The king shall have joy in Your strength, O LORD; And in Your salvation how greatly shall he rejoice!

2. You have given him his heart's desire, And have not withheld the request of his lips.Selah

3. For You meet him with the blessings of goodness; You set a crown of pure gold upon his head.

4. He asked life from You, and You gave it to him-- Length of days forever and ever.

5. His glory is great in Your salvation; Honor and majesty You have placed upon him.

6. For You have made him most blessed forever; You have made him exceedingly glad with Your presence.

7. For the king trusts in the LORD, And through the mercy of the Most High he shall not be moved.

8. Your hand will find all Your enemies; Your right hand will find those who hate You.

9. You shall make them as a fiery oven in the time of Your anger; The LORD shall swallow them up in His wrath, And the fire shall devour them.

10. Their offspring You shall destroy from the earth, And their descendants from among the sons of men.

11. For they intended evil against You; They devised a plot which they are not able to perform.

12. Therefore You will make them turn their back; You will make ready Your arrows on Your string toward their faces.

13. Be exalted, O LORD, in Your own strength! We will sing and praise Your power.

## Chapter 22

1. My God, My God, why have You forsaken Me? Why are You so far from helping Me, And from the words of My groaning?

2. O My God, I cry in the daytime, but You do not hear; And in the night season, and am not silent.

3. But You are holy, Enthroned in the praises of Israel.

4. Our fathers trusted in You; They trusted, and You delivered them.

5. They cried to You, and were delivered; They trusted in You, and were not ashamed.

6. But I am a worm, and no man; A reproach of men, and despised by the people.

7. All those who see Me ridicule Me; They shoot out the lip, they shake the head, saying,

8. "He trusted in the LORD, let Him rescue Him; Let Him deliver Him, since He delights in Him!"

9. But You are He who took Me out of the womb; You made Me trust while on My mother's breasts.

10. I was cast upon You from birth. From My mother's womb You have been My God.

11. Be not far from Me, For trouble is near; For there is none to help.

12. Many bulls have surrounded Me; Strong bulls of Bashan have encircled Me.

13. They gape at Me with their mouths, Like a raging and roaring lion.

14. I am poured out like water, And all My bones are out of joint; My heart is like wax; It has melted within Me.

15. My strength is dried up like a potsherd, And My tongue clings to My jaws; You have brought Me to the dust of death.

16. For dogs have surrounded Me; The congregation of the wicked has enclosed Me. They pierced My hands and My feet;

17. I can count all My bones. They look and stare at Me.

18. They divide My garments among them, And for My clothing they cast lots.

19. But You, O LORD, do not be far from Me; O My Strength, hasten to help Me!

20. Deliver Me from the sword, My precious life from the power of the dog.

21. Save Me from the lion's mouth And from the horns of the wild oxen! You have answered Me.

22. I will declare Your name to My brethren; In the midst of the assembly I will praise You.

23. You who fear the LORD, praise Him! All you descendants of Jacob, glorify Him, And fear Him, all you offspring of Israel!

24. For He has not despised nor abhorred the affliction of the afflicted; Nor has He hidden His face from Him; But when He cried to Him, He heard.

25. My praise shall be of You in the great assembly; I will pay My vows before those who fear Him.

26. The poor shall eat and be satisfied; Those who seek Him will praise the LORD. Let your heart live forever!

27. All the ends of the world Shall remember and turn to the LORD, And all the families of the nations Shall worship before You.

28. For the kingdom is the LORD's, And He rules over the nations.

29. All the prosperous of the earth Shall eat and worship; All those who go down to the dust Shall bow before Him, Even he who cannot keep himself alive.

30. A posterity shall serve Him. It will be recounted of the Lord to the next generation,

31. They will come and declare His righteousness to a people who will be born, That He has done this.

## Chapter 23

1. The LORD is my shepherd; I shall not want.

2. He makes me to lie down in green pastures; He leads me beside the still waters.

3. He restores my soul; He leads me in the paths of righteousness For His name's sake.

4. Yea, though I walk through the valley of the shadow of death, I will fear no evil; For You are with me; Your rod and Your staff, they comfort me.

5. You prepare a table before me in the presence of my enemies; You anoint my head with oil; My cup runs over.

6. Surely goodness and mercy shall follow me All the days of my life; And I will dwell in the house of the LORD Forever.

## Chapter 24

1. The earth is the LORD's, and all its fullness, The world and those who dwell therein.

2. For He has founded it upon the seas, And established it upon the waters.

3. Who may ascend into the hill of the LORD? Or who may stand in His holy place?

4. He who has clean hands and a pure heart, Who has not lifted up his soul to an idol, Nor sworn deceitfully.

5. He shall receive blessing from the LORD, And righteousness from the God of his salvation.

6. This is Jacob, the generation of those who seek Him, Who seek Your face.Selah

7. Lift up your heads, O you gates! And be lifted up, you everlasting doors! And the King of glory shall come in.

8. Who is this King of glory? The LORD strong and mighty, The LORD mighty in battle.

9. Lift up your heads, O you gates! Lift up, you everlasting doors! And the King of glory shall come in.

10. Who is this King of glory? The LORD of hosts, He is the King of glory.Selah

## Chapter 25

1. To You, O LORD, I lift up my soul.

2. O my God, I trust in You; Let me not be ashamed; Let not my enemies triumph over me.

3. Indeed, let no one who waits on You be ashamed; Let those be ashamed who deal treacherously without cause.

4. Show me Your ways, O LORD; Teach me Your paths.

5. Lead me in Your truth and teach me, For You are the God of my salvation; On You I wait all the day.

6. Remember, O LORD, Your tender mercies and Your lovingkindnesses, For they are from of old.

7. Do not remember the sins of my youth, nor my transgressions; According to Your mercy remember me, For Your goodness' sake, O LORD.

8. Good and upright is the LORD; Therefore He teaches sinners in the way.

9. The humble He guides in justice, And the humble He teaches His way.

10. All the paths of the LORD are mercy and truth, To such as keep His covenant and His testimonies.

11. For Your name's sake, O LORD, Pardon my iniquity, for it is great.

12. Who is the man that fears the LORD? Him shall He teach in the way He chooses.

13. He himself shall dwell in prosperity, And his descendants shall inherit the earth.

14. The secret of the LORD is with those who fear Him, And He will show them His covenant.

15. My eyes are ever toward the LORD, For He shall pluck my feet out of the net.

16. Turn Yourself to me, and have mercy on me, For I am desolate and afflicted.

17. The troubles of my heart have enlarged; Bring me out of my distresses!

18. Look on my affliction and my pain, And forgive all my sins.

19. Consider my enemies, for they are many; And they hate me with cruel hatred.

20. Keep my soul, and deliver me; Let me not be ashamed, for I put my trust in You.

21. Let integrity and uprightness preserve me, For I wait for You.

22. Redeem Israel, O God, Out of all their troubles!

## Chapter 26

1. Vindicate me, O LORD, For I have walked in my integrity. I have also trusted in the LORD; I shall not slip.

2. Examine me, O LORD, and prove me; Try my mind and my heart.

3. For Your lovingkindness is before my eyes, And I have walked in Your truth.

4. I have not sat with idolatrous mortals, Nor will I go in with hypocrites.

5. I have hated the assembly of evildoers, And will not sit with the wicked.

6. I will wash my hands in innocence; So I will go about Your altar, O LORD,

7. That I may proclaim with the voice of thanksgiving, And tell of all Your wondrous works.

8. LORD, I have loved the habitation of Your house, And the place where Your glory dwells.

9. Do not gather my soul with sinners, Nor my life with bloodthirsty men,

10. In whose hands is a sinister scheme, And whose right hand is full of bribes.

11. But as for me, I will walk in my integrity; Redeem me and be merciful to me.

12. My foot stands in an even place; In the congregations I will bless the LORD.

## Chapter 27

1. The LORD is my light and my salvation; Whom shall I fear? The LORD is the strength of my life; Of whom shall I be afraid?

2. When the wicked came against me To eat up my flesh, My enemies and foes, They stumbled and fell.

3. Though an army may encamp against me, My heart shall not fear; Though war may rise against me, In this I will be confident.

4. One thing I have desired of the LORD, That will I seek: That I may dwell in the house of the LORD All the days of my life, To behold the beauty of the LORD, And to inquire in His temple.

5. For in the time of trouble He shall hide me in His pavilion; In the secret place of His tabernacle He shall hide me; He shall set me high upon a rock.

6. And now my head shall be lifted up above my enemies all around me; Therefore I will offer sacrifices of joy in His tabernacle; I will sing, yes, I will sing praises to the LORD.

7. Hear, O LORD, when I cry with my voice! Have mercy also upon me, and answer me.

8. When You said, "Seek My face," My heart said to You, "Your face, LORD, I will seek."

9. Do not hide Your face from me; Do not turn Your servant away in anger; You have been my help; Do not leave me nor forsake me, O God of my salvation.

10. When my father and my mother forsake me, Then the LORD will take care of me.

11. Teach me Your way, O LORD, And lead me in a smooth path, because of my enemies.

12. Do not deliver me to the will of my adversaries; For false witnesses have risen against me, And such as breathe out violence.

13. I would have lost heart, unless I had believed That I would see the goodness of the LORD In the land of the living.

14. Wait on the LORD; Be of good courage, And He shall strengthen your heart; Wait, I say, on the LORD!

## Chapter 28

1. To You I will cry, O LORD my Rock: Do not be silent to me, Lest, if You are silent to me, I become like those who go down to the pit.

2. Hear the voice of my supplications When I cry to You, When I lift up my hands toward Your holy sanctuary.

3. Do not take me away with the wicked And with the workers of iniquity, Who speak peace to their neighbors, But evil is in their hearts.

4. Give them according to their deeds, And according to the wickedness of their endeavors; Give them according to the work of their hands; Render to them what they deserve.

5. Because they do not regard the works of the LORD, Nor the operation of His hands, He shall destroy them And not build them up.

6. Blessed be the LORD, Because He has heard the voice of my supplications!

7. The LORD is my strength and my shield; My heart trusted in Him, and I am helped; Therefore my heart greatly rejoices, And with my song I will praise Him.

8. The LORD is their strength, And He is the saving refuge of His anointed.

9. Save Your people, And bless Your inheritance; Shepherd them also, And bear them up forever.

## Chapter 29

1. Give unto the LORD, O you mighty ones, Give unto the LORD glory and strength.

2. Give unto the LORD the glory due to His name; Worship the LORD in the beauty of holiness.

3. The voice of the LORD is over the waters; The God of glory thunders; The LORD is over many waters.

4. The voice of the LORD is powerful; The voice of the LORD is full of majesty.

5. The voice of the LORD breaks the cedars, Yes, the LORD splinters the cedars of Lebanon.

6. He makes them also skip like a calf, Lebanon and Sirion like a young wild ox.

7. The voice of the LORD divides the flames of fire.

8. The voice of the LORD shakes the wilderness; The LORD shakes the Wilderness of Kadesh.

9. The voice of the LORD makes the deer give birth, And strips the forests bare; And in His temple everyone says, "Glory!"

10. The LORD sat enthroned at the Flood, And the LORD sits as King forever.

11. The LORD will give strength to His people; The LORD will bless His people with peace.

## Chapter 30

1. I will extol You, O LORD, for You have lifted me up, And have not let my foes rejoice over me.

2. O LORD my God, I cried out to You, And You healed me.

3. O LORD, You brought my soul up from the grave; You have kept me alive, that I should not go down to the pit.

4. Sing praise to the LORD, you saints of His, And give thanks at the remembrance of His holy name.

5. For His anger is but for a moment, His favor is for life; Weeping may endure for a night, But joy comes in the morning.

6. Now in my prosperity I said, "I shall never be moved."

7. LORD, by Your favor You have made my mountain stand strong; You hid Your face, and I was troubled.

8. I cried out to You, O LORD; And to the LORD I made supplication:

9. "What profit is there in my blood, When I go down to the pit? Will the dust praise You? Will it declare Your truth?

10. Hear, O LORD, and have mercy on me; LORD, be my helper!"

11. You have turned for me my mourning into dancing; You have put off my sackcloth and clothed me with gladness,

12. To the end that my glory may sing praise to You and not be silent. O LORD my God, I will give thanks to You forever.

## Chapter 31

1. In You, O LORD, I put my trust; Let me never be ashamed; Deliver me in Your righteousness.

2. Bow down Your ear to me, Deliver me speedily; Be my rock of refuge, A fortress of defense to save me.

3. For You are my rock and my fortress; Therefore, for Your name's sake, Lead me and guide me.

4. Pull me out of the net which they have secretly laid for me, For You are my strength.

5. Into Your hand I commit my spirit; You have redeemed me, O LORD God of truth.

6. I have hated those who regard useless idols; But I trust in the LORD.

7. I will be glad and rejoice in Your mercy, For You have considered my trouble; You have known my soul in adversities,

8. And have not shut me up into the hand of the enemy; You have set my feet in a wide place.

9. Have mercy on me, O LORD, for I am in trouble; My eye wastes away with grief, Yes, my soul and my body!

10. For my life is spent with grief, And my years with sighing; My strength fails because of my iniquity, And my bones waste away.

11. I am a reproach among all my enemies, But especially among my neighbors, And am repulsive to my acquaintances; Those who see me outside flee from me.

12. I am forgotten like a dead man, out of mind; I am like a broken vessel.

13. For I hear the slander of many; Fear is on every side; While they take counsel together against me, They scheme to take away my life.

14. But as for me, I trust in You, O LORD; I say, "You are my God."

15. My times are in Your hand; Deliver me from the hand of my enemies, And from those who persecute me.

16. Make Your face shine upon Your servant; Save me for Your mercies' sake.

17. Do not let me be ashamed, O LORD, for I have called upon You; Let the wicked be ashamed; Let them be silent in the grave.

18. Let the lying lips be put to silence, Which speak insolent things proudly and contemptuously against the righteous.

19. Oh, how great is Your goodness, Which You have laid up for those who fear You, Which You have prepared for those who trust in You In the presence of the sons of men!

20. You shall hide them in the secret place of Your presence From the plots of man; You shall keep them secretly in a pavilion From the strife of tongues.

21. Blessed be the LORD, For He has shown me His marvelous kindness in a strong city!

22. For I said in my haste, "I am cut off from before Your eyes"; Nevertheless You heard the voice of my supplications When I cried out to You.

23. Oh, love the LORD, all you His saints! For the LORD preserves the faithful, And fully repays the proud person.

24. Be of good courage, And He shall strengthen your heart, All you who hope in the LORD.

## Chapter 32

1. Blessed is he whose transgression is forgiven, Whose sin is covered.

2. Blessed is the man to whom the LORD does not impute iniquity, And in whose spirit there is no deceit.

3. When I kept silent, my bones grew old Through my groaning all the day long.

4. For day and night Your hand was heavy upon me; My vitality was turned into the drought of summer.Selah

5. I acknowledged my sin to You, And my iniquity I have not hidden. I said, "I will confess my transgressions to the LORD," And You forgave the iniquity of my sin.Selah

6. For this cause everyone who is godly shall pray to You In a time when You may be found; Surely in a flood of great waters They shall not come near him.

7. You are my hiding place; You shall preserve me from trouble; You shall surround me with songs of deliverance.Selah

8. I will instruct you and teach you in the way you should go; I will guide you with My eye.

9. Do not be like the horse or like the mule, Which have no understanding, Which must be harnessed with bit and bridle, Else they will not come near you.

10. Many sorrows shall be to the wicked; But he who trusts in the LORD, mercy shall surround him.

11. Be glad in the LORD and rejoice, you righteous; And shout for joy, all you upright in heart!

## Chapter 33

1. Rejoice in the LORD, O you righteous! For praise from the upright is beautiful.

2. Praise the LORD with the harp; Make melody to Him with an instrument of ten strings.

3. Sing to Him a new song; Play skillfully with a shout of joy.

4. For the word of the LORD is right, And all His work is done in truth.

5. He loves righteousness and justice; The earth is full of the goodness of the LORD.

6. By the word of the LORD the heavens were made, And all the host of them by the breath of His mouth.

7. He gathers the waters of the sea together as a heap; He lays up the deep in storehouses.

8. Let all the earth fear the LORD; Let all the inhabitants of the world stand in awe of Him.

9. For He spoke, and it was done; He commanded, and it stood fast.

10. The LORD brings the counsel of the nations to nothing; He makes the plans of the peoples of no effect.

11. The counsel of the LORD stands forever, The plans of His heart to all generations.

12. Blessed is the nation whose God is the LORD, The people He has chosen as His own inheritance.

13. The LORD looks from heaven; He sees all the sons of men.

14. From the place of His dwelling He looks On all the inhabitants of the earth;

15. He fashions their hearts individually; He considers all their works.

16. No king is saved by the multitude of an army; A mighty man is not delivered by great strength.

17. A horse is a vain hope for safety; Neither shall it deliver any by its great strength.

18. Behold, the eye of the LORD is on those who fear Him, On those who hope in His mercy,

19. To deliver their soul from death, And to keep them alive in famine.

20. Our soul waits for the LORD; He is our help and our shield.

21. For our heart shall rejoice in Him, Because we have trusted in His holy name.

22. Let Your mercy, O LORD, be upon us, Just as we hope in You.

## Chapter 34

1. I will bless the LORD at all times; His praise shall continually be in my mouth.

2. My soul shall make its boast in the LORD; The humble shall hear of it and be glad.

3. Oh, magnify the LORD with me, And let us exalt His name together.

4. I sought the LORD, and He heard me, And delivered me from all my fears.

5. They looked to Him and were radiant, And their faces were not ashamed.

6. This poor man cried out, and the LORD heard him, And saved him out of all his troubles.

7. The angel of the LORD encamps all around those who fear Him, And delivers them.

8. Oh, taste and see that the LORD is good; Blessed is the man who trusts in Him!

9. Oh, fear the LORD, you His saints! There is no want to those who fear Him.

10. The young lions lack and suffer hunger; But those who seek the LORD shall not lack any good thing.

11. Come, you children, listen to me; I will teach you the fear of the LORD.

12. Who is the man who desires life, And loves many days, that he may see good?

13. Keep your tongue from evil, And your lips from speaking deceit.

14. Depart from evil and do good; Seek peace and pursue it.

15. The eyes of the LORD are on the righteous, And His ears are open to their cry.

16. The face of the LORD is against those who do evil, To cut off the remembrance of them from the earth.

17. The righteous cry out, and the LORD hears, And delivers them out of all their troubles.

18. The LORD is near to those who have a broken heart, And saves such as have a contrite spirit.

19. Many are the afflictions of the righteous, But the LORD delivers him out of them all.

20. He guards all his bones; Not one of them is broken.

21. Evil shall slay the wicked, And those who hate the righteous shall be condemned.

22. The LORD redeems the soul of His servants, And none of those who trust in Him shall be condemned.

## Chapter 35

1. Plead my cause, O LORD, with those who strive with me; Fight against those who fight against me.

2. Take hold of shield and buckler, And stand up for my help.

3. Also draw out the spear, And stop those who pursue me. Say to my soul, "I am your salvation."

4. Let those be put to shame and brought to dishonor Who seek after my life; Let those be turned back and brought to confusion Who plot my hurt.

5. Let them be like chaff before the wind, And let the angel of the LORD chase them.

6. Let their way be dark and slippery, And let the angel of the LORD pursue them.

7. For without cause they have hidden their net for me in a pit, Which they have dug without cause for my life.

8. Let destruction come upon him unexpectedly, And let his net that he has hidden catch himself; Into that very destruction let him fall.

9. And my soul shall be joyful in the LORD; It shall rejoice in His salvation.

10. All my bones shall say, "LORD, who is like You, Delivering the poor from him who is too strong for him, Yes, the poor and the needy from him who plunders him?"

11. Fierce witnesses rise up; They ask me things that I do not know.

12. They reward me evil for good, To the sorrow of my soul.

13. But as for me, when they were sick, My clothing was sackcloth; I humbled myself with fasting; And my prayer would return to my own heart.

14. I paced about as though he were my friend or brother; I bowed down heavily, as one who mourns for his mother.

15. But in my adversity they rejoiced And gathered together; Attackers gathered against me, And I did not know it; They tore at me and did not cease;

16. With ungodly mockers at feasts They gnashed at me with their teeth.

17. Lord, how long will You look on? Rescue me from their destructions, My precious life from the lions.

18. I will give You thanks in the great assembly; I will praise You among many people.

19. Let them not rejoice over me who are wrongfully my enemies; Nor let them wink with the eye who hate me without a cause.

20. For they do not speak peace, But they devise deceitful matters Against the quiet ones in the land.

21. They also opened their mouth wide against me, And said, "Aha, aha! Our eyes have seen it."

22. This You have seen, O LORD; Do not keep silence. O Lord, do not be far from me.

23. Stir up Yourself, and awake to my vindication, To my cause, my God and my Lord.

24. Vindicate me, O LORD my God, according to Your righteousness; And let them not rejoice over me.

25. Let them not say in their hearts, "Ah, so we would have it!" Let them not say, "We have swallowed him up."

26. Let them be ashamed and brought to mutual confusion Who rejoice at my hurt; Let them be clothed with shame and dishonor Who exalt themselves against me.

27. Let them shout for joy and be glad, Who favor my righteous cause; And let them say continually, "Let the LORD be magnified, Who has pleasure in the prosperity of His servant."

28. And my tongue shall speak of Your righteousness And of Your praise all the day long.

## Chapter 36

1. An oracle within my heart concerning the transgression of the wicked: There is no fear of God before his eyes.

2. For he flatters himself in his own eyes, When he finds out his iniquity and when he hates.

3. The words of his mouth are wickedness and deceit; He has ceased to be wise and to do good.

4. He devises wickedness on his bed; He sets himself in a way that is not good; He does not abhor evil.

5. Your mercy, O LORD, is in the heavens; Your faithfulness reaches to the clouds.

6. Your righteousness is like the great mountains; Your judgments are a great deep; O LORD, You preserve man and beast.

7. How precious is Your lovingkindness, O God! Therefore the children of men put their trust under the shadow of Your wings.

8. They are abundantly satisfied with the fullness of Your house, And You give them drink from the river of Your pleasures.

9. For with You is the fountain of life; In Your light we see light.

10. Oh, continue Your lovingkindness to those who know You, And Your righteousness to the upright in heart.

11. Let not the foot of pride come against me, And let not the hand of the wicked drive me away.

12. There the workers of iniquity have fallen; They have been cast down and are not able to rise.

## Chapter 37

1. Do not fret because of evildoers, Nor be envious of the workers of iniquity.

2. For they shall soon be cut down like the grass, And wither as the green herb.

3. Trust in the LORD, and do good; Dwell in the land, and feed on His faithfulness.

4. Delight yourself also in the LORD, And He shall give you the desires of your heart.

5. Commit your way to the LORD, Trust also in Him, And He shall bring it to pass.

6. He shall bring forth your righteousness as the light, And your justice as the noonday.

7. Rest in the LORD, and wait patiently for Him; Do not fret because of him who prospers in his way, Because of the man who brings wicked schemes to pass.

8. Cease from anger, and forsake wrath; Do not fret--it only causes harm.

9. For evildoers shall be cut off; But those who wait on the LORD, They shall inherit the earth.

10. For yet a little while and the wicked shall be no more; Indeed, you will look carefully for his place, But it shall be no more.

11. But the meek shall inherit the earth, And shall delight themselves in the abundance of peace.

12. The wicked plots against the just, And gnashes at him with his teeth.

13. The Lord laughs at him, For He sees that his day is coming.

14. The wicked have drawn the sword And have bent their bow, To cast down the poor and needy, To slay those who are of upright conduct.

15. Their sword shall enter their own heart, And their bows shall be broken.

16. A little that a righteous man has Is better than the riches of many wicked.

17. For the arms of the wicked shall be broken, But the LORD upholds the righteous.

18. The LORD knows the days of the upright, And their inheritance shall be forever.

19. They shall not be ashamed in the evil time, And in the days of famine they shall be satisfied.

20. But the wicked shall perish; And the enemies of the LORD, Like the splendor of the meadows, shall vanish. Into smoke they shall vanish away.

21. The wicked borrows and does not repay, But the righteous shows mercy and gives.

22. For those blessed by Him shall inherit the earth, But those cursed by Him shall be cut off.

23. The steps of a good man are ordered by the LORD, And He delights in his way.

24. Though he fall, he shall not be utterly cast down; For the LORD upholds him with His hand.

25. I have been young, and now am old; Yet I have not seen the righteous forsaken, Nor his descendants begging bread.

26. He is ever merciful, and lends; And his descendants are blessed.

27. Depart from evil, and do good; And dwell forevermore.

28. For the LORD loves justice, And does not forsake His saints; They are preserved forever, But the descendants of the wicked shall be cut off.

29. The righteous shall inherit the land, And dwell in it forever.

30. The mouth of the righteous speaks wisdom, And his tongue talks of justice.

31. The law of his God is in his heart; None of his steps shall slide.

32. The wicked watches the righteous, And seeks to slay him.

33. The LORD will not leave him in his hand, Nor condemn him when he is judged.

34. Wait on the LORD, And keep His way, And He shall exalt you to inherit the land; When the wicked are cut off, you shall see it.

35. I have seen the wicked in great power, And spreading himself like a native green tree.

36. Yet he passed away, and behold, he was no more; Indeed I sought him, but he could not be found.

37. Mark the blameless man, and observe the upright; For the future of that man is peace.

38. But the transgressors shall be destroyed together; The future of the wicked shall be cut off.

39. But the salvation of the righteous is from the LORD; He is their strength in the time of trouble.

40. And the LORD shall help them and deliver them; He shall deliver them from the wicked, And save them, Because they trust in Him.

## Chapter 38

1. O LORD, do not rebuke me in Your wrath, Nor chasten me in Your hot displeasure!

2. For Your arrows pierce me deeply, And Your hand presses me down.

3. There is no soundness in my flesh Because of Your anger, Nor any health in my bones Because of my sin.

4. For my iniquities have gone over my head; Like a heavy burden they are too heavy for me.

5. My wounds are foul and festering Because of my foolishness.

6. I am troubled, I am bowed down greatly; I go mourning all the day long.

7. For my loins are full of inflammation, And there is no soundness in my flesh.

8. I am feeble and severely broken; I groan because of the turmoil of my heart.

9. Lord, all my desire is before You; And my sighing is not hidden from You.

10. My heart pants, my strength fails me; As for the light of my eyes, it also has gone from me.

11. My loved ones and my friends stand aloof from my plague, And my relatives stand afar off.

12. Those also who seek my life lay snares for me; Those who seek my hurt speak of destruction, And plan deception all the day long.

13. But I, like a deaf man, do not hear; And I am like a mute who does not open his mouth.

14. Thus I am like a man who does not hear, And in whose mouth is no response.

15. For in You, O LORD, I hope; You will hear, O Lord my God.

16. For I said, "Hear me, lest they rejoice over me, Lest, when my foot slips, they exalt themselves against me."

17. For I am ready to fall, And my sorrow is continually before me.

18. For I will declare my iniquity; I will be in anguish over my sin.

19. But my enemies are vigorous, and they are strong; And those who hate me wrongfully have multiplied.

20. Those also who render evil for good, They are my adversaries, because I follow what is good.

21. Do not forsake me, O LORD; O my God, be not far from me!

22. Make haste to help me, O Lord, my salvation!

## Chapter 39

1. I said, "I will guard my ways, Lest I sin with my tongue; I will restrain my mouth with a muzzle, While the wicked are before me."

2. I was mute with silence, I held my peace even from good; And my sorrow was stirred up.

3. My heart was hot within me; While I was musing, the fire burned. Then I spoke with my tongue:

4. "LORD, make me to know my end, And what is the measure of my days, That I may know how frail I am.

5. Indeed, You have made my days as handbreadths, And my age is as nothing before You; Certainly every man at his best state is but vapor.Selah

6. Surely every man walks about like a shadow; Surely they busy themselves in vain; He heaps up riches, And does not know who will gather them.

7. "And now, Lord, what do I wait for? My hope is in You.

8. Deliver me from all my transgressions; Do not make me the reproach of the foolish.

9. I was mute, I did not open my mouth, Because it was You who did it.

10. Remove Your plague from me; I am consumed by the blow of Your hand.

11. When with rebukes You correct man for iniquity, You make his beauty melt away like a moth; Surely every man is vapor.Selah

12. "Hear my prayer, O LORD, And give ear to my cry; Do not be silent at my tears; For I am a stranger with You, A sojourner, as all my fathers were.

13. Remove Your gaze from me, that I may regain strength, Before I go away and am no more."

## Chapter 40

1. I waited patiently for the LORD; And He inclined to me, And heard my cry.

2. He also brought me up out of a horrible pit, Out of the miry clay, And set my feet upon a rock, And established my steps.

3. He has put a new song in my mouth-- Praise to our God; Many will see it and fear, And will trust in the LORD.

4. Blessed is that man who makes the LORD his trust, And does not respect the proud, nor such as turn aside to lies.

5. Many, O LORD my God, are Your wonderful works Which You have done; And Your thoughts toward us Cannot be recounted to You in order; If I would declare and speak of them, They are more than can be numbered.

6. Sacrifice and offering You did not desire; My ears You have opened. Burnt offering and sin offering You did not require.

7. Then I said, "Behold, I come; In the scroll of the book it is written of me.

8. I delight to do Your will, O my God, And Your law is within my heart."

9. I have proclaimed the good news of righteousness In the great assembly; Indeed, I do not restrain my lips, O LORD, You Yourself know.

10. I have not hidden Your righteousness within my heart; I have declared Your faithfulness and Your salvation; I have not concealed Your lovingkindness and Your truth From the great assembly.

11. Do not withhold Your tender mercies from me, O LORD; Let Your lovingkindness and Your truth continually preserve me.

12. For innumerable evils have surrounded me; My iniquities have overtaken me, so that I am not able to look up; They are more than the hairs of my head; Therefore my heart fails me.

13. Be pleased, O LORD, to deliver me; O LORD, make haste to help me!

14. Let them be ashamed and brought to mutual confusion Who seek to destroy my life; Let them be driven backward and brought to dishonor Who wish me evil.

15. Let them be confounded because of their shame, Who say to me, "Aha, aha!"

16. Let all those who seek You rejoice and be glad in You; Let such as love Your salvation say continually, "The LORD be magnified!"

17. But I am poor and needy; Yet the LORD thinks upon me. You are my help and my deliverer; Do not delay, O my God.

## Chapter 41

1. Blessed is he who considers the poor; The LORD will deliver him in time of trouble.

2. The LORD will preserve him and keep him alive, And he will be blessed on the earth; You will not deliver him to the will of his enemies.

3. The LORD will strengthen him on his bed of illness; You will sustain him on his sickbed.

4. I said, "LORD, be merciful to me; Heal my soul, for I have sinned against You."

5. My enemies speak evil of me: "When will he die, and his name perish?"

6. And if he comes to see me, he speaks lies; His heart gathers iniquity to itself; When he goes out, he tells it.

7. All who hate me whisper together against me; Against me they devise my hurt.

8. "An evil disease," they say, "clings to him. And now that he lies down, he will rise up no more."

9. Even my own familiar friend in whom I trusted, Who ate my bread, Has lifted up his heel against me.

10. But You, O LORD, be merciful to me, and raise me up, That I may repay them.

11. By this I know that You are well pleased with me, Because my enemy does not triumph over me.

12. As for me, You uphold me in my integrity, And set me before Your face forever.

13. Blessed be the LORD God of Israel From everlasting to everlasting! Amen and Amen.

## Chapter 42

1. As the deer pants for the water brooks, So pants my soul for You, O God.

2. My soul thirsts for God, for the living God. When shall I come and appear before God?

3. My tears have been my food day and night, While they continually say to me, "Where is your God?"

4. When I remember these things, I pour out my soul within me. For I used to go with the multitude; I went with them to the house of God, With the voice of joy and praise, With a multitude that kept a pilgrim feast.

5. Why are you cast down, O my soul? And why are you disquieted within me? Hope in God, for I shall yet praise Him For the help of His countenance.

6. O my God, my soul is cast down within me; Therefore I will remember You from the land of the Jordan, And from the heights of Hermon, From the Hill Mizar.

7. Deep calls unto deep at the noise of Your waterfalls; All Your waves and billows have gone over me.

8. The LORD will command His lovingkindness in the daytime, And in the night His song shall be with me-- A prayer to the God of my life.

9. I will say to God my Rock, "Why have You forgotten me? Why do I go mourning because of the oppression of the enemy?"

10. As with a breaking of my bones, My enemies reproach me, While they say to me all day long, "Where is your God?"

11. Why are you cast down, O my soul? And why are you disquieted within me? Hope in God; For I shall yet praise Him, The help of my countenance and my God.

## Chapter 43

1. Vindicate me, O God, And plead my cause against an ungodly nation; Oh, deliver me from the deceitful and unjust man!

2. For You are the God of my strength; Why do You cast me off? Why do I go mourning because of the oppression of the enemy?

3. Oh, send out Your light and Your truth! Let them lead me; Let them bring me to Your holy hill And to Your tabernacle.

4. Then I will go to the altar of God, To God my exceeding joy; And on the harp I will praise You, O God, my God.

5. Why are you cast down, O my soul? And why are you disquieted within me? Hope in God; For I shall yet praise Him, The help of my countenance and my God.

## Chapter 44

1. We have heard with our ears, O God, Our fathers have told us, The deeds You did in their days, In days of old:

2. You drove out the nations with Your hand, But them You planted; You afflicted the peoples, and cast them out.

3. For they did not gain possession of the land by their own sword, Nor did their own arm save them; But it was Your right hand, Your arm, and the light of Your countenance, Because You favored them.

4. You are my King, O God; Command victories for Jacob.

5. Through You we will push down our enemies; Through Your name we will trample those who rise up against us.

6. For I will not trust in my bow, Nor shall my sword save me.

7. But You have saved us from our enemies, And have put to shame those who hated us.

8. In God we boast all day long, And praise Your name forever.Selah

9. But You have cast us off and put us to shame, And You do not go out with our armies.

10. You make us turn back from the enemy, And those who hate us have taken spoil for themselves.

11. You have given us up like sheep intended for food, And have scattered us among the nations.

12. You sell Your people for next to nothing, And are not enriched by selling them.

13. You make us a reproach to our neighbors, A scorn and a derision to those all around us.

14. You make us a byword among the nations, A shaking of the head among the peoples.

15. My dishonor is continually before me, And the shame of my face has covered me,

16. Because of the voice of him who reproaches and reviles, Because of the enemy and the avenger.

17. All this has come upon us; But we have not forgotten You, Nor have we dealt falsely with Your covenant.

18. Our heart has not turned back, Nor have our steps departed from Your way;

19. But You have severely broken us in the place of jackals, And covered us with the shadow of death.

20. If we had forgotten the name of our God, Or stretched out our hands to a foreign god,

21. Would not God search this out? For He knows the secrets of the heart.

22. Yet for Your sake we are killed all day long; We are accounted as sheep for the slaughter.

23. Awake! Why do You sleep, O Lord? Arise! Do not cast us off forever.

24. Why do You hide Your face, And forget our affliction and our oppression?

25. For our soul is bowed down to the dust; Our body clings to the ground.

26. Arise for our help, And redeem us for Your mercies' sake.

## Chapter 45

1. My heart is overflowing with a good theme; I recite my composition concerning the King; My tongue is the pen of a ready writer.

2. You are fairer than the sons of men; Grace is poured upon Your lips; Therefore God has blessed You forever.

3. Gird Your sword upon Your thigh, O Mighty One, With Your glory and Your majesty.

4. And in Your majesty ride prosperously because of truth, humility, and righteousness; And Your right hand shall teach You awesome things.

5. Your arrows are sharp in the heart of the King's enemies; The peoples fall under You.

6. Your throne, O God, is forever and ever; A scepter of righteousness is the scepter of Your kingdom.

7. You love righteousness and hate wickedness; Therefore God, Your God, has anointed You With the oil of gladness more than Your companions.

8. All Your garments are scented with myrrh and aloes and cassia, Out of the ivory palaces, by which they have made You glad.

9. Kings' daughters are among Your honorable women; At Your right hand stands the queen in gold from Ophir.

10. Listen, O daughter, Consider and incline your ear; Forget your own people also, and your father's house;

11. So the King will greatly desire your beauty; Because He is your Lord, worship Him.

12. And the daughter of Tyre will come with a gift; The rich among the people will seek your favor.

13. The royal daughter is all glorious within the palace; Her clothing is woven with gold.

14. She shall be brought to the King in robes of many colors; The virgins, her companions who follow her, shall be brought to You.

15. With gladness and rejoicing they shall be brought; They shall enter the King's palace.

16. Instead of Your fathers shall be Your sons, Whom You shall make princes in all the earth.

17. I will make Your name to be remembered in all generations; Therefore the people shall praise You forever and ever.

## Chapter 46

1. God is our refuge and strength, A very present help in trouble.

2. Therefore we will not fear, Even though the earth be removed, And though the mountains be carried into the midst of the sea;

3. Though its waters roar and be troubled, Though the mountains shake with its swelling.Selah

4. There is a river whose streams shall make glad the city of God, The holy place of the tabernacle of the Most High.

5. God is in the midst of her, she shall not be moved; God shall help her, just at the break of dawn.

6. The nations raged, the kingdoms were moved; He uttered His voice, the earth melted.

7. The LORD of hosts is with us; The God of Jacob is our refuge.Selah

8. Come, behold the works of the LORD, Who has made desolations in the earth.

9. He makes wars cease to the end of the earth; He breaks the bow and cuts the spear in two; He burns the chariot in the fire.

10. Be still, and know that I am God; I will be exalted among the nations, I will be exalted in the earth!

11. The LORD of hosts is with us; The God of Jacob is our refuge.Selah

## Chapter 47

1. Oh, clap your hands, all you peoples! Shout to God with the voice of triumph!

2. For the LORD Most High is awesome; He is a great King over all the earth.

3. He will subdue the peoples under us, And the nations under our feet.

4. He will choose our inheritance for us, The excellence of Jacob whom He loves.Selah

5. God has gone up with a shout, The LORD with the sound of a trumpet.

6. Sing praises to God, sing praises! Sing praises to our King, sing praises!

7. For God is the King of all the earth; Sing praises with understanding.

8. God reigns over the nations; God sits on His holy throne.

9. The princes of the people have gathered together, The people of the God of Abraham. For the shields of the earth belong to God; He is greatly exalted.

## Chapter 48

1. Great is the LORD, and greatly to be praised In the city of our God, In His holy mountain.

2. Beautiful in elevation, The joy of the whole earth, Is Mount Zion on the sides of the north, The city of the great King.

3. God is in her palaces; He is known as her refuge.

4. For behold, the kings assembled, They passed by together.

5. They saw it, and so they marveled; They were troubled, they hastened away.

6. Fear took hold of them there, And pain, as of a woman in birth pangs,

7. As when You break the ships of Tarshish With an east wind.

8. As we have heard, So we have seen In the city of the LORD of hosts, In the city of our God: God will establish it forever.Selah

9. We have thought, O God, on Your lovingkindness, In the midst of Your temple.

10. According to Your name, O God, So is Your praise to the ends of the earth; Your right hand is full of righteousness.

11. Let Mount Zion rejoice, Let the daughters of Judah be glad, Because of Your judgments.

12. Walk about Zion, And go all around her. Count her towers;

13. Mark well her bulwarks; Consider her palaces; That you may tell it to the generation following.

14. For this is God, Our God forever and ever; He will be our guide Even to death.

## Chapter 49

1. Hear this, all peoples; Give ear, all inhabitants of the world,

2. Both low and high, Rich and poor together.

3. My mouth shall speak wisdom, And the meditation of my heart shall give understanding.

4. I will incline my ear to a proverb; I will disclose my dark saying on the harp.

5. Why should I fear in the days of evil, When the iniquity at my heels surrounds me?

6. Those who trust in their wealth And boast in the multitude of their riches,

7. None of them can by any means redeem his brother, Nor give to God a ransom for him--

8. For the redemption of their souls is costly, And it shall cease forever--

9. That he should continue to live eternally, And not see the Pit.

10. For he sees wise men die; Likewise the fool and the senseless person perish, And leave their wealth to others.

11. Their inner thought is that their houses will last forever, Their dwelling places to all generations; They call their lands after their own names.

12. Nevertheless man, though in honor, does not remain; He is like the beasts that perish.

13. This is the way of those who are foolish, And of their posterity who approve their sayings.Selah

14. Like sheep they are laid in the grave; Death shall feed on them; The upright shall have dominion over them in the morning; And their beauty shall be consumed in the grave, far from their dwelling.

15. But God will redeem my soul from the power of the grave, For He shall receive me.Selah

16. Do not be afraid when one becomes rich, When the glory of his house is increased;

17. For when he dies he shall carry nothing away; His glory shall not descend after him.

18. Though while he lives he blesses himself (For men will praise you when you do well for yourself),

19. He shall go to the generation of his fathers; They shall never see light.

20. A man who is in honor, yet does not understand, Is like the beasts that perish.

## Chapter 50

1. The Mighty One, God the LORD, Has spoken and called the earth From the rising of the sun to its going down.

2. Out of Zion, the perfection of beauty, God will shine forth.

3. Our God shall come, and shall not keep silent; A fire shall devour before Him, And it shall be very tempestuous all around Him.

4. He shall call to the heavens from above, And to the earth, that He may judge His people:

5. "Gather My saints together to Me, Those who have made a covenant with Me by sacrifice."

6. Let the heavens declare His righteousness, For God Himself is Judge.Selah

7. "Hear, O My people, and I will speak, O Israel, and I will testify against you; I am God, your God!

8. I will not rebuke you for your sacrifices Or your burnt offerings, Which are continually before Me.

9. I will not take a bull from your house, Nor goats out of your folds.

10. For every beast of the forest is Mine, And the cattle on a thousand hills.

11. I know all the birds of the mountains, And the wild beasts of the field are Mine.

12. "If I were hungry, I would not tell you; For the world is Mine, and all its fullness.

13. Will I eat the flesh of bulls, Or drink the blood of goats?

14. Offer to God thanksgiving, And pay your vows to the Most High.

15. Call upon Me in the day of trouble; I will deliver you, and you shall glorify Me."

16. But to the wicked God says: "What right have you to declare My statutes, Or take My covenant in your mouth,

17. Seeing you hate instruction And cast My words behind you?

18. When you saw a thief, you consented with him, And have been a partaker with adulterers.

19. You give your mouth to evil, And your tongue frames deceit.

20. You sit and speak against your brother; You slander your own mother's son.

21. These things you have done, and I kept silent; You thought that I was altogether like you; But I will rebuke you, And set them in order before your eyes.

22. "Now consider this, you who forget God, Lest I tear you in pieces, And there be none to deliver:

23. Whoever offers praise glorifies Me; And to him who orders his conduct aright I will show the salvation of God."

## Chapter 51

1. Have mercy upon me, O God, According to Your lovingkindness; According to the multitude of Your tender mercies, Blot out my transgressions.

2. Wash me thoroughly from my iniquity, And cleanse me from my sin.

3. For I acknowledge my transgressions, And my sin is always before me.

4. Against You, You only, have I sinned, And done this evil in Your sight-- That You may be found just when You speak, And blameless when You judge.

5. Behold, I was brought forth in iniquity, And in sin my mother conceived me.

6. Behold, You desire truth in the inward parts, And in the hidden part You will make me to know wisdom.

7. Purge me with hyssop, and I shall be clean; Wash me, and I shall be whiter than snow.

8. Make me hear joy and gladness, That the bones You have broken may rejoice.

9. Hide Your face from my sins, And blot out all my iniquities.

10. Create in me a clean heart, O God, And renew a steadfast spirit within me.

11. Do not cast me away from Your presence, And do not take Your Holy Spirit from me.

12. Restore to me the joy of Your salvation, And uphold me by Your generous Spirit.

13. Then I will teach transgressors Your ways, And sinners shall be converted to You.

14. Deliver me from the guilt of bloodshed, O God, The God of my salvation, And my tongue shall sing aloud of Your righteousness.

15. O Lord, open my lips, And my mouth shall show forth Your praise.

16. For You do not desire sacrifice, or else I would give it; You do not delight in burnt offering.

17. The sacrifices of God are a broken spirit, A broken and a contrite heart-- These, O God, You will not despise.

18. Do good in Your good pleasure to Zion; Build the walls of Jerusalem.

19. Then You shall be pleased with the sacrifices of righteousness, With burnt offering and whole burnt offering; Then they shall offer bulls on Your altar.

## Chapter 52

1. Why do you boast in evil, O mighty man? The goodness of God endures continually.

2. Your tongue devises destruction, Like a sharp razor, working deceitfully.

3. You love evil more than good, Lying rather than speaking righteousness.Selah

4. You love all devouring words, You deceitful tongue.

5. God shall likewise destroy you forever; He shall take you away, and pluck you out of your dwelling place, And uproot you from the land of the living.Selah

6. The righteous also shall see and fear, And shall laugh at him, saying,

7. "Here is the man who did not make God his strength, But trusted in the abundance of his riches, And strengthened himself in his wickedness."

8. But I am like a green olive tree in the house of God; I trust in the mercy of God forever and ever.

9. I will praise You forever, Because You have done it; And in the presence of Your saints I will wait on Your name, for it is good.

## Chapter 53

1. The fool has said in his heart, "There is no God." They are corrupt, and have done abominable iniquity; There is none who does good.

2. God looks down from heaven upon the children of men, To see if there are any who understand, who seek God.

3. Every one of them has turned aside; They have together become corrupt; There is none who does good, No, not one.

4. Have the workers of iniquity no knowledge, Who eat up my people as they eat bread, And do not call upon God?

5. There they are in great fear Where no fear was, For God has scattered the bones of him who encamps against you; You have put them to shame, Because God has despised them.

6. Oh, that the salvation of Israel would come out of Zion! When God brings back the captivity of His people, Let Jacob rejoice and Israel be glad.

## Chapter 54

1. Save me, O God, by Your name, And vindicate me by Your strength.

2. Hear my prayer, O God; Give ear to the words of my mouth.

3. For strangers have risen up against me, And oppressors have sought after my life; They have not set God before them.Selah

4. Behold, God is my helper; The Lord is with those who uphold my life.

5. He will repay my enemies for their evil. Cut them off in Your truth.

6. I will freely sacrifice to You; I will praise Your name, O LORD, for it is good.

7. For He has delivered me out of all trouble; And my eye has seen its desire upon my enemies.

## Chapter 55

1. Give ear to my prayer, O God, And do not hide Yourself from my supplication.

2. Attend to me, and hear me; I am restless in my complaint, and moan noisily,

3. Because of the voice of the enemy, Because of the oppression of the wicked; For they bring down trouble upon me, And in wrath they hate me.

4. My heart is severely pained within me, And the terrors of death have fallen upon me.

5. Fearfulness and trembling have come upon me, And horror has overwhelmed me.

6. So I said, "Oh, that I had wings like a dove! I would fly away and be at rest.

7. Indeed, I would wander far off, And remain in the wilderness.Selah

8. I would hasten my escape From the windy storm and tempest."

9. Destroy, O Lord, and divide their tongues, For I have seen violence and strife in the city.

10. Day and night they go around it on its walls; Iniquity and trouble are also in the midst of it.

11. Destruction is in its midst; Oppression and deceit do not depart from its streets.

12. For it is not an enemy who reproaches me; Then I could bear it. Nor is it one who hates me who has exalted himself against me; Then I could hide from him.

13. But it was you, a man my equal, My companion and my acquaintance.

14. We took sweet counsel together, And walked to the house of God in the throng.

15. Let death seize them; Let them go down alive into hell, For wickedness is in their dwellings and among them.

16. As for me, I will call upon God, And the LORD shall save me.

17. Evening and morning and at noon I will pray, and cry aloud, And He shall hear my voice.

18. He has redeemed my soul in peace from the battle that was against me, For there were many against me.

19. God will hear, and afflict them, Even He who abides from of old.Selah Because they do not change, Therefore they do not fear God.

20. He has put forth his hands against those who were at peace with him; He has broken his covenant.

21. The words of his mouth were smoother than butter, But war was in his heart; His words were softer than oil, Yet they were drawn swords.

22. Cast your burden on the LORD, And He shall sustain you; He shall never permit the righteous to be moved.

23. But You, O God, shall bring them down to the pit of destruction; Bloodthirsty and deceitful men shall not live out half their days; But I will trust in You.

## Chapter 56

1. Be merciful to me, O God, for man would swallow me up; Fighting all day he oppresses me.

2. My enemies would hound me all day, For there are many who fight against me, O Most High.

3. Whenever I am afraid, I will trust in You.

4. In God (I will praise His word), In God I have put my trust; I will not fear. What can flesh do to me?

5. All day they twist my words; All their thoughts are against me for evil.

6. They gather together, They hide, they mark my steps, When they lie in wait for my life.

7. Shall they escape by iniquity? In anger cast down the peoples, O God!

8. You number my wanderings; Put my tears into Your bottle; Are they not in Your book?

9. When I cry out to You, Then my enemies will turn back; This I know, because God is for me.

10. In God (I will praise His word), In the LORD (I will praise His word),

11. In God I have put my trust; I will not be afraid. What can man do to me?

12. Vows made to You are binding upon me, O God; I will render praises to You,

13. For You have delivered my soul from death. Have You not kept my feet from falling, That I may walk before God In the light of the living?

## Chapter 57

1. Be merciful to me, O God, be merciful to me! For my soul trusts in You; And in the shadow of Your wings I will make my refuge, Until these calamities have passed by.

2. I will cry out to God Most High, To God who performs all things for me.

3. He shall send from heaven and save me; He reproaches the one who would swallow me up.Selah God shall send forth His mercy and His truth.

4. My soul is among lions; I lie among the sons of men Who are set on fire, Whose teeth are spears and arrows, And their tongue a sharp sword.

5. Be exalted, O God, above the heavens; Let Your glory be above all the earth.

6. They have prepared a net for my steps; My soul is bowed down; They have dug a pit before me; Into the midst of it they themselves have fallen.Selah

7. My heart is steadfast, O God, my heart is steadfast; I will sing and give praise.

8. Awake, my glory! Awake, lute and harp! I will awaken the dawn.

9. I will praise You, O Lord, among the peoples; I will sing to You among the nations.

10. For Your mercy reaches unto the heavens, And Your truth unto the clouds.

11. Be exalted, O God, above the heavens; Let Your glory be above all the earth.

## Chapter 58

1. Do you indeed speak righteousness, you silent ones? Do you judge uprightly, you sons of men?

2. No, in heart you work wickedness; You weigh out the violence of your hands in the earth.

3. The wicked are estranged from the womb; They go astray as soon as they are born, speaking lies.

4. Their poison is like the poison of a serpent; They are like the deaf cobra that stops its ear,

5. Which will not heed the voice of charmers, Charming ever so skillfully.

6. Break their teeth in their mouth, O God! Break out the fangs of the young lions, O LORD!

7. Let them flow away as waters which run continually; When he bends his bow, Let his arrows be as if cut in pieces.

8. Let them be like a snail which melts away as it goes, Like a stillborn child of a woman, that they may not see the sun.

9. Before your pots can feel the burning thorns, He shall take them away as with a whirlwind, As in His living and burning wrath.

10. The righteous shall rejoice when he sees the vengeance; He shall wash his feet in the blood of the wicked,

11. So that men will say, "Surely there is a reward for the righteous; Surely He is God who judges in the earth."

## Chapter 59

1. Deliver me from my enemies, O my God; Defend me from those who rise up against me.

2. Deliver me from the workers of iniquity, And save me from bloodthirsty men.

3. For look, they lie in wait for my life; The mighty gather against me, Not for my transgression nor for my sin, O LORD.

4. They run and prepare themselves through no fault of mine. Awake to help me, and behold!

5. You therefore, O LORD God of hosts, the God of Israel, Awake to punish all the nations; Do not be merciful to any wicked transgressors.Selah

6. At evening they return, They growl like a dog, And go all around the city.

7. Indeed, they belch with their mouth; Swords are in their lips; For they say, "Who hears?"

8. But You, O LORD, shall laugh at them; You shall have all the nations in derision.

9. I will wait for You, O You his Strength; For God is my defense.

10. My God of mercy shall come to meet me; God shall let me see my desire on my enemies.

11. Do not slay them, lest my people forget; Scatter them by Your power, And bring them down, O Lord our shield.

12. For the sin of their mouth and the words of their lips, Let them even be taken in their pride, And for the cursing and lying which they speak.

13. Consume them in wrath, consume them, That they may not be; And let them know that God rules in Jacob To the ends of the earth.Selah

14. And at evening they return, They growl like a dog, And go all around the city.

15. They wander up and down for food, And howl if they are not satisfied.

16. But I will sing of Your power; Yes, I will sing aloud of Your mercy in the morning; For You have been my defense And refuge in the day of my trouble.

17. To You, O my Strength, I will sing praises; For God is my defense, My God of mercy.

## Chapter 60

1. O God, You have cast us off; You have broken us down; You have been displeased; Oh, restore us again!

2. You have made the earth tremble; You have broken it; Heal its breaches, for it is shaking.

3. You have shown Your people hard things; You have made us drink the wine of confusion.

4. You have given a banner to those who fear You, That it may be displayed because of the truth.Selah

5. That Your beloved may be delivered, Save with Your right hand, and hear me.

6. God has spoken in His holiness: "I will rejoice; I will divide Shechem And measure out the Valley of Succoth.

7. Gilead is Mine, and Manasseh is Mine; Ephraim also is the helmet for My head; Judah is My lawgiver.

8. Moab is My washpot; Over Edom I will cast My shoe; Philistia, shout in triumph because of Me."

9. Who will bring me to the strong city? Who will lead me to Edom?

10. Is it not You, O God, who cast us off? And You, O God, who did not go out with our armies?

11. Give us help from trouble, For the help of man is useless.

12. Through God we will do valiantly, For it is He who shall tread down our enemies.

## Chapter 61

1. Hear my cry, O God; Attend to my prayer.

2. From the end of the earth I will cry to You, When my heart is overwhelmed; Lead me to the rock that is higher than I.

3. For You have been a shelter for me, A strong tower from the enemy.

4. I will abide in Your tabernacle forever; I will trust in the shelter of Your wings.Selah

5. For You, O God, have heard my vows; You have given me the heritage of those who fear Your name.

6. You will prolong the king's life, His years as many generations.

7. He shall abide before God forever. Oh, prepare mercy and truth, which may preserve him!

8. So I will sing praise to Your name forever, That I may daily perform my vows.

## Chapter 62

1. Truly my soul silently waits for God; From Him comes my salvation.

2. He only is my rock and my salvation; He is my defense; I shall not be greatly moved.

3. How long will you attack a man? You shall be slain, all of you, Like a leaning wall and a tottering fence.

4. They only consult to cast him down from his high position; They delight in lies; They bless with their mouth, But they curse inwardly.Selah

5. My soul, wait silently for God alone, For my expectation is from Him.

6. He only is my rock and my salvation; He is my defense; I shall not be moved.

7. In God is my salvation and my glory; The rock of my strength, And my refuge, is in God.

8. Trust in Him at all times, you people; Pour out your heart before Him; God is a refuge for us.Selah

9. Surely men of low degree are a vapor, Men of high degree are a lie; If they are weighed on the scales, They are altogether lighter than vapor.

10. Do not trust in oppression, Nor vainly hope in robbery; If riches increase, Do not set your heart on them.

11. God has spoken once, Twice I have heard this: That power belongs to God.

12. Also to You, O Lord, belongs mercy; For You render to each one according to his work.

## Chapter 63

1. O God, You are my God; Early will I seek You; My soul thirsts for You; My flesh longs for You In a dry and thirsty land Where there is no water.

2. So I have looked for You in the sanctuary, To see Your power and Your glory.

3. Because Your lovingkindness is better than life, My lips shall praise You.

4. Thus I will bless You while I live; I will lift up my hands in Your name.

5. My soul shall be satisfied as with marrow and fatness, And my mouth shall praise You with joyful lips.

6. When I remember You on my bed, I meditate on You in the night watches.

7. Because You have been my help, Therefore in the shadow of Your wings I will rejoice.

8. My soul follows close behind You; Your right hand upholds me.

9. But those who seek my life, to destroy it, Shall go into the lower parts of the earth.

10. They shall fall by the sword; They shall be a portion for jackals.

11. But the king shall rejoice in God; Everyone who swears by Him shall glory; But the mouth of those who speak lies shall be stopped.

## Chapter 64

1. Hear my voice, O God, in my meditation; Preserve my life from fear of the enemy.

2. Hide me from the secret plots of the wicked, From the rebellion of the workers of iniquity,

3. Who sharpen their tongue like a sword, And bend their bows to shoot their arrows--bitter words,

4. That they may shoot in secret at the blameless; Suddenly they shoot at him and do not fear.

5. They encourage themselves in an evil matter; They talk of laying snares secretly; They say, "Who will see them?"

6. They devise iniquities: "We have perfected a shrewd scheme." Both the inward thought and the heart of man are deep.

7. But God shall shoot at them with an arrow; Suddenly they shall be wounded.

8. So He will make them stumble over their own tongue; All who see them shall flee away.

9. All men shall fear, And shall declare the work of God; For they shall wisely consider His doing.

10. The righteous shall be glad in the LORD, and trust in Him. And all the upright in heart shall glory.

## Chapter 65

1. Praise is awaiting You, O God, in Zion; And to You the vow shall be performed.

2. O You who hear prayer, To You all flesh will come.

3. Iniquities prevail against me; As for our transgressions, You will provide atonement for them.

4. Blessed is the man You choose, And cause to approach You, That he may dwell in Your courts. We shall be satisfied with the goodness of Your house, Of Your holy temple.

5. By awesome deeds in righteousness You will answer us, O God of our salvation, You who are the confidence of all the ends of the earth, And of the far-off seas;

6. Who established the mountains by His strength, Being clothed with power;

7. You who still the noise of the seas, The noise of their waves, And the tumult of the peoples.

8. They also who dwell in the farthest parts are afraid of Your signs; You make the outgoings of the morning and evening rejoice.

9. You visit the earth and water it, You greatly enrich it; The river of God is full of water; You provide their grain, For so You have prepared it.

10. You water its ridges abundantly, You settle its furrows; You make it soft with showers, You bless its growth.

11. You crown the year with Your goodness, And Your paths drip with abundance.

12. They drop on the pastures of the wilderness, And the little hills rejoice on every side.

13. The pastures are clothed with flocks; The valleys also are covered with grain; They shout for joy, they also sing.

## Chapter 66

1. Make a joyful shout to God, all the earth!

2. Sing out the honor of His name; Make His praise glorious.

3. Say to God, "How awesome are Your works! Through the greatness of Your power Your enemies shall submit themselves to You.

4. All the earth shall worship You And sing praises to You; They shall sing praises to Your name."Selah

5. Come and see the works of God; He is awesome in His doing toward the sons of men.

6. He turned the sea into dry land; They went through the river on foot. There we will rejoice in Him.

7. He rules by His power forever; His eyes observe the nations; Do not let the rebellious exalt themselves.Selah

8. Oh, bless our God, you peoples! And make the voice of His praise to be heard,

9. Who keeps our soul among the living, And does not allow our feet to be moved.

10. For You, O God, have tested us; You have refined us as silver is refined.

11. You brought us into the net; You laid affliction on our backs.

12. You have caused men to ride over our heads; We went through fire and through water; But You brought us out to rich fulfillment.

13. I will go into Your house with burnt offerings; I will pay You my vows,

14. Which my lips have uttered And my mouth has spoken when I was in trouble.

15. I will offer You burnt sacrifices of fat animals, With the sweet aroma of rams; I will offer bulls with goats.Selah

16. Come and hear, all you who fear God, And I will declare what He has done for my soul.

17. I cried to Him with my mouth, And He was extolled with my tongue.

18. If I regard iniquity in my heart, The Lord will not hear.

19. But certainly God has heard me; He has attended to the voice of my prayer.

20. Blessed be God, Who has not turned away my prayer, Nor His mercy from me!

## Chapter 67

1. God be merciful to us and bless us, And cause His face to shine upon us,Selah

2. That Your way may be known on earth, Your salvation among all nations.

3. Let the peoples praise You, O God; Let all the peoples praise You.

4. Oh, let the nations be glad and sing for joy! For You shall judge the people righteously, And govern the nations on earth.Selah

5. Let the peoples praise You, O God; Let all the peoples praise You.

6. Then the earth shall yield her increase; God, our own God, shall bless us.

7. God shall bless us, And all the ends of the earth shall fear Him.

## Chapter 68

1. Let God arise, Let His enemies be scattered; Let those also who hate Him flee before Him.

2. As smoke is driven away, So drive them away; As wax melts before the fire, So let the wicked perish at the presence of God.

3. But let the righteous be glad; Let them rejoice before God; Yes, let them rejoice exceedingly.

4. Sing to God, sing praises to His name; Extol Him who rides on the clouds, By His name YAH, And rejoice before Him.

5. A father of the fatherless, a defender of widows, Is God in His holy habitation.

6. God sets the solitary in families; He brings out those who are bound into prosperity; But the rebellious dwell in a dry land.

7. O God, when You went out before Your people, When You marched through the wilderness,Selah

8. The earth shook; The heavens also dropped rain at the presence of God; Sinai itself was moved at the presence of God, the God of Israel.

9. You, O God, sent a plentiful rain, Whereby You confirmed Your inheritance, When it was weary.

10. Your congregation dwelt in it; You, O God, provided from Your goodness for the poor.

11. The Lord gave the word; Great was the company of those who proclaimed it:

12. "Kings of armies flee, they flee, And she who remains at home divides the spoil.

13. Though you lie down among the sheepfolds, You will be like the wings of a dove covered with silver, And her feathers with yellow gold."

14. When the Almighty scattered kings in it, It was white as snow in Zalmon.

15. A mountain of God is the mountain of Bashan; A mountain of many peaks is the mountain of Bashan.

16. Why do you fume with envy, you mountains of many peaks? This is the mountain which God desires to dwell in; Yes, the LORD will dwell in it forever.

17. The chariots of God are twenty thousand, Even thousands of thousands; The Lord is among them as in Sinai, in the Holy Place.

18. You have ascended on high, You have led captivity captive; You have received gifts among men, Even from the rebellious, That the LORD God might dwell there.

19. Blessed be the Lord, Who daily loads us with benefits, The God of our salvation!Selah

20. Our God is the God of salvation; And to GOD the Lord belong escapes from death.

21. But God will wound the head of His enemies, The hairy scalp of the one who still goes on in his trespasses.

22. The Lord said, "I will bring back from Bashan, I will bring them back from the depths of the sea,

23. That your foot may crush them in blood, And the tongues of your dogs may have their portion from your enemies."

24. They have seen Your procession, O God, The procession of my God, my King, into the sanctuary.

25. The singers went before, the players on instruments followed after; Among them were the maidens playing timbrels.

26. Bless God in the congregations, The Lord, from the fountain of Israel.

27. There is little Benjamin, their leader, The princes of Judah and their company, The princes of Zebulun and the princes of Naphtali.

28. Your God has commanded your strength; Strengthen, O God, what You have done for us.

29. Because of Your temple at Jerusalem, Kings will bring presents to You.

30. Rebuke the beasts of the reeds, The herd of bulls with the calves of the peoples, Till everyone submits himself with pieces of silver. Scatter the peoples who delight in war.

31. Envoys will come out of Egypt; Ethiopia will quickly stretch out her hands to God.

32. Sing to God, you kingdoms of the earth; Oh, sing praises to the Lord,Selah

33. To Him who rides on the heaven of heavens, which were of old! Indeed, He sends out His voice, a mighty voice.

34. Ascribe strength to God; His excellence is over Israel, And His strength is in the clouds.

35. O God, You are more awesome than Your holy places. The God of Israel is He who gives strength and power to His people. Blessed be God!

## Chapter 69

1. Save me, O God! For the waters have come up to my neck.

2. I sink in deep mire, Where there is no standing; I have come into deep waters, Where the floods overflow me.

3. I am weary with my crying; My throat is dry; My eyes fail while I wait for my God.

4. Those who hate me without a cause Are more than the hairs of my head; They are mighty who would destroy me, Being my enemies wrongfully; Though I have stolen nothing, I still must restore it.

5. O God, You know my foolishness; And my sins are not hidden from You.

6. Let not those who wait for You, O Lord GOD of hosts, be ashamed because of me; Let not those who seek You be confounded because of me, O God of Israel.

7. Because for Your sake I have borne reproach; Shame has covered my face.

8. I have become a stranger to my brothers, And an alien to my mother's children;

9. Because zeal for Your house has eaten me up, And the reproaches of those who reproach You have fallen on me.

10. When I wept and chastened my soul with fasting, That became my reproach.

11. I also made sackcloth my garment; I became a byword to them.

12. Those who sit in the gate speak against me, And I am the song of the drunkards.

13. But as for me, my prayer is to You, O LORD, in the acceptable time; O God, in the multitude of Your mercy, Hear me in the truth of Your salvation.

14. Deliver me out of the mire, And let me not sink; Let me be delivered from those who hate me, And out of the deep waters.

15. Let not the floodwater overflow me, Nor let the deep swallow me up; And let not the pit shut its mouth on me.

16. Hear me, O LORD, for Your lovingkindness is good; Turn to me according to the multitude of Your tender mercies.

17. And do not hide Your face from Your servant, For I am in trouble; Hear me speedily.

18. Draw near to my soul, and redeem it; Deliver me because of my enemies.

19. You know my reproach, my shame, and my dishonor; My adversaries are all before You.

20. Reproach has broken my heart, And I am full of heaviness; I looked for someone to take pity, but there was none; And for comforters, but I found none.

21. They also gave me gall for my food, And for my thirst they gave me vinegar to drink.

22. Let their table become a snare before them, And their well-being a trap.

23. Let their eyes be darkened, so that they do not see; And make their loins shake continually.

24. Pour out Your indignation upon them, And let Your wrathful anger take hold of them.

25. Let their dwelling place be desolate; Let no one live in their tents.

26. For they persecute the ones You have struck, And talk of the grief of those You have wounded.

27. Add iniquity to their iniquity, And let them not come into Your righteousness.

28. Let them be blotted out of the book of the living, And not be written with the righteous.

29. But I am poor and sorrowful; Let Your salvation, O God, set me up on high.

30. I will praise the name of God with a song, And will magnify Him with thanksgiving.

31. This also shall please the LORD better than an ox or bull, Which has horns and hooves.

32. The humble shall see this and be glad; And you who seek God, your hearts shall live.

33. For the LORD hears the poor, And does not despise His prisoners.

34. Let heaven and earth praise Him, The seas and everything that moves in them.

35. For God will save Zion And build the cities of Judah, That they may dwell there and possess it.

36. Also, the descendants of His servants shall inherit it, And those who love His name shall dwell in it.

## Chapter 70

1. Make haste, O God, to deliver me! Make haste to help me, O LORD!

2. Let them be ashamed and confounded Who seek my life; Let them be turned back and confused Who desire my hurt.

3. Let them be turned back because of their shame, Who say, "Aha, aha!"

4. Let all those who seek You rejoice and be glad in You; And let those who love Your salvation say continually, "Let God be magnified!"

5. But I am poor and needy; Make haste to me, O God! You are my help and my deliverer; O LORD, do not delay.

## Chapter 71

1. In You, O LORD, I put my trust; Let me never be put to shame.

2. Deliver me in Your righteousness, and cause me to escape; Incline Your ear to me, and save me.

3. Be my strong refuge, To which I may resort continually; You have given the commandment to save me, For You are my rock and my fortress.

4. Deliver me, O my God, out of the hand of the wicked, Out of the hand of the unrighteous and cruel man.

5. For You are my hope, O Lord GOD; You are my trust from my youth.

6. By You I have been upheld from birth; You are He who took me out of my mother's womb. My praise shall be continually of You.

7. I have become as a wonder to many, But You are my strong refuge.

8. Let my mouth be filled with Your praise And with Your glory all the day.

9. Do not cast me off in the time of old age; Do not forsake me when my strength fails.

10. For my enemies speak against me; And those who lie in wait for my life take counsel together,

11. Saying, "God has forsaken him; Pursue and take him, for there is none to deliver him."

12. O God, do not be far from me; O my God, make haste to help me!

13. Let them be confounded and consumed Who are adversaries of my life; Let them be covered with reproach and dishonor Who seek my hurt.

14. But I will hope continually, And will praise You yet more and more.

15. My mouth shall tell of Your righteousness And Your salvation all the day, For I do not know their limits.

16. I will go in the strength of the Lord GOD; I will make mention of Your righteousness, of Yours only.

17. O God, You have taught me from my youth; And to this day I declare Your wondrous works.

18. Now also when I am old and grayheaded, O God, do not forsake me, Until I declare Your strength to this generation, Your power to everyone who is to come.

19. Also Your righteousness, O God, is very high, You who have done great things; O God, who is like You?

20. You, who have shown me great and severe troubles, Shall revive me again, And bring me up again from the depths of the earth.

21. You shall increase my greatness, And comfort me on every side.

22. Also with the lute I will praise You-- And Your faithfulness, O my God! To You I will sing with the harp, O Holy One of Israel.

23. My lips shall greatly rejoice when I sing to You, And my soul, which You have redeemed.

24. My tongue also shall talk of Your righteousness all the day long; For they are confounded, For they are brought to shame Who seek my hurt.

## Chapter 72

1. Give the king Your judgments, O God, And Your righteousness to the king's Son.

2. He will judge Your people with righteousness, And Your poor with justice.

3. The mountains will bring peace to the people, And the little hills, by righteousness.

4. He will bring justice to the poor of the people; He will save the children of the needy, And will break in pieces the oppressor.

5. They shall fear You As long as the sun and moon endure, Throughout all generations.

6. He shall come down like rain upon the grass before mowing, Like showers that water the earth.

7. In His days the righteous shall flourish, And abundance of peace, Until the moon is no more.

8. He shall have dominion also from sea to sea, And from the River to the ends of the earth.

9. Those who dwell in the wilderness will bow before Him, And His enemies will lick the dust.

10. The kings of Tarshish and of the isles Will bring presents; The kings of Sheba and Seba Will offer gifts.

11. Yes, all kings shall fall down before Him; All nations shall serve Him.

12. For He will deliver the needy when he cries, The poor also, and him who has no helper.

13. He will spare the poor and needy, And will save the souls of the needy.

14. He will redeem their life from oppression and violence; And precious shall be their blood in His sight.

15. And He shall live; And the gold of Sheba will be given to Him; Prayer also will be made for Him continually, And daily He shall be praised.

16. There will be an abundance of grain in the earth, On the top of the mountains; Its fruit shall wave like Lebanon; And those of the city shall flourish like grass of the earth.

17. His name shall endure forever; His name shall continue as long as the sun. And men shall be blessed in Him; All nations shall call Him blessed.

18. Blessed be the LORD God, the God of Israel, Who only does wondrous things!

19. And blessed be His glorious name forever! And let the whole earth be filled with His glory. Amen and Amen.

20. The prayers of David the son of Jesse are ended.

## Chapter 73

1. Truly God is good to Israel, To such as are pure in heart.

2. But as for me, my feet had almost stumbled; My steps had nearly slipped.

3. For I was envious of the boastful, When I saw the prosperity of the wicked.

4. For there are no pangs in their death, But their strength is firm.

5. They are not in trouble as other men, Nor are they plagued like other men.

6. Therefore pride serves as their necklace; Violence covers them like a garment.

7. Their eyes bulge with abundance; They have more than heart could wish.

8. They scoff and speak wickedly concerning oppression; They speak loftily.

9. They set their mouth against the heavens, And their tongue walks through the earth.

10. Therefore his people return here, And waters of a full cup are drained by them.

11. And they say, "How does God know? And is there knowledge in the Most High?"

12. Behold, these are the ungodly, Who are always at ease; They increase in riches.

13. Surely I have cleansed my heart in vain, And washed my hands in innocence.

14. For all day long I have been plagued, And chastened every morning.

15. If I had said, "I will speak thus," Behold, I would have been untrue to the generation of Your children.

16. When I thought how to understand this, It was too painful for me--

17. Until I went into the sanctuary of God; Then I understood their end.

18. Surely You set them in slippery places; You cast them down to destruction.

19. Oh, how they are brought to desolation, as in a moment! They are utterly consumed with terrors.

20. As a dream when one awakes, So, Lord, when You awake, You shall despise their image.

21. Thus my heart was grieved, And I was vexed in my mind.

22. I was so foolish and ignorant; I was like a beast before You.

23. Nevertheless I am continually with You; You hold me by my right hand.

24. You will guide me with Your counsel, And afterward receive me to glory.

25. Whom have I in heaven but You? And there is none upon earth that I desire besides You.

26. My flesh and my heart fail; But God is the strength of my heart and my portion forever.

27. For indeed, those who are far from You shall perish; You have destroyed all those who desert You for harlotry.

28. But it is good for me to draw near to God; I have put my trust in the Lord GOD, That I may declare all Your works.

## Chapter 74

1. O God, why have You cast us off forever? Why does Your anger smoke against the sheep of Your pasture?

2. Remember Your congregation, which You have purchased of old, The tribe of Your inheritance, which You have redeemed-- This Mount Zion where You have dwelt.

3. Lift up Your feet to the perpetual desolations. The enemy has damaged everything in the sanctuary.

4. Your enemies roar in the midst of Your meeting place; They set up their banners for signs.

5. They seem like men who lift up Axes among the thick trees.

6. And now they break down its carved work, all at once, With axes and hammers.

7. They have set fire to Your sanctuary; They have defiled the dwelling place of Your name to the ground.

8. They said in their hearts, "Let us destroy them altogether." They have burned up all the meeting places of God in the land.

9. We do not see our signs; There is no longer any prophet; Nor is there any among us who knows how long.

10. O God, how long will the adversary reproach? Will the enemy blaspheme Your name forever?

11. Why do You withdraw Your hand, even Your right hand? Take it out of Your bosom and destroy them.

12. For God is my King from of old, Working salvation in the midst of the earth.

13. You divided the sea by Your strength; You broke the heads of the sea serpents in the waters.

14. You broke the heads of Leviathan in pieces, And gave him as food to the people inhabiting the wilderness.

15. You broke open the fountain and the flood; You dried up mighty rivers.

16. The day is Yours, the night also is Yours; You have prepared the light and the sun.

17. You have set all the borders of the earth; You have made summer and winter.

18. Remember this, that the enemy has reproached, O LORD, And that a foolish people has blasphemed Your name.

19. Oh, do not deliver the life of Your turtledove to the wild beast! Do not forget the life of Your poor forever.

20. Have respect to the covenant; For the dark places of the earth are full of the haunts of cruelty.

21. Oh, do not let the oppressed return ashamed! Let the poor and needy praise Your name.

22. Arise, O God, plead Your own cause; Remember how the foolish man reproaches You daily.

23. Do not forget the voice of Your enemies; The tumult of those who rise up against You increases continually.

## Chapter 75

1. We give thanks to You, O God, we give thanks! For Your wondrous works declare that Your name is near.

2. "When I choose the proper time, I will judge uprightly.

3. The earth and all its inhabitants are dissolved; I set up its pillars firmly.Selah

4. "I said to the boastful, "Do not deal boastfully,' And to the wicked, "Do not lift up the horn.

5. Do not lift up your horn on high; Do not speak with a stiff neck."'

6. For exaltation comes neither from the east Nor from the west nor from the south.

7. But God is the Judge: He puts down one, And exalts another.

8. For in the hand of the LORD there is a cup, And the wine is red; It is fully mixed, and He pours it out; Surely its dregs shall all the wicked of the earth Drain and drink down.

9. But I will declare forever, I will sing praises to the God of Jacob.

10. "All the horns of the wicked I will also cut off, But the horns of the righteous shall be exalted."

## Chapter 76

1. In Judah God is known; His name is great in Israel.

2. In Salem also is His tabernacle, And His dwelling place in Zion.

3. There He broke the arrows of the bow, The shield and sword of battle.Selah

4. You are more glorious and excellent Than the mountains of prey.

5. The stouthearted were plundered; They have sunk into their sleep; And none of the mighty men have found the use of their hands.

6. At Your rebuke, O God of Jacob, Both the chariot and horse were cast into a dead sleep.

7. You, Yourself, are to be feared; And who may stand in Your presence When once You are angry?

8. You caused judgment to be heard from heaven; The earth feared and was still,

9. When God arose to judgment, To deliver all the oppressed of the earth.Selah

10. Surely the wrath of man shall praise You; With the remainder of wrath You shall gird Yourself.

11. Make vows to the LORD your God, and pay them; Let all who are around Him bring presents to Him who ought to be feared.

12. He shall cut off the spirit of princes; He is awesome to the kings of the earth.

## Chapter 77

1. I cried out to God with my voice-- To God with my voice; And He gave ear to me.

2. In the day of my trouble I sought the Lord; My hand was stretched out in the night without ceasing; My soul refused to be comforted.

3. I remembered God, and was troubled; I complained, and my spirit was overwhelmed.Selah

4. You hold my eyelids open; I am so troubled that I cannot speak.

5. I have considered the days of old, The years of ancient times.

6. I call to remembrance my song in the night; I meditate within my heart, And my spirit makes diligent search.

7. Will the Lord cast off forever? And will He be favorable no more?

8. Has His mercy ceased forever? Has His promise failed forevermore?

9. Has God forgotten to be gracious? Has He in anger shut up His tender mercies?Selah

10. And I said, "This is my anguish; But I will remember the years of the right hand of the Most High."

11. I will remember the works of the LORD; Surely I will remember Your wonders of old.

12. I will also meditate on all Your work, And talk of Your deeds.

13. Your way, O God, is in the sanctuary; Who is so great a God as our God?

14. You are the God who does wonders; You have declared Your strength among the peoples.

15. You have with Your arm redeemed Your people, The sons of Jacob and Joseph.Selah

16. The waters saw You, O God; The waters saw You, they were afraid; The depths also trembled.

17. The clouds poured out water; The skies sent out a sound; Your arrows also flashed about.

18. The voice of Your thunder was in the whirlwind; The lightnings lit up the world; The earth trembled and shook.

19. Your way was in the sea, Your path in the great waters, And Your footsteps were not known.

20. You led Your people like a flock By the hand of Moses and Aaron.

## Chapter 78

1. Give ear, O my people, to my law; Incline your ears to the words of my mouth.

2. I will open my mouth in a parable; I will utter dark sayings of old,

3. Which we have heard and known, And our fathers have told us.

4. We will not hide them from their children, Telling to the generation to come the praises of the LORD, And His strength and His wonderful works that He has done.

5. For He established a testimony in Jacob, And appointed a law in Israel, Which He commanded our fathers, That they should make them known to their children;

6. That the generation to come might know them, The children who would be born, That they may arise and declare them to their children,

7. That they may set their hope in God, And not forget the works of God, But keep His commandments;

8. And may not be like their fathers, A stubborn and rebellious generation, A generation that did not set its heart aright, And whose spirit was not faithful to God.

9. The children of Ephraim, being armed and carrying bows, Turned back in the day of battle.

10. They did not keep the covenant of God; They refused to walk in His law,

11. And forgot His works And His wonders that He had shown them.

12. Marvelous things He did in the sight of their fathers, In the land of Egypt, in the field of Zoan.

13. He divided the sea and caused them to pass through; And He made the waters stand up like a heap.

14. In the daytime also He led them with the cloud, And all the night with a light of fire.

15. He split the rocks in the wilderness, And gave them drink in abundance like the depths.

16. He also brought streams out of the rock, And caused waters to run down like rivers.

17. But they sinned even more against Him By rebelling against the Most High in the wilderness.

18. And they tested God in their heart By asking for the food of their fancy.

19. Yes, they spoke against God: They said, "Can God prepare a table in the wilderness?

20. Behold, He struck the rock, So that the waters gushed out, And the streams overflowed. Can He give bread also? Can He provide meat for His people?|"

21. Therefore the LORD heard this and was furious; So a fire was kindled against Jacob, And anger also came up against Israel,

22. Because they did not believe in God, And did not trust in His salvation.

23. Yet He had commanded the clouds above, And opened the doors of heaven,

24. Had rained down manna on them to eat, And given them of the bread of heaven.

25. Men ate angels' food; He sent them food to the full.

26. He caused an east wind to blow in the heavens; And by His power He brought in the south wind.

27. He also rained meat on them like the dust, Feathered fowl like the sand of the seas;

28. And He let them fall in the midst of their camp, All around their dwellings.

29. So they ate and were well filled, For He gave them their own desire.

30. They were not deprived of their craving; But while their food was still in their mouths,

31. The wrath of God came against them, And slew the stoutest of them, And struck down the choice men of Israel.

32. In spite of this they still sinned, And did not believe in His wondrous works.

33. Therefore their days He consumed in futility, And their years in fear.

34. When He slew them, then they sought Him; And they returned and sought earnestly for God.

35. Then they remembered that God was their rock, And the Most High God their Redeemer.

36. Nevertheless they flattered Him with their mouth, And they lied to Him with their tongue;

37. For their heart was not steadfast with Him, Nor were they faithful in His covenant.

38. But He, being full of compassion, forgave their iniquity, And did not destroy them. Yes, many a time He turned His anger away, And did not stir up all His wrath;

39. For He remembered that they were but flesh, A breath that passes away and does not come again.

40. How often they provoked Him in the wilderness, And grieved Him in the desert!

41. Yes, again and again they tempted God, And limited the Holy One of Israel.

42. They did not remember His power: The day when He redeemed them from the enemy,

43. When He worked His signs in Egypt, And His wonders in the field of Zoan;

44. Turned their rivers into blood, And their streams, that they could not drink.

45. He sent swarms of flies among them, which devoured them, And frogs, which destroyed them.

46. He also gave their crops to the caterpillar, And their labor to the locust.

47. He destroyed their vines with hail, And their sycamore trees with frost.

48. He also gave up their cattle to the hail, And their flocks to fiery lightning.

49. He cast on them the fierceness of His anger, Wrath, indignation, and trouble, By sending angels of destruction among them.

50. He made a path for His anger; He did not spare their soul from death, But gave their life over to the plague,

51. And destroyed all the firstborn in Egypt, The first of their strength in the tents of Ham.

52. But He made His own people go forth like sheep, And guided them in the wilderness like a flock;

53. And He led them on safely, so that they did not fear; But the sea overwhelmed their enemies.

54. And He brought them to His holy border, This mountain which His right hand had acquired.

55. He also drove out the nations before them, Allotted them an inheritance by survey, And made the tribes of Israel dwell in their tents.

56. Yet they tested and provoked the Most High God, And did not keep His testimonies,

57. But turned back and acted unfaithfully like their fathers; They were turned aside like a deceitful bow.

58. For they provoked Him to anger with their high places, And moved Him to jealousy with their carved images.

59. When God heard this, He was furious, And greatly abhorred Israel,

60. So that He forsook the tabernacle of Shiloh, The tent He had placed among men,

61. And delivered His strength into captivity, And His glory into the enemy's hand.

62. He also gave His people over to the sword, And was furious with His inheritance.

63. The fire consumed their young men, And their maidens were not given in marriage.

64. Their priests fell by the sword, And their widows made no lamentation.

65. Then the Lord awoke as from sleep, Like a mighty man who shouts because of wine.

66. And He beat back His enemies; He put them to a perpetual reproach.

67. Moreover He rejected the tent of Joseph, And did not choose the tribe of Ephraim,

68. But chose the tribe of Judah, Mount Zion which He loved.

69. And He built His sanctuary like the heights, Like the earth which He has established forever.

70. He also chose David His servant, And took him from the sheepfolds;

71. From following the ewes that had young He brought him, To shepherd Jacob His people, And Israel His inheritance.

72. So he shepherded them according to the integrity of his heart, And guided them by the skillfulness of his hands.

## Chapter 79

1. O God, the nations have come into Your inheritance; Your holy temple they have defiled; They have laid Jerusalem in heaps.

2. The dead bodies of Your servants They have given as food for the birds of the heavens, The flesh of Your saints to the beasts of the earth.

3. Their blood they have shed like water all around Jerusalem, And there was no one to bury them.

4. We have become a reproach to our neighbors, A scorn and derision to those who are around us.

5. How long, LORD? Will You be angry forever? Will Your jealousy burn like fire?

6. Pour out Your wrath on the nations that do not know You, And on the kingdoms that do not call on Your name.

7. For they have devoured Jacob, And laid waste his dwelling place.

8. Oh, do not remember former iniquities against us! Let Your tender mercies come speedily to meet us, For we have been brought very low.

9. Help us, O God of our salvation, For the glory of Your name; And deliver us, and provide atonement for our sins, For Your name's sake!

10. Why should the nations say, "Where is their God?" Let there be known among the nations in our sight The avenging of the blood of Your servants which has been shed.

11. Let the groaning of the prisoner come before You; According to the greatness of Your power Preserve those who are appointed to die;

12. And return to our neighbors sevenfold into their bosom Their reproach with which they have reproached You, O Lord.

13. So we, Your people and sheep of Your pasture, Will give You thanks forever; We will show forth Your praise to all generations.

## Chapter 80

1. Give ear, O Shepherd of Israel, You who lead Joseph like a flock; You who dwell between the cherubim, shine forth!

2. Before Ephraim, Benjamin, and Manasseh, Stir up Your strength, And come and save us!

3. Restore us, O God; Cause Your face to shine, And we shall be saved!

4. O LORD God of hosts, How long will You be angry Against the prayer of Your people?

5. You have fed them with the bread of tears, And given them tears to drink in great measure.

6. You have made us a strife to our neighbors, And our enemies laugh among themselves.

7. Restore us, O God of hosts; Cause Your face to shine, And we shall be saved!

8. You have brought a vine out of Egypt; You have cast out the nations, and planted it.

9. You prepared room for it, And caused it to take deep root, And it filled the land.

10. The hills were covered with its shadow, And the mighty cedars with its boughs.

11. She sent out her boughs to the Sea, And her branches to the River.

12. Why have You broken down her hedges, So that all who pass by the way pluck her fruit?

13. The boar out of the woods uproots it, And the wild beast of the field devours it.

14. Return, we beseech You, O God of hosts; Look down from heaven and see, And visit this vine

15. And the vineyard which Your right hand has planted, And the branch that You made strong for Yourself.

16. It is burned with fire, it is cut down; They perish at the rebuke of Your countenance.

17. Let Your hand be upon the man of Your right hand, Upon the son of man whom You made strong for Yourself.

18. Then we will not turn back from You; Revive us, and we will call upon Your name.

19. Restore us, O LORD God of hosts; Cause Your face to shine, And we shall be saved!

## Chapter 81

1. Sing aloud to God our strength; Make a joyful shout to the God of Jacob.

2. Raise a song and strike the timbrel, The pleasant harp with the lute.

3. Blow the trumpet at the time of the New Moon, At the full moon, on our solemn feast day.

4. For this is a statute for Israel, A law of the God of Jacob.

5. This He established in Joseph as a testimony, When He went throughout the land of Egypt, Where I heard a language I did not understand.

6. "I removed his shoulder from the burden; His hands were freed from the baskets.

7. You called in trouble, and I delivered you; I answered you in the secret place of thunder; I tested you at the waters of Meribah.Selah

8. "Hear, O My people, and I will admonish you! O Israel, if you will listen to Me!

9. There shall be no foreign god among you; Nor shall you worship any foreign god.

10. I am the LORD your God, Who brought you out of the land of Egypt; Open your mouth wide, and I will fill it.

11. "But My people would not heed My voice, And Israel would have none of Me.

12. So I gave them over to their own stubborn heart, To walk in their own counsels.

13. "Oh, that My people would listen to Me, That Israel would walk in My ways!

14. I would soon subdue their enemies, And turn My hand against their adversaries.

15. The haters of the LORD would pretend submission to Him, But their fate would endure forever.

16. He would have fed them also with the finest of wheat; And with honey from the rock I would have satisfied you."

## Chapter 82

1. God stands in the congregation of the mighty; He judges among the gods.

2. How long will you judge unjustly, And show partiality to the wicked?Selah

3. Defend the poor and fatherless; Do justice to the afflicted and needy.

4. Deliver the poor and needy; Free them from the hand of the wicked.

5. They do not know, nor do they understand; They walk about in darkness; All the foundations of the earth are unstable.

6. I said, "You are gods, And all of you are children of the Most High.

7. But you shall die like men, And fall like one of the princes."

8. Arise, O God, judge the earth; For You shall inherit all nations.

## Chapter 83

1. Do not keep silent, O God! Do not hold Your peace, And do not be still, O God!

2. For behold, Your enemies make a tumult; And those who hate You have lifted up their head.

3. They have taken crafty counsel against Your people, And consulted together against Your sheltered ones.

4. They have said, "Come, and let us cut them off from being a nation, That the name of Israel may be remembered no more."

5. For they have consulted together with one consent; They form a confederacy against You:

6. The tents of Edom and the Ishmaelites; Moab and the Hagrites;

7. Gebal, Ammon, and Amalek; Philistia with the inhabitants of Tyre;

8. Assyria also has joined with them; They have helped the children of Lot.Selah

9. Deal with them as with Midian, As with Sisera, As with Jabin at the Brook Kishon,

10. Who perished at En Dor, Who became as refuse on the earth.

11. Make their nobles like Oreb and like Zeeb, Yes, all their princes like Zebah and Zalmunna,

12. Who said, "Let us take for ourselves The pastures of God for a possession."

13. O my God, make them like the whirling dust, Like the chaff before the wind!

14. As the fire burns the woods, And as the flame sets the mountains on fire,

15. So pursue them with Your tempest, And frighten them with Your storm.

16. Fill their faces with shame, That they may seek Your name, O LORD.

17. Let them be confounded and dismayed forever; Yes, let them be put to shame and perish,

18. That they may know that You, whose name alone is the LORD, Are the Most High over all the earth.

## Chapter 84

1. How lovely is Your tabernacle, O LORD of hosts!

2. My soul longs, yes, even faints For the courts of the LORD; My heart and my flesh cry out for the living God.

3. Even the sparrow has found a home, And the swallow a nest for herself, Where she may lay her young-- Even Your altars, O LORD of hosts, My King and my God.

4. Blessed are those who dwell in Your house; They will still be praising You.Selah

5. Blessed is the man whose strength is in You, Whose heart is set on pilgrimage.

6. As they pass through the Valley of Baca, They make it a spring; The rain also covers it with pools.

7. They go from strength to strength; Each one appears before God in Zion.

8. O LORD God of hosts, hear my prayer; Give ear, O God of Jacob!Selah

9. O God, behold our shield, And look upon the face of Your anointed.

10. For a day in Your courts is better than a thousand. I would rather be a doorkeeper in the house of my God Than dwell in the tents of wickedness.

11. For the LORD God is a sun and shield; The LORD will give grace and glory; No good thing will He withhold From those who walk uprightly.

12. O LORD of hosts, Blessed is the man who trusts in You!

## Chapter 85

1. LORD, You have been favorable to Your land; You have brought back the captivity of Jacob.

2. You have forgiven the iniquity of Your people; You have covered all their sin.Selah

3. You have taken away all Your wrath; You have turned from the fierceness of Your anger.

4. Restore us, O God of our salvation, And cause Your anger toward us to cease.

5. Will You be angry with us forever? Will You prolong Your anger to all generations?

6. Will You not revive us again, That Your people may rejoice in You?

7. Show us Your mercy, LORD, And grant us Your salvation.

8. I will hear what God the LORD will speak, For He will speak peace To His people and to His saints; But let them not turn back to folly.

9. Surely His salvation is near to those who fear Him, That glory may dwell in our land.

10. Mercy and truth have met together; Righteousness and peace have kissed.

11. Truth shall spring out of the earth, And righteousness shall look down from heaven.

12. Yes, the LORD will give what is good; And our land will yield its increase.

13. Righteousness will go before Him, And shall make His footsteps our pathway.

## Chapter 86

1. Bow down Your ear, O LORD, hear me; For I am poor and needy.

2. Preserve my life, for I am holy; You are my God; Save Your servant who trusts in You!

3. Be merciful to me, O Lord, For I cry to You all day long.

4. Rejoice the soul of Your servant, For to You, O Lord, I lift up my soul.

5. For You, Lord, are good, and ready to forgive, And abundant in mercy to all those who call upon You.

6. Give ear, O LORD, to my prayer; And attend to the voice of my supplications.

7. In the day of my trouble I will call upon You, For You will answer me.

8. Among the gods there is none like You, O Lord; Nor are there any works like Your works.

9. All nations whom You have made Shall come and worship before You, O Lord, And shall glorify Your name.

10. For You are great, and do wondrous things; You alone are God.

11. Teach me Your way, O LORD; I will walk in Your truth; Unite my heart to fear Your name.

12. I will praise You, O Lord my God, with all my heart, And I will glorify Your name forevermore.

13. For great is Your mercy toward me, And You have delivered my soul from the depths of Sheol.

14. O God, the proud have risen against me, And a mob of violent men have sought my life, And have not set You before them.

15. But You, O Lord, are a God full of compassion, and gracious, Longsuffering and abundant in mercy and truth.

16. Oh, turn to me, and have mercy on me! Give Your strength to Your servant, And save the son of Your maidservant.

17. Show me a sign for good, That those who hate me may see it and be ashamed, Because You, LORD, have helped me and comforted me.

## Chapter 87

1. His foundation is in the holy mountains.

2. The LORD loves the gates of Zion More than all the dwellings of Jacob.

3. Glorious things are spoken of you, O city of God!Selah

4. "I will make mention of Rahab and Babylon to those who know Me; Behold, O Philistia and Tyre, with Ethiopia: "This one was born there.'|"

5. And of Zion it will be said, "This one and that one were born in her; And the Most High Himself shall establish her."

6. The LORD will record, When He registers the peoples: "This one was born there."Selah

7. Both the singers and the players on instruments say, "All my springs are in you."

## Chapter 88

1. O LORD, God of my salvation, I have cried out day and night before You.

2. Let my prayer come before You; Incline Your ear to my cry.

3. For my soul is full of troubles, And my life draws near to the grave.

4. I am counted with those who go down to the pit; I am like a man who has no strength,

5. Adrift among the dead, Like the slain who lie in the grave, Whom You remember no more, And who are cut off from Your hand.

6. You have laid me in the lowest pit, In darkness, in the depths.

7. Your wrath lies heavy upon me, And You have afflicted me with all Your waves.Selah

8. You have put away my acquaintances far from me; You have made me an abomination to them; I am shut up, and I cannot get out;

9. My eye wastes away because of affliction. LORD, I have called daily upon You; I have stretched out my hands to You.

10. Will You work wonders for the dead? Shall the dead arise and praise You?Selah

11. Shall Your lovingkindness be declared in the grave? Or Your faithfulness in the place of destruction?

12. Shall Your wonders be known in the dark? And Your righteousness in the land of forgetfulness?

13. But to You I have cried out, O LORD, And in the morning my prayer comes before You.

14. LORD, why do You cast off my soul? Why do You hide Your face from me?

15. I have been afflicted and ready to die from my youth; I suffer Your terrors; I am distraught.

16. Your fierce wrath has gone over me; Your terrors have cut me off.

17. They came around me all day long like water; They engulfed me altogether.

18. Loved one and friend You have put far from me, And my acquaintances into darkness.

## Chapter 89

1. I will sing of the mercies of the LORD forever; With my mouth will I make known Your faithfulness to all generations.

2. For I have said, "Mercy shall be built up forever; Your faithfulness You shall establish in the very heavens."

3. "I have made a covenant with My chosen, I have sworn to My servant David:

4. "Your seed I will establish forever, And build up your throne to all generations."'Selah

5. And the heavens will praise Your wonders, O LORD; Your faithfulness also in the assembly of the saints.

6. For who in the heavens can be compared to the LORD? Who among the sons of the mighty can be likened to the LORD?

7. God is greatly to be feared in the assembly of the saints, And to be held in reverence by all those around Him.

8. O LORD God of hosts, Who is mighty like You, O LORD? Your faithfulness also surrounds You.

9. You rule the raging of the sea; When its waves rise, You still them.

10. You have broken Rahab in pieces, as one who is slain; You have scattered Your enemies with Your mighty arm.

11. The heavens are Yours, the earth also is Yours; The world and all its fullness, You have founded them.

12. The north and the south, You have created them; Tabor and Hermon rejoice in Your name.

13. You have a mighty arm; Strong is Your hand, and high is Your right hand.

14. Righteousness and justice are the foundation of Your throne; Mercy and truth go before Your face.

15. Blessed are the people who know the joyful sound! They walk, O LORD, in the light of Your countenance.

16. In Your name they rejoice all day long, And in Your righteousness they are exalted.

17. For You are the glory of their strength, And in Your favor our horn is exalted.

18. For our shield belongs to the LORD, And our king to the Holy One of Israel.

19. Then You spoke in a vision to Your holy one, And said: "I have given help to one who is mighty; I have exalted one chosen from the people.

20. I have found My servant David; With My holy oil I have anointed him,

21. With whom My hand shall be established; Also My arm shall strengthen him.

22. The enemy shall not outwit him, Nor the son of wickedness afflict him.

23. I will beat down his foes before his face, And plague those who hate him.

24. "But My faithfulness and My mercy shall be with him, And in My name his horn shall be exalted.

25. Also I will set his hand over the sea, And his right hand over the rivers.

26. He shall cry to Me, "You are my Father, My God, and the rock of my salvation.'

27. Also I will make him My firstborn, The highest of the kings of the earth.

28. My mercy I will keep for him forever, And My covenant shall stand firm with him.

29. His seed also I will make to endure forever, And his throne as the days of heaven.

30. "If his sons forsake My law And do not walk in My judgments,

31. If they break My statutes And do not keep My commandments,

32. Then I will punish their transgression with the rod, And their iniquity with stripes.

33. Nevertheless My lovingkindness I will not utterly take from him, Nor allow My faithfulness to fail.

34. My covenant I will not break, Nor alter the word that has gone out of My lips.

35. Once I have sworn by My holiness; I will not lie to David:

36. His seed shall endure forever, And his throne as the sun before Me;

37. It shall be established forever like the moon, Even like the faithful witness in the sky."Selah

38. But You have cast off and abhorred, You have been furious with Your anointed.

39. You have renounced the covenant of Your servant; You have profaned his crown by casting it to the ground.

40. You have broken down all his hedges; You have brought his strongholds to ruin.

41. All who pass by the way plunder him; He is a reproach to his neighbors.

42. You have exalted the right hand of his adversaries; You have made all his enemies rejoice.

43. You have also turned back the edge of his sword, And have not sustained him in the battle.

44. You have made his glory cease, And cast his throne down to the ground.

45. The days of his youth You have shortened; You have covered him with shame.Selah

46. How long, LORD? Will You hide Yourself forever? Will Your wrath burn like fire?

47. Remember how short my time is; For what futility have You created all the children of men?

48. What man can live and not see death? Can he deliver his life from the power of the grave?Selah

49. Lord, where are Your former lovingkindnesses, Which You swore to David in Your truth?

50. Remember, Lord, the reproach of Your servants-- How I bear in my bosom the reproach of all the many peoples,

51. With which Your enemies have reproached, O LORD, With which they have reproached the footsteps of Your anointed.

52. Blessed be the LORD forevermore! Amen and Amen.

## Chapter 90

1. Lord, You have been our dwelling place in all generations.

2. Before the mountains were brought forth, Or ever You had formed the earth and the world, Even from everlasting to everlasting, You are God.

3. You turn man to destruction, And say, "Return, O children of men."

4. For a thousand years in Your sight Are like yesterday when it is past, And like a watch in the night.

5. You carry them away like a flood; They are like a sleep. In the morning they are like grass which grows up:

6. In the morning it flourishes and grows up; In the evening it is cut down and withers.

7. For we have been consumed by Your anger, And by Your wrath we are terrified.

8. You have set our iniquities before You, Our secret sins in the light of Your countenance.

9. For all our days have passed away in Your wrath; We finish our years like a sigh.

10. The days of our lives are seventy years; And if by reason of strength they are eighty years, Yet their boast is only labor and sorrow; For it is soon cut off, and we fly away.

11. Who knows the power of Your anger? For as the fear of You, so is Your wrath.

12. So teach us to number our days, That we may gain a heart of wisdom.

13. Return, O LORD! How long? And have compassion on Your servants.

14. Oh, satisfy us early with Your mercy, That we may rejoice and be glad all our days!

15. Make us glad according to the days in which You have afflicted us, The years in which we have seen evil.

16. Let Your work appear to Your servants, And Your glory to their children.

17. And let the beauty of the LORD our God be upon us, And establish the work of our hands for us; Yes, establish the work of our hands.

## Chapter 91

1. He who dwells in the secret place of the Most High Shall abide under the shadow of the Almighty.

2. I will say of the LORD, "He is my refuge and my fortress; My God, in Him I will trust."

3. Surely He shall deliver you from the snare of the fowler And from the perilous pestilence.

4. He shall cover you with His feathers, And under His wings you shall take refuge; His truth shall be your shield and buckler.

5. You shall not be afraid of the terror by night, Nor of the arrow that flies by day,

6. Nor of the pestilence that walks in darkness, Nor of the destruction that lays waste at noonday.

7. A thousand may fall at your side, And ten thousand at your right hand; But it shall not come near you.

8. Only with your eyes shall you look, And see the reward of the wicked.

9. Because you have made the LORD, who is my refuge, Even the Most High, your dwelling place,

10. No evil shall befall you, Nor shall any plague come near your dwelling;

11. For He shall give His angels charge over you, To keep you in all your ways.

12. In their hands they shall bear you up, Lest you dash your foot against a stone.

13. You shall tread upon the lion and the cobra, The young lion and the serpent you shall trample underfoot.

14. "Because he has set his love upon Me, therefore I will deliver him; I will set him on high, because he has known My name.

15. He shall call upon Me, and I will answer him; I will be with him in trouble; I will deliver him and honor him.

16. With long life I will satisfy him, And show him My salvation."

## Chapter 92

1. It is good to give thanks to the LORD, And to sing praises to Your name, O Most High;

2. To declare Your lovingkindness in the morning, And Your faithfulness every night,

3. On an instrument of ten strings, On the lute, And on the harp, With harmonious sound.

4. For You, LORD, have made me glad through Your work; I will triumph in the works of Your hands.

5. O LORD, how great are Your works! Your thoughts are very deep.

6. A senseless man does not know, Nor does a fool understand this.

7. When the wicked spring up like grass, And when all the workers of iniquity flourish, It is that they may be destroyed forever.

8. But You, LORD, are on high forevermore.

9. For behold, Your enemies, O LORD, For behold, Your enemies shall perish; All the workers of iniquity shall be scattered.

10. But my horn You have exalted like a wild ox; I have been anointed with fresh oil.

11. My eye also has seen my desire on my enemies; My ears hear my desire on the wicked Who rise up against me.

12. The righteous shall flourish like a palm tree, He shall grow like a cedar in Lebanon.

13. Those who are planted in the house of the LORD Shall flourish in the courts of our God.

14. They shall still bear fruit in old age; They shall be fresh and flourishing,

15. To declare that the LORD is upright; He is my rock, and there is no unrighteousness in Him.

## Chapter 93

1. The LORD reigns, He is clothed with majesty; The LORD is clothed, He has girded Himself with strength. Surely the world is established, so that it cannot be moved.

2. Your throne is established from of old; You are from everlasting.

3. The floods have lifted up, O LORD, The floods have lifted up their voice; The floods lift up their waves.

4. The LORD on high is mightier Than the noise of many waters, Than the mighty waves of the sea.

5. Your testimonies are very sure; Holiness adorns Your house, O LORD, forever.

## Chapter 94

1. O LORD God, to whom vengeance belongs-- O God, to whom vengeance belongs, shine forth!

2. Rise up, O Judge of the earth; Render punishment to the proud.

3. LORD, how long will the wicked, How long will the wicked triumph?

4. They utter speech, and speak insolent things; All the workers of iniquity boast in themselves.

5. They break in pieces Your people, O LORD, And afflict Your heritage.

6. They slay the widow and the stranger, And murder the fatherless.

7. Yet they say, "The LORD does not see, Nor does the God of Jacob understand."

8. Understand, you senseless among the people; And you fools, when will you be wise?

9. He who planted the ear, shall He not hear? He who formed the eye, shall He not see?

10. He who instructs the nations, shall He not correct, He who teaches man knowledge?

11. The LORD knows the thoughts of man, That they are futile.

12. Blessed is the man whom You instruct, O LORD, And teach out of Your law,

13. That You may give him rest from the days of adversity, Until the pit is dug for the wicked.

14. For the LORD will not cast off His people, Nor will He forsake His inheritance.

15. But judgment will return to righteousness, And all the upright in heart will follow it.

16. Who will rise up for me against the evildoers? Who will stand up for me against the workers of iniquity?

17. Unless the LORD had been my help, My soul would soon have settled in silence.

18. If I say, "My foot slips," Your mercy, O LORD, will hold me up.

19. In the multitude of my anxieties within me, Your comforts delight my soul.

20. Shall the throne of iniquity, which devises evil by law, Have fellowship with You?

21. They gather together against the life of the righteous, And condemn innocent blood.

22. But the LORD has been my defense, And my God the rock of my refuge.

23. He has brought on them their own iniquity, And shall cut them off in their own wickedness; The LORD our God shall cut them off.

## Chapter 95

1. Oh come, let us sing to the LORD! Let us shout joyfully to the Rock of our salvation.

2. Let us come before His presence with thanksgiving; Let us shout joyfully to Him with psalms.

3. For the LORD is the great God, And the great King above all gods.

4. In His hand are the deep places of the earth; The heights of the hills are His also.

5. The sea is His, for He made it; And His hands formed the dry land.

6. Oh come, let us worship and bow down; Let us kneel before the LORD our Maker.

7. For He is our God, And we are the people of His pasture, And the sheep of His hand. Today, if you will hear His voice:

8. "Do not harden your hearts, as in the rebellion, As in the day of trial in the wilderness,

9. When your fathers tested Me; They tried Me, though they saw My work.

10. For forty years I was grieved with that generation, And said, "It is a people who go astray in their hearts, And they do not know My ways.'

11. So I swore in My wrath, "They shall not enter My rest.'|"

## Chapter 96

1. Oh, sing to the LORD a new song! Sing to the LORD, all the earth.

2. Sing to the LORD, bless His name; Proclaim the good news of His salvation from day to day.

3. Declare His glory among the nations, His wonders among all peoples.

4. For the LORD is great and greatly to be praised; He is to be feared above all gods.

5. For all the gods of the peoples are idols, But the LORD made the heavens.

6. Honor and majesty are before Him; Strength and beauty are in His sanctuary.

7. Give to the LORD, O families of the peoples, Give to the LORD glory and strength.

8. Give to the LORD the glory due His name; Bring an offering, and come into His courts.

9. Oh, worship the LORD in the beauty of holiness! Tremble before Him, all the earth.

10. Say among the nations, "The LORD reigns; The world also is firmly established, It shall not be moved; He shall judge the peoples righteously."

11. Let the heavens rejoice, and let the earth be glad; Let the sea roar, and all its fullness;

12. Let the field be joyful, and all that is in it. Then all the trees of the woods will rejoice before the LORD.

13. For He is coming, for He is coming to judge the earth. He shall judge the world with righteousness, And the peoples with His truth.

## Chapter 97

1. The LORD reigns; Let the earth rejoice; Let the multitude of isles be glad!

2. Clouds and darkness surround Him; Righteousness and justice are the foundation of His throne.

3. A fire goes before Him, And burns up His enemies round about.

4. His lightnings light the world; The earth sees and trembles.

5. The mountains melt like wax at the presence of the LORD, At the presence of the Lord of the whole earth.

6. The heavens declare His righteousness, And all the peoples see His glory.

7. Let all be put to shame who serve carved images, Who boast of idols. Worship Him, all you gods.

8. Zion hears and is glad, And the daughters of Judah rejoice Because of Your judgments, O LORD.

9. For You, LORD, are most high above all the earth; You are exalted far above all gods.

10. You who love the LORD, hate evil! He preserves the souls of His saints; He delivers them out of the hand of the wicked.

11. Light is sown for the righteous, And gladness for the upright in heart.

12. Rejoice in the LORD, you righteous, And give thanks at the remembrance of His holy name.

## Chapter 98

1. Oh, sing to the LORD a new song! For He has done marvelous things; His right hand and His holy arm have gained Him the victory.

2. The LORD has made known His salvation; His righteousness He has revealed in the sight of the nations.

3. He has remembered His mercy and His faithfulness to the house of Israel; All the ends of the earth have seen the salvation of our God.

4. Shout joyfully to the LORD, all the earth; Break forth in song, rejoice, and sing praises.

5. Sing to the LORD with the harp, With the harp and the sound of a psalm,

6. With trumpets and the sound of a horn; Shout joyfully before the LORD, the King.

7. Let the sea roar, and all its fullness, The world and those who dwell in it;

8. Let the rivers clap their hands; Let the hills be joyful together before the LORD,

9. For He is coming to judge the earth. With righteousness He shall judge the world, And the peoples with equity.

## Chapter 99

1. The LORD reigns; Let the peoples tremble! He dwells between the cherubim; Let the earth be moved!

2. The LORD is great in Zion, And He is high above all the peoples.

3. Let them praise Your great and awesome name-- He is holy.

4. The King's strength also loves justice; You have established equity; You have executed justice and righteousness in Jacob.

5. Exalt the LORD our God, And worship at His footstool-- He is holy.

6. Moses and Aaron were among His priests, And Samuel was among those who called upon His name; They called upon the LORD, and He answered them.

7. He spoke to them in the cloudy pillar; They kept His testimonies and the ordinance He gave them.

8. You answered them, O LORD our God; You were to them God-Who-Forgives, Though You took vengeance on their deeds.

9. Exalt the LORD our God, And worship at His holy hill; For the LORD our God is holy.

## Chapter 100

1. Make a joyful shout to the LORD, all you lands!

2. Serve the LORD with gladness; Come before His presence with singing.

3. Know that the LORD, He is God; It is He who has made us, and not we ourselves; We are His people and the sheep of His pasture.

4. Enter into His gates with thanksgiving, And into His courts with praise. Be thankful to Him, and bless His name.

5. For the LORD is good; His mercy is everlasting, And His truth endures to all generations.

## Chapter 101

1. I will sing of mercy and justice; To You, O LORD, I will sing praises.

2. I will behave wisely in a perfect way. Oh, when will You come to me? I will walk within my house with a perfect heart.

3. I will set nothing wicked before my eyes; I hate the work of those who fall away; It shall not cling to me.

4. A perverse heart shall depart from me; I will not know wickedness.

5. Whoever secretly slanders his neighbor, Him I will destroy; The one who has a haughty look and a proud heart, Him I will not endure.

6. My eyes shall be on the faithful of the land, That they may dwell with me; He who walks in a perfect way, He shall serve me.

7. He who works deceit shall not dwell within my house; He who tells lies shall not continue in my presence.

8. Early I will destroy all the wicked of the land, That I may cut off all the evildoers from the city of the LORD.

## Chapter 102

1. Hear my prayer, O LORD, And let my cry come to You.

2. Do not hide Your face from me in the day of my trouble; Incline Your ear to me; In the day that I call, answer me speedily.

3. For my days are consumed like smoke, And my bones are burned like a hearth.

4. My heart is stricken and withered like grass, So that I forget to eat my bread.

5. Because of the sound of my groaning My bones cling to my skin.

6. I am like a pelican of the wilderness; I am like an owl of the desert.

7. I lie awake, And am like a sparrow alone on the housetop.

8. My enemies reproach me all day long; Those who deride me swear an oath against me.

9. For I have eaten ashes like bread, And mingled my drink with weeping,

10. Because of Your indignation and Your wrath; For You have lifted me up and cast me away.

11. My days are like a shadow that lengthens, And I wither away like grass.

12. But You, O LORD, shall endure forever, And the remembrance of Your name to all generations.

13. You will arise and have mercy on Zion; For the time to favor her, Yes, the set time, has come.

14. For Your servants take pleasure in her stones, And show favor to her dust.

15. So the nations shall fear the name of the LORD, And all the kings of the earth Your glory.

16. For the LORD shall build up Zion; He shall appear in His glory.

17. He shall regard the prayer of the destitute, And shall not despise their prayer.

18. This will be written for the generation to come, That a people yet to be created may praise the LORD.

19. For He looked down from the height of His sanctuary; From heaven the LORD viewed the earth,

20. To hear the groaning of the prisoner, To release those appointed to death,

21. To declare the name of the LORD in Zion, And His praise in Jerusalem,

22. When the peoples are gathered together, And the kingdoms, to serve the LORD.

23. He weakened my strength in the way; He shortened my days.

24. I said, "O my God, Do not take me away in the midst of my days; Your years are throughout all generations.

25. Of old You laid the foundation of the earth, And the heavens are the work of Your hands.

26. They will perish, but You will endure; Yes, they will all grow old like a garment; Like a cloak You will change them, And they will be changed.

27. But You are the same, And Your years will have no end.

28. The children of Your servants will continue, And their descendants will be established before You."

## Chapter 103

1. Bless the LORD, O my soul; And all that is within me, bless His holy name!

2. Bless the LORD, O my soul, And forget not all His benefits:

3. Who forgives all your iniquities, Who heals all your diseases,

4. Who redeems your life from destruction, Who crowns you with lovingkindness and tender mercies,

5. Who satisfies your mouth with good things, So that your youth is renewed like the eagle's.

6. The LORD executes righteousness And justice for all who are oppressed.

7. He made known His ways to Moses, His acts to the children of Israel.

8. The LORD is merciful and gracious, Slow to anger, and abounding in mercy.

9. He will not always strive with us, Nor will He keep His anger forever.

10. He has not dealt with us according to our sins, Nor punished us according to our iniquities.

11. For as the heavens are high above the earth, So great is His mercy toward those who fear Him;

12. As far as the east is from the west, So far has He removed our transgressions from us.

13. As a father pities his children, So the LORD pities those who fear Him.

14. For He knows our frame; He remembers that we are dust.

15. As for man, his days are like grass; As a flower of the field, so he flourishes.

16. For the wind passes over it, and it is gone, And its place remembers it no more.

17. But the mercy of the LORD is from everlasting to everlasting On those who fear Him, And His righteousness to children's children,

18. To such as keep His covenant, And to those who remember His commandments to do them.

19. The LORD has established His throne in heaven, And His kingdom rules over all.

20. Bless the LORD, you His angels, Who excel in strength, who do His word, Heeding the voice of His word.

21. Bless the LORD, all you His hosts, You ministers of His, who do His pleasure.

22. Bless the LORD, all His works, In all places of His dominion. Bless the LORD, O my soul!

## Chapter 104

1. Bless the LORD, O my soul! O LORD my God, You are very great: You are clothed with honor and majesty,

2. Who cover Yourself with light as with a garment, Who stretch out the heavens like a curtain.

3. He lays the beams of His upper chambers in the waters, Who makes the clouds His chariot, Who walks on the wings of the wind,

4. Who makes His angels spirits, His ministers a flame of fire.

5. You who laid the foundations of the earth, So that it should not be moved forever,

6. You covered it with the deep as with a garment; The waters stood above the mountains.

7. At Your rebuke they fled; At the voice of Your thunder they hastened away.

8. They went up over the mountains; They went down into the valleys, To the place which You founded for them.

9. You have set a boundary that they may not pass over, That they may not return to cover the earth.

10. He sends the springs into the valleys; They flow among the hills.

11. They give drink to every beast of the field; The wild donkeys quench their thirst.

12. By them the birds of the heavens have their home; They sing among the branches.

13. He waters the hills from His upper chambers; The earth is satisfied with the fruit of Your works.

14. He causes the grass to grow for the cattle, And vegetation for the service of man, That he may bring forth food from the earth,

15. And wine that makes glad the heart of man, Oil to make his face shine, And bread which strengthens man's heart.

16. The trees of the LORD are full of sap, The cedars of Lebanon which He planted,

17. Where the birds make their nests; The stork has her home in the fir trees.

18. The high hills are for the wild goats; The cliffs are a refuge for the rock badgers.

19. He appointed the moon for seasons; The sun knows its going down.

20. You make darkness, and it is night, In which all the beasts of the forest creep about.

21. The young lions roar after their prey, And seek their food from God.

22. When the sun rises, they gather together And lie down in their dens.

23. Man goes out to his work And to his labor until the evening.

24. O LORD, how manifold are Your works! In wisdom You have made them all. The earth is full of Your possessions--

25. This great and wide sea, In which are innumerable teeming things, Living things both small and great.

26. There the ships sail about; There is that Leviathan Which You have made to play there.

27. These all wait for You, That You may give them their food in due season.

28. What You give them they gather in; You open Your hand, they are filled with good.

29. You hide Your face, they are troubled; You take away their breath, they die and return to their dust.

30. You send forth Your Spirit, they are created; And You renew the face of the earth.

31. May the glory of the LORD endure forever; May the LORD rejoice in His works.

32. He looks on the earth, and it trembles; He touches the hills, and they smoke.

33. I will sing to the LORD as long as I live; I will sing praise to my God while I have my being.

34. May my meditation be sweet to Him; I will be glad in the LORD.

35. May sinners be consumed from the earth, And the wicked be no more. Bless the LORD, O my soul! Praise the LORD!

## Chapter 105

1. Oh, give thanks to the LORD! Call upon His name; Make known His deeds among the peoples!

2. Sing to Him, sing psalms to Him; Talk of all His wondrous works!

3. Glory in His holy name; Let the hearts of those rejoice who seek the LORD!

4. Seek the LORD and His strength; Seek His face evermore!

5. Remember His marvelous works which He has done, His wonders, and the judgments of His mouth,

6. O seed of Abraham His servant, You children of Jacob, His chosen ones!

7. He is the LORD our God; His judgments are in all the earth.

8. He remembers His covenant forever, The word which He commanded, for a thousand generations,

9. The covenant which He made with Abraham, And His oath to Isaac,

10. And confirmed it to Jacob for a statute, To Israel as an everlasting covenant,

11. Saying, "To you I will give the land of Canaan As the allotment of your inheritance,"

12. When they were few in number, Indeed very few, and strangers in it.

13. When they went from one nation to another, From one kingdom to another people,

14. He permitted no one to do them wrong; Yes, He rebuked kings for their sakes,

15. Saying, "Do not touch My anointed ones, And do My prophets no harm."

16. Moreover He called for a famine in the land; He destroyed all the provision of bread.

17. He sent a man before them-- Joseph--who was sold as a slave.

18. They hurt his feet with fetters, He was laid in irons.

19. Until the time that his word came to pass, The word of the LORD tested him.

20. The king sent and released him, The ruler of the people let him go free.

21. He made him lord of his house, And ruler of all his possessions,

22. To bind his princes at his pleasure, And teach his elders wisdom.

23. Israel also came into Egypt, And Jacob dwelt in the land of Ham.

24. He increased His people greatly, And made them stronger than their enemies.

25. He turned their heart to hate His people, To deal craftily with His servants.

26. He sent Moses His servant, And Aaron whom He had chosen.

27. They performed His signs among them, And wonders in the land of Ham.

28. He sent darkness, and made it dark; And they did not rebel against His word.

29. He turned their waters into blood, And killed their fish.

30. Their land abounded with frogs, Even in the chambers of their kings.

31. He spoke, and there came swarms of flies, And lice in all their territory.

32. He gave them hail for rain, And flaming fire in their land.

33. He struck their vines also, and their fig trees, And splintered the trees of their territory.

34. He spoke, and locusts came, Young locusts without number,

35. And ate up all the vegetation in their land, And devoured the fruit of their ground.

36. He also destroyed all the firstborn in their land, The first of all their strength.

37. He also brought them out with silver and gold, And there was none feeble among His tribes.

38. Egypt was glad when they departed, For the fear of them had fallen upon them.

39. He spread a cloud for a covering, And fire to give light in the night.

40. The people asked, and He brought quail, And satisfied them with the bread of heaven.

41. He opened the rock, and water gushed out; It ran in the dry places like a river.

42. For He remembered His holy promise, And Abraham His servant.

43. He brought out His people with joy, His chosen ones with gladness.

44. He gave them the lands of the Gentiles, And they inherited the labor of the nations,

45. That they might observe His statutes And keep His laws. Praise the LORD!

## Chapter 106

1. Praise the LORD! Oh, give thanks to the LORD, for He is good! For His mercy endures forever.

2. Who can utter the mighty acts of the LORD? Who can declare all His praise?

3. Blessed are those who keep justice, And he who does righteousness at all times!

4. Remember me, O LORD, with the favor You have toward Your people. Oh, visit me with Your salvation,

5. That I may see the benefit of Your chosen ones, That I may rejoice in the gladness of Your nation, That I may glory with Your inheritance.

6. We have sinned with our fathers, We have committed iniquity, We have done wickedly.

7. Our fathers in Egypt did not understand Your wonders; They did not remember the multitude of Your mercies, But rebelled by the sea--the Red Sea.

8. Nevertheless He saved them for His name's sake, That He might make His mighty power known.

9. He rebuked the Red Sea also, and it dried up; So He led them through the depths, As through the wilderness.

10. He saved them from the hand of him who hated them, And redeemed them from the hand of the enemy.

11. The waters covered their enemies; There was not one of them left.

12. Then they believed His words; They sang His praise.

13. They soon forgot His works; They did not wait for His counsel,

14. But lusted exceedingly in the wilderness, And tested God in the desert.

15. And He gave them their request, But sent leanness into their soul.

16. When they envied Moses in the camp, And Aaron the saint of the LORD,

17. The earth opened up and swallowed Dathan, And covered the faction of Abiram.

18. A fire was kindled in their company; The flame burned up the wicked.

19. They made a calf in Horeb, And worshiped the molded image.

20. Thus they changed their glory Into the image of an ox that eats grass.

21. They forgot God their Savior, Who had done great things in Egypt,

22. Wondrous works in the land of Ham, Awesome things by the Red Sea.

23. Therefore He said that He would destroy them, Had not Moses His chosen one stood before Him in the breach, To turn away His wrath, lest He destroy them.

24. Then they despised the pleasant land; They did not believe His word,

25. But complained in their tents, And did not heed the voice of the LORD.

26. Therefore He raised His hand in an oath against them, To overthrow them in the wilderness,

27. To overthrow their descendants among the nations, And to scatter them in the lands.

28. They joined themselves also to Baal of Peor, And ate sacrifices made to the dead.

29. Thus they provoked Him to anger with their deeds, And the plague broke out among them.

30. Then Phinehas stood up and intervened, And the plague was stopped.

31. And that was accounted to him for righteousness To all generations forevermore.

32. They angered Him also at the waters of strife, So that it went ill with Moses on account of them;

33. Because they rebelled against His Spirit, So that he spoke rashly with his lips.

34. They did not destroy the peoples, Concerning whom the LORD had commanded them,

35. But they mingled with the Gentiles And learned their works;

36. They served their idols, Which became a snare to them.

37. They even sacrificed their sons And their daughters to demons,

38. And shed innocent blood, The blood of their sons and daughters, Whom they sacrificed to the idols of Canaan; And the land was polluted with blood.

39. Thus they were defiled by their own works, And played the harlot by their own deeds.

40. Therefore the wrath of the LORD was kindled against His people, So that He abhorred His own inheritance.

41. And He gave them into the hand of the Gentiles, And those who hated them ruled over them.

42. Their enemies also oppressed them, And they were brought into subjection under their hand.

43. Many times He delivered them; But they rebelled in their counsel, And were brought low for their iniquity.

44. Nevertheless He regarded their affliction, When He heard their cry;

45. And for their sake He remembered His covenant, And relented according to the multitude of His mercies.

46. He also made them to be pitied By all those who carried them away captive.

47. Save us, O LORD our God, And gather us from among the Gentiles, To give thanks to Your holy name, To triumph in Your praise.

48. Blessed be the LORD God of Israel From everlasting to everlasting! And let all the people say, "Amen!" Praise the LORD!

## Chapter 107

1. Oh, give thanks to the LORD, for He is good! For His mercy endures forever.

2. Let the redeemed of the LORD say so, Whom He has redeemed from the hand of the enemy,

3. And gathered out of the lands, From the east and from the west, From the north and from the south.

4. They wandered in the wilderness in a desolate way; They found no city to dwell in.

5. Hungry and thirsty, Their soul fainted in them.

6. Then they cried out to the LORD in their trouble, And He delivered them out of their distresses.

7. And He led them forth by the right way, That they might go to a city for a dwelling place.

8. Oh, that men would give thanks to the LORD for His goodness, And for His wonderful works to the children of men!

9. For He satisfies the longing soul, And fills the hungry soul with goodness.

10. Those who sat in darkness and in the shadow of death, Bound in affliction and irons--

11. Because they rebelled against the words of God, And despised the counsel of the Most High,

12. Therefore He brought down their heart with labor; They fell down, and there was none to help.

13. Then they cried out to the LORD in their trouble, And He saved them out of their distresses.

14. He brought them out of darkness and the shadow of death, And broke their chains in pieces.

15. Oh, that men would give thanks to the LORD for His goodness, And for His wonderful works to the children of men!

16. For He has broken the gates of bronze, And cut the bars of iron in two.

17. Fools, because of their transgression, And because of their iniquities, were afflicted.

18. Their soul abhorred all manner of food, And they drew near to the gates of death.

19. Then they cried out to the LORD in their trouble, And He saved them out of their distresses.

20. He sent His word and healed them, And delivered them from their destructions.

21. Oh, that men would give thanks to the LORD for His goodness, And for His wonderful works to the children of men!

22. Let them sacrifice the sacrifices of thanksgiving, And declare His works with rejoicing.

23. Those who go down to the sea in ships, Who do business on great waters,

24. They see the works of the LORD, And His wonders in the deep.

25. For He commands and raises the stormy wind, Which lifts up the waves of the sea.

26. They mount up to the heavens, They go down again to the depths; Their soul melts because of trouble.

27. They reel to and fro, and stagger like a drunken man, And are at their wits' end.

28. Then they cry out to the LORD in their trouble, And He brings them out of their distresses.

29. He calms the storm, So that its waves are still.

30. Then they are glad because they are quiet; So He guides them to their desired haven.

31. Oh, that men would give thanks to the LORD for His goodness, And for His wonderful works to the children of men!

32. Let them exalt Him also in the assembly of the people, And praise Him in the company of the elders.

33. He turns rivers into a wilderness, And the watersprings into dry ground;

34. A fruitful land into barrenness, For the wickedness of those who dwell in it.

35. He turns a wilderness into pools of water, And dry land into watersprings.

36. There He makes the hungry dwell, That they may establish a city for a dwelling place,

37. And sow fields and plant vineyards, That they may yield a fruitful harvest.

38. He also blesses them, and they multiply greatly; And He does not let their cattle decrease.

39. When they are diminished and brought low Through oppression, affliction and sorrow,

40. He pours contempt on princes, And causes them to wander in the wilderness where there is no way;

41. Yet He sets the poor on high, far from affliction, And makes their families like a flock.

42. The righteous see it and rejoice, And all iniquity stops its mouth.

43. Whoever is wise will observe these things, And they will understand the lovingkindness of the LORD.

## Chapter 108

1. O God, my heart is steadfast; I will sing and give praise, even with my glory.

2. Awake, lute and harp! I will awaken the dawn.

3. I will praise You, O LORD, among the peoples, And I will sing praises to You among the nations.

4. For Your mercy is great above the heavens, And Your truth reaches to the clouds.

5. Be exalted, O God, above the heavens, And Your glory above all the earth;

6. That Your beloved may be delivered, Save with Your right hand, and hear me.

7. God has spoken in His holiness: "I will rejoice; I will divide Shechem And measure out the Valley of Succoth.

8. Gilead is Mine; Manasseh is Mine; Ephraim also is the helmet for My head; Judah is My lawgiver.

9. Moab is My washpot; Over Edom I will cast My shoe; Over Philistia I will triumph."

10. Who will bring me into the strong city? Who will lead me to Edom?

11. Is it not You, O God, who cast us off? And You, O God, who did not go out with our armies?

12. Give us help from trouble, For the help of man is useless.

13. Through God we will do valiantly, For it is He who shall tread down our enemies.

## Chapter 109

1. Do not keep silent, O God of my praise!

2. For the mouth of the wicked and the mouth of the deceitful Have opened against me; They have spoken against me with a lying tongue.

3. They have also surrounded me with words of hatred, And fought against me without a cause.

4. In return for my love they are my accusers, But I give myself to prayer.

5. Thus they have rewarded me evil for good, And hatred for my love.

6. Set a wicked man over him, And let an accuser stand at his right hand.

7. When he is judged, let him be found guilty, And let his prayer become sin.

8. Let his days be few, And let another take his office.

9. Let his children be fatherless, And his wife a widow.

10. Let his children continually be vagabonds, and beg; Let them seek their bread also from their desolate places.

11. Let the creditor seize all that he has, And let strangers plunder his labor.

12. Let there be none to extend mercy to him, Nor let there be any to favor his fatherless children.

13. Let his posterity be cut off, And in the generation following let their name be blotted out.

14. Let the iniquity of his fathers be remembered before the LORD, And let not the sin of his mother be blotted out.

15. Let them be continually before the LORD, That He may cut off the memory of them from the earth;

16. Because he did not remember to show mercy, But persecuted the poor and needy man, That he might even slay the broken in heart.

17. As he loved cursing, so let it come to him; As he did not delight in blessing, so let it be far from him.

18. As he clothed himself with cursing as with his garment, So let it enter his body like water, And like oil into his bones.

19. Let it be to him like the garment which covers him, And for a belt with which he girds himself continually.

20. Let this be the LORD's reward to my accusers, And to those who speak evil against my person.

21. But You, O GOD the Lord, Deal with me for Your name's sake; Because Your mercy is good, deliver me.

22. For I am poor and needy, And my heart is wounded within me.

23. I am gone like a shadow when it lengthens; I am shaken off like a locust.

24. My knees are weak through fasting, And my flesh is feeble from lack of fatness.

25. I also have become a reproach to them; When they look at me, they shake their heads.

26. Help me, O LORD my God! Oh, save me according to Your mercy,

27. That they may know that this is Your hand-- That You, LORD, have done it!

28. Let them curse, but You bless; When they arise, let them be ashamed, But let Your servant rejoice.

29. Let my accusers be clothed with shame, And let them cover themselves with their own disgrace as with a mantle.

30. I will greatly praise the LORD with my mouth; Yes, I will praise Him among the multitude.

31. For He shall stand at the right hand of the poor, To save him from those who condemn him.

## Chapter 110

1. The LORD said to my Lord, "Sit at My right hand, Till I make Your enemies Your footstool."

2. The LORD shall send the rod of Your strength out of Zion. Rule in the midst of Your enemies!

3. Your people shall be volunteers In the day of Your power; In the beauties of holiness, from the womb of the morning, You have the dew of Your youth.

4. The LORD has sworn And will not relent, "You are a priest forever According to the order of Melchizedek."

5. The Lord is at Your right hand; He shall execute kings in the day of His wrath.

6. He shall judge among the nations, He shall fill the places with dead bodies, He shall execute the heads of many countries.

7. He shall drink of the brook by the wayside; Therefore He shall lift up the head.

## Chapter 111

1. Praise the LORD! I will praise the LORD with my whole heart, In the assembly of the upright and in the congregation.

2. The works of the LORD are great, Studied by all who have pleasure in them.

3. His work is honorable and glorious, And His righteousness endures forever.

4. He has made His wonderful works to be remembered; The LORD is gracious and full of compassion.

5. He has given food to those who fear Him; He will ever be mindful of His covenant.

6. He has declared to His people the power of His works, In giving them the heritage of the nations.

7. The works of His hands are verity and justice; All His precepts are sure.

8. They stand fast forever and ever, And are done in truth and uprightness.

9. He has sent redemption to His people; He has commanded His covenant forever: Holy and awesome is His name.

10. The fear of the LORD is the beginning of wisdom; A good understanding have all those who do His commandments. His praise endures forever.

## Chapter 112

1. Praise the LORD! Blessed is the man who fears the LORD, Who delights greatly in His commandments.

2. His descendants will be mighty on earth; The generation of the upright will be blessed.

3. Wealth and riches will be in his house, And his righteousness endures forever.

4. Unto the upright there arises light in the darkness; He is gracious, and full of compassion, and righteous.

5. A good man deals graciously and lends; He will guide his affairs with discretion.

6. Surely he will never be shaken; The righteous will be in everlasting remembrance.

7. He will not be afraid of evil tidings; His heart is steadfast, trusting in the LORD.

8. His heart is established; He will not be afraid, Until he sees his desire upon his enemies.

9. He has dispersed abroad, He has given to the poor; His righteousness endures forever; His horn will be exalted with honor.

10. The wicked will see it and be grieved; He will gnash his teeth and melt away; The desire of the wicked shall perish.

## Chapter 113

1. Praise the LORD! Praise, O servants of the LORD, Praise the name of the LORD!

2. Blessed be the name of the LORD From this time forth and forevermore!

3. From the rising of the sun to its going down The LORD's name is to be praised.

4. The LORD is high above all nations, His glory above the heavens.

5. Who is like the LORD our God, Who dwells on high,

6. Who humbles Himself to behold The things that are in the heavens and in the earth?

7. He raises the poor out of the dust, And lifts the needy out of the ash heap,

8. That He may seat him with princes-- With the princes of His people.

9. He grants the barren woman a home, Like a joyful mother of children. Praise the LORD!

## Chapter 114

1. When Israel went out of Egypt, The house of Jacob from a people of strange language,

2. Judah became His sanctuary, And Israel His dominion.

3. The sea saw it and fled; Jordan turned back.

4. The mountains skipped like rams, The little hills like lambs.

5. What ails you, O sea, that you fled? O Jordan, that you turned back?

6. O mountains, that you skipped like rams? O little hills, like lambs?

7. Tremble, O earth, at the presence of the Lord, At the presence of the God of Jacob,

8. Who turned the rock into a pool of water, The flint into a fountain of waters.

## Chapter 115

1. Not unto us, O LORD, not unto us, But to Your name give glory, Because of Your mercy, Because of Your truth.

2. Why should the Gentiles say, "So where is their God?"

3. But our God is in heaven; He does whatever He pleases.

4. Their idols are silver and gold, The work of men's hands.

5. They have mouths, but they do not speak; Eyes they have, but they do not see;

6. They have ears, but they do not hear; Noses they have, but they do not smell;

7. They have hands, but they do not handle; Feet they have, but they do not walk; Nor do they mutter through their throat.

8. Those who make them are like them; So is everyone who trusts in them.

9. O Israel, trust in the LORD; He is their help and their shield.

10. O house of Aaron, trust in the LORD; He is their help and their shield.

11. You who fear the LORD, trust in the LORD; He is their help and their shield.

12. The LORD has been mindful of us; He will bless us; He will bless the house of Israel; He will bless the house of Aaron.

13. He will bless those who fear the LORD, Both small and great.

14. May the LORD give you increase more and more, You and your children.

15. May you be blessed by the LORD, Who made heaven and earth.

16. The heaven, even the heavens, are the LORD's; But the earth He has given to the children of men.

17. The dead do not praise the LORD, Nor any who go down into silence.

18. But we will bless the LORD From this time forth and forevermore. Praise the LORD!

## Chapter 116

1. I love the LORD, because He has heard My voice and my supplications.

2. Because He has inclined His ear to me, Therefore I will call upon Him as long as I live.

3. The pains of death surrounded me, And the pangs of Sheol laid hold of me; I found trouble and sorrow.

4. Then I called upon the name of the LORD: "O LORD, I implore You, deliver my soul!"

5. Gracious is the LORD, and righteous; Yes, our God is merciful.

6. The LORD preserves the simple; I was brought low, and He saved me.

7. Return to your rest, O my soul, For the LORD has dealt bountifully with you.

8. For You have delivered my soul from death, My eyes from tears, And my feet from falling.

9. I will walk before the LORD In the land of the living.

10. I believed, therefore I spoke, "I am greatly afflicted."

11. I said in my haste, "All men are liars."

12. What shall I render to the LORD For all His benefits toward me?

13. I will take up the cup of salvation, And call upon the name of the LORD.

14. I will pay my vows to the LORD Now in the presence of all His people.

15. Precious in the sight of the LORD Is the death of His saints.

16. O LORD, truly I am Your servant; I am Your servant, the son of Your maidservant; You have loosed my bonds.

17. I will offer to You the sacrifice of thanksgiving, And will call upon the name of the LORD.

18. I will pay my vows to the LORD Now in the presence of all His people,

19. In the courts of the LORD's house, In the midst of you, O Jerusalem. Praise the LORD!

## Chapter 117

1. Praise the LORD, all you Gentiles! Laud Him, all you peoples!

2. For His merciful kindness is great toward us, And the truth of the LORD endures forever. Praise the LORD!

## Chapter 118

1. Oh, give thanks to the LORD, for He is good! For His mercy endures forever.

2. Let Israel now say, "His mercy endures forever."

3. Let the house of Aaron now say, "His mercy endures forever."

4. Let those who fear the LORD now say, "His mercy endures forever."

5. I called on the LORD in distress; The LORD answered me and set me in a broad place.

6. The LORD is on my side; I will not fear. What can man do to me?

7. The LORD is for me among those who help me; Therefore I shall see my desire on those who hate me.

8. It is better to trust in the LORD Than to put confidence in man.

9. It is better to trust in the LORD Than to put confidence in princes.

10. All nations surrounded me, But in the name of the LORD I will destroy them.

11. They surrounded me, Yes, they surrounded me; But in the name of the LORD I will destroy them.

12. They surrounded me like bees; They were quenched like a fire of thorns; For in the name of the LORD I will destroy them.

13. You pushed me violently, that I might fall, But the LORD helped me.

14. The LORD is my strength and song, And He has become my salvation.

15. The voice of rejoicing and salvation Is in the tents of the righteous; The right hand of the LORD does valiantly.

16. The right hand of the LORD is exalted; The right hand of the LORD does valiantly.

17. I shall not die, but live, And declare the works of the LORD.

18. The LORD has chastened me severely, But He has not given me over to death.

19. Open to me the gates of righteousness; I will go through them, And I will praise the LORD.

20. This is the gate of the LORD, Through which the righteous shall enter.

21. I will praise You, For You have answered me, And have become my salvation.

22. The stone which the builders rejected Has become the chief cornerstone.

23. This was the LORD's doing; It is marvelous in our eyes.

24. This is the day the LORD has made; We will rejoice and be glad in it.

25. Save now, I pray, O LORD; O LORD, I pray, send now prosperity.

26. Blessed is he who comes in the name of the LORD! We have blessed you from the house of the LORD.

27. God is the LORD, And He has given us light; Bind the sacrifice with cords to the horns of the altar.

28. You are my God, and I will praise You; You are my God, I will exalt You.

29. Oh, give thanks to the LORD, for He is good! For His mercy endures forever.

## Chapter 119

1. Blessed are the undefiled in the way, Who walk in the law of the LORD!

2. Blessed are those who keep His testimonies, Who seek Him with the whole heart!

3. They also do no iniquity; They walk in His ways.

4. You have commanded us To keep Your precepts diligently.

5. Oh, that my ways were directed To keep Your statutes!

6. Then I would not be ashamed, When I look into all Your commandments.

7. I will praise You with uprightness of heart, When I learn Your righteous judgments.

8. I will keep Your statutes; Oh, do not forsake me utterly!

9. How can a young man cleanse his way? By taking heed according to Your word.

10. With my whole heart I have sought You; Oh, let me not wander from Your commandments!

11. Your word I have hidden in my heart, That I might not sin against You.

12. Blessed are You, O LORD! Teach me Your statutes.

13. With my lips I have declared All the judgments of Your mouth.

14. I have rejoiced in the way of Your testimonies, As much as in all riches.

15. I will meditate on Your precepts, And contemplate Your ways.

16. I will delight myself in Your statutes; I will not forget Your word.

17. Deal bountifully with Your servant, That I may live and keep Your word.

18. Open my eyes, that I may see Wondrous things from Your law.

19. I am a stranger in the earth; Do not hide Your commandments from me.

20. My soul breaks with longing For Your judgments at all times.

21. You rebuke the proud--the cursed, Who stray from Your commandments.

22. Remove from me reproach and contempt, For I have kept Your testimonies.

23. Princes also sit and speak against me, But Your servant meditates on Your statutes.

24. Your testimonies also are my delight And my counselors.

25. My soul clings to the dust; Revive me according to Your word.

26. I have declared my ways, and You answered me; Teach me Your statutes.

27. Make me understand the way of Your precepts; So shall I meditate on Your wonderful works.

28. My soul melts from heaviness; Strengthen me according to Your word.

29. Remove from me the way of lying, And grant me Your law graciously.

30. I have chosen the way of truth; Your judgments I have laid before me.

31. I cling to Your testimonies; O LORD, do not put me to shame!

32. I will run the course of Your commandments, For You shall enlarge my heart.

33. Teach me, O LORD, the way of Your statutes, And I shall keep it to the end.

34. Give me understanding, and I shall keep Your law; Indeed, I shall observe it with my whole heart.

35. Make me walk in the path of Your commandments, For I delight in it.

36. Incline my heart to Your testimonies, And not to covetousness.

37. Turn away my eyes from looking at worthless things, And revive me in Your way.

38. Establish Your word to Your servant, Who is devoted to fearing You.

39. Turn away my reproach which I dread, For Your judgments are good.

40. Behold, I long for Your precepts; Revive me in Your righteousness.

41. Let Your mercies come also to me, O LORD-- Your salvation according to Your word.

42. So shall I have an answer for him who reproaches me, For I trust in Your word.

43. And take not the word of truth utterly out of my mouth, For I have hoped in Your ordinances.

44. So shall I keep Your law continually, Forever and ever.

45. And I will walk at liberty, For I seek Your precepts.

46. I will speak of Your testimonies also before kings, And will not be ashamed.

47. And I will delight myself in Your commandments, Which I love.

48. My hands also I will lift up to Your commandments, Which I love, And I will meditate on Your statutes.

49. Remember the word to Your servant, Upon which You have caused me to hope.

50. This is my comfort in my affliction, For Your word has given me life.

51. The proud have me in great derision, Yet I do not turn aside from Your law.

52. I remembered Your judgments of old, O LORD, And have comforted myself.

53. Indignation has taken hold of me Because of the wicked, who forsake Your law.

54. Your statutes have been my songs In the house of my pilgrimage.

55. I remember Your name in the night, O LORD, And I keep Your law.

56. This has become mine, Because I kept Your precepts.

57. You are my portion, O LORD; I have said that I would keep Your words.

58. I entreated Your favor with my whole heart; Be merciful to me according to Your word.

59. I thought about my ways, And turned my feet to Your testimonies.

60. I made haste, and did not delay To keep Your commandments.

61. The cords of the wicked have bound me, But I have not forgotten Your law.

62. At midnight I will rise to give thanks to You, Because of Your righteous judgments.

63. I am a companion of all who fear You, And of those who keep Your precepts.

64. The earth, O LORD, is full of Your mercy; Teach me Your statutes.

65. You have dealt well with Your servant, O LORD, according to Your word.

66. Teach me good judgment and knowledge, For I believe Your commandments.

67. Before I was afflicted I went astray, But now I keep Your word.

68. You are good, and do good; Teach me Your statutes.

69. The proud have forged a lie against me, But I will keep Your precepts with my whole heart.

70. Their heart is as fat as grease, But I delight in Your law.

71. It is good for me that I have been afflicted, That I may learn Your statutes.

72. The law of Your mouth is better to me Than thousands of coins of gold and silver.

73. Your hands have made me and fashioned me; Give me understanding, that I may learn Your commandments.

74. Those who fear You will be glad when they see me, Because I have hoped in Your word.

75. I know, O LORD, that Your judgments are right, And that in faithfulness You have afflicted me.

76. Let, I pray, Your merciful kindness be for my comfort, According to Your word to Your servant.

77. Let Your tender mercies come to me, that I may live; For Your law is my delight.

78. Let the proud be ashamed, For they treated me wrongfully with falsehood; But I will meditate on Your precepts.

79. Let those who fear You turn to me, Those who know Your testimonies.

80. Let my heart be blameless regarding Your statutes, That I may not be ashamed.

81. My soul faints for Your salvation, But I hope in Your word.

82. My eyes fail from searching Your word, Saying, "When will You comfort me?"

83. For I have become like a wineskin in smoke, Yet I do not forget Your statutes.

84. How many are the days of Your servant? When will You execute judgment on those who persecute me?

85. The proud have dug pits for me, Which is not according to Your law.

86. All Your commandments are faithful; They persecute me wrongfully; Help me!

87. They almost made an end of me on earth, But I did not forsake Your precepts.

88. Revive me according to Your lovingkindness, So that I may keep the testimony of Your mouth.

89. Forever, O LORD, Your word is settled in heaven.

90. Your faithfulness endures to all generations; You established the earth, and it abides.

91. They continue this day according to Your ordinances, For all are Your servants.

92. Unless Your law had been my delight, I would then have perished in my affliction.

93. I will never forget Your precepts, For by them You have given me life.

94. I am Yours, save me; For I have sought Your precepts.

95. The wicked wait for me to destroy me, But I will consider Your testimonies.

96. I have seen the consummation of all perfection, But Your commandment is exceedingly broad.

97. Oh, how I love Your law! It is my meditation all the day.

98. You, through Your commandments, make me wiser than my enemies; For they are ever with me.

99. I have more understanding than all my teachers, For Your testimonies are my meditation.

100. I understand more than the ancients, Because I keep Your precepts.

101. I have restrained my feet from every evil way, That I may keep Your word.

102. I have not departed from Your judgments, For You Yourself have taught me.

103. How sweet are Your words to my taste, Sweeter than honey to my mouth!

104. Through Your precepts I get understanding; Therefore I hate every false way.

105. Your word is a lamp to my feet And a light to my path.

106. I have sworn and confirmed That I will keep Your righteous judgments.

107. I am afflicted very much; Revive me, O LORD, according to Your word.

108. Accept, I pray, the freewill offerings of my mouth, O LORD, And teach me Your judgments.

109. My life is continually in my hand, Yet I do not forget Your law.

110. The wicked have laid a snare for me, Yet I have not strayed from Your precepts.

111. Your testimonies I have taken as a heritage forever, For they are the rejoicing of my heart.

112. I have inclined my heart to perform Your statutes Forever, to the very end.

113. I hate the double-minded, But I love Your law.

114. You are my hiding place and my shield; I hope in Your word.

115. Depart from me, you evildoers, For I will keep the commandments of my God!

116. Uphold me according to Your word, that I may live; And do not let me be ashamed of my hope.

117. Hold me up, and I shall be safe, And I shall observe Your statutes continually.

118. You reject all those who stray from Your statutes, For their deceit is falsehood.

119. You put away all the wicked of the earth like dross; Therefore I love Your testimonies.

120. My flesh trembles for fear of You, And I am afraid of Your judgments.

121. I have done justice and righteousness; Do not leave me to my oppressors.

122. Be surety for Your servant for good; Do not let the proud oppress me.

123. My eyes fail from seeking Your salvation And Your righteous word.

124. Deal with Your servant according to Your mercy, And teach me Your statutes.

125. I am Your servant; Give me understanding, That I may know Your testimonies.

126. It is time for You to act, O LORD, For they have regarded Your law as void.

127. Therefore I love Your commandments More than gold, yes, than fine gold!

128. Therefore all Your precepts concerning all things I consider to be right; I hate every false way.

129. Your testimonies are wonderful; Therefore my soul keeps them.

130. The entrance of Your words gives light; It gives understanding to the simple.

131. I opened my mouth and panted, For I longed for Your commandments.

132. Look upon me and be merciful to me, As Your custom is toward those who love Your name.

133. Direct my steps by Your word, And let no iniquity have dominion over me.

134. Redeem me from the oppression of man, That I may keep Your precepts.

135. Make Your face shine upon Your servant, And teach me Your statutes.

136. Rivers of water run down from my eyes, Because men do not keep Your law.

137. Righteous are You, O LORD, And upright are Your judgments.

138. Your testimonies, which You have commanded, Are righteous and very faithful.

139. My zeal has consumed me, Because my enemies have forgotten Your words.

140. Your word is very pure; Therefore Your servant loves it.

141. I am small and despised, Yet I do not forget Your precepts.

142. Your righteousness is an everlasting righteousness, And Your law is truth.

143. Trouble and anguish have overtaken me, Yet Your commandments are my delights.

144. The righteousness of Your testimonies is everlasting; Give me understanding, and I shall live.

145. I cry out with my whole heart; Hear me, O LORD! I will keep Your statutes.

146. I cry out to You; Save me, and I will keep Your testimonies.

147. I rise before the dawning of the morning, And cry for help; I hope in Your word.

148. My eyes are awake through the night watches, That I may meditate on Your word.

149. Hear my voice according to Your lovingkindness; O LORD, revive me according to Your justice.

150. They draw near who follow after wickedness; They are far from Your law.

151. You are near, O LORD, And all Your commandments are truth.

152. Concerning Your testimonies, I have known of old that You have founded them forever.

153. Consider my affliction and deliver me, For I do not forget Your law.

154. Plead my cause and redeem me; Revive me according to Your word.

155. Salvation is far from the wicked, For they do not seek Your statutes.

156. Great are Your tender mercies, O LORD; Revive me according to Your judgments.

157. Many are my persecutors and my enemies, Yet I do not turn from Your testimonies.

158. I see the treacherous, and am disgusted, Because they do not keep Your word.

159. Consider how I love Your precepts; Revive me, O LORD, according to Your lovingkindness.

160. The entirety of Your word is truth, And every one of Your righteous judgments endures forever.

161. Princes persecute me without a cause, But my heart stands in awe of Your word.

162. I rejoice at Your word As one who finds great treasure.

163. I hate and abhor lying, But I love Your law.

164. Seven times a day I praise You, Because of Your righteous judgments.

165. Great peace have those who love Your law, And nothing causes them to stumble.

166. LORD, I hope for Your salvation, And I do Your commandments.

167. My soul keeps Your testimonies, And I love them exceedingly.

168. I keep Your precepts and Your testimonies, For all my ways are before You.

169. Let my cry come before You, O LORD; Give me understanding according to Your word.

170. Let my supplication come before You; Deliver me according to Your word.

171. My lips shall utter praise, For You teach me Your statutes.

172. My tongue shall speak of Your word, For all Your commandments are righteousness.

173. Let Your hand become my help, For I have chosen Your precepts.

174. I long for Your salvation, O LORD, And Your law is my delight.

175. Let my soul live, and it shall praise You; And let Your judgments help me.

176. I have gone astray like a lost sheep; Seek Your servant, For I do not forget Your commandments.

## Chapter 120

1. In my distress I cried to the LORD, And He heard me.

2. Deliver my soul, O LORD, from lying lips And from a deceitful tongue.

3. What shall be given to you, Or what shall be done to you, You false tongue?

4. Sharp arrows of the warrior, With coals of the broom tree!

5. Woe is me, that I dwell in Meshech, That I dwell among the tents of Kedar!

6. My soul has dwelt too long With one who hates peace.

7. I am for peace; But when I speak, they are for war.

## Chapter 121

1. I will lift up my eyes to the hills-- From whence comes my help?

2. My help comes from the LORD, Who made heaven and earth.

3. He will not allow your foot to be moved; He who keeps you will not slumber.

4. Behold, He who keeps Israel Shall neither slumber nor sleep.

5. The LORD is your keeper; The LORD is your shade at your right hand.

6. The sun shall not strike you by day, Nor the moon by night.

7. The LORD shall preserve you from all evil; He shall preserve your soul.

8. The LORD shall preserve your going out and your coming in From this time forth, and even forevermore.

## Chapter 122

1. I was glad when they said to me, "Let us go into the house of the LORD."

2. Our feet have been standing Within your gates, O Jerusalem!

3. Jerusalem is built As a city that is compact together,

4. Where the tribes go up, The tribes of the LORD, To the Testimony of Israel, To give thanks to the name of the LORD.

5. For thrones are set there for judgment, The thrones of the house of David.

6. Pray for the peace of Jerusalem: "May they prosper who love you.

7. Peace be within your walls, Prosperity within your palaces."

8. For the sake of my brethren and companions, I will now say, "Peace be within you."

9. Because of the house of the LORD our God I will seek your good.

## Chapter 123

1. Unto You I lift up my eyes, O You who dwell in the heavens.

2. Behold, as the eyes of servants look to the hand of their masters, As the eyes of a maid to the hand of her mistress, So our eyes look to the LORD our God, Until He has mercy on us.

3. Have mercy on us, O LORD, have mercy on us! For we are exceedingly filled with contempt.

4. Our soul is exceedingly filled With the scorn of those who are at ease, With the contempt of the proud.

## Chapter 124

1. "If it had not been the LORD who was on our side," Let Israel now say--

2. "If it had not been the LORD who was on our side, When men rose up against us,

3. Then they would have swallowed us alive, When their wrath was kindled against us;

4. Then the waters would have overwhelmed us, The stream would have gone over our soul;

5. Then the swollen waters Would have gone over our soul."

6. Blessed be the LORD, Who has not given us as prey to their teeth.

7. Our soul has escaped as a bird from the snare of the fowlers; The snare is broken, and we have escaped.

8. Our help is in the name of the LORD, Who made heaven and earth.

## Chapter 125

1. Those who trust in the LORD Are like Mount Zion, Which cannot be moved, but abides forever.

2. As the mountains surround Jerusalem, So the LORD surrounds His people From this time forth and forever.

3. For the scepter of wickedness shall not rest On the land allotted to the righteous, Lest the righteous reach out their hands to iniquity.

4. Do good, O LORD, to those who are good, And to those who are upright in their hearts.

5. As for such as turn aside to their crooked ways, The LORD shall lead them away With the workers of iniquity. Peace be upon Israel!

## Chapter 126

1. When the LORD brought back the captivity of Zion, We were like those who dream.

2. Then our mouth was filled with laughter, And our tongue with singing. Then they said among the nations, "The LORD has done great things for them."

3. The LORD has done great things for us, And we are glad.

4. Bring back our captivity, O LORD, As the streams in the South.

5. Those who sow in tears Shall reap in joy.

6. He who continually goes forth weeping, Bearing seed for sowing, Shall doubtless come again with rejoicing, Bringing his sheaves with him.

## Chapter 127

1. Unless the LORD builds the house, They labor in vain who build it; Unless the LORD guards the city, The watchman stays awake in vain.

2. It is vain for you to rise up early, To sit up late, To eat the bread of sorrows; For so He gives His beloved sleep.

3. Behold, children are a heritage from the LORD, The fruit of the womb is a reward.

4. Like arrows in the hand of a warrior, So are the children of one's youth.

5. Happy is the man who has his quiver full of them; They shall not be ashamed, But shall speak with their enemies in the gate.

## Chapter 128

1. Blessed is every one who fears the LORD, Who walks in His ways.

2. When you eat the labor of your hands, You shall be happy, and it shall be well with you.

3. Your wife shall be like a fruitful vine In the very heart of your house, Your children like olive plants All around your table.

4. Behold, thus shall the man be blessed Who fears the LORD.

5. The LORD bless you out of Zion, And may you see the good of Jerusalem All the days of your life.

6. Yes, may you see your children's children. Peace be upon Israel!

## Chapter 129

1. "Many a time they have afflicted me from my youth," Let Israel now say--

2. "Many a time they have afflicted me from my youth; Yet they have not prevailed against me.

3. The plowers plowed on my back; They made their furrows long."

4. The LORD is righteous; He has cut in pieces the cords of the wicked.

5. Let all those who hate Zion Be put to shame and turned back.

6. Let them be as the grass on the housetops, Which withers before it grows up,

7. With which the reaper does not fill his hand, Nor he who binds sheaves, his arms.

8. Neither let those who pass by them say, "The blessing of the LORD be upon you; We bless you in the name of the LORD!"

## Chapter 130

1. Out of the depths I have cried to You, O LORD;

2. Lord, hear my voice! Let Your ears be attentive To the voice of my supplications.

3. If You, LORD, should mark iniquities, O Lord, who could stand?

4. But there is forgiveness with You, That You may be feared.

5. I wait for the LORD, my soul waits, And in His word I do hope.

6. My soul waits for the Lord More than those who watch for the morning-- Yes, more than those who watch for the morning.

7. O Israel, hope in the LORD; For with the LORD there is mercy, And with Him is abundant redemption.

8. And He shall redeem Israel From all his iniquities.

## Chapter 131

1. LORD, my heart is not haughty, Nor my eyes lofty. Neither do I concern myself with great matters, Nor with things too profound for me.

2. Surely I have calmed and quieted my soul, Like a weaned child with his mother; Like a weaned child is my soul within me.

3. O Israel, hope in the LORD From this time forth and forever.

## Chapter 132

1. LORD, remember David And all his afflictions;

2. How he swore to the LORD, And vowed to the Mighty One of Jacob:

3. "Surely I will not go into the chamber of my house, Or go up to the comfort of my bed;

4. I will not give sleep to my eyes Or slumber to my eyelids,

5. Until I find a place for the LORD, A dwelling place for the Mighty One of Jacob."

6. Behold, we heard of it in Ephrathah; We found it in the fields of the woods.

7. Let us go into His tabernacle; Let us worship at His footstool.

8. Arise, O LORD, to Your resting place, You and the ark of Your strength.

9. Let Your priests be clothed with righteousness, And let Your saints shout for joy.

10. For Your servant David's sake, Do not turn away the face of Your Anointed.

11. The LORD has sworn in truth to David; He will not turn from it: "I will set upon your throne the fruit of your body.

12. If your sons will keep My covenant And My testimony which I shall teach them, Their sons also shall sit upon your throne forevermore."

13. For the LORD has chosen Zion; He has desired it for His dwelling place:

14. "This is My resting place forever; Here I will dwell, for I have desired it.

15. I will abundantly bless her provision; I will satisfy her poor with bread.

16. I will also clothe her priests with salvation, And her saints shall shout aloud for joy.

17. There I will make the horn of David grow; I will prepare a lamp for My Anointed.

18. His enemies I will clothe with shame, But upon Himself His crown shall flourish."

## Chapter 133

1. Behold, how good and how pleasant it is For brethren to dwell together in unity!

2. It is like the precious oil upon the head, Running down on the beard, The beard of Aaron, Running down on the edge of his garments.

3. It is like the dew of Hermon, Descending upon the mountains of Zion; For there the LORD commanded the blessing-- Life forevermore.

## Chapter 134

1. Behold, bless the LORD, All you servants of the LORD, Who by night stand in the house of the LORD!

2. Lift up your hands in the sanctuary, And bless the LORD.

3. The LORD who made heaven and earth Bless you from Zion!

## Chapter 135

1. Praise the LORD! Praise the name of the LORD; Praise Him, O you servants of the LORD!

2. You who stand in the house of the LORD, In the courts of the house of our God,

3. Praise the LORD, for the LORD is good; Sing praises to His name, for it is pleasant.

4. For the LORD has chosen Jacob for Himself, Israel for His special treasure.

5. For I know that the LORD is great, And our Lord is above all gods.

6. Whatever the LORD pleases He does, In heaven and in earth, In the seas and in all deep places.

7. He causes the vapors to ascend from the ends of the earth; He makes lightning for the rain; He brings the wind out of His treasuries.

8. He destroyed the firstborn of Egypt, Both of man and beast.

9. He sent signs and wonders into the midst of you, O Egypt, Upon Pharaoh and all his servants.

10. He defeated many nations And slew mighty kings--

11. Sihon king of the Amorites, Og king of Bashan, And all the kingdoms of Canaan--

12. And gave their land as a heritage, A heritage to Israel His people.

13. Your name, O LORD, endures forever, Your fame, O LORD, throughout all generations.

14. For the LORD will judge His people, And He will have compassion on His servants.

15. The idols of the nations are silver and gold, The work of men's hands.

16. They have mouths, but they do not speak; Eyes they have, but they do not see;

17. They have ears, but they do not hear; Nor is there any breath in their mouths.

18. Those who make them are like them; So is everyone who trusts in them.

19. Bless the LORD, O house of Israel! Bless the LORD, O house of Aaron!

20. Bless the LORD, O house of Levi! You who fear the LORD, bless the LORD!

21. Blessed be the LORD out of Zion, Who dwells in Jerusalem! Praise the LORD!

## Chapter 136

1. Oh, give thanks to the LORD, for He is good! For His mercy endures forever.

2. Oh, give thanks to the God of gods! For His mercy endures forever.

3. Oh, give thanks to the Lord of lords! For His mercy endures forever:

4. To Him who alone does great wonders, For His mercy endures forever;

5. To Him who by wisdom made the heavens, For His mercy endures forever;

6. To Him who laid out the earth above the waters, For His mercy endures forever;

7. To Him who made great lights, For His mercy endures forever--

8. The sun to rule by day, For His mercy endures forever;

9. The moon and stars to rule by night, For His mercy endures forever.

10. To Him who struck Egypt in their firstborn, For His mercy endures forever;

11. And brought out Israel from among them, For His mercy endures forever;

12. With a strong hand, and with an outstretched arm, For His mercy endures forever;

13. To Him who divided the Red Sea in two, For His mercy endures forever;

14. And made Israel pass through the midst of it, For His mercy endures forever;

15. But overthrew Pharaoh and his army in the Red Sea, For His mercy endures forever;

16. To Him who led His people through the wilderness, For His mercy endures forever;

17. To Him who struck down great kings, For His mercy endures forever;

18. And slew famous kings, For His mercy endures forever--

19. Sihon king of the Amorites, For His mercy endures forever;

20. And Og king of Bashan, For His mercy endures forever--

21. And gave their land as a heritage, For His mercy endures forever;

22. A heritage to Israel His servant, For His mercy endures forever.

23. Who remembered us in our lowly state, For His mercy endures forever;

24. And rescued us from our enemies, For His mercy endures forever;

25. Who gives food to all flesh, For His mercy endures forever.

26. Oh, give thanks to the God of heaven! For His mercy endures forever.

## Chapter 137

1. By the rivers of Babylon, There we sat down, yea, we wept When we remembered Zion.

2. We hung our harps Upon the willows in the midst of it.

3. For there those who carried us away captive asked of us a song, And those who plundered us requested mirth, Saying, "Sing us one of the songs of Zion!"

4. How shall we sing the LORD's song In a foreign land?

5. If I forget you, O Jerusalem, Let my right hand forget its skill!

6. If I do not remember you, Let my tongue cling to the roof of my mouth-- If I do not exalt Jerusalem Above my chief joy.

7. Remember, O LORD, against the sons of Edom The day of Jerusalem, Who said, "Raze it, raze it, To its very foundation!"

8. O daughter of Babylon, who are to be destroyed, Happy the one who repays you as you have served us!

9. Happy the one who takes and dashes Your little ones against the rock!

## Chapter 138

1. I will praise You with my whole heart; Before the gods I will sing praises to You.

2. I will worship toward Your holy temple, And praise Your name For Your lovingkindness and Your truth; For You have magnified Your word above all Your name.

3. In the day when I cried out, You answered me, And made me bold with strength in my soul.

4. All the kings of the earth shall praise You, O LORD, When they hear the words of Your mouth.

5. Yes, they shall sing of the ways of the LORD, For great is the glory of the LORD.

6. Though the LORD is on high, Yet He regards the lowly; But the proud He knows from afar.

7. Though I walk in the midst of trouble, You will revive me; You will stretch out Your hand Against the wrath of my enemies, And Your right hand will save me.

8. The LORD will perfect that which concerns me; Your mercy, O LORD, endures forever; Do not forsake the works of Your hands.

## Chapter 139

1. O LORD, You have searched me and known me.

2. You know my sitting down and my rising up; You understand my thought afar off.

3. You comprehend my path and my lying down, And are acquainted with all my ways.

4. For there is not a word on my tongue, But behold, O LORD, You know it altogether.

5. You have hedged me behind and before, And laid Your hand upon me.

6. Such knowledge is too wonderful for me; It is high, I cannot attain it.

7. Where can I go from Your Spirit? Or where can I flee from Your presence?

8. If I ascend into heaven, You are there; If I make my bed in hell, behold, You are there.

9. If I take the wings of the morning, And dwell in the uttermost parts of the sea,

10. Even there Your hand shall lead me, And Your right hand shall hold me.

11. If I say, "Surely the darkness shall fall on me," Even the night shall be light about me;

12. Indeed, the darkness shall not hide from You, But the night shines as the day; The darkness and the light are both alike to You.

13. For You formed my inward parts; You covered me in my mother's womb.

14. I will praise You, for I am fearfully and wonderfully made; Marvelous are Your works, And that my soul knows very well.

15. My frame was not hidden from You, When I was made in secret, And skillfully wrought in the lowest parts of the earth.

16. Your eyes saw my substance, being yet unformed. And in Your book they all were written, The days fashioned for me, When as yet there were none of them.

17. How precious also are Your thoughts to me, O God! How great is the sum of them!

18. If I should count them, they would be more in number than the sand; When I awake, I am still with You.

19. Oh, that You would slay the wicked, O God! Depart from me, therefore, you bloodthirsty men.

20. For they speak against You wickedly; Your enemies take Your name in vain.

21. Do I not hate them, O LORD, who hate You? And do I not loathe those who rise up against You?

22. I hate them with perfect hatred; I count them my enemies.

23. Search me, O God, and know my heart; Try me, and know my anxieties;

24. And see if there is any wicked way in me, And lead me in the way everlasting.

## Chapter 140

1. Deliver me, O LORD, from evil men; Preserve me from violent men,

2. Who plan evil things in their hearts; They continually gather together for war.

3. They sharpen their tongues like a serpent; The poison of asps is under their lips.Selah

4. Keep me, O LORD, from the hands of the wicked; Preserve me from violent men, Who have purposed to make my steps stumble.

5. The proud have hidden a snare for me, and cords; They have spread a net by the wayside; They have set traps for me.Selah

6. I said to the LORD: "You are my God; Hear the voice of my supplications, O LORD.

7. O GOD the Lord, the strength of my salvation, You have covered my head in the day of battle.

8. Do not grant, O LORD, the desires of the wicked; Do not further his wicked scheme, Lest they be exalted.Selah

9. "As for the head of those who surround me, Let the evil of their lips cover them;

10. Let burning coals fall upon them; Let them be cast into the fire, Into deep pits, that they rise not up again.

11. Let not a slanderer be established in the earth; Let evil hunt the violent man to overthrow him."

12. I know that the LORD will maintain The cause of the afflicted, And justice for the poor.

13. Surely the righteous shall give thanks to Your name; The upright shall dwell in Your presence.

## Chapter 141

1. LORD, I cry out to You; Make haste to me! Give ear to my voice when I cry out to You.

2. Let my prayer be set before You as incense, The lifting up of my hands as the evening sacrifice.

3. Set a guard, O LORD, over my mouth; Keep watch over the door of my lips.

4. Do not incline my heart to any evil thing, To practice wicked works With men who work iniquity; And do not let me eat of their delicacies.

5. Let the righteous strike me; It shall be a kindness. And let him rebuke me; It shall be as excellent oil; Let my head not refuse it. For still my prayer is against the deeds of the wicked.

6. Their judges are overthrown by the sides of the cliff, And they hear my words, for they are sweet.

7. Our bones are scattered at the mouth of the grave, As when one plows and breaks up the earth.

8. But my eyes are upon You, O GOD the Lord; In You I take refuge; Do not leave my soul destitute.

9. Keep me from the snares they have laid for me, And from the traps of the workers of iniquity.

10. Let the wicked fall into their own nets, While I escape safely.

## Chapter 142

1. I cry out to the LORD with my voice; With my voice to the LORD I make my supplication.

2. I pour out my complaint before Him; I declare before Him my trouble.

3. When my spirit was overwhelmed within me, Then You knew my path. In the way in which I walk They have secretly set a snare for me.

4. Look on my right hand and see, For there is no one who acknowledges me; Refuge has failed me; No one cares for my soul.

5. I cried out to You, O LORD: I said, "You are my refuge, My portion in the land of the living.

6. Attend to my cry, For I am brought very low; Deliver me from my persecutors, For they are stronger than I.

7. Bring my soul out of prison, That I may praise Your name; The righteous shall surround me, For You shall deal bountifully with me."

## Chapter 143

1. Hear my prayer, O LORD, Give ear to my supplications! In Your faithfulness answer me, And in Your righteousness.

2. Do not enter into judgment with Your servant, For in Your sight no one living is righteous.

3. For the enemy has persecuted my soul; He has crushed my life to the ground; He has made me dwell in darkness, Like those who have long been dead.

4. Therefore my spirit is overwhelmed within me; My heart within me is distressed.

5. I remember the days of old; I meditate on all Your works; I muse on the work of Your hands.

6. I spread out my hands to You; My soul longs for You like a thirsty land.Selah

7. Answer me speedily, O LORD; My spirit fails! Do not hide Your face from me, Lest I be like those who go down into the pit.

8. Cause me to hear Your lovingkindness in the morning, For in You do I trust; Cause me to know the way in which I should walk, For I lift up my soul to You.

9. Deliver me, O LORD, from my enemies; In You I take shelter.

10. Teach me to do Your will, For You are my God; Your Spirit is good. Lead me in the land of uprightness.

11. Revive me, O LORD, for Your name's sake! For Your righteousness' sake bring my soul out of trouble.

12. In Your mercy cut off my enemies, And destroy all those who afflict my soul; For I am Your servant.

## Chapter 144

1. Blessed be the LORD my Rock, Who trains my hands for war, And my fingers for battle--

2. My lovingkindness and my fortress, My high tower and my deliverer, My shield and the One in whom I take refuge, Who subdues my people under me.

3. LORD, what is man, that You take knowledge of him? Or the son of man, that You are mindful of him?

4. Man is like a breath; His days are like a passing shadow.

5. Bow down Your heavens, O LORD, and come down; Touch the mountains, and they shall smoke.

6. Flash forth lightning and scatter them; Shoot out Your arrows and destroy them.

7. Stretch out Your hand from above; Rescue me and deliver me out of great waters, From the hand of foreigners,

8. Whose mouth speaks lying words, And whose right hand is a right hand of falsehood.

9. I will sing a new song to You, O God; On a harp of ten strings I will sing praises to You,

10. The One who gives salvation to kings, Who delivers David His servant From the deadly sword.

11. Rescue me and deliver me from the hand of foreigners, Whose mouth speaks lying words, And whose right hand is a right hand of falsehood--

12. That our sons may be as plants grown up in their youth; That our daughters may be as pillars, Sculptured in palace style;

13. That our barns may be full, Supplying all kinds of produce; That our sheep may bring forth thousands And ten thousands in our fields;

14. That our oxen may be well laden; That there be no breaking in or going out; That there be no outcry in our streets.

15. Happy are the people who are in such a state; Happy are the people whose God is the LORD!

## Chapter 145

1. I will extol You, my God, O King; And I will bless Your name forever and ever.

2. Every day I will bless You, And I will praise Your name forever and ever.

3. Great is the LORD, and greatly to be praised; And His greatness is unsearchable.

4. One generation shall praise Your works to another, And shall declare Your mighty acts.

5. I will meditate on the glorious splendor of Your majesty, And on Your wondrous works.

6. Men shall speak of the might of Your awesome acts, And I will declare Your greatness.

7. They shall utter the memory of Your great goodness, And shall sing of Your righteousness.

8. The LORD is gracious and full of compassion, Slow to anger and great in mercy.

9. The LORD is good to all, And His tender mercies are over all His works.

10. All Your works shall praise You, O LORD, And Your saints shall bless You.

11. They shall speak of the glory of Your kingdom, And talk of Your power,

12. To make known to the sons of men His mighty acts, And the glorious majesty of His kingdom.

13. Your kingdom is an everlasting kingdom, And Your dominion endures throughout all generations.

14. The LORD upholds all who fall, And raises up all who are bowed down.

15. The eyes of all look expectantly to You, And You give them their food in due season.

16. You open Your hand And satisfy the desire of every living thing.

17. The LORD is righteous in all His ways, Gracious in all His works.

18. The LORD is near to all who call upon Him, To all who call upon Him in truth.

19. He will fulfill the desire of those who fear Him; He also will hear their cry and save them.

20. The LORD preserves all who love Him, But all the wicked He will destroy.

21. My mouth shall speak the praise of the LORD, And all flesh shall bless His holy name Forever and ever.

## Chapter 146

1. Praise the LORD! Praise the LORD, O my soul!

2. While I live I will praise the LORD; I will sing praises to my God while I have my being.

3. Do not put your trust in princes, Nor in a son of man, in whom there is no help.

4. His spirit departs, he returns to his earth; In that very day his plans perish.

5. Happy is he who has the God of Jacob for his help, Whose hope is in the LORD his God,

6. Who made heaven and earth, The sea, and all that is in them; Who keeps truth forever,

7. Who executes justice for the oppressed, Who gives food to the hungry. The LORD gives freedom to the prisoners.

8. The LORD opens the eyes of the blind; The LORD raises those who are bowed down; The LORD loves the righteous.

9. The LORD watches over the strangers; He relieves the fatherless and widow; But the way of the wicked He turns upside down.

10. The LORD shall reign forever-- Your God, O Zion, to all generations. Praise the LORD!

## Chapter 147

1. Praise the LORD! For it is good to sing praises to our God; For it is pleasant, and praise is beautiful.

2. The LORD builds up Jerusalem; He gathers together the outcasts of Israel.

3. He heals the brokenhearted And binds up their wounds.

4. He counts the number of the stars; He calls them all by name.

5. Great is our Lord, and mighty in power; His understanding is infinite.

6. The LORD lifts up the humble; He casts the wicked down to the ground.

7. Sing to the LORD with thanksgiving; Sing praises on the harp to our God,

8. Who covers the heavens with clouds, Who prepares rain for the earth, Who makes grass to grow on the mountains.

9. He gives to the beast its food, And to the young ravens that cry.

10. He does not delight in the strength of the horse; He takes no pleasure in the legs of a man.

11. The LORD takes pleasure in those who fear Him, In those who hope in His mercy.

12. Praise the LORD, O Jerusalem! Praise your God, O Zion!

13. For He has strengthened the bars of your gates; He has blessed your children within you.

14. He makes peace in your borders, And fills you with the finest wheat.

15. He sends out His command to the earth; His word runs very swiftly.

16. He gives snow like wool; He scatters the frost like ashes;

17. He casts out His hail like morsels; Who can stand before His cold?

18. He sends out His word and melts them; He causes His wind to blow, and the waters flow.

19. He declares His word to Jacob, His statutes and His judgments to Israel.

20. He has not dealt thus with any nation; And as for His judgments, they have not known them. Praise the LORD!

## Chapter 148

1. Praise the LORD! Praise the LORD from the heavens; Praise Him in the heights!

2. Praise Him, all His angels; Praise Him, all His hosts!

3. Praise Him, sun and moon; Praise Him, all you stars of light!

4. Praise Him, you heavens of heavens, And you waters above the heavens!

5. Let them praise the name of the LORD, For He commanded and they were created.

6. He also established them forever and ever; He made a decree which shall not pass away.

7. Praise the LORD from the earth, You great sea creatures and all the depths;

8. Fire and hail, snow and clouds; Stormy wind, fulfilling His word;

9. Mountains and all hills; Fruitful trees and all cedars;

10. Beasts and all cattle; Creeping things and flying fowl;

11. Kings of the earth and all peoples; Princes and all judges of the earth;

12. Both young men and maidens; Old men and children.

13. Let them praise the name of the LORD, For His name alone is exalted; His glory is above the earth and heaven.

14. And He has exalted the horn of His people, The praise of all His saints-- Of the children of Israel, A people near to Him. Praise the LORD!

## Chapter 149

1. Praise the LORD! Sing to the LORD a new song, And His praise in the assembly of saints.

2. Let Israel rejoice in their Maker; Let the children of Zion be joyful in their King.

3. Let them praise His name with the dance; Let them sing praises to Him with the timbrel and harp.

4. For the LORD takes pleasure in His people; He will beautify the humble with salvation.

5. Let the saints be joyful in glory; Let them sing aloud on their beds.

6. Let the high praises of God be in their mouth, And a two-edged sword in their hand,

7. To execute vengeance on the nations, And punishments on the peoples;

8. To bind their kings with chains, And their nobles with fetters of iron;

9. To execute on them the written judgment-- This honor have all His saints. Praise the LORD!

## Chapter 150

1. Praise the LORD! Praise God in His sanctuary; Praise Him in His mighty firmament!

2. Praise Him for His mighty acts; Praise Him according to His excellent greatness!

3. Praise Him with the sound of the trumpet; Praise Him with the lute and harp!

4. Praise Him with the timbrel and dance; Praise Him with stringed instruments and flutes!

5. Praise Him with loud cymbals; Praise Him with clashing cymbals!

6. Let everything that has breath praise the LORD. Praise the LORD!


# romans

## Chapter 1

1. Paul, a bondservant of Jesus Christ, called to be an apostle, separated to the gospel of God

2. which He promised before through His prophets in the Holy Scriptures,

3. concerning His Son Jesus Christ our Lord, who was born of the seed of David according to the flesh,

4. and declared to be the Son of God with power according to the Spirit of holiness, by the resurrection from the dead.

5. Through Him we have received grace and apostleship for obedience to the faith among all nations for His name,

6. among whom you also are the called of Jesus Christ;

7. To all who are in Rome, beloved of God, called to be saints: Grace to you and peace from God our Father and the Lord Jesus Christ.

8. First, I thank my God through Jesus Christ for you all, that your faith is spoken of throughout the whole world.

9. For God is my witness, whom I serve with my spirit in the gospel of His Son, that without ceasing I make mention of you always in my prayers,

10. making request if, by some means, now at last I may find a way in the will of God to come to you.

11. For I long to see you, that I may impart to you some spiritual gift, so that you may be established--

12. that is, that I may be encouraged together with you by the mutual faith both of you and me.

13. Now I do not want you to be unaware, brethren, that I often planned to come to you (but was hindered until now), that I might have some fruit among you also, just as among the other Gentiles.

14. I am a debtor both to Greeks and to barbarians, both to wise and to unwise.

15. So, as much as is in me, I am ready to preach the gospel to you who are in Rome also.

16. For I am not ashamed of the gospel of Christ, for it is the power of God to salvation for everyone who believes, for the Jew first and also for the Greek.

17. For in it the righteousness of God is revealed from faith to faith; as it is written, "The just shall live by faith."

18. For the wrath of God is revealed from heaven against all ungodliness and unrighteousness of men, who suppress the truth in unrighteousness,

19. because what may be known of God is manifest in them, for God has shown it to them.

20. For since the creation of the world His invisible attributes are clearly seen, being understood by the things that are made, even His eternal power and Godhead, so that they are without excuse,

21. because, although they knew God, they did not glorify Him as God, nor were thankful, but became futile in their thoughts, and their foolish hearts were darkened.

22. Professing to be wise, they became fools,

23. and changed the glory of the incorruptible God into an image made like corruptible man--and birds and four-footed animals and creeping things.

24. Therefore God also gave them up to uncleanness, in the lusts of their hearts, to dishonor their bodies among themselves,

25. who exchanged the truth of God for the lie, and worshiped and served the creature rather than the Creator, who is blessed forever. Amen.

26. For this reason God gave them up to vile passions. For even their women exchanged the natural use for what is against nature.

27. Likewise also the men, leaving the natural use of the woman, burned in their lust for one another, men with men committing what is shameful, and receiving in themselves the penalty of their error which was due.

28. And even as they did not like to retain God in their knowledge, God gave them over to a debased mind, to do those things which are not fitting;

29. being filled with all unrighteousness, sexual immorality, wickedness, covetousness, maliciousness; full of envy, murder, strife, deceit, evil-mindedness; they are whisperers,

30. backbiters, haters of God, violent, proud, boasters, inventors of evil things, disobedient to parents,

31. undiscerning, untrustworthy, unloving, unforgiving, unmerciful;

32. who, knowing the righteous judgment of God, that those who practice such things are deserving of death, not only do the same but also approve of those who practice them.

## Chapter 2

1. Therefore you are inexcusable, O man, whoever you are who judge, for in whatever you judge another you condemn yourself; for you who judge practice the same things.

2. But we know that the judgment of God is according to truth against those who practice such things.

3. And do you think this, O man, you who judge those practicing such things, and doing the same, that you will escape the judgment of God?

4. Or do you despise the riches of His goodness, forbearance, and longsuffering, not knowing that the goodness of God leads you to repentance?

5. But in accordance with your hardness and your impenitent heart you are treasuring up for yourself wrath in the day of wrath and revelation of the righteous judgment of God,

6. who "will render to each one according to his deeds":

7. eternal life to those who by patient continuance in doing good seek for glory, honor, and immortality;

8. but to those who are self-seeking and do not obey the truth, but obey unrighteousness--indignation and wrath,

9. tribulation and anguish, on every soul of man who does evil, of the Jew first and also of the Greek;

10. but glory, honor, and peace to everyone who works what is good, to the Jew first and also to the Greek.

11. For there is no partiality with God.

12. For as many as have sinned without law will also perish without law, and as many as have sinned in the law will be judged by the law

13. (for not the hearers of the law are just in the sight of God, but the doers of the law will be justified;

14. for when Gentiles, who do not have the law, by nature do the things in the law, these, although not having the law, are a law to themselves,

15. who show the work of the law written in their hearts, their conscience also bearing witness, and between themselves their thoughts accusing or else excusing them)

16. in the day when God will judge the secrets of men by Jesus Christ, according to my gospel.

17. Indeed you are called a Jew, and rest on the law, and make your boast in God,

18. and know His will, and approve the things that are excellent, being instructed out of the law,

19. and are confident that you yourself are a guide to the blind, a light to those who are in darkness,

20. an instructor of the foolish, a teacher of babes, having the form of knowledge and truth in the law.

21. You, therefore, who teach another, do you not teach yourself? You who preach that a man should not steal, do you steal?

22. You who say, "Do not commit adultery," do you commit adultery? You who abhor idols, do you rob temples?

23. You who make your boast in the law, do you dishonor God through breaking the law?

24. For "the name of God is blasphemed among the Gentiles because of you," as it is written.

25. For circumcision is indeed profitable if you keep the law; but if you are a breaker of the law, your circumcision has become uncircumcision.

26. Therefore, if an uncircumcised man keeps the righteous requirements of the law, will not his uncircumcision be counted as circumcision?

27. And will not the physically uncircumcised, if he fulfills the law, judge you who, even with your written code and circumcision, are a transgressor of the law?

28. For he is not a Jew who is one outwardly, nor is circumcision that which is outward in the flesh;

29. but he is a Jew who is one inwardly; and circumcision is that of the heart, in the Spirit, not in the letter; whose praise is not from men but from God.

## Chapter 3

1. What advantage then has the Jew, or what is the profit of circumcision?

2. Much in every way! Chiefly because to them were committed the oracles of God.

3. For what if some did not believe? Will their unbelief make the faithfulness of God without effect?

4. Certainly not! Indeed, let God be true but every man a liar. As it is written: "That You may be justified in Your words, And may overcome when You are judged."

5. But if our unrighteousness demonstrates the righteousness of God, what shall we say? Is God unjust who inflicts wrath? (I speak as a man.)

6. Certainly not! For then how will God judge the world?

7. For if the truth of God has increased through my lie to His glory, why am I also still judged as a sinner?

8. And why not say, "Let us do evil that good may come"?--as we are slanderously reported and as some affirm that we say. Their condemnation is just.

9. What then? Are we better than they? Not at all. For we have previously charged both Jews and Greeks that they are all under sin.

10. As it is written: "There is none righteous, no, not one;

11. There is none who understands; There is none who seeks after God.

12. They have all turned aside; They have together become unprofitable; There is none who does good, no, not one."

13. "Their throat is an open tomb; With their tongues they have practiced deceit"; "The poison of asps is under their lips";

14. "Whose mouth is full of cursing and bitterness."

15. "Their feet are swift to shed blood;

16. Destruction and misery are in their ways;

17. And the way of peace they have not known."

18. "There is no fear of God before their eyes."

19. Now we know that whatever the law says, it says to those who are under the law, that every mouth may be stopped, and all the world may become guilty before God.

20. Therefore by the deeds of the law no flesh will be justified in His sight, for by the law is the knowledge of sin.

21. But now the righteousness of God apart from the law is revealed, being witnessed by the Law and the Prophets,

22. even the righteousness of God, through faith in Jesus Christ, to all and on all who believe. For there is no difference;

23. for all have sinned and fall short of the glory of God,

24. being justified freely by His grace through the redemption that is in Christ Jesus,

25. whom God set forth as a propitiation by His blood, through faith, to demonstrate His righteousness, because in His forbearance God had passed over the sins that were previously committed,

26. to demonstrate at the present time His righteousness, that He might be just and the justifier of the one who has faith in Jesus.

27. Where is boasting then? It is excluded. By what law? Of works? No, but by the law of faith.

28. Therefore we conclude that a man is justified by faith apart from the deeds of the law.

29. Or is He the God of the Jews only? Is He not also the God of the Gentiles? Yes, of the Gentiles also,

30. since there is one God who will justify the circumcised by faith and the uncircumcised through faith.

31. Do we then make void the law through faith? Certainly not! On the contrary, we establish the law.

## Chapter 4

1. What then shall we say that Abraham our father has found according to the flesh?

2. For if Abraham was justified by works, he has something to boast about, but not before God.

3. For what does the Scripture say? "Abraham believed God, and it was accounted to him for righteousness."

4. Now to him who works, the wages are not counted as grace but as debt.

5. But to him who does not work but believes on Him who justifies the ungodly, his faith is accounted for righteousness,

6. just as David also describes the blessedness of the man to whom God imputes righteousness apart from works:

7. "Blessed are those whose lawless deeds are forgiven, And whose sins are covered;

8. Blessed is the man to whom the LORD shall not impute sin."

9. Does this blessedness then come upon the circumcised only, or upon the uncircumcised also? For we say that faith was accounted to Abraham for righteousness.

10. How then was it accounted? While he was circumcised, or uncircumcised? Not while circumcised, but while uncircumcised.

11. And he received the sign of circumcision, a seal of the righteousness of the faith which he had while still uncircumcised, that he might be the father of all those who believe, though they are uncircumcised, that righteousness might be imputed to them also,

12. and the father of circumcision to those who not only are of the circumcision, but who also walk in the steps of the faith which our father Abraham had while still uncircumcised.

13. For the promise that he would be the heir of the world was not to Abraham or to his seed through the law, but through the righteousness of faith.

14. For if those who are of the law are heirs, faith is made void and the promise made of no effect,

15. because the law brings about wrath; for where there is no law there is no transgression.

16. Therefore it is of faith that it might be according to grace, so that the promise might be sure to all the seed, not only to those who are of the law, but also to those who are of the faith of Abraham, who is the father of us all

17. (as it is written, "I have made you a father of many nations") in the presence of Him whom he believed--God, who gives life to the dead and calls those things which do not exist as though they did;

18. who, contrary to hope, in hope believed, so that he became the father of many nations, according to what was spoken, "So shall your descendants be."

19. And not being weak in faith, he did not consider his own body, already dead (since he was about a hundred years old), and the deadness of Sarah's womb.

20. He did not waver at the promise of God through unbelief, but was strengthened in faith, giving glory to God,

21. and being fully convinced that what He had promised He was also able to perform.

22. And therefore "it was accounted to him for righteousness."

23. Now it was not written for his sake alone that it was imputed to him,

24. but also for us. It shall be imputed to us who believe in Him who raised up Jesus our Lord from the dead,

25. who was delivered up because of our offenses, and was raised because of our justification.

## Chapter 5

1. Therefore, having been justified by faith, we have peace with God through our Lord Jesus Christ,

2. through whom also we have access by faith into this grace in which we stand, and rejoice in hope of the glory of God.

3. And not only that, but we also glory in tribulations, knowing that tribulation produces perseverance;

4. and perseverance, character; and character, hope.

5. Now hope does not disappoint, because the love of God has been poured out in our hearts by the Holy Spirit who was given to us.

6. For when we were still without strength, in due time Christ died for the ungodly.

7. For scarcely for a righteous man will one die; yet perhaps for a good man someone would even dare to die.

8. But God demonstrates His own love toward us, in that while we were still sinners, Christ died for us.

9. Much more then, having now been justified by His blood, we shall be saved from wrath through Him.

10. For if when we were enemies we were reconciled to God through the death of His Son, much more, having been reconciled, we shall be saved by His life.

11. And not only that, but we also rejoice in God through our Lord Jesus Christ, through whom we have now received the reconciliation.

12. Therefore, just as through one man sin entered the world, and death through sin, and thus death spread to all men, because all sinned--

13. (For until the law sin was in the world, but sin is not imputed when there is no law.

14. Nevertheless death reigned from Adam to Moses, even over those who had not sinned according to the likeness of the transgression of Adam, who is a type of Him who was to come.

15. But the free gift is not like the offense. For if by the one man's offense many died, much more the grace of God and the gift by the grace of the one Man, Jesus Christ, abounded to many.

16. And the gift is not like that which came through the one who sinned. For the judgment which came from one offense resulted in condemnation, but the free gift which came from many offenses resulted in justification.

17. For if by the one man's offense death reigned through the one, much more those who receive abundance of grace and of the gift of righteousness will reign in life through the One, Jesus Christ.)

18. Therefore, as through one man's offense judgment came to all men, resulting in condemnation, even so through one Man's righteous act the free gift came to all men, resulting in justification of life.

19. For as by one man's disobedience many were made sinners, so also by one Man's obedience many will be made righteous.

20. Moreover the law entered that the offense might abound. But where sin abounded, grace abounded much more,

21. so that as sin reigned in death, even so grace might reign through righteousness to eternal life through Jesus Christ our Lord.

## Chapter 6

1. What shall we say then? Shall we continue in sin that grace may abound?

2. Certainly not! How shall we who died to sin live any longer in it?

3. Or do you not know that as many of us as were baptized into Christ Jesus were baptized into His death?

4. Therefore we were buried with Him through baptism into death, that just as Christ was raised from the dead by the glory of the Father, even so we also should walk in newness of life.

5. For if we have been united together in the likeness of His death, certainly we also shall be in the likeness of His resurrection,

6. knowing this, that our old man was crucified with Him, that the body of sin might be done away with, that we should no longer be slaves of sin.

7. For he who has died has been freed from sin.

8. Now if we died with Christ, we believe that we shall also live with Him,

9. knowing that Christ, having been raised from the dead, dies no more. Death no longer has dominion over Him.

10. For the death that He died, He died to sin once for all; but the life that He lives, He lives to God.

11. Likewise you also, reckon yourselves to be dead indeed to sin, but alive to God in Christ Jesus our Lord.

12. Therefore do not let sin reign in your mortal body, that you should obey it in its lusts.

13. And do not present your members as instruments of unrighteousness to sin, but present yourselves to God as being alive from the dead, and your members as instruments of righteousness to God.

14. For sin shall not have dominion over you, for you are not under law but under grace.

15. What then? Shall we sin because we are not under law but under grace? Certainly not!

16. Do you not know that to whom you present yourselves slaves to obey, you are that one's slaves whom you obey, whether of sin leading to death, or of obedience leading to righteousness?

17. But God be thanked that though you were slaves of sin, yet you obeyed from the heart that form of doctrine to which you were delivered.

18. And having been set free from sin, you became slaves of righteousness.

19. I speak in human terms because of the weakness of your flesh. For just as you presented your members as slaves of uncleanness, and of lawlessness leading to more lawlessness, so now present your members as slaves of righteousness for holiness.

20. For when you were slaves of sin, you were free in regard to righteousness.

21. What fruit did you have then in the things of which you are now ashamed? For the end of those things is death.

22. But now having been set free from sin, and having become slaves of God, you have your fruit to holiness, and the end, everlasting life.

23. For the wages of sin is death, but the gift of God is eternal life in Christ Jesus our Lord.

## Chapter 7

1. Or do you not know, brethren (for I speak to those who know the law), that the law has dominion over a man as long as he lives?

2. For the woman who has a husband is bound by the law to her husband as long as he lives. But if the husband dies, she is released from the law of her husband.

3. So then if, while her husband lives, she marries another man, she will be called an adulteress; but if her husband dies, she is free from that law, so that she is no adulteress, though she has married another man.

4. Therefore, my brethren, you also have become dead to the law through the body of Christ, that you may be married to another--to Him who was raised from the dead, that we should bear fruit to God.

5. For when we were in the flesh, the sinful passions which were aroused by the law were at work in our members to bear fruit to death.

6. But now we have been delivered from the law, having died to what we were held by, so that we should serve in the newness of the Spirit and not in the oldness of the letter.

7. What shall we say then? Is the law sin? Certainly not! On the contrary, I would not have known sin except through the law. For I would not have known covetousness unless the law had said, "You shall not covet."

8. But sin, taking opportunity by the commandment, produced in me all manner of evil desire. For apart from the law sin was dead.

9. I was alive once without the law, but when the commandment came, sin revived and I died.

10. And the commandment, which was to bring life, I found to bring death.

11. For sin, taking occasion by the commandment, deceived me, and by it killed me.

12. Therefore the law is holy, and the commandment holy and just and good.

13. Has then what is good become death to me? Certainly not! But sin, that it might appear sin, was producing death in me through what is good, so that sin through the commandment might become exceedingly sinful.

14. For we know that the law is spiritual, but I am carnal, sold under sin.

15. For what I am doing, I do not understand. For what I will to do, that I do not practice; but what I hate, that I do.

16. If, then, I do what I will not to do, I agree with the law that it is good.

17. But now, it is no longer I who do it, but sin that dwells in me.

18. For I know that in me (that is, in my flesh) nothing good dwells; for to will is present with me, but how to perform what is good I do not find.

19. For the good that I will to do, I do not do; but the evil I will not to do, that I practice.

20. Now if I do what I will not to do, it is no longer I who do it, but sin that dwells in me.

21. I find then a law, that evil is present with me, the one who wills to do good.

22. For I delight in the law of God according to the inward man.

23. But I see another law in my members, warring against the law of my mind, and bringing me into captivity to the law of sin which is in my members.

24. O wretched man that I am! Who will deliver me from this body of death?

25. I thank God--through Jesus Christ our Lord! So then, with the mind I myself serve the law of God, but with the flesh the law of sin.

## Chapter 8

1. There is therefore now no condemnation to those who are in Christ Jesus, who do not walk according to the flesh, but according to the Spirit.

2. For the law of the Spirit of life in Christ Jesus has made me free from the law of sin and death.

3. For what the law could not do in that it was weak through the flesh, God did by sending His own Son in the likeness of sinful flesh, on account of sin: He condemned sin in the flesh,

4. that the righteous requirement of the law might be fulfilled in us who do not walk according to the flesh but according to the Spirit.

5. For those who live according to the flesh set their minds on the things of the flesh, but those who live according to the Spirit, the things of the Spirit.

6. For to be carnally minded is death, but to be spiritually minded is life and peace.

7. Because the carnal mind is enmity against God; for it is not subject to the law of God, nor indeed can be.

8. So then, those who are in the flesh cannot please God.

9. But you are not in the flesh but in the Spirit, if indeed the Spirit of God dwells in you. Now if anyone does not have the Spirit of Christ, he is not His.

10. And if Christ is in you, the body is dead because of sin, but the Spirit is life because of righteousness.

11. But if the Spirit of Him who raised Jesus from the dead dwells in you, He who raised Christ from the dead will also give life to your mortal bodies through His Spirit who dwells in you.

12. Therefore, brethren, we are debtors--not to the flesh, to live according to the flesh.

13. For if you live according to the flesh you will die; but if by the Spirit you put to death the deeds of the body, you will live.

14. For as many as are led by the Spirit of God, these are sons of God.

15. For you did not receive the spirit of bondage again to fear, but you received the Spirit of adoption by whom we cry out, "Abba, Father."

16. The Spirit Himself bears witness with our spirit that we are children of God,

17. and if children, then heirs--heirs of God and joint heirs with Christ, if indeed we suffer with Him, that we may also be glorified together.

18. For I consider that the sufferings of this present time are not worthy to be compared with the glory which shall be revealed in us.

19. For the earnest expectation of the creation eagerly waits for the revealing of the sons of God.

20. For the creation was subjected to futility, not willingly, but because of Him who subjected it in hope;

21. because the creation itself also will be delivered from the bondage of corruption into the glorious liberty of the children of God.

22. For we know that the whole creation groans and labors with birth pangs together until now.

23. Not only that, but we also who have the firstfruits of the Spirit, even we ourselves groan within ourselves, eagerly waiting for the adoption, the redemption of our body.

24. For we were saved in this hope, but hope that is seen is not hope; for why does one still hope for what he sees?

25. But if we hope for what we do not see, we eagerly wait for it with perseverance.

26. Likewise the Spirit also helps in our weaknesses. For we do not know what we should pray for as we ought, but the Spirit Himself makes intercession for us with groanings which cannot be uttered.

27. Now He who searches the hearts knows what the mind of the Spirit is, because He makes intercession for the saints according to the will of God.

28. And we know that all things work together for good to those who love God, to those who are the called according to His purpose.

29. For whom He foreknew, He also predestined to be conformed to the image of His Son, that He might be the firstborn among many brethren.

30. Moreover whom He predestined, these He also called; whom He called, these He also justified; and whom He justified, these He also glorified.

31. What then shall we say to these things? If God is for us, who can be against us?

32. He who did not spare His own Son, but delivered Him up for us all, how shall He not with Him also freely give us all things?

33. Who shall bring a charge against God's elect? It is God who justifies.

34. Who is he who condemns? It is Christ who died, and furthermore is also risen, who is even at the right hand of God, who also makes intercession for us.

35. Who shall separate us from the love of Christ? Shall tribulation, or distress, or persecution, or famine, or nakedness, or peril, or sword?

36. As it is written: "For Your sake we are killed all day long; We are accounted as sheep for the slaughter."

37. Yet in all these things we are more than conquerors through Him who loved us.

38. For I am persuaded that neither death nor life, nor angels nor principalities nor powers, nor things present nor things to come,

39. nor height nor depth, nor any other created thing, shall be able to separate us from the love of God which is in Christ Jesus our Lord.

## Chapter 9

1. I tell the truth in Christ, I am not lying, my conscience also bearing me witness in the Holy Spirit,

2. that I have great sorrow and continual grief in my heart.

3. For I could wish that I myself were accursed from Christ for my brethren, my countrymen according to the flesh,

4. who are Israelites, to whom pertain the adoption, the glory, the covenants, the giving of the law, the service of God, and the promises;

5. of whom are the fathers and from whom, according to the flesh, Christ came, who is over all, the eternally blessed God. Amen.

6. But it is not that the word of God has taken no effect. For they are not all Israel who are of Israel,

7. nor are they all children because they are the seed of Abraham; but, "In Isaac your seed shall be called."

8. That is, those who are the children of the flesh, these are not the children of God; but the children of the promise are counted as the seed.

9. For this is the word of promise: "At this time I will come and Sarah shall have a son."

10. And not only this, but when Rebecca also had conceived by one man, even by our father Isaac

11. (for the children not yet being born, nor having done any good or evil, that the purpose of God according to election might stand, not of works but of Him who calls),

12. it was said to her, "The older shall serve the younger."

13. As it is written, "Jacob I have loved, but Esau I have hated."

14. What shall we say then? Is there unrighteousness with God? Certainly not!

15. For He says to Moses, "I will have mercy on whomever I will have mercy, and I will have compassion on whomever I will have compassion."

16. So then it is not of him who wills, nor of him who runs, but of God who shows mercy.

17. For the Scripture says to the Pharaoh, "For this very purpose I have raised you up, that I may show My power in you, and that My name may be declared in all the earth."

18. Therefore He has mercy on whom He wills, and whom He wills He hardens.

19. You will say to me then, "Why does He still find fault? For who has resisted His will?"

20. But indeed, O man, who are you to reply against God? Will the thing formed say to him who formed it, "Why have you made me like this?"

21. Does not the potter have power over the clay, from the same lump to make one vessel for honor and another for dishonor?

22. What if God, wanting to show His wrath and to make His power known, endured with much longsuffering the vessels of wrath prepared for destruction,

23. and that He might make known the riches of His glory on the vessels of mercy, which He had prepared beforehand for glory,

24. even us whom He called, not of the Jews only, but also of the Gentiles?

25. As He says also in Hosea: "I will call them My people, who were not My people, And her beloved, who was not beloved."

26. "And it shall come to pass in the place where it was said to them, "You are not My people,' There they shall be called sons of the living God."

27. Isaiah also cries out concerning Israel: "Though the number of the children of Israel be as the sand of the sea, The remnant will be saved.

28. For He will finish the work and cut it short in righteousness, Because the LORD will make a short work upon the earth."

29. And as Isaiah said before: "Unless the LORD of Sabaoth had left us a seed, We would have become like Sodom, And we would have been made like Gomorrah."

30. What shall we say then? That Gentiles, who did not pursue righteousness, have attained to righteousness, even the righteousness of faith;

31. but Israel, pursuing the law of righteousness, has not attained to the law of righteousness.

32. Why? Because they did not seek it by faith, but as it were, by the works of the law. For they stumbled at that stumbling stone.

33. As it is written: "Behold, I lay in Zion a stumbling stone and rock of offense, And whoever believes on Him will not be put to shame."

## Chapter 10

1. Brethren, my heart's desire and prayer to God for Israel is that they may be saved.

2. For I bear them witness that they have a zeal for God, but not according to knowledge.

3. For they being ignorant of God's righteousness, and seeking to establish their own righteousness, have not submitted to the righteousness of God.

4. For Christ is the end of the law for righteousness to everyone who believes.

5. For Moses writes about the righteousness which is of the law, "The man who does those things shall live by them."

6. But the righteousness of faith speaks in this way, "Do not say in your heart, "Who will ascend into heaven?"' (that is, to bring Christ down from above)

7. or, ""Who will descend into the abyss?"' (that is, to bring Christ up from the dead).

8. But what does it say? "The word is near you, in your mouth and in your heart" (that is, the word of faith which we preach):

9. that if you confess with your mouth the Lord Jesus and believe in your heart that God has raised Him from the dead, you will be saved.

10. For with the heart one believes unto righteousness, and with the mouth confession is made unto salvation.

11. For the Scripture says, "Whoever believes on Him will not be put to shame."

12. For there is no distinction between Jew and Greek, for the same Lord over all is rich to all who call upon Him.

13. For "whoever calls on the name of the LORD shall be saved."

14. How then shall they call on Him in whom they have not believed? And how shall they believe in Him of whom they have not heard? And how shall they hear without a preacher?

15. And how shall they preach unless they are sent? As it is written: "How beautiful are the feet of those who preach the gospel of peace, Who bring glad tidings of good things!"

16. But they have not all obeyed the gospel. For Isaiah says, "LORD, who has believed our report?"

17. So then faith comes by hearing, and hearing by the word of God.

18. But I say, have they not heard? Yes indeed: "Their sound has gone out to all the earth, And their words to the ends of the world."

19. But I say, did Israel not know? First Moses says: "I will provoke you to jealousy by those who are not a nation, I will move you to anger by a foolish nation."

20. But Isaiah is very bold and says: "I was found by those who did not seek Me; I was made manifest to those who did not ask for Me."

21. But to Israel he says: "All day long I have stretched out My hands To a disobedient and contrary people."

## Chapter 11

1. I say then, has God cast away His people? Certainly not! For I also am an Israelite, of the seed of Abraham, of the tribe of Benjamin.

2. God has not cast away His people whom He foreknew. Or do you not know what the Scripture says of Elijah, how he pleads with God against Israel, saying,

3. "LORD, they have killed Your prophets and torn down Your altars, and I alone am left, and they seek my life"?

4. But what does the divine response say to him? "I have reserved for Myself seven thousand men who have not bowed the knee to Baal."

5. Even so then, at this present time there is a remnant according to the election of grace.

6. And if by grace, then it is no longer of works; otherwise grace is no longer grace. But if it is of works, it is no longer grace; otherwise work is no longer work.

7. What then? Israel has not obtained what it seeks; but the elect have obtained it, and the rest were blinded.

8. Just as it is written: "God has given them a spirit of stupor, Eyes that they should not see And ears that they should not hear, To this very day."

9. And David says: "Let their table become a snare and a trap, A stumbling block and a recompense to them.

10. Let their eyes be darkened, so that they do not see, And bow down their back always."

11. I say then, have they stumbled that they should fall? Certainly not! But through their fall, to provoke them to jealousy, salvation has come to the Gentiles.

12. Now if their fall is riches for the world, and their failure riches for the Gentiles, how much more their fullness!

13. For I speak to you Gentiles; inasmuch as I am an apostle to the Gentiles, I magnify my ministry,

14. if by any means I may provoke to jealousy those who are my flesh and save some of them.

15. For if their being cast away is the reconciling of the world, what will their acceptance be but life from the dead?

16. For if the firstfruit is holy, the lump is also holy; and if the root is holy, so are the branches.

17. And if some of the branches were broken off, and you, being a wild olive tree, were grafted in among them, and with them became a partaker of the root and fatness of the olive tree,

18. do not boast against the branches. But if you do boast, remember that you do not support the root, but the root supports you.

19. You will say then, "Branches were broken off that I might be grafted in."

20. Well said. Because of unbelief they were broken off, and you stand by faith. Do not be haughty, but fear.

21. For if God did not spare the natural branches, He may not spare you either.

22. Therefore consider the goodness and severity of God: on those who fell, severity; but toward you, goodness, if you continue in His goodness. Otherwise you also will be cut off.

23. And they also, if they do not continue in unbelief, will be grafted in, for God is able to graft them in again.

24. For if you were cut out of the olive tree which is wild by nature, and were grafted contrary to nature into a cultivated olive tree, how much more will these, who are natural branches, be grafted into their own olive tree?

25. For I do not desire, brethren, that you should be ignorant of this mystery, lest you should be wise in your own opinion, that blindness in part has happened to Israel until the fullness of the Gentiles has come in.

26. And so all Israel will be saved, as it is written: "The Deliverer will come out of Zion, And He will turn away ungodliness from Jacob;

27. For this is My covenant with them, When I take away their sins."

28. Concerning the gospel they are enemies for your sake, but concerning the election they are beloved for the sake of the fathers.

29. For the gifts and the calling of God are irrevocable.

30. For as you were once disobedient to God, yet have now obtained mercy through their disobedience,

31. even so these also have now been disobedient, that through the mercy shown you they also may obtain mercy.

32. For God has committed them all to disobedience, that He might have mercy on all.

33. Oh, the depth of the riches both of the wisdom and knowledge of God! How unsearchable are His judgments and His ways past finding out!

34. "For who has known the mind of the LORD? Or who has become His counselor?"

35. "Or who has first given to Him And it shall be repaid to him?"

36. For of Him and through Him and to Him are all things, to whom be glory forever. Amen.

## Chapter 12

1. I beseech you therefore, brethren, by the mercies of God, that you present your bodies a living sacrifice, holy, acceptable to God, which is your reasonable service.

2. And do not be conformed to this world, but be transformed by the renewing of your mind, that you may prove what is that good and acceptable and perfect will of God.

3. For I say, through the grace given to me, to everyone who is among you, not to think of himself more highly than he ought to think, but to think soberly, as God has dealt to each one a measure of faith.

4. For as we have many members in one body, but all the members do not have the same function,

5. so we, being many, are one body in Christ, and individually members of one another.

6. Having then gifts differing according to the grace that is given to us, let us use them: if prophecy, let us prophesy in proportion to our faith;

7. or ministry, let us use it in our ministering; he who teaches, in teaching;

8. he who exhorts, in exhortation; he who gives, with liberality; he who leads, with diligence; he who shows mercy, with cheerfulness.

9. Let love be without hypocrisy. Abhor what is evil. Cling to what is good.

10. Be kindly affectionate to one another with brotherly love, in honor giving preference to one another;

11. not lagging in diligence, fervent in spirit, serving the Lord;

12. rejoicing in hope, patient in tribulation, continuing steadfastly in prayer;

13. distributing to the needs of the saints, given to hospitality.

14. Bless those who persecute you; bless and do not curse.

15. Rejoice with those who rejoice, and weep with those who weep.

16. Be of the same mind toward one another. Do not set your mind on high things, but associate with the humble. Do not be wise in your own opinion.

17. Repay no one evil for evil. Have regard for good things in the sight of all men.

18. If it is possible, as much as depends on you, live peaceably with all men.

19. Beloved, do not avenge yourselves, but rather give place to wrath; for it is written, "Vengeance is Mine, I will repay," says the Lord.

20. Therefore "If your enemy is hungry, feed him; If he is thirsty, give him a drink; For in so doing you will heap coals of fire on his head."

21. Do not be overcome by evil, but overcome evil with good.

## Chapter 13

1. Let every soul be subject to the governing authorities. For there is no authority except from God, and the authorities that exist are appointed by God.

2. Therefore whoever resists the authority resists the ordinance of God, and those who resist will bring judgment on themselves.

3. For rulers are not a terror to good works, but to evil. Do you want to be unafraid of the authority? Do what is good, and you will have praise from the same.

4. For he is God's minister to you for good. But if you do evil, be afraid; for he does not bear the sword in vain; for he is God's minister, an avenger to execute wrath on him who practices evil.

5. Therefore you must be subject, not only because of wrath but also for conscience' sake.

6. For because of this you also pay taxes, for they are God's ministers attending continually to this very thing.

7. Render therefore to all their due: taxes to whom taxes are due, customs to whom customs, fear to whom fear, honor to whom honor.

8. Owe no one anything except to love one another, for he who loves another has fulfilled the law.

9. For the commandments, "You shall not commit adultery," "You shall not murder," "You shall not steal," "You shall not bear false witness," "You shall not covet," and if there is any other commandment, are all summed up in this saying, namely, "You shall love your neighbor as yourself."

10. Love does no harm to a neighbor; therefore love is the fulfillment of the law.

11. And do this, knowing the time, that now it is high time to awake out of sleep; for now our salvation is nearer than when we first believed.

12. The night is far spent, the day is at hand. Therefore let us cast off the works of darkness, and let us put on the armor of light.

13. Let us walk properly, as in the day, not in revelry and drunkenness, not in lewdness and lust, not in strife and envy.

14. But put on the Lord Jesus Christ, and make no provision for the flesh, to fulfill its lusts.

## Chapter 14

1. Receive one who is weak in the faith, but not to disputes over doubtful things.

2. For one believes he may eat all things, but he who is weak eats only vegetables.

3. Let not him who eats despise him who does not eat, and let not him who does not eat judge him who eats; for God has received him.

4. Who are you to judge another's servant? To his own master he stands or falls. Indeed, he will be made to stand, for God is able to make him stand.

5. One person esteems one day above another; another esteems every day alike. Let each be fully convinced in his own mind.

6. He who observes the day, observes it to the Lord; and he who does not observe the day, to the Lord he does not observe it. He who eats, eats to the Lord, for he gives God thanks; and he who does not eat, to the Lord he does not eat, and gives God thanks.

7. For none of us lives to himself, and no one dies to himself.

8. For if we live, we live to the Lord; and if we die, we die to the Lord. Therefore, whether we live or die, we are the Lord's.

9. For to this end Christ died and rose and lived again, that He might be Lord of both the dead and the living.

10. But why do you judge your brother? Or why do you show contempt for your brother? For we shall all stand before the judgment seat of Christ.

11. For it is written: "As I live, says the LORD, Every knee shall bow to Me, And every tongue shall confess to God."

12. So then each of us shall give account of himself to God.

13. Therefore let us not judge one another anymore, but rather resolve this, not to put a stumbling block or a cause to fall in our brother's way.

14. I know and am convinced by the Lord Jesus that there is nothing unclean of itself; but to him who considers anything to be unclean, to him it is unclean.

15. Yet if your brother is grieved because of your food, you are no longer walking in love. Do not destroy with your food the one for whom Christ died.

16. Therefore do not let your good be spoken of as evil;

17. for the kingdom of God is not eating and drinking, but righteousness and peace and joy in the Holy Spirit.

18. For he who serves Christ in these things is acceptable to God and approved by men.

19. Therefore let us pursue the things which make for peace and the things by which one may edify another.

20. Do not destroy the work of God for the sake of food. All things indeed are pure, but it is evil for the man who eats with offense.

21. It is good neither to eat meat nor drink wine nor do anything by which your brother stumbles or is offended or is made weak.

22. Do you have faith? Have it to yourself before God. Happy is he who does not condemn himself in what he approves.

23. But he who doubts is condemned if he eats, because he does not eat from faith; for whatever is not from faith is sin.

## Chapter 15

1. We then who are strong ought to bear with the scruples of the weak, and not to please ourselves.

2. Let each of us please his neighbor for his good, leading to edification.

3. For even Christ did not please Himself; but as it is written, "The reproaches of those who reproached You fell on Me."

4. For whatever things were written before were written for our learning, that we through the patience and comfort of the Scriptures might have hope.

5. Now may the God of patience and comfort grant you to be like-minded toward one another, according to Christ Jesus,

6. that you may with one mind and one mouth glorify the God and Father of our Lord Jesus Christ.

7. Therefore receive one another, just as Christ also received us, to the glory of God.

8. Now I say that Jesus Christ has become a servant to the circumcision for the truth of God, to confirm the promises made to the fathers,

9. and that the Gentiles might glorify God for His mercy, as it is written: "For this reason I will confess to You among the Gentiles, And sing to Your name."

10. And again he says: "Rejoice, O Gentiles, with His people!"

11. And again: "Praise the LORD, all you Gentiles! Laud Him, all you peoples!"

12. And again, Isaiah says: "There shall be a root of Jesse; And He who shall rise to reign over the Gentiles, In Him the Gentiles shall hope."

13. Now may the God of hope fill you with all joy and peace in believing, that you may abound in hope by the power of the Holy Spirit.

14. Now I myself am confident concerning you, my brethren, that you also are full of goodness, filled with all knowledge, able also to admonish one another.

15. Nevertheless, brethren, I have written more boldly to you on some points, as reminding you, because of the grace given to me by God,

16. that I might be a minister of Jesus Christ to the Gentiles, ministering the gospel of God, that the offering of the Gentiles might be acceptable, sanctified by the Holy Spirit.

17. Therefore I have reason to glory in Christ Jesus in the things which pertain to God.

18. For I will not dare to speak of any of those things which Christ has not accomplished through me, in word and deed, to make the Gentiles obedient--

19. in mighty signs and wonders, by the power of the Spirit of God, so that from Jerusalem and round about to Illyricum I have fully preached the gospel of Christ.

20. And so I have made it my aim to preach the gospel, not where Christ was named, lest I should build on another man's foundation,

21. but as it is written: "To whom He was not announced, they shall see; And those who have not heard shall understand."

22. For this reason I also have been much hindered from coming to you.

23. But now no longer having a place in these parts, and having a great desire these many years to come to you,

24. whenever I journey to Spain, I shall come to you. For I hope to see you on my journey, and to be helped on my way there by you, if first I may enjoy your company for a while.

25. But now I am going to Jerusalem to minister to the saints.

26. For it pleased those from Macedonia and Achaia to make a certain contribution for the poor among the saints who are in Jerusalem.

27. It pleased them indeed, and they are their debtors. For if the Gentiles have been partakers of their spiritual things, their duty is also to minister to them in material things.

28. Therefore, when I have performed this and have sealed to them this fruit, I shall go by way of you to Spain.

29. But I know that when I come to you, I shall come in the fullness of the blessing of the gospel of Christ.

30. Now I beg you, brethren, through the Lord Jesus Christ, and through the love of the Spirit, that you strive together with me in prayers to God for me,

31. that I may be delivered from those in Judea who do not believe, and that my service for Jerusalem may be acceptable to the saints,

32. that I may come to you with joy by the will of God, and may be refreshed together with you.

33. Now the God of peace be with you all. Amen.

## Chapter 16

1. I commend to you Phoebe our sister, who is a servant of the church in Cenchrea,

2. that you may receive her in the Lord in a manner worthy of the saints, and assist her in whatever business she has need of you; for indeed she has been a helper of many and of myself also.

3. Greet Priscilla and Aquila, my fellow workers in Christ Jesus,

4. who risked their own necks for my life, to whom not only I give thanks, but also all the churches of the Gentiles.

5. Likewise greet the church that is in their house. Greet my beloved Epaenetus, who is the firstfruits of Achaia to Christ.

6. Greet Mary, who labored much for us.

7. Greet Andronicus and Junia, my countrymen and my fellow prisoners, who are of note among the apostles, who also were in Christ before me.

8. Greet Amplias, my beloved in the Lord.

9. Greet Urbanus, our fellow worker in Christ, and Stachys, my beloved.

10. Greet Apelles, approved in Christ. Greet those who are of the household of Aristobulus.

11. Greet Herodion, my countryman. Greet those who are of the household of Narcissus who are in the Lord.

12. Greet Tryphena and Tryphosa, who have labored in the Lord. Greet the beloved Persis, who labored much in the Lord.

13. Greet Rufus, chosen in the Lord, and his mother and mine.

14. Greet Asyncritus, Phlegon, Hermas, Patrobas, Hermes, and the brethren who are with them.

15. Greet Philologus and Julia, Nereus and his sister, and Olympas, and all the saints who are with them.

16. Greet one another with a holy kiss. The churches of Christ greet you.

17. Now I urge you, brethren, note those who cause divisions and offenses, contrary to the doctrine which you learned, and avoid them.

18. For those who are such do not serve our Lord Jesus Christ, but their own belly, and by smooth words and flattering speech deceive the hearts of the simple.

19. For your obedience has become known to all. Therefore I am glad on your behalf; but I want you to be wise in what is good, and simple concerning evil.

20. And the God of peace will crush Satan under your feet shortly. The grace of our Lord Jesus Christ be with you. Amen.

21. Timothy, my fellow worker, and Lucius, Jason, and Sosipater, my countrymen, greet you.

22. I, Tertius, who wrote this epistle, greet you in the Lord.

23. Gaius, my host and the host of the whole church, greets you. Erastus, the treasurer of the city, greets you, and Quartus, a brother.

24. The grace of our Lord Jesus Christ be with you all. Amen.

25. Now to Him who is able to establish you according to my gospel and the preaching of Jesus Christ, according to the revelation of the mystery kept secret since the world began

26. but now made manifest, and by the prophetic Scriptures made known to all nations, according to the commandment of the everlasting God, for obedience to the faith--

27. to God, alone wise, be glory through Jesus Christ forever. Amen.


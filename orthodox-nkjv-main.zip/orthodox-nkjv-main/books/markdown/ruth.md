# ruth

## Chapter 1

1. Now it came to pass, in the days when the judges ruled, that there was a famine in the land. And a certain man of Bethlehem, Judah, went to dwell in the country of Moab, he and his wife and his two sons.

2. The name of the man was Elimelech, the name of his wife was Naomi, and the names of his two sons were Mahlon and Chilion--Ephrathites of Bethlehem, Judah. And they went to the country of Moab and remained there.

3. Then Elimelech, Naomi's husband, died; and she was left, and her two sons.

4. Now they took wives of the women of Moab: the name of the one was Orpah, and the name of the other Ruth. And they dwelt there about ten years.

5. Then both Mahlon and Chilion also died; so the woman survived her two sons and her husband.

6. Then she arose with her daughters-in-law that she might return from the country of Moab, for she had heard in the country of Moab that the LORD had visited His people by giving them bread.

7. Therefore she went out from the place where she was, and her two daughters-in-law with her; and they went on the way to return to the land of Judah.

8. And Naomi said to her two daughters-in-law, "Go, return each to her mother's house. The LORD deal kindly with you, as you have dealt with the dead and with me.

9. The LORD grant that you may find rest, each in the house of her husband." So she kissed them, and they lifted up their voices and wept.

10. And they said to her, "Surely we will return with you to your people."

11. But Naomi said, "Turn back, my daughters; why will you go with me? Are there still sons in my womb, that they may be your husbands?

12. Turn back, my daughters, go--for I am too old to have a husband. If I should say I have hope, if I should have a husband tonight and should also bear sons,

13. would you wait for them till they were grown? Would you restrain yourselves from having husbands? No, my daughters; for it grieves me very much for your sakes that the hand of the LORD has gone out against me!"

14. Then they lifted up their voices and wept again; and Orpah kissed her mother-in-law, but Ruth clung to her.

15. And she said, "Look, your sister-in-law has gone back to her people and to her gods; return after your sister-in-law."

16. But Ruth said: "Entreat me not to leave you, Or to turn back from following after you; For wherever you go, I will go; And wherever you lodge, I will lodge; Your people shall be my people, And your God, my God.

17. Where you die, I will die, And there will I be buried. The LORD do so to me, and more also, If anything but death parts you and me."

18. When she saw that she was determined to go with her, she stopped speaking to her.

19. Now the two of them went until they came to Bethlehem. And it happened, when they had come to Bethlehem, that all the city was excited because of them; and the women said, "Is this Naomi?"

20. But she said to them, "Do not call me Naomi; call me Mara, for the Almighty has dealt very bitterly with me.

21. I went out full, and the LORD has brought me home again empty. Why do you call me Naomi, since the LORD has testified against me, and the Almighty has afflicted me?"

22. So Naomi returned, and Ruth the Moabitess her daughter-in-law with her, who returned from the country of Moab. Now they came to Bethlehem at the beginning of barley harvest.

## Chapter 2

1. There was a relative of Naomi's husband, a man of great wealth, of the family of Elimelech. His name was Boaz.

2. So Ruth the Moabitess said to Naomi, "Please let me go to the field, and glean heads of grain after him in whose sight I may find favor." And she said to her, "Go, my daughter."

3. Then she left, and went and gleaned in the field after the reapers. And she happened to come to the part of the field belonging to Boaz, who was of the family of Elimelech.

4. Now behold, Boaz came from Bethlehem, and said to the reapers, "The LORD be with you!" And they answered him, "The LORD bless you!"

5. Then Boaz said to his servant who was in charge of the reapers, "Whose young woman is this?"

6. So the servant who was in charge of the reapers answered and said, "It is the young Moabite woman who came back with Naomi from the country of Moab.

7. And she said, "Please let me glean and gather after the reapers among the sheaves.' So she came and has continued from morning until now, though she rested a little in the house."

8. Then Boaz said to Ruth, "You will listen, my daughter, will you not? Do not go to glean in another field, nor go from here, but stay close by my young women.

9. Let your eyes be on the field which they reap, and go after them. Have I not commanded the young men not to touch you? And when you are thirsty, go to the vessels and drink from what the young men have drawn."

10. So she fell on her face, bowed down to the ground, and said to him, "Why have I found favor in your eyes, that you should take notice of me, since I am a foreigner?"

11. And Boaz answered and said to her, "It has been fully reported to me, all that you have done for your mother-in-law since the death of your husband, and how you have left your father and your mother and the land of your birth, and have come to a people whom you did not know before.

12. The LORD repay your work, and a full reward be given you by the LORD God of Israel, under whose wings you have come for refuge."

13. Then she said, "Let me find favor in your sight, my lord; for you have comforted me, and have spoken kindly to your maidservant, though I am not like one of your maidservants."

14. Now Boaz said to her at mealtime, "Come here, and eat of the bread, and dip your piece of bread in the vinegar." So she sat beside the reapers, and he passed parched grain to her; and she ate and was satisfied, and kept some back.

15. And when she rose up to glean, Boaz commanded his young men, saying, "Let her glean even among the sheaves, and do not reproach her.

16. Also let grain from the bundles fall purposely for her; leave it that she may glean, and do not rebuke her."

17. So she gleaned in the field until evening, and beat out what she had gleaned, and it was about an ephah of barley.

18. Then she took it up and went into the city, and her mother-in-law saw what she had gleaned. So she brought out and gave to her what she had kept back after she had been satisfied.

19. And her mother-in-law said to her, "Where have you gleaned today? And where did you work? Blessed be the one who took notice of you." So she told her mother-in-law with whom she had worked, and said, "The man's name with whom I worked today is Boaz."

20. Then Naomi said to her daughter-in-law, "Blessed be he of the LORD, who has not forsaken His kindness to the living and the dead!" And Naomi said to her, "This man is a relation of ours, one of our close relatives."

21. Ruth the Moabitess said, "He also said to me, "You shall stay close by my young men until they have finished all my harvest."'

22. And Naomi said to Ruth her daughter-in-law, "It is good, my daughter, that you go out with his young women, and that people do not meet you in any other field."

23. So she stayed close by the young women of Boaz, to glean until the end of barley harvest and wheat harvest; and she dwelt with her mother-in-law.

## Chapter 3

1. Then Naomi her mother-in-law said to her, "My daughter, shall I not seek security for you, that it may be well with you?

2. Now Boaz, whose young women you were with, is he not our relative? In fact, he is winnowing barley tonight at the threshing floor.

3. Therefore wash yourself and anoint yourself, put on your best garment and go down to the threshing floor; but do not make yourself known to the man until he has finished eating and drinking.

4. Then it shall be, when he lies down, that you shall notice the place where he lies; and you shall go in, uncover his feet, and lie down; and he will tell you what you should do."

5. And she said to her, "All that you say to me I will do."

6. So she went down to the threshing floor and did according to all that her mother-in-law instructed her.

7. And after Boaz had eaten and drunk, and his heart was cheerful, he went to lie down at the end of the heap of grain; and she came softly, uncovered his feet, and lay down.

8. Now it happened at midnight that the man was startled, and turned himself; and there, a woman was lying at his feet.

9. And he said, "Who are you?" So she answered, "I am Ruth, your maidservant. Take your maidservant under your wing, for you are a close relative."

10. Then he said, "Blessed are you of the LORD, my daughter! For you have shown more kindness at the end than at the beginning, in that you did not go after young men, whether poor or rich.

11. And now, my daughter, do not fear. I will do for you all that you request, for all the people of my town know that you are a virtuous woman.

12. Now it is true that I am a close relative; however, there is a relative closer than I.

13. Stay this night, and in the morning it shall be that if he will perform the duty of a close relative for you--good; let him do it. But if he does not want to perform the duty for you, then I will perform the duty for you, as the LORD lives! Lie down until morning."

14. So she lay at his feet until morning, and she arose before one could recognize another. Then he said, "Do not let it be known that the woman came to the threshing floor."

15. Also he said, "Bring the shawl that is on you and hold it." And when she held it, he measured six ephahs of barley, and laid it on her. Then she went into the city.

16. When she came to her mother-in-law, she said, "Is that you, my daughter?" Then she told her all that the man had done for her.

17. And she said, "These six ephahs of barley he gave me; for he said to me, "Do not go empty-handed to your mother-in-law."'

18. Then she said, "Sit still, my daughter, until you know how the matter will turn out; for the man will not rest until he has concluded the matter this day."

## Chapter 4

1. Now Boaz went up to the gate and sat down there; and behold, the close relative of whom Boaz had spoken came by. So Boaz said, "Come aside, friend, sit down here." So he came aside and sat down.

2. And he took ten men of the elders of the city, and said, "Sit down here." So they sat down.

3. Then he said to the close relative, "Naomi, who has come back from the country of Moab, sold the piece of land which belonged to our brother Elimelech.

4. And I thought to inform you, saying, "Buy it back in the presence of the inhabitants and the elders of my people. If you will redeem it, redeem it; but if you will not redeem it, then tell me, that I may know; for there is no one but you to redeem it, and I am next after you."' And he said, "I will redeem it."

5. Then Boaz said, "On the day you buy the field from the hand of Naomi, you must also buy it from Ruth the Moabitess, the wife of the dead, to perpetuate the name of the dead through his inheritance."

6. And the close relative said, "I cannot redeem it for myself, lest I ruin my own inheritance. You redeem my right of redemption for yourself, for I cannot redeem it."

7. Now this was the custom in former times in Israel concerning redeeming and exchanging, to confirm anything: one man took off his sandal and gave it to the other, and this was a confirmation in Israel.

8. Therefore the close relative said to Boaz, "Buy it for yourself." So he took off his sandal.

9. And Boaz said to the elders and all the people, "You are witnesses this day that I have bought all that was Elimelech's, and all that was Chilion's and Mahlon's, from the hand of Naomi.

10. Moreover, Ruth the Moabitess, the widow of Mahlon, I have acquired as my wife, to perpetuate the name of the dead through his inheritance, that the name of the dead may not be cut off from among his brethren and from his position at the gate. You are witnesses this day."

11. And all the people who were at the gate, and the elders, said, "We are witnesses. The LORD make the woman who is coming to your house like Rachel and Leah, the two who built the house of Israel; and may you prosper in Ephrathah and be famous in Bethlehem.

12. May your house be like the house of Perez, whom Tamar bore to Judah, because of the offspring which the LORD will give you from this young woman."

13. So Boaz took Ruth and she became his wife; and when he went in to her, the LORD gave her conception, and she bore a son.

14. Then the women said to Naomi, "Blessed be the LORD, who has not left you this day without a close relative; and may his name be famous in Israel!

15. And may he be to you a restorer of life and a nourisher of your old age; for your daughter-in-law, who loves you, who is better to you than seven sons, has borne him."

16. Then Naomi took the child and laid him on her bosom, and became a nurse to him.

17. Also the neighbor women gave him a name, saying, "There is a son born to Naomi." And they called his name Obed. He is the father of Jesse, the father of David.

18. Now this is the genealogy of Perez: Perez begot Hezron;

19. Hezron begot Ram, and Ram begot Amminadab;

20. Amminadab begot Nahshon, and Nahshon begot Salmon;

21. Salmon begot Boaz, and Boaz begot Obed;

22. Obed begot Jesse, and Jesse begot David.


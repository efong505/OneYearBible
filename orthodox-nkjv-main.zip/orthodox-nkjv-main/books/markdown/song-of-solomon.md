# song-of-solomon

## Chapter 1

1. The song of songs, which is Solomon's.

2. Let him kiss me with the kisses of his mouth-- For your love is better than wine.

3. Because of the fragrance of your good ointments, Your name is ointment poured forth; Therefore the virgins love you.

4. Draw me away! We will run after you. The king has brought me into his chambers. We will be glad and rejoice in you. We will remember 1your love more than wine. Rightly do they love 1you.

5. I am dark, but lovely, O daughters of Jerusalem, Like the tents of Kedar, Like the curtains of Solomon.

6. Do not look upon me, because I am dark, Because the sun has tanned me. My mother's sons were angry with me; They made me the keeper of the vineyards, But my own vineyard I have not kept.

7. Tell me, O you whom I love, Where you feed your flock, Where you make it rest at noon. For why should I be as one who veils herself By the flocks of your companions?

8. If you do not know, O fairest among women, Follow in the footsteps of the flock, And feed your little goats Beside the shepherds' tents.

9. I have compared you, my love, To my filly among Pharaoh's chariots.

10. Your cheeks are lovely with ornaments, Your neck with chains of gold.

11. We will make you ornaments of gold With studs of silver.

12. While the king is at his table, My spikenard sends forth its fragrance.

13. A bundle of myrrh is my beloved to me, That lies all night between my breasts.

14. My beloved is to me a cluster of henna blooms In the vineyards of En Gedi.

15. Behold, you are fair, my love! Behold, you are fair! You have dove's eyes.

16. Behold, you are handsome, my beloved! Yes, pleasant! Also our bed is green.

17. The beams of our houses are cedar, And our rafters of fir.

## Chapter 2

1. I am the rose of Sharon, And the lily of the valleys.

2. Like a lily among thorns, So is my love among the daughters.

3. Like an apple tree among the trees of the woods, So is my beloved among the sons. I sat down in his shade with great delight, And his fruit was sweet to my taste.

4. He brought me to the banqueting house, And his banner over me was love.

5. Sustain me with cakes of raisins, Refresh me with apples, For I am lovesick.

6. His left hand is under my head, And his right hand embraces me.

7. I charge you, O daughters of Jerusalem, By the gazelles or by the does of the field, Do not stir up nor awaken love Until it pleases.

8. The voice of my beloved! Behold, he comes Leaping upon the mountains, Skipping upon the hills.

9. My beloved is like a gazelle or a young stag. Behold, he stands behind our wall; He is looking through the windows, Gazing through the lattice.

10. My beloved spoke, and said to me: "Rise up, my love, my fair one, And come away.

11. For lo, the winter is past, The rain is over and gone.

12. The flowers appear on the earth; The time of singing has come, And the voice of the turtledove Is heard in our land.

13. The fig tree puts forth her green figs, And the vines with the tender grapes Give a good smell. Rise up, my love, my fair one, And come away!

14. "O my dove, in the clefts of the rock, In the secret places of the cliff, Let me see your face, Let me hear your voice; For your voice is sweet, And your face is lovely."

15. Catch us the foxes, The little foxes that spoil the vines, For our vines have tender grapes.

16. My beloved is mine, and I am his. He feeds his flock among the lilies.

17. Until the day breaks And the shadows flee away, Turn, my beloved, And be like a gazelle Or a young stag Upon the mountains of Bether.

## Chapter 3

1. By night on my bed I sought the one I love; I sought him, but I did not find him.

2. "I will rise now," I said, "And go about the city; In the streets and in the squares I will seek the one I love." I sought him, but I did not find him.

3. The watchmen who go about the city found me; I said, "Have you seen the one I love?"

4. Scarcely had I passed by them, When I found the one I love. I held him and would not let him go, Until I had brought him to the house of my mother, And into the chamber of her who conceived me.

5. I charge you, O daughters of Jerusalem, By the gazelles or by the does of the field, Do not stir up nor awaken love Until it pleases.

6. Who is this coming out of the wilderness Like pillars of smoke, Perfumed with myrrh and frankincense, With all the merchant's fragrant powders?

7. Behold, it is Solomon's couch, With sixty valiant men around it, Of the valiant of Israel.

8. They all hold swords, Being expert in war. Every man has his sword on his thigh Because of fear in the night.

9. Of the wood of Lebanon Solomon the King Made himself a palanquin:

10. He made its pillars of silver, Its support of gold, Its seat of purple, Its interior paved with love By the daughters of Jerusalem.

11. Go forth, O daughters of Zion, And see King Solomon with the crown With which his mother crowned him On the day of his wedding, The day of the gladness of his heart.

## Chapter 4

1. Behold, you are fair, my love! Behold, you are fair! You have dove's eyes behind your veil. Your hair is like a flock of goats, Going down from Mount Gilead.

2. Your teeth are like a flock of shorn sheep Which have come up from the washing, Every one of which bears twins, And none is barren among them.

3. Your lips are like a strand of scarlet, And your mouth is lovely. Your temples behind your veil Are like a piece of pomegranate.

4. Your neck is like the tower of David, Built for an armory, On which hang a thousand bucklers, All shields of mighty men.

5. Your two breasts are like two fawns, Twins of a gazelle, Which feed among the lilies.

6. Until the day breaks And the shadows flee away, I will go my way to the mountain of myrrh And to the hill of frankincense.

7. You are all fair, my love, And there is no spot in you.

8. Come with me from Lebanon, my spouse, With me from Lebanon. Look from the top of Amana, From the top of Senir and Hermon, From the lions' dens, From the mountains of the leopards.

9. You have ravished my heart, My sister, my spouse; You have ravished my heart With one look of your eyes, With one link of your necklace.

10. How fair is your love, My sister, my spouse! How much better than wine is your love, And the scent of your perfumes Than all spices!

11. Your lips, O my spouse, Drip as the honeycomb; Honey and milk are under your tongue; And the fragrance of your garments Is like the fragrance of Lebanon.

12. A garden enclosed Is my sister, my spouse, A spring shut up, A fountain sealed.

13. Your plants are an orchard of pomegranates With pleasant fruits, Fragrant henna with spikenard,

14. Spikenard and saffron, Calamus and cinnamon, With all trees of frankincense, Myrrh and aloes, With all the chief spices--

15. A fountain of gardens, A well of living waters, And streams from Lebanon.

16. Awake, O north wind, And come, O south! Blow upon my garden, That its spices may flow out. Let my beloved come to his garden And eat its pleasant fruits.

## Chapter 5

1. I have come to my garden, my sister, my spouse; I have gathered my myrrh with my spice; I have eaten my honeycomb with my honey; I have drunk my wine with my milk. Eat, O friends! Drink, yes, drink deeply, O beloved ones!

2. I sleep, but my heart is awake; It is the voice of my beloved! He knocks, saying, "Open for me, my sister, my love, My dove, my perfect one; For my head is covered with dew, My locks with the drops of the night."

3. I have taken off my robe; How can I put it on again? I have washed my feet; How can I defile them?

4. My beloved put his hand By the latch of the door, And my heart yearned for him.

5. I arose to open for my beloved, And my hands dripped with myrrh, My fingers with liquid myrrh, On the handles of the lock.

6. I opened for my beloved, But my beloved had turned away and was gone. My heart leaped up when he spoke. I sought him, but I could not find him; I called him, but he gave me no answer.

7. The watchmen who went about the city found me. They struck me, they wounded me; The keepers of the walls Took my veil away from me.

8. I charge you, O daughters of Jerusalem, If you find my beloved, That you tell him I am lovesick!

9. What is your beloved More than another beloved, O fairest among women? What is your beloved More than another beloved, That you so charge us?

10. My beloved is white and ruddy, Chief among ten thousand.

11. His head is like the finest gold; His locks are wavy, And black as a raven.

12. His eyes are like doves By the rivers of waters, Washed with milk, And fitly set.

13. His cheeks are like a bed of spices, Banks of scented herbs. His lips are lilies, Dripping liquid myrrh.

14. His hands are rods of gold Set with beryl. His body is carved ivory Inlaid with sapphires.

15. His legs are pillars of marble Set on bases of fine gold. His countenance is like Lebanon, Excellent as the cedars.

16. His mouth is most sweet, Yes, he is altogether lovely. This is my beloved, And this is my friend, O daughters of Jerusalem!

## Chapter 6

1. Where has your beloved gone, O fairest among women? Where has your beloved turned aside, That we may seek him with you?

2. My beloved has gone to his garden, To the beds of spices, To feed his flock in the gardens, And to gather lilies.

3. I am my beloved's, And my beloved is mine. He feeds his flock among the lilies.

4. O my love, you are as beautiful as Tirzah, Lovely as Jerusalem, Awesome as an army with banners!

5. Turn your eyes away from me, For they have overcome me. Your hair is like a flock of goats Going down from Gilead.

6. Your teeth are like a flock of sheep Which have come up from the washing; Every one bears twins, And none is barren among them.

7. Like a piece of pomegranate Are your temples behind your veil.

8. There are sixty queens And eighty concubines, And virgins without number.

9. My dove, my perfect one, Is the only one, The only one of her mother, The favorite of the one who bore her. The daughters saw her And called her blessed, The queens and the concubines, And they praised her.

10. Who is she who looks forth as the morning, Fair as the moon, Clear as the sun, Awesome as an army with banners?

11. I went down to the garden of nuts To see the verdure of the valley, To see whether the vine had budded And the pomegranates had bloomed.

12. Before I was even aware, My soul had made me As the chariots of my noble people.

13. Return, return, O Shulamite; Return, return, that we may look upon you! What would you see in the Shulamite-- As it were, the dance of the two camps?

## Chapter 7

1. How beautiful are your feet in sandals, O prince's daughter! The curves of your thighs are like jewels, The work of the hands of a skillful workman.

2. Your navel is a rounded goblet; It lacks no blended beverage. Your waist is a heap of wheat Set about with lilies.

3. Your two breasts are like two fawns, Twins of a gazelle.

4. Your neck is like an ivory tower, Your eyes like the pools in Heshbon By the gate of Bath Rabbim. Your nose is like the tower of Lebanon Which looks toward Damascus.

5. Your head crowns you like Mount Carmel, And the hair of your head is like purple; A king is held captive by your tresses.

6. How fair and how pleasant you are, O love, with your delights!

7. This stature of yours is like a palm tree, And your breasts like its clusters.

8. I said, "I will go up to the palm tree, I will take hold of its branches." Let now your breasts be like clusters of the vine, The fragrance of your breath like apples,

9. And the roof of your mouth like the best wine. The wine goes down smoothly for my beloved, Moving gently the lips of sleepers.

10. I am my beloved's, And his desire is toward me.

11. Come, my beloved, Let us go forth to the field; Let us lodge in the villages.

12. Let us get up early to the vineyards; Let us see if the vine has budded, Whether the grape blossoms are open, And the pomegranates are in bloom. There I will give you my love.

13. The mandrakes give off a fragrance, And at our gates are pleasant fruits, All manner, new and old, Which I have laid up for you, my beloved.

## Chapter 8

1. Oh, that you were like my brother, Who nursed at my mother's breasts! If I should find you outside, I would kiss you; I would not be despised.

2. I would lead you and bring you Into the house of my mother, She who used to instruct me. I would cause you to drink of spiced wine, Of the juice of my pomegranate.

3. His left hand is under my head, And his right hand embraces me.

4. I charge you, O daughters of Jerusalem, Do not stir up nor awaken love Until it pleases.

5. Who is this coming up from the wilderness, Leaning upon her beloved? I awakened you under the apple tree. There your mother brought you forth; There she who bore you brought you forth.

6. Set me as a seal upon your heart, As a seal upon your arm; For love is as strong as death, Jealousy as cruel as the grave; Its flames are flames of fire, A most vehement flame.

7. Many waters cannot quench love, Nor can the floods drown it. If a man would give for love All the wealth of his house, It would be utterly despised.

8. We have a little sister, And she has no breasts. What shall we do for our sister In the day when she is spoken for?

9. If she is a wall, We will build upon her A battlement of silver; And if she is a door, We will enclose her With boards of cedar.

10. I am a wall, And my breasts like towers; Then I became in his eyes As one who found peace.

11. Solomon had a vineyard at Baal Hamon; He leased the vineyard to keepers; Everyone was to bring for its fruit A thousand silver coins.

12. My own vineyard is before me. You, O Solomon, may have a thousand, And those who tend its fruit two hundred.

13. You who dwell in the gardens, The companions listen for your voice-- Let me hear it!

14. Make haste, my beloved, And be like a gazelle Or a young stag On the mountains of spices.


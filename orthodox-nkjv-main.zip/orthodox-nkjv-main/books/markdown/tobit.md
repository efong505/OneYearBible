# tobit

## Chapter 1

1. This is the book of the words of Tobit, the son of Tobiel, the son of Hananiel, the son of Aduel, the son of Gabael, of the seed of Asiel, from the tribe of Naphtali.

2. He was led captive out of Thisbe in the days of Shalmaneser, king of the Assyrians. Thisbe is south of Kedesh Naphtali, in Galilee above Asher.

3. I, Tobit, walked in the paths of truth and righteousness all the days of my life. I did much almsgiving to my brethren and to the people who journeyed with me as exiles to Nineveh, in the country of the Assyrians.

4. In my young days, when I was in my own country, the land of Israel, the entire tribe of my father Naphtali turned away from the house of Jerusalem, which was chosen from all the tribes of Israel, to sacrifice for all the tribes. This temple, the habitation of the Most High God, was sanctified and built for all generations forever.

5. Now all the tribes that joined in the revolt sacrificed the heifer to Baal. The house of Naphtali, the tribe of my father, also revolted.

6. But I alone traveled frequently to Jerusalem for the feast days, as it is written for all of Israel in an everlasting ordinance. I would carry the firstfruits and the tithes of my harvest and the first-shearing.

7. These I would give to the priests, the sons of Aaron, at the altar. I would offer the tenth of all the harvest to the sons of Levi who served at Jerusalem. I would also sell off the second tenth and go and spend it at Jerusalem each year.

8. The third tenth I would give to whom it was fitting, as Deborah the mother of my father commanded me, for I was left an orphan by my father.

9. When I became a man, I took Anna for a wife from my own kindred. With her I became the father of Tobias.

10. When I was taken captive to Nineveh, all my brothers and those from my race ate from the bread of the Gentiles.

11. But I protected myself by not eating it.

12. For I remembered God with all my soul

13. So the Most High gave me grace and comeliness before Shalmaneser, and I became his purchasing agent.

14. I would go into Media. And one time in Rages of Media, I entrusted to Gabael, the brother of Gabrias, ten talents of silver.

15. When Shalmaneser died and his son Sennacherib reigned in his place, the roads were unstable and I could no longer travel to Media. 16In the days of Shalmaneser, I did much almsgiving to my brothers.

16. I would give my bread to the hungry and my clothing to the naked. If I saw anyone of my people dead, cast outside the wall of Nineveh, I would bury him.

17. If King Sennacherib put someone to death when he came trying to escape from Judea, I buried them secretly. For in his anger, he put many to death, and the bodies were sought by the king; but they were not found.

18. But one of the men of Nineveh went and made known to the king concerning my burying them. So I hid, and when I knew I was being sought to be put to death I was frightened and ran away.

19. All of my possessions were seized and I had nothing left, except Anna my wife and Tobias my son.

20. But not even fifty days passed before two of King Sennacherib's sons had killed him and escaped into the mountains of Ararat. Thus Esarhaddon his son reigned in his place. He appointed Ahikar, the son of my brother Anael, to be over all the accounts of his kingdom and over the entire government.

21. Ahikar then entreated on my behalf, so I came to Nineveh. Now Ahikar was the wine-pourer, the keeper of the signet ring, the administrator and the accountant. Esarhaddon appointed him second to himself, and he was my nephew.

## Chapter 2

1. When I arrived at my house, my wife Anna and my son Tobias were given back to me. It was the Feast of Pentecost, which is the holy feast of the seven weeks. A good dinner was prepared for me, so I sat down at the table to eat.

2. When I saw the abundance of meat, I said to my son, “Go and bring whomever you may find of our needy brethren who are mindful of the Lord. Behold, I will wait for you.”

3. But he came back and said, “O father, one of our people was strangled and thrown into the marketplace.”

4. So before I even tasted anything, I jumped up and carried the corpse into a room until sunset.

5. Then I returned, bathed myself, and ate my bread in sorrow.

6. Then I remembered the prophecy of Amos, how he said, “Your feasts will be turned into mourning, And all y our gladness into a song of grief.” So I wept.

7. When the sun went down, I departed, and after digging a grave, I buried him.

8. My neighbors laughed at me and said, “He is no longer afraid to be put to death for doing such a thing. He ran away before, and now, behold, he is burying the dead again.”

9. On the same night that I buried him, I returned home. But since I was defiled, I slept by the wall of the courtyard with my face uncovered.

10. However, I did not see the sparrows on the wall, for while my eyes were open the sparrows discharged their droppings into my eyes, and they became white films in my eyes. I went to physicians, but they could not help me. Then Ahikar supported me until he left for Elymais.

11. Then my wife Anna worked for hire at what women do.

12. She would send her work to the owners and they would pay her. On one occasion they paid her wages and also gave her a small goat.

13. But when she returned to me, it began to bleat. So I said to her, “Where did this goat come from? Is it not stolen? Return it to the owners, for it is unlawful to eat what is stolen.”

14. But she replied, “It was given to me as a gift. It was in addition to my wages.” But I did not believe her, telling her to return it to its owners. I blushed in embarrassment for her sake. So she answered and said to me, “Are your acts of charity and righteous deeds lawful? Behold, you are a know-it-all!”

## Chapter 3

1. Then I wept in my sorrow, and with pain I prayed, saying:

2. “O Lord, You are righteous. So too are all Your works. All Your ways are mercy and truth. Your judgments are true and just forever.

3. Remember me and look upon me with favor. Do not punish me for my sins and my ignorance, nor those sins of my fathers which they committed against You.

4. Because they disobeyed Your commands, so You gave us as spoil, captivity and death. You made us a byword of disgrace among all the nations in which we were scattered.

5. Now Your judgments concerning my sins are many and they are true, because I did them, and so did my fathers. For we did not keep Your commandments. Indeed we did not walk in truth before You.

6. Now do with me as is best before You. Command that my spirit be taken up, so I may be released and become soil, since it is better for me to die than to live. For I have heard false insults, and there is much sorrow within me. Command that I be freed from distress to now enter into the eternal place. Do not turn Your face away from me.”

7. On the same day, in Ecbatana of Media, Sarah, the daughter of Raguel, happened to be insulted by her father's maids.

8. She was married to seven husbands, but before they could be with her as a wife, Asmodeus, the evil demon, killed them. So they said to her, “Do you not recollect that you strangled these husbands? You have already had seven husbands, but you received no profit from any of them.

9. Therefore, why punish us? If they are dead, go with them. May we never see a son or daughter of yours.”

10. When she heard this, she was so distressed that she considered hanging herself. But she said, “I am the only one of my father. If I do this, it will be a disgrace to him, and I will bring down his old age with sorrow into Hades.”

11. So she prayed by her window and said: Sarah's Prayer “Blessed are You, O Lord my God. Blessed is Your holy and precious name unto the ages. May all Your works bless You forever.

12. Now, O Lord, I offer myself completely to You.

13. Command that I be released from the land, that I may not hear such disgrace any more.

14. O Lord, You know that I am innocent of any sin with a man.

15. I have not defiled my name nor the name of my father in the land of my captivity. I am my father's only offspring. He has no other child who will be his heir. Neither does he have a brother close at hand, nor an adopted son that I might keep myself as a wife to him. Seven of my husbands have already perished. What should I live for? But if it does not seem good to You to kill me, command that I be looked upon with favor, and that mercy be shown to me, so I may no longer hear disgrace.”

16. The prayer of both was heard in the presence of the great glory of Raphael,

17. and he was sent to heal the two of them: to remove the white films from Tobit; to give Sarah of Raguel to Tobias the son of Tobit as a wife; and to bind Asmodeus the evil demon, for it fell upon Tobias to inherit her. At that same time Tobit returned and entered his house, and Sarah of Raguel came down from her upstairs room.

## Chapter 4

1. On that day Tobit remembered the silver he had entrusted to Gabael at Rages of Media.

2. So he said to himself, “I requested death for myself. Why do I not call my son Tobias to make this known to him before I die?”

3. So he summoned him and said, “My son, if I die, bury me, but do not disregard your mother. Honor her all the days of your life. Do what is pleasing to her, but do not grieve her.

4. Remember, my son, that she experienced many dangers for you while you were in the womb. When she dies, bury her beside me in the same grave.

5. My son, remember the Lord our God all your days, and do not desire to sin or to disobey His commandments. Do righteousness all the days of your life, and do not walk in the ways of wrongdoing.

6. For if you walk in the truth, you will be successful in your works.

7. Do almsgiving from your possessions to all who do righteousness. When you do almsgiving, do not let your eye be envious. Do not turn your face away from any poor man, so the face of God will not be turned away from you.

8. Do almsgiving based on the quantity of your possessions. If you possess only a few, do not be afraid to give according to the little you have.

9. You are storing up a good treasure for yourself in the day of necessity.

10. For almsgiving delivers us from death and prevents us from entering into the darkness.

11. Indeed, almsgiving is a good gift for all who do it before the Most High.

12. “My son, guard yourself from all fornication, and above all take a wife from among the seed of your fathers. Do not take a foreign woman who is not from the tribe of your father, for we are sons of the prophets. Noah, Abraham, Isaac, and Jacob are our fathers from of old. Remember, my son, that all these took wives from among their brothers and were blessed in their children. Their seed will inherit the land.

13. So now, my son, love your brothers and do not be arrogant in your heart against your brothers, the sons and daughters of your people. Take a wife for yourself from them, for arrogance brings destruction and great disorder, and in such worthlessness there is loss and great defect. For worthlessness is the mother of famine.

14. “Do not keep overnight the wages of any man who works for you, but pay him immediately. If you serve God, He will pay you. Give heed to yourself, my son, in all your works, and be disciplined in all your conduct.

15. What you yourself hate, do not do to anyone. Do not drink wine unto a state of drunkenness, and do not let drunkenness become your traveling companion.

16. From your bread, give to him who is hungry, and from your clothing, give to the naked. If you have more than you need, do almsgiving, and do not let your eye envy the almsgiving when you do it.

17. Spread out your bread on the grave of the righteous, but do not give it to sinners.

18. “Seek counsel from every sensible man, and do not treat any useful advice with contempt.

19. At every opportunity bless the Lord God, but more than this ask that your ways may become straight, and that all your paths and purposes may prosper. For not every nation has understanding. But the Lord Himself gives all that is good, and as He desires He humbles whomever He will. Now my son, let none of my commandments be removed from your heart.

20. “Now let me point out to you the ten talents of silver I entrusted to Gabael the son of Gabrias, in Rages of Media.

21. Do not fear, my son, that we have become poor. For you are very rich if you fear God. Stay away from every sin, and do what is pleasing before Him.”

## Chapter 5

1. Tobias answered him and said, “O father, I will do everything you have commanded me.

2. But how will I be able to obtain the silver, for I do not know him?”

3. Then he gave him the record of the debt and said to him, “Find for yourself a man who will travel with you, and I will pay him his wages as long as I remain alive. Now go and obtain the silver.”

4. Then Tobias went to look for a man and found Raphael, who was an angel. But he did not know it.

5. So Tobias said to him, “Can you go with me to Rages of Media? Are you acquainted with those places?” 6The angel said to him, “I will go with you. I am acquainted with the roadways and I have lodged with our brother Gabael.” 7Tobias said to him, “Wait for me and I will tell my father.” 8He said to him, “Do so, but do not delay.”

6. So he went to his father and said, “Behold, I have found someone who will go with me.” But his father said, “Call him to me, that I may know what tribe he belongs to, and if he is trustworthy enough to go with you.”

7. So he invited him, and Raphael came in. They greeted one another cordially.

8. Tobit then said to him, “Brother, to what tribe and kindred do you belong?”

9. Raphael responded, “Do you seek a tribe and a family, or a hired man to go with your son?” Tobit replied, “Brother, I wish to know your people and your name.”

10. Then he said, “I am Azarias, the son of Ananias the Great, one of your relatives.”

11. So Tobit said to him, “You are most welcome, my brother. Do be not angry with me for seeking to learn of your tribe and your family. As it turns out, you are a brother of mine from a good and upright family. For I knew Ananias and Jonathan, the sons of Shemiah the Great, since we would journey in common to Jerusalem to worship and to offer the firstborn and the tenth of our harvest. They were not led astray in the deception of our brothers. My brother, you are from a good root.

12. “But tell me, what shall I give you as wages? A drachma a day and expenses for you and my son?

13. I will even add more to your pay, if you both return in good health.”

14. Thus they were well pleased. Then he said to Tobias, “Prepare for the journey, and may it be prosperous.” So his son prepared the things for the journey. Then his father said to him, “Go with this man, and may the God who dwells in heaven prosper your journey. May His angel journey with you.” They both departed, and the young man's dog went with them.

15. But Anna his mother wept and said to Tobit, “Why have you sent our son away, or is he not the staff of our hands when he goes in and out before us?

16. Do not attain silver upon silver, but may it be dirt compared to our son.

17. For as he was given to us to live by the Lord, this is sufficient for our existence.”

18. Tobit said to her, “My sister, do not be concerned. He shall return in good health, and your eyes will see him.

19. For a good angel will go with him, and his journey shall be prosperous. He will return in good health.”

20. So she ceased weeping.

## Chapter 6

1. They went on the journey and came to the Tigris River. So they spent the evening there.

2. The young man went down to wash himself, and a fish jumped up from the river and was determined to swallow the young man.

3. The angel said to him, “Take hold of the fish.” So the young man grabbed the fish and put it on the bank.

4. Then the angel said to him, “Cut open the fish. Take the heart, the liver, and the gall and put them in a safe place.”

5. The young man did as the angel commanded him. Then they cooked the fish and ate it.

6. After this, they traveled together until they came near to Ecbatana.

7. Then the young man said to the angel, “Brother Azarias, what is the purpose of the liver, the heart, and the gall of the fish?”

8. He replied, “If a demon or an evil spirit troubles anyone, the heart and the liver must be used to make smoke before the man or woman, and that person will never be troubled again.

9. As for the gall, use it to anoint a man who has white films on his eyes, and he will be healed.”

10. As they came near Rages,

11. the angel said to the young man, “Brother, we will spend the night with Raguel. He is your relative and with him is his only child, a daughter named Sarah.

12. I will speak for her that she might be given to you as a wife, because her inheritance belongs to you; for you alone are from her people. The girl is beautiful and she is sensible.

13. “So now listen to me, for I will speak to her father. When we return from Rages, we will celebrate the wedding. For I know that Raguel cannot give her to any other man according to the rule of Moses, or he will be subject to death. Thus it is proper that you receive the inheritance rather than another man.”

14. Then the young man said to the angel, “Brother Azarias, I have heard the girl was given seven husbands, and they all perished in the bridal chamber.

15. Now I am the only son of my father, and I fear for myself lest, entering the bridal chamber, I may die even as those before me. For a demon loves her, and he does not harm anyone except those who approach her. Now I fear for myself lest I die and bring the life of my father and mother down into their tomb with grief and sorrow upon me. They have no other son who will bury them.”

16. But the angel said to him, “Do you not remember the words your father commanded you, to take a wife for yourself from among your people? Now listen to me, brother, for she will be a wife to you. As for the demon, have no concern, for this night she will be given to you as a wife.

17. If you enter the bridal chamber, you will take with you ashes of incense, and lay some of it on the heart and liver of the fish. Then you will make smoke, and the demon will smell it and flee and never return.

18. When you approach her, both of you will rise up and cry out to the merciful God. He will save you and be merciful. Do not fear for yourself, for she has been prepared for you from of old. You will save her and she will go with you. I believe that you will have children by her.”

19. As Tobias heard these words, he loved her and his soul was very much united to her.

## Chapter 7

1. Then they went to Ecbatana and came to the house of Raguel. Sarah went ahead to meet them, and after they greeted one another, she escorted them into the house.

2. Raguel said to Edna his wife, “How the young man resembles my cousin Tobit!”

3. Then Raguel asked them, “Where are you from, brothers?” They answered, “We are from the sons of Naphtali who are captives in Nineveh.”

4. Then he said to them, “Do you know Tobit our brother?” They responded, “We know him.”

5. Then he asked, “Is he in good health?” They answered, “He is alive and in good health.” Tobias then added, “He is my father.”

6. Raguel jumped up and kissed him and wept. He blessed him and said to him, “You are the son of a good and noble man!” But when he heard that Tobit had lost his eyesight, he was grieved and wept.

7. Edna his wife and Sarah his daughter also wept, and they received them eagerly.

8. And they killed a ram from the sheep and set many dishes before them.

9. Then Tobias said to Raphael, “Brother Azarias, speak about what you said on the way, and let the matter be completed.”

10. So he told Raguel what he said, and Raguel said to Tobias, “Eat, drink, and be glad, for it is fitting for you to marry my child. However, I must tell you the truth.

11. I gave my daughter to seven men, and when they went in to her, they died during the night. But for now, be glad!”

12. But Tobias said, “I will not eat anything until after you establish an agreement with me.” So Raguel said, “Receive her according to the decree, for you are her relative and she is yours. The merciful God will prosper you in what is good.”

13. So he called Sarah his daughter, and taking her by the hand, he gave her to be a wife for Tobias. Then he said, “Behold, receive her according to the decree of Moses, and bring her before your father.” He then blessed them

14. and summoned his wife Edna. She took a scroll and wrote out the agreement. They sealed it, and then they began to eat.

15. After this, Raguel called his wife Edna and said to her, “Sister, prepare the other room and lead her into it.”

16. She did as he said and led her there. Then Sarah wept, but Edna understood the tears of her daughter and said to her,

17. “Be courageous, my child. May the Lord of heaven and earth give you grace instead of this sorrow of yours. Be courageous, my daughter.”

## Chapter 8

1. When they finished dining, they led Tobias to her.

2. As he went, he remembered the words of Raphael, and put the heart and the liver of the fish upon the embers of the incense and made smoke.

3. When the demon smelled the fragrant scent, he fled to the upper parts of Egypt, and there the angel bound him.

4. While both were enclosed in the room, Tobias rose up from the bed and said, “Arise, sister, and let us pray that the Lord will have mercy upon us.”

5. So Tobias began to pray, saying: “Blessed are You, O God of our fathers, and blessed is Your holy and glorious name unto the ages. The heavens and all Your creatures bless You.

6. You made Adam and gave him Eve as a helper, his wife as a support. From them the seed of mankind came to be. You said, ‘It is not good for the man to be alone. Let Us make a helper for him like himself.’

7. O Lord, I now take this my sister as my wife, not on account of fornication, but in truth. Command that she and I may have mercy, and in this grow old together.”

8. And with him she said, “Amen.”

9. Then both fell asleep for the night.

10. But Raguel rose up and went outside and dug a grave, saying, “He, too, may have died.”

11. Raguel then went back into his house 12and said to his wife Edna, “Send one of the maids and let her see if indeed Tobias is alive. If he is not, let us bury him that no one may know.”

12. So the maid went to the door, and when she opened it she found both of them sleeping.

13. She came out and told the two of them that he was alive.

14. Then Raguel blessed God, saying: “Blessed are You, the God, with every pure and holy blessing. Your holy ones and all Your creatures bless You. All Your angels and Your chosen ones bless You unto all the ages.

15. Blessed are You, for You have made me glad, and it did not turn out for me as I suspected. Rather, You did with us according to Your abundant mercy.

16. Blessed are You, for You had mercy on our two only children. O Lord, show them mercy, and complete their life in health and with gladness and mercy.”

17. Then he ordered his household servants to fill in the grave.

18. After this he provided a wedding feast for them lasting fourteen days.

19. Before the time of the wedding feast was over, Raguel swore an oath and said to Tobias, “You are not to leave from here unless the two of you stay the fourteen days of the wedding feast. 21At that time take half of my belongings and go in good health to your father. The remainder will be yours when I and my wife die.”

## Chapter 9

1. Then Tobias called Raphael and said to him,

2. “Brother Azarias, take a servant and two camels with you and journey to Rages of Media. Find Gabael and bring the silver back to me and bring him to the wedding feast.

3. For Raguel has sworn an oath for me not to go away.

4. But my father is counting the days, and if I delay much longer he will be very distressed.”

5. Then Raphael went and spent the night with Gabael, and gave him the handwritten receipt. So Gabael brought the small sealed bags and gave them to him. 6They both rose early in the morning and went to the wedding feast. Then Tobias blessed his wife.

## Chapter 10

1. Tobit his father was counting each day. But when the days needed to complete the journey ended and they had not returned,

2. he asked, “Has he perhaps been dishonored? Or has Gabael died and no one gave him the silver?”

3. So he was very distressed.

4. Then his wife told him, “The young man has perished. That is why he is delayed.” Then she began to weep for him and said,

5. “Nothing matters to me, my child, the light of my eyes, for I permitted you to go.”

6. So Tobit said to her, “Be silent and have no more thoughts about it. He is in good health.”

7. She replied to him, “You be quiet. Do not deceive me. My child has perished.” Then throughout the day she went outside to the road by which he departed, and during the day she did not eat bread. At night she did not cease lamenting for her son Tobias until the fourteen days of the wedding feast were over, the days Raguel swore him to celebrate there.

8. Then Tobias said to Raguel, “Send me back, for my father and my mother no longer hope they will see me.”

9. But his father-in-law said to him, “Stay with me, and I will send messengers to your father. They will make clear to him how you are doing.” But Tobias said, “No indeed. On the contrary, send me back to my father.”

10. Then Raguel arose and gave Sarah his wife to him, and half of his belongings in servants, cattle, and silver.

11. Then he blessed them and sent them on their way, saying, “May the God of heaven prosper you, my children, before the day I die.”

12. To his daughter he said, “Honor your husband's mother and father, for they are now your parents. Let me hear a good report of you,” and he kissed her.

13. Then Edna said to Tobias, “My beloved brother, may the Lord of heaven bring you back and grant me to see your children from my daughter Sarah, that I may rejoice before the Lord. Behold, I am entrusting my daughter to your care. Do not grieve her.”

14. With this, Tobias went on his way blessing God that He had prospered his journey. Then he blessed Raguel and Edna his wife.

## Chapter 11

1. He traveled until they approached Nineveh. Here Raphael said to Tobias,

2. “My brother, are you not aware of how you left your father?

3. Let us run ahead of your wife and prepare the house.

4. Take the gall of the fish in your hand.” So they proceeded, and the dog followed behind them.

5. Meanwhile Anna sat gazing upon the road for her boy.

6. She perceived that he was coming and said to the father, “Behold, your son is coming, and the man traveling with him!”

7. Raphael said, “I know that the eyes of your father will open.

8. Rub the gall on his eyes. When the eyes sting, he will rub them and cause the white film to fall away. He will then see you.”

9. Then Anna ran up to her son and fell upon his neck and said to him, “I have seen you, my child. From this day, I am now ready to die!” So they both wept.

10. Then Tobit came out of the door. He stumbled, but his son ran up to him.

11. He took hold of his father and dabbed the gall on the eyes of his father, saying, “Father, take courage!”

12. Then as his eyes stung, he rubbed them, and the white films peeled off from the corners of his eyes.

13. When he saw his son, he fell upon his neck, weeping, and said,

14. “Blessed are You, O God, and blessed is Your name unto the ages. Blessed are all Your holy angels, for You scourged me but had mercy on me. Behold, I see Tobias my son.”

15. His son went in rejoicing and told his father the great things that had happened to him in Media.

16. Then Tobit rejoiced and blessed God as he went to meet his daughter-in-law at the gate of Nineveh. But those who saw him as he walked along were amazed that he could see. Tobit gave thanks before them, because God had mercy on him.

17. Then as Tobit drew near to meet Sarah, his daughter-in-law, he blessed her, saying, “May you be in good health, my daughter! Blessed is God who brought you to us, and blessed are your father and your mother.”

18. So there was rejoicing among all his brethren in Nineveh.

19. Even Ahikar and his nephew Nadab came, for the wedding feast for Tobias was kept with gladness for seven days.

## Chapter 12

1. Tobit summoned his son Tobias and said to him, “My son, see to the wages of the man who went with you, and we must add to them.”

2. He replied to him, “My father, it is no harm for me to give him half of what I brought.

3. For he brought me safely to you, healed my wife, and brought me the silver. Likewise he healed you.”

4. The elderly man replied, “He more than earned it.”

5. So he called the angel and said to him, “Take half of everything you brought.”

6. Then Raphael secretly called the two of them, and said to them, “Bless God and give Him thanks. Ascribe greatness to Him and give thanks in the presence of all the living for what He has done for you. It is good to bless God and to exalt His name. Make known the words of God's works honorably and do not delay to give thanks to Him.

7. It is noble to keep hidden the secret of a king, but glorious to unveil the works of God. Do good, and evil will not find you.

8. Prayer is good with fasting, almsgiving, and righteousness. A few prayers with righteousness are better than many with wrongdoing. It is better to do almsgiving than to lay up gold.

9. For almsgiving rescues one from death, and it will wash away every sin. Those who do almsgiving and are righteous will be full of life.

10. But those who sin are enemies of their own life.

11. “I will not hide anything from you. Indeed, I did say that it is good to conceal the secret of a king, but to reveal gloriously the works of God.

12. Now when you and your daughter-in-law Sarah prayed, I brought the remembrance of your prayer before the Holy One. When you also buried the dead, I was likewise present with you.

13. Then too, when you did not hesitate to stand up and leave your dinner so as to depart and care for the dead, your doing what is good did not escape me; but I was with you.

14. Now God sent me to heal you and Sarah your daughter-in-law.

15. I am Raphael, one of the seven holy angels who report the prayers of the saints and who enter before the glory of the Holy One.”

16. The two of them were troubled and fell upon their faces, for they were afraid.

17. But he said to them, “Do not be afraid, for peace shall be with you. But bless God forever.

18. For I did not come of my own good will, but rather by the will of our God. Therefore bless Him forever.

19. All these days I appeared to you I did not eat or drink; but you were seeing a vision.

20. Now give thanks to God, because I am ascending to Him who sent me. Write in a book everything that was accomplished.”

21. Then they stood up, but no longer saw him. 22. They acknowledged the great and wondrous works of God, and how the angel of the Lord had appeared to them.

## Chapter 13

1. Then Tobit with exceeding joy wrote a prayer, saying:

2. “Blessed is God

undefined. Who lives unto the ages,

undefined. And blessed is His kingdom,

undefined. For He scourges, and is merciful;

undefined. He brings down into Hades,

undefined. And leads up.

undefined. There is no one who will escape His hand.

3. Give thanks to Him before the nations,

undefined. O children of Israel,

undefined. For He scattered us among them.

4. Make known His greatness there;

undefined. Exalt Him in the presence of all the living,

undefined. For He is our Lord and God;

undefined. He is our Father unto all the ages.

5. He will scourge us for our wrongdoings,

undefined. But He will again have mercy

undefined. And gather us from all the nations,

undefined. Wherever you were dispersed among them.

6. If you return to Him with all your heart

undefined. And with all your soul,

undefined. To do the truth before Him,

undefined. Then He will turn to y ou

undefined. And not hide His presence from you.

7. Behold for yourself what He will do for you,

undefined. And give thanks to Him fully with the organ of speech.

undefined. Bless the Lord of righteousness,

undefined. And exalt the King of the ages.

8. In the land of my captivity, I give thanks to Him,

undefined. And make known His might and majesty to a nation of sinners.

undefined. Be converted, you sinners,

undefined. And do righteousness before Him.

undefined. Who knows if He will desire you

undefined. And have mercy on you?

9. I exalt my God,

undefined. And my soul exalts the King of heaven

undefined. And will rejoice exceedingly in His majesty.

10. Let all speak of His majesty

undefined. And give thanks to Him in Jerusalem.

undefined. O Jerusalem, the holy city,

undefined. He will scourge you for the deeds of your sons,

undefined. But He will again show mercy to the sons of the righteous.

11. Give thanks to the Lord with goodness

undefined. And bless the King of the ages,

undefined. That His tabernacle may be restored again to you in joy .

12. May He rejoice in ou, the captives,

undefined. And may He love those who are distressed among you

undefined. Unto all generations forever.

13. Many Gentiles will come from afar

undefined. To the name of the Lord God,

undefined. Bearing gifts in their hands

undefined. And offerings to the King of heaven.

undefined. Generations of generations will offer You joyful worship.

14. Cursed are all who hate You;

undefined. Blessed are all who love You forever.

15. Rejoice and be exceedingly glad for the children of the righteous, For they will be gathered together

undefined. And will bless the Lord of the righteous.

undefined. Blessed are those who love You.

undefined. They will rejoice in Your peace.

16. Blessed are the many who grieved over all Your scourges,

undefined. For they will rejoice when they see all Your glory

undefined. And will rejoice forever.

undefined. Let my soul bless God the great King.

17. For Jerusalem will be built with sapphire and emerald,

undefined. And her walls with precious stones,

undefined. And her towers and battlements with pure gold.

undefined. The streets of Jerusalem will be paved

undefined. With beryl, onyx, and stones from Ophir.

18. All her streets will proclaim, ‘Alleluia!’

undefined. And will give praise, saying,

undefined. ‘Blessed is God, who exalted you unto all the ages.’”

## Chapter 14

1. Then Tobit ceased giving thanks.

2. He was fifty-eight years old when he lost his sight, and eight years later he regained it. Tobit did almsgiving, and continued to fear the Lord God, and gave thanks to Him.

3. He grew very old, and called his son and his son's sons, and said, “My son, take your sons. Behold, I have grown old, and I am departing from this life.

4. Depart to Media, my son, for I trust all the words Jonah the prophet spoke concerning Nineveh, that it will be overthrown. But in Media there will be more peace for a time. For our brethren in the land will be dispersed in the earth from the good land. Jerusalem shall be desolate, and the house of God therein will be burned up. It shall be desolate for a time.

5. “But God will again have mercy on them, and He will return them to the land. They will build the house, but not as it was before, until the times of the age are fulfilled. After this, they will return from the captivity and build Jerusalem honorably. The house of God within her will be built as a glorious building for every generation forever, as the prophets said concerning her.

6. All the Gentiles shall return to truly fear the Lord God. They shall bury their idols in the earth, and all the Gentiles will bless the Lord.

7. His people will offer thanks to God, and the Lord will exalt His people. All who love the Lord God in truth and righteousness will rejoice. They will show mercy to our brethren.

8. “So now, my son, depart from Nineveh, since what the prophet Jonah said will doubtless come to pass.

9. But keep the law and the ordinances. Be merciful and righteous, that it may be well with you. Bury me decently and your mother with me, but lodge no longer in Nineveh.

10. My son, observe what Aman did to Ahikar who reared him, how he led him from light into darkness, and how greatly he repaid him. Indeed Ahikar was saved, but as for that man, he was repaid with retribution and descended into the darkness. Manasseh did almsgiving and was saved from the trap of death that was set for him. But Aman fell into the trap and perished.

11. Now then, my children, observe what almsgiving does, and how righteousness delivers us.” After he said these things, his soul departed as he lay on his bed. He was one hundred and fifty-eight years old, and Tobias buried him gloriously.

12. When Anna died, he buried her with his father. Then Tobias departed with his wife and his children to Ecbatana, to Raguel his father-in-law.

13. He grew old honorably and buried the parents of his wife most respectfully. They inherited their estate and that of Tobit his father.

14. Tobias died at Ecbatana of Media when he was one hundred and twenty-seven years old.

15. Before he died, he heard of the destruction of Nineveh, taken by Nebuchadnezzar and Ahasuerus. Thus before his death he rejoiced over Nineveh.


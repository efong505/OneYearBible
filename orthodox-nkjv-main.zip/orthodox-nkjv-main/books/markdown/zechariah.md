# zechariah

## Chapter 1

1. In the eighth month of the second year of Darius, the word of the LORD came to Zechariah the son of Berechiah, the son of Iddo the prophet, saying,

2. "The LORD has been very angry with your fathers.

3. Therefore say to them, "Thus says the LORD of hosts: "Return to Me," says the LORD of hosts, "and I will return to you," says the LORD of hosts.

4. "Do not be like your fathers, to whom the former prophets preached, saying, "Thus says the LORD of hosts: "Turn now from your evil ways and your evil deeds."' But they did not hear nor heed Me," says the LORD.

5. "Your fathers, where are they? And the prophets, do they live forever?

6. Yet surely My words and My statutes, Which I commanded My servants the prophets, Did they not overtake your fathers? "So they returned and said: "Just as the LORD of hosts determined to do to us, According to our ways and according to our deeds, So He has dealt with us."""

7. On the twenty-fourth day of the eleventh month, which is the month Shebat, in the second year of Darius, the word of the LORD came to Zechariah the son of Berechiah, the son of Iddo the prophet:

8. I saw by night, and behold, a man riding on a red horse, and it stood among the myrtle trees in the hollow; and behind him were horses: red, sorrel, and white.

9. Then I said, "My lord, what are these?" So the angel who talked with me said to me, "I will show you what they are."

10. And the man who stood among the myrtle trees answered and said, "These are the ones whom the LORD has sent to walk to and fro throughout the earth."

11. So they answered the Angel of the LORD, who stood among the myrtle trees, and said, "We have walked to and fro throughout the earth, and behold, all the earth is resting quietly."

12. Then the Angel of the LORD answered and said, "O LORD of hosts, how long will You not have mercy on Jerusalem and on the cities of Judah, against which You were angry these seventy years?"

13. And the LORD answered the angel who talked to me, with good and comforting words.

14. So the angel who spoke with me said to me, "Proclaim, saying, "Thus says the LORD of hosts: "I am zealous for Jerusalem And for Zion with great zeal.

15. I am exceedingly angry with the nations at ease; For I was a little angry, And they helped--but with evil intent."

16. "Therefore thus says the LORD: "I am returning to Jerusalem with mercy; My house shall be built in it," says the LORD of hosts, "And a surveyor's line shall be stretched out over Jerusalem."'

17. "Again proclaim, saying, "Thus says the LORD of hosts: "My cities shall again spread out through prosperity; The LORD will again comfort Zion, And will again choose Jerusalem.""'

18. Then I raised my eyes and looked, and there were four horns.

19. And I said to the angel who talked with me, "What are these?" So he answered me, "These are the horns that have scattered Judah, Israel, and Jerusalem."

20. Then the LORD showed me four craftsmen.

21. And I said, "What are these coming to do?" So he said, "These are the horns that scattered Judah, so that no one could lift up his head; but the craftsmen are coming to terrify them, to cast out the horns of the nations that lifted up their horn against the land of Judah to scatter it."

## Chapter 2

1. Then I raised my eyes and looked, and behold, a man with a measuring line in his hand.

2. So I said, "Where are you going?" And he said to me, "To measure Jerusalem, to see what is its width and what is its length."

3. And there was the angel who talked with me, going out; and another angel was coming out to meet him,

4. who said to him, "Run, speak to this young man, saying: "Jerusalem shall be inhabited as towns without walls, because of the multitude of men and livestock in it.

5. For I,' says the LORD, "will be a wall of fire all around her, and I will be the glory in her midst."'

6. "Up, up! Flee from the land of the north," says the LORD; "for I have spread you abroad like the four winds of heaven," says the LORD.

7. "Up, Zion! Escape, you who dwell with the daughter of Babylon."

8. For thus says the LORD of hosts: "He sent Me after glory, to the nations which plunder you; for he who touches you touches the apple of His eye.

9. For surely I will shake My hand against them, and they shall become spoil for their servants. Then you will know that the LORD of hosts has sent Me.

10. "Sing and rejoice, O daughter of Zion! For behold, I am coming and I will dwell in your midst," says the LORD.

11. "Many nations shall be joined to the LORD in that day, and they shall become My people. And I will dwell in your midst. Then you will know that the LORD of hosts has sent Me to you.

12. And the LORD will take possession of Judah as His inheritance in the Holy Land, and will again choose Jerusalem.

13. Be silent, all flesh, before the LORD, for He is aroused from His holy habitation!"

## Chapter 3

1. Then he showed me Joshua the high priest standing before the Angel of the LORD, and Satan standing at his right hand to oppose him.

2. And the LORD said to Satan, "The LORD rebuke you, Satan! The LORD who has chosen Jerusalem rebuke you! Is this not a brand plucked from the fire?"

3. Now Joshua was clothed with filthy garments, and was standing before the Angel.

4. Then He answered and spoke to those who stood before Him, saying, "Take away the filthy garments from him." And to him He said, "See, I have removed your iniquity from you, and I will clothe you with rich robes."

5. And I said, "Let them put a clean turban on his head." So they put a clean turban on his head, and they put the clothes on him. And the Angel of the LORD stood by.

6. Then the Angel of the LORD admonished Joshua, saying,

7. "Thus says the LORD of hosts: "If you will walk in My ways, And if you will keep My command, Then you shall also judge My house, And likewise have charge of My courts; I will give you places to walk Among these who stand here.

8. "Hear, O Joshua, the high priest, You and your companions who sit before you, For they are a wondrous sign; For behold, I am bringing forth My Servant the BRANCH.

9. For behold, the stone That I have laid before Joshua: Upon the stone are seven eyes. Behold, I will engrave its inscription,' Says the LORD of hosts, "And I will remove the iniquity of that land in one day.

10. In that day,' says the LORD of hosts, "Everyone will invite his neighbor Under his vine and under his fig tree."'

## Chapter 4

1. Now the angel who talked with me came back and wakened me, as a man who is wakened out of his sleep.

2. And he said to me, "What do you see?" So I said, "I am looking, and there is a lampstand of solid gold with a bowl on top of it, and on the stand seven lamps with seven pipes to the seven lamps.

3. Two olive trees are by it, one at the right of the bowl and the other at its left."

4. So I answered and spoke to the angel who talked with me, saying, "What are these, my lord?"

5. Then the angel who talked with me answered and said to me, "Do you not know what these are?" And I said, "No, my lord."

6. So he answered and said to me: "This is the word of the LORD to Zerubbabel: "Not by might nor by power, but by My Spirit,' Says the LORD of hosts.

7. "Who are you, O great mountain? Before Zerubbabel you shall become a plain! And he shall bring forth the capstone With shouts of "Grace, grace to it!""'

8. Moreover the word of the LORD came to me, saying:

9. "The hands of Zerubbabel Have laid the foundation of this temple; His hands shall also finish it. Then you will know That the LORD of hosts has sent Me to you.

10. For who has despised the day of small things? For these seven rejoice to see The plumb line in the hand of Zerubbabel. They are the eyes of the LORD, Which scan to and fro throughout the whole earth."

11. Then I answered and said to him, "What are these two olive trees--at the right of the lampstand and at its left?"

12. And I further answered and said to him, "What are these two olive branches that drip into the receptacles of the two gold pipes from which the golden oil drains?"

13. Then he answered me and said, "Do you not know what these are?" And I said, "No, my lord."

14. So he said, "These are the two anointed ones, who stand beside the Lord of the whole earth."

## Chapter 5

1. Then I turned and raised my eyes, and saw there a flying scroll.

2. And he said to me, "What do you see?" So I answered, "I see a flying scroll. Its length is twenty cubits and its width ten cubits."

3. Then he said to me, "This is the curse that goes out over the face of the whole earth: "Every thief shall be expelled,' according to this side of the scroll; and, "Every perjurer shall be expelled,' according to that side of it."

4. "I will send out the curse," says the LORD of hosts; "It shall enter the house of the thief And the house of the one who swears falsely by My name. It shall remain in the midst of his house And consume it, with its timber and stones."

5. Then the angel who talked with me came out and said to me, "Lift your eyes now, and see what this is that goes forth."

6. So I asked, "What is it?" And he said, "It is a basket that is going forth." He also said, "This is their resemblance throughout the earth:

7. Here is a lead disc lifted up, and this is a woman sitting inside the basket";

8. then he said, "This is Wickedness!" And he thrust her down into the basket, and threw the lead cover over its mouth.

9. Then I raised my eyes and looked, and there were two women, coming with the wind in their wings; for they had wings like the wings of a stork, and they lifted up the basket between earth and heaven.

10. So I said to the angel who talked with me, "Where are they carrying the basket?"

11. And he said to me, "To build a house for it in the land of Shinar; when it is ready, the basket will be set there on its base."

## Chapter 6

1. Then I turned and raised my eyes and looked, and behold, four chariots were coming from between two mountains, and the mountains were mountains of bronze.

2. With the first chariot were red horses, with the second chariot black horses,

3. with the third chariot white horses, and with the fourth chariot dappled horses--strong steeds.

4. Then I answered and said to the angel who talked with me, "What are these, my lord?"

5. And the angel answered and said to me, "These are four spirits of heaven, who go out from their station before the Lord of all the earth.

6. The one with the black horses is going to the north country, the white are going after them, and the dappled are going toward the south country."

7. Then the strong steeds went out, eager to go, that they might walk to and fro throughout the earth. And He said, "Go, walk to and fro throughout the earth." So they walked to and fro throughout the earth.

8. And He called to me, and spoke to me, saying, "See, those who go toward the north country have given rest to My Spirit in the north country."

9. Then the word of the LORD came to me, saying:

10. "Receive the gift from the captives--from Heldai, Tobijah, and Jedaiah, who have come from Babylon--and go the same day and enter the house of Josiah the son of Zephaniah.

11. Take the silver and gold, make an elaborate crown, and set it on the head of Joshua the son of Jehozadak, the high priest.

12. Then speak to him, saying, "Thus says the LORD of hosts, saying: "Behold, the Man whose name is the BRANCH! From His place He shall branch out, And He shall build the temple of the LORD;

13. Yes, He shall build the temple of the LORD. He shall bear the glory, And shall sit and rule on His throne; So He shall be a priest on His throne, And the counsel of peace shall be between them both."'

14. "Now the elaborate crown shall be for a memorial in the temple of the LORD for Helem, Tobijah, Jedaiah, and Hen the son of Zephaniah.

15. Even those from afar shall come and build the temple of the LORD. Then you shall know that the LORD of hosts has sent Me to you. And this shall come to pass if you diligently obey the voice of the LORD your God."

## Chapter 7

1. Now in the fourth year of King Darius it came to pass that the word of the LORD came to Zechariah, on the fourth day of the ninth month, Chislev,

2. when the people sent Sherezer, with Regem-Melech and his men, to the house of God, to pray before the LORD,

3. and to ask the priests who were in the house of the LORD of hosts, and the prophets, saying, "Should I weep in the fifth month and fast as I have done for so many years?"

4. Then the word of the LORD of hosts came to me, saying,

5. "Say to all the people of the land, and to the priests: "When you fasted and mourned in the fifth and seventh months during those seventy years, did you really fast for Me--for Me?

6. When you eat and when you drink, do you not eat and drink for yourselves?

7. Should you not have obeyed the words which the LORD proclaimed through the former prophets when Jerusalem and the cities around it were inhabited and prosperous, and the South and the Lowland were inhabited?"'

8. Then the word of the LORD came to Zechariah, saying,

9. "Thus says the LORD of hosts: "Execute true justice, Show mercy and compassion Everyone to his brother.

10. Do not oppress the widow or the fatherless, The alien or the poor. Let none of you plan evil in his heart Against his brother.'

11. But they refused to heed, shrugged their shoulders, and stopped their ears so that they could not hear.

12. Yes, they made their hearts like flint, refusing to hear the law and the words which the LORD of hosts had sent by His Spirit through the former prophets. Thus great wrath came from the LORD of hosts.

13. Therefore it happened, that just as He proclaimed and they would not hear, so they called out and I would not listen," says the LORD of hosts.

14. "But I scattered them with a whirlwind among all the nations which they had not known. Thus the land became desolate after them, so that no one passed through or returned; for they made the pleasant land desolate."

## Chapter 8

1. Again the word of the LORD of hosts came, saying,

2. "Thus says the LORD of hosts: "I am zealous for Zion with great zeal; With great fervor I am zealous for her.'

3. "Thus says the LORD: "I will return to Zion, And dwell in the midst of Jerusalem. Jerusalem shall be called the City of Truth, The Mountain of the LORD of hosts, The Holy Mountain.'

4. "Thus says the LORD of hosts: "Old men and old women shall again sit In the streets of Jerusalem, Each one with his staff in his hand Because of great age.

5. The streets of the city Shall be full of boys and girls Playing in its streets.'

6. "Thus says the LORD of hosts: "If it is marvelous in the eyes of the remnant of this people in these days, Will it also be marvelous in My eyes?' Says the LORD of hosts.

7. "Thus says the LORD of hosts: "Behold, I will save My people from the land of the east And from the land of the west;

8. I will bring them back, And they shall dwell in the midst of Jerusalem. They shall be My people And I will be their God, In truth and righteousness.'

9. "Thus says the LORD of hosts: "Let your hands be strong, You who have been hearing in these days These words by the mouth of the prophets, Who spoke in the day the foundation was laid For the house of the LORD of hosts, That the temple might be built.

10. For before these days There were no wages for man nor any hire for beast; There was no peace from the enemy for whoever went out or came in; For I set all men, everyone, against his neighbor.

11. But now I will not treat the remnant of this people as in the former days,' says the LORD of hosts.

12. "For the seed shall be prosperous, The vine shall give its fruit, The ground shall give her increase, And the heavens shall give their dew-- I will cause the remnant of this people To possess all these.

13. And it shall come to pass That just as you were a curse among the nations, O house of Judah and house of Israel, So I will save you, and you shall be a blessing. Do not fear, Let your hands be strong.'

14. "For thus says the LORD of hosts: "Just as I determined to punish you When your fathers provoked Me to wrath,' Says the LORD of hosts, "And I would not relent,

15. So again in these days I am determined to do good To Jerusalem and to the house of Judah. Do not fear.

16. These are the things you shall do: Speak each man the truth to his neighbor; Give judgment in your gates for truth, justice, and peace;

17. Let none of you think evil in your heart against your neighbor; And do not love a false oath. For all these are things that I hate,' Says the LORD."

18. Then the word of the LORD of hosts came to me, saying,

19. "Thus says the LORD of hosts: "The fast of the fourth month, The fast of the fifth, The fast of the seventh, And the fast of the tenth, Shall be joy and gladness and cheerful feasts For the house of Judah. Therefore love truth and peace.'

20. "Thus says the LORD of hosts: "Peoples shall yet come, Inhabitants of many cities;

21. The inhabitants of one city shall go to another, saying, "Let us continue to go and pray before the LORD, And seek the LORD of hosts. I myself will go also."

22. Yes, many peoples and strong nations Shall come to seek the LORD of hosts in Jerusalem, And to pray before the LORD.'

23. "Thus says the LORD of hosts: "In those days ten men from every language of the nations shall grasp the sleeve of a Jewish man, saying, "Let us go with you, for we have heard that God is with you.""'

## Chapter 9

1. The burden of the word of the LORD Against the land of Hadrach, And Damascus its resting place (For the eyes of men And all the tribes of Israel Are on the LORD);

2. Also against Hamath, which borders on it, And against Tyre and Sidon, though they are very wise.

3. For Tyre built herself a tower, Heaped up silver like the dust, And gold like the mire of the streets.

4. Behold, the LORD will cast her out; He will destroy her power in the sea, And she will be devoured by fire.

5. Ashkelon shall see it and fear; Gaza also shall be very sorrowful; And Ekron, for He dried up her expectation. The king shall perish from Gaza, And Ashkelon shall not be inhabited.

6. "A mixed race shall settle in Ashdod, And I will cut off the pride of the Philistines.

7. I will take away the blood from his mouth, And the abominations from between his teeth. But he who remains, even he shall be for our God, And shall be like a leader in Judah, And Ekron like a Jebusite.

8. I will camp around My house Because of the army, Because of him who passes by and him who returns. No more shall an oppressor pass through them, For now I have seen with My eyes.

9. "Rejoice greatly, O daughter of Zion! Shout, O daughter of Jerusalem! Behold, your King is coming to you; He is just and having salvation, Lowly and riding on a donkey, A colt, the foal of a donkey.

10. I will cut off the chariot from Ephraim And the horse from Jerusalem; The battle bow shall be cut off. He shall speak peace to the nations; His dominion shall be "from sea to sea, And from the River to the ends of the earth.'

11. "As for you also, Because of the blood of your covenant, I will set your prisoners free from the waterless pit.

12. Return to the stronghold, You prisoners of hope. Even today I declare That I will restore double to you.

13. For I have bent Judah, My bow, Fitted the bow with Ephraim, And raised up your sons, O Zion, Against your sons, O Greece, And made you like the sword of a mighty man."

14. Then the LORD will be seen over them, And His arrow will go forth like lightning. The Lord GOD will blow the trumpet, And go with whirlwinds from the south.

15. The LORD of hosts will defend them; They shall devour and subdue with slingstones. They shall drink and roar as if with wine; They shall be filled with blood like basins, Like the corners of the altar.

16. The LORD their God will save them in that day, As the flock of His people. For they shall be like the jewels of a crown, Lifted like a banner over His land--

17. For how great is its goodness And how great its beauty! Grain shall make the young men thrive, And new wine the young women.

## Chapter 10

1. Ask the LORD for rain In the time of the latter rain. The LORD will make flashing clouds; He will give them showers of rain, Grass in the field for everyone.

2. For the idols speak delusion; The diviners envision lies, And tell false dreams; They comfort in vain. Therefore the people wend their way like sheep; They are in trouble because there is no shepherd.

3. "My anger is kindled against the shepherds, And I will punish the goatherds. For the LORD of hosts will visit His flock, The house of Judah, And will make them as His royal horse in the battle.

4. From him comes the cornerstone, From him the tent peg, From him the battle bow, From him every ruler together.

5. They shall be like mighty men, Who tread down their enemies In the mire of the streets in the battle. They shall fight because the LORD is with them, And the riders on horses shall be put to shame.

6. "I will strengthen the house of Judah, And I will save the house of Joseph. I will bring them back, Because I have mercy on them. They shall be as though I had not cast them aside; For I am the LORD their God, And I will hear them.

7. Those of Ephraim shall be like a mighty man, And their heart shall rejoice as if with wine. Yes, their children shall see it and be glad; Their heart shall rejoice in the LORD.

8. I will whistle for them and gather them, For I will redeem them; And they shall increase as they once increased.

9. "I will sow them among the peoples, And they shall remember Me in far countries; They shall live, together with their children, And they shall return.

10. I will also bring them back from the land of Egypt, And gather them from Assyria. I will bring them into the land of Gilead and Lebanon, Until no more room is found for them.

11. He shall pass through the sea with affliction, And strike the waves of the sea: All the depths of the River shall dry up. Then the pride of Assyria shall be brought down, And the scepter of Egypt shall depart.

12. "So I will strengthen them in the LORD, And they shall walk up and down in His name," Says the LORD.

## Chapter 11

1. Open your doors, O Lebanon, That fire may devour your cedars.

2. Wail, O cypress, for the cedar has fallen, Because the mighty trees are ruined. Wail, O oaks of Bashan, For the thick forest has come down.

3. There is the sound of wailing shepherds! For their glory is in ruins. There is the sound of roaring lions! For the pride of the Jordan is in ruins.

4. Thus says the LORD my God, "Feed the flock for slaughter,

5. whose owners slaughter them and feel no guilt; those who sell them say, "Blessed be the LORD, for I am rich'; and their shepherds do not pity them.

6. For I will no longer pity the inhabitants of the land," says the LORD. "But indeed I will give everyone into his neighbor's hand and into the hand of his king. They shall attack the land, and I will not deliver them from their hand."

7. So I fed the flock for slaughter, in particular the poor of the flock. I took for myself two staffs: the one I called Beauty, and the other I called Bonds; and I fed the flock.

8. I dismissed the three shepherds in one month. My soul loathed them, and their soul also abhorred me.

9. Then I said, "I will not feed you. Let what is dying die, and what is perishing perish. Let those that are left eat each other's flesh."

10. And I took my staff, Beauty, and cut it in two, that I might break the covenant which I had made with all the peoples.

11. So it was broken on that day. Thus the poor of the flock, who were watching me, knew that it was the word of the LORD.

12. Then I said to them, "If it is agreeable to you, give me my wages; and if not, refrain." So they weighed out for my wages thirty pieces of silver.

13. And the LORD said to me, "Throw it to the potter"--that princely price they set on me. So I took the thirty pieces of silver and threw them into the house of the LORD for the potter.

14. Then I cut in two my other staff, Bonds, that I might break the brotherhood between Judah and Israel.

15. And the LORD said to me, "Next, take for yourself the implements of a foolish shepherd.

16. For indeed I will raise up a shepherd in the land who will not care for those who are cut off, nor seek the young, nor heal those that are broken, nor feed those that still stand. But he will eat the flesh of the fat and tear their hooves in pieces.

17. "Woe to the worthless shepherd, Who leaves the flock! A sword shall be against his arm And against his right eye; His arm shall completely wither, And his right eye shall be totally blinded."

## Chapter 12

1. The burden of the word of the LORD against Israel. Thus says the LORD, who stretches out the heavens, lays the foundation of the earth, and forms the spirit of man within him:

2. "Behold, I will make Jerusalem a cup of drunkenness to all the surrounding peoples, when they lay siege against Judah and Jerusalem.

3. And it shall happen in that day that I will make Jerusalem a very heavy stone for all peoples; all who would heave it away will surely be cut in pieces, though all nations of the earth are gathered against it.

4. In that day," says the LORD, "I will strike every horse with confusion, and its rider with madness; I will open My eyes on the house of Judah, and will strike every horse of the peoples with blindness.

5. And the governors of Judah shall say in their heart, "The inhabitants of Jerusalem are my strength in the LORD of hosts, their God.'

6. In that day I will make the governors of Judah like a firepan in the woodpile, and like a fiery torch in the sheaves; they shall devour all the surrounding peoples on the right hand and on the left, but Jerusalem shall be inhabited again in her own place--Jerusalem.

7. "The LORD will save the tents of Judah first, so that the glory of the house of David and the glory of the inhabitants of Jerusalem shall not become greater than that of Judah.

8. In that day the LORD will defend the inhabitants of Jerusalem; the one who is feeble among them in that day shall be like David, and the house of David shall be like God, like the Angel of the LORD before them.

9. It shall be in that day that I will seek to destroy all the nations that come against Jerusalem.

10. "And I will pour on the house of David and on the inhabitants of Jerusalem the Spirit of grace and supplication; then they will look on Me whom they pierced. Yes, they will mourn for Him as one mourns for his only son, and grieve for Him as one grieves for a firstborn.

11. In that day there shall be a great mourning in Jerusalem, like the mourning at Hadad Rimmon in the plain of Megiddo.

12. And the land shall mourn, every family by itself: the family of the house of David by itself, and their wives by themselves; the family of the house of Nathan by itself, and their wives by themselves;

13. the family of the house of Levi by itself, and their wives by themselves; the family of Shimei by itself, and their wives by themselves;

14. all the families that remain, every family by itself, and their wives by themselves.

## Chapter 13

1. "In that day a fountain shall be opened for the house of David and for the inhabitants of Jerusalem, for sin and for uncleanness.

2. "It shall be in that day," says the LORD of hosts, "that I will cut off the names of the idols from the land, and they shall no longer be remembered. I will also cause the prophets and the unclean spirit to depart from the land.

3. It shall come to pass that if anyone still prophesies, then his father and mother who begot him will say to him, "You shall not live, because you have spoken lies in the name of the LORD.' And his father and mother who begot him shall thrust him through when he prophesies.

4. "And it shall be in that day that every prophet will be ashamed of his vision when he prophesies; they will not wear a robe of coarse hair to deceive.

5. But he will say, "I am no prophet, I am a farmer; for a man taught me to keep cattle from my youth.'

6. And one will say to him, "What are these wounds between your arms?' Then he will answer, "Those with which I was wounded in the house of my friends.'

7. "Awake, O sword, against My Shepherd, Against the Man who is My Companion," Says the LORD of hosts. "Strike the Shepherd, And the sheep will be scattered; Then I will turn My hand against the little ones.

8. And it shall come to pass in all the land," Says the LORD, "That two-thirds in it shall be cut off and die, But one-third shall be left in it:

9. I will bring the one-third through the fire, Will refine them as silver is refined, And test them as gold is tested. They will call on My name, And I will answer them. I will say, "This is My people'; And each one will say, "The LORD is my God."'

## Chapter 14

1. Behold, the day of the LORD is coming, And your spoil will be divided in your midst.

2. For I will gather all the nations to battle against Jerusalem; The city shall be taken, The houses rifled, And the women ravished. Half of the city shall go into captivity, But the remnant of the people shall not be cut off from the city.

3. Then the LORD will go forth And fight against those nations, As He fights in the day of battle.

4. And in that day His feet will stand on the Mount of Olives, Which faces Jerusalem on the east. And the Mount of Olives shall be split in two, From east to west, Making a very large valley; Half of the mountain shall move toward the north And half of it toward the south.

5. Then you shall flee through My mountain valley, For the mountain valley shall reach to Azal. Yes, you shall flee As you fled from the earthquake In the days of Uzziah king of Judah. Thus the LORD my God will come, And all the saints with You.

6. It shall come to pass in that day That there will be no light; The lights will diminish.

7. It shall be one day Which is known to the LORD-- Neither day nor night. But at evening time it shall happen That it will be light.

8. And in that day it shall be That living waters shall flow from Jerusalem, Half of them toward the eastern sea And half of them toward the western sea; In both summer and winter it shall occur.

9. And the LORD shall be King over all the earth. In that day it shall be-- "The LORD is one," And His name one.

10. All the land shall be turned into a plain from Geba to Rimmon south of Jerusalem. Jerusalem shall be raised up and inhabited in her place from Benjamin's Gate to the place of the First Gate and the Corner Gate, and from the Tower of Hananel to the king's winepresses.

11. The people shall dwell in it; And no longer shall there be utter destruction, But Jerusalem shall be safely inhabited.

12. And this shall be the plague with which the LORD will strike all the people who fought against Jerusalem: Their flesh shall dissolve while they stand on their feet, Their eyes shall dissolve in their sockets, And their tongues shall dissolve in their mouths.

13. It shall come to pass in that day That a great panic from the LORD will be among them. Everyone will seize the hand of his neighbor, And raise his hand against his neighbor's hand;

14. Judah also will fight at Jerusalem. And the wealth of all the surrounding nations Shall be gathered together: Gold, silver, and apparel in great abundance.

15. Such also shall be the plague On the horse and the mule, On the camel and the donkey, And on all the cattle that will be in those camps. So shall this plague be.

16. And it shall come to pass that everyone who is left of all the nations which came against Jerusalem shall go up from year to year to worship the King, the LORD of hosts, and to keep the Feast of Tabernacles.

17. And it shall be that whichever of the families of the earth do not come up to Jerusalem to worship the King, the LORD of hosts, on them there will be no rain.

18. If the family of Egypt will not come up and enter in, they shall have no rain; they shall receive the plague with which the LORD strikes the nations who do not come up to keep the Feast of Tabernacles.

19. This shall be the punishment of Egypt and the punishment of all the nations that do not come up to keep the Feast of Tabernacles.

20. In that day "HOLINESS TO THE LORD" shall be engraved on the bells of the horses. The pots in the LORD's house shall be like the bowls before the altar.

21. Yes, every pot in Jerusalem and Judah shall be holiness to the LORD of hosts. Everyone who sacrifices shall come and take them and cook in them. In that day there shall no longer be a Canaanite in the house of the LORD of hosts.


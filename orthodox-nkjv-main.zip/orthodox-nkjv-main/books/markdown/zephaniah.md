# zephaniah

## Chapter 1

1. The word of the LORD which came to Zephaniah the son of Cushi, the son of Gedaliah, the son of Amariah, the son of Hezekiah, in the days of Josiah the son of Amon, king of Judah.

2. "I will utterly consume everything From the face of the land," Says the LORD;

3. "I will consume man and beast; I will consume the birds of the heavens, The fish of the sea, And the stumbling blocks along with the wicked. I will cut off man from the face of the land," Says the LORD.

4. "I will stretch out My hand against Judah, And against all the inhabitants of Jerusalem. I will cut off every trace of Baal from this place, The names of the idolatrous priests with the pagan priests--

5. Those who worship the host of heaven on the housetops; Those who worship and swear oaths by the LORD, But who also swear by Milcom;

6. Those who have turned back from following the LORD, And have not sought the LORD, nor inquired of Him."

7. Be silent in the presence of the Lord GOD; For the day of the LORD is at hand, For the LORD has prepared a sacrifice; He has invited His guests.

8. "And it shall be, In the day of the LORD's sacrifice, That I will punish the princes and the king's children, And all such as are clothed with foreign apparel.

9. In the same day I will punish All those who leap over the threshold, Who fill their masters' houses with violence and deceit.

10. "And there shall be on that day," says the LORD, "The sound of a mournful cry from the Fish Gate, A wailing from the Second Quarter, And a loud crashing from the hills.

11. Wail, you inhabitants of Maktesh! For all the merchant people are cut down; All those who handle money are cut off.

12. "And it shall come to pass at that time That I will search Jerusalem with lamps, And punish the men Who are settled in complacency, Who say in their heart, "The LORD will not do good, Nor will He do evil.'

13. Therefore their goods shall become booty, And their houses a desolation; They shall build houses, but not inhabit them; They shall plant vineyards, but not drink their wine."

14. The great day of the LORD is near; It is near and hastens quickly. The noise of the day of the LORD is bitter; There the mighty men shall cry out.

15. That day is a day of wrath, A day of trouble and distress, A day of devastation and desolation, A day of darkness and gloominess, A day of clouds and thick darkness,

16. A day of trumpet and alarm Against the fortified cities And against the high towers.

17. "I will bring distress upon men, And they shall walk like blind men, Because they have sinned against the LORD; Their blood shall be poured out like dust, And their flesh like refuse."

18. Neither their silver nor their gold Shall be able to deliver them In the day of the LORD's wrath; But the whole land shall be devoured By the fire of His jealousy, For He will make speedy riddance Of all those who dwell in the land.

## Chapter 2

1. Gather yourselves together, yes, gather together, O undesirable nation,

2. Before the decree is issued, Or the day passes like chaff, Before the LORD's fierce anger comes upon you, Before the day of the LORD's anger comes upon you!

3. Seek the LORD, all you meek of the earth, Who have upheld His justice. Seek righteousness, seek humility. It may be that you will be hidden In the day of the LORD's anger.

4. For Gaza shall be forsaken, And Ashkelon desolate; They shall drive out Ashdod at noonday, And Ekron shall be uprooted.

5. Woe to the inhabitants of the seacoast, The nation of the Cherethites! The word of the LORD is against you, O Canaan, land of the Philistines: "I will destroy you; So there shall be no inhabitant."

6. The seacoast shall be pastures, With shelters for shepherds and folds for flocks.

7. The coast shall be for the remnant of the house of Judah; They shall feed their flocks there; In the houses of Ashkelon they shall lie down at evening. For the LORD their God will intervene for them, And return their captives.

8. "I have heard the reproach of Moab, And the insults of the people of Ammon, With which they have reproached My people, And made arrogant threats against their borders.

9. Therefore, as I live," Says the LORD of hosts, the God of Israel, "Surely Moab shall be like Sodom, And the people of Ammon like Gomorrah-- Overrun with weeds and saltpits, And a perpetual desolation. The residue of My people shall plunder them, And the remnant of My people shall possess them."

10. This they shall have for their pride, Because they have reproached and made arrogant threats Against the people of the LORD of hosts.

11. The LORD will be awesome to them, For He will reduce to nothing all the gods of the earth; People shall worship Him, Each one from his place, Indeed all the shores of the nations.

12. "You Ethiopians also, You shall be slain by My sword."

13. And He will stretch out His hand against the north, Destroy Assyria, And make Nineveh a desolation, As dry as the wilderness.

14. The herds shall lie down in her midst, Every beast of the nation. Both the pelican and the bittern Shall lodge on the capitals of her pillars; Their voice shall sing in the windows; Desolation shall be at the threshold; For He will lay bare the cedar work.

15. This is the rejoicing city That dwelt securely, That said in her heart, "I am it, and there is none besides me." How has she become a desolation, A place for beasts to lie down! Everyone who passes by her Shall hiss and shake his fist.

## Chapter 3

1. Woe to her who is rebellious and polluted, To the oppressing city!

2. She has not obeyed His voice, She has not received correction; She has not trusted in the LORD, She has not drawn near to her God.

3. Her princes in her midst are roaring lions; Her judges are evening wolves That leave not a bone till morning.

4. Her prophets are insolent, treacherous people; Her priests have polluted the sanctuary, They have done violence to the law.

5. The LORD is righteous in her midst, He will do no unrighteousness. Every morning He brings His justice to light; He never fails, But the unjust knows no shame.

6. "I have cut off nations, Their fortresses are devastated; I have made their streets desolate, With none passing by. Their cities are destroyed; There is no one, no inhabitant.

7. I said, "Surely you will fear Me, You will receive instruction'-- So that her dwelling would not be cut off, Despite everything for which I punished her. But they rose early and corrupted all their deeds.

8. "Therefore wait for Me," says the LORD, "Until the day I rise up for plunder; My determination is to gather the nations To My assembly of kingdoms, To pour on them My indignation, All My fierce anger; All the earth shall be devoured With the fire of My jealousy.

9. "For then I will restore to the peoples a pure language, That they all may call on the name of the LORD, To serve Him with one accord.

10. From beyond the rivers of Ethiopia My worshipers, The daughter of My dispersed ones, Shall bring My offering.

11. In that day you shall not be shamed for any of your deeds In which you transgress against Me; For then I will take away from your midst Those who rejoice in your pride, And you shall no longer be haughty In My holy mountain.

12. I will leave in your midst A meek and humble people, And they shall trust in the name of the LORD.

13. The remnant of Israel shall do no unrighteousness And speak no lies, Nor shall a deceitful tongue be found in their mouth; For they shall feed their flocks and lie down, And no one shall make them afraid."

14. Sing, O daughter of Zion! Shout, O Israel! Be glad and rejoice with all your heart, O daughter of Jerusalem!

15. The LORD has taken away your judgments, He has cast out your enemy. The King of Israel, the LORD, is in your midst; You shall see disaster no more.

16. In that day it shall be said to Jerusalem: "Do not fear; Zion, let not your hands be weak.

17. The LORD your God in your midst, The Mighty One, will save; He will rejoice over you with gladness, He will quiet you with His love, He will rejoice over you with singing."

18. "I will gather those who sorrow over the appointed assembly, Who are among you, To whom its reproach is a burden.

19. Behold, at that time I will deal with all who afflict you; I will save the lame, And gather those who were driven out; I will appoint them for praise and fame In every land where they were put to shame.

20. At that time I will bring you back, Even at the time I gather you; For I will give you fame and praise Among all the peoples of the earth, When I return your captives before your eyes," Says the LORD.

